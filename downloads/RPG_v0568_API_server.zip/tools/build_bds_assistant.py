"""Build the optional BDS-only addon using the server's supported beta versions."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--net-version',required=True,help='@minecraft/server-net version supported by your BDS')
p.add_argument('--admin-version',required=True,help='@minecraft/server-admin version supported by your BDS')
args=p.parse_args()
for value in [args.net_version,args.admin_version]:
 if not value or len(value)>90 or any(c not in '0123456789abcdefghijklmnopqrstuvwxyz.-' for c in value):p.error('Invalid module version')
source=root/'dist/RPG_v0568.mcaddon'
if not source.is_file():p.error('Run python build.py first')
target=root/'dist/RPG_v0568_BDS_API.mcaddon'
with zipfile.ZipFile(source) as outer,zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as output:
 for name in outer.namelist():
  if not name.startswith('RPG_BP_'):output.writestr(name,outer.read(name));continue
  buffer=io.BytesIO()
  with zipfile.ZipFile(io.BytesIO(outer.read(name))) as pack,zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as bp:
   for filename in pack.namelist():
    data=pack.read(filename)
    if filename=='manifest.json':
     manifest=json.loads(data);manifest['header']['name']+=' BDS API'
     manifest['dependencies'] += [{'module_name':'@minecraft/server-net','version':args.net_version},{'module_name':'@minecraft/server-admin','version':args.admin_version}]
     data=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
    elif filename=='scripts/core/assistantTransport.js':data=(root/'optional_bds_api/assistantTransport.js').read_bytes()
    bp.writestr(filename,data)
  output.writestr(name,buffer.getvalue())
with zipfile.ZipFile(target) as outer:
 assert outer.testzip() is None
 for name in outer.namelist():
  with zipfile.ZipFile(io.BytesIO(outer.read(name))) as pack:assert pack.testzip() is None
print(target.name,hashlib.sha256(target.read_bytes()).hexdigest())
