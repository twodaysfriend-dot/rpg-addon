# RPG v0.6.82 · 등급 명령어와 룬 꺼내기

- 관리자 명령 `/rpg:setgrade <등급> [대상]`을 RPG 본체에서 직접 실행합니다. Bedrock 커스텀 명령어에는 `rpg:`가 필요합니다.
- 등급은 일반·레어·에픽·고대·영웅·전설·신화 또는 0~6입니다. 장비 대상은 `hand`, `head`, `chest`, `leggings`, `boots`입니다.
- `/rpg:setgrade 신화 runes 1`은 장착 룬 1번을 신화로 바꿉니다. 1~5번을 지정할 수 있고 `rune1`과 `rune:r1` 형식도 사용할 수 있습니다.
- `/rpg:runes`에서 룬을 선택하고 **일반 가방으로 꺼내기**를 누르면 등급과 강화 단계가 유지됩니다. 등급 또는 강화가 붙은 룬에는 빈 칸 하나가 필요하며 기본 룬은 계속 쌓을 수 있습니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.82로 활성화하고 월드를 다시 여세요. 모의 테스트에서 명령어 인자와 권한, 일곱 등급의 왕복 이동, 보관함 저장 실패 복구를 확인했습니다. 실제 Bedrock 월드에서의 조작은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0682
```
