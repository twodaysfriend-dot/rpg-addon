"""Build fitted armor meshes using solid swatches in the existing 128px atlases.

This changes geometry and UV selection only. Item icons and texture PNGs stay exact.
"""
from pathlib import Path
import json
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
RP=ROOT/'RPG_RP_v0578'
PALETTES={
 'adventurer':[(110,120,130),(40,48,56),(180,160,110)],
 'warden':[(50,100,65),(20,40,30),(150,180,80)],
 'astral':[(70,40,115),(25,15,45),(150,105,220)],
 'abyssal':[(22,35,40),(8,15,18),(45,145,125)],
}

def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')

def main():
 geometries=[]
 for style,colors in PALETTES.items():
  for part in ['helmet','chestplate','leggings','boots']:
   file=RP/'attachables'/f'{style}_{part}.json'
   attach=json.loads(file.read_text());desc=attach['minecraft:attachable']['description']
   image=Image.open(RP/(desc['textures']['default']+'.png')).convert('RGBA')
   pixels=[(image.getpixel((x,y))[:3],x,y) for y in range(128) for x in range(128) if image.getpixel((x,y))[3]==255]
   swatches=[]
   for color in colors:
    _,x,y=min(pixels,key=lambda p:sum((a-b)**2 for a,b in zip(p[0],color)))
    swatches.append([x,y])
   bones=[{'name':'waist','pivot':[0,12,0]},
          {'name':'body','parent':'waist','pivot':[0,24,0]},
          {'name':'head','parent':'body','pivot':[0,24,0]},
          {'name':'rightArm','parent':'body','pivot':[-5,22,0]},
          {'name':'leftArm','parent':'body','pivot':[5,22,0]},
          {'name':'rightLeg','parent':'waist','pivot':[-1.9,12,0]},
          {'name':'leftLeg','parent':'waist','pivot':[1.9,12,0]}]
   by_name={b['name']:b for b in bones}
   def cube(bone,origin,size,color=0,inflate=0):
    c={'origin':origin,'size':size,'inflate':inflate,
       'uv':{f:{'uv':swatches[color],'uv_size':[1,1]} for f in ['north','south','east','west','up','down']}}
    by_name[bone].setdefault('cubes',[]).append(c)
   if part=='helmet':
    cube('head',[-4.5,31,-4.5],[9,1.5,9])
    cube('head',[-4.5,25,3.5],[9,6,1])
    for x in [-4.5,3.5]:cube('head',[x,25,-4.5],[1,6,8])
    cube('head',[-4.5,30,-4.6],[9,1,1],2)
    cube('head',[-.5,27,-4.7],[1,3,1],1)
    if style in ['warden','abyssal']:
     for x in [-3.5,2.5]:cube('head',[x,32,-1],[1,2.5,2],2)
    if style=='astral':cube('head',[-1,30,-4.8],[2,2,1],2)
   elif part=='chestplate':
    cube('body',[-4,12,-2],[8,12,4],0,.5)
    cube('body',[-4.6,12,-2.65],[9.2,1.2,5.3],1)
    for x in [-3.5,2.5]:cube('body',[x,13.5,-2.65],[1,9,0.3],2)
    cube('body',[-1,19.5,-2.85],[2,2,.5],2)
    for bone,x in [('rightArm',-8),('leftArm',4)]:
     cube(bone,[x,18,-2],[4,6,4],0,.65)
     cube(bone,[x-.7,22,-2.7],[5.4,1.2,5.4],2)
     cube(bone,[x-.6,17.5,-2.6],[5.2,1,5.2],1)
     if style=='abyssal':cube(bone,[x+.8,23.5,-1],[1.5,3,2],1)
   elif part=='leggings':
    cube('body',[-4,12,-2],[8,2,4],1,.3)
    for bone,x in [('rightLeg',-3.9),('leftLeg',-.1)]:
     cube(bone,[x,0,-2],[4,12,4],0,.3)
     cube(bone,[x+.5,4,-2.5],[3,3,.5],1)
     cube(bone,[x+.8,5,-2.65],[2.4,1,.3],2)
   else:
    for bone,x in [('rightLeg',-3.9),('leftLeg',-.1)]:
     cube(bone,[x,0,-2],[4,5,4],0,.65)
     cube(bone,[x-.7,0,-2.9],[5.4,1,5.6],1)
     cube(bone,[x-.65,4,-2.65],[5.3,1,5.3],2)
   identifier=f'geometry.rpg.armor.{style}.{part}'
   geometries.append({'description':{'identifier':identifier,'texture_width':128,'texture_height':128,
                       'visible_bounds_width':3,'visible_bounds_height':3,'visible_bounds_offset':[0,1.5,0]},'bones':bones})
   desc['geometry']['default']=identifier
   write(file,attach)
 write(RP/'models/entity/rpg_worn_armor.geo.json',{'format_version':'1.12.0','minecraft:geometry':geometries})
 print('Built 16 fitted worn armor meshes; PNG icons/textures unchanged.')

if __name__=='__main__':main()
