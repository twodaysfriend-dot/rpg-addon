"""Use the engine's actual vanilla tool renderer, plus a small hand-item delta.

No reconstructed sword pose, first-person absolute target, or replacement mesh.
Player animations add to the vanilla rightItem bone, retaining its native motion.
"""
from pathlib import Path
import json
import math

ROOT=Path(__file__).resolve().parents[1]
RP,BP=ROOT/'RPG_RP_v0578',ROOT/'RPG_BP_v0578'
FIRST_PARENT=[95,-45,115]  # Mojang player_firstperson: empty_hand (all non-map items)
THIRD_PARENT=[-18,0,0]    # Mojang player: holding, idle right arm
EXTRA_DEGREES=0
HELD_SCALE=2
EXCLUDED={'rpg:war_god_gauntlets','rpg:fighter_fist','rpg:fist_bone_fist','rpg:apprentice_fist'}


def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')


def mul(a,b):
    return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def rotation(native):
    x,y,z=map(math.radians,[-native[0],-native[1],native[2]])
    cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
    return [[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],
            [sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]]


def native_delta(parent,extra=EXTRA_DEGREES):
    # G * D * vanilla_tool == extra_roll * G * vanilla_tool.
    # The unknown engine tool transform is preserved, never replaced by a target.
    g=rotation(parent)
    inverse=[list(row) for row in zip(*g)]
    delta=mul(mul(inverse,rotation([0,0,extra])),g)
    x=math.atan2(delta[2][1],delta[2][2])
    y=math.asin(max(-1,min(1,-delta[2][0])))
    z=math.atan2(delta[1][0],delta[0][0])
    return [round(-math.degrees(x),9),round(-math.degrees(y),9),round(math.degrees(z),9)]


def main():
    classes=json.loads((BP/'scripts/data/classWeapons.js').read_text().split('Object.freeze(',1)[1].split(');',1)[0])
    common=json.loads((BP/'scripts/data/commonWeapons.js').read_text().split('=',1)[1].strip().rstrip(';'))
    ids=[v['id'] for v in common+classes if v['id'] not in EXCLUDED]
    assert len(ids)==39 and len(set(ids))==39
    for f in (RP/'attachables').glob('*.json'):
        ident=json.loads(f.read_text())['minecraft:attachable']['description']['identifier']
        if ident in ids:f.unlink()
    for ident in ids:
        key=ident[4:]
        # Allow the built-in tool mesh and native item placement to render.
        (RP/'attachables'/(key+'.json')).unlink(missing_ok=True)
        (RP/'models/entity/held_weapons'/(key+'.geo.json')).unlink(missing_ok=True)
        for base in [BP,RP]:
            f=base/'items'/(key+'.json')
            if f.exists():
                d=json.loads(f.read_text());c=d['minecraft:item']['components']
                c['minecraft:hand_equipped']=True
                c.pop('minecraft:render_offsets',None)  # Removed by Bedrock 1.20.10.
                write(f,d)
    for f in ['models/entity/upright_weapons.geo.json','animations/upright_weapons.animation.json',
              'animations/held_weapons.animation.json']:
        (RP/f).unlink(missing_ok=True)
    chunks=[ids[i:i+8] for i in range(0,len(ids),8)]
    match=' || '.join("query.is_item_name_any('slot.weapon.mainhand', "+', '.join(repr(i) for i in group)+')' for group in chunks)
    predicate='!variable.is_paperdoll && !variable.map_face_icon && ('+match+')'
    player=json.loads((ROOT/'vanilla_player_client_base.json').read_text())
    desc=player['minecraft:client_entity']['description']
    # Keep Mojang root, skins, materials, geometry, render controllers and motion.
    profiles=json.loads((ROOT/'weapon_hand_profiles.json').read_text())['items']
    flipped=[]
    animations={}
    for mode,parent in [('first',FIRST_PARENT),('third',THIRD_PARENT)]:
        alias='rpg_native_weapon_'+mode
        full='animation.rpg.native_weapon.'+mode
        desc['animations'][alias]=full
        condition=predicate+' && '+('variable.is_first_person' if mode=='first' else '!variable.is_first_person')
        desc['scripts']['animate'].append({alias:condition})
        angles=native_delta(parent)
        animations[full]={'loop':True,'bones':{'rightItem':{'rotation':angles,'scale':HELD_SCALE}}}
    write(RP/'entity/player.entity.json',player)
    write(RP/'animations/native_weapons.animation.json',{'format_version':'1.10.0','animations':animations})
    write(ROOT/'held_weapon_pose.json',{
        'mode':'native_handheld','baseline':'engine vanilla hand_equipped renderer',
        'additionalRollDegrees':EXTRA_DEGREES,'heldScale':HELD_SCALE,
        'thirdPersonExtraDegrees':0,'thirdPersonReversedItems':flipped,
        'firstParentNative':FIRST_PARENT,'thirdParentNative':THIRD_PARENT,
        'items':ids,'predicate':predicate
    })
    from make_native_grip_textures import main as align_grips
    align_grips()
    print('Using native vanilla tool rendering for',len(ids),'items; vanilla rotations, 2x scale.')


if __name__=='__main__':
    main()
