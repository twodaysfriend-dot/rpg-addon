"""Create lossless display copies on the vanilla sword's icon coordinate frame.
Original PNGs are read only. Visible pixels are mirrored if needed, doubled with
nearest-neighbour duplication, and translated without clipping or recolouring.
"""
from pathlib import Path
import json,hashlib,shutil
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];RP=ROOT/'RPG_RP_v0578'

def main():
    atlas_file=RP/'textures/item_texture.json';atlas=json.loads(atlas_file.read_text())
    profiles=json.loads((ROOT/'weapon_hand_profiles.json').read_text())['items']
    shutil.rmtree(RP/'textures/items/native_grips',ignore_errors=True)
    records=[]
    for p in profiles:
        if p['kind'] not in {'blade','axe','polearm','staff'}:continue
        source=RP/(p['texture']+'.png');assert hashlib.sha256(source.read_bytes()).hexdigest()==p['sha256']
        original=Image.open(source).convert('RGBA');w,h=original.size;gx,gy=[v+.5 for v in p['gripPixel']]
        mirrored=p['axisPixel'][0]<p['gripPixel'][0]
        icon=original.transpose(Image.Transpose.FLIP_LEFT_RIGHT) if mirrored else original.copy()
        if mirrored:gx=w-gx
        # Source coordinates of the centre of the vanilla netherite handle.
        target=(w*2*3.5/16,h*2*12.5/16)
        icon=icon.resize((w*2,h*2),Image.Resampling.NEAREST);box=icon.getbbox();assert box
        dx,dy=round(target[0]-gx*2),round(target[1]-gy*2)
        dx=max(-box[0],min(dx,w*2-box[2]));dy=max(-box[1],min(dy,h*2-box[3]))
        image=Image.new('RGBA',(w*2,h*2),(0,0,0,0));image.paste(icon.crop(box),(box[0]+dx,box[1]+dy))
        visible=lambda im:sum(im.getchannel('A').histogram()[1:])
        assert visible(image)==visible(original)*4
        key=p['id'][4:];texture='textures/items/native_grips/'+Path(p['texture']).name
        out=RP/(texture+'.png');out.parent.mkdir(parents=True,exist_ok=True);image.save(out)
        item=json.loads((ROOT/'RPG_BP_v0578/items'/(key+'.json')).read_text())['minecraft:item']
        atlas['texture_data'][item['components']['minecraft:icon']]['textures']=texture
        error=[(gx*2+dx-target[0])/(w*2)*16,(gy*2+dy-target[1])/(h*2)*16]
        records.append({'id':p['id'],'sourceTexture':p['texture'],'displayTexture':texture,'mirrored':mirrored,'offset':[dx,dy],'gripErrorModelUnits':error,'sourceSha256':p['sha256'],'originalSize':[w,h],'displaySize':[w*2,h*2]})
    atlas_file.write_text(json.dumps(atlas,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'native_grip_alignment.json').write_text(json.dumps({'reference':'netherite handle centre at (3.5,12.5) on 16x16 icon','records':records},ensure_ascii=False,indent=2)+'\n')
    print('Created',len(records),'lossless display copies; original PNGs unchanged.')
    for p in records:
        if max(map(abs,p['gripErrorModelUnits']))>.5:print('bounded grip tolerance:',p['id'],p['gripErrorModelUnits'])
if __name__=='__main__':main()
