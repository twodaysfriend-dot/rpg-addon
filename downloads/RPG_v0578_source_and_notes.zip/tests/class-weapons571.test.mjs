import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,EquipmentSlot} from './minecraftMock.mjs';
import {CLASS_WEAPONS} from '../RPG_BP_v0578/scripts/data/classWeapons.js';
import {itemRarity} from '../RPG_BP_v0578/scripts/data/rarity.js';
import {WEAPON_LEVEL_KEY,upgradeLevel} from '../RPG_BP_v0578/scripts/data/upgrades.js';
import {enhancementQuote,enhanceEquipped} from '../RPG_BP_v0578/scripts/core/upgrades.js';
import {skillDamageFor} from '../RPG_BP_v0578/scripts/core/stats.js';
import {commonWeaponFactor} from '../RPG_BP_v0578/scripts/core/commonWeaponDamage.js';
import {setWallet,getWallet} from '../RPG_BP_v0578/scripts/core/wallet.js';
import {ensureWeapon,giveWeapon} from '../RPG_BP_v0578/scripts/core/advance.js';
import {swapChameleonWeapon} from '../RPG_BP_v0578/scripts/core/chameleon.js';
import {JOBS} from '../RPG_BP_v0578/scripts/data/jobs.js';
import {fusionQuote} from '../RPG_BP_v0578/scripts/core/fusion.js';
function ready(id='rpg:mage_book',level=0){const p=player('class');const w=new ItemStack(id);w.setDynamicProperty(WEAPON_LEVEL_KEY,level);p.equipment.set(EquipmentSlot.Mainhand,w);setWallet(p,{gold:100000,stone:1000,dust:1000});return p;}
test('all 36 class and starter items enhance to ten but have no grade or promotion',()=>{
 assert.equal(CLASS_WEAPONS.length,36);
 for(const w of CLASS_WEAPONS){const p=ready(w.id,9),q=enhancementQuote(p,'weapon',EquipmentSlot.Mainhand);assert.ok(q,w.id);assert.match(q.effect,/등급·승급 없음/);assert.equal(enhanceEquipped(p,'weapon',EquipmentSlot.Mainhand,undefined,{random:()=>0}).level,10);assert.equal(enhanceEquipped(p,'weapon',EquipmentSlot.Mainhand).ok,false);assert.equal(itemRarity(p.equipment.get(EquipmentSlot.Mainhand)),undefined);
  p.slots[3]=p.equipment.get(EquipmentSlot.Mainhand).clone();p.slots[4]=p.slots[3].clone();assert.equal(fusionQuote(p,{kind:'inventory',slot:3},{kind:'inventory',slot:4}),undefined);
 }
});
test('class enhancement adds twenty percent to physical/magic skills at ten and leaves fixed damage unchanged',()=>{
 const p=ready('rpg:mage_book',10);assert.equal(skillDamageFor(p,100,'magic'),120);assert.equal(skillDamageFor(p,100,'physical'),120);assert.equal(skillDamageFor(p,100,'fixed'),100);
 assert.equal(commonWeaponFactor(p.equipment.get(EquipmentSlot.Mainhand)),11);
 p.equipment.set(EquipmentSlot.Mainhand,new ItemStack('minecraft:stick'));assert.equal(skillDamageFor(p,100,'magic'),100);
});
test('class item upgrade rollback restores its original level and all currency',()=>{
 const p=ready('rpg:mage_book',9),before=getWallet(p),get=p.getComponent.bind(p),eq=get('minecraft:equippable');let fail=true;
 p.getComponent=k=>k==='minecraft:equippable'?{...eq,setEquipment:(s,i)=>{if(fail){fail=false;return false;}return eq.setEquipment(s,i);}}:get(k);
 assert.equal(enhanceEquipped(p,'weapon',EquipmentSlot.Mainhand,undefined,{random:()=>0}).ok,false);assert.equal(upgradeLevel(p.equipment.get(EquipmentSlot.Mainhand),'weapon'),9);assert.deepEqual(getWallet(p),before);
});
test('Chameleon form swapping retains enhancement without creating rarity',()=>{
 const p=ready();p.setDynamicProperty('rpg:job','chameleon');const w=new ItemStack(JOBS.chameleon.weapon);w.setDynamicProperty(WEAPON_LEVEL_KEY,8);p.slots[0]=w;
 assert.equal(swapChameleonWeapon(p).ok,true);assert.equal(upgradeLevel(p.slots[0],'weapon'),8);assert.equal(itemRarity(p.slots[0]),undefined);assert.equal(swapChameleonWeapon(p).ok,true);assert.equal(upgradeLevel(p.slots[0],'weapon'),8);
});
test('reissuing the same class item preserves its stack and advancement inherits its enhancement',()=>{
 const p=ready();p.setDynamicProperty('rpg:job','mage');const w=new ItemStack('rpg:mage_book');w.setDynamicProperty(WEAPON_LEVEL_KEY,7);w.nameTag='original';p.slots[5]=w;
 p.dimension.spawnItem=()=>{};ensureWeapon(p);assert.equal(upgradeLevel(p.slots[0],'weapon'),7);assert.equal(p.slots[0].nameTag,'original');
 giveWeapon(p,JOBS.sage);assert.equal(p.slots[0].typeId,JOBS.sage.weapon);assert.equal(upgradeLevel(p.slots[0],'weapon'),7);
});
