from pathlib import Path
import json,hashlib
from collections import Counter
from PIL import Image
root=Path(__file__).resolve().parents[1];rp=root/'RPG_RP_v0578'
data=json.loads((root/'native_grip_alignment.json').read_text())['records']
assert len(data)==24
for r in data:
    source=rp/(r['sourceTexture']+'.png');display=rp/(r['displayTexture']+'.png')
    assert hashlib.sha256(source.read_bytes()).hexdigest()==r['sourceSha256']
    a=Image.open(source).convert('RGBA');b=Image.open(display).convert('RGBA')
    assert b.size==(a.width*2,a.height*2)
    original=Counter(c for c in a.get_flattened_data() if c[3]);copy=Counter(c for c in b.get_flattened_data() if c[3])
    assert copy==Counter({c:n*4 for c,n in original.items()}),r['id']
    assert max(map(abs,r['gripErrorModelUnits']))<=1,r['id']
print('24 display copies: every visible RGBA pixel preserved four times; no clipping/recolouring; originals intact.')
