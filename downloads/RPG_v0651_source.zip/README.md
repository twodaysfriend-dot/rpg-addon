# RPG v0.6.51 · 갑옷 능력치·수선 2배·보스 목표 변경

Bedrock 1.21.100 이상. BP·Commands BP·RP를 모두 v0.6.51로 활성화하고 월드를 다시 여세요. 기존 팩 UUID·아이템 ID·강화·등급·저장 데이터는 유지합니다.

## RPG 갑옷 능력치 표시·장착 상태 복구

심연 수호자 각 부위의 **내구성 +4(방어 강인함)**와 **밀치기 저항 +2(20%)**를 제작 미리보기와 아이템 설명에 표시합니다. 여기서 내구성은 사진의 다이아몬드 흉갑에 표시되는 방어 강인함이며, 장비의 남은 내구도와 별개입니다.

Bedrock의 커스텀 갑옷 툴팁은 이 두 수치를 자동 표시하지 않기 때문에 설명을 보완했습니다. 기존에 지급된 아이템도 인벤토리/장착 상태에서 최대 5초 이내 설명을 갱신하며, 사용자 이름·기존 설명·강화·등급·인챈트·남은 내구도를 보존합니다. 장착 효과 태그가 사라졌으면 즉시 복구하고, 네이티브 밀치기 저항도 1초마다 재동기화합니다.

기존 수치: 부위당 강인함 +4에 따른 추가 피해 감소 4%, 밀치기 저항 20%; 4부위 강인함 16·추가 피해 감소 16%·밀치기 저항 80%. 방어 합계 28과 Bedrock 방어 20 초과분의 추가 감소, 보호 인챈트 중첩을 유지합니다. 다른 RPG 세트에 없던 보너스를 새로 부여하거나 갑옷 최대 내구도를 바꾸지는 않습니다.

## 수선 회복량 2배

수선 인챈트가 있는 손/보조 손/장착 갑옷에서 기본 수선이 회복한 만큼을 한 번 더 회복합니다. RPG 장비와 바닐라 장비 모두 적용하며, 예를 들어 기본 수선이 내구도 10을 회복하면 추가로 10을 회복합니다. 최대 내구도에서 멈추고 경험치·레벨을 추가 지급하거나 차감하지 않습니다.

안정 Script API에는 전용 수선 이벤트가 없어, 같은 슬롯에 연속 장착한 동일 아이템의 내구도 회복을 매 틱 관찰하는 방식입니다. 다른 동일 종류 아이템으로 교체하거나 벗은 경우, 사망/리스폰·재접속 시 기준을 초기화하여 잘못된 회복과 반복 증폭을 방지합니다. 모루/숫돌 수리를 위해 뺀 아이템은 추가 회복하지 않습니다. 다른 애드온이 착용 중인 동일 아이템을 직접 수리해도 회복으로 감지할 수 있으며, 같은 틱에 손상과 수선이 겹치면 관찰한 순회복량 기준으로 추가 적용합니다.

## 보스가 가까운 공격 대상을 재선택

고대 마력 골렘·외눈박이 거인·히드라·기계 블록 골렘·엘리트 데스웜의 피격자 우선 고정을 제거합니다. 야생과 던전 1~10층 모두 적용합니다.

기존 탐지 범위 안에서 **보이고 경로로 접근 가능한 가장 가까운 플레이어**를 네이티브 AI가 10틱(20TPS 기준 0.5초)마다 재탐색하도록 설정합니다. 기존 대상이 숨으면 0.5초 후 유효성을 잃고 추가 추적 유예를 두지 않습니다. 먼 플레이어가 먼저 때렸더라도 가까이 있는 다른 적으로 전환할 수 있게 합니다. 일반 몬스터의 AI, 기존 보스 HP·공격력·보상은 유지합니다.

## 검증 결과와 한계

선택된 소스의 전체 기존 회귀 검사 및 새 수선·보스 타겟 데이터 검사를 수행합니다. 수선 반복 증폭 방지·상한·장비 교체·바닐라 도구/보조 손·강화/등급/이름/설명/인챈트 보존, 기존 갑옷 설명 갱신·유실 태그 복구, 네이티브 피해 센서 130,560 조합과 5종 보스 목표 설정을 검사합니다.

이 결과는 모의 Minecraft API·스크립트·데이터 검사입니다. 실제 Minecraft 엔진의 툴팁 표시·기본 수선 이벤트 타이밍·네이티브 밀치기·길찾기와 목표 전환은 클라우드에서 실행하지 못해 인게임 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지 설치나 별도 서비스는 필요하지 않습니다. 내부 v0638 폴더명은 호환용입니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0651
```
