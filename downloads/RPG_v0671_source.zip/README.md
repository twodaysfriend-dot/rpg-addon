# RPG v0.6.71 · 블라디미르와 광역 핏빛 사슬

블러드엣지의 직업명이 블라디미르로 바뀝니다. 기존 캐릭터는 전직할 필요가 없습니다. 새로 전직하려면 마법사 레벨 20에서 `/rpg:job 블라디미르`를 사용하세요.

핏빛 사슬은 적을 좌클릭으로 맞히면 시전자 반경 10칸의 모든 적을 5초간 속박합니다. 쿨타임은 15초이며 보스는 기존 제어 저항을 적용합니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.71로 활성화하세요. 모의 전투에서 10칸 경계와 다중 속박, 기존 직업·낫 이름 호환성을 확인했습니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0671
```
