import {world,system,MolangVariableMap} from '@minecraft/server';
import {CONFIG} from '../config.js';
import {actualHurtAmount} from '../core/damageAmounts.js';
import {plagueAdjustedHit,setCombatHealth} from '../core/combatContext.js';
import {areAllies} from '../core/social.js';
import {getJobId} from '../core/playerData.js';
import {isJailed} from '../core/prison.js';
import {isTimeFrozen} from '../core/timeStopDamage.js';
import {ccTicks} from '../core/crowdControl.js';
import {BLOODEDGE_POOL_TAG,blocksBloodedgeDamage,isBloodedgePool,isShieldFront,shieldSessions,activeBloodPlague,plagueSessions} from '../core/bloodedgeState.js';
import {clearBlockPath,dist3,flatDir,getTargets,headPos,healthAlive,hurt,isSolidAt,knockback,norm3,particle,sound} from '../core/util.js';
import {notify} from '../core/hud.js';

const SPARK='rpg:blood_spark',BURST='rpg:blood_burst',SIGIL='rpg:blood_sigil';
const SLOTS=16;
const POOL_INVISIBILITY='rpg:bloodedge_pool_invisibility';
const guardTag=slot=>'rpg_be_guard_'+slot;
const frontTag=slot=>'rpg_be_front_'+slot;
const pools=new Map(),pins=new Map();
let registered=false;

const offset=(p,dy)=>({...p,y:p.y+dy});
function active(p,dimension) {
  try {
    return p.isValid!==false && p.dimension.id===dimension && healthAlive(p) &&
      getJobId(p)==='bloodedge' && !isJailed(p);
  } catch { return false; }
}
function usable(p,dimension) { return active(p,dimension) && !isTimeFrozen(p); }
function ring(dim,center,radius,count,fx=SIGIL) {
  for(let i=0;i<count;i++){
    const a=i*Math.PI*2/count;
    particle(dim,fx,{x:center.x+Math.cos(a)*radius,y:center.y,z:center.z+Math.sin(a)*radius});
  }
}
function enemies(p,loc,radius) {
  return getTargets(p,loc,radius).filter(target=>{
    if(dist3(loc,target.location)>radius)return false;
    const mode=target.getGameMode?.();
    return mode!=='creative' && mode!=='spectator';
  });
}

function clearShield(s) {
  shieldSessions.delete(s.player.id);
  try { s.player.removeTag(guardTag(s.slot)); } catch {}
  for(const entity of s.marked.values())try{entity.removeTag(frontTag(s.slot));}catch{}
}
function markShieldFront(s){
  const p=s.player,tag=frontTag(s.slot),next=new Map();
  for(const entity of p.dimension.getEntities({location:p.location,maxDistance:48,excludeTypes:['minecraft:item','minecraft:xp_orb']})){
    if(entity.id===p.id)continue;
    try{
      if(!isShieldFront(p,entity)){
        if(entity.hasTag(tag))entity.removeTag(tag);
        continue;
      }
      if(!entity.hasTag(tag))entity.addTag(tag);
      next.set(entity.id,entity);
    }catch{}
  }
  for(const [id,entity] of s.marked)if(!next.has(id))try{entity.removeTag(tag);}catch{}
  s.marked=next;
}
function shield(p,_job,def) {
  if(shieldSessions.has(p.id))return false;
  const taken=new Set(Array.from(shieldSessions.values(),state=>state.slot));
  const slot=Array.from({length:SLOTS},(_,index)=>index).find(index=>!taken.has(index));
  if(slot===undefined){notify(p,'§7지금은 블러드 배리어를 펼칠 수 없습니다.');return false;}
  const state={player:p,def,slot,dimension:p.dimension.id,until:system.currentTick+def.duration,marked:new Map()};
  try{
    markShieldFront(state);
    p.addTag(guardTag(slot));
  }catch{clearShield(state);return false;}
  shieldSessions.set(p.id,state);
  notify(p,'§c블러드 배리어 · 5초');
  return true;
}
function endShield(s,burst) {
  clearShield(s);
  if(!burst)return;
  const p=s.player,origin=p.location;
  ring(p.dimension,offset(origin,0.15),s.def.radius,36,BURST);
  sound(p.dimension,'random.explode',origin,{volume:0.75,pitch:0.6});
  for(const target of enemies(p,origin,s.def.radius)){
    if(!clearBlockPath(p.dimension,offset(origin,0.9),offset(target.location,0.9)))continue;
    if(!hurt(target,p,s.def.damage,'magic',{ignoreInvulnerability:true}))continue;
    knockback(target,target.location.x-origin.x,target.location.z-origin.z,s.def.knockback,0.35);
  }
}

const flightOptions={ignoreInvulnerability:true,immediatePlague:true};

function visibleEnemy(p,origin,target,height=0.9) {
  return clearBlockPath(p.dimension,origin,offset(target.location,height));
}

function volley(p,_job,def) {
  const dim=p.dimension,origin=headPos(p),aim=p.getViewDirection(),flat=flatDir(p);
  const pitch=Math.asin(Math.max(-1,Math.min(1,aim.y)));
  const spread=def.spread*Math.PI/180;
  const rays=Array.from({length:def.shots},(_,i)=>{
    const angle=(i/(def.shots-1)-0.5)*spread;
    return {at:origin,dir:{
      x:(flat.x*Math.cos(angle)-flat.z*Math.sin(angle))*Math.cos(pitch),y:Math.sin(pitch),
      z:(flat.z*Math.cos(angle)+flat.x*Math.sin(angle))*Math.cos(pitch),
    }};
  });
  const hits=new Map();
  let traveled=0,activeRays=rays;
  const timer=system.runInterval(()=>{
    if(!usable(p,dim.id) || traveled>=def.range || activeRays.length===0){system.clearRun(timer);return;}
    // One query per volley tick. Intersect each pellet independently so overlapping rays
    // count separately while the per-target cap applies across the entire volley.
    const targets=enemies(p,offset(origin,-0.9),Math.min(def.range,traveled+def.speed)+def.radius+1);
    const step=Math.min(def.speed,def.range-traveled)/3;
    activeRays=activeRays.filter(ray=>{
      for(let sub=0;sub<3;sub++){
        const next={x:ray.at.x+ray.dir.x*step,y:ray.at.y+ray.dir.y*step,z:ray.at.z+ray.dir.z*step};
        if(!clearBlockPath(dim,ray.at,next)){particle(dim,BURST,ray.at);return false;}
        ray.at=next;
        let contact,closest=def.radius;
        for(const target of targets){
          if(!healthAlive(target))continue;
          const gap=dist3(next,offset(target.location,0.9));
          if(gap<=closest && visibleEnemy(p,next,target)){contact=target;closest=gap;}
        }
        if(contact){
          const count=hits.get(contact.id)??0;
          if(count<def.maxHits && hurt(contact,p,def.damage,'magic',flightOptions))hits.set(contact.id,count+1);
          particle(dim,BURST,next);
          return false;
        }
      }
      particle(dim,SPARK,ray.at);
      return true;
    });
    traveled+=step*3;
  },1);
  sound(dim,'mob.blaze.shoot',origin,{volume:0.7,pitch:1.6});
  return true;
}

function lanceOrb(dim,center,radius) {
  try{
    const variables=new MolangVariableMap();
    variables.setFloat('variable.bloodedge_radius',radius);
    particle(dim,'rpg:bloodedge_lance',center,variables);
  }catch{}
}

function lanceImpact(p,dim,center,def){
  ring(dim,center,def.blastRadius,30,BURST);
  lanceOrb(dim,center,def.orbRadius);
  sound(dim,'random.explode',center,{volume:1,pitch:0.6});
  for(const target of enemies(p,center,def.blastRadius+1)){
    if(dist3(center,offset(target.location,0.9))<=def.blastRadius && visibleEnemy(p,center,target)){
      hurt(target,p,def.damage,'magic',flightOptions);
    }
  }
}

function launchLance(p,dim,center,target,def) {
  const aim=offset(target.location,0.9);
  const direction=norm3({x:aim.x-center.x,y:aim.y-center.y,z:aim.z-center.z});
  let at=center,travel=0;
  sound(dim,'mob.blaze.shoot',center,{volume:1,pitch:0.55});
  const timer=system.runInterval(()=>{
    if(!usable(p,dim.id)){system.clearRun(timer);return;}
    for(let sub=0;sub<3;sub++){
      const step=Math.min(def.speed/3,def.range-travel);
      const next={x:at.x+direction.x*step,y:at.y+direction.y*step,z:at.z+direction.z*step};
      const clear=clearBlockPath(dim,at,next);
      if(clear){at=next;travel+=step;}
      const touches=enemies(p,at,def.orbRadius+1).some(e=>
        dist3(at,offset(e.location,0.9))<=def.orbRadius && visibleEnemy(p,at,e));
      if(!clear || touches || travel>=def.range){
        system.clearRun(timer);lanceImpact(p,dim,at,def);return;
      }
    }
    lanceOrb(dim,at,def.orbRadius);
  },1);
}

function lance(p,_job,def) {
  const dim=p.dimension,start=system.currentTick;
  const timer=system.runInterval(()=>{
    if(!usable(p,dim.id)){system.clearRun(timer);return;}
    const elapsed=system.currentTick-start;
    const radius=def.orbRadius*Math.max(0.08,Math.min(1,elapsed/def.charge));
    const center=offset(headPos(p),radius+0.4);
    lanceOrb(dim,center,radius);
    if(elapsed<def.charge)return;
    system.clearRun(timer);
    const origin=p.location;
    const target=!isSolidAt(dim,center) && enemies(p,origin,def.range)
      .sort((a,b)=>dist3(origin,a.location)-dist3(origin,b.location))
      .find(e=>visibleEnemy(p,center,e));
    if(target)launchLance(p,dim,center,target,def);
    else notify(p,'§7롱기누스의 창을 던질 적이 없습니다.');
  },1);
  return true;
}
function bind(p,_job,def,target){
  const targets=enemies(p,p.location,def.radius);
  if(!target || !targets.some(enemy=>enemy.id===target.id)){
    notify(p,'§7핏빛 사슬을 쓰려면 적을 좌클릭으로 맞히세요.');return false;
  }
  const now=system.currentTick;
  for(const enemy of targets){
    const duration=ccTicks(enemy,def.duration),anchor={...enemy.location};
    pins.set(enemy.id,{owner:p,target:enemy,anchor,dimension:enemy.dimension.id,until:now+duration});
    ring(p.dimension,offset(anchor,0.5),0.8,12);
  }
  return true;
}

function actualMagicDamage(p,target,amount) {
  const health=target.getComponent('minecraft:health'),before=health?.currentValue??0;
  if(before<=0 || !hurt(target,p,amount,'magic',flightOptions))return 0;
  let after=0;
  try { after=health.currentValue; } catch {}
  return Math.max(0,before-after);
}
function healFromDamage(player,amount) {
  const hp=player.getComponent('minecraft:health');
  if(hp?.currentValue>0 && amount>0)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+amount));
}
function transfusion(p,_job,def) {
  const origin=p.location;
  const target=enemies(p,origin,def.range)
    .sort((a,b)=>b.getComponent('minecraft:health').effectiveMax-a.getComponent('minecraft:health').effectiveMax ||
      dist3(origin,a.location)-dist3(origin,b.location))
    .find(e=>visibleEnemy(p,headPos(p),e));
  if(!target){notify(p,'§7수혈할 적이 없습니다.');return false;}
  const amount=actualMagicDamage(p,target,def.damage);
  healFromDamage(p,amount*def.healRatio);
  ring(p.dimension,offset(p.location,0.7),0.75,12,SPARK);
  return true;
}
function plague(p,_job,def) {
  const dimension=p.dimension.id;
  const targets=enemies(p,p.location,def.radius).filter(e=>
    !plagueSessions.has(e.id) && visibleEnemy(p,headPos(p),e));
  if(!targets.length){notify(p,'§7혈사병에 감염시킬 적이 없습니다.');return false;}
  for(const target of targets){
    plagueSessions.set(target.id,{player:p,target,def,dimension,until:system.currentTick+def.duration,damage:0});
    ring(target.dimension,offset(target.location,0.45),1,12);
  }
  return true;
}

function onPlagueHurt(ev) {
  const target=ev.hurtEntity,mark=activeBloodPlague(target);
  if(!mark || !(ev.damage>0))return;
  const source=ev.damageSource?.damagingEntity,projectile=ev.damageSource?.damagingProjectile;
  if(isBloodedgePool(target) || blocksBloodedgeDamage(target,projectile??source))return;
  const hp=target.getComponent('minecraft:health');
  if(!hp || hp.currentValue<=0)return;
  const amount=actualHurtAmount(ev,undefined,{peek:true});
  mark.damage+=amount;
  if(!plagueAdjustedHit(source,target) && amount>0){
    setCombatHealth(target,source,hp,Math.max(0,hp.currentValue-amount*mark.def.vulnerability),
      {plagueIncluded:true,raceIncluded:true,armorIncluded:true});
  }
}

function removePoolAppearance(p){
  if(!p.hasTag(BLOODEDGE_POOL_TAG))return;
  p.triggerEvent('rpg:bloodedge_pool_off');
  p.removeTag(BLOODEDGE_POOL_TAG);
  if(p.getDynamicProperty(POOL_INVISIBILITY)===true && p.getEffect?.('invisibility')?.amplifier===1)p.removeEffect('invisibility');
  p.setDynamicProperty(POOL_INVISIBILITY,undefined);
}
function endPool(s,heal){
  const p=s.player;
  pools.delete(p.id);
  try{removePoolAppearance(p);}catch{}
  if(!heal)return;
  healFromDamage(p,s.damage*s.def.healRatio);
}
function pool(p,_job,def){
  if(pools.has(p.id))return false;
  try{
    p.addTag(BLOODEDGE_POOL_TAG);
    p.triggerEvent('rpg:bloodedge_pool_on');
    if(!p.getEffect?.('invisibility')){
      p.addEffect('invisibility',def.duration,{amplifier:1,showParticles:false});
      p.setDynamicProperty(POOL_INVISIBILITY,true);
    }
  }catch{
    try{removePoolAppearance(p);}catch{}
    return false;
  }
  const start=system.currentTick;
  pools.set(p.id,{player:p,def,dimension:p.dimension.id,until:start+def.duration,next:start+20,damage:0});
  notify(p,'§c진홍의 역류 · 10초');
  return true;
}
function pulsePool(s){
  const p=s.player,origin=p.location;
  for(const target of enemies(p,origin,s.def.radius+1)){
    const pos=target.location;
    if(Math.hypot(pos.x-origin.x,pos.z-origin.z)>s.def.radius || pos.y-origin.y<-.65 ||
       pos.y-origin.y>1.25 || !clearBlockPath(p.dimension,offset(origin,0.6),offset(pos,0.6)))continue;
    s.damage+=actualMagicDamage(p,target,s.def.damage);
  }
}
function tick(){
  const now=system.currentTick;
  for(const s of shieldSessions.values()){
    try{
      if(!active(s.player,s.dimension) || now>=s.until){
        endShield(s,now>=s.until && usable(s.player,s.dimension));continue;
      }
      markShieldFront(s);
      if(now%4===0){
        const p=s.player,head=headPos(p),dir=p.getViewDirection();
        const front=norm3({x:dir.x,y:0,z:dir.z});
        for(let i=-2;i<=2;i++)for(let row=-1;row<=1;row++){
          particle(p.dimension,SIGIL,{x:head.x+front.x*1.1-front.z*i*0.43,y:head.y-0.45+row*0.38,z:head.z+front.z*1.1+front.x*i*0.43});
        }
      }
    }catch{clearShield(s);}
  }
  for(const [id,s] of pins){
    try{
      if(now>=s.until || !usable(s.owner,s.dimension) || !healthAlive(s.target) ||
        s.target.dimension.id!==s.dimension || areAllies(s.owner,s.target) || isBloodedgePool(s.target) ||
        dist3(s.target.location,s.anchor)>12){
        pins.delete(id);continue;
      }
      if(dist3(s.target.location,s.anchor)>.05)
        s.target.teleport(s.anchor,{dimension:s.target.dimension,keepVelocity:false,checkForBlocks:true});
      s.target.clearVelocity?.();
      if(now%6===0)ring(s.target.dimension,offset(s.anchor,0.3),0.65,8);
    }catch{pins.delete(id);}
  }
  for(const s of pools.values()){
    try{
      const p=s.player;
      if(!active(p,s.dimension)){endPool(s,false);continue;}
      if(!isTimeFrozen(p)){
        if(now%4===0){
          const center=offset(p.location,0.1);
          particle(p.dimension,'rpg:bloodedge_pool',center);
          ring(p.dimension,center,s.def.radius,24);
        }
        if(now>=s.next){pulsePool(s);s.next=now+20;}
      }else if(now>=s.next){s.next=now+20;}
      if(now>=s.until)endPool(s,true);
    }catch{endPool(s,false);}
  }
  for(const [id,mark] of plagueSessions){
    try{
      const {player,target,def,dimension}=mark;
      if(!active(player,dimension) || !healthAlive(target) || target.dimension.id!==dimension ||
        areAllies(player,target) || isBloodedgePool(target) || (!CONFIG.pvp && target.typeId==='minecraft:player')){
        plagueSessions.delete(id);continue;
      }
      if(now>=mark.until){
        plagueSessions.delete(id);
        if(mark.damage>0 && usable(player,dimension)){
          hurt(target,player,mark.damage*def.burstRatio,'magic',flightOptions);
          ring(target.dimension,offset(target.location,0.7),1.2,18,BURST);
        }
      }else if(now%10===0)particle(target.dimension,SIGIL,offset(target.location,1.2));
    }catch{plagueSessions.delete(id);}
  }
}
function resetPlayer(p){
  try{
    const s=shieldSessions.get(p.id);if(s)clearShield(s);
    const state=pools.get(p.id);if(state)endPool(state,false);
    for(let i=0;i<SLOTS;i++)if(p.hasTag(guardTag(i)))p.removeTag(guardTag(i));
    removePoolAppearance(p);
  }catch{}
}
export function registerBloodedge(){
  if(registered)return;registered=true;
  world.beforeEvents?.entityHurt?.subscribe(ev=>{
    const p=ev.hurtEntity,source=ev.damageSource;
    try{if(blocksBloodedgeDamage(p,source?.damagingProjectile??source?.damagingEntity))ev.cancel=true;}catch{}
  });
  world.afterEvents.entityHurt.subscribe(ev=>{
    const p=ev.hurtEntity,source=ev.damageSource;
    try{
      if(!blocksBloodedgeDamage(p,source?.damagingProjectile??source?.damagingEntity)){onPlagueHurt(ev);return;}
      const hp=p.getComponent('minecraft:health');
      if(hp?.currentValue>0 && ev.damage>0)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+ev.damage));
    }catch{}
  });
  world.afterEvents.entityLoad?.subscribe(({entity})=>{
    try{
      for(const tag of entity.getTags())if(tag.startsWith('rpg_be_front_'))entity.removeTag(tag);
    }catch{}
  });
  world.afterEvents.playerLeave.subscribe(({playerId})=>{
    const shield=shieldSessions.get(playerId);if(shield)clearShield(shield);
    pools.delete(playerId);
    for(const [id,mark] of plagueSessions)if(id===playerId||mark.player.id===playerId)plagueSessions.delete(id);
    for(const [id,s] of pins)if(id===playerId||s.owner.id===playerId)pins.delete(id);
  });
  world.afterEvents.playerSpawn.subscribe(({player})=>resetPlayer(player));
  world.afterEvents.entityDie.subscribe(({deadEntity})=>{
    pins.delete(deadEntity.id);
    plagueSessions.delete(deadEntity.id);
    if(deadEntity.typeId==='minecraft:player')resetPlayer(deadEntity);
  });
  system.run(()=>{for(const p of world.getAllPlayers())resetPlayer(p);});
  system.runInterval(tick,1);
}

export const RUNNERS={
  bloodedge_shield:shield,bloodedge_volley:volley,bloodedge_lance:lance,bloodedge_bind:bind,bloodedge_pool:pool,
  bloodedge_transfusion:transfusion,bloodedge_plague:plague,
};
