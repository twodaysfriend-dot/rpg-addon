# RPG v0.6.68 · 보스 기믹 타격과 히드라 유도 화염구

보스 기믹이 범위 안의 플레이어에게 적중했을 때 엔진이 피해 요청을 거부하면 RPG 전투 피해 경로로 처리합니다. 직선 기믹은 예고선의 양옆과 끝부분까지 판정합니다.

| 보스 기믹 | 변경된 범위 |
|---|---|
| 바위 골렘 암석 분출 | 반경 3 → 5칸 |
| 외눈 거인 직선 광선 | 중심선 좌우 각각 0.8 → 2칸 |
| 마공학 골렘 전격 장판 | 장판마다 반경 2 → 3.5칸 |
| 엘리트 데스웜 모래 균열 | 중심선 좌우 각각 1.35 → 2.5칸 |
| 히드라 꼬리 휩쓸기 | 반경 4 → 6칸 |

히드라는 가장 가까운 적이 5칸 이상 떨어져 있으면 세 머리에서 유도 화염구 3발을 차례로 발사합니다. 화염구는 벽에 막히며, 플레이어에게 닿으면 반경 3.5칸에 피해를 주고 불을 붙입니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.68로 활성화하세요. 모의 전투로 피해 요청 거부, 확장 범위, 유도와 벽 차단을 검증했습니다. 실제 베드락에서의 피격과 연출은 별도 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0668
```
