import { ItemStack,world } from '@minecraft/server';
import { SKILLS } from '../data/skills.js';
import { JOBS,APPRENTICE_SKILLS,isChameleonJob } from '../data/jobs.js';
import { getJobId,getSkills,setSkills,getDisabled,setDisabled,getIndex,setIndex } from './playerData.js';
import { unspentPoints } from './stats.js';
import { getWallet,setWallet } from './wallet.js';
export const CHAMELEON_KEY='rpg:chameleon_progress_v1';
export const SKILLBOOK_ID='rpg:random_skillbook';
const ALLOWED=new Set(Object.values(JOBS).filter(j=>!j.placeholder&&!isChameleonJob(j.id)&&j.line!=='bloodedge').flatMap(j=>j.skills));
for(const skills of Object.values(APPRENTICE_SKILLS))for(const id of skills)if(SKILLS[id])ALLOWED.add(id);
export const CHAMELEON_ALLOWED=[...ALLOWED];
const LEGACY_ULTS=new Set(['sword_rush','fist_finale','archer_heavenly','fallen_end','sage_zoltraak','beast_grand_explosion']);
export function isUltimate(id){return !!SKILLS[id]&&(SKILLS[id].ultimate===true||SKILLS[id].name.includes('궁극기')||LEGACY_ULTS.has(id));}
export const IMPORTANT_SKILLS=new Set(['sword_annihilation','hacker_reboot','hacker_hack','holy_shield','holy_sword','holy_orb','demon_contract','demon_vampirism','blood_awaken','sun_divine_blessing','dragon_sprint','assassin_pierce','assassin_stealth','fallen_sword_frenzy','beast_berserk','mage_gravity','sage_zero','war_god_flurry','war_god_kick_flurry']);
export function learningRule(id){
  if(isUltimate(id)||id==='hacker_copy')return {cost:15,uses:3,diamondUses:1};
  if(IMPORTANT_SKILLS.has(id))return {cost:9,uses:10,diamondUses:5};
  return {cost:3,uses:null,diamondUses:0};
}
// ---- 스킬 각성: 횟수 제한을 해제 (골드 + 강화석) ----
const CHAMELEON_SLOTS = 3;
const ALL_FOR_ONE_SLOTS = 5;
export const chameleonSlots = p => getJobId(p) === 'all_for_one' ? ALL_FOR_ONE_SLOTS : CHAMELEON_SLOTS;
export function evolveCost(id){
  if(isUltimate(id)||id==='hacker_copy')return {gold:100000,stone:200};
  return {gold:30000,stone:60};
}
export function readChameleonProgress(p){
  const raw=p.getDynamicProperty(CHAMELEON_KEY);
  if(raw===undefined)return {version:1,spentSp:0,refundedSp:0,learned:[],charges:{},evolved:[],transcended:{},levelsToBook:0,pendingBooks:0};
  const state=JSON.parse(raw);
  state.refundedSp??=0;
  state.evolved??=[];
  state.transcended??={};
  if(state?.version!==1||!Number.isSafeInteger(state.spentSp)||state.spentSp<0||!Array.isArray(state.learned)||!state.charges||!Number.isInteger(state.levelsToBook)||state.levelsToBook<0||state.levelsToBook>4||!Number.isSafeInteger(state.pendingBooks)||state.pendingBooks<0)throw Error('카멜레온 성장 데이터 오류');
  for(const n of Object.values(state.charges))if(!Number.isSafeInteger(n)||n<0)throw Error('스킬 사용 횟수 데이터 오류');
  if(!Number.isSafeInteger(state.refundedSp)||state.refundedSp<0)throw Error('분해 SP 데이터 오류');
  if(!Array.isArray(state.evolved)||state.evolved.length>ALL_FOR_ONE_SLOTS||state.evolved.some(x=>typeof x!=='string'))throw Error('스킬 각성 데이터 오류');
  if(!state.transcended||typeof state.transcended!=='object'||Array.isArray(state.transcended)||Object.keys(state.transcended).length>ALL_FOR_ONE_SLOTS||Object.values(state.transcended).some(n=>!Number.isInteger(n)||n<0||n>3))throw Error('스킬 초월 데이터 오류');
  return state;
}
export function saveChameleonProgress(p,state){p.setDynamicProperty(CHAMELEON_KEY,JSON.stringify(state));}
export function learningSpent(p){const state=readChameleonProgress(p);return state.spentSp-state.refundedSp;}
export function syncChameleonLoadout(p){
  if(!isChameleonJob(getJobId(p)))return;
  const state=readChameleonProgress(p),known=[...new Set([...state.learned,...getSkills(p).filter(id=>ALLOWED.has(id))])];
  const exclusive=id=>SKILLS[id]?.line==='bloodedge';
  const removed=known.filter(exclusive),retained=known.filter(id=>!exclusive(id));
  if(removed.length){
    // Use the normal dismantle refund for legacy learned skills, once per ID.
    state.refundedSp+=removed.reduce((sum,id)=>sum+learningRule(id).cost,0);
    for(const id of removed){delete state.charges[id];delete state.transcended[id];}
  }
  const evolved=state.evolved.filter(id=>!exclusive(id));
  for(const id of Object.keys(state.transcended))if(exclusive(id))delete state.transcended[id];
  if(JSON.stringify(retained)!==JSON.stringify(state.learned)||evolved.length!==state.evolved.length){
    state.learned=retained;state.evolved=evolved;saveChameleonProgress(p,state);
  }
  const skills=[...new Set([...JOBS.chameleon.skills,...retained])];
  if(JSON.stringify(skills)!==JSON.stringify(getSkills(p)))setSkills(p,skills);
}
export function isEvolved(p,id,state){try{return (state??readChameleonProgress(p)).evolved.slice(0,chameleonSlots(p)).includes(id);}catch{return false;}}
export function remainingSkillUses(p,id){const rule=learningRule(id);if(rule.uses===null)return null;if(isEvolved(p,id))return null;return readChameleonProgress(p).charges[id]??rule.uses;}
function learn(p,id,free){
  if(!isChameleonJob(getJobId(p))||!ALLOWED.has(id))return {ok:false,message:'카멜레온이 배울 수 없는 스킬입니다.'};
  syncChameleonLoadout(p);if(getSkills(p).includes(id))return {ok:false,message:'이미 배운 스킬입니다.'};
  const state=readChameleonProgress(p),rule=learningRule(id);
  if(!free&&unspentPoints(p)<rule.cost)return {ok:false,message:`레벨업 SP ${rule.cost}가 필요합니다. 남은 SP ${unspentPoints(p)}`};
  const old=p.getDynamicProperty(CHAMELEON_KEY),skills=getSkills(p);
  if(!free){if(!Number.isSafeInteger(state.spentSp+rule.cost))return {ok:false,message:'SP 저장 범위를 초과했습니다.'};state.spentSp+=rule.cost;}
  state.learned.push(id);if(rule.uses!==null&&state.charges[id]===undefined)state.charges[id]=rule.uses;
  try{saveChameleonProgress(p,state);setSkills(p,[...skills,id]);}
  catch(error){p.setDynamicProperty(CHAMELEON_KEY,old);setSkills(p,skills);return {ok:false,message:'스킬 저장 실패: '+String(error)};}
  return {ok:true,id,message:`§a${SKILLS[id].name} 습득! ${free?'스킬북 사용':rule.cost+' SP 소비'}${rule.uses===null?' · 횟수 제한 없음':' · '+state.charges[id]+'회 사용 가능'}`};
}
export function purchaseChameleonSkill(p,id){return learn(p,id,false);}
export function dismantleChameleonSkill(p,id){
  try{
    if(!isChameleonJob(getJobId(p))||!ALLOWED.has(id))return {ok:false,message:'분해 가능한 카멜레온 차용 기술이 아닙니다.'};
    syncChameleonLoadout(p);const state=readChameleonProgress(p),skills=getSkills(p);
    if(!state.learned.includes(id)||!skills.includes(id))return {ok:false,message:'이미 분해했거나 배우지 않은 기술입니다.'};
    const refund=learningRule(id).cost;if(!Number.isSafeInteger(state.refundedSp+refund))return {ok:false,message:'SP 저장 범위를 초과했습니다.'};
    const before=p.getDynamicProperty(CHAMELEON_KEY),disabled=getDisabled(p),index=getIndex(p);
    state.learned=state.learned.filter(s=>s!==id);state.evolved=state.evolved.filter(s=>s!==id);delete state.transcended[id];state.refundedSp+=refund;
    // Retain charges and cooldowns so relearning cannot refill limited skills.
    try{saveChameleonProgress(p,state);setSkills(p,skills.filter(s=>s!==id));setDisabled(p,disabled.filter(s=>s!==id));setIndex(p,0);}
    catch(error){p.setDynamicProperty(CHAMELEON_KEY,before);setSkills(p,skills);setDisabled(p,disabled);setIndex(p,index);throw error;}
    return {ok:true,refund,message:`${SKILLS[id].name} 분해 · ${refund} SP 환급. 스킬북 기술도 같은 등급의 SP를 받습니다.`};
  }catch(error){return {ok:false,message:'분해 실패: '+String(error)};}
}
export function executeChameleonSkill(p,id,runner){
  if(!isChameleonJob(getJobId(p)))return {ok:true,result:runner()};
  if(SKILLS[id]?.line==='bloodedge')return {ok:false,message:'블라디미르 전용 스킬입니다.'};
  if(!ALLOWED.has(id))return {ok:true,result:runner()};
  const rule=learningRule(id);if(rule.uses===null)return {ok:true,result:runner()};
  const state=readChameleonProgress(p);
  if(isEvolved(p,id,state))return {ok:true,result:runner()};
  const left=state.charges[id]??rule.uses;
  if(left<=0)return {ok:false,message:'사용 횟수가 없습니다. /rpg:skillbook 에서 다이아몬드로 충전하세요.'};
  const before=p.getDynamicProperty(CHAMELEON_KEY);state.charges[id]=left-1;saveChameleonProgress(p,state);
  try{const result=runner();if(result===false)p.setDynamicProperty(CHAMELEON_KEY,before);return {ok:true,result};}
  catch(error){p.setDynamicProperty(CHAMELEON_KEY,before);return {ok:false,message:'스킬 발동 오류: '+String(error)};}
}
export function rechargeSkill(p,id,diamonds=1){
  try{
    if(!isChameleonJob(getJobId(p))||!getSkills(p).includes(id)||learningRule(id).uses===null)return {ok:false,message:'충전 가능한 카멜레온 스킬이 아닙니다.'};
    if(isEvolved(p,id))return {ok:false,message:'이미 각성해 횟수 제한이 없는 스킬입니다.'};
    if(!Number.isInteger(diamonds)||diamonds<1||diamonds>64)return {ok:false,message:'다이아 수량은 1~64개입니다.'};
    const inv=p.getComponent('minecraft:inventory')?.container,entries=[];let need=diamonds;
    if(inv)for(let i=0;i<inv.size&&need>0;i++){const t=inv.getItem(i);if(t?.typeId==='minecraft:diamond'){const take=Math.min(t.amount,need);entries.push({slot:i,old:t.clone(),take});need-=take;}}
    if(need>0)return {ok:false,message:'다이아몬드가 부족합니다.'};
    const state=readChameleonProgress(p),before=p.getDynamicProperty(CHAMELEON_KEY),rule=learningRule(id);
    const count=(state.charges[id]??rule.uses)+rule.diamondUses*diamonds;if(!Number.isSafeInteger(count))return {ok:false,message:'저장 범위를 초과했습니다.'};
    state.charges[id]=count;
    try{for(const e of entries){if(e.old.amount===e.take)inv.setItem(e.slot,undefined);else{const t=e.old.clone();t.amount-=e.take;inv.setItem(e.slot,t);}}saveChameleonProgress(p,state);}
    catch(error){for(const e of entries)inv.setItem(e.slot,e.old);p.setDynamicProperty(CHAMELEON_KEY,before);throw error;}
    return {ok:true,message:`다이아 ${diamonds}개 사용 · ${SKILLS[id].name} 남은 횟수 ${count}`};
  }catch(error){return {ok:false,message:String(error)};}
}
export function evolvableSkills(p){
  return getSkills(p).filter(id=>SKILLS[id]&&ALLOWED.has(id)&&learningRule(id).uses!==null);
}
export function evolveChameleonSkill(p,id){
  try{
    if(!isChameleonJob(getJobId(p)))return {ok:false,message:'카멜레온과 올포원만 스킬을 각성할 수 있습니다.'};
    syncChameleonLoadout(p);
    if(!ALLOWED.has(id)||!getSkills(p).includes(id))return {ok:false,message:'배우지 않은 스킬입니다.'};
    if(learningRule(id).uses===null)return {ok:false,message:'원래 횟수 제한이 없는 스킬은 각성할 필요가 없습니다.'};
    const state=readChameleonProgress(p);
    if(state.evolved.includes(id))return {ok:false,message:'이미 각성한 스킬입니다.'};
    const limit=chameleonSlots(p);
    if(state.evolved.length>=limit)return {ok:false,message:`각성은 최대 ${limit}개까지입니다. 다른 각성 스킬을 분해해야 슬롯이 납니다.`};
    const cost=evolveCost(id),wallet=getWallet(p);
    if(wallet.gold<cost.gold||wallet.stone<cost.stone)return {ok:false,message:`재료 부족: 골드 ${cost.gold.toLocaleString()} / 강화석 ${cost.stone.toLocaleString()} 필요 (보유 골드 ${wallet.gold.toLocaleString()} / 강화석 ${wallet.stone.toLocaleString()})`};
    const before=p.getDynamicProperty(CHAMELEON_KEY);
    state.evolved.push(id);
    try{setWallet(p,{...wallet,gold:wallet.gold-cost.gold,stone:wallet.stone-cost.stone});saveChameleonProgress(p,state);}
    catch(error){try{setWallet(p,wallet);}catch{}p.setDynamicProperty(CHAMELEON_KEY,before);throw error;}
    return {ok:true,message:`§d✦ ${SKILLS[id].name} 각성! §f이제 횟수 제한 없이 사용합니다. §7(골드 ${cost.gold.toLocaleString()}, 강화석 ${cost.stone.toLocaleString()} 소비 · ${state.evolved.length}/${limit})`};
  }catch(error){return {ok:false,message:'진화 실패: '+String(error)};}
}
export function deliverSkillBooks(p){
  const state=readChameleonProgress(p);if(state.pendingBooks<=0)return 0;
  const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return 0;
  const before=p.getDynamicProperty(CHAMELEON_KEY),changed=[];let remaining=state.pendingBooks;
  try{
    for(let i=0;i<inv.size&&remaining>0;i++){
      const token=inv.getItem(i);if(token&&token.typeId!==SKILLBOOK_ID)continue;
      const room=64-(token?.amount??0);if(room<=0)continue;
      changed.push({slot:i,old:token?.clone()});const take=Math.min(room,remaining);
      const next=token?.clone()??new ItemStack(SKILLBOOK_ID,1);next.amount=(token?.amount??0)+take;inv.setItem(i,next);remaining-=take;
    }
    const delivered=state.pendingBooks-remaining;state.pendingBooks=remaining;saveChameleonProgress(p,state);return delivered;
  }catch(error){for(const e of changed)inv.setItem(e.slot,e.old);p.setDynamicProperty(CHAMELEON_KEY,before);throw error;}
}
export function awardChameleonLevels(p,levels){
  if(!isChameleonJob(getJobId(p))||!Number.isSafeInteger(levels)||levels<=0)return;
  const state=readChameleonProgress(p),total=state.levelsToBook+levels;
  state.pendingBooks+=Math.floor(total/5);state.levelsToBook=total%5;saveChameleonProgress(p,state);
  const delivered=deliverSkillBooks(p);if(delivered)p.sendMessage(`§b[카멜레온] 랜덤 스킬북 ${delivered}권 획득! /rpg:skillbook`);
}
const usedAt=new Map();
world.afterEvents.playerLeave.subscribe(ev=>usedAt.delete(ev.playerId));
export function useRandomSkillBook(p,random=Math.random){
  try{
    if(!isChameleonJob(getJobId(p)))return {ok:false,message:'카멜레온만 랜덤 스킬북을 사용할 수 있습니다.'};
    syncChameleonLoadout(p);const pool=CHAMELEON_ALLOWED.filter(id=>!isUltimate(id)&&!getSkills(p).includes(id));
    if(!pool.length)return {ok:false,message:'배울 수 있는 일반 스킬을 모두 배웠습니다. 책은 소비하지 않습니다.'};
    const inv=p.getComponent('minecraft:inventory')?.container;let slot=-1;
    if(inv)for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId===SKILLBOOK_ID){slot=i;break;}
    if(slot<0)return {ok:false,message:'가방에 랜덤 스킬북이 없습니다.'};
    const roll=random();if(!Number.isFinite(roll)||roll<0||roll>=1)throw Error('스킬북 난수 오류');
    const token=inv.getItem(slot).clone(),before=p.getDynamicProperty(CHAMELEON_KEY),skills=getSkills(p);
    const result=learn(p,pool[Math.floor(roll*pool.length)],true);if(!result.ok)return result;
    try{if(token.amount===1)inv.setItem(slot,undefined);else{const t=token.clone();t.amount--;inv.setItem(slot,t);}}
    catch(error){p.setDynamicProperty(CHAMELEON_KEY,before);setSkills(p,skills);inv.setItem(slot,token);throw error;}
    return result;
  }catch(error){return {ok:false,message:String(error)};}
}
export function skillBookItemUse(p,tick){if(usedAt.get(p.id)===tick)return;usedAt.set(p.id,tick);const result=useRandomSkillBook(p);p.sendMessage((result.ok?'§a':'§c')+result.message);}
