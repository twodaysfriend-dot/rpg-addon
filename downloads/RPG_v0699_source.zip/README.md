# RPG v0.6.99 · 올포원, 직업 교체, 전직관 고정

- 직업 교환과 복귀에 성공하면 30분의 공통 대기시간이 시작됩니다. 남은 시간은 `/rpg:jobchange`에서 확인할 수 있습니다. 이번 버전부터 교환만으로 사용한 직업은 복귀 목록에 추가되지 않습니다. 이전 버전에서 교환과 직접 전직을 구분하지 않고 저장한 이력은 보존합니다.
- 카멜레온은 RPG 레벨 80 이상, 차용 스킬 15개 습득, 전설 등급 룬 1개 장착을 완료하고 구욱에게 말을 걸면 올포원으로 전직할 수 있습니다. 기존 무기와 차용 스킬을 이어서 사용할 수 있습니다.
- 올포원은 `/rpg:skillbook`에서 각성 5개와 초월 5개를 각각 사용할 수 있습니다. 각성은 사용 횟수 제한을 해제합니다. 초월은 각성 여부와 상관없이 습득한 공격·직접 회복 기술에 적용할 수 있습니다. 초월강화는 기술당 최대 +3입니다.
- 전직관은 배치 위치에 고정됩니다. 기존 전직관은 업데이트 후 처음 불러온 위치에 고정됩니다. 크리에이티브 인벤토리의 **전직관 삭제 막대**를 들고 전직관을 우클릭하거나 모바일에서 상호작용하면 그 전직관을 제거합니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.99로 활성화하세요. 자동 검사에서 교환·복귀 제한, 올포원 전직과 슬롯 한도, 전직관 고정과 삭제 권한을 확인했습니다. 실제 Bedrock 월드에서는 확인하지 못했습니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
python3 tools/build_protected_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0699
```
