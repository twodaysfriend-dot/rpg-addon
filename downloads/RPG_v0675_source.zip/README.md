# RPG v0.6.75 · 공속 룬의 스킬 투사체 가속

- 공속 룬은 원거리 무기와 플레이어가 스킬로 발사하는 투사체의 비행 속도를 높입니다. 같은 장착 등급과 강화 배율이 적용되며, 신화 +10에서 **최대 3배**입니다.
- 대상에는 혈액 난사와 롱기누스의 창, 용의 브레스, 마법사의 투사체, 충격파, 검기, 작살, 유도 차크람과 각종 스킬 화살이 포함됩니다. 가속 중에도 가능한 한 짧은 이동 구간으로 나눠 기존 벽 충돌과 사거리를 적용합니다.
- 충전·시전·연사 간격과 스킬 피해·쿨타임에는 이번 비행 속도 변경이 적용되지 않습니다. 몬스터가 발사한 투사체는 시전자에게 장착 효과가 없으므로 기본 속도로 날아갑니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.75로 활성화하고 월드를 다시 여세요. 모의 전투에서 공속 룬 장착 여부별 비행 속도, 용의 브레스의 명중·벽·사거리 판정과 기존 전투 회귀 검사를 확인했습니다. 실제 Bedrock 월드에서의 연출은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0675
```
