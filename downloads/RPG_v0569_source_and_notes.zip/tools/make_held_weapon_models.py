"""Build enlarged hand-bound meshes; read the original icons without changing them."""
from pathlib import Path
import json
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
RP = ROOT / 'RPG_RP_v0569'

# Pixel coordinates are the centre of the grip, rather than the image centre.
# The PNG remains the inventory icon and the model's unmodified texture.
WEAPONS = [
    ('common_redmoon_blade', 'common_weapons/redmoon_blade', [98, 106], 24, -45),
    ('common_battle_sword', 'common_weapons/magitech_sword', [98, 106], 24, -45),
    ('common_magitech_greatsword', 'common_weapons/magitech_greatsword', [98, 106], 28, -45),
    ('common_battle_spear', 'common_weapons/elite_knight_greatsword', [23, 103], 28, 45),
    ('common_frost_greatsword', 'common_weapons/frost_greatsword', [99, 106], 28, -45),
    ('common_flame_greatsword', 'common_weapons/flame_greatsword', [99, 106], 28, -45),
    ('common_beast_axe', 'common_weapons/beast_axe', [100, 107], 28, -45),
    ('sun_heir_axe', 'sun_heir_axe', [31, 96], 28, 45),
]


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def geometry(key, texture, grip, side, turn):
    image = Image.open(RP / ('textures/items/' + texture + '.png')).convert('RGBA')
    assert image.size == (128, 128)
    alpha = image.getchannel('A')
    unit = side / 128
    thickness = 0.6
    def occupied(x, y):
        return 0 <= x < 128 and 0 <= y < 128 and alpha.getpixel((x, y)) >= 128
    # Two full icon faces, plus only the silhouette edges. No opaque rectangle.
    cubes = [{
        'origin': [-grip[0]*unit, (grip[1]-128)*unit, -thickness/2],
        'size': [side, side, thickness],
        'uv': {'north': {'uv': [128, 0], 'uv_size': [-128, 128]},
               'south': {'uv': [0, 0], 'uv_size': [128, 128]}}
    }]
    for y in range(128):
        for x in range(128):
            if not occupied(x, y):
                continue
            faces = {}
            for face, dx, dy in [('west', -1, 0), ('east', 1, 0),
                                 ('up', 0, -1), ('down', 0, 1)]:
                if not occupied(x+dx, y+dy):
                    faces[face] = {'uv': [x, y], 'uv_size': [1, 1]}
            if faces:
                cubes.append({'origin': [(x-grip[0])*unit, (grip[1]-y-1)*unit, -thickness/2],
                              'size': [unit, unit, thickness], 'uv': faces})
    return {'format_version': '1.16.0', 'minecraft:geometry': [{
        'description': {'identifier': 'geometry.rpg.held.'+key,
                        'texture_width': 128, 'texture_height': 128,
                        'visible_bounds_width': 6, 'visible_bounds_height': 6,
                        'visible_bounds_offset': [0, 1, 0]},
        'bones': [
            {'name': 'grip', 'binding': 'query.item_slot_to_bone_name(context.item_slot)',
             'pivot': [0, 0, 0]},
            {'name': 'blade', 'parent': 'grip', 'pivot': [0, 0, 0],
             'rotation': [0, 0, turn], 'cubes': cubes}
        ]
    }]}


def main():
    for key, texture, grip, side, turn in WEAPONS:
        write(RP / 'models/entity/held_weapons' / (key+'.geo.json'),
              geometry(key, texture, grip, side, turn))
        write(RP / 'attachables' / (key+'.json'), {
            'format_version': '1.10.0', 'minecraft:attachable': {'description': {
                'identifier': 'rpg:'+key,
                'materials': {'default': 'entity_alphatest', 'enchanted': 'entity_alphatest_glint'},
                'textures': {'default': 'textures/items/'+texture,
                             'enchanted': 'textures/misc/enchanted_item_glint'},
                'geometry': {'default': 'geometry.rpg.held.'+key},
                'animations': {'first_person': 'animation.rpg.held_weapon.first_person',
                               'third_person': 'animation.rpg.held_weapon.third_person'},
                'scripts': {'animate': [{'first_person': 'context.is_first_person'},
                                        {'third_person': '!context.is_first_person'}]},
                'render_controllers': ['controller.render.item_default']
            }}})
    # Binding has a -24 Y offset. Translate the grip, not the blade centre.
    # The player's hand continues to supply movement and melee swing animation.
    write(RP / 'animations/held_weapons.animation.json', {
        'format_version': '1.10.0', 'animations': {
            'animation.rpg.held_weapon.first_person': {
                'loop': True, 'bones': {'grip': {
                    'position': [0, 24, 0], 'rotation': [0, 0, -15], 'scale': 0.9}}},
            'animation.rpg.held_weapon.third_person': {
                'loop': True, 'bones': {'grip': {
                    'position': [0, 24, 0], 'rotation': [-75, 0, 0], 'scale': 1.0}}}
        }})
    print('Generated 8 hand-bound weapon models (original PNGs unchanged).')


if __name__ == '__main__':
    main()
