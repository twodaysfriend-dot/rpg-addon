import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root=path.resolve('.');
const rp=path.join(root,'RPG_RP_v0569');
const read=(file)=>JSON.parse(fs.readFileSync(file,'utf8'));
const ids=['common_redmoon_blade','common_battle_sword','common_magitech_greatsword',
 'common_battle_spear','common_frost_greatsword','common_flame_greatsword','common_beast_axe','sun_heir_axe'];
const animations=read(path.join(rp,'animations/held_weapons.animation.json')).animations;

test('all eight enlarged models resolve original textures and both viewing perspectives',()=>{
 for(const id of ids){
  const a=read(path.join(rp,'attachables',id+'.json'))['minecraft:attachable'].description;
  assert.equal(a.identifier,'rpg:'+id);
  assert.ok(fs.existsSync(path.join(rp,a.textures.default+'.png')));
  const g=read(path.join(rp,'models/entity/held_weapons',id+'.geo.json'))['minecraft:geometry'][0];
  assert.equal(a.geometry.default,g.description.identifier);
  assert.equal(g.description.texture_width,128);
  assert.equal(g.description.texture_height,128);
  const [grip,blade]=g.bones;
  assert.equal(grip.binding,'query.item_slot_to_bone_name(context.item_slot)');
  assert.equal(blade.parent,grip.name);
  assert.deepEqual(blade.pivot,[0,0,0]);
  assert.equal(blade.cubes[0].size[0],id==='common_redmoon_blade'||id==='common_battle_sword'?24:28);
  assert.ok(blade.cubes.length<1500,'bounded mobile mesh size');
  for(const p of ['first_person','third_person']){
   assert.ok(animations[a.animations[p]]);
   assert.ok(a.scripts.animate.some(x=>Object.hasOwn(x,p)));
  }
  assert.deepEqual(a.render_controllers,['controller.render.item_default']);
 }
});

test('all original common weapon textures retain their supplied hashes',()=>{
 for(const entry of read(path.join(root,'original_weapon_texture_mapping.json'))){
  const png=fs.readFileSync(path.join(rp,'textures/items/common_weapons',entry.target));
  assert.equal(crypto.createHash('sha256').update(png).digest('hex'),entry.sha256);
 }
});

test('both perspectives compensate binding height and keep enlarged scale',()=>{
 for(const a of Object.values(animations)){
  assert.deepEqual(a.bones.grip.position,[0,24,0]);
  assert.ok(a.bones.grip.scale>=0.9);
  assert.equal(a.loop,true);
 }
});
