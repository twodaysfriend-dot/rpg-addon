import {teleportForSkill,insideDungeon} from '../RPG_BP_v0569/scripts/core/dungeonMovement.js';
import {RUNNERS as FIRE} from '../RPG_BP_v0569/scripts/skills/fire.js';
import {SKILLS} from '../RPG_BP_v0569/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0569/scripts/data/jobs.js';
import test,{after} from 'node:test';
import assert from 'node:assert/strict';
import {player,players,world,events,system,timeouts,intervals,ItemStack,replies,forms} from './minecraftMock.mjs';
import {DUNGEON_KEY,RETURN_KEY,createDungeon,listDungeons,dungeonTick,enterDungeon,startDungeon as queueStart,soloDungeon as queueSolo,leaveDungeon,dungeonDeath,recoverDungeons,registerDungeons,removeDungeon,openDungeons} from '../RPG_BP_v0569/scripts/core/dungeons.js';
import {dungeonRuns,dungeonLobbies,dungeonHudText} from '../RPG_BP_v0569/scripts/core/dungeonState.js';
import {DUNGEON_LOOT_KEY,creditDungeonClear,claimDungeonLoot,readDungeonLoot} from '../RPG_BP_v0569/scripts/core/dungeonRewards.js';
import {DUNGEON,DUNGEON_TIERS,dungeonBlock,ceilingHeight} from '../RPG_BP_v0569/scripts/data/dungeons.js';
import {getWallet,setWallet} from '../RPG_BP_v0569/scripts/core/wallet.js';
import {CATALYST_ID} from '../RPG_BP_v0569/scripts/data/upgrades.js';
import {runRpgAction} from '../RPG_BP_v0569/scripts/core/rpgActions.js';
import {notify,refreshHud} from '../RPG_BP_v0569/scripts/core/hud.js';
const realNow=Date.now;let clock=1000000;Date.now=()=>clock;after(()=>{Date.now=realNow;});
const mineralDrops=[],blocks=new Map(),mobs=new Map(),spawned=[],areas=new Set(),commands=[],key=q=>[q.x,q.y,q.z].join(',');let counter=0,blockWrites=0,spawnFailure=false;
const dim={id:'minecraft:overworld',spawnItem(item,location){mineralDrops.push({item,location});},runCommand(command){commands.push(command);const p=command.split(' ');if(command.startsWith('tickingarea add'))areas.add(p.at(-2));if(command.startsWith('tickingarea remove'))areas.delete(p.at(-1));assert.ok(areas.size<=1);return {successCount:1};},
 getBlock(q){const k=key(q);return {location:{x:q.x,y:q.y,z:q.z},dimension:dim,get typeId(){return blocks.get(k)??'minecraft:air';},get isAir(){return !blocks.has(k);},get isSolid(){return blocks.has(k);},setType(id){blockWrites++;blocks.set(k,id);}};},
 getEntities(query={}){return [...mobs.values()].filter(m=>!query.tags||query.tags.every(t=>m.hasTag(t)));},
 spawnEntity(typeId,location){if(spawnFailure)throw Error('spawn unavailable');const tags=new Set(),m={id:'mob'+(++counter),typeId,dimension:dim,location,isValid:true,tags,addTag:t=>tags.add(t),hasTag:t=>tags.has(t),triggerEvent(e){this.event=e;},remove(){mobs.delete(this.id);this.isValid=false;}};if(typeId==='rpg:dungeon_loot_cache'){
 const values=new Map(),slots=new Array(27);m.getDynamicProperty=k=>values.get(k);m.setDynamicProperty=(k,v)=>values.set(k,v);
 m.getComponent=k=>k==='minecraft:inventory'?{container:{size:27,getItem:i=>slots[i]?.clone(),setItem:(i,v)=>{slots[i]=v?.clone();}}}:undefined;
 }mobs.set(m.id,m);spawned.push(m);return m;}};
world.getEntity=id=>mobs.get(id);
world.getDimension=id=>{if(id!==dim.id)throw Error('bad dimension');return dim;};
for(const name of ['playerBreakBlock','playerPlaceBlock','explosion'])world.beforeEvents[name]={listeners:[],subscribe(fn){this.listeners.push(fn);}};
function actor(id,x=0,admin=false){const p=player(id,30,{dimension:dim,location:{x,y:64,z:0},commandPermissionLevel:admin?1:0});p.home={...p.location};p.teleports=0;p.teleport=(loc,opt)=>{p.teleports++;p.location={...loc};p.dimension=opt.dimension;};players.push(p);return p;}
const leader=actor('leader',0,true),ally=actor('ally',150),c=actor('c',200),d=actor('d',250),fifth=actor('fifth',300);
world.setDynamicProperty('rpg:social_v1',JSON.stringify({version:1,nextId:2,guilds:[],parties:[{id:1,leader:leader.name,members:[leader.name,ally.name]}]}));
world.setDynamicProperty(DUNGEON_KEY,JSON.stringify({version:1,nextRun:77,dungeons:[{id:'oldruin',dimId:dim.id,x:-200,y:96,z:0,status:'ready',activeId:76}],outbox:[]}));
function tick(n=1){for(let i=0;i<n;i++){system.currentTick++;clock+=50;dungeonTick();}}
function advance(ms){clock+=ms;system.currentTick++;dungeonTick();}
function drainBuild(){for(let i=0;i<10000;i++){if(listDungeons().every(d=>!['queued','scanning','building'].includes(d.status)))return;tick();}throw Error('build did not finish');}
function resetGroup(){for(const p of players){if([...dungeonRuns.values()].some(r=>r.members.some(m=>m.id===p.id))){p.health=0;dungeonDeath({deadEntity:p});}p.health=20;leaveDungeon(p);p.location={...p.home??{x:0,y:64,z:0}};p.dimension=dim;p.health=20;p.getGameMode=()=> 'survival';claimDungeonLoot(p);}}
function kill(m){mobs.delete(m.id);dungeonDeath({deadEntity:m});}
function nonBosses(r){return [...r.live.values()].filter(x=>x.kind!=='boss').map(x=>x.mob);}
function reachBoss(p=leader,tier=1){soloDungeon(p,tier);const r=dungeonRuns.get('dungeon_'+tier);for(let i=0;i<250&&r.phase==='mobs';i++){for(const m of nonBosses(r))kill(m);if(r.phase==='mobs')advance(1000);}assert.equal(r.phase,'boss');return r;}
function scheduled(){for(const fn of timeouts.splice(0))fn();}

function startDungeon(p){const r=queueStart(p);scheduled();return r;}
function soloDungeon(p,t){const r=queueSolo(p,t);scheduled();return r;}
test('v0.5.33 saves migrate without deleting old buildings, return points or reward sequence',()=>{
 registerDungeons();const s=JSON.parse(world.getDynamicProperty(DUNGEON_KEY));assert.equal(s.version,2);assert.equal(s.nextRun,77);assert.equal(s.legacyDungeons[0].id,'oldruin');assert.equal(listDungeons().length,10);assert.ok(listDungeons().every(d=>d.status==='unbuilt'));
});
test('only admins can generate, and only ten finite difficulties are accepted',()=>{
 assert.throws(()=>createDungeon(ally,'all'),/관리자/);runRpgAction('dungeoncreate',ally,'all');assert.ok(ally.messages.at(-1).includes('관리자'));
 for(const value of ['',0,11,'ruin','../x','1;kill'])assert.throws(()=>createDungeon(leader,value),/1~10/);
});
test('cave geometry is circular, has a domed closed roof and open spacious interior',()=>{
 assert.ok(dungeonBlock(0,0,0));assert.ok(dungeonBlock(31,2,0));assert.ok(dungeonBlock(0,26,0));assert.equal(dungeonBlock(31,0,31),undefined);assert.equal(dungeonBlock(10,3,10),undefined);assert.ok(ceilingHeight(0)>ceilingHeight(20));assert.ok(ceilingHeight(20)>ceilingHeight(30));
});
test('an occupied candidate is rejected before any writes and temporary loaded chunks are released',()=>{
 const p=actor('occupied-admin',2000,true);blocks.set('1968,128,0','minecraft:diamond_block');const n=blockWrites;createDungeon(p,10);drainBuild();assert.equal(blockWrites,n);assert.equal(blocks.get('1968,128,0'),'minecraft:diamond_block');assert.equal(listDungeons()[9].status,'unbuilt');assert.equal(areas.size,0);
});
test('one command builds all ten caves sequentially and never keeps more than one temporary chunk area',()=>{
 createDungeon(leader,'all');assert.equal(listDungeons().filter(d=>d.status==='queued').length,10);tick(20);assert.equal(blockWrites,0);drainBuild();assert.ok(listDungeons().every(d=>d.status==='ready'));assert.equal(areas.size,0);assert.equal(commands.filter(c=>c.startsWith('tickingarea add')).length,11);
 const one=listDungeons()[0];assert.ok(blocks.has(key({x:one.x,y:one.y,z:one.z})));assert.equal(blocks.has(key({x:one.x+31,y:one.y,z:one.z+31})),false);
});
test('interrupted cave construction resumes without replacing existing completed shell blocks',()=>{
 removeDungeon(leader,10);const p=actor('resume-admin',3000,true);createDungeon(p,10);
 for(let i=0;i<1000&&listDungeons()[9].status!=='building';i++)tick();assert.equal(listDungeons()[9].status,'building');
 const original=dim.getBlock;let calls=0;dim.getBlock=q=>{if(++calls===40)throw Error('chunk lost');return original(q);};tick();dim.getBlock=original;
 assert.equal(listDungeons()[9].status,'building');recoverDungeons();assert.equal(areas.size,0);drainBuild();assert.equal(listDungeons()[9].status,'ready');assert.equal(areas.size,0);
});
test('a failed temporary chunk load produces no blocks and does not reserve an inaccessible tier',()=>{
 removeDungeon(leader,10);const p=actor('load-fail-admin',3000,true),original=dim.runCommand,before=blockWrites;
 dim.runCommand=()=>{throw Error('tickingarea limit');};createDungeon(p,10);tick();dim.runCommand=original;
 assert.equal(listDungeons()[9].status,'unbuilt');assert.equal(blockWrites,before);assert.ok(p.actionBars.some(s=>s.includes('tickingarea limit')));
 // Recreate elsewhere because unregister intentionally retained the previous cave.
 p.location.x=3100;createDungeon(p,10);drainBuild();assert.equal(listDungeons()[9].status,'ready');
});
test('joining is voluntary, does not teleport party mates and supports four independently joined players',()=>{
 const teleports=ally.teleports;enterDungeon(leader,1);assert.equal(ally.teleports,teleports);assert.equal(leader.location.y,64);enterDungeon(ally,1);enterDungeon(c,1);enterDungeon(d,1);assert.equal(listDungeons()[0].waiting,4);
 assert.throws(()=>enterDungeon(fifth,1),/4명/);assert.throws(()=>startDungeon(ally),/첫 참가자/);assert.throws(()=>enterDungeon(leader,2),/다른 대기실/);assert.throws(()=>soloDungeon(fifth,1),/대기 중/);
 const run=startDungeon(leader);assert.equal(run.members.length,4);assert.equal(ally.location.y,129);assert.equal(fifth.location.y,64);assert.throws(()=>enterDungeon(fifth,1),/진행 중/);resetGroup();
});
test('a player in an RPG party can choose to enter alone and two different caves run independently',()=>{
 const before=ally.teleports;soloDungeon(leader,1);soloDungeon(fifth,2);assert.equal(ally.teleports,before);assert.equal(dungeonRuns.size,2);assert.equal(dungeonRuns.get('dungeon_1').members.length,1);assert.equal(dungeonRuns.get('dungeon_2').members.length,1);resetGroup();
});
test('the five-minute combat timer begins only after the destination loads and enemies actually spawn',()=>{
 queueSolo(leader,1);const r=dungeonRuns.get('dungeon_1');assert.equal(r.phase,'preparing');assert.equal(r.live.size,0);assert.match(dungeonHudText(leader),/입장 준비/);clock+=1000;scheduled();assert.equal(r.phase,'mobs');assert.equal(r.deadline-clock,450000);assert.equal(r.live.size,3);resetGroup();
});
test('normal enemies start small, appear over time and reinforce after kills without exceeding exact quotas',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1');assert.equal(r.normalSpawned,3);assert.equal(r.eliteSpawned,0);advance(6000);assert.equal(r.normalSpawned,5);
 const m=nonBosses(r)[0];kill(m);dungeonDeath({deadEntity:m});assert.equal(r.normalKilled,1);advance(999);assert.equal(r.normalSpawned,5);advance(1);assert.equal(r.normalSpawned,7);resetGroup();
});
test('late elite reinforcements still arrive gradually instead of catching up in one burst',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1');advance(220000);assert.equal(r.eliteSpawned,1);dungeonTick();dungeonTick();assert.equal(r.eliteSpawned,1);advance(4999);assert.equal(r.eliteSpawned,1);advance(1);assert.equal(r.eliteSpawned,2);resetGroup();
});
test('spawn population is bounded, and removed/untracked monsters do not count as kills',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1');for(let i=0;i<100;i++)advance(1000);assert.ok(r.live.size<=12);assert.ok(r.normalSpawned<50);const m=nonBosses(r)[0];m.remove();assert.equal(r.normalKilled,0);dungeonDeath({deadEntity:{id:'untracked',typeId:'rpg:green_goblin'}});assert.equal(r.normalKilled,0);resetGroup();
});
test('exactly fifty normal and five elite deaths trigger one boss with a fresh three-minute timer',()=>{
 const before=spawned.length,r=reachBoss();assert.equal(r.normalSpawned,50);assert.equal(r.normalKilled,50);assert.equal(r.eliteSpawned,5);assert.equal(r.eliteKilled,5);assert.equal(r.live.size,1);assert.equal(r.deadline-clock,270000);assert.ok(clock-r.startedAt<200000);assert.equal(spawned.length-before,56);assert.match(dungeonHudText(leader),/보스.*4:30/);
 const boss=r.live.get(r.bossId).mob,clears=readDungeonLoot(leader).clears;kill(boss);dungeonDeath({deadEntity:boss});assert.equal(readDungeonLoot(leader).clears,clears+1);assert.equal(leader.location.y,64);resetGroup();
});
test('all fifty normal kills alone never spawn the boss while any of five elites remain',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1');for(let i=0;i<210;i++){for(const entry of [...r.live.values()])if(entry.kind==='normal')kill(entry.mob);advance(1000);}assert.equal(r.normalKilled,50);assert.equal(r.eliteSpawned,5);assert.equal(r.eliteKilled,0);assert.equal(r.phase,'mobs');assert.equal(r.bossId,undefined);resetGroup();
});
test('five-minute timeout ejects everyone, removes mobs and pays no clear reward',()=>{
 enterDungeon(leader,1);enterDungeon(ally,1);startDungeon(leader);const r=dungeonRuns.get('dungeon_1'),before=getWallet(leader).gold;clock=r.deadline;dungeonTick();assert.equal(dungeonRuns.size,0);assert.equal([...mobs.values()].filter(m=>m.typeId!=='rpg:dungeon_loot_cache').length,0);assert.equal(leader.location.y,64);assert.equal(ally.location.y,64);assert.equal(getWallet(leader).gold,before);assert.ok(leader.actionBars.some(s=>s.includes('5분을 초과')));resetGroup();
});
test('a final elite death at the exact five-minute deadline fails even before the maintenance tick',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1');for(let i=0;i<205;i++){for(const entry of [...r.live.values()])if(entry.kind==='normal'||r.eliteKilled<4)kill(entry.mob);advance(1000);}assert.equal(r.eliteKilled,4);assert.equal(r.normalKilled,50);const last=[...r.live.values()][0].mob;clock=r.deadline;kill(last);assert.equal(dungeonRuns.size,0);assert.equal(r.bossId,undefined);resetGroup();
});
test('a boss death at exactly three minutes fails, while a kill just before succeeds',()=>{
 let r=reachBoss(),before=readDungeonLoot(leader).clears;clock=r.deadline;kill(r.live.get(r.bossId).mob);assert.equal(readDungeonLoot(leader).clears,before);assert.equal(leader.location.y,64);
 r=reachBoss();clock=r.deadline-1;kill(r.live.get(r.bossId).mob);assert.equal(readDungeonLoot(leader).clears,before+1);resetGroup();
});
test('killing a few monsters never refreshes the five-minute deadline',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1'),end=r.deadline;advance(20000);kill(nonBosses(r)[0]);assert.equal(r.deadline,end);resetGroup();
});
test('all ten tiers use their own scaling event and boss definition',()=>{
 for(let n=1;n<=10;n++){const p=actor('tier'+n,n*10);soloDungeon(p,n);const r=dungeonRuns.get('dungeon_'+n);assert.equal(r.live.size,3);for(const entry of r.live.values())assert.equal(entry.mob.event,'rpg:dungeon_tier_'+n);assert.equal(r.d.tier,n);}
 assert.equal(dungeonRuns.size,10);resetGroup();
});
test('only death removes a live participant; voluntary exit is blocked without chat',()=>{
 enterDungeon(leader,1);enterDungeon(ally,1);startDungeon(leader);const chats=leader.messages.length;
 assert.equal(leaveDungeon(leader),false);assert.equal(dungeonRuns.get('dungeon_1').members.length,2);assert.equal(leader.messages.length,chats);
 ally.health=0;dungeonDeath({deadEntity:ally});assert.equal(dungeonRuns.get('dungeon_1').members.length,1);assert.ok(ally.getDynamicProperty(RETURN_KEY));ally.health=20;leaveDungeon(ally);assert.equal(ally.location.y,64);
 leader.health=0;dungeonDeath({deadEntity:leader});assert.equal([...mobs.values()].filter(m=>m.typeId!=='rpg:dungeon_loot_cache').length,0);resetGroup();
});
test('lobby leader departure transfers control, and disconnect never enrolls a party mate',()=>{
 enterDungeon(leader,1);enterDungeon(ally,1);for(const fn of events.playerLeave.listeners)fn({playerId:leader.id});assert.equal(dungeonLobbies.get('dungeon_1').members[0].id,ally.id);assert.equal(startDungeon(ally).members.length,1);resetGroup();
});
test('server restart aborts battles and waiting rooms, keeps return positions and does not award clears',()=>{
 soloDungeon(leader,1);enterDungeon(ally,2);const before=readDungeonLoot(leader).clears;recoverDungeons();assert.equal(dungeonRuns.size,0);assert.equal(dungeonLobbies.size,0);assert.equal([...mobs.values()].filter(m=>m.typeId!=='rpg:dungeon_loot_cache').length,0);for(const fn of events.playerSpawn.listeners)fn({player:leader,initialSpawn:true});scheduled();assert.equal(leader.location.y,64);assert.equal(readDungeonLoot(leader).clears,before);resetGroup();
});
test('spawn failure returns participants without clear rewards or a busy instance',()=>{
 spawnFailure=true;const before=readDungeonLoot(leader).clears;try{soloDungeon(leader,1);}finally{spawnFailure=false;}assert.equal(leader.location.y,64);assert.equal(dungeonRuns.size,0);assert.equal(readDungeonLoot(leader).clears,before);resetGroup();
});
test('combat count and timer stay visible alongside numeric HP and skill notifications',()=>{
 soloDungeon(leader,1);leader.maxHealth=80;notify(leader,'테스트 스킬');refreshHud(leader);assert.match(leader.actionBars.at(-1),/일반 0\/50/);assert.match(leader.actionBars.at(-1),/HP 20\/80/);assert.match(leader.actionBars.at(-1),/테스트 스킬/);resetGroup();
});
test('menu allows an explicit solo choice without enrolling another player',async()=>{
 replies.push({canceled:false,selection:0},{canceled:false,selection:1});await openDungeons(leader);scheduled();assert.equal(dungeonRuns.get('dungeon_1').members.length,1);assert.ok(forms.some(f=>f.heading==='던전 · 난이도 1~10'));resetGroup();
});
test('clear ledger is idempotent and five clears grant every rune, 36 catalysts and one armor kit',()=>{
 const p=player('ledger');for(let run=100;run<105;run++){creditDungeonClear(p,run);creditDungeonClear(p,run);}const s=readDungeonLoot(p);
 assert.equal(s.clears,5);assert.equal(getWallet(p).gold,10000);assert.equal(s.pending[CATALYST_ID],36);
 for(const id of ['power','arcane','vitality','mana','ward'])assert.equal(s.pending['rpg:rune_'+id],1);
 for(const id of ['helmet','chestplate','leggings','boots'])assert.equal(s.pending['rpg:adventurer_'+id],1);
});
test('ledger storage failure restores wallet and allows a single safe retry',()=>{
 const p=player('ledger-fail');setWallet(p,{gold:50,stone:1,dust:2});const write=p.setDynamicProperty.bind(p);let fail=true;
 p.setDynamicProperty=(k,v)=>{if(fail&&k===DUNGEON_LOOT_KEY){fail=false;throw Error('storage');}write(k,v);};assert.throws(()=>creditDungeonClear(p,200));assert.deepEqual(getWallet(p),{gold:50,stone:1,dust:2});assert.equal(readDungeonLoot(p).clears,0);creditDungeonClear(p,200);assert.equal(getWallet(p).gold,2050);
});
test('full inventory keeps pending loot; freeing a slot grants a bounded stack exactly once',()=>{
 const p=player('bag');creditDungeonClear(p,300);p.slots.fill(new ItemStack('minecraft:stone',64));const pending=readDungeonLoot(p).pending;assert.equal(claimDungeonLoot(p).delivered,0);assert.deepEqual(readDungeonLoot(p).pending,pending);
 p.slots[5]=undefined;const r=claimDungeonLoot(p);assert.ok(r.delivered>0);const before=p.slots[5].amount;assert.equal(claimDungeonLoot(p).delivered,0);assert.equal(p.slots[5].amount,before);
});
test('loot never occupies the reserved RPG weapon slot even when it is empty',()=>{
 const p=player('reserved-weapon');creditDungeonClear(p,350);for(let i=1;i<p.slots.length;i++)p.slots[i]=new ItemStack('minecraft:stone',64);
 assert.equal(claimDungeonLoot(p).delivered,0);assert.equal(p.slots[0],undefined);assert.equal(readDungeonLoot(p).pending[CATALYST_ID],7);
});
test('inventory or pending-write failure rolls back claimed loot and leaves the receipt claimable',()=>{
 for(const failure of ['inventory','storage']){
  const p=player('claim-'+failure);creditDungeonClear(p,400);const before=p.getDynamicProperty(DUNGEON_LOOT_KEY);let fail=true;
  if(failure==='inventory'){const real=p.getComponent.bind(p),c=real('minecraft:inventory').container,write=c.setItem;c.setItem=(i,v)=>{if(fail&&i===2){fail=false;throw Error('inventory');}write(i,v);};}
  else{const write=p.setDynamicProperty.bind(p);p.setDynamicProperty=(k,v)=>{if(fail&&k===DUNGEON_LOOT_KEY){fail=false;throw Error('storage');}write(k,v);};}
  assert.throws(()=>claimDungeonLoot(p));assert.equal(p.slots.filter(Boolean).length,0);assert.equal(p.getDynamicProperty(DUNGEON_LOOT_KEY),before);assert.ok(claimDungeonLoot(p).delivered>0);assert.equal(readDungeonLoot(p).clears,1);
 }
});
test('registered circular cave blocks are protected, but square corners outside the cave stay editable',()=>{
 const d=listDungeons()[0],inside=dim.getBlock({x:d.x,y:d.y,z:d.z}),outside=dim.getBlock({x:d.x+31,y:d.y,z:d.z+31});
 for(const name of ['playerBreakBlock','playerPlaceBlock']){const a={block:inside,player:leader,cancel:false},b={block:outside,player:leader,cancel:false};for(const fn of world.beforeEvents[name].listeners){fn(a);fn(b);}assert.equal(a.cancel,true);assert.equal(b.cancel,false);}
 let kept;for(const fn of world.beforeEvents.explosion.listeners)fn({getImpactedBlocks:()=>[inside,outside],setImpactedBlocks:b=>{kept=b;}});assert.deepEqual(kept,[outside]);
});
test('completed caves have every floor column and roof column, including all four quadrants',()=>{
 const d=listDungeons()[0];for(let x=-32;x<=32;x++)for(let z=-32;z<=32;z++){
  const radius=Math.hypot(x,z);if(radius>32)continue;
  assert.equal(blocks.get(key({x:d.x+x,y:d.y,z:d.z+z})),dungeonBlock(x,0,z));
  const roof=ceilingHeight(radius)+1;assert.equal(blocks.get(key({x:d.x+x,y:d.y+roof,z:d.z+z})),dungeonBlock(x,roof,z));
 }
 for(const command of commands.filter(c=>c.startsWith('tickingarea add')))assert.equal(command.includes(' circle '),false);
});
test('an unavailable half of the footprint resumes automatically without skipped blocks or premature ready',()=>{
 removeDungeon(leader,10);const p=actor('half-load',4000,true);createDungeon(p,10);
 for(let i=0;i<1000&&listDungeons()[9].status!=='building';i++)tick();
 const d=listDungeons()[9],original=dim.getBlock;let unavailable=true;
 dim.getBlock=q=>unavailable&&q.x>d.x?undefined:original(q);
 try{tick(30);assert.equal(listDungeons()[9].status,'building');assert.ok(areas.size===1);unavailable=false;drainBuild();}
 finally{dim.getBlock=original;}
 assert.equal(listDungeons()[9].status,'ready');assert.equal(areas.size,0);
 assert.equal(blocks.get(key({x:d.x+32,y:d.y,z:d.z})),dungeonBlock(32,0,0));
});
test('verification repairs a dropped block write before declaring the dungeon complete',()=>{
 removeDungeon(leader,10);const p=actor('dropped-write',4200,true);createDungeon(p,10);const d=listDungeons()[9],original=dim.getBlock;let dropped=false;
 dim.getBlock=q=>{const block=original(q);if(q.x===d.x+31&&q.y===d.y&&q.z===d.z){const set=block.setType;block.setType=id=>{if(!dropped){dropped=true;return;}set(id);};}return block;};
 try{drainBuild();}finally{dim.getBlock=original;}
 assert.equal(dropped,true);assert.equal(listDungeons()[9].status,'ready');assert.equal(blocks.get(key({x:d.x+31,y:d.y,z:d.z})),dungeonBlock(31,0,0));
});
test('old ready caves repair missing roof and wall blocks automatically while preserving unrelated interior blocks',()=>{
 const saved=JSON.parse(world.getDynamicProperty(DUNGEON_KEY)),d=saved.dungeons.find(d=>d.tier===1);delete d.buildRevision;
 const roof={x:d.x,y:d.y+ceilingHeight(0)+1,z:d.z},wall={x:d.x+31,y:d.y+2,z:d.z},foreign={x:d.x,y:d.y+1,z:d.z+10};
 blocks.delete(key(roof));blocks.delete(key(wall));blocks.set(key(foreign),'minecraft:diamond_block');world.setDynamicProperty(DUNGEON_KEY,JSON.stringify(saved));
 recoverDungeons();assert.equal(listDungeons()[0].status,'building');drainBuild();
 assert.equal(listDungeons()[0].status,'ready');assert.ok(blocks.has(key(roof)));assert.ok(blocks.has(key(wall)));assert.equal(blocks.get(key(foreign)),'minecraft:diamond_block');blocks.delete(key(foreign));
});
test('manual create on a ready tier checks and repairs it at the registered location',()=>{
 const d=listDungeons()[0],at={x:d.x+32,y:d.y+1,z:d.z};blocks.delete(key(at));const before={x:d.x,y:d.y,z:d.z};
 createDungeon(leader,1);drainBuild();const after=listDungeons()[0];assert.deepEqual({x:after.x,y:after.y,z:after.z},before);assert.ok(blocks.has(key(at)));
});
test('active skill teleports cannot cross dungeon walls but remain unrestricted outside an active run',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1'),before={...leader.location};
 assert.throws(()=>teleportForSkill(leader,{x:r.d.x+100,y:r.d.y+1,z:r.d.z},{dimension:dim}),/DungeonBoundary/);assert.deepEqual(leader.location,before);
 teleportForSkill(leader,{x:r.d.x+2,y:r.d.y+1,z:r.d.z},{dimension:dim});assert.equal(leader.location.x,r.d.x+2);resetGroup();
 teleportForSkill(leader,{x:9999,y:64,z:9999},{dimension:dim});assert.equal(leader.location.x,9999);resetGroup();
});
test('the actual fire dash stops at a dungeon edge instead of teleporting outside',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1');leader.location={x:r.d.x,y:r.d.y+1,z:r.d.z+29};leader.getViewDirection=()=>({x:0,y:0,z:1});leader.getRotation=()=>({x:0,y:0});
 const before=intervals.length;FIRE.fire_wheel(leader,JOBS.fire_controller,SKILLS.fire_wheel);assert.equal(intervals.length,before+1);intervals.at(-1)();assert.ok(insideDungeon(leader.location,leader.dimension.id,r.d));assert.equal(r.members.length,1);resetGroup();
});
test('external movement or a different dimension silently returns a living participant without losing their run',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1'),end=r.deadline,chats=leader.messages.length,returnPoint=leader.getDynamicProperty(RETURN_KEY);
 leader.location={x:r.d.x+100,y:r.d.y+30,z:r.d.z};tick();assert.ok(insideDungeon(leader.location,leader.dimension.id,r.d));assert.equal(dungeonRuns.get('dungeon_1'),r);
 leader.dimension={id:'minecraft:nether'};for(const fn of events.playerDimensionChange.listeners)fn({player:leader});assert.ok(insideDungeon(leader.location,leader.dimension.id,r.d));
 assert.equal(r.deadline,end);assert.equal(leader.getDynamicProperty(RETURN_KEY),returnPoint);assert.equal(leader.messages.length,chats);resetGroup();
});
test('disconnecting cannot abandon a live run and reconnecting outside restores the player inside',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1'),end=r.deadline;
 players.splice(players.indexOf(leader),1);for(const fn of events.playerLeave.listeners)fn({playerId:leader.id});advance(1000);assert.equal(r.members.length,1);assert.equal(dungeonRuns.get('dungeon_1'),r);
 leader.location={x:9999,y:64,z:9999};players.push(leader);for(const fn of events.playerSpawn.listeners)fn({player:leader,initialSpawn:true});scheduled();
 assert.ok(insideDungeon(leader.location,leader.dimension.id,r.d));assert.equal(r.deadline,end);resetGroup();
});
test('clearing the arena immediately advances all remaining normal and elite waves without chat or quota inflation',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1'),started=clock,chats=leader.messages.length,before=spawned.length;
 for(let i=0;i<60&&r.phase==='mobs';i++){const entry=r.live.values().next().value;assert.ok(entry);kill(entry.mob);}
 assert.equal(r.phase,'boss');assert.equal(clock,started);assert.equal(r.normalKilled,50);assert.equal(r.eliteKilled,5);assert.equal(r.normalSpawned,50);assert.equal(r.eliteSpawned,5);assert.equal(spawned.length-before,53);assert.equal(r.live.size,1);assert.equal(leader.messages.length,chats);resetGroup();
});
test('a final-frame escape is corrected before clear reward eligibility is checked',()=>{
 const r=reachBoss(),before=readDungeonLoot(leader).clears;leader.location={x:r.d.x+100,y:r.d.y+1,z:r.d.z};kill(r.live.get(r.bossId).mob);
 assert.equal(readDungeonLoot(leader).clears,before+1);assert.equal(leader.location.y,64);resetGroup();
});
test('removed monsters are replaced without counting a fake kill or consuming another wave slot',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1'),entry=r.live.values().next().value,spawnCount=r.normalSpawned;entry.mob.remove();tick(20);
 assert.equal(r.normalKilled,0);assert.equal(r.normalSpawned,spawnCount);assert.equal(r.live.size,3);assert.equal(r.live.has(entry.mob.id),false);resetGroup();
});
test('a real solo clear receives the solo multiplier through the persisted outbox',()=>{
 resetGroup();const before=getWallet(leader).gold,r=reachBoss();assert.equal(r.initialPartySize,1);kill(r.live.get(r.bossId).mob);assert.equal(getWallet(leader).gold-before,3000);resetGroup();
});
test('a party reduced to one survivor never receives the solo multiplier',()=>{
 resetGroup();enterDungeon(leader,1);enterDungeon(ally,1);startDungeon(leader);const r=dungeonRuns.get('dungeon_1');assert.equal(r.initialPartySize,2);
 ally.health=0;dungeonDeath({deadEntity:ally});for(let i=0;i<250&&r.phase==='mobs';i++){for(const m of nonBosses(r))kill(m);if(r.phase==='mobs')advance(1000);}assert.equal(r.phase,'boss');const before=getWallet(leader).gold;kill(r.live.get(r.bossId).mob);assert.equal(getWallet(leader).gold-before,2000);resetGroup();
});




test('actual timeout clears untagged internal mobs as well as the encounter, without killing visitors or paying rewards',()=>{
 soloDungeon(leader,1);const r=dungeonRuns.get('dungeon_1'),at={x:r.d.x,y:r.d.y+1,z:r.d.z},rogue=dim.spawnEntity('minecraft:zombie',at),trainer=dim.spawnEntity('rpg:hito_sword',at),outside=dim.spawnEntity('minecraft:zombie',{x:r.d.x+80,y:r.d.y+1,z:r.d.z});
 rogue.getComponent=outside.getComponent=()=>({currentValue:20});trainer.getComponent=()=>({currentValue:2500});const before=getWallet(leader);advance(450000);
 assert.equal(dungeonRuns.has(r.d.id),false);assert.equal(mobs.has(rogue.id),false);assert.ok(mobs.has(trainer.id));assert.ok(mobs.has(outside.id));assert.deepEqual(getWallet(leader),before);assert.deepEqual(leader.location,leader.home);trainer.remove();outside.remove();
});


test('mobs loaded later in a failed dungeon are cleaned, and the next run also sweeps previously untagged mobs before spawning',()=>{
 const dungeon=listDungeons()[0],at={x:dungeon.x,y:dungeon.y+1,z:dungeon.z},rogue=dim.spawnEntity('minecraft:zombie',at);rogue.getComponent=()=>({currentValue:20});
 for(const handler of events.entityLoad.listeners)handler({entity:rogue});assert.equal(mobs.has(rogue.id),false);
 const stray=dim.spawnEntity('minecraft:skeleton',at);stray.getComponent=()=>({currentValue:20});soloDungeon(leader,1);assert.equal(mobs.has(stray.id),false);assert.equal(dungeonRuns.get('dungeon_1').live.size,3);resetGroup();
});

test('unregister preserves the actual cave and legacy structures',()=>{
 const count=blocks.size;removeDungeon(leader,1);removeDungeon(leader,'oldruin');assert.equal(blocks.size,count);assert.equal(listDungeons()[0].status,'unbuilt');
});
