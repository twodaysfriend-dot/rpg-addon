import {CONFIG} from '../RPG_BP_v0569/scripts/config.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,ItemStack,EquipmentSlot,intervals,system,events} from './minecraftMock.mjs';
import {RUNNERS as SWORD} from '../RPG_BP_v0569/scripts/skills/sword.js';
import {RUNNERS as HARPOON} from '../RPG_BP_v0569/scripts/skills/harpoon.js';
import {SKILLS} from '../RPG_BP_v0569/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0569/scripts/data/jobs.js';
import {getContext} from '../RPG_BP_v0569/scripts/core/context.js';
import {setSkills,getSkills,setIndex,getIndex,setDisabled,getDisabled,setMana,getMana,startCooldown,cooldownLeft} from '../RPG_BP_v0569/scripts/core/playerData.js';
import {registerInput} from '../RPG_BP_v0569/scripts/core/input.js';
import {purchaseChameleonSkill,learningRule,CHAMELEON_ALLOWED} from '../RPG_BP_v0569/scripts/core/chameleonProgress.js';
let serial=0;
function scene(job='revenant'){
 const p=player('lunar-'+serial++,40),targets=[],particles=[];p.setDynamicProperty('rpg:job',job);setSkills(p,JOBS[job].skills);p.equipment.set(EquipmentSlot.Mainhand,new ItemStack(JOBS[job].weapon));
 const dim={id:'minecraft:overworld',getEntities:()=>targets,getBlock:()=>({isSolid:false}),spawnParticle:(id,at)=>particles.push({id,at}),playSound(){}};
 p.dimension=dim;p.getTags=()=>[];p.hasTag=()=>false;p.getViewDirection=()=>({x:0,y:0,z:1});p.getRotation=()=>({x:0,y:0});
 function mob(x,z,y=64,typeId='minecraft:zombie'){
  const t=player('enemy-'+serial++,1,{typeId,location:{x,y,z},health:1000,maxHealth:1000});t.dimension=dim;t.getTags=()=>[];t.hasTag=()=>false;t.hits=[];t.applyDamage=(n)=>{t.hits.push(n);t.health-=n;return true;};t.applyKnockback=()=>{};targets.push(t);return t;
 }
 return {p,dim,mob,particles};
}
function timerFor(fn){const before=intervals.length;assert.equal(fn(),true);assert.ok(intervals.length>before);return intervals[before];}
test('moon dragon hits only the forward 180-degree fan with large and small crescent visuals',()=>{
 const {p,mob,particles}=scene('sword_saint'),targets=[mob(8,0),mob(-8,0),mob(0,8),mob(0,-8)],far=mob(12.1,0),high=mob(0,3,68);
 const tick=timerFor(()=>SWORD.sword_moon_dragon(p,JOBS.sword_saint,SKILLS.sword_moon_dragon));for(let n=0;n<12;n++)tick();
 for(const t of targets.slice(0,3))assert.deepEqual(t.hits,[28]);assert.deepEqual(targets[3].hits,[]);assert.equal(far.hits.length,0);assert.equal(high.hits.length,0);
 assert.equal(particles.filter(p=>p.id==='rpg:moon_dragon_large').length,24);assert.equal(particles.filter(p=>p.id==='rpg:moon_dragon_small').length,144);
});
test('moon dragon respects walls and allies and stops on caster death',()=>{
 const {p,dim,mob}=scene('fallen_sword_saint'),blocked=mob(8,0),near=mob(0,2),ally=mob(0,3,64,'minecraft:player');p.getTags=()=>['rpg_team_lunar'];ally.hasTag=t=>t==='rpg_team_lunar';
 dim.getBlock=q=>({isSolid:Math.floor(q.x)===3});const tick=timerFor(()=>SWORD.sword_moon_dragon(p,JOBS.fallen_sword_saint,SKILLS.sword_moon_dragon));for(let i=0;i<12;i++)tick();
 assert.deepEqual(near.hits,[28]);assert.equal(blocked.hits.length,0);assert.equal(ally.hits.length,0);
 const s=scene('sword_saint'),late=s.mob(0,12),second=timerFor(()=>SWORD.sword_moon_dragon(s.p,JOBS.sword_saint,SKILLS.sword_moon_dragon));second();s.p.health=0;for(let i=0;i<12;i++)second();assert.equal(late.hits.length,0);
});
test('deep pierce is a short-cooldown physical thrust with narrow aim and wall checks',()=>{
 const {p,dim,mob}=scene(),front=mob(0,2),behind=mob(0,-2),side=mob(2,2),blocked=mob(0,5);
 dim.getBlock=q=>({isSolid:Math.floor(q.z)===4});HARPOON.revenant_deep_pierce(p,JOBS.revenant,SKILLS.revenant_deep_pierce);
 assert.deepEqual(front.hits,[18]);for(const t of [behind,side,blocked])assert.equal(t.hits.length,0);assert.equal(SKILLS.revenant_deep_pierce.cooldown,50);assert.equal(SKILLS.revenant_deep_pierce.mana,18);
});
test('rend deals sixteen plus three bleed ticks and recasting refreshes rather than stacking bleed',()=>{
 const {p,mob}=scene(),t=mob(0,2),start=intervals.length;HARPOON.revenant_rend(p,JOBS.revenant,SKILLS.revenant_rend);const old=intervals[start];for(let i=0;i<3;i++)old();assert.deepEqual(t.hits,[16,3,3,3]);
 const s=scene(),target=s.mob(0,2),n=intervals.length;HARPOON.revenant_rend(s.p,JOBS.revenant,SKILLS.revenant_rend);const first=intervals[n];HARPOON.revenant_rend(s.p,JOBS.revenant,SKILLS.revenant_rend);const second=intervals[n+1];first();for(let i=0;i<3;i++)second();assert.deepEqual(target.hits,[16,16,3,3,3]);
});
test('rend bleed stops when an affected player becomes an ally in an explicitly enabled PvP scenario',()=>{
 const was=CONFIG.pvp;CONFIG.pvp=true;try{
 const {p,mob}=scene(),t=mob(0,2,64,'minecraft:player'),n=intervals.length;HARPOON.revenant_rend(p,JOBS.revenant,SKILLS.revenant_rend);p.getTags=()=>['rpg_team_new'];t.hasTag=tag=>tag==='rpg_team_new';intervals[n]();assert.deepEqual(t.hits,[16]);
 }finally{CONFIG.pvp=was;}
});
test('existing Revenants migrate to damage-first order without losing disabled skills or cooldowns',()=>{
 const {p}=scene();setSkills(p,['harpoon_throw','harpoon_dive','harpoon_charge','soul_harpoon','soul_separation','revenant_execution']);setDisabled(p,['harpoon_throw']);setIndex(p,5);startCooldown(p,'revenant_execution',1200);
 const ctx=getContext(p);assert.deepEqual(ctx.all,JOBS.revenant.skills);assert.deepEqual(getSkills(p),JOBS.revenant.skills);assert.equal(ctx.all.at(-1),'revenant_execution');assert.deepEqual(getDisabled(p),['harpoon_throw']);assert.equal(cooldownLeft(p,'revenant_execution'),1200);assert.equal(getIndex(p),0);
 setIndex(p,4);getContext(p);assert.equal(getIndex(p),4);
});
test('actual Revenant item input pays the low mana costs and enforces the new cooldowns',()=>{
 registerInput();const {p,mob}=scene(),t=mob(0,2);setMana(p,100);setIndex(p,0);const event={source:p,itemStack:new ItemStack(JOBS.revenant.weapon)};
 for(const fn of events.itemUse.listeners)fn(event);assert.equal(getMana(p),82);assert.equal(cooldownLeft(p,'revenant_deep_pierce'),50);assert.deepEqual(t.hits,[18]);
 for(const fn of events.itemUse.listeners)fn(event);assert.equal(getMana(p),82);system.currentTick+=5;setIndex(p,1);for(const fn of events.itemUse.listeners)fn(event);assert.equal(getMana(p),58);assert.equal(cooldownLeft(p,'revenant_rend'),80);
});
test('Chameleon can learn both quick attacks as ordinary unlimited-use skills and borrow lunar sweep',()=>{
 const {p,mob}=scene('chameleon');for(const id of ['revenant_deep_pierce','revenant_rend']){assert.ok(CHAMELEON_ALLOWED.includes(id));assert.deepEqual(learningRule(id),{cost:3,uses:null,diamondUses:0});assert.equal(purchaseChameleonSkill(p,id).ok,true);}
 assert.equal(purchaseChameleonSkill(p,'sword_moon_dragon').ok,true);const t=mob(0,4),tick=timerFor(()=>SWORD.sword_moon_dragon(p,JOBS.sword_saint,SKILLS.sword_moon_dragon));for(let i=0;i<12;i++)tick();assert.deepEqual(t.hits,[28]);
});
test('lunar particles use registered crescent textures with a fixed bounded emitter count',()=>{
 for(const name of ['large','small']){const d=JSON.parse(fs.readFileSync(new URL('../RPG_RP_v0569/particles/rpg_moon_dragon_'+name+'.json',import.meta.url))).particle_effect;assert.equal(d.description.identifier,'rpg:moon_dragon_'+name);assert.equal(d.components['minecraft:emitter_rate_instant'].num_particles,1);assert.ok(fs.existsSync(new URL('../RPG_RP_v0569/'+d.description.basic_render_parameters.texture+'.png',import.meta.url)));}
});

test('lunar fan stays aligned with the initial facing and all visual emitters remain in that half',()=>{
 const {p,mob,particles}=scene('sword_saint');p.getViewDirection=()=>({x:1,y:0,z:0});
 const front=mob(6,0),back=mob(-6,0),sides=[mob(0,6),mob(0,-6)];
 const tick=timerFor(()=>SWORD.sword_moon_dragon(p,JOBS.sword_saint,SKILLS.sword_moon_dragon));
 p.getViewDirection=()=>({x:-1,y:0,z:0});for(let i=0;i<12;i++)tick();
 assert.deepEqual(front.hits,[28]);assert.deepEqual(back.hits,[]);for(const t of sides)assert.deepEqual(t.hits,[28]);
 assert.equal(particles.length,168);for(const particle of particles)assert.ok(particle.at.x>=-1e-8,JSON.stringify(particle));
});
