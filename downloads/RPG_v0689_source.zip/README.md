# RPG v0.6.89 · 자동 청소기와 진홍의 군주 전직

## 자동 청소기

운영자가 `/rpg:cleaner`를 입력하면 3분마다 작동합니다. 작동 5초 전부터 매초 채팅에 남은 시간을 알리고, 끝나면 제거된 몹과 드롭 아이템, 날아가던 경험치 병의 수를 표시합니다. 다시 입력하면 남은 시간을 확인할 수 있으며, `/rpg:cleaner off`로 끌 수 있습니다. 켜 둔 상태로 월드를 다시 열면 3분 주기가 새로 시작됩니다.

오버월드·네더·엔드의 불러온 영역을 청소합니다. 주민, 좀비 계열, 애완동물, 가축, 눈사람, 철 골렘과 던전 몹은 보호합니다. 청소 대상은 즉시 제거되어 전리품과 경험치를 생성하지 않습니다.

## 진홍의 군주

블라디미르로 5단계 이상 던전을 솔로나 파티로 클리어하고 RPG 레벨 45를 달성하면 창셀혼에게 전직할 수 있습니다. 창셀혼과 대화하면 전직 카드 없이도 조건별 진행도를 확인할 수 있습니다. 기존에 저장된 시련 완료 기록은 적용됩니다. 이전 버전에서 기록되지 않은 파티 클리어는 업데이트 후 다시 클리어해야 합니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.89로 활성화하고 월드를 다시 여세요. 모의 테스트에서 청소 카운트다운·제거 통계·던전 보호와 솔로·파티 전직 기록을 확인했습니다. 실제 Bedrock 월드에서는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0689
```
