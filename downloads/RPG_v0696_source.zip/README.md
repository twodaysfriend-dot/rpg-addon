# RPG v0.6.96 · 갑옷 강화 성공률과 파손 방지

- 모든 등급의 +9·+10 RPG 갑옷은 피격 내구도 소모 확률이 0%입니다. 기존 보유 장비도 접속하거나 착용할 때 적용되며, 등급·인챈트·기존 마모 수치는 유지됩니다.
- +9→+10 강화의 파괴 확률은 0%입니다. 강등으로 +8이 되면 +8 갑옷의 내구도 규칙이 적용됩니다.
- 갑옷의 기본 강화 성공률을 높였습니다. +1부터 +10까지 순서대로 100%, 95%, 90%, 85%, 75%, 65%, 60%, 50%, 45%, 40%입니다. +8→+9는 22%에서 45%로, +9→+10은 15%에서 40%로 올랐습니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.96으로 활성화하세요. 갑옷 데이터, 전체 등급과 촉매 확률, 기존 장비 전환·이전·승급을 검증했습니다. 실제 Bedrock 전투에서의 내구도 동작은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
python3 tools/build_protected_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0696
```
