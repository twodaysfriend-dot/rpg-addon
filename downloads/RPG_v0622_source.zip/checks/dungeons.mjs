import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0622'),base=root+'/RPG_BP_v0622/scripts/';
async function dataModule(file){const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'));await m.link(()=>{});await m.evaluate();return m.namespace;}
const data=await dataModule('data/dungeons.js');
async function setup(initial=[],options={}){
 const props=new Map([['rpg:dungeons_v1',JSON.stringify({version:2,nextRun:1,dungeons:initial,legacyDungeons:[],outbox:[]})]]),blocks=new Map(),messages=[],commands=[];
 let writes=0,glitchCount=0;const active=new Map(),lobbies=new Map();const system={currentTick:0,runInterval:()=>1,runTimeout:()=>1};
 const p={id:'admin',typeId:'minecraft:player',playerPermissionLevel:2,location:{x:0,y:64,z:0},dimension:{id:'minecraft:overworld'},sendMessage:s=>messages.push(s)};
 const dim={runCommand:s=>{commands.push(s);return {successCount:1};},getBlock:at=>{
  if(options.glitch&&glitchCount++===5000){const e=Error('temporarily unloaded');e.name='UnloadedChunkError';throw e;}
  const key=[at.x,at.y,at.z].join(',');return {get isAir(){return !blocks.has(key);},get typeId(){return blocks.get(key)??'minecraft:air';},setType:type=>{blocks.set(key,type);writes++;}};
 },getEntities:()=>[]};
 const world={getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),getDimension:()=>dim,getAllPlayers:()=>[p]};
 const bindings={...Object.fromEntries(Object.keys(data).map(k=>[k,data[k]])),world,system,dungeonRuns:active,dungeonLobbies:lobbies,isRpgAdmin:player=>player.playerPermissionLevel===2,notify:()=>{}};
 const ctx=vm.createContext({console});const placement=new vm.SourceTextModule(fs.readFileSync(base+'core/dungeonPlacement.js','utf8'),{context:ctx});const dataExports=Object.keys(data);const dmod=new vm.SyntheticModule(dataExports,function(){for(const n of dataExports)this.setExport(n,data[n]);},{context:ctx});await placement.link(()=>dmod);await placement.evaluate();bindings.newDungeonSite=placement.namespace.newDungeonSite;
 const source=fs.readFileSync(base+'core/dungeons.js','utf8'),m=new vm.SourceTextModule(source,{context:ctx});
 await m.link(async spec=>{const names=[];for(const hit of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(hit[2]===spec)names.push(...hit[1].split(',').map(n=>n.trim().split(/\s+as\s+/)[0]));return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context:ctx});});await m.evaluate();
 const api=m.namespace;return {api,p,blocks,messages,commands,props,system,placement:placement.namespace,get writes(){return writes;},tick(){system.currentTick++;api.dungeonTick();}};
}
const firstNine=Array.from({length:9},(_,i)=>({id:'dungeon_'+(i+1),tier:i+1,shape:'cave_v2',dimId:'minecraft:overworld',x:i%5*80,y:128,z:Math.floor(i/5)*80,status:'ready',buildRevision:3}));
{
 const t=await setup(firstNine,{glitch:true});const result=t.api.createDungeon(t.p,'10');assert.equal(result.tiers[0],10);let dungeon=t.api.listDungeons().find(d=>d.tier===10);assert.equal(dungeon.x,320);assert.equal(dungeon.z,80);for(const old of firstNine)assert.equal(t.placement.dungeonSitesOverlap(dungeon,old),false);
 assert.equal(t.api.createDungeon(t.p,'10').alreadyBuilding,true);let ticks=0;while(t.api.listDungeons().find(d=>d.tier===10).status!=='ready'&&ticks++<3000)t.tick();dungeon=t.api.listDungeons().find(d=>d.tier===10);assert.equal(dungeon.status,'ready');let expected=0;
 for(let y=0;y<=data.DUNGEON.height;y++)for(let x=-32;x<=32;x++)for(let z=-32;z<=32;z++)if(data.inCaveVolume(x,y,z)){const type=data.dungeonBlock(x,y,z);if(type){expected++;assert.equal(t.blocks.get([dungeon.x+x,dungeon.y+y,dungeon.z+z].join(',')),type);}}
 assert.equal(t.blocks.size,expected);assert.ok(t.messages.some(s=>s.includes('10 생성·완성 검사 완료')));assert.ok(t.commands.at(-1).startsWith('tickingarea remove '));
 const key=[dungeon.x,dungeon.y,dungeon.z].join(',');t.blocks.delete(key);t.api.createDungeon(t.p,10);ticks=0;while(t.api.listDungeons().find(d=>d.tier===10).status!=='ready'&&ticks++<3000)t.tick();assert.equal(t.blocks.get(key),'minecraft:sea_lantern');
 console.log('Tier 10: created with 1–9 already registered, complete shell verified, one chunk interruption, repeat status, missing-floor repair passed');
}
{
 const t=await setup();t.api.createDungeon(t.p,'all');let ticks=0;while(t.api.listDungeons().some(d=>d.status!=='ready')&&ticks++<20000)t.tick();assert.ok(t.api.listDungeons().every(d=>d.status==='ready'));assert.equal(t.api.listDungeons().length,10);
 console.log('All-tier creation: ten nonoverlapping dungeons reach ready, including tier 10');
}
{
 const t=await setup();t.api.createDungeon(t.p,10);let ticks=0;while(t.writes<500&&ticks++<2000)t.tick();assert.ok(t.writes>0);const written=t.blocks.size;t.api.recoverDungeons();ticks=0;while(t.api.listDungeons().find(d=>d.tier===10).status!=='ready'&&ticks++<3000)t.tick();assert.equal(t.api.listDungeons().find(d=>d.tier===10).status,'ready');assert.ok(t.blocks.size>written);
 console.log('Partially built tier 10 survives recovery and completes without erasing placed blocks');
}
