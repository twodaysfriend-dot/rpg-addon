import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0622'),source=fs.readFileSync(root+'/RPG_BP_v0622/scripts/core/spawnEffects.js','utf8');
let tick=0,now=100000;const props=new Map(),effects=new Map(),globals=new Map(),events={};
const p={id:'p',location:{x:0,y:65,z:0},dimension:{id:'minecraft:overworld'},getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>v===undefined?props.delete(k):props.set(k,v),getEffect:id=>{const e=effects.get(id);if(!e)return;const duration=e.end-tick;if(duration<=0){effects.delete(id);return;}return {amplifier:e.amp,duration};},addEffect:(id,d,o)=>effects.set(id,{amp:o.amplifier,end:tick+d}),removeEffect:id=>effects.delete(id)};
const world={getAllPlayers:()=>[p],getDynamicProperty:k=>globals.get(k),setDynamicProperty:(k,v)=>globals.set(k,v),afterEvents:new Proxy({},{get:(o,k)=>({subscribe:fn=>events[k]=fn})})};const system={runInterval:()=>1,run:fn=>fn()};
async function load(){const context=vm.createContext({console,Date:class extends Date{static now(){return now;}}});const m=new vm.SourceTextModule(source,{context});const native=new vm.SyntheticModule(['world','system'],function(){this.setExport('world',world);this.setExport('system',system);},{context});await m.link(()=>native);await m.evaluate();return m.namespace;}
let api=await load();api.setSpawnRegion({x:-125,y:64,z:-125});
const step=()=>{tick++;now+=50;api.tickSpawnEffects();};
step();assert.equal(p.getEffect('speed').amplifier,5);assert.equal(p.getEffect('night_vision').amplifier,0);assert.equal(p.getEffect('saturation').amplifier,0);
for(let i=0;i<2000;i++)step();assert.ok(p.getEffect('night_vision').duration>=234);assert.ok(p.getEffect('speed'));
p.location.x=125;step();for(const id of ['speed','night_vision','saturation'])assert.equal(p.getEffect(id),undefined);
p.location.x=-125;p.location.z=-125;step();assert.ok(p.getEffect('speed'));p.dimension.id='minecraft:nether';step();assert.equal(p.getEffect('speed'),undefined);p.dimension.id='minecraft:overworld';
console.log('Spawn: persistent Speed VI/Night Vision/Saturation, exact 250-square boundary and dimension exit clear in one tick');
// Existing external effects should return with only their remaining duration.
p.location={x:200,y:65,z:0};step();p.addEffect('speed',600,{amplifier:1});p.location={x:0,y:65,z:0};step();assert.equal(p.getEffect('speed').amplifier,5);for(let i=0;i<100;i++)step();p.location.x=125;step();assert.equal(p.getEffect('speed').amplifier,1);assert.ok(p.getEffect('speed').duration<=500&&p.getEffect('speed').duration>=495);
p.removeEffect('speed');p.addEffect('speed',600,{amplifier:7});p.location.x=0;step();assert.equal(p.getEffect('speed').amplifier,7);p.location.x=125;step();assert.equal(p.getEffect('speed').amplifier,7);
console.log('External weaker/stronger speed effects preserved; only spawn-owned boost removed');
p.removeEffect('speed');p.location.x=0;step();assert.ok(p.getEffect('night_vision'));api=await load();p.location.x=125;step();assert.equal(p.getEffect('night_vision'),undefined);assert.equal(p.getEffect('speed'),undefined);
api.registerSpawnEffects();p.location.x=0;step();effects.clear();events.playerSpawn({player:p,initialSpawn:false});assert.ok(p.getEffect('speed'));p.location.x=125;step();assert.equal(p.getEffect('speed'),undefined);
console.log('Persisted ownership: outside rejoin removes leftovers; respawn refreshes and exit still clears');

p.location={x:0,y:-20,z:0};step();assert.ok(p.getEffect('speed'));p.location.z=125;step();assert.equal(p.getEffect('speed'),undefined);console.log('Spawn buffs follow horizontal village bounds at any elevation');
