"""Remove obsolete enlarged hand meshes so Bedrock renders native tool sprites.

The original icon PNGs are deliberately never changed. Keep the cleanup in the
build so old generated attachables cannot accidentally return in a release.
"""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RP=ROOT/'RPG_RP_v0570'
WEAPONS=['common_redmoon_blade','common_battle_sword','common_magitech_greatsword',
         'common_battle_spear','common_frost_greatsword','common_flame_greatsword',
         'common_beast_axe','sun_heir_axe']
def main():
 for key in WEAPONS:
  (RP/'attachables'/(key+'.json')).unlink(missing_ok=True)
  (RP/'models/entity/held_weapons'/(key+'.geo.json')).unlink(missing_ok=True)
 (RP/'animations/held_weapons.animation.json').unlink(missing_ok=True)
 print('8 weapons use native hand_equipped tool rendering; original PNGs unchanged.')
if __name__=='__main__':main()
