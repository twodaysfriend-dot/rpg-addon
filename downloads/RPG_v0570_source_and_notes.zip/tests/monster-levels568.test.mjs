import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player} from './minecraftMock.mjs';
import {MONSTER_LEVELS,MONSTER_LEVEL_KEY,dungeonMonsterLevel,wildMonsterLevel,monsterDefenseMultiplier,levelRewardMultiplier} from '../RPG_BP_v0570/scripts/data/monsterLevels.js';
import {LEVELED_MONSTERS} from '../RPG_BP_v0570/scripts/data/leveledMonsters.js';
import {DUNGEON_TIERS,encounterTypes} from '../RPG_BP_v0570/scripts/data/dungeons.js';
import {applyMonsterLevel} from '../RPG_BP_v0570/scripts/core/monsterLevels.js';
import {recordSoloDungeonClear} from '../RPG_BP_v0570/scripts/core/newTrials.js';
import {getProgress} from '../RPG_BP_v0570/scripts/core/playerData.js';
import {hurt} from '../RPG_BP_v0570/scripts/core/util.js';
const entity=id=>JSON.parse(fs.readFileSync(new URL('../RPG_BP_v0570/entities/'+id.slice(4)+'.json',import.meta.url)))['minecraft:entity'];

test('same species can roll four levels per field zone, with no player-level rubber band',()=>{
 const zone=x=>Array.from({length:4},(_,i)=>wildMonsterLevel({x,z:0},()=>i/4));
 assert.deepEqual(zone(1500),[1,5,10,15]);assert.deepEqual(zone(1501),[20,30,40,55]);assert.deepEqual(zone(4001),[70,90,115,145]);
 assert.deepEqual(zone(-4001),zone(4001));assert.deepEqual(zone(20000),zone(4001));
 for(const n of [-1,1,NaN])assert.throws(()=>wildMonsterLevel({x:0,z:0},()=>n));
});
test('all encounter types resolve native level health, melee and defense at every tier',()=>{
 for(const tier of DUNGEON_TIERS){
  for(const id of new Set(encounterTypes(tier.tier).map(t=>'rpg:'+t))){
   assert.ok(LEVELED_MONSTERS.includes(id));const e=entity(id);
   for(const kind of ['normal','elite','boss'])for(let index=0;index<(kind==='normal'?3:1);index++){
    const level=dungeonMonsterLevel(tier.tier,kind,index),name=`rpg:dungeon_scaled_${tier.tier}_${kind}_${index}`,group=e.component_groups[name];
    assert.ok(MONSTER_LEVELS.includes(level));assert.ok(group['minecraft:health'].max>=e.components['minecraft:health'].max);
    assert.deepEqual(e.events[name].add.component_groups,[name]);
    assert.ok(group['minecraft:damage_sensor'].triggers[0].damage_multiplier>0);
    assert.ok(group['minecraft:damage_sensor'].triggers[0].damage_multiplier<=1);
   }
  }
 }
 assert.equal(dungeonMonsterLevel(10,'boss'),260);assert.equal(dungeonMonsterLevel(10,'elite'),220);
});
test('native health and attack increase across levels and preserve unscaled baseline',()=>{
 for(const id of LEVELED_MONSTERS){const e=entity(id);let last=0;
  for(const level of MONSTER_LEVELS){const c=e.component_groups['rpg:level_'+level];assert.ok(c['minecraft:health'].max>last);last=c['minecraft:health'].max;}
  assert.equal(e.component_groups['rpg:level_1']['minecraft:health'].max,e.components['minecraft:health'].max);
 }
});
test('persistent level is applied once and never resets an already-wounded mob',()=>{
 const p=player('mob');p.typeId='rpg:green_goblin';p.nameTag='named mob';p.triggerEvent=id=>{p.event=id;};
 assert.equal(applyMonsterLevel(p,55),true);p.health=3;assert.equal(applyMonsterLevel(p,145),false);assert.equal(p.health,3);assert.equal(p.getDynamicProperty(MONSTER_LEVEL_KEY),55);assert.match(p.nameTag,/Lv.55.*named mob/);
 assert.equal(applyMonsterLevel({...p,typeId:'minecraft:cow'},55),false);
});
test('fixed skill damage bypasses only level defense, ordinary attacks retain reduction',()=>{
 const p=player('source'),t=player('enemy');t.typeId='rpg:green_goblin';t.health=1000;t.setDynamicProperty(MONSTER_LEVEL_KEY,260);
 t.applyDamage=n=>{t.health-=n*monsterDefenseMultiplier(t);return true;};
 hurt(t,p,40,'fixed');assert.ok(Math.abs(t.health-960)<1e-9);
 t.health=1000;hurt(t,p,40,'physical');assert.ok(t.health>960);
 assert.equal(levelRewardMultiplier(p),1);assert.ok(levelRewardMultiplier(t)>3);
});
test('final boss reference budget separates ordinary and legendary full +10 builds without an entry gate',()=>{
 const e=entity('rpg:tech_block_golem_boss'),c=e.component_groups.rpg_dungeon_scaled_10_boss_0??e.component_groups['rpg:dungeon_scaled_10_boss_0'];
 const hp=c['minecraft:health'].max,defense=c['minecraft:damage_sensor'].triggers[0].damage_multiplier;
 // Four players: 1.6 basic hits/s, base skill DPS 16, stat x1.7,
 // Strength +50%, set +8%. This is a reference model, not a client playtest.
 const dps=grade=>( (1+11*grade+10)*1.6*1.5 + 16*1.7*1.5*(1+.3*grade)*1.08 )*defense*4;
 assert.ok(hp/dps(1)>180);assert.ok(hp/dps(1.75)<180);
});
test('War God solo milestone now accepts tier two, retains legacy key and rejects party clears',()=>{
 const p=player('trial',40);p.setDynamicProperty('rpg:job','fighter');recordSoloDungeonClear(p,1,true);assert.equal(getProgress(p).solo_d5,undefined);
 recordSoloDungeonClear(p,2,false);assert.equal(getProgress(p).solo_d5,undefined);
 recordSoloDungeonClear(p,2,true);assert.equal(getProgress(p).solo_d5,1);
 recordSoloDungeonClear(p,10,true);assert.equal(getProgress(p).solo_d5,1);
});
