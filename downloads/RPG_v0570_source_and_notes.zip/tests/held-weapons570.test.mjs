import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve('.'),rp=path.join(root,'RPG_RP_v0570'),bp=path.join(root,'RPG_BP_v0570');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const ids=['common_redmoon_blade','common_battle_sword','common_magitech_greatsword','common_battle_spear','common_frost_greatsword','common_flame_greatsword','common_beast_axe','sun_heir_axe'];
test('all eight weapons use native tool rendering without hand-bound replacement meshes',()=>{
 for(const id of ids){
  assert.equal(read(path.join(bp,'items',id+'.json'))['minecraft:item'].components['minecraft:hand_equipped'],true);
  assert.equal(fs.existsSync(path.join(rp,'attachables',id+'.json')),false);
  assert.equal(fs.existsSync(path.join(rp,'models/entity/held_weapons',id+'.geo.json')),false);
 }
 assert.equal(fs.existsSync(path.join(rp,'animations/held_weapons.animation.json')),false);
});
test('original common weapon texture bytes remain unchanged',()=>{
 for(const record of read(path.join(root,'original_weapon_texture_mapping.json'))){const data=fs.readFileSync(path.join(rp,'textures/items/common_weapons',record.target));assert.equal(crypto.createHash('sha256').update(data).digest('hex'),record.sha256);}
});
test('native rendering has no oversized per-perspective overrides and preserves private gauntlets',()=>{
 for(const id of ids)for(const pack of [bp,rp]){const file=path.join(pack,'items',id+'.json');if(fs.existsSync(file))assert.equal(read(file)['minecraft:item'].components['minecraft:render_offsets'],undefined);}
 assert.match(JSON.stringify(read(path.join(rp,'attachables/war_god_gauntlets.json'))),/context.is_first_person/);
});
