import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,events,system,forms,replies,ItemStack} from './minecraftMock.mjs';
import {GPT_NPC,spawnGptNpc,registerGptNpc} from '../RPG_BP_v0570/scripts/core/gptNpc.js';
import {runRpgAction} from '../RPG_BP_v0570/scripts/core/rpgActions.js';
import {answerRpgQuestion} from '../RPG_BP_v0570/scripts/core/rpgAssistant.js';
import {lookupRpgQuestion,knowledgeEntries} from '../RPG_BP_v0570/scripts/core/rpgKnowledge.js';
import {getTargets,hurt} from '../RPG_BP_v0570/scripts/core/util.js';
import {mobXp} from '../RPG_BP_v0570/scripts/data/mobXp.js';
import {currencyReward} from '../RPG_BP_v0570/scripts/core/economy.js';
import {registerTracking,getLastHit} from '../RPG_BP_v0570/scripts/core/tracking.js';
import {grantSkillLifesteal,healLifesteal} from '../RPG_BP_v0570/scripts/core/lifesteal.js';
import {BALANCE_ANSWER,HIDDEN_PROMOTION_ANSWER} from '../RPG_BP_v0570/scripts/core/assistantPolicy.js';
const emit=(name,ev)=>{for(const fn of events[name].listeners)fn(ev);};
function scene(){const p=player('gpt-player-'+Math.random()),spawns=[];p.getViewDirection=()=>({x:0,y:0,z:1});const dim={id:'minecraft:overworld',getBlock:()=>({isSolid:false,isAir:true}),getEntities:()=>[],spawnEntity(id,at){const n=player('npc',1,{typeId:id,location:at,dimension:dim});spawns.push(n);return n;}};p.dimension=dim;return {p,dim,spawns};}
registerGptNpc();
test('only administrators spawn through RPG commands and blocked spaces are rejected',()=>{
 const {p,spawns,dim}=scene();runRpgAction('gptnpc',p);assert.equal(spawns.length,0);p.playerPermissionLevel=2;runRpgAction('gptnpc',p);assert.equal(spawns[0].typeId,GPT_NPC);assert.equal(spawns[0].location.z,2.5);assert.match(spawns[0].nameTag,/GPT/);dim.getBlock=()=>({isSolid:true});assert.equal(spawnGptNpc(p),false);assert.equal(spawns.length,1);
});
test('NPC interaction opens a private question form, answers scaling, and deduplicates mobile taps',async()=>{
 const {p}=scene(),npc=spawnGptNpc(p),start=forms.length;replies.push({canceled:false,formValues:['풍압은 근력이야 마력이야?']},{canceled:true});emit('playerInteractWithEntity',{player:p,target:npc});emit('playerInteractWithEntity',{player:p,target:npc});await new Promise(resolve=>setImmediate(resolve));
 const opened=forms.slice(start);assert.equal(opened.filter(f=>f.heading==='RPG 정보 질문').length,1);const answer=opened.find(f=>f.heading==='RPG 정보 안내');assert.ok(answer);assert.match(answer.text,/마력\(마법\)/);assert.equal(p.messages.filter(m=>m.includes('[RPG 안내]')).length,0);
});
test('distant, dead, other dimension players and unrelated NPCs do not open questions',()=>{
 for(const change of [(p,n)=>n.location.z=20,p=>p.health=0,(p,n)=>n.dimension={id:'minecraft:nether'},(p,n)=>n.typeId='minecraft:cow']){const {p}=scene(),npc=spawnGptNpc(p),n=forms.length;change(p,npc);emit('playerInteractWithEntity',{player:p,target:npc});assert.equal(forms.length,n);}
});
test('NPC cannot be selected, damaged, farmed, lifestealed or tracked as an attack target',()=>{
 const {p,dim}=scene(),npc=spawnGptNpc(p);dim.getEntities=()=>[npc];assert.deepEqual(getTargets(p,p.location,10),[]);npc.applyDamage=()=>{throw Error('should not attack');};assert.equal(hurt(npc,p,999,'fixed',{ignoreInvulnerability:true}),false);assert.equal(mobXp(GPT_NPC),0);assert.equal(currencyReward(GPT_NPC),undefined);grantSkillLifesteal(p,.15,100);p.health=5;assert.equal(healLifesteal(p,npc,100),0);registerTracking();emit('entityHurt',{hurtEntity:npc,damage:0,damageSource:{damagingEntity:p}});assert.equal(getLastHit(p),null);
});
test('skill scaling distinguishes physical, magical, mixed, fixed and non-damaging exceptions',async()=>{
 for(const [q,re]of [['풍압 근력이야 마력이야',/마력\(마법\) 보정/],['폭멸타 마력이야',/근력\(물리\) 보정/],['초승달 참격 마력이야',/근력\(물리\) 보정/],['대미장식 근력?',/고정 피해/],['피의 창 근력?',/마력\(마법\) 보정.*힘 버프 보정은 제외/],['해커 카피 마력?',/복제한 궁극기/],['혈인 근력이야 마력이야',/혼합/],['축복 영역 근력?',/직접 타격 피해가 없는/]]){const r=await answerRpgQuestion(q);assert.match(r.text,re,q);}
 assert.match((await answerRpgQuestion('해커는 근력이야 마력이야?')).text,/마력\(마법\)/);assert.match((await answerRpgQuestion('근력 직업 알려줘')).text,/투신/);
});
test('API candidate records contain scaling and retain balance and hidden-promotion policy',async()=>{
 assert.match(lookupRpgQuestion('풍압 마력?').entries[0].body,/마력\(마법\) 보정/);assert.equal((await answerRpgQuestion('사기인 직업은 어떤거고 어떻게 전직해?')).text,BALANCE_ANSWER);assert.equal((await answerRpgQuestion('투신 전직 조건')).text,HIDDEN_PROMOTION_ANSWER);assert.ok(!knowledgeEntries().find(e=>e.id==='job:war_god').body.includes('150'));
});
test('NPC asset chain points to a dedicated 128px GPT face texture and damage-immune behavior',()=>{
 const bp=JSON.parse(fs.readFileSync(new URL('../RPG_BP_v0570/entities/gpt_guide.json',import.meta.url)))['minecraft:entity'];assert.equal(bp.description.identifier,GPT_NPC);assert.equal(bp.components['minecraft:damage_sensor'].triggers[0].deals_damage,false);assert.equal(bp.components['minecraft:interact'].interactions[0].interact_text,'GPT에게 질문');
 const rp=JSON.parse(fs.readFileSync(new URL('../RPG_RP_v0570/entity/gpt_guide.entity.json',import.meta.url)))['minecraft:client_entity'].description,geo=JSON.parse(fs.readFileSync(new URL('../RPG_RP_v0570/models/entity/gpt_guide.geo.json',import.meta.url)))['minecraft:geometry'][0];assert.equal(rp.geometry.default,geo.description.identifier);assert.equal(geo.description.texture_width,128);assert.deepEqual(geo.bones.find(b=>b.name==='head').cubes[0].uv.north.uv,[0,0]);assert.ok(fs.existsSync(new URL('../RPG_RP_v0570/'+rp.textures.default+'.png',import.meta.url)));
});
