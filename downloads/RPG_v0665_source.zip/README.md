# RPG v0.6.65 · 투신 스킬 피해 조정

투신 공격 스킬 6종의 기본 피해를 두 배로 올렸습니다. 천멸격은 다음 투신 공격 스킬 한 번의 피해를 2배로 강화하며, 연타와 충격파는 해당 시전의 각 타격에 적용됩니다.

| 스킬 | 1회 타격 기본 피해 | 천멸격 사용 시 |
|---|---:|---:|
| 폭멸타 | 80 | 160 |
| 난참 | 20 | 40 |
| 난식 | 17 | 34 |
| 폭열권 | 96 | 192 |
| 파황각 | 36 | 72 |
| 귀심 팔중 | 36 | 72 |

표는 장비·능력치 보정 전 수치입니다. Bedrock 1.21.100 이상에서 세 팩을 v0.6.65로 활성화하세요.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0665
```
