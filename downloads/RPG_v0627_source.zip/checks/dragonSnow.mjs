import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0627';
const base=root+'/RPG_BP_v0627/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}


const zone=await load('scripts/data/huntingZones.js'),mobs=await load('scripts/data/mobXp.js'),leveled=await load('scripts/data/leveledMonsters.js');
const events={},system={currentTick:100},spawned=[];let biome='minecraft:snowy_plains',ground='minecraft:snow_layer';
const dimension={id:'minecraft:overworld',getBiome:()=>({id:biome}),getTopmostBlock:()=>({typeId:ground,location:{x:0,y:64,z:0}}),getBlock:()=>({typeId:ground}),spawnEntity:(id,location)=>{const m={typeId:id,location,tags:new Set(),addTag(t){this.tags.add(t);},setRotation:()=>{},remove(){this.removed=true;}};spawned.push(m);return m;}};
const world={getTimeOfDay:()=>15000};
const api=await load('scripts/core/huntingZones.js',{...Object.fromEntries(Object.keys(zone).map(k=>[k,zone[k]])),VANILLA_HOSTILES:mobs.VANILLA_HOSTILES,LEVELED_MONSTERS:leveled.LEVELED_MONSTERS,world,system});
const mob=id=>({typeId:id,isValid:true,dimension,location:{x:0,y:65,z:0},nameTag:'',tags:new Set(),hasTag(t){return this.tags.has(t);},addTag(t){this.tags.add(t);},getComponent:()=>undefined,getDynamicProperty:()=>undefined,getRotation:()=>({x:0,y:0}),remove(){this.removed=true;}});
for(const id of leveled.LEVELED_MONSTERS){const e=mob(id),r=api.applyHuntingZone(e);assert.equal(r.id,'minecraft:stray');assert.equal(e.removed,true);}
let e=mob('minecraft:stray');assert.equal(api.enforceVanillaCaveSpawn(e).action,'kept');assert.ok(!e.removed);
for(const id of ['minecraft:zombie','minecraft:skeleton','minecraft:creeper','minecraft:spider']){e=mob(id);assert.equal(api.enforceVanillaCaveSpawn(e).action,'removed');}
for(const type of ['dungeon','tamed','summon','name','egg']){
 const e=mob('rpg:green_goblin');
 if(type==='dungeon')e.tags.add('rpg_dungeon_mob');if(type==='tamed')e.getComponent=()=>({isTamed:true});if(type==='summon')e.getDynamicProperty=k=>k==='rpg:necro_owner'?'owner':undefined;if(type==='name')e.nameTag='My pet';
 if(type==='egg')api.noteHuntingEggUse({itemStack:{typeId:'rpg:green_goblin_spawn_egg'},block:{dimension,location:{x:0,y:65,z:0}}});
 assert.equal(api.applyHuntingZone(e).action,'ignored',type);assert.ok(!e.removed,type);
}
biome='minecraft:plains';ground='minecraft:grass_block';assert.equal(api.isSnowTerrain(dimension,{x:0,y:65,z:0}),false);assert.equal(api.applyHuntingZone(mob('rpg:green_goblin')).action,'kept');assert.equal(api.applyHuntingZone(mob('rpg:mantis')).action,'ignored');
biome='';ground='minecraft:snow_layer';assert.equal(api.isSnowTerrain(dimension,{x:0,y:65,z:0}),true);
for(const id of ['snowy_taiga','frozen_peaks','ice_plains','cold_taiga','grove']){biome='minecraft:'+id;ground='minecraft:grass_block';assert.equal(api.isSnowTerrain(dimension,{x:0,y:65,z:0}),true,id);}
const filter=(f,tags)=>Array.isArray(f)?f.every(x=>filter(x,tags)):f.all_of?f.all_of.every(x=>filter(x,tags)):f.any_of?f.any_of.some(x=>filter(x,tags)):f.none_of?!f.none_of.some(x=>filter(x,tags)):f.test==='has_biome_tag'?(f.operator==='!='?!tags.has(f.value):tags.has(f.value)):true;
let rules=0;
for(const name of fs.readdirSync(root+'/RPG_BP_v0627/spawn_rules')){
 const rule=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0627/spawn_rules/'+name,'utf8'))['minecraft:spawn_rules'];
 if(rule.description.identifier==='minecraft:stray'){
  assert.ok(rule.conditions.some(c=>c['minecraft:spawns_on_surface']&&filter(c['minecraft:biome_filter'],new Set(['frozen','monster']))));
  assert.ok(rule.conditions.every(c=>!c['minecraft:spawn_event']));
 }else for(const c of rule.conditions){assert.equal(filter(c['minecraft:biome_filter'],new Set(['frozen','monster'])),false,name);assert.equal(filter(c['minecraft:biome_filter'],new Set(['snowy','monster'])),false,name);}
 rules++;
}
const recipe=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0627/recipes/dragon_choice.json','utf8'))['minecraft:recipe_shapeless'];assert.equal(recipe.ingredients.length,1);assert.equal(recipe.ingredients[0].item,'minecraft:dragon_egg');assert.equal(recipe.result.item,'rpg:dragon_choice');assert.equal(recipe.result.count,1);
const item=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0627/items/dragon_choice.json','utf8'))['minecraft:item'];assert.equal(item.components['minecraft:display_name'].value,'용의 선택');assert.ok(item.components['rpg:dragon_choice']);
console.log(`Snow: ${rules} native spawn rules exclude snowy RPG/other hostiles and enable surface Strays without skeleton conversion; biome/ground fallback, 22 RPG replacements, vanilla Stray only, dungeon/pet/summon/name/egg exclusions and unchanged plains passed; dragon-egg recipe/component verified`);
