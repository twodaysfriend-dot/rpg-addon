import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0627';
const base=root+'/RPG_BP_v0627/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}


const defs=(await load('scripts/data/skills.js')).SKILLS;
assert.equal(defs.frost_shard.damage,10);assert.equal(defs.frost_shard.cooldown,20);
assert.equal(defs.frost_grasp.damage,24);assert.equal(defs.frost_grasp.angle,60);assert.equal(defs.frost_grasp.range,7);
assert.equal(defs.frost_barrage.cooldown,100);assert.equal(defs.frost_barrage.shots,5);
assert.equal(defs.frost_great_release.damage,68);assert.equal(defs.frost_absolute.damage,56);
async function setup(){
 const hits=[],effects=[],particles=[],intervals=new Map(),delays=new Map();let id=0,tick=0,targets=[],solid=()=>false;
 const dim={id:'minecraft:overworld'},system={currentTick:0,runInterval:fn=>{intervals.set(++id,fn);return id;},clearRun:i=>intervals.delete(i),runTimeout:(fn,n)=>{delays.set(++id,{fn,at:tick+n});return id;}};
 const norm=v=>{const d=Math.hypot(v.x,v.y,v.z)||1;return {x:v.x/d,y:v.y/d,z:v.z/d};};
 const p={id:'p',typeId:'minecraft:player',isValid:true,location:{x:0,y:0,z:0},dimension:dim,getViewDirection:()=>({x:0,y:0,z:1}),getTags:()=>[]};
 const api=await load('scripts/skills/frost.js',{world:{},system,ccTicks:(t,n)=>n,CONFIG:{pvp:false},areAllies:(p,t)=>t.ally,healthAlive:e=>e.isValid,headPos:e=>({...e.location,y:e.location.y+1}),flatDir:()=>({x:0,y:0,z:1}),norm3:norm,dist3:(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z),isSolidAt:(dim,at)=>solid(at),getTargets:(p,at,r)=>targets.filter(t=>Math.hypot(t.location.x-at.x,t.location.y+.9-at.y,t.location.z-at.z)<=r),hurt:(t,p,n,type)=>{hits.push({t,n,type});return true;},applyStatus:(t,e,n,o)=>effects.push({t,e,n,...o}),particle:(dim,id,at)=>particles.push(at),teleportForSkill:(p,at)=>p.location={...at}});
 const mob=(id,x,z,y=0)=>({id,typeId:'minecraft:zombie',isValid:true,dimension:dim,location:{x,y,z}});
 return {p,api,hits,effects,particles,mob,intervals,setTargets:t=>targets=t,setSolid:fn=>solid=fn,tick(){tick++;system.currentTick=tick;for(const [i,d]of [...delays])if(d.at<=tick){delays.delete(i);d.fn();}for(const fn of [...intervals.values()])fn();}};
}
{
 const t=await setup(),point=(id,a,r)=>t.mob(id,Math.sin(a*Math.PI/180)*r,Math.cos(a*Math.PI/180)*r);
 const a=point('middle',0,5),b=point('edgeL',-30,7),c=point('edgeR',30,7),out=point('outsideAngle',30.1,5),far=point('outsideRadius',0,7.01),back=point('back',180,4),ally=point('ally',0,3),high=point('high',0,3);ally.ally=true;high.location.y=4;
 t.setTargets([a,b,c,a,out,far,back,ally,high]);assert.equal(t.api.RUNNERS.frost_grasp(t.p,{},defs.frost_grasp),true);
 assert.deepEqual(t.hits.map(h=>h.t.id),['middle','edgeL','edgeR']);assert.ok(t.hits.every(h=>h.n===24&&h.type==='magic'));
 assert.equal(t.effects.filter(e=>e.e==='slowness'&&e.n===40).length,3);
}
{
 const t=await setup();t.setTargets([t.mob('wall',0,5)]);t.setSolid(at=>at.z>=2&&at.z<3);assert.equal(t.api.RUNNERS.frost_grasp(t.p,{},defs.frost_grasp),false);assert.equal(t.hits.length,0);
}
{
 const t=await setup(),enemy=t.mob('moving',0,10);t.setTargets([enemy]);assert.equal(t.api.RUNNERS.frost_shard(t.p,{},defs.frost_shard),true);t.tick();enemy.location={x:3,y:0,z:9};for(let n=0;n<30;n++)t.tick();
 assert.equal(t.hits.length,1);assert.equal(t.hits[0].n,10);assert.equal(t.hits[0].t,enemy);assert.ok(t.particles.some(at=>at.x>1));assert.equal(t.intervals.size,0);
}
for(const variant of ['wall','lost','range']){
 const t=await setup(),enemy=t.mob('target',0,10);t.setTargets([enemy]);t.api.RUNNERS.frost_shard(t.p,{},defs.frost_shard);
 if(variant==='wall')t.setSolid(at=>at.z>=3&&at.z<=5);
 if(variant==='lost')enemy.isValid=false;
 if(variant==='range')enemy.location.z=1000;
 for(let n=0;n<50;n++)t.tick();assert.equal(t.hits.length,0);assert.equal(t.intervals.size,0);
}
{
 const t=await setup();t.setSolid(at=>at.y<0);assert.equal(t.api.RUNNERS.frost_step(t.p,{},defs.frost_step),true);assert.equal(t.p.location.z,6);
 assert.ok(t.effects.some(e=>e.e==='speed'&&e.n===200&&e.amplifier===4));assert.ok(t.effects.some(e=>e.e==='resistance'&&e.n===200&&e.amplifier===2));
}
{
 const t=await setup(),enemy=t.mob('enemy',0,5);t.setTargets([enemy]);t.api.RUNNERS.frost_absolute(t.p,{},defs.frost_absolute);assert.equal(t.hits[0].n,56);assert.ok(t.effects.some(e=>e.n===100&&e.e==='slowness'));
}
{
 const t=await setup();t.setTargets([t.mob('enemy',0,8)]);assert.equal(t.api.RUNNERS.frost_barrage(t.p,{},defs.frost_barrage),true);for(let n=0;n<50;n++)t.tick();assert.equal(t.hits.length,5);assert.ok(t.hits.every(h=>h.n===7));assert.equal(t.intervals.size,0);
}
{
 const t=await setup();t.setTargets([t.mob('enemy',0,5)]);assert.equal(t.api.RUNNERS.frost_great_release(t.p,{},defs.frost_great_release),true);for(let n=0;n<40;n++)t.tick();assert.equal(t.hits.length,1);assert.equal(t.hits[0].n,68);assert.ok(t.effects.some(e=>e.n===60&&e.e==='slowness'));assert.equal(t.intervals.size,0);
}
console.log('Frost: requested damage/cooldown data, 60deg/7-block multi-target sector and exact edges, duplicate/allied/height/behind/wall exclusions, shard live homing/wall/lost-target/range cleanup, speed V/resistance III 200 ticks, absolute 56 passed');
