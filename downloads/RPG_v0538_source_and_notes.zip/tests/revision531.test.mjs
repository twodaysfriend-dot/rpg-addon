import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,EquipmentSlot,world,players,replies,forms,events,intervals,system} from './minecraftMock.mjs';
import {RUNES} from '../RPG_BP_v0538/scripts/data/equipment.js';
import {upgradedRune} from '../RPG_BP_v0538/scripts/data/upgrades.js';
import {JOBS,BASIC_JOB_IDS} from '../RPG_BP_v0538/scripts/data/jobs.js';
import {JOB_TRIALS} from '../RPG_BP_v0538/scripts/data/jobTrials.js';
import {readRuneBag,writeRuneBag,addRuneRecord,equipRune,migrateRetiredRunes,migrateChestRune} from '../RPG_BP_v0538/scripts/core/runeInventory.js';
import {getEquipmentBonuses} from '../RPG_BP_v0538/scripts/core/equipment.js';
import {CHAMELEON_KEY,purchaseChameleonSkill,dismantleChameleonSkill,useRandomSkillBook,SKILLBOOK_ID,remainingSkillUses,executeChameleonSkill} from '../RPG_BP_v0538/scripts/core/chameleonProgress.js';
import {setSkills,getSkills,setMana,getMana,getProgress} from '../RPG_BP_v0538/scripts/core/playerData.js';
import {unspentPoints,allocateStat} from '../RPG_BP_v0538/scripts/core/stats.js';
import {offerBooks,offerSwords,offerLight} from '../RPG_BP_v0538/scripts/core/offer.js';
import {checkAdvance,requestAdvance} from '../RPG_BP_v0538/scripts/core/advance.js';
import {recordHealedPlayer,witnessHealedDeath,recordVillagerTrialKill,rememberQuestArrow,recordTargetHit,HEALED_KEY} from '../RPG_BP_v0538/scripts/core/jobQuests.js';
import {registerSandbag} from '../RPG_BP_v0538/scripts/core/sandbag.js';
function setProgress(p,s){p.setDynamicProperty('rpg:progress',JSON.stringify(s));}
function cham(id){const p=player(id,30);p.setDynamicProperty('rpg:job','chameleon');setSkills(p,[...JOBS.chameleon.skills]);return p;}
function add(p,id,level){const b=readRuneBag(p),r=addRuneRecord(b,id,level);writeRuneBag(p,b);equipRune(p,r.uid,0);}
test('five active runes: power/arcane cap30%, mana 1–3% per second, vitality cap24',()=>{
  assert.equal(Object.keys(RUNES).length,6);assert.equal(RUNES.haste,undefined);
  for(let n=0;n<=5;n++){
    assert.ok(Math.abs(upgradedRune(RUNES.power,n).physical-(1.1+n*.04))<1e-9);assert.ok(Math.abs(upgradedRune(RUNES.arcane,n).magic-(1.1+n*.04))<1e-9);
    assert.equal(upgradedRune(RUNES.mana,n).manaRegenPercent,(10+n*4)/1000);assert.ok(upgradedRune(RUNES.vitality,n).health<=24);
  }
  assert.equal(upgradedRune(RUNES.vitality,5).health,24);
});
test('retired bag and physical haste runes convert to mana without losing levels or duplicating equipped effects',()=>{
  const p=player('retired');p.setDynamicProperty('rpg:rune_bag_v1',JSON.stringify({version:1,nextId:3,runes:[{uid:'r1',id:'haste',level:5},{uid:'r2',id:'mana',level:2}],equipped:['r1','r2',null]}));p.slots[2]=new ItemStack('rpg:rune_haste',3);
  assert.equal(migrateRetiredRunes(p).ok,true);assert.equal(p.slots[2].typeId,'rpg:rune_mana');assert.equal(p.slots[2].amount,3);assert.deepEqual(readRuneBag(p).equipped,['r1',null,null]);assert.equal(readRuneBag(p).runes[0].level,5);assert.equal(getEquipmentBonuses(p).manaRegenPercent,.03);
  assert.equal(migrateRetiredRunes(p).converted,0);assert.equal(readRuneBag(p).runes.length,2);
});
test('old chest haste migrates to mana with enhancement grade intact',()=>{
  const p=player('oldchest'),t=new ItemStack('rpg:warden_chestplate');t.setDynamicProperty('rpg:chest_rune','haste');t.setDynamicProperty('rpg:rune_upgrade',4);p.equipment.set(EquipmentSlot.Chest,t);assert.equal(migrateChestRune(p).ok,true);assert.deepEqual(readRuneBag(p).runes[0],{uid:'r1',id:'mana',level:4});
});
test('purchased skill dismantles once and returns its SP to the common stat pool',()=>{
  const p=cham('paid'),before=unspentPoints(p);purchaseChameleonSkill(p,'sword_annihilation');assert.equal(unspentPoints(p),before-9);assert.equal(dismantleChameleonSkill(p,'sword_annihilation').refund,9);assert.equal(unspentPoints(p),before);assert.equal(dismantleChameleonSkill(p,'sword_annihilation').ok,false);assert.equal(getSkills(p).includes('sword_annihilation'),false);assert.equal(dismantleChameleonSkill(p,'chameleon_crimson_dash').ok,false);
});
test('random skillbook skill dismantles for SP and can fund stat allocation',()=>{
  const p=cham('free'),before=unspentPoints(p);p.slots[3]=new ItemStack(SKILLBOOK_ID);const learned=useRandomSkillBook(p,()=>0);assert.equal(learned.ok,true);const r=dismantleChameleonSkill(p,learned.id);assert.equal(r.ok,true);assert.equal(unspentPoints(p),before+r.refund);assert.equal(allocateStat(p,'str',before+r.refund).ok,true);
});
test('relearning after dismantle preserves exhausted charges and diamond purchases',()=>{
  const p=cham('charges');purchaseChameleonSkill(p,'sword_rush');for(let i=0;i<3;i++)executeChameleonSkill(p,'sword_rush',()=>true);dismantleChameleonSkill(p,'sword_rush');purchaseChameleonSkill(p,'sword_rush');assert.equal(remainingSkillUses(p,'sword_rush'),0);
});
test('failed dismantle storage restores skills and points',()=>{
  const p=cham('breakfail');purchaseChameleonSkill(p,'sword_spin');const before=p.getDynamicProperty(CHAMELEON_KEY),skills=getSkills(p),write=p.setDynamicProperty.bind(p);let fail=true;
  p.setDynamicProperty=(k,v)=>{if(fail&&k==='rpg:skills'){fail=false;throw Error('storage');}write(k,v);};assert.equal(dismantleChameleonSkill(p,'sword_spin').ok,false);assert.equal(p.getDynamicProperty(CHAMELEON_KEY),before);assert.deepEqual(getSkills(p),skills);
});
test('only five basic jobs are normal and all their trials require level ten',()=>{
  for(const j of Object.values(JOBS)){if(j.id==='apprentice'||j.placeholder)continue;assert.equal(j.hidden,!BASIC_JOB_IDS.includes(j.id),j.id);}
  for(const id of BASIC_JOB_IDS){assert.equal(JOB_TRIALS[id].level,10);const p=player('low',9);setProgress(p,Object.fromEntries(JOB_TRIALS[id].all.map(c=>[c.key,c.need])));assert.equal(checkAdvance(p,JOBS[id]).ok,false);p.setDynamicProperty('rpg:rpg_level',10);assert.equal(checkAdvance(p,JOBS[id]).ok,true);}
});
test('sword donation consumes five only, partial progress persists and surplus remains',()=>{
  const p=player('swords',10);for(let i=0;i<7;i++)p.slots[i]=new ItemStack('minecraft:diamond_sword');assert.equal(offerSwords(p).taken,5);assert.equal(p.slots.filter(Boolean).length,2);assert.equal(checkAdvance(p,JOBS.swordsman).ok,true);assert.equal(offerSwords(p).ok,false);
});
test('mage donation stops at ten and book surplus remains',()=>{
  const p=player('books',10);p.slots[3]=new ItemStack('minecraft:enchanted_book',15);assert.equal(offerBooks(p).taken,10);assert.equal(p.slots[3].amount,5);assert.equal(checkAdvance(p,JOBS.mage).ok,true);
});
test('Michael requires 192 lights from angel and donation rolls back on save failure',()=>{
  const p=player('lights',40);p.setDynamicProperty('rpg:job','angel');p.slots[0]=new ItemStack('rpg:blessing_light',64);p.slots[1]=new ItemStack('rpg:blessing_light',64);p.slots[2]=new ItemStack('rpg:blessing_light',64);p.slots[3]=new ItemStack('rpg:blessing_light',5);
  const write=p.setDynamicProperty.bind(p);let fail=true;p.setDynamicProperty=(k,v)=>{if(fail&&k==='rpg:progress'){fail=false;throw Error('storage');}write(k,v);};assert.equal(offerLight(p).ok,false);assert.equal(p.slots[0].amount,64);assert.equal(getProgress(p).light_michael,undefined);
  assert.equal(offerLight(p).taken,192);assert.equal(p.slots[3].amount,5);assert.equal(checkAdvance(p,JOBS.michael).ok,true);
});
test('archer target trial uses launch location, rejects 20 or less and prevents duplicate credit',()=>{
  const p=player('target',10);const arrow={id:'questarrow',typeId:'minecraft:arrow',location:{x:0,y:64,z:0},dimension:p.dimension,getComponent:()=>({owner:p})};const block={typeId:'minecraft:target',location:{x:21,y:64,z:0}};rememberQuestArrow(arrow);p.location={x:100,y:64,z:0};assert.equal(recordTargetHit({source:p,projectile:arrow,getBlockHit:()=>({block})}),true);assert.equal(recordTargetHit({source:p,projectile:arrow,getBlockHit:()=>({block})}),false);
  p.location={x:0,y:64,z:0};block.location.x=19;rememberQuestArrow({...arrow,id:'near'});assert.equal(recordTargetHit({source:p,projectile:{...arrow,id:'near'},getBlockHit:()=>({block})}),false);
});
test('cleric conversation cancel does not advance; explicit pledge advances at level ten',async()=>{
  const p=player('cleric',10);replies.push({canceled:false,selection:0});await requestAdvance(p,JOBS.cleric);assert.equal(p.getDynamicProperty('rpg:job'),'apprentice');assert.equal(getProgress(p).holy_consulted,undefined);
  replies.push({canceled:false,selection:1});await requestAdvance(p,JOBS.cleric);assert.equal(p.getDynamicProperty('rpg:job'),'cleric');
});
test('villager deaths count only as sword saint and sandbags count two then ten by current job',()=>{
  const p=player('villager',30);for(const job of ['swordsman','fallen_sword_saint','sword_saint']){p.setDynamicProperty('rpg:job',job);recordVillagerTrialKill(p,{typeId:'minecraft:villager_v2'});}assert.equal(getProgress(p).villager_kills,1);
  p.setDynamicProperty('rpg:job','sword_saint');setProgress(p,{villager_kills:100});assert.equal(checkAdvance(p,JOBS.fallen_sword_saint).ok,true);
  const d=player('bags',20);players.push(d);registerSandbag();const handler=events.entityDie.listeners.at(-1),die=()=>handler({deadEntity:{id:'dummy',typeId:'rpg:sandbag_entity'},damageSource:{damagingEntity:d}});die();die();assert.equal(checkAdvance(d,JOBS.fighter).ok,true);d.setDynamicProperty('rpg:job','fighter');for(let i=0;i<10;i++)die();assert.equal(checkAdvance(d,JOBS.fist_bone).ok,true);
});
function healerScene(id){const p=player('healer'+id,40),dead=player('patient'+id);p.setDynamicProperty('rpg:job','cleric');p.dimension.getBlock=()=>({isSolid:false});dead.health=0;return {p,dead};}
test('witness requires an actually healed other player nearby and consumes one life record',()=>{
  const {p,dead}=healerScene('yes');recordHealedPlayer(p,dead,0);assert.equal(witnessHealedDeath(p,dead),false);recordHealedPlayer(p,p,10);assert.equal(p.getDynamicProperty(HEALED_KEY),undefined);
  recordHealedPlayer(p,dead,4);assert.equal(witnessHealedDeath(p,dead),true);assert.equal(getProgress(p).healed_deaths,1);assert.equal(witnessHealedDeath(p,dead),false);
});
test('witness rejects walls, different dimensions and distance beyond 32',()=>{
  for(const kind of ['wall','dimension','distance']){const {p,dead}=healerScene(kind);recordHealedPlayer(p,dead,4);if(kind==='wall')p.dimension.getBlock=()=>({isSolid:true});if(kind==='dimension')dead.dimension={id:'minecraft:nether'};if(kind==='distance')dead.location.x=33;assert.equal(witnessHealedDeath(p,dead),false);assert.equal(getProgress(p).healed_deaths,undefined);}
});
test('five witnessed deaths then explicit renunciation switches holy job to fallen and removes old skills',async()=>{
  const {p,dead}=healerScene('fallen');setSkills(p,[...JOBS.cleric.skills]);for(let i=0;i<5;i++){recordHealedPlayer(p,dead,8);assert.equal(witnessHealedDeath(p,dead),true);}assert.equal(checkAdvance(p,JOBS.fallen_angel).ok,true);
  replies.push({canceled:false,selection:0});await requestAdvance(p,JOBS.fallen_angel);assert.equal(p.getDynamicProperty('rpg:job'),'cleric');
  replies.push({canceled:false,selection:1});await requestAdvance(p,JOBS.fallen_angel);assert.equal(p.getDynamicProperty('rpg:job'),'fallen_angel');assert.equal(getSkills(p).includes('holy_heal'),false);assert.equal(getSkills(p).includes('fallen_end'),true);
});
