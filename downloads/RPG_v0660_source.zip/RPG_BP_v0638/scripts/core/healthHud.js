import { HudElement, HudVisibility } from '@minecraft/server';

// Seven three-row tiers, twenty health points in a vanilla row.
const TIER_KEYS = 'roygcbp';
const visibility = new Map();

export function heartFrame(player) {
  const mode = String(player.getGameMode?.()).toLowerCase();
  const hp = player.getComponent('minecraft:health');
  if (mode === 'creative' || mode === 'spectator' || !hp ||
      !Number.isFinite(hp.currentValue) || !Number.isFinite(hp.effectiveMax) || hp.effectiveMax <= 0) {
    return '__________';
  }
  const current = Math.max(0, Math.min(hp.currentValue, hp.effectiveMax));
  const tier = Math.min(6, Math.max(0, Math.ceil(current / 60) - 1));
  const halfHearts = Math.ceil(20 * current / hp.effectiveMax);
  const full = Math.floor(halfHearts / 2);
  const partial = halfHearts % 2;
  return TIER_KEYS[tier].repeat(full) + (partial ? String(tier + 1) : '') + '0'.repeat(10 - full - partial);
}

export function syncHudVisibility(player, frame, gearLabel) {
  const previous = visibility.get(player.id);
  const customHealth = frame !== '__________';
  const customItem = Boolean(gearLabel);
  const display = player.onScreenDisplay;
  if (!previous) display.setHudVisibility(HudVisibility.Hide, [HudElement.Armor,HudElement.StatusEffects]);
  if (previous?.customHealth !== customHealth) {
    display.setHudVisibility(customHealth ? HudVisibility.Hide : HudVisibility.Reset, [HudElement.Health]);
  }
  if (previous?.customItem !== customItem) {
    display.setHudVisibility(customItem ? HudVisibility.Hide : HudVisibility.Reset, [HudElement.ItemText]);
  }
  visibility.set(player.id, {customHealth,customItem});
}

export function clearHealthHud(id) { visibility.delete(id); }
