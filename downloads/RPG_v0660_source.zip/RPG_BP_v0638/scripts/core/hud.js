import {BLACK_FLASH_KEY} from './combatContext.js';
import {dungeonHudText} from './dungeonState.js';
import {system,world} from '@minecraft/server';
import {CONFIG} from '../config.js';
import {SKILLS} from '../data/skills.js';
import {HUD_ITEM_NAMES} from '../data/hudNames.js';
import {manaText,getIndex,cooldownLeft} from './playerData.js';
import {getContext} from './context.js';
import {heartFrame,clearHealthHud,syncHudVisibility} from './healthHud.js';
import {itemRarity,rarityBadge} from '../data/rarity.js';
import {itemGrade} from '../data/grades.js';
import {classWeapon} from '../data/classWeapons.js';
import {remainingSkillUses,isEvolved} from './chameleonProgress.js';
export const RPG_HUD_MARKER='RPGH';
const hold=new Map(),sent=new Map();
const plain=text=>String(text??'').replace(/§./g,'');
const short=(text,max=26)=>{const chars=[...plain(text)];return chars.length>max?chars.slice(0,max-1).join('')+'…':chars.join('');};
function firstSlotGear(player) {
 if (player.selectedSlotIndex!==0) return '';
 const item=player.getComponent('minecraft:inventory')?.container?.getItem(0);
 if (!item) return '';
 const gear=itemRarity(item)??classWeapon(item.typeId);
 return gear ? rarityBadge(itemGrade(item))+' '+gear.name : '';
}
export function compactHudText(player,notice){
 const frame=heartFrame(player);
 const gear=firstSlotGear(player);
 syncHudVisibility(player,frame,gear);
 const header=RPG_HUD_MARKER+frame;
 if (gear) return header+gear;
 const ctx=getContext(player),lines=[];
 if(ctx){
  lines.push('§7'+short(HUD_ITEM_NAMES[ctx.held]??ctx.job.name+' 무기',22)+(player.getDynamicProperty(BLACK_FLASH_KEY)===true?' §c천멸격':''));
  if(notice)lines.push('§f'+short(notice,36));
  else if(ctx.skills.length){
   const skill=SKILLS[ctx.skills[getIndex(player)%ctx.skills.length]],left=cooldownLeft(player,skill.id);
   let text='§f'+short(skill.name,20)+' '+(left>0?'§c'+(left/20).toFixed(1)+'초':'§a준비');
   if(ctx.job.id==='chameleon'){const uses=remainingSkillUses(player,skill.id);if(uses!==null)text+=' §7남은 '+uses+'회';else if(isEvolved(player,skill.id))text+=' §d∞';}
   lines.push(text);
  }
 }
 else if(notice)lines.push('§f'+short(notice,36));
 if(ctx)lines.push((ctx.job.id==='nen'?'§3오라 ':'§bMP ')+manaText(player));
 const dungeon=dungeonHudText(player);if(dungeon)lines.push(dungeon);
 return header+lines.join('\n');
}
function send(player,text,force){
 const previous=sent.get(player.id);
 if(!text&&!previous?.text)return;
 if(force||previous?.text!==text||system.currentTick-(previous?.tick??-100)>=20){
  player.onScreenDisplay.setActionBar(text);sent.set(player.id,{text,tick:system.currentTick});
 }
}
export function notify(player,message){
 try{hold.set(player.id,{until:system.currentTick+30,message});send(player,compactHudText(player,message),true);}catch{}
}
export function refreshHud(player,force=false){
 try{if(force)hold.delete(player.id);const note=hold.get(player.id);if(note&&note.until<=system.currentTick)hold.delete(player.id);send(player,compactHudText(player,note&&note.until>system.currentTick?note.message:undefined),force);}catch{}
}
export function startHud(){
 world.afterEvents.playerLeave.subscribe(ev=>{hold.delete(ev.playerId);sent.delete(ev.playerId);clearHealthHud(ev.playerId);});
 world.afterEvents.playerSpawn.subscribe(ev=>{sent.delete(ev.player.id);clearHealthHud(ev.player.id);refreshHud(ev.player,true);});
 world.afterEvents.playerHotbarSelectedSlotChange?.subscribe(ev=>refreshHud(ev.player,true));
 system.runInterval(()=>{for(const p of world.getAllPlayers())refreshHud(p);},CONFIG.hudInterval);
}
