# RPG v0.6.60 · 한 줄 하트와 1번 칸 장비 표시

- 하트 10개를 핫바 왼쪽 위에 한 줄로 표시합니다. 채워진 양은 현재 체력 비율을 반 칸 단위로 나타냅니다. 현재 HP가 60씩 올라갈 때마다 빨강, 주황, 노랑, 초록, 하늘, 파랑, 분홍으로 바뀝니다. 148/148이면 노란 하트 10개입니다.
- 1번 칸의 RPG 장비를 들면 실제 장비의 등급과 기본 이름만 한 줄에 표시합니다. 예를 들어 고대 등급의 마공학 대검은 ‘[고대] 마공학 대검’으로 보입니다. 마법 부여, 강화, 잠금 정보는 인벤토리에서 확인할 수 있습니다.
- 투신 난참의 초기 다섯 갈래 타격 이펙트를 복원했습니다. 전방 4칸, 0.25초 간격 6회, 타격당 기본 물리 피해 10입니다. 난식은 별도 스킬로 32발 부채꼴을 사용합니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.60으로 활성화하세요. 테스트 범위는 모의 Script API, 리소스 및 패키지 구조입니다. 실제 모바일 렌더링은 별도 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0660
```
