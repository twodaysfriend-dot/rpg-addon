import {world,system} from '@minecraft/server';
import {MONSTER_LEVEL_KEY,MONSTER_LEVELS,wildMonsterLevel,levelRewardMultiplier} from '../data/monsterLevels.js';
import {LEVELED_MONSTERS,MONSTER_NAMES} from '../data/leveledMonsters.js';
export function applyMonsterLevel(entity,level,context){
 if(!LEVELED_MONSTERS.includes(entity?.typeId)||!MONSTER_LEVELS.includes(level)||typeof entity.setDynamicProperty!=='function')return false;
 if(entity.getDynamicProperty(MONSTER_LEVEL_KEY)!==undefined)return false;
 entity.triggerEvent(context?`rpg:dungeon_scaled_${context.tier}_${context.kind}_${context.kind==='normal'?context.index%3:0}`:'rpg:level_'+level);
 entity.setDynamicProperty(MONSTER_LEVEL_KEY,level);
 const original=entity.nameTag??'';entity.setDynamicProperty('rpg:monster_original_name',original);
 entity.nameTag=`§e[Lv.${level}]§r ${original||MONSTER_NAMES[entity.typeId]}`;
 return true;
}
export function registerMonsterLevels(){
 world.afterEvents.entitySpawn.subscribe(ev=>system.run(()=>{
  try{const e=ev.entity;if(!e?.isValid||!LEVELED_MONSTERS.includes(e.typeId)||e.hasTag?.('rpg_dungeon_mob')||e.getComponent('minecraft:tameable')?.isTamed||e.getDynamicProperty('rpg:necro_owner'))return;
   applyMonsterLevel(e,wildMonsterLevel(e.location));
  }catch(error){console.warn('[RPG monster level] '+error);}
 }));
}
export {levelRewardMultiplier};
