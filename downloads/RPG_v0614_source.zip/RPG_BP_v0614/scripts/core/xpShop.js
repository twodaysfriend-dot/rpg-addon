import {world,ItemStack} from '@minecraft/server';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {showForm} from './skillMenu.js';
import {XP_POTION,xpBoostRemaining,activateXpBoost} from './xpBoost.js';
export const XP_PRICE=50;
export const XP_PRODUCTS=Object.freeze([{id:'minecraft:golden_carrot',count:8,price:1,name:'황금 당근',description:'황금 당근 8개'}, {id:XP_POTION,count:3,price:50,name:'RPG 경험치 포션',description:'10분간 획득 RPG 경험치 2.5배'},{id:'rpg:enhancement_catalyst',count:25,price:50,name:'강화 촉매',description:'장비 강화에 사용하는 촉매'}]);
const busy=new Set(),buying=new Set();let registered=false;
export function purchaseXpProduct(p,index){
 if(!Number.isInteger(index)||!XP_PRODUCTS[index])return {ok:false,message:'잘못된 상품입니다.'};
 if(buying.has(p.id))return {ok:false,message:'구매 처리 중입니다.'};
 buying.add(p.id);
 let inv,before,xp,charged=false;
 try{
  xp=p.getTotalXp();if(!Number.isSafeInteger(p.level)||p.level<XP_PRODUCTS[index].price)return {ok:false,message:'기본 마인크래프트 경험치 '+XP_PRODUCTS[index].price+'레벨이 필요합니다.'};
  inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return {ok:false,message:'인벤토리를 사용할 수 없습니다.'};
  before=Array.from({length:inv.size},(_,i)=>inv.getItem(i)?.clone());
  const beforeLevel=p.level;
  p.addLevels(-XP_PRODUCTS[index].price);charged=true;
  if(p.level!==beforeLevel-XP_PRODUCTS[index].price)throw Error('경험치 차감 확인 실패');
  if(inv.addItem(new ItemStack(XP_PRODUCTS[index].id,XP_PRODUCTS[index].count)))throw Error('인벤토리 공간이 부족합니다.');
  return {ok:true,message:XP_PRODUCTS[index].name+' '+XP_PRODUCTS[index].count+'개 구매 완료 · 기본 경험치 '+XP_PRODUCTS[index].price+'레벨 사용'};
 }catch(error){
  if(before&&inv)for(let i=0;i<before.length;i++)try{inv.setItem(i,before[i]);}catch{}
  if(charged)try{p.addExperience(xp-p.getTotalXp());}catch(refundError){console.error('[RPG XP shop refund] '+refundError);return {ok:false,message:'경험치 복구 실패. 관리자에게 문의하세요.'};}
  return {ok:false,message:String(error.message??error)+' 구매를 취소했습니다.'};
 }finally{buying.delete(p.id);}
}
export async function openXpShop(p){
 if(busy.has(p.id))return;busy.add(p.id);
 try{
  while(p.isValid){
   const seconds=Math.ceil(xpBoostRemaining(p)/1000);
   const form=new ActionFormData().title('기본 경험치 상점').body('보유 기본 경험치: '+p.level+'레벨\n황금 당근 8개: 1레벨 / 포션 3개·촉매 25개: 각 50레벨\n\n포션: 마신 뒤 10분간 획득 RPG 경험치 ×2.5.\n재사용 시 10분으로 갱신되며 배율은 중첩되지 않습니다.\n접속을 종료해도 시간이 흐릅니다.\n현재 효과: '+(seconds?Math.floor(seconds/60)+'분 '+seconds%60+'초 남음':'없음'));
   for(const product of XP_PRODUCTS)form.button(product.name+' '+product.count+'개 · '+product.price+'레벨\n'+product.description);form.button('닫기');
   const r=await showForm(form,p);if(!r||r.canceled||!Number.isInteger(r.selection)||r.selection<0||r.selection>=XP_PRODUCTS.length)return;
   const confirm=await showForm(new MessageFormData().title('구매 확인').body('기본 경험치 '+XP_PRODUCTS[r.selection].price+'레벨로 '+XP_PRODUCTS[r.selection].name+' '+XP_PRODUCTS[r.selection].count+'개를 구매할까요?').button1('취소').button2('구매'),p);
   if(confirm&&!confirm.canceled&&confirm.selection===1){const result=purchaseXpProduct(p,r.selection);p.sendMessage((result.ok?'§a':'§e')+result.message);}
  }
 }catch(error){try{p.sendMessage('§c[경험치 상점] '+String(error));}catch{}}
 finally{busy.delete(p.id);}
}
export function registerXpShop(){
 if(registered)return;registered=true;
 // Vanilla food consumption handles the drink animation and consumes one bottle.
 world.afterEvents.itemCompleteUse.subscribe(e=>{if(e.itemStack?.typeId===XP_POTION)try{activateXpBoost(e.source);}catch(error){console.warn('[RPG XP potion] '+error);}});
 world.afterEvents.playerLeave.subscribe(e=>{busy.delete(e.playerId);buying.delete(e.playerId);});
}
