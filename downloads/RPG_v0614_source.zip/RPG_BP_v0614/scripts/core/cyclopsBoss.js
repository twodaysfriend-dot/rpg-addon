import {isTimeFrozen} from './timeStopDamage.js';
import {levelAttackMultiplier,MONSTER_LEVEL_KEY} from '../data/monsterLevels.js';
import {playBossMotion} from './bossMotion.js';
import { world, system, EntityDamageCause } from '@minecraft/server';

export const CYCLOPS_ID='rpg:cyclops_boss';
export const EYE_HEIGHT=5.44;
export const EYE_FORWARD=1.16;
export const EYE_RADIUS=0.67;
const STATE=new Map();
const PROJECTILE_EYES=new Map();
const BONUS_IN_FLIGHT=new Set();
const DUST='minecraft:basic_smoke_particle';
const CRIT='minecraft:critical_hit_emitter';
function valid(e){try{return !!e?.isValid && (e.getComponent('minecraft:health')?.currentValue??0)>0;}catch{return false;}}
function vec(a,b){return {x:a.x-b.x,y:a.y-b.y,z:a.z-b.z};}
function dist(a,b){const d=vec(a,b);return Math.hypot(d.x,d.y,d.z);}
function flatView(boss){
  try{const v=boss.getViewDirection();const n=Math.hypot(v.x,v.z)||1;return {x:v.x/n,z:v.z/n};}
  catch{return {x:0,z:-1};}
}
export function eyeCenter(boss){
  const l=boss.location,v=flatView(boss);
  return {x:l.x+v.x*EYE_FORWARD,y:l.y+EYE_HEIGHT,z:l.z+v.z*EYE_FORWARD};
}
export function isEyeProjectileHit(boss,location,source){
  if(!location || source?.typeId!=='minecraft:player')return false;
  const eye=eyeCenter(boss),f=flatView(boss),back=vec(source.location,eye);
  return (back.x*f.x+back.z*f.z)>-0.1 && dist(location,eye)<=0.92;
}
export function isEyeMeleeAim(boss,attacker){
  if(attacker?.typeId!=='minecraft:player')return false;
  try {
    const origin=attacker.getHeadLocation(),dir=attacker.getViewDirection();
    const eye=eyeCenter(boss),f=flatView(boss),off=vec(origin,eye);
    if(off.x*f.x+off.z*f.z<-0.1)return false;
    const to=vec(eye,origin),t=to.x*dir.x+to.y*dir.y+to.z*dir.z;
    if(t<0 || t>6.8)return false;
    const near={x:origin.x+dir.x*t,y:origin.y+dir.y*t,z:origin.z+dir.z*t};
    return dist(near,eye)<=EYE_RADIUS;
  } catch{return false;}
}
function fx(dim,id,p){try{dim.spawnParticle(id,p);}catch{}}
function sound(dim,id,p){try{dim.playSound(id,p,{volume:1.15,pitch:0.6});}catch{}}
function playersNear(boss,range){
  const pos=boss.location;return world.getAllPlayers().filter(p=>{
    try{return valid(p) && p.dimension.id===boss.dimension.id && dist(p.location,pos)<=range && p.getGameMode()!=='creative' && p.getGameMode()!=='spectator';}
    catch{return false;}
  });
}
function ring(dim,point,r,num=18,id=DUST){
  for(let i=0;i<num;i++){
    const a=i*Math.PI*2/num;
    fx(dim,id,{x:point.x+Math.cos(a)*r,y:point.y+0.12,z:point.z+Math.sin(a)*r});
  }
}
function stomp(boss){
  if(!valid(boss)||isTimeFrozen(boss))return;
  playBossMotion(boss,'slam');
  const pos={...boss.location},dir=flatView(boss);
  const impact={x:pos.x+dir.x*1.4,y:pos.y,z:pos.z+dir.z*1.4};
  const dim=boss.dimension, radius=3.9;
  ring(dim,impact,radius,14,CRIT);
  sound(dim,'mob.irongolem.throw',pos);
  system.runTimeout(()=>{
    if(!valid(boss)||isTimeFrozen(boss))return;
    ring(dim,impact,radius,25,CRIT);
    ring(dim,impact,2.2,16,DUST);
    sound(dim,'random.explode',impact);
    for(const p of playersNear(boss,6.4)){
      const l=p.location,d=Math.hypot(l.x-impact.x,l.z-impact.z);
      if(d>radius || Math.abs(l.y-impact.y)>2.5)continue;
      try{p.applyDamage(18*levelAttackMultiplier(boss.getDynamicProperty?.(MONSTER_LEVEL_KEY)??1),{cause:EntityDamageCause.entityAttack,damagingEntity:boss});}catch{}
      try{
        const n=d||1;
        p.applyImpulse({x:(l.x-impact.x)/n*0.9,y:0.19,z:(l.z-impact.z)/n*0.9});
      }catch{}
      try{p.addEffect('slowness',40,{amplifier:1,showParticles:false});}catch{}
    }
  },16);
}
function bonusDamage(boss,attacker,damage){
  if(!valid(boss)||!Number.isFinite(damage)||damage<=0 || BONUS_IN_FLIGHT.has(boss.id))return;
  BONUS_IN_FLIGHT.add(boss.id);
  // 3x damage = vanilla hit once + a separately attributed 2x weak-spot bonus.
  try{boss.applyDamage(damage*2,{cause:EntityDamageCause.entityAttack,damagingEntity:attacker});}
  catch{}
  try{const p=eyeCenter(boss);for(let i=0;i<4;i++)fx(boss.dimension,CRIT,{x:p.x+(i%2?0.24:-0.24),y:p.y+(i%3-1)*0.17,z:p.z});}catch{}
  try{if(attacker?.typeId==='minecraft:player')attacker.onScreenDisplay?.setActionBar('§c외눈박이 거인 약점 명중! §e치명타 ×3');}catch{}
  system.runTimeout(()=>BONUS_IN_FLIGHT.delete(boss.id),2);
}
export function registerCyclopsBoss(){
  world.afterEvents.projectileHitEntity.subscribe(ev=>{
    try{
      const b=ev.getEntityHit()?.entity;
      if(b?.typeId!==CYCLOPS_ID || !ev.projectile?.id)return;
      if(isEyeProjectileHit(b,ev.location,ev.source))
        PROJECTILE_EYES.set(ev.projectile.id,{boss:b.id,source:ev.source,tick:system.currentTick});
    }catch{}
  });
  world.afterEvents.entityHurt.subscribe(ev=>{
    const b=ev.hurtEntity;
    if(b?.typeId!==CYCLOPS_ID||BONUS_IN_FLIGHT.has(b.id))return;
    const damage=ev.damage,src=ev.damageSource;
    if(!Number.isFinite(damage)||damage<=0)return;
    const projectileId=src?.damagingProjectile?.id;
    if(projectileId){
      // Bedrock emits the projectile-hit and hurt notifications in either order.
      system.runTimeout(()=>{
        const hit=PROJECTILE_EYES.get(projectileId);
        if(hit && hit.boss===b.id && system.currentTick-hit.tick<=6){
          PROJECTILE_EYES.delete(projectileId);
          bonusDamage(b,hit.source,damage);
        }
      },1);
      return;
    }
    const player=src?.damagingEntity;
    if(src?.cause===EntityDamageCause.entityAttack && isEyeMeleeAim(b,player))
      system.run(()=>bonusDamage(b,player,damage));
  });
  // Use only loaded bosses, and prune event/AI state to prevent world-save memory leaks.
  system.runInterval(()=>{
    const tick=system.currentTick, seen=new Set();
    for(const dimName of ['overworld','nether','the_end']){
      let dim,bosses;try{dim=world.getDimension(dimName);bosses=dim.getEntities({type:CYCLOPS_ID});}catch{continue;}
      for(const boss of bosses){
        if(!valid(boss)||isTimeFrozen(boss))continue;
        seen.add(boss.id);
        let st=STATE.get(boss.id);
        if(!st){st={next:tick+90};STATE.set(boss.id,st);}
        const players=playersNear(boss,7);
        if(!players.length)continue;
        const hp=boss.getComponent('minecraft:health');
        const fury=(hp?.currentValue??850)<(hp?.effectiveMax??850)*0.5;
        if(tick>=st.next && players.some(p=>dist(p.location,boss.location)<5.5)){
          st.next=tick+(fury?125:175);
          stomp(boss);
        }
      }
    }
    for(const id of STATE.keys())if(!seen.has(id))STATE.delete(id);
    for(const [id,hit] of PROJECTILE_EYES)if(tick-hit.tick>7)PROJECTILE_EYES.delete(id);
  },10);
}
