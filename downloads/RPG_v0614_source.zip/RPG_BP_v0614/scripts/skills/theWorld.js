import {canUseSkill,isChameleonWeapon} from '../core/skillAccess.js';
import {isBoundHeld} from '../core/weaponBinding.js';
import {scriptedMeleeRuneFactor} from '../core/runeMelee.js';
import {duelOf} from '../core/pvp.js';
import {world,system,InputPermissionCategory,EntityDamageCause,InputButton,ButtonState} from '@minecraft/server';
import {attack as martialAttack} from './warGod.js';
import {SKILLS} from '../data/skills.js';
import {getJobId} from '../core/playerData.js';
import {getTargets,flatDir,isSolidAt,knockback,skillItemId as heldItemId,hurt} from '../core/util.js';
import {areAllies} from '../core/social.js';
import {isBoss} from '../core/crowdControl.js';
import {scriptedHit,setCombatHealth,noteManualDamage} from '../core/combatContext.js';
import {registerStoppedTarget,takeStoppedDamage,isTimeFrozen} from '../core/timeStopDamage.js';
export {isTimeFrozen};
const MARK='rpg:the_world_freeze_v1',TAG='rpg_the_world_frozen',WEAK='rpg:the_world_native_guard',HIGH='rpg:the_world_high_until',BLOOD='rpg:the_world_blood_until';
const sessions=new Map(),frames=new Map(),basics=new Map();let registered=false;
// 비행 이동속도: 기존의 2배(수평 .42→.84, 수직 .32→.64).
const FLY_H=.84,FLY_V=.64;
// /rpg:wfly — 시간 정지 밖에서도 켜 두는 상시 비행. id -> {hoverY,flightControlled}
const WFLY='rpg:wfly_on',wfly=new Map();
function slowFall(p,ticks){try{p.addEffect('slow_falling',ticks,{amplifier:0,showParticles:false});}catch{}}
export function isWorldFlyOn(p){return wfly.has(p.id);}
export function setWorldFly(p,on){
 if(!on){const s=wfly.get(p.id);wfly.delete(p.id);try{p.setDynamicProperty(WFLY,undefined);}catch{}
  if(s){stopWorldFlight(p,s);slowFall(p,100);return true;}return false;}
 if(wfly.has(p.id))return false;
 wfly.set(p.id,{hoverY:undefined,flightControlled:false});try{p.setDynamicProperty(WFLY,true);}catch{}slowFall(p,30);return true;
}
function tickWfly(){
 if(!wfly.size)return;
 const players=world.getAllPlayers();
 for(const [id,s]of wfly){
  const p=players.find(q=>q.id===id);
  if(!p||!living(p)||getJobId(p)!=='the_world'){wfly.delete(id);if(valid(p)){try{p.setDynamicProperty(WFLY,undefined);}catch{}}continue;}
  if(sessions.has(id))continue; // 시간 정지 중에는 정지 비행이 처리합니다.
  try{tickWorldFlight(p,s);if(system.currentTick%10===0)slowFall(p,30);}catch(error){console.warn('[The World wfly] '+error);}
 }
}
const valid=e=>{try{return Boolean(e?.isValid);}catch{return false;}};
const living=e=>valid(e)&&(e.getComponent('minecraft:health')?.currentValue??0)>0;
const effectData=(e,name)=>{const f=e.getEffect(name);return f?{duration:f.duration,amplifier:f.amplifier}:null;};
function enemy(p,e){return valid(e)&&p.id!==e.id&&e.typeId!=='rpg:the_world_stand'&&!areAllies(p,e)&&!e.typeId.startsWith('rpg:hito_')&&e.typeId!=='rpg:gpt_guide'&&(e.typeId!=='minecraft:player'||!['creative','spectator'].includes(String(e.getGameMode?.()).toLowerCase()));}
export function restoreFrozenEntity(e){
 const raw=e.getDynamicProperty(MARK);if(raw===undefined){try{e.removeTag(TAG);}catch{}return true;}
 let saved;try{saved=JSON.parse(raw);}catch{console.warn('[The World] corrupt recovery marker');return false;}
 let okay=true;const elapsed=Math.max(0,Math.floor((Date.now()-saved.at)/50));
 for(const name of ['slowness','weakness'])try{e.removeEffect(name);const old=saved.effects[name];if(old&&old.duration>elapsed)e.addEffect(name,old.duration-elapsed,{amplifier:old.amplifier,showParticles:false});}catch{okay=false;}
 if(e.typeId==='minecraft:player')for(const [category,enabled]of saved.permissions??[])try{e.inputPermissions.setPermissionCategory(category,enabled);}catch{okay=false;}
 try{e.clearVelocity();const projectile=e.getComponent('minecraft:projectile');if(projectile)projectile.shoot(saved.velocity);else e.applyImpulse(saved.velocity);}catch{okay=false;}
 if(okay){e.setDynamicProperty(MARK,undefined);e.removeTag(TAG);}return okay;
}
function sharedGuild(a,b){try{return a?.typeId==='minecraft:player'&&b?.typeId==='minecraft:player'&&a.getTags().some(t=>t.startsWith('rpg_guild_')&&b.hasTag(t));}catch{return false;}}
function freeze(p,e,session){
 const base=session.duration??SKILLS.world_stop.duration;
 if(frames.has(e.id)||!enemy(p,e)||sharedGuild(p,e))return false;
 const projectile=e.getComponent('minecraft:projectile');
 if(projectile?.owner&&(projectile.owner.id===p.id||areAllies(p,projectile.owner)||sharedGuild(p,projectile.owner)))return false;
 if(!projectile&&!living(e))return false;
 if(e.getDynamicProperty(MARK)!==undefined&&!restoreFrozenEntity(e))return false;
 const saved={at:Date.now(),effects:{slowness:effectData(e,'slowness'),weakness:effectData(e,'weakness')},velocity:e.getVelocity(),permissions:[]};
 if(e.typeId==='minecraft:player')try{for(const category of [...new Set([InputPermissionCategory.Movement,InputPermissionCategory.Camera,...Object.values(InputPermissionCategory).filter(v=>typeof v==='number')])])saved.permissions.push([category,e.inputPermissions.isPermissionCategoryEnabled(category)]);}catch{saved.permissions=[];}
 e.setDynamicProperty(MARK,JSON.stringify(saved));e.addTag(TAG);e.clearVelocity();
 let mode='position';
 if(saved.permissions.length>=2)try{for(const category of [InputPermissionCategory.Movement,InputPermissionCategory.Camera])e.inputPermissions.setPermissionCategory(category,false);mode='inputPermissions';}catch{mode='position';}
 const duration=Math.ceil(base*(isBoss(e)?.5:1));
 if(!projectile){e.addEffect('slowness',duration,{amplifier:255,showParticles:false});e.addEffect('weakness',duration,{amplifier:255,showParticles:false});}
 frames.set(e.id,{entity:e,owner:p,location:{...e.location},rotation:e.getRotation(),dimension:e.dimension.id,until:system.currentTick+duration,duel:duelOf(p),mode});session.ids.add(e.id);registerStoppedTarget(e,p);return true;
}
function releaseFrame(id,applyDamage=true){
 const f=frames.get(id);frames.delete(id);const deferred=takeStoppedDamage(id);if(!f)return;
 try{if(valid(f.entity))restoreFrozenEntity(f.entity);}catch(error){console.warn('[The World restore] '+error);}
 if(!applyDamage||!deferred?.damage||!living(f.entity)||!living(f.owner)||areAllies(f.owner,f.entity)||(f.duel&&(f.duel.finished||duelOf(f.owner)!==f.duel||duelOf(f.entity)!==f.duel)))return;
 const target=f.entity,source=f.owner,amount=deferred.damage;
 scriptedHit(target,source,()=>{try{if(target.applyDamage(amount,{cause:EntityDamageCause.override,damagingEntity:source})!==false)return true;}catch{}
  const hp=target.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return false;const before=hp.currentValue;setCombatHealth(target,source,hp,Math.max(0,before-amount));noteManualDamage(source,target,Math.min(before,amount));return true;});
}
function restoreWorldGuard(id,session){
 try{const pl=world.getAllPlayers().find(x=>x.id===id);if(!pl||!valid(pl)||!session.guard)return;
  pl.removeEffect('resistance');const prev=session.guard.prev;
  if(prev){const left=prev.endTick-system.currentTick;if(left>0)pl.addEffect('resistance',left,{amplifier:prev.amplifier,showParticles:false});}
 }catch{}
}
// Stable 2.2.0 has no survival mayfly setter. Use ordinary collision-aware
// player physics; never change game mode, abilities, gravity or input permissions.
function tickWorldFlight(p,session){
 const mode=String(p.getGameMode()).toLowerCase();
 if(mode==='creative'||mode==='spectator'||isTimeFrozen(p)){session.flightControlled=false;return;}
 const input=p.inputInfo;
 const move=input.getMovementVector();
 const x=Number.isFinite(move.x)?move.x:0,y=Number.isFinite(move.y)?move.y:0;
 const length=Math.max(1,Math.hypot(x,y));
 const yaw=p.getRotation().y*Math.PI/180;
 // Movement vector: x is left-positive, y is forward-positive.
 const vx=(x*Math.cos(yaw)-y*Math.sin(yaw))/length*FLY_H;
 const vz=(y*Math.cos(yaw)+x*Math.sin(yaw))/length*FLY_H;
 const up=input.getButtonState(InputButton.Jump)===ButtonState.Pressed;
 // Touch sneak is a one-tick input pulse; isSneaking also covers its toggle state.
 const down=p.isSneaking||input.getButtonState(InputButton.Sneak)===ButtonState.Pressed;
 const vertical=Number(up)-Number(down);
 let vy;
 if(vertical){session.hoverY=undefined;vy=vertical*FLY_V;}
 else {session.hoverY??=p.location.y;vy=Math.max(-FLY_V,Math.min(FLY_V,(session.hoverY-p.location.y)*.5));}
 p.clearVelocity();
 p.applyImpulse({x:vx,y:vy+.08,z:vz});
 session.flightControlled=true;
}
function stopWorldFlight(p,session){
 // No persistent flight state exists: reload/rejoin naturally returns to normal physics.
 if(session.flightControlled&&valid(p))try{p.clearVelocity();}catch{}
 session.flightControlled=false;
}
export function stopTheWorld(p,applyDamage=true){const session=sessions.get(p.id);if(!session)return false;sessions.delete(p.id);stopWorldFlight(p,session);restoreWorldGuard(p.id,session);for(const id of session.ids)releaseFrame(id,applyDamage);return true;}

export function startTheWorld(p){
 if(!canUseSkill(p,'world_stop',['the_world']))return false;
 if(sessions.has(p.id))return false;
 let duration=SKILLS.world_stop.duration,extended=false;
 try{if(Number(p.getDynamicProperty(BLOOD)??0)>Date.now()){duration=SKILLS.world_stop.bloodDuration;extended=true;}p.setDynamicProperty(BLOOD,undefined);}catch{}
 const session={ids:new Set(),dimension:p.dimension.id,duration,until:system.currentTick+duration};sessions.set(p.id,session);
 // 시간 정지 중 시전자는 어떤 적의 공격도 받지 않음(저항 V = 피해 100% 감소). 기존 저항 효과는 종료 후 복원.
 try{const old=p.getEffect('resistance');session.guard={prev:old?{amplifier:old.amplifier,endTick:system.currentTick+old.duration}:null};p.addEffect('resistance',duration+10,{amplifier:4,showParticles:false});}catch(error){console.warn('[The World guard] '+error);}
 try{for(const e of p.dimension.getEntities({location:p.location,maxDistance:SKILLS.world_stop.radius})){if(session.ids.size>=60)break;try{freeze(p,e,session);}catch(error){try{restoreFrozenEntity(e);}catch{}console.warn('[The World freeze] '+error);}}}
 catch(error){stopTheWorld(p,false);throw error;}
 p.sendMessage(extended?'§6더 월드! §c흡혈의 힘으로 §e9초§7간 시간이 멈춥니다.':'§6더 월드! §7시간이 멈췄습니다.');return true;
}
export function tickTheWorld(){
 tickWfly();
 for(const [id,s]of sessions){const p=world.getAllPlayers().find(p=>p.id===id);if(!living(p)||p.dimension.id!==s.dimension||system.currentTick>=s.until||!canUseSkill(p,'world_stop',['the_world'])){stopTheWorld(p??{id},living(p)&&p.dimension.id===s.dimension&&canUseSkill(p,'world_stop',['the_world']));continue;}
  try{tickWorldFlight(p,s);}catch(error){stopTheWorld(p,false);console.warn('[The World flight] '+error);}
 }
 for(const [id,f]of frames){
  if(!valid(f.entity)||!living(f.owner)||f.entity.dimension.id!==f.dimension||system.currentTick>=f.until||areAllies(f.owner,f.entity)){releaseFrame(id);continue;}
  try{f.entity.teleport(f.location,{dimension:f.entity.dimension,rotation:f.rotation,keepVelocity:false});f.entity.clearVelocity();}catch{releaseFrame(id);}
 }
}
export function recoverStoppedEntities(){
 for(const name of ['overworld','nether','the_end'])try{for(const e of world.getDimension(name).getEntities({tags:[TAG]}))if(!frames.has(e.id))try{restoreFrozenEntity(e);}catch(error){console.warn('[The World recovery] '+error);}}catch{}
 for(const p of world.getAllPlayers())if(!frames.has(p.id)&&p.getDynamicProperty(MARK)!==undefined)try{restoreFrozenEntity(p);}catch{}
}
function saveNativeGuard(p){if(p.getDynamicProperty(WEAK)===undefined)p.setDynamicProperty(WEAK,JSON.stringify({at:Date.now(),effect:effectData(p,'weakness')}));p.addEffect('weakness',40,{amplifier:255,showParticles:false});}
function restoreNativeGuard(p){const raw=p.getDynamicProperty(WEAK);if(raw===undefined)return;const saved=JSON.parse(raw);p.removeEffect('weakness');const ticks=(Date.now()-saved.at)/50;if(saved.effect?.duration>ticks)p.addEffect('weakness',Math.ceil(saved.effect.duration-ticks),{amplifier:saved.effect.amplifier,showParticles:false});p.setDynamicProperty(WEAK,undefined);}
export function tickWorldGuards(){for(const p of world.getAllPlayers())try{if(isTimeFrozen(p))continue;if(getJobId(p)==='the_world'&&(heldItemId(p)==='rpg:the_world_arrow'||sessions.has(p.id))&&!isTimeFrozen(p))saveNativeGuard(p);else restoreNativeGuard(p);}catch(error){console.warn('[The World melee guard] '+error);}}
export function isWorldHighActive(p){return Number(p.getDynamicProperty(HIGH)??0)>Date.now();}
function punch(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,hits:d.hits*2}:d);}
function finisher(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,damagePerHit:d.damagePerHit*2}:d);}
function roller(p,job,d){const dir=flatDir(p),origin=p.location;let at=origin;for(let n=.5;n<=3;n+=.5){const q={x:origin.x+dir.x*n,y:origin.y,z:origin.z+dir.z*n};if(isSolidAt(p.dimension,q)||isSolidAt(p.dimension,{...q,y:q.y+1}))break;at=q;}p.teleport(at,{dimension:p.dimension,keepVelocity:false});return martialAttack(p,job,d);}
function high(p){p.setDynamicProperty(HIGH,Date.now()+8000);p.addEffect('speed',160,{amplifier:1,showParticles:false});const strength=p.getEffect('strength');if(!strength||strength.amplifier<1||(strength.amplifier===1&&strength.duration<160))p.addEffect('strength',160,{amplifier:1,showParticles:false});return true;}
// 흡혈: 전방 근접 대상을 물어 체력을 회복하고 재생 II 10초·저항 II 30초.
// 보스·데스웜(샌드웜)·대장 고블린(대왕 고블린)을 흡혈하면 60초 안에 쓰는 다음 더 월드가 9초로 증가.
const BLOOD_BIG=new Set(['rpg:deathworm','rpg:elite_deathworm','rpg:goblin_captain','rpg:elite_goblin_captain']);
function bloodTarget(p){
 const dir=p.getViewDirection(),origin={x:p.location.x,y:p.location.y+1,z:p.location.z};let best,bestD=Infinity;
 for(const e of getTargets(p,origin,5.5,0)){
  if(!enemy(p,e)||!living(e))continue;
  const dx=e.location.x-origin.x,dy=e.location.y+(e.getComponent('minecraft:health')?1:0)*.8-origin.y,dz=e.location.z-origin.z,d=Math.hypot(dx,dy,dz)||.01;
  if((dx*dir.x+dy*dir.y+dz*dir.z)/d<.35)continue;
  if(d<bestD){best=e;bestD=d;}
 }
 return best;
}
function blood(p,job,def,hitTarget){
 const target=hitTarget&&enemy(p,hitTarget)&&living(hitTarget)&&p.dimension.id===hitTarget.dimension.id&&Math.hypot(p.location.x-hitTarget.location.x,p.location.y-hitTarget.location.y,p.location.z-hitTarget.location.z)<=5.5?hitTarget:bloodTarget(p);
 p.addEffect('regeneration',200,{amplifier:1,showParticles:true});
 p.addEffect('resistance',600,{amplifier:1,showParticles:true});
 if(!target){p.sendMessage('§c흡혈! §7(대상 없음 · 재생 II 10초 / 저항 II 30초)');return true;}
 hurt(target,p,12,'physical',{ignoreInvulnerability:true});
 try{const hp=p.getComponent('minecraft:health');if(hp)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+8));}catch{}
 try{p.dimension.spawnParticle('minecraft:redstone_ore_dust_particle',{x:target.location.x,y:target.location.y+1,z:target.location.z});}catch{}
 if(isBoss(target)||BLOOD_BIG.has(target.typeId)){
  p.setDynamicProperty(BLOOD,Date.now()+60000);
  p.sendMessage('§4흡혈! §7강대한 피를 마셨습니다. §e60초 안의 더 월드가 9초로 증가합니다.');
 }else p.sendMessage('§c흡혈! §7재생 II 10초 / 저항 II 30초');
 return true;
}
export const RUNNERS={world_blood:blood,world_muda:punch,world_finish:finisher,world_roller:roller,world_high:high,world_stop:startTheWorld};
export function registerTheWorld(){
 if(registered)return;registered=true;
 world.beforeEvents.itemUse.subscribe(e=>{const id=e.itemStack?.typeId,allowed=id==='rpg:the_world_arrow'||isBoundHeld(e.source,id)||(getJobId(e.source)==='chameleon'&&isChameleonWeapon(id));if(isTimeFrozen(e.source)||(sessions.has(e.source.id)&&!allowed))e.cancel=true;});
 system.runInterval(tickTheWorld,1);system.runInterval(tickWorldGuards,1);system.runInterval(recoverStoppedEntities,100);system.run(recoverStoppedEntities);
 world.afterEvents.entitySpawn.subscribe(ev=>system.run(()=>{try{const owner=ev.entity.getComponent('minecraft:projectile')?.owner;if(owner&&isTimeFrozen(owner))ev.entity.remove();}catch{}}));
 // Stable 2.2.0 has no before-hurt cancellation. Weakness/projectile suppression
 // prevent normal attacks; refund any surviving native damage that still reports.
 world.afterEvents.entityHurt.subscribe(ev=>{
  const src=ev.damageSource,projectile=src?.damagingProjectile;
  let attacker=src?.damagingEntity;
  try{attacker=attacker??projectile?.getComponent('minecraft:projectile')?.owner;}catch{}
  try{const victim=ev.hurtEntity;if(victim?.typeId==='minecraft:player'&&sessions.has(victim.id)&&ev.damage>0&&attacker?.id!==victim.id){const h=victim.getComponent('minecraft:health');if(h&&h.currentValue>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));}}catch{}
  if(!isTimeFrozen(attacker)&&!isTimeFrozen(projectile))return;
  try{const h=ev.hurtEntity.getComponent('minecraft:health');if(h?.currentValue>0&&ev.damage>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));}catch{}
 });
 world.afterEvents.entityLoad.subscribe(ev=>{if(!frames.has(ev.entity.id))try{restoreFrozenEntity(ev.entity);}catch{}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.run(()=>{try{if(ev.initialSpawn&&ev.player.getDynamicProperty(WFLY)===true&&getJobId(ev.player)==='the_world'&&!wfly.has(ev.player.id))wfly.set(ev.player.id,{hoverY:undefined,flightControlled:false});}catch{}try{if(!frames.has(ev.player.id))restoreFrozenEntity(ev.player);restoreNativeGuard(ev.player);}catch{}}));
 world.afterEvents.playerDimensionChange.subscribe(ev=>stopTheWorld(ev.player,false));
 world.afterEvents.playerLeave.subscribe(ev=>{stopTheWorld({id:ev.playerId},false);basics.delete(ev.playerId);wfly.delete(ev.playerId);});
 world.afterEvents.entityDie.subscribe(ev=>{stopTheWorld(ev.deadEntity,false);if(wfly.delete(ev.deadEntity.id))try{ev.deadEntity.setDynamicProperty(WFLY,undefined);}catch{}if(frames.has(ev.deadEntity.id))releaseFrame(ev.deadEntity.id,false);});
 world.afterEvents.entityHitEntity.subscribe(ev=>{const p=ev.damagingEntity,t=ev.hitEntity;if(p?.typeId!=='minecraft:player'||getJobId(p)!=='the_world'||heldItemId(p)!=='rpg:the_world_arrow'||isTimeFrozen(p)||!enemy(p,t))return;
  const gap=isWorldHighActive(p)?5:10;if((basics.get(p.id)??-100)>system.currentTick-gap)return;basics.set(p.id,system.currentTick);hurt(t,p,8*scriptedMeleeRuneFactor(p),'physical',{ignoreInvulnerability:true});});
}
