import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const base=(process.argv[2]??'/workspace/rpg-work/v0614')+'/RPG_BP_v0614/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}
const potion='rpg:xp_potion';
class Item{constructor(id,count){this.typeId=id;this.amount=count;}clone(){return new Item(this.typeId,this.amount);}}
const shop=await load('scripts/core/xpShop.js',{ItemStack:Item,XP_POTION:potion});
function customer(level=100,fail=false){const items=Array(4);const inv={size:4,getItem:i=>items[i],setItem:(i,v)=>items[i]=v,addItem:item=>{items[0]=item;return fail?item:undefined;}};const p={id:'buyer',level,getTotalXp:()=>p.level*100,addLevels:n=>p.level+=n,addExperience:n=>p.level+=n/100,getComponent:()=>({container:inv})};return {p,items};}
for(const [i,id,count] of [[1,potion,3],[2,'rpg:enhancement_catalyst',25]]){
 const {p,items}=customer();assert.equal(shop.purchaseXpProduct(p,i).ok,true);assert.equal(p.level,50);assert.equal(items[0].typeId,id);assert.equal(items[0].amount,count);
}
{const {p,items}=customer(49);assert.equal(shop.purchaseXpProduct(p,1).ok,false);assert.equal(p.level,49);assert.equal(items[0],undefined);}
{const {p,items}=customer(100,true);assert.equal(shop.purchaseXpProduct(p,2).ok,false);assert.equal(p.level,100);assert.equal(items[0],undefined);}
console.log('Shop: potion/catalyst quantity, insufficient XP, full inventory refund passed');
const jobs=await load('scripts/data/jobs.js');const skills=await load('scripts/data/skills.js');
assert.equal(jobs.JOBS.war_god.skills.length,6);assert.equal(jobs.JOBS.the_world.unlockPending,undefined);
let pending=[],damage=[];let target={id:'enemy',typeId:'minecraft:zombie',location:{x:0,y:0,z:2},applyDamage:n=>damage.push(n)};
const wg=await load('scripts/skills/warGod.js',{
 system:{runTimeout:fn=>pending.push(fn)},world:{},getTargets:()=>target?[target]:[],flatDir:()=>({x:0,z:1}),isSolidAt:()=>false,areAllies:()=>false,CONFIG:{pvp:false},
 skillDamageFor:(p,n)=>n,scriptedHit:(t,p,fn)=>fn(),deferStoppedDamage:()=>false,EntityDamageCause:{override:'override'},BLACK_FLASH_KEY:'flash',
});
const flags={};const p={id:'p',isValid:true,location:{x:0,y:0,z:0},dimension:{id:'overworld'},getComponent:()=>({currentValue:100}),getDynamicProperty:k=>flags[k],setDynamicProperty:(k,v)=>flags[k]=v};
assert.equal(wg.RUNNERS.war_god_slash,wg.attack);
flags.flash=true;assert.equal(wg.RUNNERS.war_god_slash(p,null,skills.SKILLS.war_god_slash),true);for(const fn of pending)fn();assert.equal(damage.length,6);assert.equal(damage.reduce((a,b)=>a+b,0),180);assert.equal(flags.flash,undefined);
target=null;flags.flash=true;assert.equal(wg.attack(p,null,skills.SKILLS.war_god_slash),false);assert.equal(flags.flash,true);
console.log('War God: 6 skills, restored slash 6 hits, boosted 180 damage, miss preserves buff passed');
const trial=await load('scripts/data/jobTrials.js');
const trials=await load('scripts/core/jobTrials.js',{JOB_TRIALS:trial.JOB_TRIALS,getProgress:p=>p.progress,VANILLA_HOSTILES:new Set()});
for(const [id,progress] of [['nen',{nen_solo:1}],['the_world',{job_boss:3,job_night:60}]]){
 const p={progress,getDynamicProperty:()=>40};assert.equal(trials.jobTrialStatus(p,{id}).met,true);p.getDynamicProperty=()=>39;assert.equal(trials.jobTrialStatus(p,{id}).met,false);
 p.getDynamicProperty=()=>40;p.progress={};assert.equal(trials.jobTrialStatus(p,{id}).met,false);
}
console.log('Advancement trial progress: level thresholds / missing requirements passed');
const spawn=await load('scripts/core/spawnPlaza.js');
function builder(blocked=false,failNPC=false){
 const blocks=new Map(),entities=[],messages=[];let writes=0;
 const dim={id:'overworld',getEntities:()=>[],getBlock:at=>{const key=JSON.stringify(at);return {isAir:!(blocked&&at.x===0&&at.y===64&&at.z===20)&&(!blocks.has(key)||blocks.get(key)==='minecraft:air'),setType:t=>{writes++;blocks.set(key,t);}}},spawnEntity:(type,at)=>{if(failNPC)throw Error('NPC failure');const e={type,at,remove:()=>{e.removed=true}};entities.push(e);return e;}};
 return {p:{dimension:dim,location:{x:0,y:64,z:0},sendMessage:s=>messages.push(s)},blocks,entities,messages,get writes(){return writes;}};
}
{const b=builder();assert.equal(spawn.createSpawnPlaza(b.p),true);assert.equal(b.entities.length,8);assert.equal(b.blocks.get(JSON.stringify({x:0,y:64,z:20})),'minecraft:gold_block');assert.equal(spawn.createSpawnPlaza(b.p),false);assert.equal(b.entities.length,8);}
{const b=builder(true);assert.equal(spawn.createSpawnPlaza(b.p),false);assert.equal(b.writes,0);}
{const b=builder(false,true);assert.equal(spawn.createSpawnPlaza(b.p),false);assert.ok([...b.blocks.values()].every(t=>t==='minecraft:air'));}
console.log('Spawn: successful build, repeat refusal, obstructed volume no writes, failure rollback passed');
const advance=await load('scripts/core/advance.js',{JOB_TRIALS:trial.JOB_TRIALS,JOBS:jobs.JOBS,SKILLS:skills.SKILLS,ALL_WEAPON_IDS:[],ALL_EQUIPMENT_IDS:[],getJobId:p=>p.job,getProgress:p=>p.progress,jobTrialStatus:trials.jobTrialStatus});
for(const job of ['fighter','cleric','mage']){
 const p={job,progress:{nen_solo:1},getDynamicProperty:()=>40};assert.equal(advance.checkAdvance(p,jobs.JOBS.nen).ok,true);
}
assert.equal(advance.checkAdvance({job:'swordsman',progress:{nen_solo:1},getDynamicProperty:()=>40},jobs.JOBS.nen).ok,false);
assert.equal(advance.checkAdvance({job:'apprentice',progress:{job_boss:3,job_night:60},getDynamicProperty:()=>40},jobs.JOBS.the_world).ok,false);
assert.equal(advance.checkAdvance({job:'fighter',progress:{job_boss:3,job_night:60},getDynamicProperty:()=>40},jobs.JOBS.the_world).ok,true);
console.log('Advancement: allowed origins and normal transfer gate passed');
