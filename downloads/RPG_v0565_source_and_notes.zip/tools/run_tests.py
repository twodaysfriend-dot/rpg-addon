"""Run each Bedrock-mocked scenario suite in its own Node process."""
from pathlib import Path
import re
import subprocess
import sys
root=Path(__file__).resolve().parents[1]
total=0
for path in sorted((root/'tests').glob('*.test.mjs')):
    result=subprocess.run(['node','--experimental-loader','./tests/loader.mjs',str(path)],cwd=root,text=True,capture_output=True)
    if result.returncode:
        print(result.stdout);print(result.stderr,file=sys.stderr);sys.exit(result.returncode)
    match=re.search(r'\btests (\d+)',result.stdout)
    if not match:
        print(result.stdout);raise RuntimeError('Missing test summary: '+str(path))
    count=int(match.group(1));total+=count;print(path.name+': '+str(count)+' passed')
result=subprocess.run([sys.executable,'tests/validate_loot_and_recipes.py'],cwd=root)
if result.returncode:sys.exit(result.returncode)
print(f'Passed {total} JavaScript scenarios + 5 Python validation tests.')
