import {world} from '@minecraft/server';
import {CONFIG} from '../config.js';
let registered=false;
export function applyPeaceRules(){
 if(CONFIG.pvp===false&&world.gameRules){world.gameRules.pvp=false;world.gameRules.doInsomnia=false;}
}
export function registerPeaceServer(){
 if(registered)return;registered=true;
 try{applyPeaceRules();}catch(error){console.warn('[RPG peace rules] '+String(error));}
 world.afterEvents.worldLoad?.subscribe(()=>{try{applyPeaceRules();}catch{}});
}
