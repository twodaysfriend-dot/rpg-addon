import {applyCommonWeaponBonus} from './commonWeaponDamage.js';
import {world,system} from '@minecraft/server';
import {replaceBloodSpearHit} from '../skills/blood.js';
import {currentScriptHit} from './combatContext.js';
import {readRuneBag} from './runeInventory.js';
import {RUNES} from '../data/equipment.js';
import {upgradedRune} from '../data/upgrades.js';
import {areAllies} from './social.js';
import {CONFIG} from '../config.js';
import {markDamageReported,setUnreportedDamageHandler,handleBasicHit} from './combatContext.js';
const temporary=new Map();
export function grantSkillLifesteal(p,rate,ticks){temporary.set(p.id,{rate,until:system.currentTick+ticks});}
export function skillLifestealRate(p){const s=temporary.get(p.id);if(!s)return 0;if(s.until<=system.currentTick){temporary.delete(p.id);return 0;}return s.rate;}
export function runeLifestealRate(p){
 const b=readRuneBag(p);for(const uid of b.equipped){const r=b.runes.find(r=>r.uid===uid);if(r?.id==='absorption')return upgradedRune(RUNES.absorption,r.level,r.grade).lifesteal;}return 0;
}
export function healLifesteal(source,target,damage){
 if(source?.typeId!=='minecraft:player'||!target||source.id===target.id||areAllies(source,target)||(!CONFIG.pvp&&target.typeId==='minecraft:player')||['rpg:gpt_guide','minecraft:armor_stand','rpg:sandbag_entity','minecraft:item','minecraft:xp_orb'].includes(target.typeId))return 0;
 if(target.typeId.startsWith('rpg:hito_'))return 0;
 if(!Number.isFinite(damage)||damage<=0)return 0;
 const h=source.getComponent('minecraft:health'),rate=Math.max(runeLifestealRate(source),skillLifestealRate(source));if(!h||h.currentValue<=0||rate<=0)return 0;
 const before=h.currentValue,after=Math.min(h.effectiveMax,before+damage*rate);if(after>before)h.setCurrentValue(after);return after-before;
}
let registered=false;
export function registerLifesteal(){
 if(registered)return;registered=true;world.afterEvents.playerLeave.subscribe(ev=>temporary.delete(ev.playerId));world.afterEvents.entityDie.subscribe(ev=>temporary.delete(ev.deadEntity?.id));setUnreportedDamageHandler(healLifesteal);
 world.afterEvents.entityHurt.subscribe(ev=>{try{if(!currentScriptHit(ev.damageSource?.damagingEntity,ev.hurtEntity)&&replaceBloodSpearHit(ev))return;let source=ev.damageSource?.damagingEntity;if(source?.typeId!=='minecraft:player')source=ev.damageSource?.damagingProjectile?.getComponent('minecraft:projectile')?.owner;const h=markDamageReported(source,ev.hurtEntity);const amount=h&&Number.isFinite(h.before)?Math.min(h.before,ev.damage):ev.damage;const damage=applyCommonWeaponBonus(ev,Boolean(h));healLifesteal(source,ev.hurtEntity,amount);handleBasicHit({...ev,damage},Boolean(h));}catch{}});
}
