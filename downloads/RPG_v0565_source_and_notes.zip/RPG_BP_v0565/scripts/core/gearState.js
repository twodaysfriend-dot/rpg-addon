import {EquipmentSlot} from '@minecraft/server';
import {itemRarity,rarityBadge} from '../data/rarity.js';
import {ARMOR_LEVEL_KEY,WEAPON_LEVEL_KEY,upgradeLevel} from '../data/upgrades.js';
import {decorateRarity} from './rarityLabels.js';
export const armorSlots=()=>[EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet];
export function readGear(p,ref){
 if(ref?.kind==='equipment'&&armorSlots().includes(ref.slot))return p.getComponent('minecraft:equippable')?.getEquipment(ref.slot);
 const inv=p.getComponent('minecraft:inventory')?.container;
 if(ref?.kind==='inventory'&&Number.isInteger(ref.slot)&&ref.slot>=0&&ref.slot<(inv?.size??0))return inv.getItem(ref.slot);
}
export function writeGear(p,ref,item){
 if(ref.kind==='equipment'){if(!p.getComponent('minecraft:equippable')?.setEquipment(ref.slot,item))throw Error('착용 장비 저장 실패');}
 else p.getComponent('minecraft:inventory').container.setItem(ref.slot,item);
}
export function gearFingerprint(item){
 if(!item)return '';
 let durability,enchantments,props;
 try{durability=item.getComponent?.('minecraft:durability')?.damage;enchantments=item.getComponent?.('minecraft:enchantable')?.getEnchantments().map(e=>[e.type.id,e.level]).sort();}catch{}
 const keys=item.getDynamicPropertyIds?.()??(item.props instanceof Map?[...item.props.keys()]:['rpg:rarity','rpg:armor_upgrade','rpg:weapon_upgrade']);
 props=keys.sort().map(k=>[k,item.getDynamicProperty(k)]);
 return JSON.stringify([item.typeId,item.amount,item.nameTag??'',item.getLore(),props,durability,enchantments]);
}
export function setGearLevel(item,kind,level){
 const next=item.clone();next.setDynamicProperty(kind==='armor'?ARMOR_LEVEL_KEY:WEAPON_LEVEL_KEY,level);
 const lore=next.getLore().filter(s=>!s.startsWith('§7강화:'));
 if(level>0)lore.push(`§7강화: +${level} · ${kind==='armor'?'최대 HP':'근접 피해'} +${level}`);
 next.setLore(lore);decorateRarity(next);return next;
}
export function physicalGearOptions(p){
 const out=[];for(const slot of armorSlots()){const ref={kind:'equipment',slot},item=readGear(p,ref);if(itemRarity(item))out.push({ref,item});}
 const inv=p.getComponent('minecraft:inventory')?.container;
 if(inv)for(let slot=0;slot<inv.size;slot++){const item=inv.getItem(slot),info=itemRarity(item);if(info&&info.kind!=='rune')out.push({ref:{kind:'inventory',slot},item});}
 return out;
}
export function gearLabel(item){const info=itemRarity(item);return info?`${rarityBadge(info.rank)} ${info.name} +${upgradeLevel(item,info.kind)}`:'';}
