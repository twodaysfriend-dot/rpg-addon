import {applyStatus,ccScale} from './crowdControl.js';
import {scriptedHit,noteManualDamage,rememberScriptKiller} from './combatContext.js';
import { EntityDamageCause, EquipmentSlot } from "@minecraft/server";
import { hasPiercing } from "./piercing.js";
import { CONFIG } from "../config.js";
import { areAllies } from "./social.js";
import { skillDamageFor, defaultDamageTypeFor } from "./stats.js";

// 아이템/경험치 구슬 같은 것은 대상에서 제외합니다.
const EXCLUDE_TYPES = ["rpg:gpt_guide","minecraft:item", "minecraft:xp_orb", "minecraft:armor_stand", "rpg:moon_chakram_projectile", "rpg:moon_weapon_chakram", "rpg:tech_prison_dome"];

export function healthAlive(entity) {
  try {
    const hp = entity.getComponent("minecraft:health");
    return !!hp && hp.currentValue > 0;
  } catch {
    return false;
  }
}

// center 주변 radius 블록 안의 공격 가능한 엔티티 목록.
// 엔티티 위치는 발밑 기준이라, 눈높이로 날아가는 투사체처럼 center 가 몸 높이일 때는
// bodyOffset(보통 0.9)을 줘서 몸 중심 기준으로 거리를 잽니다.
export function getTargets(source, center, radius, bodyOffset = 0) {
  const out = [];
  let list = [];
  try {
    list = source.dimension.getEntities({
      location: { x: center.x, y: center.y - bodyOffset, z: center.z },
      maxDistance: radius,
      excludeTypes: EXCLUDE_TYPES,
    });
  } catch {
    return out;
  }
  for (const e of list) {
    try {
      if (e.typeId === "rpg:gpt_guide" || e.id === source.id || areAllies(source, e)) continue;
      if (!CONFIG.pvp && e.typeId === "minecraft:player") continue;
      if (!healthAlive(e)) continue;
      out.push(e);
    } catch {
      // 사라진 엔티티는 무시
    }
  }
  return out;
}

export function hurt(target,source,amount,type="auto",options){return scriptedHit(target,source,()=>hurtCore(target,source,amount,type,options));}
function hurtCore(target, source, amount, type = "auto", options) {
  if (target?.typeId==="rpg:gpt_guide"||areAllies(source, target)) return false;
  if (!CONFIG.pvp && target?.typeId === "minecraft:player") return false;
  const finalDamage=skillDamageFor(source, amount, type === "auto" ? defaultDamageTypeFor(source) : type, options);
  if(hasPiercing(source)||options?.ignoreInvulnerability){
    // override is used for 3 seconds only. Fallback handles damage immunity
    // when an engine still rejects repeated hits via applyDamage.
    try{
      if(target.applyDamage(finalDamage,{cause:EntityDamageCause.override,damagingEntity:source})) return true;
    }catch{}
    try{
      const hp=target.getComponent("minecraft:health");
      if(hp && hp.currentValue>0){
        const before=hp.currentValue;if(finalDamage>=before)rememberScriptKiller(source,target);hp.setCurrentValue(Math.max(0,before-finalDamage));noteManualDamage(source,target,Math.min(before,finalDamage));
        return true;
      }
    }catch{}
    return false;
  }
  try {
    return target.applyDamage(finalDamage,{
      cause: EntityDamageCause.entityAttack,
      damagingEntity: source,
    }) !== false;
  } catch {
    return false;
  }
}

// 버전에 따라 applyKnockback 인자 형태가 달라서 두 가지를 모두 시도합니다.
export function knockback(entity, dirX, dirZ, strength, vertical = 0.35) {
  strength*=ccScale(entity);vertical*=ccScale(entity);
  const len = Math.hypot(dirX, dirZ) || 1;
  const x = dirX / len;
  const z = dirZ / len;
  try {
    entity.applyKnockback({ x: x * strength, z: z * strength }, vertical);
    return;
  } catch {
    // 구버전 형태로 재시도
  }
  try {
    entity.applyKnockback(x, z, strength, vertical);
  } catch {
    // 밀 수 없는 대상
  }
}

// 엔티티에 불 붙이기. 블록/바닥에는 불이 붙지 않습니다.
export function burn(entity, seconds) {
  if (!CONFIG.igniteEntities) return;
  try {
    entity.setOnFire(seconds, true);
  } catch {
    // 불 붙일 수 없는 대상
  }
}

export function slow(entity, amplifier, ticks) {
  try {
    applyStatus(entity,"slowness", ticks, { amplifier, showParticles: true });
  } catch {
    // 효과를 받을 수 없는 대상
  }
}

export function push(entity, x, y, z) {
  const scale=ccScale(entity);x*=scale;y*=scale;z*=scale;
  try {
    entity.applyImpulse({ x, y, z });
  } catch {
    // 플레이어 등 impulse 불가 대상
  }
}

export function particle(dimension, id, pos) {
  try {
    dimension.spawnParticle(id, pos);
  } catch {
    // 없는 파티클 id 등은 무시
  }
}

export function sound(dimension, id, pos, options = { volume: 1, pitch: 1 }) {
  try {
    dimension.playSound(id, pos, options);
  } catch {
    // 없는 사운드 id 등은 무시
  }
}

// 시선의 수평 방향 (위/아래를 봐도 앞쪽으로 나가도록)
export function flatDir(player) {
  const v = player.getViewDirection();
  const len = Math.hypot(v.x, v.z);
  if (len < 0.001) {
    const yaw = (player.getRotation().y * Math.PI) / 180;
    return { x: -Math.sin(yaw), z: Math.cos(yaw) };
  }
  return { x: v.x / len, z: v.z / len };
}

export function isSolidAt(dimension, pos) {
  try {
    const b = dimension.getBlock(pos);
    if (!b) return true;
    const solid = typeof b.isSolid === "function" ? b.isSolid() : b.isSolid;
    return !!solid;
  } catch {
    return true;
  }
}

export function dist3(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
}

export function norm3(v) {
  const l = Math.hypot(v.x, v.y, v.z) || 1;
  return { x: v.x / l, y: v.y / l, z: v.z / l };
}

export function headPos(player) {
  try {
    return player.getHeadLocation();
  } catch {
    const l = player.location;
    return { x: l.x, y: l.y + 1.6, z: l.z };
  }
}

// 시선 끝 지점 (벽/바닥에 닿으면 그 직전). hit 는 무언가에 닿았는지.
export function aimPoint(player, maxDist, step = 0.5) {
  const dim = player.dimension;
  const d = player.getViewDirection();
  const h = headPos(player);
  let last = { ...h };
  for (let t = step; t <= maxDist; t += step) {
    const p = { x: h.x + d.x * t, y: h.y + d.y * t, z: h.z + d.z * t };
    if (isSolidAt(dim, p)) return { point: last, hit: true };
    last = p;
  }
  return { point: last, hit: false };
}

// 시선 앞에서 가장 먼저 만나는 대상
export function firstTargetInView(player, maxDist) {
  const dim = player.dimension;
  const d = player.getViewDirection();
  const h = headPos(player);
  for (let t = 1; t <= maxDist; t += 1) {
    const p = { x: h.x + d.x * t, y: h.y + d.y * t, z: h.z + d.z * t };
    if (isSolidAt(dim, p)) return undefined;
    const list = getTargets(player, p, 2.2, 0.9);
    if (list.length > 0) {
      list.sort((a, b) => dist3(a.location, h) - dist3(b.location, h));
      return list[0];
    }
  }
  return undefined;
}

// 현재 주 손에 든 아이템의 typeId
export function heldItemId(player) {
  try {
    const eq = player.getComponent("minecraft:equippable");
    const item = eq?.getEquipment(EquipmentSlot.Mainhand ?? "Mainhand");
    return item?.typeId;
  } catch {
    return undefined;
  }
}
