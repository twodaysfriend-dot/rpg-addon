import { ItemStack,world } from '@minecraft/server';
import { SKILLS } from '../data/skills.js';
import { JOBS,APPRENTICE_SKILLS } from '../data/jobs.js';
import { getJobId,getSkills,setSkills,getDisabled,setDisabled,getIndex,setIndex } from './playerData.js';
import { unspentPoints } from './stats.js';
export const CHAMELEON_KEY='rpg:chameleon_progress_v1';
export const SKILLBOOK_ID='rpg:random_skillbook';
const ALLOWED=new Set(Object.values(JOBS).filter(j=>!j.placeholder&&j.id!=='chameleon').flatMap(j=>j.skills));
for(const skills of Object.values(APPRENTICE_SKILLS))for(const id of skills)if(SKILLS[id])ALLOWED.add(id);
export const CHAMELEON_ALLOWED=[...ALLOWED];
const LEGACY_ULTS=new Set(['sword_rush','fist_finale','archer_heavenly','fallen_end','sage_zoltraak','beast_grand_explosion']);
export function isUltimate(id){return !!SKILLS[id]&&(SKILLS[id].ultimate===true||SKILLS[id].name.includes('궁극기')||LEGACY_ULTS.has(id));}
export const IMPORTANT_SKILLS=new Set(['sword_annihilation','hacker_reboot','hacker_hack','holy_shield','holy_sword','holy_orb','demon_contract','demon_vampirism','blood_awaken','sun_divine_blessing','dragon_sprint','assassin_pierce','assassin_stealth','fallen_sword_frenzy','beast_berserk','mage_gravity','sage_zero','war_god_flurry','war_god_kick_flurry']);
export function learningRule(id){
  if(isUltimate(id)||id==='hacker_copy')return {cost:15,uses:3,diamondUses:1};
  if(IMPORTANT_SKILLS.has(id))return {cost:9,uses:10,diamondUses:5};
  return {cost:3,uses:null,diamondUses:0};
}
export function readChameleonProgress(p){
  const raw=p.getDynamicProperty(CHAMELEON_KEY);
  if(raw===undefined)return {version:1,spentSp:0,refundedSp:0,learned:[],charges:{},levelsToBook:0,pendingBooks:0};
  const state=JSON.parse(raw);
  state.refundedSp??=0;
  if(state?.version!==1||!Number.isSafeInteger(state.spentSp)||state.spentSp<0||!Array.isArray(state.learned)||!state.charges||!Number.isInteger(state.levelsToBook)||state.levelsToBook<0||state.levelsToBook>4||!Number.isSafeInteger(state.pendingBooks)||state.pendingBooks<0)throw Error('카멜레온 성장 데이터 오류');
  for(const n of Object.values(state.charges))if(!Number.isSafeInteger(n)||n<0)throw Error('스킬 사용 횟수 데이터 오류');
  if(!Number.isSafeInteger(state.refundedSp)||state.refundedSp<0)throw Error('분해 SP 데이터 오류');
  return state;
}
export function saveChameleonProgress(p,state){p.setDynamicProperty(CHAMELEON_KEY,JSON.stringify(state));}
export function learningSpent(p){const state=readChameleonProgress(p);return state.spentSp-state.refundedSp;}
export function syncChameleonLoadout(p){
  if(getJobId(p)!=='chameleon')return;
  const state=readChameleonProgress(p),known=[...new Set([...state.learned,...getSkills(p).filter(id=>ALLOWED.has(id))])];
  if(JSON.stringify(known)!==JSON.stringify(state.learned)){state.learned=known;saveChameleonProgress(p,state);}
  const skills=[...new Set([...JOBS.chameleon.skills,...known])];
  if(JSON.stringify(skills)!==JSON.stringify(getSkills(p)))setSkills(p,skills);
}
export function remainingSkillUses(p,id){const rule=learningRule(id);if(rule.uses===null)return null;return readChameleonProgress(p).charges[id]??rule.uses;}
function learn(p,id,free){
  if(getJobId(p)!=='chameleon'||!ALLOWED.has(id))return {ok:false,message:'카멜레온이 배울 수 없는 스킬입니다.'};
  syncChameleonLoadout(p);if(getSkills(p).includes(id))return {ok:false,message:'이미 배운 스킬입니다.'};
  const state=readChameleonProgress(p),rule=learningRule(id);
  if(!free&&unspentPoints(p)<rule.cost)return {ok:false,message:`레벨업 SP ${rule.cost}가 필요합니다. 남은 SP ${unspentPoints(p)}`};
  const old=p.getDynamicProperty(CHAMELEON_KEY),skills=getSkills(p);
  if(!free){if(!Number.isSafeInteger(state.spentSp+rule.cost))return {ok:false,message:'SP 저장 범위를 초과했습니다.'};state.spentSp+=rule.cost;}
  state.learned.push(id);if(rule.uses!==null&&state.charges[id]===undefined)state.charges[id]=rule.uses;
  try{saveChameleonProgress(p,state);setSkills(p,[...skills,id]);}
  catch(error){p.setDynamicProperty(CHAMELEON_KEY,old);setSkills(p,skills);return {ok:false,message:'스킬 저장 실패: '+String(error)};}
  return {ok:true,id,message:`§a${SKILLS[id].name} 습득! ${free?'스킬북 사용':rule.cost+' SP 소비'}${rule.uses===null?' · 횟수 제한 없음':' · '+state.charges[id]+'회 사용 가능'}`};
}
export function purchaseChameleonSkill(p,id){return learn(p,id,false);}
export function dismantleChameleonSkill(p,id){
  try{
    if(getJobId(p)!=='chameleon'||!ALLOWED.has(id))return {ok:false,message:'분해 가능한 카멜레온 차용 기술이 아닙니다.'};
    syncChameleonLoadout(p);const state=readChameleonProgress(p),skills=getSkills(p);
    if(!state.learned.includes(id)||!skills.includes(id))return {ok:false,message:'이미 분해했거나 배우지 않은 기술입니다.'};
    const refund=learningRule(id).cost;if(!Number.isSafeInteger(state.refundedSp+refund))return {ok:false,message:'SP 저장 범위를 초과했습니다.'};
    const before=p.getDynamicProperty(CHAMELEON_KEY),disabled=getDisabled(p),index=getIndex(p);
    state.learned=state.learned.filter(s=>s!==id);state.refundedSp+=refund;
    // Retain charges and cooldowns so relearning cannot refill limited skills.
    try{saveChameleonProgress(p,state);setSkills(p,skills.filter(s=>s!==id));setDisabled(p,disabled.filter(s=>s!==id));setIndex(p,0);}
    catch(error){p.setDynamicProperty(CHAMELEON_KEY,before);setSkills(p,skills);setDisabled(p,disabled);setIndex(p,index);throw error;}
    return {ok:true,refund,message:`${SKILLS[id].name} 분해 · ${refund} SP 환급. 스킬북 기술도 같은 등급의 SP를 받습니다.`};
  }catch(error){return {ok:false,message:'분해 실패: '+String(error)};}
}
export function executeChameleonSkill(p,id,runner){
  if(getJobId(p)!=='chameleon'||!ALLOWED.has(id))return {ok:true,result:runner()};
  const rule=learningRule(id);if(rule.uses===null)return {ok:true,result:runner()};
  const state=readChameleonProgress(p),left=state.charges[id]??rule.uses;
  if(left<=0)return {ok:false,message:'사용 횟수가 없습니다. /rpg:skillbook 에서 다이아몬드로 충전하세요.'};
  const before=p.getDynamicProperty(CHAMELEON_KEY);state.charges[id]=left-1;saveChameleonProgress(p,state);
  try{const result=runner();if(result===false)p.setDynamicProperty(CHAMELEON_KEY,before);return {ok:true,result};}
  catch(error){p.setDynamicProperty(CHAMELEON_KEY,before);return {ok:false,message:'스킬 발동 오류: '+String(error)};}
}
export function rechargeSkill(p,id,diamonds=1){
  try{
    if(getJobId(p)!=='chameleon'||!getSkills(p).includes(id)||learningRule(id).uses===null)return {ok:false,message:'충전 가능한 카멜레온 스킬이 아닙니다.'};
    if(!Number.isInteger(diamonds)||diamonds<1||diamonds>64)return {ok:false,message:'다이아 수량은 1~64개입니다.'};
    const inv=p.getComponent('minecraft:inventory')?.container,entries=[];let need=diamonds;
    if(inv)for(let i=0;i<inv.size&&need>0;i++){const t=inv.getItem(i);if(t?.typeId==='minecraft:diamond'){const take=Math.min(t.amount,need);entries.push({slot:i,old:t.clone(),take});need-=take;}}
    if(need>0)return {ok:false,message:'다이아몬드가 부족합니다.'};
    const state=readChameleonProgress(p),before=p.getDynamicProperty(CHAMELEON_KEY),rule=learningRule(id);
    const count=(state.charges[id]??rule.uses)+rule.diamondUses*diamonds;if(!Number.isSafeInteger(count))return {ok:false,message:'저장 범위를 초과했습니다.'};
    state.charges[id]=count;
    try{for(const e of entries){if(e.old.amount===e.take)inv.setItem(e.slot,undefined);else{const t=e.old.clone();t.amount-=e.take;inv.setItem(e.slot,t);}}saveChameleonProgress(p,state);}
    catch(error){for(const e of entries)inv.setItem(e.slot,e.old);p.setDynamicProperty(CHAMELEON_KEY,before);throw error;}
    return {ok:true,message:`다이아 ${diamonds}개 사용 · ${SKILLS[id].name} 남은 횟수 ${count}`};
  }catch(error){return {ok:false,message:String(error)};}
}
export function deliverSkillBooks(p){
  const state=readChameleonProgress(p);if(state.pendingBooks<=0)return 0;
  const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return 0;
  const before=p.getDynamicProperty(CHAMELEON_KEY),changed=[];let remaining=state.pendingBooks;
  try{
    for(let i=0;i<inv.size&&remaining>0;i++){
      const token=inv.getItem(i);if(token&&token.typeId!==SKILLBOOK_ID)continue;
      const room=64-(token?.amount??0);if(room<=0)continue;
      changed.push({slot:i,old:token?.clone()});const take=Math.min(room,remaining);
      const next=token?.clone()??new ItemStack(SKILLBOOK_ID,1);next.amount=(token?.amount??0)+take;inv.setItem(i,next);remaining-=take;
    }
    const delivered=state.pendingBooks-remaining;state.pendingBooks=remaining;saveChameleonProgress(p,state);return delivered;
  }catch(error){for(const e of changed)inv.setItem(e.slot,e.old);p.setDynamicProperty(CHAMELEON_KEY,before);throw error;}
}
export function awardChameleonLevels(p,levels){
  if(getJobId(p)!=='chameleon'||!Number.isSafeInteger(levels)||levels<=0)return;
  const state=readChameleonProgress(p),total=state.levelsToBook+levels;
  state.pendingBooks+=Math.floor(total/5);state.levelsToBook=total%5;saveChameleonProgress(p,state);
  const delivered=deliverSkillBooks(p);if(delivered)p.sendMessage(`§b[카멜레온] 랜덤 스킬북 ${delivered}권 획득! /rpg:skillbook`);
}
const usedAt=new Map();
world.afterEvents.playerLeave.subscribe(ev=>usedAt.delete(ev.playerId));
export function useRandomSkillBook(p,random=Math.random){
  try{
    if(getJobId(p)!=='chameleon')return {ok:false,message:'카멜레온만 랜덤 스킬북을 사용할 수 있습니다.'};
    syncChameleonLoadout(p);const pool=CHAMELEON_ALLOWED.filter(id=>!isUltimate(id)&&!getSkills(p).includes(id));
    if(!pool.length)return {ok:false,message:'배울 수 있는 일반 스킬을 모두 배웠습니다. 책은 소비하지 않습니다.'};
    const inv=p.getComponent('minecraft:inventory')?.container;let slot=-1;
    if(inv)for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId===SKILLBOOK_ID){slot=i;break;}
    if(slot<0)return {ok:false,message:'가방에 랜덤 스킬북이 없습니다.'};
    const roll=random();if(!Number.isFinite(roll)||roll<0||roll>=1)throw Error('스킬북 난수 오류');
    const token=inv.getItem(slot).clone(),before=p.getDynamicProperty(CHAMELEON_KEY),skills=getSkills(p);
    const result=learn(p,pool[Math.floor(roll*pool.length)],true);if(!result.ok)return result;
    try{if(token.amount===1)inv.setItem(slot,undefined);else{const t=token.clone();t.amount--;inv.setItem(slot,t);}}
    catch(error){p.setDynamicProperty(CHAMELEON_KEY,before);setSkills(p,skills);inv.setItem(slot,token);throw error;}
    return result;
  }catch(error){return {ok:false,message:String(error)};}
}
export function skillBookItemUse(p,tick){if(usedAt.get(p.id)===tick)return;usedAt.set(p.id,tick);const result=useRandomSkillBook(p);p.sendMessage((result.ok?'§a':'§c')+result.message);}
