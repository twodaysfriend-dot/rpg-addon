import {EquipmentSlot,EntityDamageCause} from '@minecraft/server';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {GRADE_MULTIPLIERS,itemGrade} from '../data/grades.js';
import {upgradeLevel} from '../data/upgrades.js';
import {currentScriptHit,scriptedHit,rememberScriptKiller,noteManualDamage} from './combatContext.js';
import {areAllies} from './social.js';
import {CONFIG} from '../config.js';
export function commonWeaponFactor(item){
 const w=COMMON_WEAPONS.find(w=>w.id===item?.typeId);if(!w)return 1;
 // minecraft:damage adds to the player's one point native unarmed damage.
 return (1+w.damage*GRADE_MULTIPLIERS[itemGrade(item)]+upgradeLevel(item,'weapon'))/(1+w.damage);
}
export function applyCommonWeaponBonus(ev,scripted=false){
 const p=ev.damageSource?.damagingEntity,t=ev.hurtEntity;
 if(scripted||p?.typeId!=='minecraft:player'||!t||p.id===t.id||ev.damageSource?.cause!==EntityDamageCause.entityAttack||currentScriptHit(p,t)||!(ev.damage>0)||areAllies(p,t))return ev.damage;
 if(['rpg:gpt_guide','minecraft:armor_stand','minecraft:item','minecraft:xp_orb'].includes(t.typeId)||t.typeId.startsWith('rpg:hito_'))return ev.damage;
 if(t.typeId==='minecraft:player'&&(!CONFIG.pvp||['creative','spectator'].includes(String(t.getGameMode?.()).toLowerCase())))return ev.damage;
 const item=p.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand),factor=commonWeaponFactor(item);
 if(factor<=1)return ev.damage;
 const hp=t.getComponent('minecraft:health');if(!(hp?.currentValue>0))return ev.damage;
 // Add the same-hit proportional bonus AFTER native mitigation, without a second
 // armor pass or a second hit lost to invulnerability. Enchants/critical/Strength
 // inherit that hit's effective scaling. This is only a basic melee hit hook.
 const bonus=ev.damage*(factor-1),before=hp.currentValue,actual=Math.min(before,bonus);
 if(actual>=before)rememberScriptKiller(p,t);
 scriptedHit(t,p,()=>{hp.setCurrentValue(Math.max(0,before-actual));noteManualDamage(p,t,actual,{incomingScaled:true});return true;});
 return ev.damage+bonus;
}
