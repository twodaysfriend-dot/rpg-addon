import { ItemStack, EquipmentSlot } from '@minecraft/server';
import { RUNES, RUNE_KEY } from '../data/equipment.js';
import {itemGrade} from '../data/grades.js';
import { RUNE_LEVEL_KEY, upgradeLevel } from '../data/upgrades.js';

export const RUNE_BAG_KEY='rpg:rune_bag_v1';
export const RUNE_CAPACITY=30;
export const RUNE_SLOTS=3;
export function readRuneBag(p){
  const raw=p.getDynamicProperty(RUNE_BAG_KEY);
  if(raw===undefined)return {version:2,nextId:1,runes:[],equipped:[null,null,null]};
  const bag=JSON.parse(raw);
  if(![1,2].includes(bag?.version)||!Number.isSafeInteger(bag.nextId)||bag.nextId<1||!Array.isArray(bag.runes)||bag.runes.length>RUNE_CAPACITY||!Array.isArray(bag.equipped)||bag.equipped.length!==3)throw Error('룬 보관함 데이터 오류');
  const ids=new Set();
  for(const r of bag.runes){if(r.id==='haste')r.id='mana';if(typeof r.uid!=='string'||ids.has(r.uid)||!RUNES[r.id]||!Number.isInteger(r.level)||r.level<0||r.level>(bag.version===1?5:10))throw Error('룬 데이터 오류');if(bag.version===1){r.level*=2;r.grade=0;}if(!Number.isInteger(r.grade)||r.grade<0||r.grade>6)throw Error('룬 등급 오류');ids.add(r.uid);}
  if(bag.equipped.some(uid=>uid!==null&&!ids.has(uid)))throw Error('룬 장착 데이터 오류');
  const kinds=new Set();bag.equipped=bag.equipped.map(uid=>{if(uid===null)return null;const rune=bag.runes.find(r=>r.uid===uid);if(kinds.has(rune.id))return null;kinds.add(rune.id);return uid;});
  bag.version=2;return bag;
}
export function writeRuneBag(p,bag){p.setDynamicProperty(RUNE_BAG_KEY,JSON.stringify(bag));}
export function migrateRetiredRunes(p){
  const old=p.getDynamicProperty(RUNE_BAG_KEY),inv=p.getComponent('minecraft:inventory')?.container,changed=[];
  try{
    const bag=readRuneBag(p);
    if(inv)for(let i=0;i<inv.size;i++){const token=inv.getItem(i);if(token?.typeId==='rpg:rune_haste'){changed.push({slot:i,old:token.clone()});inv.setItem(i,new ItemStack('rpg:rune_mana',token.amount));}}
    if(old!==undefined&&JSON.stringify(bag)!==old)writeRuneBag(p,bag);
    return {ok:true,converted:changed.length};
  }catch(error){for(const e of changed)inv.setItem(e.slot,e.old);p.setDynamicProperty(RUNE_BAG_KEY,old);return {ok:false,reason:String(error)};}
}
export function equippedRunes(p){
  const bag=readRuneBag(p),seen=new Set(),result=[];
  for(const uid of bag.equipped){const rune=bag.runes.find(r=>r.uid===uid);if(rune&&!seen.has(rune.id)){seen.add(rune.id);result.push(rune);}}
  return result;
}
export function addRuneRecord(bag,id,level=0,grade=0){
  if(!RUNES[id]||bag.runes.length>=RUNE_CAPACITY)throw Error('룬 보관함이 가득 찼거나 잘못된 룬입니다.');
  if(!Number.isInteger(level)||level<0||level>10||!Number.isInteger(grade)||grade<0||grade>6)throw Error('룬 강화·등급 오류');
  const rune={uid:'r'+bag.nextId++,id,level,grade};bag.runes.push(rune);return rune;
}
export function depositRune(p,slot){
  try{
    const bag=readRuneBag(p),original=JSON.stringify(bag),inventory=p.getComponent('minecraft:inventory')?.container;
    const token=inventory?.getItem(slot),id=token?.typeId?.replace('rpg:rune_','');
    if(!token||token.typeId!=='rpg:rune_'+id||!RUNES[id])return {ok:false,reason:'선택한 칸에 룬이 없습니다.'};
    const previous=token.clone();const rune=addRuneRecord(bag,id,upgradeLevel(token,'rune'),itemGrade(token));
    try{
      if(token.amount===1)inventory.setItem(slot,undefined);else{token.amount--;inventory.setItem(slot,token);}
      writeRuneBag(p,bag);
    }catch(error){inventory.setItem(slot,previous);p.setDynamicProperty(RUNE_BAG_KEY,original);throw error;}
    return {ok:true,rune};
  }catch(error){return {ok:false,reason:String(error)};}
}
export function equipRune(p,uid,slot){
  try{
    if(!Number.isInteger(slot)||slot<0||slot>=RUNE_SLOTS)return {ok:false,reason:'장착 칸은 1~3입니다.'};
    const bag=readRuneBag(p),rune=bag.runes.find(r=>r.uid===uid);
    if(!rune)return {ok:false,reason:'보관함에 해당 룬이 없습니다.'};
    for(let i=0;i<3;i++)if(i!==slot){const other=bag.runes.find(r=>r.uid===bag.equipped[i]);if(other?.id===rune.id)return {ok:false,reason:'같은 종류의 룬은 하나만 장착할 수 있습니다.'};}
    bag.equipped[slot]=uid;writeRuneBag(p,bag);return {ok:true};
  }catch(error){return {ok:false,reason:String(error)};}
}
export function unequipRune(p,uid){const bag=readRuneBag(p);bag.equipped=bag.equipped.map(id=>id===uid?null:id);writeRuneBag(p,bag);}
export function removeRune(p,uid){const bag=readRuneBag(p);if(!bag.runes.some(r=>r.uid===uid))return false;bag.runes=bag.runes.filter(r=>r.uid!==uid);bag.equipped=bag.equipped.map(id=>id===uid?null:id);writeRuneBag(p,bag);return true;}
export function withdrawRune(p,uid){
  try{
    const bag=readRuneBag(p),old=JSON.stringify(bag),rune=bag.runes.find(r=>r.uid===uid);
    if(!rune)return {ok:false,reason:'룬이 없습니다.'};
    if(rune.level>0||rune.grade>0)return {ok:false,reason:'강화하거나 승급한 룬은 전용 보관함에서만 관리합니다.'};
    const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return {ok:false,reason:'가방이 없습니다.'};
    let slot=-1;for(let i=0;i<inv.size;i++){const item=inv.getItem(i);if(!item||(item.typeId==='rpg:rune_'+rune.id&&item.amount<64&&itemGrade(item)===0&&upgradeLevel(item,'rune')===0)){slot=i;break;}}
    if(slot<0)return {ok:false,reason:'가방에 빈 공간이 없습니다.'};
    const previous=inv.getItem(slot)?.clone(),token=previous?.clone()??new ItemStack('rpg:rune_'+rune.id,1);if(previous)token.amount++;
    try{inv.setItem(slot,token);bag.runes=bag.runes.filter(r=>r.uid!==uid);bag.equipped=bag.equipped.map(id=>id===uid?null:id);writeRuneBag(p,bag);}
    catch(error){inv.setItem(slot,previous);p.setDynamicProperty(RUNE_BAG_KEY,old);throw error;}
    return {ok:true};
  }catch(error){return {ok:false,reason:String(error)};}
}
export function migrateChestRune(p){
  const eq=p.getComponent('minecraft:equippable'),chest=eq?.getEquipment(EquipmentSlot.Chest);
  const legacyId=chest?.getDynamicProperty(RUNE_KEY),id=legacyId==='haste'?'mana':legacyId;if(!RUNES[id])return {ok:true,migrated:false};
  const bag=readRuneBag(p);if(bag.runes.length>=RUNE_CAPACITY)return {ok:false,reason:'룬 이전을 위해 보관함 빈 칸이 필요합니다.'};
  const oldBag=JSON.stringify(bag),oldChest=chest.clone(),rune=addRuneRecord(bag,id,Math.min(10,upgradeLevel(chest,'rune')*2));
  const slot=bag.equipped.indexOf(null);if(slot>=0&&!equippedRunes(p).some(r=>r.id===id))bag.equipped[slot]=rune.uid;
  chest.setDynamicProperty(RUNE_KEY,undefined);chest.setDynamicProperty(RUNE_LEVEL_KEY,undefined);chest.setLore(chest.getLore().filter(line=>!line.startsWith('§8룬:')));
  try{writeRuneBag(p,bag);if(!eq.setEquipment(EquipmentSlot.Chest,chest))throw Error('기존 흉갑 저장 실패');}
  catch(error){p.setDynamicProperty(RUNE_BAG_KEY,oldBag);eq.setEquipment(EquipmentSlot.Chest,oldChest);return {ok:false,reason:String(error)};}
  return {ok:true,migrated:true};
}
