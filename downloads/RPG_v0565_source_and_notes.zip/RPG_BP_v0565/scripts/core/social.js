import { world, system } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";

// RPG 길드·파티: 길드/파티는 월드 동적 속성에 보관하여 재접속 후에도 유지.
// 초대장은 최대 2분 동안만 유효하며, 받는 사람의 수락이 있어야 가입됩니다.
const STORE = "rpg:social_v1";
const GROUP_TYPES = ["guild", "party"];
const PREFIX = { guild: "rpg_guild_", party: "rpg_party_" };
const LIMIT = { guild: 30, party: 4 };
const EXPIRES = 2400;
const invites = new Map();
const menus = new Set();
let db;

async function showForm(form, player) {
  for (let i=0; i<16; i++) {
    const res = await form.show(player);
    if (!res.canceled || String(res.cancelationReason) !== "UserBusy") return res;
    await new Promise(resolve => system.runTimeout(resolve, 10));
  }
  return undefined;
}
const nameKey = (s) => String(s ?? "").toLowerCase();
const online = () => world.getAllPlayers();
const byName = (name) => online().find(p => nameKey(p.name) === nameKey(name));
const caption = (type) => type === "guild" ? "길드" : "파티";

function state() {
  if (db) return db;
  let saved;
  try { saved = world.getDynamicProperty(STORE); } catch {}
  try {
    const parsed = typeof saved === "string" ? JSON.parse(saved) : null;
    if (parsed && Array.isArray(parsed.guilds) && Array.isArray(parsed.parties) && Number.isFinite(parsed.nextId)) {
      db = parsed;
    }
  } catch {}
  if (!db) db = { version: 1, nextId: 1, guilds: [], parties: [] };
  return db;
}
function groups(data, type) { return type === "guild" ? data.guilds : data.parties; }
function memberOf(data, type, name) {
  return groups(data, type).find(g => g.members.some(n => nameKey(n) === nameKey(name)));
}
function mutate(fn, player) {
  try {
    const next = JSON.parse(JSON.stringify(state()));
    const outcome = fn(next);
    if (outcome !== true) {
      if (typeof outcome === "string" && player) player.sendMessage(`§c${outcome}`);
      return false;
    }
    const encoded = JSON.stringify(next);
    if (encoded.length > 30000) {
      player?.sendMessage("§c길드·파티 저장 용량이 가득 찼습니다.");
      return false;
    }
    world.setDynamicProperty(STORE, encoded);
    db = next;
    syncAllTags();
    return true;
  } catch (error) {
    console.warn(`[RPG social] 저장 실패: ${error}`);
    player?.sendMessage("§c길드·파티 정보 저장에 실패했습니다.");
    return false;
  }
}
function notifyMembers(type, id, message) {
  const g = groups(state(), type).find(item => item.id === id);
  if (!g) return;
  for (const name of g.members) {
    const p = byName(name);
    try { p?.sendMessage(message); } catch {}
  }
}

function syncPlayerTags(player) {
  try {
    const data = state();
    for (const type of GROUP_TYPES) {
      const g = memberOf(data, type, player.name);
      const wanted = g ? `${PREFIX[type]}${g.id}` : null;
      for (const tag of player.getTags()) {
        if (tag.startsWith(PREFIX[type]) && tag !== wanted) player.removeTag(tag);
      }
      if (wanted && !player.hasTag(wanted)) player.addTag(wanted);
    }
  } catch {}
}
function syncAllTags() { for (const p of online()) syncPlayerTags(p); }

// 수동으로 설정된 rpg_team_* 태그도 기존처럼 아군으로 간주합니다.
export function areAllies(source, other) {
  if (!source || !other) return false;
  if (source.id === other.id) return true;
  if (source.typeId !== "minecraft:player" || other.typeId !== "minecraft:player") return false;
  try {
    return source.getTags().some(tag =>
      (tag.startsWith("rpg_guild_") || tag.startsWith("rpg_party_") || tag.startsWith("rpg_team_")) && other.hasTag(tag));
  } catch { return false; }
}

// Resolve actual party membership from saved data, not guild/team tags.
// A guild alone never shares kill XP. Offline members are not recipients.
export function partyMembership(player) {
  const party = memberOf(state(), 'party', player.name);
  if (!party) return {inParty:false, members:[player]};
  // Older saves may have 5–8 members. Keep their roster intact, but only the
  // leader and the first three other members share XP until the roster shrinks.
  const activeNames = [party.leader, ...party.members.filter(n => nameKey(n) !== nameKey(party.leader))].slice(0, LIMIT.party);
  if (!activeNames.some(n => nameKey(n) === nameKey(player.name))) return {inParty:true, members:[]};
  const names = new Set(activeNames.map(nameKey));
  return {inParty:true, members:online().filter(p => names.has(nameKey(p.name)))};
}

export function enforcePartyLimit() {
  if (!state().parties.some(p => p.members.length > LIMIT.party)) return true;
  const removed = [];
  const ok = mutate(data => {
    for (const party of data.parties) {
      if (party.members.length <= LIMIT.party) continue;
      const keep = [party.leader, ...party.members.filter(n => nameKey(n) !== nameKey(party.leader))].slice(0, LIMIT.party);
      removed.push(...party.members.filter(n => !keep.some(k => nameKey(k) === nameKey(n))));
      party.members = keep;
    }
    return true;
  });
  if (ok) for (const name of removed) try { byName(name)?.sendMessage('§e[RPG] 파티 정원이 4명으로 변경되어 기존 파티에서 탈퇴 처리되었습니다. 새 파티에 가입할 수 있습니다.'); } catch {}
  return ok;
}

function incoming(player) {
  const key = nameKey(player.name);
  const now = system.currentTick;
  const list = (invites.get(key) ?? []).filter(x => x.expires > now);
  if (list.length) invites.set(key, list); else invites.delete(key);
  return list;
}
function removeInvitation(player, invite) {
  const key = nameKey(player.name);
  const next = incoming(player).filter(i => i !== invite);
  if (next.length) invites.set(key, next); else invites.delete(key);
}
function clearGroupInvites(type, id) {
  for (const [key, list] of invites) {
    const rest = list.filter(i => i.type !== type || i.id !== id);
    if (rest.length) invites.set(key, rest); else invites.delete(key);
  }
}
function sendInvite(sender, target, type) {
  const g = memberOf(state(), type, sender.name);
  if (!g || nameKey(g.leader) !== nameKey(sender.name)) {
    sender.sendMessage(`§c${caption(type)}장만 초대할 수 있습니다.`); return;
  }
  if (memberOf(state(), type, target.name)) {
    sender.sendMessage(`§c${target.name}님은 이미 ${caption(type)}에 소속되어 있습니다.`); return;
  }
  if (nameKey(sender.name) === nameKey(target.name)) return;
  const key = nameKey(target.name);
  const curr = incoming(target).filter(i => i.type !== type);
  curr.push({ type, id: g.id, inviter: sender.name, expires: system.currentTick + EXPIRES });
  invites.set(key, curr);
  sender.sendMessage(`§a${target.name}님에게 ${caption(type)} 초대를 보냈습니다. (2분 유효)`);
  target.sendMessage(`§e${sender.name}님의 ${caption(type)} 초대가 왔습니다! §f/rpg:invites §7또는 /rpg:${type}에서 수락할 수 있습니다.`);
  system.runTimeout(() => { if (target.isValid && !menus.has(target.id)) showInviteNotice(target); }, 15);
}
async function showInviteNotice(target) {
  try {
    const list = incoming(target);
    if (!list.length) return;
    const form = new MessageFormData().title("RPG 그룹 초대")
      .body(`${list[0].inviter}님에게서 ${caption(list[0].type)} 초대가 왔습니다.\n받은 초대함에서 수락하거나 거절할 수 있습니다.`)
      .button1("나중에")
      .button2("초대 확인");
    // 다른 게임 메뉴를 가리지 않도록 자동 팝업은 한 번만 시도합니다.
    const result = await form.show(target);
    if (!result.canceled && result.selection === 1) openInvites(target);
  } catch {}
}
function approve(player, invite, accept) {
  removeInvitation(player, invite);
  if (!accept) {
    player.sendMessage("§7초대를 거절했습니다."); return;
  }
  let joinedId = null;
  if (!mutate(data => {
    const g = groups(data, invite.type).find(v => v.id === invite.id);
    if (!g) return "초대한 그룹이 사라졌습니다.";
    if (memberOf(data, invite.type, player.name)) return `이미 다른 ${caption(invite.type)}에 소속되어 있습니다.`;
    if (g.members.length >= LIMIT[invite.type]) return "그룹 정원이 가득 찼습니다.";
    g.members.push(player.name);
    joinedId = g.id;
    return true;
  }, player)) return;
  player.sendMessage(`§a${caption(invite.type)} 가입에 성공했습니다.`);
  notifyMembers(invite.type, joinedId, `§b[${caption(invite.type)}] §f${player.name}님이 가입했습니다.`);
}

async function openInvitesView(player) {
  const list = incoming(player);
  const form = new ActionFormData().title("받은 초대");
  if (!list.length) {
    form.body("현재 받은 초대가 없습니다.").button("돌아가기");
    await showForm(form, player); return;
  }
  form.body("초대를 선택하여 수락하거나 거절하세요. (2분 후 자동 만료)");
  for (const item of list) form.button(`${caption(item.type)} · ${item.inviter}`);
  form.button("뒤로");
  const r = await showForm(form, player);
  if (!r || r.canceled || r.selection >= list.length) return;
  const item = list[r.selection];
  if (!incoming(player).includes(item)) { player.sendMessage("§7초대가 만료되었습니다."); return; }
  const g = groups(state(), item.type).find(v => v.id === item.id);
  if (!g) { removeInvitation(player, item); player.sendMessage("§7초대한 그룹이 존재하지 않습니다."); return; }
  const choice = await showForm(new MessageFormData().title("초대 응답")
    .body(`${item.inviter}님의 ${caption(item.type)} 초대에 응하시겠습니까?\n${item.type === "guild" ? g.name : g.leader + "님의 파티"}`)
    .button1("거절")
    .button2("수락"), player);
  if (!choice || choice.canceled) return;
  if (!incoming(player).includes(item)) { player.sendMessage("§7초대가 만료되었습니다."); return; }
  approve(player, item, choice.selection === 1);
}
export function openInvites(player) { return openMenu(player, "invites"); }

async function makeGuild(player) {
  if (memberOf(state(), "guild", player.name)) return;
  const form = new ModalFormData().title("길드 창설")
    .textField("길드 이름 (2~16자)", "예: 달빛기사단")
    .submitButton("길드 생성");
  const r = await showForm(form, player);
  if (!r || r.canceled) return;
  const name = String(r.formValues?.[0] ?? "").trim();
  if (name.length < 2 || name.length > 16 || /[§\r\n\t]/.test(name)) {
    player.sendMessage("§c길드 이름은 2~16자이며 줄바꿈·색상 코드는 사용할 수 없습니다."); return;
  }
  if (mutate(data => {
    if (memberOf(data, "guild", player.name)) return "이미 길드에 가입했습니다.";
    if (data.guilds.some(g => nameKey(g.name) === nameKey(name))) return "이미 사용 중인 길드 이름입니다.";
    data.guilds.push({ id: data.nextId++, name, leader: player.name, members: [player.name] });
    return true;
  }, player)) player.sendMessage(`§a길드 [${name}] 생성 완료!`);
}
function makeParty(player) {
  if (mutate(data => {
    if (memberOf(data, "party", player.name)) return "이미 파티에 가입했습니다.";
    data.parties.push({ id: data.nextId++, leader: player.name, members: [player.name] });
    return true;
  }, player)) player.sendMessage("§a파티를 만들었습니다. 파티 메뉴에서 다른 플레이어를 초대하세요.");
}

async function choosePlayer(player, type, action) {
  const group = memberOf(state(), type, player.name);
  if (!group || nameKey(group.leader) !== nameKey(player.name)) return;
  let candidates;
  if (action === "invite") candidates = online().filter(p => nameKey(p.name) !== nameKey(player.name) && !memberOf(state(), type, p.name));
  else candidates = group.members.filter(n => nameKey(n) !== nameKey(player.name));
  if (!candidates.length) { player.sendMessage(action === "invite" ? "§7초대할 수 있는 접속 중인 플레이어가 없습니다." : "§7다른 멤버가 없습니다."); return; }
  const names = candidates.map(p => typeof p === "string" ? p : p.name);
  const title = action === "invite" ? `${caption(type)}에 초대` : action === "kick" ? "멤버 추방" : "그룹장 위임";
  const form = new ActionFormData().title(title).body("대상 플레이어를 선택하세요.");
  names.forEach(n => form.button(n)); form.button("취소");
  const res = await showForm(form, player);
  if (!res || res.canceled || res.selection >= names.length) return;
  const name = names[res.selection];
  const current = memberOf(state(), type, player.name);
  if (!current || nameKey(current.leader) !== nameKey(player.name)) return;
  if (action === "invite") {
    const target = byName(name);
    if (!target) { player.sendMessage("§c플레이어가 접속을 종료했습니다."); return; }
    sendInvite(player, target, type);
    return;
  }
  const success = mutate(data => {
    const g = memberOf(data, type, player.name);
    if (!g || nameKey(g.leader) !== nameKey(player.name)) return "권한이 없습니다.";
    if (!g.members.some(n => nameKey(n) === nameKey(name))) return "더 이상 그룹원이 아닙니다.";
    if (action === "kick") g.members = g.members.filter(n => nameKey(n) !== nameKey(name));
    else if (action === "transfer") g.leader = g.members.find(n => nameKey(n) === nameKey(name));
    return true;
  }, player);
  if (success) {
    player.sendMessage(action === "kick" ? `§e${name}님을 추방했습니다.` : `§a그룹장을 ${name}님에게 위임했습니다.`);
    if (action === "kick") byName(name)?.sendMessage(`§c${caption(type)}에서 추방되었습니다.`);
    const g = memberOf(state(), type, player.name);
    if (g) notifyMembers(type, g.id, `§b[${caption(type)}] §f${name}님 ${action === "kick" ? "추방" : "그룹장 위임"}`);
  }
}
function leaveGroup(player, type, disband) {
  const group = memberOf(state(), type, player.name);
  if (!group) return;
  const id = group.id;
  const memberNames = [...group.members];
  const success = mutate(data => {
    const list = groups(data, type);
    const index = list.findIndex(g => g.id === id);
    if (index < 0) return "그룹을 찾을 수 없습니다.";
    const g = list[index];
    const isLeader = nameKey(g.leader) === nameKey(player.name);
    if (disband) {
      if (!isLeader) return "그룹장만 해산할 수 있습니다.";
      list.splice(index, 1);
    } else {
      if (isLeader && type === "guild" && g.members.length > 1) return "길드장을 다른 멤버에게 위임한 후 탈퇴할 수 있습니다.";
      g.members = g.members.filter(n => nameKey(n) !== nameKey(player.name));
      if (!g.members.length) list.splice(index, 1);
      else if (isLeader) g.leader = g.members[0];
    }
    return true;
  }, player);
  if (!success) return;
  if (disband) {
    clearGroupInvites(type, id);
    for (const n of memberNames) byName(n)?.sendMessage(`§e${caption(type)}가 해산되었습니다.`);
  } else {
    player.sendMessage(`§7${caption(type)}에서 탈퇴했습니다.`);
    notifyMembers(type, id, `§b[${caption(type)}] §f${player.name}님이 탈퇴했습니다.`);
  }
}
async function confirmLeave(player, type, disband) {
  const res = await showForm(new MessageFormData().title(`${caption(type)} ${disband ? "해산" : "탈퇴"}`)
    .body(disband ? "그룹이 해산되고 모든 멤버가 제거됩니다. 계속하시겠습니까?" : `${caption(type)}에서 탈퇴하시겠습니까?`)
    .button1("취소").button2("확인"), player);
  if (res && !res.canceled && res.selection === 1) leaveGroup(player, type, disband);
}
async function showMembers(player, type) {
  const g = memberOf(state(), type, player.name);
  if (!g) return;
  const text = g.members.map(n => `${nameKey(n) === nameKey(g.leader) ? "§6[장]§r " : ""}${n} ${byName(n) ? "§a접속" : "§7오프라인"}`).join("\n");
  await showForm(new ActionFormData().title(`${caption(type)} 멤버`).body(text).button("뒤로"), player);
}
async function groupPage(player, type) {
  const g = memberOf(state(), type, player.name);
  const heading = caption(type);
  const form = new ActionFormData().title(`RPG ${heading}`);
  const actions = [];
  const add = (label, fn) => { form.button(label); actions.push(fn); };
  if (!g) {
    form.body(`${heading}에 소속되어 있지 않습니다.`);
    add(type === "guild" ? "길드 만들기" : "파티 만들기", () => type === "guild" ? makeGuild(player) : makeParty(player));
  } else {
    form.body(`${type === "guild" ? `§b${g.name}` : `${g.leader}님의 파티`} §7(${g.members.length}/${LIMIT[type]})\n그룹장: ${g.leader}`);
    if (type === 'party' && g.members.length > LIMIT.party) form.body(`${g.leader}님의 파티 (${g.members.length}/4)\n§e구버전 파티입니다. 리더와 명단 앞 3명만 경험치를 공유합니다.\n리더가 멤버를 정리해 4명 이하로 맞춰 주세요.`);
    add("멤버 보기", () => showMembers(player, type));
    if (nameKey(g.leader) === nameKey(player.name)) {
      add("플레이어 초대", () => choosePlayer(player, type, "invite"));
      add("멤버 추방", () => choosePlayer(player, type, "kick"));
      add("그룹장 위임", () => choosePlayer(player, type, "transfer"));
      add(`${heading} 해산`, () => confirmLeave(player, type, true));
    }
    add(`${heading} 탈퇴`, () => confirmLeave(player, type, false));
  }
  add("받은 초대", () => openInvitesView(player));
  add("닫기", () => "close");
  const r = await showForm(form, player);
  if (!r || r.canceled || r.selection >= actions.length) return "close";
  return actions[r.selection]();
}
async function openMenu(player, initialType) {
  if (menus.has(player.id)) { player.sendMessage("§7이미 길드·파티 창이 열려 있습니다."); return; }
  menus.add(player.id);
  try {
    if (initialType === "invites") { await openInvitesView(player); return; }
    for (let i=0; i<20 && player.isValid; i++) {
      const result = await groupPage(player, initialType);
      if (result === "close") break;
    }
  } catch (e) { console.warn(`[RPG social] UI 오류: ${e}`); }
  finally { menus.delete(player.id); }
}
export function openGuildMenu(player) { return openMenu(player, "guild"); }
export function openPartyMenu(player) { return openMenu(player, "party"); }

export function registerSocial() {
  // 최초 로드와 재접속 때 길드/파티 태그 재부착
  system.run(() => { state(); enforcePartyLimit(); syncAllTags(); });
  world.afterEvents.playerSpawn.subscribe(event => system.runTimeout(() => {
    if (event.player.isValid) syncPlayerTags(event.player);
  }, 30));
  system.runInterval(() => {
    try { syncAllTags(); for (const p of online()) incoming(p); }
    catch {}
  }, 200);
}

export function partyLeaderName(player){return memberOf(state(),"party",player.name)?.leader??player.name;}
