import { world, ItemStack } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { JOBS, STARTER_BY_LINE, APPRENTICE_SKILLS } from '../data/jobs.js';
import { getJobId, getSkills, setSkills } from './playerData.js';
import { gainRpgXp, openStatsMenu } from './stats.js';
import { requestAdvance } from './advance.js';
import { showForm } from './skillMenu.js';
import {
  INTRO_KEY, INTRO_KILLS, INTRO_XP, BEGINNER_LINES, getBeginnerState,
  setBeginnerState, isBeginnerTarget,
} from './beginnerData.js';

const LABELS = {sword:'검', mage:'마법', holy:'성직', fist:'격투', archer:'궁수'};
const TARGETS = {sword:'swordsman', mage:'mage', holy:'cleric', fist:'fighter', archer:'archer'};
const open = new Set();
let registered = false;

export function chooseBeginnerLine(player, line) {
  if (!BEGINNER_LINES.includes(line)) return {ok:false, reason:'알 수 없는 계열입니다.'};
  if (getJobId(player) !== 'apprentice') return {ok:false, reason:'견습만 시작 장비를 받을 수 있습니다.'};
  if (getBeginnerState(player).line) return {ok:false, reason:'이미 시작 계열을 선택했습니다.'};
  const inventory = player.getComponent('minecraft:inventory')?.container;
  if (!inventory) return {ok:false, reason:'인벤토리가 준비되지 않았습니다.'};
  // Use empty slots only: no item is overwritten or dropped into the world.
  const bundle = [[STARTER_BY_LINE[line],1], ['minecraft:bread',16]];
  if (line === 'archer') bundle.push(['minecraft:arrow',64]);
  const empty = [];
  for (let i=0; i<inventory.size; i++) if (!inventory.getItem(i)) empty.push(i);
  if (empty.length < bundle.length) return {ok:false, reason:`가방에 빈 칸 ${bundle.length}개가 필요합니다. 정리한 뒤 /rpg:guide 를 입력하세요.`};
  const previousSkills = getSkills(player);
  const previousState = player.getDynamicProperty(INTRO_KEY);
  try {
    const items = bundle.map(([id, count]) => new ItemStack(id, count));
    items[0].keepOnDeath = true;
    for (let i=0; i<items.length; i++) inventory.setItem(empty[i], items[i]);
    setSkills(player, [...new Set([...previousSkills, ...(APPRENTICE_SKILLS[line]??[])])]);
    setBeginnerState(player, {line,tried:[line],trialArrowsGiven:line==='archer', kills:0, rewarded:false, offered:true});
    return {ok:true};
  } catch (error) {
    // All writes above are synchronous; restore the previously empty slots on failure.
    for (let i=0; i<bundle.length; i++) try { inventory.setItem(empty[i], undefined); } catch {}
    try { setSkills(player, previousSkills); player.setDynamicProperty(INTRO_KEY, previousState); } catch {}
    return {ok:false, reason:'장비 지급에 실패했습니다. 다시 시도하세요: ' + String(error)};
  }
}

function controls(line) {
  const basic = '§e[조작]§r\n받은 무기를 손에 드세요. 일반 공격으로 적을 때릴 수 있습니다.\n웅크리면 다음 스킬로 전환합니다.\n';
  if (line === 'archer') return basic + '활을 당겨 놓으면 사격과 선택 스킬을 사용합니다. 화살이 필요합니다.\n';
  if (line === 'holy') return basic + '견습 회복은 대상을 때려 사용하는 스킬입니다. 전투 중 무작정 아군을 공격하지 마세요.\n';
  if (line === 'mage') return basic + '우클릭/아이템 사용으로 선택한 마법을 발동합니다.\n';
  return basic + '이 계열의 견습은 일반 공격으로 시작합니다. 첫 전직 뒤 전용 스킬을 배웁니다.\n';
}

export function recordBeginnerKill(player, entity) {
  if (!isBeginnerTarget(entity?.typeId)) return;
  try {
    const state = getBeginnerState(player);
    if (!state.line || state.rewarded || state.kills >= INTRO_KILLS) return;
    const mode = String(player.getGameMode()).toLowerCase();
    if (mode === 'creative' || mode === 'spectator') return;
    state.kills++;
    setBeginnerState(player, state);
    player.sendMessage(`§a[첫 사냥] 적 처치 ${state.kills}/${INTRO_KILLS}` +
      (state.kills === INTRO_KILLS ? ' §e완료! /rpg:guide 에서 보상을 받으세요. 전직 시련은 /rpg:jobs' : ''));
  } catch (error) { console.warn('[RPG intro] kill progress: ' + String(error)); }
}

export function claimBeginnerReward(player) {
  const state = getBeginnerState(player);
  if (!state.line || state.rewarded || state.kills < INTRO_KILLS) return false;
  // A single synchronous claim; opening the menu again cannot grant a second reward.
  state.rewarded = true;
  setBeginnerState(player, state);
  gainRpgXp(player, INTRO_XP);
  player.sendMessage(`§a[첫 사냥] RPG XP +${INTRO_XP}! 보상을 받았습니다. 첫 전직은 레벨 10과 직업별 시련이 필요합니다. §e/rpg:guide`);
  return true;
}

export async function openBeginnerGuide(player) {
  if (!player?.isValid || open.has(player.id)) return;
  open.add(player.id);
  try {
    let state = getBeginnerState(player);
    if (!state.line && getJobId(player) === 'apprentice') {
      setBeginnerState(player, {...state, offered:true});
      const form = new ActionFormData().title('RPG 모험의 시작')
        .body('먼저 체험할 장비를 고르세요. 견습은 이후에도 5계열을 자유롭게 체험할 수 있습니다. 빵은 처음 한 번 지급합니다.\n궁수는 화살 64개도 받습니다.\n\n첫 사냥: 몬스터 5마리 처치 → RPG XP 100 + 선택 계열 첫 사냥 보상! 첫 전직은 레벨 10＋직업별 시련입니다.\n동물·주민·플레이어·샌드백은 목표에 포함되지 않습니다.\n/rpg:guide의 견습 5계열 체험에서 다른 장비도 받으세요.');
      for (const line of BEGINNER_LINES) form.button(LABELS[line] + ' 계열');
      form.button('나중에 선택');
      const result = await showForm(form, player);
      if (!result || result.canceled || result.selection == null || result.selection >= BEGINNER_LINES.length) {
        player.sendMessage('§e[RPG] 준비되면 /rpg:guide 를 입력해 모험을 시작하세요.');
        return;
      }
      const chosen = chooseBeginnerLine(player, BEGINNER_LINES[result.selection]);
      if (!chosen.ok) { player.sendMessage('§c[RPG] ' + chosen.reason); return; }
      state = getBeginnerState(player);
    }
    const target = JOBS[TARGETS[state.line]];
    const job = JOBS[getJobId(player)];
    let body = (state.line ? controls(state.line) : '현재 직업: ' + (job?.name ?? '견습') + '\n') +
      '\n§e[성장]§r\n/rpg:stats: 레벨과 스탯 배분\n/rpg:skills: 사용할 스킬 켜기/끄기\n/rpg:status: 다음 전직 조건\n/rpg:party: 최대 4명 파티 만들기/가입\n/rpg:craft: 갑옷·룬 획득과 제작법\n/rpg:runes: 룬 보관함·장착\n/rpg:offer: 검과 책을 바칩니다\n/rpg:jobs: 전직 조건\n/rpg:equipment: 장비 메뉴\n/rpg:wallet: 골드·강화 재화\n/rpg:upgrade: 갑옷·룬·무기 강화\n/rpg:rulebook: 평화 서버 종합 룰북\n';
    if (state.line) body += `\n§e[첫 사냥]§r ${state.kills}/${INTRO_KILLS}` +
      (state.rewarded ? ' · 보상 수령 완료' : `\n보상: RPG XP ${INTRO_XP} + 첫 전직 조건은 /rpg:jobs 확인`) +
      '\n첫 사냥 목표는 처치자만 오릅니다. 전직용 처치는 전투에 기여한 파티원도 인정합니다. 파티 XP는 각자 75%입니다.\n';
    body += '\n§e[파티 경험치]§r\n처치자 32블록 안, 같은 차원에서 살아 있는 파티원에게 각자 원래 XP의 75%를 받습니다. (90 XP → 67.5 XP)\n최대 레벨·크리에이티브·관전자·오프라인은 제외됩니다.\n';
    const form = new ActionFormData().title('모험 안내').body(body);
    const actions = [];
    if (state.line && !state.rewarded && state.kills >= INTRO_KILLS) {
      form.button('첫 사냥 보상 받기'); actions.push(() => claimBeginnerReward(player));
    }
    if (state.rewarded && getJobId(player) === 'apprentice' && target) {
      form.button(target.name + ' 첫 전직'); actions.push(() => requestAdvance(player, target));
    }
    form.button('스탯 배분하기'); actions.push(() => openStatsMenu(player));
    if(getJobId(player)==='apprentice'){form.button('견습 5계열 체험');actions.push(()=>openApprenticeTrials(player));}
    form.button('닫기');
    const result = await showForm(form, player);
    if (result && !result.canceled && result.selection != null && result.selection < actions.length) await actions[result.selection]();
  } catch (error) {
    try { player.sendMessage('§c[RPG] 모험 안내 오류: ' + String(error)); } catch {}
  } finally { open.delete(player.id); }
}

export function registerBeginnerGuide() {
  if (registered) return;
  registered = true;
  // 첫 접속·재접속·스크립트 초기화 시 계열 선택창을 자동으로 열지 않습니다.
  // 시작 장비와 첫 사냥 안내는 플레이어가 /rpg:guide 를 실행했을 때만 엽니다.
  world.afterEvents.playerLeave.subscribe(ev => open.delete(ev.playerId));
}


export function tryBeginnerLine(player,line){
 if(!BEGINNER_LINES.includes(line))return {ok:false,reason:'알 수 없는 체험 장비입니다.'};
 if(getJobId(player)!=='apprentice')return {ok:false,reason:'견습 상태에서만 체험할 수 있습니다.'};
 const state=getBeginnerState(player);if(!state.line)return chooseBeginnerLine(player,line);
 const inv=player.getComponent('minecraft:inventory')?.container;if(!inv)return {ok:false,reason:'인벤토리를 확인할 수 없습니다.'};
 const tried=state.tried??[state.line],owned=[];for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId===STARTER_BY_LINE[line])owned.push(i);
 const bundle=[];
 if(!owned.length)bundle.push([STARTER_BY_LINE[line],1]);
 if(line==='archer'&&!state.trialArrowsGiven)bundle.push(['minecraft:arrow',64]);
 const empty=[];for(let i=0;i<inv.size;i++)if(!inv.getItem(i))empty.push(i);
 if(empty.length<bundle.length)return {ok:false,reason:`가방에 빈 칸 ${bundle.length}개가 필요합니다.`};
 const oldState=player.getDynamicProperty(INTRO_KEY),oldSkills=getSkills(player);
 try{
  for(let i=0;i<bundle.length;i++){const [id,n]=bundle[i],item=new ItemStack(id,n);if(id===STARTER_BY_LINE[line])item.keepOnDeath=true;inv.setItem(empty[i],item);}
  setSkills(player,[...new Set([...oldSkills,...(APPRENTICE_SKILLS[line]??[])])]);
  setBeginnerState(player,{...state,line,tried:[...new Set([...tried,line])],trialArrowsGiven:state.trialArrowsGiven||line==='archer',offered:true});
  return {ok:true,reused:bundle.length===0};
 }catch(error){for(let i=0;i<bundle.length;i++)try{inv.setItem(empty[i],undefined);}catch{}try{setSkills(player,oldSkills);player.setDynamicProperty(INTRO_KEY,oldState);}catch{}return {ok:false,reason:'체험 장비 저장에 실패해 지급을 취소했습니다.'};}
}
const trialOpen=new Set();
export async function openApprenticeTrials(player){
 if(trialOpen.has(player.id))return;trialOpen.add(player.id);
 try{
  if(getJobId(player)!=='apprentice'){player.sendMessage('§e견습 상태에서만 체험할 수 있습니다.');return;}
  const f=new ActionFormData().title('견습 5계열 자유 체험').body('시작 계열과 관계없이 견습 장비를 바꿔 사용하세요. 가방에 없는 견습 장비를 보충합니다. 이미 가진 장비는 중복 지급하지 않으며, 빵과 화살은 각각 처음 한 번만 지급합니다.');
  for(const line of BEGINNER_LINES)f.button(LABELS[line]+' 체험');f.button('닫기');
  const r=await showForm(f,player);if(!r||r.canceled||r.selection==null||r.selection>=BEGINNER_LINES.length)return;
  const line=BEGINNER_LINES[r.selection],result=tryBeginnerLine(player,line);
  player.sendMessage(result.ok?'§a'+LABELS[line]+' 견습 장비를 손에 들고 체험하세요.':'§e'+result.reason);
 }finally{trialOpen.delete(player.id);}
}
