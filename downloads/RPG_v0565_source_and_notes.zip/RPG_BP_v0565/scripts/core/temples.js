import {registerStructureProtection} from './structureProtection.js';
import {world,system} from '@minecraft/server';
import {ActionFormData} from '@minecraft/server-ui';
import {TEMPLE_KEY,TEMPLE_RADIUS,TEMPLE_HEIGHT,TEMPLE_BUDGET,TEMPLE_VOLUME,templeBlock,templeOffset,altarPosition,celestialPhase} from '../data/temple.js';
import {readTemple,saveTemple,templeRequirement} from './templeAccess.js';
import {requestAdvance,requirementStatus} from './advance.js';
import {JOBS} from '../data/jobs.js';
import {showForm} from './skillMenu.js';
const AIR=new Set(['minecraft:air','minecraft:cave_air','minecraft:void_air','minecraft:short_grass','minecraft:tallgrass','minecraft:snow_layer']);
const GROUND=new Set(['minecraft:grass_block','minecraft:grass','minecraft:dirt','minecraft:stone','minecraft:sand','minecraft:gravel','minecraft:snow','minecraft:deepslate']);
const admin=p=>p?.playerPermissionLevel===2||p?.commandPermissionLevel>=1||p?.isOp?.()===true;
const tell=(id,msg)=>{try{world.getAllPlayers().find(p=>p.id===id)?.sendMessage(msg);}catch{}};
const position=(t,o)=>({x:t.x+o.x,y:t.y+o.y,z:t.z+o.z});
let registered=false,phaseApplied;
export function createTemple(p){
 if(!admin(p))throw Error('신전 생성은 관리자만 가능합니다.');
 if(p.dimension.id!=='minecraft:overworld')throw Error('신전은 오버월드에 생성하세요.');
 let t=readTemple();
 if(t&&t.status==='ready'){p.sendMessage(`§e기존 천체 신전: ${t.x}, ${t.y+1}, ${t.z}. /rpg:temple로 확인하세요. 다른 곳에 만들려면 /rpg:templeremove로 등록을 해제하세요.`);return t;}
 if(t&&t.status==='error'&&t.writes>0){t.status=t.resumePhase??'build';delete t.error;t.stalled=0;saveTemple(t);p.sendMessage('§e같은 위치에서 중단된 신전 공사를 재개합니다.');return t;}
 if(t&&['scan','build','verify'].includes(t.status)){p.sendMessage('§e신전 생성·검사가 진행 중입니다. 해당 지역에 머물러 주세요.');return t;}
 const view=p.getViewDirection?.()??{x:0,z:1},length=Math.hypot(view.x,view.z)||1,dx=length===1&&!view.x&&!view.z?0:view.x/length,dz=!view.x&&!view.z?1:view.z/length;
 const y=Math.floor(p.location.y)-1;if(y<-63||y+TEMPLE_HEIGHT>319)throw Error('신전을 만들 높이가 부족합니다.');
 t={dimId:p.dimension.id,x:Math.floor(p.location.x+dx*22),y,z:Math.floor(p.location.z+dz*22),status:'scan',cursor:0,writes:0,ownerId:p.id,stalled:0};saveTemple(t);
 p.sendMessage(`§e앞쪽 ${t.x}, ${t.y+1}, ${t.z}에 지름 27칸 천체 신전 생성 예약. 빈 공간을 확인한 뒤 건축합니다. 지역에 머물러 주세요.`);return t;
}
export function removeTemple(p){if(!admin(p))throw Error('신전 등록 해제는 관리자만 가능합니다.');saveTemple(undefined);phaseApplied=undefined;p.sendMessage('§7신전 등록을 해제했습니다. 기존 건축물은 보존하며 해당 제단의 전직 기능은 종료합니다.');}
export function templeTick(){
 const t=readTemple();if(!t)return;
 const dim=world.getDimension(t.dimId);
 if(t.status==='ready'){
  if(system.currentTick%20!==0)return;
  const phase=celestialPhase(world.getTimeOfDay());if(phaseApplied===phase)return;
  let complete=true;
  for(const kind of ['sun','moon']){try{const b=dim.getBlock(altarPosition(t,kind));if(!b||!['minecraft:sea_lantern','minecraft:gold_block','minecraft:amethyst_block'].includes(b.typeId)){complete=false;continue;}b.setType(kind===phase?'minecraft:sea_lantern':kind==='sun'?'minecraft:gold_block':'minecraft:amethyst_block');}catch{complete=false;}}
  if(complete)phaseApplied=phase;return;
 }
 if(t.status==='error')return;
 let visited=0,writes=0;const old=t.cursor??0;
 try{
  while(t.cursor<TEMPLE_VOLUME&&visited<512&&writes<TEMPLE_BUDGET){
   const o=templeOffset(t.cursor),at=position(t,o),expected=templeBlock(o.x,o.y,o.z);let block;try{block=dim.getBlock(at);}catch(error){if(/chunk|unloaded|청크/i.test(String(error)))break;throw error;}if(!block)break;
   if(t.status==='scan'){
    if(!AIR.has(block.typeId)&&!(o.y===0&&GROUND.has(block.typeId)))throw Error(`기존 블록(${at.x}, ${at.y}, ${at.z})이 있어 생성하지 않았습니다. 빈 지역에서 다시 실행하세요.`);
   }else if(expected){
    if(t.status==='verify'){if(block.typeId!==expected){if(!AIR.has(block.typeId)&&!(o.y===0&&GROUND.has(block.typeId)))throw Error('완성 검사 중 다른 블록을 발견했습니다. 확인 후 /rpg:templecreate로 재개하세요.');block.setType(expected);writes++;t.writes++;if(block.typeId!==expected)break;}}
    else if(block.typeId!==expected){if(!AIR.has(block.typeId)&&!(o.y===0&&GROUND.has(block.typeId)))throw Error('공사 중 다른 블록이 생겨 중단했습니다. 확인 후 같은 위치에서 재개하세요.');block.setType(expected);writes++;t.writes++;}
   }
   t.cursor++;visited++;
  }
  if(t.cursor===TEMPLE_VOLUME){
   if(t.status==='verify'){t.status='ready';delete t.cursor;phaseApplied=undefined;t.stalled=0;saveTemple(t);tell(t.ownerId,'§a천체 신전 완성! 낮에는 해, 밤에는 달 제단 활성. /rpg:temple 또는 제단 상호작용으로 전직하세요.');return;}
   t.status=t.status==='scan'?'build':'verify';t.cursor=0;t.stalled=0;
  }else if(t.cursor===old){t.stalled=(t.stalled??0)+1;if(t.stalled>=600)throw Error('청크를 읽지 못했습니다. 신전 위치로 이동한 뒤 /rpg:templecreate로 재개하세요.');}
  else t.stalled=0;
  saveTemple(t);
 }catch(error){t.resumePhase=t.status==='verify'?'build':t.status;t.status='error';t.error=String(error.message??error);saveTemple(t);tell(t.ownerId,'§c신전 공사 중단: '+t.error);}
}
const open=new Set();
export async function openTemple(p){
 if(open.has(p.id))return;open.add(p.id);
 try{
  const t=readTemple();if(!t||t.status!=='ready'){p.sendMessage('§e신전이 없거나 아직 공사 중입니다. 관리자 /rpg:templecreate');return;}
  const kind=celestialPhase(world.getTimeOfDay()),job=JOBS[kind==='sun'?'sun_heir':'moon_heir'],check=templeRequirement(p,kind),status=requirementStatus(p,job);
  const form=new ActionFormData().title(kind==='sun'?'해의 신전':'달의 신전').body(`현재 ${kind==='sun'?'낮 · 해':'밤 · 달'} 제단 활성\n${check.label}\n\n아무 2차 이상 직업·레벨 20·해당 시간대 적 60마리 처치\n${status?.label??''}\n\n해·달의 후예는 활성 제단 4칸 안에서만 전직합니다. 기존 후예의 스킬은 신전 밖에서도 사용합니다.`).button(job.name+' 전직').button('닫기');
  const answer=await showForm(form,p);if(!answer||answer.canceled||answer.selection!==0)return;await requestAdvance(p,job);
 }catch(error){try{p.sendMessage('§e신전: '+String(error.message??error));}catch{}}
 finally{open.delete(p.id);}
}
export function templeProtected(block){const t=readTemple();if(!t||(!t.writes&&t.status!=='ready')||block?.dimension?.id!==t.dimId)return false;const p=block.location;return p.y>=t.y&&p.y<=t.y+TEMPLE_HEIGHT&&Math.hypot(p.x-t.x,p.z-t.z)<=TEMPLE_RADIUS;}
export function registerTemples(){
 if(registered)return;registered=true;
 system.runInterval(()=>{try{templeTick();}catch(error){console.warn('[RPG temple] '+String(error));}},1);
 world.beforeEvents?.playerInteractWithBlock?.subscribe(ev=>{
  const t=readTemple();if(!t||t.status!=='ready'||ev.block?.dimension?.id!==t.dimId)return;
  const pos=ev.block.location;if(!['sun','moon'].some(kind=>{const a=altarPosition(t,kind);return pos.x===a.x&&pos.z===a.z&&(pos.y===a.y||pos.y===a.y-1);}))return;
  ev.cancel=true;system.run(()=>openTemple(ev.player));
 });
 registerStructureProtection('temple',templeProtected);
}
