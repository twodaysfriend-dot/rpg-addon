import { areAllies } from "./social.js";
import { world } from "@minecraft/server";
import { JOBS } from "../data/jobs.js";
import { CONFIG } from "../config.js";
import { getJobId, addProgress } from "./playerData.js";
import { heldItemId } from "./util.js";
import { notify } from "./hud.js";

// 플레이어가 가장 최근에 타격한 엔티티 (러쉬 스킬이 사용)
const lastHit = new Map();
export function getLastHit(player) {
  const candidate = lastHit.get(player.id)?.entity ?? null;
  return candidate && !areAllies(player, candidate) ? candidate : null;
}

const VILLAGERS = ["minecraft:villager", "minecraft:villager_v2"];

function bump(player, key, label, need) {
  const n = addProgress(player, key);
  if (n < need) {
    notify(player, `§7${label} ${n}/${need}`);
  } else if (n === need) {
    notify(player, `§a${label} ${need}/${need} 달성! 전직 조건을 채웠습니다.`);
  }
}

// 궁수 전직 명중 수와 최근 전투 대상을 기록합니다. 처치 시련은 jobTrials.js에서 처리합니다.
export function registerTracking() {
  world.afterEvents.projectileHitEntity?.subscribe((ev) => {
    try {
      const p = ev.source;
      if (p?.typeId !== "minecraft:player" || ev.projectile?.typeId !== "minecraft:arrow") return;
      const victim = ev.getEntityHit()?.entity;
      if (!victim || victim.typeId === "rpg:gpt_guide" || victim.id === p.id || areAllies(p,victim) || victim.typeId === "minecraft:player") return;
      // Projectile hits count as the most recent target for Judgement.
      lastHit.set(p.id, { entity: victim });
      const job = getJobId(p);
      const held = heldItemId(p);
      if (job === "archer" && held === "rpg:archer_bow") {
        bump(p, "archer_arrow_hits", "궁수 활 명중", JOBS.heavenly_archer.req.need);
      }
    } catch { /* 화살 회수/대상 소멸 시 무시 */ }
  });

  world.afterEvents.entityHurt.subscribe((ev) => {
    const attacker = ev.damageSource?.damagingEntity;
    if (attacker?.typeId !== "minecraft:player") return;
    const victim = ev.hurtEntity;
    if (!victim || victim.typeId === "rpg:gpt_guide" || victim.id === attacker.id || areAllies(attacker,victim) || (victim.typeId === "minecraft:player" && !CONFIG.pvp)) return;
    lastHit.set(attacker.id, { entity: victim });
  });

}
