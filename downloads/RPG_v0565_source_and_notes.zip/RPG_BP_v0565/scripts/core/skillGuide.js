import { ActionFormData } from '@minecraft/server-ui';
import { JOBS,APPRENTICE_SKILLS } from '../data/jobs.js';
import { SKILLS } from '../data/skills.js';
import { LINE_NAMES,LINE_NOTES,SKILL_NOTES } from '../data/skillGuide.js';
import { showForm } from './skillMenu.js';
const activeJobs=Object.values(JOBS).filter(j=>!j.placeholder);
const activeIds=new Set([...activeJobs.flatMap(j=>j.skills),...Object.values(APPRENTICE_SKILLS).flat()]);
export function skillGuideGroups(){return Object.entries(LINE_NAMES).map(([line,name])=>({line,name,ids:[...activeIds].filter(id=>SKILLS[id]?.line===line)})).filter(g=>g.ids.length);}
export function skillGuideDetail(id){
  if(!activeIds.has(id)||!SKILLS[id]||!SKILL_NOTES[id])return undefined;
  const skill=SKILLS[id],owners=activeJobs.filter(j=>j.skills.includes(id)).map(j=>j.name);
  if(Object.values(APPRENTICE_SKILLS).some(list=>list.includes(id)))owners.unshift('견습');
  return `사용 직업: ${owners.join(', ')}\n기본 MP ${skill.mana} / 쿨 ${skill.cooldown/20}초\n\n${SKILL_NOTES[id]}\n\n기본 피해는 스탯·장비 보정 전입니다. 다단 명목 합계는 실제 피해를 보장하지 않습니다.\n스킬 ID: ${id}`;
}
const open=new Set();
export async function openSkillGuide(p){
  if(open.has(p.id))return;open.add(p.id);
  try{
    const groups=skillGuideGroups();
    for(let i=0;i<80&&p.isValid;i++){
      const form=new ActionFormData().title('직업 계열별 스킬 도감').body('모든 구현 직업의 효과·마나·쿨타임·패시브 설명을 볼 수 있습니다.');
      for(const g of groups)form.button(`${g.name} (${g.ids.length})`);form.button('닫기');
      const res=await showForm(form,p);if(!res||res.canceled||res.selection==null||res.selection>=groups.length)return;
      const group=groups[res.selection];
      for(let j=0;j<80&&p.isValid;j++){
        const form=new ActionFormData().title(group.name).body(LINE_NOTES[group.line]);
        for(const id of group.ids)form.button(SKILLS[id].name);form.button('뒤로');
        const pick=await showForm(form,p);if(!pick||pick.canceled||pick.selection==null||pick.selection>=group.ids.length)break;
        const id=group.ids[pick.selection];await showForm(new ActionFormData().title(SKILLS[id].name).body(skillGuideDetail(id)).button('돌아가기'),p);
      }
    }
  }catch(error){try{p.sendMessage('§c스킬 도감: '+String(error));}catch{}}
  finally{open.delete(p.id);}
}
