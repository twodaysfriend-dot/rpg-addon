export const HUNT_REWARDS=Object.freeze({normal:{gold:114,stone:2,dustChance:.15},elite:{gold:360,stone:6,dust:1},boss:{gold:3600,stone:24,dust:6}});
export const DUNGEON={radius:32,height:28,maxCount:10,maxParty:4,mobLimitMs:300000,bossLimitMs:180000,normalCount:50,eliteCount:5,initialNormals:3,normalBatch:2,normalIntervalMs:6000,eliteIntervalMs:40000,eliteMinGapMs:5000,reinforceDelayMs:1000,maxAlive:12,baselineMinutes:10,buildBudget:512,buildSpacing:80};
export const CLEAR_REWARD={gold:2000,stone:8,dust:2,catalysts:7,bonusEvery:3};
export function clearRewardForTier(tier=1,solo=false){
 const t=Math.max(1,Math.min(10,Math.floor(Number(tier)||1))),mult=[1,1.6,2.4,3.4,4.6,6,7.8,10,12.5,15.5][t-1];
 const bonus=solo?1.5:1;
 return {...CLEAR_REWARD,gold:Math.round(CLEAR_REWARD.gold*mult*bonus),stone:Math.ceil(CLEAR_REWARD.stone*mult*bonus),dust:Math.ceil(CLEAR_REWARD.dust*mult*bonus),catalysts:Math.ceil([7,8,9,10,12,14,16,19,22,26][t-1]*bonus),runes:1+Math.floor((t-1)/4),supplyMultiplier:1+Math.floor((t-1)/3)};
}
export const RUNE_CYCLE=['power','arcane','vitality','mana','ward','absorption'];
export const ARMOR_KIT=['adventurer_helmet','adventurer_chestplate','adventurer_leggings','adventurer_boots'];
export const SUPPLIES={'minecraft:iron_ingot':8,'minecraft:copper_ingot':2,'minecraft:emerald':2,'minecraft:oak_planks':2,'minecraft:amethyst_shard':2,'minecraft:lapis_lazuli':1};
const names=['이끼 동굴','붉은 수정굴','균사의 동굴','사마귀 둥지','전갈 소굴','정예의 동굴','히드라의 둥지','심연의 동굴','마공학 폐광','종말의 심연'];
const hp=[1,1.25,1.5,1.8,2.1,2.5,3,3.6,4.3,5.2];
const normalPools=[['green_goblin'],['green_goblin','red_goblin'],['red_goblin','blue_mushroom'],['mantis','red_goblin'],['scorpion','mantis'],['red_goblin','gold_goblin'],['mantis','scorpion'],['red_mushroom','gold_goblin'],['gold_goblin','mantis'],['red_goblin','gold_goblin','mantis','scorpion']];
const elitePools=[['elite_green_goblin'],['elite_green_goblin','elite_red_goblin'],['elite_blue_mushroom'],['elite_mantis'],['elite_scorpion'],['elite_goblin_captain'],['elite_mantis','elite_scorpion'],['elite_red_mushroom','elite_gold_goblin'],['elite_gold_goblin','elite_goblin_captain'],['elite_goblin_captain','elite_mantis','elite_scorpion']];
export const DUNGEON_TIERS=names.map((name,i)=>({tier:i+1,id:'dungeon_'+(i+1),name,hpMultiplier:hp[i],attackMultiplier:1+i*.15,normal:normalPools[i],elite:elitePools[i],boss:i<3?'rock_golem_boss':i<6?'cyclops_boss':i<8?'hydra_boss':'tech_block_golem_boss'}));
export function dungeonTier(value){const match=/^(?:dungeon_|d)?([1-9]|10)$/.exec(String(value??''));return match?DUNGEON_TIERS[Number(match[1])-1]:undefined;}
export function encounterTypes(tier=1){const d=DUNGEON_TIERS[tier-1];return [...Array.from({length:50},(_,i)=>d.normal[i%d.normal.length]),...Array.from({length:5},(_,i)=>d.elite[i%d.elite.length]),d.boss];}
// Compatibility for the cost report: one complete tier-1 encounter, not timed waves.
export const WAVES=[{name:'일반 50·엘리트 5·보스 1',types:encounterTypes(1)}];
export function ceilingHeight(radius){return 4+Math.floor(22*Math.sqrt(Math.max(0,1-(radius/DUNGEON.radius)**2)));}
export function inCaveVolume(x,y,z){return Math.hypot(x,z)<=DUNGEON.radius&&y>=0&&y<=ceilingHeight(Math.hypot(x,z))+1;}
export function dungeonBlock(x,y,z){
 const radius=Math.hypot(x,z);if(!inCaveVolume(x,y,z))return undefined;
 if(y===0)return x%4===0&&z%4===0?'minecraft:sea_lantern':'minecraft:deepslate_tiles';
 if(radius>=DUNGEON.radius-2||y>=ceilingHeight(radius)-1)return (x*17+z*31+y*7)%9===0?'minecraft:tuff':'minecraft:deepslate';
 return undefined;
}
