import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,ItemStack,events,replies,forms} from './minecraftMock.mjs';
import {HITO_LINES,giveHitoEgg,openHitoEggMenu,registerHito} from '../RPG_BP_v0565/scripts/core/hito.js';
import {JOBS} from '../RPG_BP_v0565/scripts/data/jobs.js';
import {runRpgAction} from '../RPG_BP_v0565/scripts/core/rpgActions.js';
test('all 30 implemented jobs have a placeable native trainer egg, with matching resource definitions',()=>{
 assert.equal(HITO_LINES.length,18);const jobs=new Set(HITO_LINES.flatMap(l=>l.jobs));for(const job of Object.values(JOBS))if(!job.placeholder&&job.id!=='apprentice')assert.ok(jobs.has(job.id),job.id);
 for(const line of HITO_LINES){const id='rpg:hito_'+line.id,read=name=>JSON.parse(fs.readFileSync(new URL(name,import.meta.url)));const bp=read('../RPG_BP_v0565/entities/hito_'+line.id+'.json')['minecraft:entity'],rp=read('../RPG_RP_v0565/entity/hito_'+line.id+'.entity.json')['minecraft:client_entity'];assert.equal(bp.description.identifier,id);assert.equal(bp.description.is_spawnable,true);assert.ok(bp.components['minecraft:persistent']);assert.equal(bp.components['minecraft:movement'].value,0);assert.equal(rp.description.identifier,id);assert.ok(rp.description.spawn_egg);}
});
test('hito command gives an egg without spawning an NPC or replacing reserved slot zero',()=>{
 const p=player('trainer-admin',20,{commandPermissionLevel:1});let spawns=0;p.dimension.spawnEntity=()=>{spawns++;};p.slots[0]=new ItemStack('rpg:war_god_gauntlets');runRpgAction('hito',p,'투신');assert.equal(spawns,0);assert.equal(p.slots[1].typeId,'rpg:hito_war_god_spawn_egg');assert.equal(p.slots[0].typeId,'rpg:war_god_gauntlets');
 const ordinary=player('not-admin');runRpgAction('hito',ordinary,'검사');assert.equal(ordinary.slots.filter(Boolean).length,0);assert.match(ordinary.messages[0],/관리자/);
});
test('full inventory rejects egg delivery without overwriting items; invalid names do not grant',()=>{
 const p=player('full');for(let i=1;i<p.slots.length;i++)p.slots[i]=new ItemStack('minecraft:stone',64);assert.equal(giveHitoEgg(p,'검사'),false);assert.ok(p.slots.slice(1).every(i=>i.amount===64&&i.typeId==='minecraft:stone'));assert.equal(p.slots[0],undefined);assert.equal(giveHitoEgg(p,'unknown'),false);
});
test('trainer picker delivers the selected native egg and cancellation gives nothing',async()=>{
 const p=player('picker');replies.push({selection:HITO_LINES.findIndex(l=>l.id==='holy')});await openHitoEggMenu(p);assert.equal(p.slots[1].typeId,'rpg:hito_holy_spawn_egg');assert.ok(forms.some(f=>f.heading==='전직관 소환알'));const before=p.slots.filter(Boolean).length;replies.push({canceled:true});await openHitoEggMenu(p);assert.equal(p.slots.filter(Boolean).length,before);
});
test('newly placed trainers receive their label, preserving the Loto identity',()=>{
 registerHito();for(const [typeId,label]of [['rpg:hito_war_god','투신'],['rpg:hito_sword','검'],['rpg:hito_hacker','로토']]){const npc={typeId};for(const listener of events.entitySpawn.listeners)listener({entity:npc});assert.match(npc.nameTag,new RegExp(label));}
});
