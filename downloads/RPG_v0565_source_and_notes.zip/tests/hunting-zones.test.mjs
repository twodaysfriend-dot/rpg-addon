import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {huntingZone,huntingNight,HUNT_ZONE_TYPES,chooseZoneMob} from '../RPG_BP_v0565/scripts/data/huntingZones.js';
import {applyHuntingZone,enforceVanillaCaveSpawn,cavePosition,noteHuntingEggUse,registerHuntingZones} from '../RPG_BP_v0565/scripts/core/huntingZones.js';
import {world,system,events} from './minecraftMock.mjs';
const root=new URL('../RPG_BP_v0565/',import.meta.url);let serial=0;
function entity(typeId='rpg:green_goblin',at={x:0,y:64,z:0}){const tags=new Set(),dim={id:'minecraft:overworld',spawnEntity:(id,p)=>{const e=entity(id,p);e.dimension=dim;return e;}};return {id:'wild'+serial++,isValid:true,typeId,location:{...at},dimension:dim,hasTag:t=>tags.has(t),addTag:t=>tags.add(t),getRotation:()=>({x:0,y:0}),setRotation(){},remove(){this.removed=true;this.isValid=false;}};}
test('square zone boundaries use absolute X/Z, ignore Y, and continue late mobs beyond 10000',()=>{
 for(const [n,id]of [[0,'early'],[1500,'early'],[1501,'mid'],[4000,'mid'],[4001,'late'],[10000,'late'],[10001,'late']])for(const axis of ['x','z'])for(const sign of [-1,1])assert.equal(huntingZone({x:0,z:0,y:-60,[axis]:sign*n}).id,id);
 assert.equal(huntingZone({x:1500,z:1500}).id,'early');assert.equal(huntingZone({x:1500,z:1500},{metric:'circle',beyond:'late'}).id,'mid');assert.equal(huntingZone({x:10001,z:0},{metric:'square',beyond:'none'}),undefined);
});
test('night wraps game time and pools are distinct with valid registered entities',()=>{
 assert.equal(huntingNight(11999),false);assert.equal(huntingNight(12000),true);assert.equal(huntingNight(23999),true);assert.equal(huntingNight(24000),false);const ids=HUNT_ZONE_TYPES.flatMap(z=>z.pool.map(m=>m.id));assert.equal(new Set(ids).size,12);for(const id of ids)assert.ok(fs.existsSync(new URL('entities/'+id.slice(4)+'.json',root)));for(const z of HUNT_ZONE_TYPES){assert.ok(z.pool.some(m=>m.id===chooseZoneMob(z,()=>0)));assert.ok(z.pool.some(m=>m.id===chooseZoneMob(z,()=>.9999)));}
});
test('natural land spawns use the destination coordinates; transformations do not create XP/death events or recursive replacements',()=>{
 const e=entity('rpg:red_mushroom',{x:-4001,y:64,z:0}),spawn=e.dimension.spawnEntity;let replacement;e.dimension.spawnEntity=(id,p)=>{replacement=spawn(id,p);return replacement;};e.kill=()=>{throw Error('must remove');};const r=applyHuntingZone(e,{time:13000,random:()=>0});assert.equal(r.action,'replaced');assert.equal(r.zone,'late');assert.ok(e.removed);assert.ok(r.id.startsWith('rpg:elite_'));assert.equal(applyHuntingZone(replacement,{time:13000}).action,'ignored');
});
test('daytime natural land mobs disappear, while dungeon mobs, manual eggs and desert types are excluded',()=>{
 const daytime=entity();assert.equal(applyHuntingZone(daytime,{time:6000}).action,'removed');const dungeon=entity();dungeon.addTag('rpg_dungeon_mob');assert.equal(applyHuntingZone(dungeon,{time:6000}).action,'ignored');
 const manual=entity();noteHuntingEggUse({itemStack:{typeId:'rpg:green_goblin_spawn_egg'},block:{dimension:manual.dimension,location:manual.location}});assert.equal(applyHuntingZone(manual,{time:6000}).action,'ignored');const desert=entity('rpg:scorpion',{x:50000,y:64,z:50000});assert.equal(applyHuntingZone(desert,{time:6000}).action,'ignored');
});
test('all six desert spawn rules allow both day/night at any coordinates, preserving desert biome and density checks',()=>{
 for(const id of ['scorpion','mantis','deathworm','elite_scorpion','elite_mantis','elite_deathworm']){const rules=JSON.parse(fs.readFileSync(new URL('spawn_rules/'+id+'.json',root)))['minecraft:spawn_rules'];for(const c of rules.conditions){assert.deepEqual(c['minecraft:brightness_filter'],{min:0,max:15,adjust_for_weather:false});assert.match(JSON.stringify(c['minecraft:biome_filter']),/desert/);assert.ok(c['minecraft:spawns_on_surface']);assert.ok(!c['minecraft:distance_filter']);}}
});
test('vanilla cave overrides keep official biome/difficulty rules, do not override animals or Nether/End endermen',()=>{
 const files=fs.readdirSync(new URL('spawn_rules/',root)).filter(f=>f.startsWith('vanilla_'));assert.equal(files.length,14);assert.ok(!files.some(f=>/cow|pig\.|sheep|chicken/.test(f)));
 for(const file of files){const rules=JSON.parse(fs.readFileSync(new URL('spawn_rules/'+file,root)))['minecraft:spawn_rules'];for(const c of rules.conditions){const biome=JSON.stringify(c['minecraft:biome_filter']);if(file==='vanilla_enderman.json'&&/nether|the_end|warped_forest/.test(biome))continue;assert.ok(c['minecraft:spawns_underground']);assert.equal(c['minecraft:spawns_on_surface'],undefined);}}
});
test('vanilla spawn guard recognizes terrain-covered caves rather than a fixed Y level or leaf cover',()=>{
 const dim={getTopmostBlock:()=>({location:{y:70}}),getBlock:p=>({typeId:p.y===70?'minecraft:oak_leaves':p.y===63?'minecraft:grass_block':'minecraft:air'})};assert.equal(cavePosition(dim,{x:0,y:64,z:0}),false);assert.equal(cavePosition(dim,{x:0,y:50,z:0}),true);const e=entity('minecraft:zombie');e.dimension={...dim,id:'minecraft:overworld'};assert.equal(enforceVanillaCaveSpawn(e).action,'removed');const animal=entity('minecraft:cow');assert.equal(enforceVanillaCaveSpawn(animal).action,'ignored');
});
test('event integration filters only natural Spawned initialization, keeping loaded/transformed/entities from other dimensions',()=>{
 registerHuntingZones();for(const cause of ['Loaded','Event','Born','Transformed']){const e=entity();for(const fn of events.entitySpawn.listeners)fn({entity:e,cause});assert.equal(e.removed,undefined);}
 const natural=entity();world.getTimeOfDay=()=>6000;for(const fn of events.entitySpawn.listeners)fn({entity:natural,cause:'Spawned'});assert.ok(natural.removed);const nether=entity();nether.dimension.id='minecraft:nether';assert.equal(applyHuntingZone(nether,{time:13000}).action,'ignored');
});
