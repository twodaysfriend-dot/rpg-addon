import test from 'node:test';
import assert from 'node:assert/strict';
import {player,timeouts} from './minecraftMock.mjs';
import {RUNNERS} from '../RPG_BP_v0565/scripts/skills/mage.js';
import {SKILLS} from '../RPG_BP_v0565/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0565/scripts/data/jobs.js';
test('charged Zoltraak hits both five-block edges once, excludes outside targets, and retains damage and cost',()=>{
 const p=player('wide-beam'),targets=[4,5,-5,5.01].map((x,i)=>player('beam-target'+i,1,{typeId:'minecraft:zombie',health:500,location:{x,y:64.5,z:27.25}}));p.setDynamicProperty('rpg:job','sage');p.getViewDirection=()=>({x:0,y:0,z:1});
 const dim={id:'minecraft:overworld',getBlock:()=>({isSolid:false}),getEntities:q=>targets.filter(t=>Math.hypot(t.location.x-q.location.x,t.location.y-q.location.y,t.location.z-q.location.z)<=q.maxDistance),spawnParticle(){},playSound(){}};p.dimension=dim;
 for(const t of targets){t.dimension=dim;t.hits=[];t.applyDamage=n=>{t.hits.push(n);return true;};t.applyKnockback=()=>{};}
 const n=timeouts.length;RUNNERS.sage_zoltraak(p,JOBS.sage,SKILLS.sage_zoltraak);assert.ok(targets.every(t=>!t.hits.length));timeouts[n]();
 for(const t of targets.slice(0,3))assert.deepEqual(t.hits,[96]);assert.deepEqual(targets[3].hits,[]);assert.deepEqual([SKILLS.sage_zoltraak.width,SKILLS.sage_zoltraak.mana,SKILLS.sage_zoltraak.cooldown],[5,1000,600]);
});
