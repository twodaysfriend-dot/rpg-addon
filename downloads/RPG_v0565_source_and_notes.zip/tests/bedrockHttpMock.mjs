export class HttpRequest {constructor(uri){this.uri=uri;}}
export class HttpHeader {constructor(key,value){this.key=key;this.value=value;}}
export const HttpRequestMethod={Post:'Post'};
export const requests=[];
let handler=async()=>({status:200,body:'{"ids":[]}'});
export const http={request:async request=>{requests.push(request);return handler(request);}};
export const secrets={get:key=>Object.freeze({secretName:key})};
export function setHttpHandler(next){requests.length=0;handler=next;}
