import test from 'node:test';
import assert from 'node:assert/strict';
import {player,players,events,system,intervals,timeouts,world,ItemStack,clearedRuns} from './minecraftMock.mjs';
import {RUNNERS as HACKER,copyUltimatePool} from '../RPG_BP_v0565/scripts/skills/hacker.js';
import {RUNNERS as FROST} from '../RPG_BP_v0565/scripts/skills/frost.js';
import {RUNNERS as TECH,registerTechnomancer} from '../RPG_BP_v0565/scripts/skills/technomancer.js';
import {RUNNERS as DEMON} from '../RPG_BP_v0565/scripts/skills/demon.js';
import {RUNNERS as CELESTIAL,registerCelestial,throwMoonWeapon} from '../RPG_BP_v0565/scripts/skills/celestial.js';
import {SKILLS} from '../RPG_BP_v0565/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0565/scripts/data/jobs.js';
import {setSkills,setIndex,setMana,getMana,cooldownLeft} from '../RPG_BP_v0565/scripts/core/playerData.js';
import {registerInput} from '../RPG_BP_v0565/scripts/core/input.js';
import {defaultDamageTypeFor} from '../RPG_BP_v0565/scripts/core/stats.js';
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
let serial=0;
function scene(job='hacker'){
 const p=player('r553-'+serial++,40,{maxHealth:100,health:50}),targets=[],particles=[],spawned=[];
 p.setDynamicProperty('rpg:job',job);setSkills(p,JOBS[job].skills);p.getTags=()=>[];p.hasTag=()=>false;p.getViewDirection=()=>({x:0,y:0,z:1});p.getRotation=()=>({x:0,y:0});p.getHeadLocation=()=>({x:p.location.x,y:p.location.y+1.6,z:p.location.z});p.teleport=q=>p.location={...q};
 const dim={id:'minecraft:overworld',getEntities(q={}){return targets.filter(t=>!q.location||Math.hypot(t.location.x-q.location.x,t.location.y-q.location.y,t.location.z-q.location.z)<=(q.maxDistance??Infinity));},getPlayers:()=>[p],getBlock:()=>({isSolid:false,isAir:true,typeId:'minecraft:air'}),spawnParticle:(id,pos)=>particles.push({id,pos}),playSound(){},spawnEntity(id,at){spawned.push({id,at});return {isValid:true,addTag(){},remove(){this.isValid=false;},teleport(){}};}};p.dimension=dim;players.push(p);
 const mob=(x=0,z=3,y=64)=>{const t=player('r553mob-'+serial++,1,{typeId:'minecraft:zombie',maxHealth:1000,health:1000,dimension:dim,location:{x,y,z}});t.hits=[];t.applyDamage=(n,o)=>{t.hits.push({n,o});t.health-=n;return true;};t.getTags=()=>[];t.hasTag=()=>false;t.applyKnockback=()=>{};t.teleport=q=>t.location={...q};targets.push(t);return t;};
 return {p,dim,mob,particles,spawned};
}
const emit=(event,ev)=>{for(const fn of events[event].listeners)fn(ev);};
test('copy discovers every registered attack/control ultimate, excludes pure buffs and placeholders',()=>{
 const ids=copyUltimatePool().map(x=>x[0]);assert.equal(ids.length,17);
 for(const id of ['frost_absolute','moon_fullwave','tech_storm','demon_storm','revenant_execution','beast_grand_explosion'])assert.ok(ids.includes(id),id);
 const old=SKILLS.frost_shard.ultimate;SKILLS.frost_shard.ultimate=true;try{assert.ok(copyUltimatePool().some(x=>x[0]==='frost_shard'));}finally{if(old===undefined)delete SKILLS.frost_shard.ultimate;else SKILLS.frost_shard.ultimate=old;}
 for(const id of ['war_god_black_flash','fallen_sword_frenzy','beast_berserk','angel_zone','hacker_copy','death_domain'])assert.equal(ids.includes(id),false,id);
});
test('copy through actual input casts a mixed offensive ultimate, pays only copy mana/cooldown and keeps the job',()=>{
 registerInput();const {p,mob}=scene(),t=mob();p.equipment.set('Mainhand',new ItemStack(JOBS.hacker.weapon));setIndex(p,JOBS.hacker.skills.indexOf('hacker_copy'));setMana(p,200);const rng=Math.random;Math.random=()=>.999999;
 try{emit('itemUse',{source:p,itemStack:new ItemStack(JOBS.hacker.weapon)});}finally{Math.random=rng;}
 assert.equal(t.hits[0].n,20);assert.equal(getMana(p),0);assert.equal(cooldownLeft(p,'hacker_copy'),1200);assert.equal(cooldownLeft(p,'sun_descent'),0);assert.equal(p.getDynamicProperty('rpg:job'),'hacker');
});
test('copied Beast explosion completes its delayed damage on a Hacker without changing class',()=>{
 const {p,mob}=scene(),t=mob(),pool=copyUltimatePool(),index=pool.findIndex(x=>x[0]==='beast_grand_explosion'),n=timeouts.length;const rng=Math.random;let i=pool.length-1;
 // Keep every shuffle step in place, except move the selected entry to slot zero.
 Math.random=()=>{const value=i===index?0:.999999;i--;return value;};
 try{assert.equal(HACKER.hacker_copy(p,JOBS.hacker,SKILLS.hacker_copy),true);}finally{Math.random=rng;}
 for(const fn of timeouts.splice(n))fn();assert.ok(t.hits.some(h=>h.n===70));assert.equal(p.getDynamicProperty('rpg:job'),'hacker');
});
test('ice barrage follows a moving target with five unchanged 7-damage projectiles',()=>{
 const {p,mob}=scene('frost_controller'),t=mob(0,8),n=timeouts.length,run=intervals.length;
 assert.equal(FROST.frost_barrage(p,JOBS.frost_controller,SKILLS.frost_barrage),true);for(const fn of timeouts.splice(n))fn();t.location.x=7;
 const shots=intervals.slice(run);for(let step=0;step<20;step++)for(const [i,fn] of shots.entries())if(!clearedRuns.has(run+i+1))fn();assert.equal(t.hits.length,5);assert.ok(t.hits.every(h=>h.n===7));
});
test('ice barrage stops at walls and does not launch or spend when no target exists',()=>{
 const empty=scene('frost_controller');assert.equal(FROST.frost_barrage(empty.p,JOBS.frost_controller,SKILLS.frost_barrage),false);
 const {p,mob,dim}=scene('frost_controller'),t=mob(0,8),n=timeouts.length,run=intervals.length;FROST.frost_barrage(p,JOBS.frost_controller,SKILLS.frost_barrage);for(const fn of timeouts.splice(n))fn();dim.getBlock=()=>({isSolid:true});for(const fn of intervals.slice(run))fn();assert.equal(t.hits.length,0);
});
test('tech prison chooses nearest enemy instead of aim point, then prefers a marked farther enemy',()=>{
 const {p,mob,spawned}=scene('technomancer'),near=mob(-2,0),far=mob(0,8);
 assert.equal(TECH.tech_prison(p,JOBS.technomancer,SKILLS.tech_prison),true);assert.equal(spawned.at(-1).at.x,-2);
 TECH.tech_ray(p,JOBS.technomancer,SKILLS.tech_ray);assert.ok(far.hits.length);TECH.tech_prison(p,JOBS.technomancer,SKILLS.tech_prison);assert.equal(spawned.at(-1).at.z,8);
 system.currentTick+=201;TECH.tech_prison(p,JOBS.technomancer,SKILLS.tech_prison);assert.equal(spawned.at(-1).at.x,near.location.x);
});
test('empty tech prison fails and ray marking immediately enables the homing sphere',()=>{
 const {p,mob}=scene('technomancer');assert.equal(TECH.tech_prison(p,JOBS.technomancer,SKILLS.tech_prison),false);const t=mob(0,6);
 assert.equal(TECH.tech_sphere(p,JOBS.technomancer,SKILLS.tech_sphere),false);TECH.tech_ray(p,JOBS.technomancer,SKILLS.tech_ray);assert.equal(TECH.tech_sphere(p,JOBS.technomancer,SKILLS.tech_sphere),true);assert.ok(t.hits.length);
});
test('vampirism hits all enemies through 10 blocks and draws lasting tethers without extra damage',()=>{
 const {p,mob,particles}=scene('demon'),a=mob(0,9.9),b=mob(-6,0),out=mob(0,10.1),n=intervals.length;
 DEMON.demon_vampirism(p,JOBS.demon,SKILLS.demon_vampirism);assert.deepEqual([a.hits.length,b.hits.length,out.hits.length],[1,1,0]);assert.equal(p.effects.get('regeneration').amplifier,1);
 const count=particles.length;intervals[n]();assert.ok(particles.length>count);assert.equal(a.hits.length,1);assert.equal(b.hits.length,1);
});
test('sun and moon store 500 light while active +35 and passive +4 charge stay unchanged',()=>{
 registerCelestial();for(const [job,key,skill,time]of [['sun_heir','rpg:sun_light','sun_charge',1000],['moon_heir','rpg:moon_light','moon_charge',13000]]){
 const {p}=scene(job);world.getTimeOfDay=()=>time;p.setDynamicProperty(key,450);CELESTIAL[skill](p,JOBS[job],SKILLS[skill]);assert.equal(p.getDynamicProperty(key),485);CELESTIAL[skill](p,JOBS[job],SKILLS[skill]);assert.equal(p.getDynamicProperty(key),500);
 p.setDynamicProperty(key,490);const tick=intervals.find(fn=>String(fn).includes('energy(p,true)+CHARGE'));tick();assert.equal(p.getDynamicProperty(key),494);
 }
});
test('Sun slash multiplies the next actual melee by four and applies slow III for one second',()=>{
 const {p,mob}=scene('sun_heir'),t=mob(0,2);p.equipment.set('Mainhand',new ItemStack('rpg:sun_heir_axe'));p.setDynamicProperty('rpg:sun_light',100);CELESTIAL.sun_slash(p,JOBS.sun_heir,SKILLS.sun_slash);
 t.health-=10;emit('entityHurt',{hurtEntity:t,damage:10,damageSource:{damagingEntity:p,cause:'entityAttack'}});assert.equal(t.health,960);assert.equal(t.effects.get('slowness').amplifier,2);assert.equal(t.effects.get('slowness').duration,20);
});
test('radiant beam follows live yaw and pitch in both damage and VFX',()=>{
 const {p,mob,particles}=scene('sun_heir'),forward=mob(0,5),up=mob(0,0,69),side=mob(5,0),n=intervals.length;p.setDynamicProperty('rpg:sun_light',500);CELESTIAL.sun_radiant_beam(p,JOBS.sun_heir,SKILLS.sun_radiant_beam);const tick=intervals[n];
 for(let i=0;i<20;i++)tick();p.getViewDirection=()=>({x:0,y:1,z:0});tick();tick();assert.ok(up.hits.length>0);assert.equal(forward.hits.length,0);assert.ok(particles.some(f=>f.id==='rpg:radiant_core'&&f.pos.y>70));
 p.getViewDirection=()=>({x:1,y:0,z:0});for(let i=0;i<4;i++)tick();assert.ok(side.hits.length>0);assert.equal(forward.hits.length,0);
});
test('all three Moon attacks use STR physical scaling and requested base damage, regardless of high MAG',()=>{
 for(const id of ['moon_slash','moon_homing','moon_fullwave']){
 const {p,mob}=scene('moon_heir'),t=mob(0,3),n=intervals.length;p.setDynamicProperty('rpg:moon_light',500);p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:105,mag:1005,vit:5,int:5}));CELESTIAL[id](p,JOBS.moon_heir,SKILLS[id]);if(id==='moon_homing'){const tick=intervals[n];for(let i=0;i<6&&!t.hits.length;i++)tick();}
 assert.equal(t.hits.length,1);close(t.hits[0].n,SKILLS[id].damage*1.7);assert.equal(defaultDamageTypeFor(p),'physical');
 }
});

test('split Moon discs also use physical STR scaling and preserve separate hits',()=>{
 const {p,mob}=scene('moon_heir'),t=mob(0,3),n=timeouts.length,start=intervals.length;p.setDynamicProperty('rpg:moon_light',500);p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:105,mag:1005,vit:5,int:5}));p.equipment.set('Mainhand',new ItemStack('rpg:moon_heir_blade'));
 CELESTIAL.moon_chakram_split(p,JOBS.moon_heir,SKILLS.moon_chakram_split);assert.equal(throwMoonWeapon(p),true);for(const fn of timeouts.splice(n))fn();const attacks=intervals.slice(start);
 for(let step=0;step<10;step++)for(const [i,fn]of attacks.entries())if(!clearedRuns.has(start+i+1))fn();
 assert.equal(t.hits.filter(h=>Math.abs(h.n-6.8)<1e-8).length,3);assert.equal(t.hits.filter(h=>Math.abs(h.n-18.7)<1e-8).length,1);
});
