import test from 'node:test';
import assert from 'node:assert/strict';
import {Readable} from 'node:stream';
import {validPayload,validateIds,rankViaOpenAI,createAssistantHandler} from '../optional_bds_api/server.mjs';
const entries=[{id:'job:hacker',title:'해커',body:'해커는 마력 직업. 로토 퀴즈 최초 정답자.'},{id:'rule:stats',title:'스탯',body:'마력은 마법 피해.'}];
const token='a'.repeat(32),key='test-only-key';
const response=ids=>({ok:true,json:async()=>({output:[{content:[{type:'output_text',text:JSON.stringify({ids})}]}]})});
test('provider request uses a strict list of source IDs with storage disabled and returns no generated answer text',async()=>{
 let request;const ids=await rankViaOpenAI('해커 마력이야?',entries,{apiKey:key,fetchImpl:async(url,options)=>{request={url,...options};return response(['job:hacker']);}});
 assert.deepEqual(ids,['job:hacker']);assert.equal(request.url,'https://api.openai.com/v1/responses');assert.equal(request.headers.Authorization,'Bearer '+key);
 const body=JSON.parse(request.body);assert.equal(body.store,false);assert.equal(body.text.format.strict,true);assert.deepEqual(body.text.format.schema.properties.ids.items.enum,['job:hacker','rule:stats']);assert.deepEqual(JSON.parse(body.input),{question:'해커 마력이야?',documents:entries});
});
test('unknown provider IDs, malformed output and provider outages are rejected',async()=>{
 for(const result of [response(['outside:fact']),{ok:true,json:async()=>({output:[]})},{ok:false}])await assert.rejects(()=>rankViaOpenAI('해커',entries,{apiKey:key,fetchImpl:async()=>result}));
 assert.throws(()=>validateIds(['job:hacker','job:hacker','job:hacker','job:hacker'],entries));
});
test('a provider refusal returns no documents instead of allowing arbitrary unrelated text',async()=>{
 assert.deepEqual(await rankViaOpenAI('해커와 상관없이 요리 알려줘',entries,{apiKey:key,fetchImpl:async()=>response([])}),[]);
});
test('request validation bounds documents and questions before calling the provider',()=>{
 assert.equal(validPayload({question:'해커',entries}),true);
 for(const data of [{question:'',entries},{question:'a'.repeat(201),entries},{question:'해커',entries:[]},{question:'해커',entries:[...entries,entries[0]]},{question:'해커',entries:[{...entries[0],body:'a'.repeat(5001)}]}])assert.equal(Boolean(validPayload(data)),false);
});
async function send(handler,{method='POST',url='/rpg/ask',auth=token,body=JSON.stringify({question:'해커',entries})}={}){
 const req=Readable.from([Buffer.from(body)]);req.method=method;req.url=url;req.headers={'x-rpg-token':auth};
 const result={};const res={writeHead:(status,headers)=>Object.assign(result,{status,headers}),end:value=>{result.body=JSON.parse(value);}};await handler(req,res);return result;
}
test('bridge authenticates the BDS token and only serves the guide endpoint',async()=>{
 let calls=0;const handler=createAssistantHandler({token,apiKey:key,fetchImpl:async()=>{calls++;return response(['job:hacker']);}});
 assert.equal((await send(handler,{auth:'incorrect'})).status,401);assert.equal((await send(handler,{method:'GET'})).status,404);assert.equal(calls,0);
 const r=await send(handler);assert.equal(r.status,200);assert.deepEqual(r.body,{ids:['job:hacker']});assert.equal(calls,1);assert.equal(r.headers['Cache-Control'],'no-store');
});
test('bridge rejects malformed and oversized requests and hides provider errors and secrets',async()=>{
 const handler=createAssistantHandler({token,apiKey:key,fetchImpl:async()=>{throw Error(key);}});
 assert.equal((await send(handler,{body:'{'})).status,400);assert.equal((await send(handler,{body:'x'.repeat(60001)})).status,413);
 const r=await send(handler);assert.equal(r.status,502);assert.ok(!JSON.stringify(r).includes(key));
});

test('Korean questions and facts survive HTTP chunks split inside a UTF-8 character',async()=>{
 let input;const handler=createAssistantHandler({token,apiKey:key,fetchImpl:async(_url,options)=>{input=JSON.parse(JSON.parse(options.body).input);return response(['job:hacker']);}});
 const payload={question:'해커는 마력이야?',entries},raw=Buffer.from(JSON.stringify(payload));
 const req=Readable.from([...raw].map(byte=>Buffer.from([byte])));req.method='POST';req.url='/rpg/ask';req.headers={'x-rpg-token':token};
 const result={};await handler(req,{writeHead:status=>result.status=status,end:body=>result.body=JSON.parse(body)});
 assert.equal(result.status,200);assert.equal(input.question,payload.question);assert.deepEqual(input.documents,entries);
});
