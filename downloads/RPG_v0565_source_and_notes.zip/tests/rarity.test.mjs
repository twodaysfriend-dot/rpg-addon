import test from 'node:test';
import assert from 'node:assert/strict';
import {ItemStack,player,EquipmentSlot} from './minecraftMock.mjs';
import {RARITIES,itemRarity} from '../RPG_BP_v0565/scripts/data/rarity.js';
import {RARITY_KEY,ARMOR_GRADE_HP} from '../RPG_BP_v0565/scripts/data/grades.js';
import {decorateRarity,refreshRarityLabels} from '../RPG_BP_v0565/scripts/core/rarityLabels.js';
import {ARMOR_LEVEL_KEY,upgradedRune} from '../RPG_BP_v0565/scripts/data/upgrades.js';
import {COMMON_WEAPONS} from '../RPG_BP_v0565/scripts/data/commonWeapons.js';
import {RUNES} from '../RPG_BP_v0565/scripts/data/equipment.js';
import {enhanceEquipped} from '../RPG_BP_v0565/scripts/core/upgrades.js';
import {setWallet} from '../RPG_BP_v0565/scripts/core/wallet.js';
import {getEquipmentBonuses} from '../RPG_BP_v0565/scripts/core/equipment.js';
import {answerRpgQuestion} from '../RPG_BP_v0565/scripts/core/rpgAssistant.js';
test('all seven common weapon types independently support all seven grades',()=>{
 assert.deepEqual(RARITIES,['일반','레어','에픽','고대','영웅','전설','신화']);
 for(const w of COMMON_WEAPONS){const item=new ItemStack(w.id);assert.equal(itemRarity(item).rank,0);for(let grade=0;grade<7;grade++){item.setDynamicProperty(RARITY_KEY,grade);assert.equal(itemRarity(item).rank,grade);}}
 assert.equal(itemRarity(new ItemStack('minecraft:diamond_sword')),undefined);assert.equal(itemRarity(new ItemStack('rpg:sword_saint')),undefined);
});
test('grade labels are idempotent and preserve custom names and unrelated properties',()=>{
 const i=new ItemStack('rpg:common_battle_sword');i.setLore(['personal lore']);i.setDynamicProperty('custom:tag',99);assert.equal(decorateRarity(i),true);assert.match(i.nameTag,/일반.*마공학 검/);assert.equal(decorateRarity(i),false);
 i.nameTag='my custom name';i.setDynamicProperty(RARITY_KEY,5);decorateRarity(i);assert.equal(i.nameTag,'my custom name');assert.ok(i.getLore().includes('personal lore'));assert.equal(i.getDynamicProperty('custom:tag'),99);assert.equal(i.getLore().filter(s=>s.startsWith('§8등급:')).length,1);
});
test('ordinary enhancement never changes rarity and refreshes level labels',()=>{
 const p=player('rarity-up'),i=new ItemStack('rpg:adventurer_helmet');i.setDynamicProperty(ARMOR_LEVEL_KEY,2);i.setDynamicProperty(RARITY_KEY,1);p.equipment.set(EquipmentSlot.Head,i);setWallet(p,{gold:10000,stone:100,dust:100});const before=getEquipmentBonuses(p).health,r=enhanceEquipped(p,'armor',EquipmentSlot.Head,undefined,{random:()=>0});assert.equal(r.ok,true);assert.equal(r.level,3);assert.equal(getEquipmentBonuses(p).health,before+1);assert.equal(itemRarity(p.equipment.get(EquipmentSlot.Head)).rank,1);assert.match(p.equipment.get(EquipmentSlot.Head).nameTag,/레어.*\+3/);
});
test('each rarity applies independent armor HP and numerical rune boosts, not resistance amp scaling',()=>{
 const p=player('grade-hp');for(let grade=0;grade<7;grade++){const i=new ItemStack('rpg:adventurer_helmet');i.setDynamicProperty(RARITY_KEY,grade);p.equipment.set(EquipmentSlot.Head,i);assert.equal(getEquipmentBonuses(p).health,ARMOR_GRADE_HP[grade]);}
 assert.ok(Math.abs(upgradedRune(RUNES.power,10,6).physical-1.6)<1e-9);assert.equal(upgradedRune(RUNES.vitality,10,6).health,48);assert.equal(upgradedRune(RUNES.absorption,10,6).lifesteal,.24);assert.equal(upgradedRune(RUNES.ward,10,6).wardAmplifier,1);
});
test('existing items default to normal, excluded items and counts remain intact',()=>{
 const p=player('rarity-old');p.slots[0]=new ItemStack('rpg:rune_power',10);p.slots[1]=new ItemStack('minecraft:diamond',64);refreshRarityLabels(p);assert.equal(p.slots[0].amount,10);assert.match(p.slots[0].nameTag,/일반/);assert.equal(p.slots[1].nameTag,undefined);
});
test('NPC factual grades explain fusion while balance opinion policy remains',async()=>{
 const a=await answerRpgQuestion('아이템 등급 순서');assert.match(a.text,/일반 → 레어 → 에픽 → 고대 → 영웅 → 전설 → 신화/);assert.match(a.text,/주장비 \+10 유지/);assert.match((await answerRpgQuestion('사기인 신화 무기 추천')).text,/밸런스 평가는 답할 수 없습니다/);
});
