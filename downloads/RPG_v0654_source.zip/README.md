# RPG v0.6.54 · 운영자 도구 재화 지급

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.54로 적용하고 월드를 다시 여세요.

1. 운영자가 `/rpg:admin`으로 관리 도구를 받고 손에 든 채 사용합니다.
2. **대상 플레이어 선택**에서 온라인 플레이어를 고릅니다.
3. **재화 지급**에서 골드·강화석·룬 가루 중 하나를 선택하고 양의 정수를 입력한 다음 확인합니다.

재화는 대상의 RPG 지갑에 즉시 추가됩니다. 지급자 지갑에서는 차감되지 않으며 대상과 운영자에게 지급 내역을 알립니다. 잔액 한도를 넘기거나 확인 전에 대상이 접속을 종료하면 지급이 취소됩니다.

모의 API에서 세 재화의 정확한 지급량, 권한 재확인, 취소, 입력 오류, 지갑 한도, 접속 종료를 검증했습니다. 실제 Bedrock 월드에서의 메뉴 동작은 인게임 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0654
```
