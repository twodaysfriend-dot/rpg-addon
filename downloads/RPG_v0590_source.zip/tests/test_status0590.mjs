import fs from 'node:fs';import assert from 'node:assert/strict';
const tasks=[],handlers={},forms=[],answers=[],routed=[];let tick=100;
const event=name=>({subscribe(fn){handlers[name]=fn;}});
const system={get currentTick(){return tick;},run:fn=>tasks.push(fn),runTimeout:fn=>tasks.push(fn),beforeEvents:{startup:event('startup')}};
const world={afterEvents:{itemUse:event('use'),playerSpawn:event('spawn'),playerLeave:event('leave')},getAllPlayers:()=>[]};
class Form{constructor(){this.buttons=[];}title(v){this.titleText=v;return this;}body(v){this.bodyText=v;return this;}button(v){this.buttons.push(v);return this;}}
class ItemStack{constructor(typeId,amount){this.typeId=typeId;this.amount=amount;}}
const props=new Map(),inventory=[];let full=false;
const inv={size:4,getItem:i=>inventory[i],addItem:i=>full?i:(inventory.push(i),undefined)};
const player={id:'p',name:'모험가',isValid:true,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),getComponent:k=>k==='minecraft:inventory'?{container:inv}:{currentValue:17,effectiveMax:24},sendMessage(){}};
globalThis.mock={world,system,ItemStack,ActionFormData:Form,getJobId:()=> 'mage',getMana:()=>90,maxManaOf:()=>200,getLevel:()=>12,getXp:()=>50,xpForNext:()=>100,getStats:()=>({str:6,mag:9,vit:7,int:8}),LEVEL_MAX:100,JOBS:{mage:{name:'마법사'}},showForm:async f=>{forms.push(f);return answers.shift()??{canceled:true};}};
let src=fs.readFileSync('/workspace/status0590/RPG_BP_v0578/scripts/core/statusTablet.js','utf8').replace(/^import .*;\n/gm,'');src='const {world,system,ItemStack,ActionFormData,getJobId,getMana,maxManaOf,getLevel,getXp,xpForNext,getStats,LEVEL_MAX,JOBS,showForm}=globalThis.mock;\n'+src;
const m=await import('data:text/javascript;base64,'+Buffer.from(src).toString('base64'));
m.registerStatusTablet((action,p)=>routed.push([action,p.id]));
function flush(){while(tasks.length)tasks.shift()();}
flush();assert.equal(m.STATUS_ACTIONS.length,18);
assert.match(m.statusBody(player),/HP 17 \/ 24/);assert.match(m.statusBody(player),/MP 90 \/ 200/);assert.match(m.statusBody(player),/마법사.*Lv.12/);assert.match(m.statusBody(player),/EXP 50 \/ 100/);
assert.equal((m.resourceBar(-1,100).match(/■/g)||[]).length,10);assert.equal((m.resourceBar(999,100).match(/■/g)||[]).length,10);
for(let i=0;i<16;i++){answers.push({selection:i});await m.openStatusTablet(player);flush();assert.deepEqual(routed.at(-1),[m.STATUS_ACTIONS[i].action,'p']);}
const before=routed.length;answers.push({selection:16},{selection:17});const count=forms.length;await m.openStatusTablet(player);flush();assert.equal(forms.length,count+2);assert.equal(routed.length,before);
for(const response of [{canceled:true},{selection:99},{selection:-1}]){answers.push(response);await m.openStatusTablet(player);flush();assert.equal(routed.length,before);}
assert.equal(forms[0].buttons.length,18);assert.equal(forms[0].titleText,m.STATUS_TITLE);
full=true;m.giveStatusTablet(player);assert.equal(props.get('rpg:status_tablet_given_v1'),undefined);full=false;m.giveStatusTablet(player);assert.equal(inventory.length,1);m.giveStatusTablet(player);assert.equal(inventory.length,1);assert.equal(inventory[0].amount,1);
let component;handlers.startup({itemComponentRegistry:{registerCustomComponent:(name,def)=>component=def}});answers.push({selection:17});const n=forms.length;component.onUse({source:player});handlers.use({source:player,itemStack:{typeId:m.STATUS_TABLET}});flush();await Promise.resolve();flush();assert.equal(forms.length,n+1);assert.equal(inventory[0].amount,1);
console.log('PASS: 18 buttons, 16 action routes, refresh/close/cancel, live-data snapshot, bar bounds, inventory-full retry, one-time grant, nonconsumption, duplicate-use debounce');
