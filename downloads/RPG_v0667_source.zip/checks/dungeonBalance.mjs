import fs from 'node:fs';
import assert from 'node:assert/strict';
import {DUNGEON_TIERS} from '../RPG_BP_v0638/scripts/data/dungeons.js';
import {DUNGEON_HEALTH_PRESSURE,MONSTER_LEVELS,dungeonMonsterLevel,monsterCombatMultipliers,monsterDefenseFor} from '../RPG_BP_v0638/scripts/data/monsterLevels.js';
import {MONSTER_BASE_STATS,DUNGEON_BALANCE} from '../RPG_BP_v0638/scripts/data/dungeonBalance.js';
import {LEVELED_MONSTERS} from '../RPG_BP_v0638/scripts/data/leveledMonsters.js';
const root=process.argv[2]??'.';
const close=(a,b,e=1e-6)=>assert.ok(Math.abs(a-b)<e,`${a} != ${b}`);
let cases=0;
for(const id of LEVELED_MONSTERS){
 const e=JSON.parse(fs.readFileSync(`${root}/RPG_BP_v0638/entities/${id.split(':')[1]}.json`))['minecraft:entity'];
 const base=e.components;
 const profile=MONSTER_BASE_STATS[id.split(':')[1]];
 assert.equal(profile.health,base['minecraft:health'].max);assert.equal(profile.attack,base['minecraft:attack'].damage);
 for(const level of MONSTER_LEVELS){
  const g=e.component_groups['rpg:level_'+level];
  close(g['minecraft:health'].max,Number((base['minecraft:health'].max*((1+(level-1)*.035)*.9)).toFixed(2)));
  close(g['minecraft:damage_sensor'].triggers[0].damage_multiplier,1);
  assert.equal(monsterDefenseFor(level),1);
 }
 for(const t of DUNGEON_TIERS)for(const kind of ['normal','elite','boss'])for(let index=0;index<(kind==='normal'?3:1);index++){
  const level=dungeonMonsterLevel(t.tier,kind,index),ctx={tier:t.tier,kind,index};
  const oldReduction=1-1/((1+(level-1)*.004)*(t.tier>=2?1+(t.tier-2)*.04:1));
  const g=e.component_groups[`rpg:dungeon_scaled_${t.tier}_${kind}_${index}`];
  close(1-g['minecraft:damage_sensor'].triggers[0].damage_multiplier,oldReduction*.64);
  const m=monsterCombatMultipliers(level,ctx);
  close(g['minecraft:health'].max,Number((base['minecraft:health'].max*m.health).toFixed(2)),.011);
  close(g['minecraft:attack'].damage,Number((base['minecraft:attack'].damage*m.attack).toFixed(2)),.011);
  cases++;
 }
}
const expectedBossHealth=[1000,5000,7500,10000,12500,15000,27500,30000,33000,40000];
const expectedBossAttack=[14,20,28,40,55,72,92,115,145,180];
let previous={boss:0,normal:0,elite:0};
for(const t of DUNGEON_TIERS){
 const file=id=>JSON.parse(fs.readFileSync(`${root}/RPG_BP_v0638/entities/${id}.json`))['minecraft:entity'];
 const boss=file(t.boss).component_groups[`rpg:dungeon_scaled_${t.tier}_boss_0`];
 assert.equal(boss['minecraft:health'].max,expectedBossHealth[t.tier-1]);
 assert.equal(boss['minecraft:attack'].damage,expectedBossAttack[t.tier-1]);
 // Scripted boss moves use the same multiplier as native melee damage.
 close(monsterCombatMultipliers(dungeonMonsterLevel(t.tier,'boss'),{tier:t.tier,kind:'boss'}).attack*file(t.boss).components['minecraft:attack'].damage,expectedBossAttack[t.tier-1]);
 for(const kind of ['normal','elite']){
  let max=0;
  for(const id of t[kind])for(let i=0;i<(kind==='normal'?3:1);i++){
   const e=file(id),g=e.component_groups[`rpg:dungeon_scaled_${t.tier}_${kind}_${i}`];
   assert.ok(g['minecraft:health'].max<=DUNGEON_BALANCE[t.tier-1][kind+'Health']+.01);
   assert.ok(g['minecraft:attack'].damage<=DUNGEON_BALANCE[t.tier-1][kind+'Attack']+.01);
   // Levels and roles remain distinct, and trimming cannot buff ordinary mobs.
   const level=dungeonMonsterLevel(t.tier,kind,i),kindHp=kind==='elite'&&t.tier>=2?1.35:1;
   const oldHp=e.components['minecraft:health'].max*(1+(level-1)*.035)*t.hpMultiplier*kindHp*DUNGEON_HEALTH_PRESSURE[t.tier-1];
   assert.ok(g['minecraft:health'].max<=oldHp+.011);
   max=Math.max(max,g['minecraft:health'].max);
  }
  assert.ok(max>previous[kind],`${kind} peak health progression at tier ${t.tier}`);previous[kind]=max;
 }
}
close(monsterDefenseFor(260,{tier:10,kind:'boss'}),.5981377626957195);
console.log(`${cases} dungeon groups: ten boss HP/attack targets, normal/elite ceilings and peak HP progression, scripted/native attack parity, no ordinary mob HP buffs, wild reduction zero, dungeon reduction original ×0.64`);
