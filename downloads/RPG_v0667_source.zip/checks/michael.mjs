import vm from 'node:vm';import fs from 'node:fs';import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-dev/v0638',bp=root+'/RPG_BP_v0638/';
async function load(file,bindings={}){const source=fs.readFileSync(bp+file,'utf8'),context=vm.createContext({console}),m=new vm.SourceTextModule(source,{context});await m.link(async spec=>{const names=new Set();for(const hit of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(hit[2]===spec)for(const n of hit[1].split(','))names.add(n.trim().split(/\s+as\s+/)[0]);return new vm.SyntheticModule([...names],function(){for(const n of names)this.setExport(n,bindings[n]??(()=>{}));},{context});});await m.evaluate();return m.namespace;}
const defs=(await load('scripts/data/skills.js')).SKILLS;
function setup(){let next=0;const timers=new Map(),hooks={},players=[],hits=[],particles=[],world={getAllPlayers:()=>players},system={currentTick:0,run:fn=>{timers.set(++next,{fn,due:system.currentTick+1});return next;},runInterval:(fn,n)=>{timers.set(++next,{fn,due:system.currentTick+n,period:n});return next;},clearRun:id=>timers.delete(id)};
 world.afterEvents=new Proxy({},{get:(_,key)=>({subscribe:fn=>(hooks[key]??=[]).push(fn)})});
 const dim={id:'minecraft:overworld',blocked:false,spawnParticle:(id,at)=>particles.push({id,at}),playSound:()=>{}};
 function player(id,job='mage'){const props=new Map(),native=new Map(),p={id,job,typeId:'minecraft:player',isValid:true,hp:50,location:{x:0,y:64,z:1},dimension:dim,getComponent:k=>k==='minecraft:health'?{currentValue:p.hp,effectiveMax:100,setCurrentValue:n=>p.hp=n}:undefined,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),setProperty:(k,v)=>native.set(k,v),getProperty:k=>native.get(k),sendMessage:()=>{}};players.push(p);return p;}
 function step(n){for(let i=0;i<n;i++){system.currentTick++;for(const [id,t]of [...timers])if(timers.has(id)&&t.due<=system.currentTick){if(t.period)t.due+=t.period;else timers.delete(id);t.fn();}}}
 const bindings={world,system,getJobId:p=>p.job,getSkills:p=>p.skills??[],areAllies:(a,b)=>a.id!==b.id&&!b.enemy,pvpOwner:p=>p?.owner??p,resurrectionPvpBlocked:p=>p?.pvp===true};
 return {world,system,dim,players,hits,particles,player,step,hooks,bindings};}
{
 const h=setup(),api=await load('scripts/core/resurrection.js',h.bindings),caster=h.player('caster','michael'),a=h.player('a'),b=h.player('b'),c=h.player('c');
 assert.equal(api.markResurrection(caster,a),true);assert.equal(api.markResurrection(caster,a),false);assert.equal(api.markResurrection(caster,b),true);assert.equal(api.markResurrection(caster,c),false);assert.equal(api.markResurrection(caster,caster),false);
 a.hp=2;const mob={id:'monster',typeId:'minecraft:zombie'};assert.equal(api.tryResurrection(a,mob,0),true);assert.equal(a.hp,100);assert.equal(a.getProperty(api.RESURRECTION_ARMED),false);assert.equal(api.tryResurrection(a,mob,0),false);assert.equal(api.markResurrection(caster,c),true);
 assert.equal(api.tryResurrection(b,{typeId:'minecraft:player'},0),false);assert.equal(api.tryResurrection(b,{owner:{typeId:'minecraft:player'}},0),false);assert.equal(api.tryResurrection(b,{typeId:'minecraft:zombie',hasTag:()=>true},0),false,'offline player summon excluded');assert.equal(b.hp,50);
 b.pvp=true;api.tickResurrection();assert.equal(b.getProperty(api.RESURRECTION_ARMED),false);assert.equal(api.tryResurrection(b,mob,0),false);b.pvp=false;api.tickResurrection();assert.equal(b.getProperty(api.RESURRECTION_ARMED),true);
 b.setProperty(api.RESURRECTION_ARMED,false);b.setProperty(api.RESURRECTION_PENDING,true);api.tickResurrection();assert.equal(b.hp,100);assert.equal(b.getProperty(api.RESURRECTION_PENDING),false);
 b.setProperty(api.RESURRECTION_PENDING,true);api.tickResurrection();assert.equal(b.getProperty(api.RESURRECTION_PENDING),false,'late orphan flag cleared');
 c.dimension={id:'minecraft:nether'};api.tickResurrection();assert.equal(c.getProperty(api.RESURRECTION_ARMED),false);
 console.log('Resurrection: per-caster two allies, no stacking/self; native pending and direct lethal paths consume once/full heal; player/projectile PvP excluded, PvP suspension/rearm, dimension cleanup and orphan flag reset');
}
{
 const h=setup(),api=await load('scripts/core/resurrection.js',h.bindings),caster=h.player('caster','michael'),a=h.player('ally');api.registerResurrection();h.step(1);
 assert.equal(api.markResurrection(caster,a),true);for(const fn of h.hooks.playerLeave)fn({playerId:caster.id});assert.equal(a.getProperty(api.RESURRECTION_ARMED),false);
}
function filter(f,s){
 if(f.all_of&&!f.all_of.every(v=>filter(v,s)))return false;if(f.any_of&&!f.any_of.some(v=>filter(v,s)))return false;if(f.none_of&&f.none_of.some(v=>filter(v,s)))return false;if(!f.test)return true;
 let value;if(f.test==='bool_property')value=s[f.domain]===f.value;
 else if(f.test==='is_family')value=f.value==='monster'?s.monster:f.value==='player'?s.player:false;
 else if(f.test==='has_tag')value=f.value==='rpg_vampire_sun'?s.sun:f.value==='rpg_player_owned'?s.owned:false;
 else if(f.test==='has_damage')value=f.value==='fatal'?s.fatal:f.value===s.cause;
 else throw Error('Unknown filter '+f.test);
 return f.operator==='!='?!value:!!value;
}
{
 const e=JSON.parse(fs.readFileSync(bp+'entities/player.json'))['minecraft:entity'],sensors=[e.components['minecraft:damage_sensor'],...Object.values(e.component_groups).map(g=>g['minecraft:damage_sensor']).filter(Boolean)];
 const choose=(sensor,state)=>sensor.triggers.filter(t=>(t.cause==='all'||t.cause===state.cause)&&filter(t.on_damage.filters,state));
 for(const sensor of sensors){
  const state={monster:true,player:false,owned:false,sun:false,cause:'entity_attack',fatal:true,'rpg:resurrection_armed':true,'rpg:resurrection_pending':false};
  let t=choose(sensor,state);assert.equal(t.length,1);assert.equal(t[0].deals_damage,false);assert.equal(t[0].on_damage.event,'rpg:resurrection_save');
  for(const change of [{'rpg:resurrection_armed':false},{fatal:false},{monster:false,player:true},{owned:true},{monster:false,cause:'projectile'},{monster:false,cause:'void'}]){t=choose(sensor,{...state,...change});assert.equal(t.length,1,JSON.stringify(change));assert.equal(t[0].deals_damage,true,JSON.stringify(change));}
  for(const cause of ['fall','drowning','suffocation','fire','fire_tick','lava','starve','contact','wither']){t=choose(sensor,{...state,monster:false,cause});assert.equal(t.length,1,cause);assert.equal(t[0].deals_damage,false,cause);}
  t=choose(sensor,{...state,'rpg:resurrection_armed':false,'rpg:resurrection_pending':true,fatal:false});assert.equal(t.length,1);assert.equal(t[0].deals_damage,false);
 }
 const event=e.events['rpg:resurrection_save'].set_property;assert.equal(event['rpg:resurrection_armed'],false);assert.equal(event['rpg:resurrection_pending'],true);
 console.log('Native player policy: exclusive fatal PvE save in all '+sensors.length+' base/ward sensors; ordinary damage, player/owned attacks, unknown projectiles and void retain normal damage; pending one-tick handoff and save event properties verified');
}
{
 const h=setup(),caster=h.player('caster','michael');caster.location={x:0,y:64,z:0};
 const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
 const enemy=(id,x,z)=>({id,isValid:true,typeId:'minecraft:zombie',hp:100,location:{x,y:64,z},dimension:h.dim,getComponent:()=>undefined});
 const near=enemy('near',0,4),far=enemy('far',9,2),ally=enemy('ally',1,0);ally.ally=true;
 let targets=[ally,far,near],recent=far;
 const mod=await load('scripts/skills/michael.js',{...h.bindings,CONFIG:{pvp:true},getLastHit:()=>recent,
   particle:(dim,id,at)=>dim.spawnParticle(id,at),canUseSkill:(p,id,jobs)=>jobs.includes(p.job),
   VANILLA_HOSTILES:new Set(['zombie']),LEVELED_MONSTERS:[],healthAlive:e=>e.hp>0,areAllies:(p,e)=>!!e.ally,
   dist3:distance,hurt:(e,p,n,type)=>{h.hits.push({id:e.id,n,type});return true;},
   headPos:p=>({...p.location,y:p.location.y+1.6}),norm3:v=>{const n=Math.hypot(v.x,v.y,v.z)||1;return {x:v.x/n,y:v.y/n,z:v.z/n};},
   isSolidAt:(dim,at)=>dim.blocked&&at.z>=1.4&&at.z<2.4,getTargets:(p,at,r)=>targets.filter(e=>distance(e.location,at)<=r),
   MolangVariableMap:class{setVector3(){}}});
 const cast=target=>mod.RUNNERS.michael_holy_spear(caster,null,defs.michael_holy_spear,target);
 const spears=()=>h.particles.filter(e=>e.id==='rpg:holy_spear');
 assert.equal(cast(),true);h.step(16);
 assert.equal(h.hits.length,0);assert.equal(spears().length,16);
 spears().forEach(({at},i)=>{
   assert.ok(Math.abs(at.x-.82*Math.cos((i+1)*Math.PI/8))<1e-6);
   assert.ok(Math.abs(at.z-.82*Math.sin((i+1)*Math.PI/8))<1e-6);
   assert.ok(at.y>65.6);
 });
 h.step(2);far.location.z+=4;h.step(25);
 assert.deepEqual(h.hits,[{id:'far',n:30,type:'magic'}]);
 recent=undefined;assert.equal(cast(),true);h.step(50);assert.equal(h.hits.at(-1).id,'near');
 recent=far;assert.equal(cast(),true);far.isValid=false;h.step(50);assert.equal(h.hits.at(-1).id,'near');
 const victim={...near,id:'player',typeId:'minecraft:player',location:{...near.location}};
 assert.equal(cast(victim),true);assert.equal(h.hits.at(-1).n,20);
 const embedded=spears().at(-1).at;victim.location.x+=2;h.step(1);
 assert.equal(spears().at(-1).at.x,embedded.x+2);
 h.step(25);const count=spears().length;h.step(5);assert.equal(spears().length,count);
 const hits=h.hits.length;h.dim.blocked=true;assert.equal(cast(near),false);cast();h.step(50);assert.equal(h.hits.length,hits);
 h.dim.blocked=false;targets=[ally,enemy('distant',0,22)];assert.equal(cast(),false);
 caster.job='angel';assert.equal(cast(near),false);
 console.log('Holy Spear: one overhead revolution, recent target priority, moving target pursuit, fallback and loss, wall/range, direct hit and moving embedded spear with no extra damage');
}
for(const [name,width,height] of [['holy_spear',128,256],['holy_spear_impact',128,128],['resurrection_mark',64,64]]){
 const effect=JSON.parse(fs.readFileSync(root+'/RPG_RP_v0638/particles/rpg_'+name+'.json')).particle_effect;
 assert.equal(effect.description.identifier,'rpg:'+name);
 const tex=fs.readFileSync(root+'/RPG_RP_v0638/'+effect.description.basic_render_parameters.texture+'.png');
 const uv=effect.components['minecraft:particle_appearance_billboard'].uv;
 assert.equal(tex.readUInt32BE(16),width);assert.equal(tex.readUInt32BE(20),height);
 assert.equal(uv.texture_width,width);assert.equal(uv.texture_height,height);
}
