import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root=process.argv[2]??'.';
const read=path=>JSON.parse(fs.readFileSync(root+'/'+path));
const script=path=>fs.readFileSync(root+'/RPG_BP_v0638/scripts/core/'+path,'utf8');
const context=vm.createContext({console});
const dim={id:'overworld',getPlayers:()=>players.filter(p=>p.dimension===dim),getEntities:({type})=>type===boss?.typeId?[boss]:[]};
const empty={id:'nether',getPlayers:()=>[]};
const timers=[],animations=[],hits=[],particles=[];
const hooks={};
const world={getDimension:id=>id==='overworld'?dim:empty,afterEvents:new Proxy({},{
 get:(_obj,key)=>({subscribe:fn=>hooks[key]=fn}),
})};
const system={currentTick:0,runInterval:fn=>tickers.push(fn),runTimeout:(fn,delay)=>timers.push({fn,delay})};
const tickers=[];
let players=[],boss,wall=false,frozen=false;
const dist3=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
const bindings={world,system,EntityDamageCause:{fire:'fire',magic:'magic'},monsterAttackMultiplier:()=>1,dist3,
 healthAlive:e=>e.getComponent().currentValue>0,isTimeFrozen:e=>frozen&&e===boss,
 clearBlockPath:(_d,a,b)=>!wall || Math.max(a.z,b.z)<3 || Math.min(a.z,b.z)>3,
 particle:(dim,id,pos)=>particles.push({id,pos}),sound:()=>{}};
const motion=new vm.SourceTextModule(script('bossMotion.js'),{context});
const mechanics=new vm.SourceTextModule(script('bossMechanics.js'),{context});
await mechanics.link(async specifier=>specifier==='./bossMotion.js'?motion:new vm.SyntheticModule(Object.keys(bindings),function(){
 for (const [name,value] of Object.entries(bindings)) this.setExport(name,value);
},{context}));
await mechanics.evaluate();
const {nearestBossPlayer,registerBossMechanics}=mechanics.namespace;
registerBossMechanics();
const update=()=>tickers[0]();
function player(id,x,z,mode='survival',dimension=dim){
 return {id,dimension,location:{x,y:0,z},getGameMode:()=>mode,getComponent:()=>({currentValue:100}),applyDamage:(amount,options)=>hits.push({id,amount,cause:options.cause}),setOnFire:seconds=>hits.push({id,seconds}),addEffect:()=>{}};
}
function actor(type){
 return {id:type,typeId:'rpg:'+type,dimension:dim,location:{x:0,y:0,z:0},getComponent:()=>({currentValue:100}),setRotation:()=>{},playAnimation:name=>animations.push(name)};
}
const mapping={rock_golem_boss:['eruption',24],cyclops_boss:['eye_beam',22],hydra_boss:['fire_breath',18],tech_block_golem_boss:['arc_field',22],elite_deathworm:['sand_rupture',20]};
for(const [type,[attack,windup]] of Object.entries(mapping)){
 boss=actor(type);
 players=[player('far',6,12),player('creative',0,1,'creative'),player('nearest',0,5),player('other',0,1,'survival',empty)];
 assert.equal(nearestBossPlayer(boss,players,38,1).id,'nearest');
 system.currentTick+=500;update();system.currentTick+=40;update();
 assert.equal(hits.length,0,'wind-up deals no damage');
 const motionID='animation.rpg.'+type+'.'+attack;
 assert.equal(animations.at(-1),motionID);
 const {fn,delay}=timers.shift();assert.equal(delay,windup);
 assert.equal(motion.namespace.playBossMotion(boss),false,'melee motion cannot interrupt windup');
 fn();
 assert.ok(hits.some(hit=>hit.id==='nearest'&&hit.amount>0));
 assert.ok(hits.every(hit=>hit.id==='nearest'));
 if(type==='hydra_boss')assert.deepEqual(hits,[{id:'nearest',amount:13,cause:'fire'},{id:'nearest',seconds:3}]);
 hits.length=0;
}
boss=actor('hydra_boss');
players=[player('melee',0,4.99),player('far',0,15)];
system.currentTick+=500;update();system.currentTick+=40;update();
assert.match(animations.at(-1),/tail_sweep$/);
timers.shift().fn();
assert.equal(hits.length,0,'standing outside the tail radius avoids the hit');
players=[player('near',0,5)];
system.currentTick+=200;wall=true;update();
assert.equal(timers.length,0,'wall blocks breath target acquisition');
wall=false;update();assert.equal(timers.length,1);
wall=true;timers.shift().fn();assert.equal(hits.length,0,'new wall blocks damage');
system.currentTick+=200;wall=false;update();
players[0].location.x=12;timers.shift().fn();assert.equal(hits.length,0,'sidestep avoids the locked fire lane');
players[0].location.x=0;
system.currentTick+=200;update();frozen=true;timers.shift().fn();assert.equal(hits.length,0,'frozen boss never damages on delayed impact');
assert.ok(particles.some(p=>p.id==='minecraft:basic_flame_particle'));
const animationsDoc=read('RPG_RP_v0638/animations/rpg_boss_motion.animation.json').animations;
for(const [type,patterns] of Object.entries({...mapping,hydra_boss:['fire_breath','tail_sweep']})){
 const names=type==='hydra_boss'?patterns:patterns.slice(0,1);
 const entity=read('RPG_RP_v0638/entity/'+type+'.entity.json')['minecraft:client_entity'].description;
 const model=type==='elite_deathworm'?'rpg_elite_deathworm_v98':type;
 const bones=new Set(read('RPG_RP_v0638/models/entity/'+model+'.geo.json')['minecraft:geometry'][0].bones.map(b=>b.name));
 for(const name of names){
  const animation=animationsDoc[entity.animations[name]];
  assert.ok(animation.animation_length>0);
  for(const bone of Object.keys(animation.bones))assert.ok(bones.has(bone),type+' missing '+bone);
 }
}
console.log('Five custom boss patterns, six animations, nearest target, Hydra five-block threshold, wall, dodge and freeze checks passed');
