# RPG v0.6.67 · 검사 발도술과 보스 기믹

- 검사의 발도술은 접근 가능한 가장 가까운 적에게 최대 15칸 돌진하고 이동 경로 주변에서 최대 3마리를 한 번씩 벱니다. 타격당 기본 물리 피해는 섬멸 41의 3/5인 24.6입니다. 검성은 섬멸을 사용합니다.
- 처치 룬 가루는 일반 몬스터가 30%로 1개, 엘리트가 2개, 보스가 12개를 지급합니다.
- 커스텀 보스 5종은 시야 안에서 가장 가까운 공격 가능 플레이어를 5틱마다 다시 찾습니다. 기믹은 공격 전에 범위 이펙트와 전용 동작으로 예고합니다.

| 보스 | 기믹 |
|---|---|
| 바위 골렘 | 목표가 서 있던 위치에 암석 분출 |
| 외눈 거인 | 눈을 들어 올린 뒤 예고된 방향으로 직선 광선 |
| 히드라 | 5칸 이상 떨어진 목표에게 화염 브레스, 근거리에서는 꼬리 휩쓸기 |
| 마공학 골렘 | 목표와 양옆 세 곳에 전격 장판 |
| 엘리트 데스웜 | 몸을 들어 올렸다 내리찍어 목표 방향으로 모래 균열 |

Bedrock 1.21.100 이상에서 세 팩을 v0.6.67로 활성화하세요. 모의 게임 테스트로 공격 판정, 시야 차단, 히드라 5칸 경계와 신규 애니메이션 연결을 확인했습니다. 실제 플레이에서의 AI 추적과 모션 렌더링은 별도 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0667
```
