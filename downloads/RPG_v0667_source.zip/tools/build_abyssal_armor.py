"""Compose abyssal armor with existing native race, ward and resurrection sensors.

Keep native armor and Protection enchantments. Above Bedrock's 20 armor cap,
each overflow point reduces remaining damage by 4%; toughness adds 1% per point.
Damage sensor triggers are mutually exclusive; resurrection triggers stay intact.
"""
import copy
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
path = root / 'RPG_BP_v0638/entities/player.json'
original = path.read_text()
data = json.loads(original)
entity = data['minecraft:entity']
profiles = [(0, 0)] + [(n, overflow) for n in (1, 2, 3) for overflow in range(n * 2 + 1)] + [(4, 8)]
prefix = 'rpg_abyssal_'

for container in [entity['components'], *entity['component_groups'].values()]:
    sensor = container.get('minecraft:damage_sensor')
    if not sensor:
        continue
    templates = []
    for trigger in sensor['triggers']:
        trigger = copy.deepcopy(trigger)
        f = trigger.get('on_damage', {}).get('filters', {})
        tail = f.get('all_of', [{}])[-1]
        if tail.get('test') == 'has_tag' and str(tail.get('value', '')).startswith(prefix):
            continue
        if 'none_of' in tail and any(str(x.get('value', '')).startswith(prefix) for x in tail['none_of']):
            trigger['on_damage']['filters'] = f['all_of'][0]
        templates.append(trigger)
    result = []
    for template in templates:
        if 'damage_multiplier' not in template:
            result.append(template)
            continue
        for count, overflow in profiles:
            trigger = copy.deepcopy(template)
            condition = ({'none_of': [{'test': 'has_tag', 'subject': 'self', 'value': 'rpg_abyssal_active'}]}
                         if not count else {'test': 'has_tag', 'subject': 'self', 'value': prefix + str(count * 9 + overflow)})
            trigger['on_damage']['filters'] = {'all_of': [template['on_damage']['filters'], condition]}
            trigger['damage_multiplier'] = round(template['damage_multiplier'] * (1 - overflow * .04) * (1 - count * .04), 10)
            result.append(trigger)
    sensor['triggers'] = result

groups = [f'rpg:abyssal_knockback_{n}' for n in range(5)]
for count, key in enumerate(groups):
    entity['component_groups'][key] = {'minecraft:knockback_resistance': {'value': round(count * .2, 2)}}
    entity['events'][key] = {'sequence': [{'remove': {'component_groups': groups}}, {'add': {'component_groups': [key]}}]}
# Native profile combinations repeat filters; compact JSON keeps the pack small.
output = json.dumps(data, ensure_ascii=False, separators=(',', ':')) + '\n'
if '--check' in sys.argv:
    assert output == original, 'Stale generated abyssal armor sensors'
else:
    path.write_text(output)
print('Verified' if '--check' in sys.argv else 'Generated', '17 armor profiles across native race/ward sensors; knockback 0/20/40/60/80%')
