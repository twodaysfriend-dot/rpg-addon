import {isRpgAdmin} from './adminPermissions.js';
import {sharesBuildingGroup} from './social.js';
import {world,system} from '@minecraft/server';
import {MessageFormData} from '@minecraft/server-ui';
import {showForm} from './skillMenu.js';
import {spawnRegion} from './spawnEffects.js';
export const LAND_DEED='rpg:land_deed',LAND_KEY='rpg:town_land_v1';
const pending=new Set();let registered=false;
const dim=id=>id?.replace('minecraft:','');
export function landSelection(p,region=spawnRegion()){
 if(!region||dim(p.dimension?.id)!==dim(region.dimId))return undefined;
 const cx=Math.floor(p.location.x/16),cz=Math.floor(p.location.z/16),x=cx*16,z=cz*16;
 // Sell only full world-aligned chunks within the village.
 if(x<region.x||z<region.z||x+15>=region.x+region.size||z+15>=region.z+region.size)return undefined;
 return {cx,cz,x,z,y:region.y,dimension:region.dimId,key:[dim(region.dimId),region.x,region.y,region.z,region.size,cx,cz].join(':')};
}
export function landRecords(){
 const raw=world.getDynamicProperty(LAND_KEY);if(raw===undefined)return {};
 const data=JSON.parse(raw);if(!data||typeof data!=='object'||Array.isArray(data))throw Error('부동산 저장 데이터 오류');return data;
}
export function landOwner(selection){return selection?landRecords()[selection.key]:undefined;}
export function ownsTownChunk(p,block,region=spawnRegion()){
 if(!p)return false;
 const s=landSelection({dimension:block.dimension,location:block.location},region),owner=landOwner(s);
 return !!owner&&owner.id===p.id;
}
export function canEditTownChunk(p,block,region=spawnRegion()){
 if(!p)return false;
 const selection=landSelection({dimension:block.dimension,location:block.location},region),owner=landOwner(selection);
 return !!owner&&(owner.id===p.id||sharesBuildingGroup(p,owner));
}
export function claimTownChunk(p,expectedKey){
 const s=landSelection(p);if(!s)return {ok:false,message:'마을 안에 완전히 들어오는 16×16 청크에서 사용하세요.'};
 if(expectedKey!==undefined&&s.key!==expectedKey)return {ok:false,message:'청크가 변경됐습니다. 다시 선택하세요.'};
 const data=landRecords();if(data[s.key])return {ok:false,message:'이미 구매한 청크입니다. 소유자: '+data[s.key].name};
 const inv=p.getComponent('minecraft:inventory')?.container,slot=p.selectedSlotIndex,item=inv?.getItem(slot);
 if(item?.typeId!==LAND_DEED)return {ok:false,message:'부동산 구매권을 손에 들어 주세요.'};
 const original=item.clone(),old=world.getDynamicProperty(LAND_KEY);
 data[s.key]={id:p.id,name:p.name};const encoded=JSON.stringify(data);
 if(encoded.length>30000)return {ok:false,message:'부동산 저장 공간이 부족합니다.'};
 try{
  if(item.amount===1)inv.setItem(slot,undefined);else{item.amount--;inv.setItem(slot,item);}
  world.setDynamicProperty(LAND_KEY,encoded);
 }catch(error){let restored=true;try{inv.setItem(slot,original);}catch{restored=false;}try{world.setDynamicProperty(LAND_KEY,old);}catch{restored=false;}return {ok:false,message:restored?'구매 저장 실패로 구매권을 복구했습니다.':'구매 복구 실패. 관리자에게 문의하세요.'};}
 return {ok:true,message:'청크 ['+s.cx+', '+s.cz+'] 구매 완료. Y '+s.y+' 바닥 위부터 건축 가능 · 바닥/지하는 보호됩니다.'};
}
export async function useLandDeed(p){
 if(pending.has(p.id))return;pending.add(p.id);
 try{
  const s=landSelection(p);if(!s){p.sendMessage('§e마을 안에 완전히 들어오는 청크에서 사용하세요.');return;}
  const owner=landOwner(s);if(owner){p.sendMessage('§e이미 구매한 청크입니다. 소유자: '+owner.name);return;}
  const answer=await showForm(new MessageFormData().title('마을 부동산 구매').body('현재 청크 ['+s.cx+', '+s.cz+'] 16×16을 구매할까요?\n구매권 1개 소비 (상점 가격: 다이아몬드 5개)\n본인·같은 길드/파티 건축 가능 · 바닥 Y '+s.y+' 및 지하는 파괴 불가').button1('취소').button2('구매'),p);
  if(answer&&!answer.canceled&&answer.selection===1){const result=claimTownChunk(p,s.key);p.sendMessage((result.ok?'§a':'§e')+result.message);}
 }catch(error){p.sendMessage('§c[부동산] '+String(error));}finally{pending.delete(p.id);}
}
export function previewLand(p){
 const inv=p.getComponent('minecraft:inventory')?.container;if(inv?.getItem(p.selectedSlotIndex)?.typeId!==LAND_DEED)return;
 const s=landSelection(p);if(!s){p.onScreenDisplay.setActionBar('부동산: 마을 내부의 완전한 청크로 이동하세요.');return;}
 const owner=landOwner(s);p.onScreenDisplay.setActionBar('청크 ['+s.cx+', '+s.cz+'] '+(owner?'소유: '+owner.name+(owner.id===p.id||sharesBuildingGroup(p,owner)?' · 수정 가능':' · 수정 불가'):'구매 가능 · 사용해서 구매')+' · 바닥 Y '+s.y);
 const height=Math.max(s.y+0.15,p.location.y+0.15);
 for(let n=0;n<=16;n+=2)for(const at of [{x:s.x+n,z:s.z},{x:s.x+n,z:s.z+16},{x:s.x,z:s.z+n},{x:s.x+16,z:s.z+n}])try{p.dimension.spawnParticle('minecraft:totem_particle',{...at,y:height});}catch{}
}
system.beforeEvents.startup.subscribe(e=>{try{e.itemComponentRegistry.registerCustomComponent('rpg:land_deed',{onUse(ev){system.run(()=>useLandDeed(ev.source));}});}catch(error){console.warn('[RPG land component] '+error);}});
export function registerRealEstate(){if(registered)return;registered=true;system.runInterval(()=>{for(const p of world.getAllPlayers())try{previewLand(p);}catch(error){console.warn('[RPG land preview] '+error);}},10);world.afterEvents.playerLeave.subscribe(e=>pending.delete(e.playerId));}

export function administerTownLand(admin,target,expectedKey){
 if(!isRpgAdmin(admin))return {ok:false,message:'관리자만 토지를 지정·해제할 수 있습니다.'};
 const s=landSelection(admin);if(!s)return {ok:false,message:'마을 내부의 완전한 청크에서 사용하세요.'};
 if(expectedKey!==undefined&&expectedKey!==s.key)return {ok:false,message:'청크가 변경됐습니다. 다시 선택하세요.'};
 if(target&&(!target.isValid||target.typeId!=='minecraft:player'))return {ok:false,message:'대상 플레이어가 오프라인입니다.'};
 const oldRaw=world.getDynamicProperty(LAND_KEY),data=landRecords(),previous=data[s.key];
 if(!target&&!previous)return {ok:false,message:'해제할 소유권이 없습니다.'};
 if(target)data[s.key]={id:target.id,name:target.name};else delete data[s.key];
 const encoded=JSON.stringify(data);if(encoded.length>30000)return {ok:false,message:'부동산 저장 공간이 부족합니다.'};
 try{world.setDynamicProperty(LAND_KEY,encoded);}catch{try{world.setDynamicProperty(LAND_KEY,oldRaw);}catch{}return {ok:false,message:'토지 변경을 저장하지 못했습니다.'};}
 return {ok:true,message:'청크 ['+s.cx+', '+s.cz+'] '+(target?target.name+' 소유로 지정':'소유권 해제')+' 완료. 건축물은 유지됩니다.'};
}
export async function openAdminLand(admin,target){
 if(!isRpgAdmin(admin))return;
 const s=landSelection(admin);if(!s){admin.sendMessage('§e변경할 마을 청크에 서 주세요.');return;}
 const owner=landOwner(s);
 const res=await showForm(new MessageFormData().title(target?'토지 소유자 지정':'토지 소유권 해제').body('현재 청크 ['+s.cx+', '+s.cz+']\n현재 소유자: '+(owner?.name??'없음')+'\n'+(target?'새 소유자: '+target.name:'소유권을 해제합니다.')+'\n구매권/다이아 소비 없음 · 건축물 유지').button1('취소').button2('적용'),admin);
 if(res&&!res.canceled&&res.selection===1){const result=administerTownLand(admin,target,s.key);admin.sendMessage((result.ok?'§a':'§e')+result.message);}
}
