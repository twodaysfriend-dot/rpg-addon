import {armorAttributeLines} from '../data/equipment.js';
import {upgradeLevel} from '../data/upgrades.js';
import {world,system,EquipmentSlot} from '@minecraft/server';
import {classWeapon} from '../data/classWeapons.js';
import {RARITY_KEY,itemGrade} from '../data/grades.js';
import {itemRarity,rarityBadge} from '../data/rarity.js';
const KEY='rpg:last_grade_label';let registered=false;
export function decorateRarity(item){
 const jobWeapon=classWeapon(item?.typeId);
 const assigned=jobWeapon&&item.getDynamicProperty(RARITY_KEY)!==undefined;
 const info=itemRarity(item)??(assigned&&{...jobWeapon,rank:itemGrade(item),kind:'weapon'});if(!info)return false;
 const level=upgradeLevel(item,info.kind),label=rarityBadge(info.rank)+' '+info.name+(level?' +'+level:''),line='§8등급: '+rarityBadge(info.rank);
 const attributes=armorAttributeLines(item.typeId);
 const old=item.getLore(),lore=[line,...attributes,...old.filter(s=>!s.startsWith('§8등급:')&&!attributes.includes(s))];let changed=JSON.stringify(lore)!==JSON.stringify(old);
 if(changed)item.setLore(lore);
 const managed=info.kind==='rune'?undefined:item.getDynamicProperty(KEY);
 if(!item.nameTag||item.nameTag===managed||(assigned&&item.nameTag===item.getDynamicProperty('rpg:class_upgrade_label'))){if(item.nameTag!==label){item.nameTag=label;if(info.kind!=='rune')item.setDynamicProperty(KEY,label);changed=true;}}
 return changed;
}
export function refreshRarityLabels(p){
 try{const inv=p.getComponent('minecraft:inventory')?.container;if(inv)for(let i=0;i<inv.size;i++){const item=inv.getItem(i);if(item&&decorateRarity(item))inv.setItem(i,item);}
 const eq=p.getComponent('minecraft:equippable');if(eq)for(const slot of [EquipmentSlot.Mainhand,EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet]){const item=eq.getEquipment(slot);if(item&&decorateRarity(item))eq.setEquipment(slot,item);}}catch{}
}
export function registerRarityLabels(){if(registered)return;registered=true;system.runInterval(()=>{for(const p of world.getAllPlayers())refreshRarityLabels(p);},100);world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{if(ev.player?.isValid)refreshRarityLabels(ev.player);},20));}
