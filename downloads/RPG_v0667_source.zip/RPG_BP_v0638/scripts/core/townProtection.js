import {CITY_HOUSE_PLOTS} from '../data/fantasyCity.js';
import {landOwner,landSelection} from './realEstate.js';
import {spawnRegion} from './spawnEffects.js';
import {canEditTownChunk} from './realEstate.js';
import {registerStructureProtection} from './structureProtection.js';
const dimensionId=id=>id?.replace('minecraft:','');
export function townProtected(block,region=spawnRegion(),player,operation){
 if(!region||!block?.location||dimensionId(block.dimension?.id)!==dimensionId(region.dimId))return false;
 const {x,y,z}=block.location;
 if(x<region.x||x>=region.x+region.size||z<region.z||z>=region.z+region.size)return false;
 // Restore public remodeling of unclaimed homes, above the permanent floor.
 const house=CITY_HOUSE_PLOTS.some(p=>x-region.x>=p.x&&x-region.x<p.x+p.w&&z-region.z>=p.z&&z-region.z<p.z+p.d&&y>region.y&&y<=region.y+16);
 try{
  const selection=landSelection({dimension:block.dimension,location:block.location},region);
  if(player&&house&&!landOwner(selection))return false;
  // Placing on the floor of a public house must be allowed too.
  if(player&&operation==='support'&&Math.floor(y)===region.y&&CITY_HOUSE_PLOTS.some(p=>x-region.x>=p.x&&x-region.x<p.x+p.w&&z-region.z>=p.z&&z-region.z<p.z+p.d)&&!landOwner(selection))return false;
  if(!canEditTownChunk(player,block,region))return true;
 }catch{return true;}
 // A purchased chunk allows building on top of the permanent village floor.
 if(operation==='support'&&Math.floor(y)===region.y)return false;
 return Math.floor(y)<=region.y;
}
let registered=false;
export function registerTownProtection(){if(registered)return;registered=true;registerStructureProtection('town',(block,player,operation)=>townProtected(block,spawnRegion(),player,operation));}
