import {system, world} from '@minecraft/server';
import {getTargets, hurt, particle} from './util.js';
import {applyStatus} from './crowdControl.js';
import {areAllies} from './social.js';
import {CONFIG} from '../config.js';
import {weaponOptionChance} from '../data/commonWeapons.js';

const marks = new Map(), guards = new Map(), embers = new Map();
const health = entity => entity.getComponent('minecraft:health');

function temporary(map, key, value, ticks) {
  map.set(key, value);
  system.runTimeout(() => { if (map.get(key) === value) map.delete(key); }, ticks);
}
function enemies(player, location, radius, excluded = []) {
  return getTargets(player, location, radius).filter(e => !excluded.includes(e.id) &&
    !e.typeId.startsWith('rpg:hito_') && (e.typeId !== 'minecraft:player' ||
    !['creative','spectator'].includes(String(e.getGameMode?.()).toLowerCase())))
    .sort((a,b) => distance(a.location,location) - distance(b.location,location));
}
function distance(a,b) { return Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z); }
function deal(player,target,damage) {
  if (!player.isValid || !target.isValid || player.dimension.id !== target.dimension.id ||
      !(health(target)?.currentValue > 0)) return false;
  return hurt(target,player,damage,'fixed',{ignoreInvulnerability:true});
}
function ignite(player,target,damage) {
  const id=target.id, ember={player,damage};
  embers.set(id,ember);
  for (let tick=1;tick<=3;tick++) system.runTimeout(() => {
    if (embers.get(id)!==ember) return;
    if (target.isValid && player.isValid) deal(player,target,damage*.15);
  },tick*20);
  system.runTimeout(()=>{if(embers.get(id)===ember) embers.delete(id);},61);
}
function guardingHit(ev, before) {
  const defender=ev.hurtEntity, attacker=ev.damageSource?.damagingEntity;
  if (!guards.has(defender.id) || !(ev.damage>0) || !attacker || attacker.id===defender.id ||
      !health(attacker) || areAllies(defender,attacker) || (attacker.typeId==='minecraft:player'&&!CONFIG.pvp)) return;
  const saved=ev.damage*.35;
  if (before) ev.damage-=saved;
  else {
    const hp=health(defender);
    if (!hp || hp.currentValue<=0) return;
    hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+saved));
  }
  guards.delete(defender.id);
  system.run(()=>deal(defender,attacker,saved));
}
export function registerWeaponOptions(){
  let beforeHook=false;
  try {
    if (world.beforeEvents?.entityHurt) {
      world.beforeEvents.entityHurt.subscribe(ev=>guardingHit(ev,true));
      beforeHook=true;
    }
  } catch {}
  if (!beforeHook) world.afterEvents.entityHurt.subscribe(ev=>guardingHit(ev,false));
  world.afterEvents.entityDie.subscribe(ev=>{
    const dead=ev.deadEntity, ember=embers.get(dead.id);
    guards.delete(dead.id);
    if (!ember) return;
    embers.delete(dead.id);
    if (!ember.player.isValid || ember.player.dimension.id!==dead.dimension.id) return;
    const next=enemies(ember.player,dead.location,3,[dead.id])[0];
    if(next) ignite(ember.player,next,ember.damage);
  });
}

export function onWeaponStrike(player,target,item,damage,healthBefore,random=Math.random){
  const chance=weaponOptionChance(item);
  if (!chance) return;
  const key=JSON.stringify([player.id,target.id,item.typeId]);
  const mark=marks.get(key);
  if (mark) {
    marks.delete(key);
    if (item.typeId==='rpg:common_redmoon_blade') deal(player,target,mark.damage*.60);
    else for(const enemy of enemies(player,target.location,2,[target.id])) deal(player,enemy,damage*.35);
    return;
  }
  if (random()*100>=chance) return;
  switch(item.typeId){
    case 'rpg:common_redmoon_blade':
      temporary(marks,key,{damage},60); break;
    case 'rpg:common_battle_sword': {
      const visited=[target.id]; let origin=target.location;
      for(const multiplier of [.80,.50]){
        const enemy=enemies(player,origin,4,visited)[0];
        if(!enemy) break;
        visited.push(enemy.id); origin={...enemy.location};
        particle(player.dimension,'minecraft:electric_spark_particle',origin);
        deal(player,enemy,damage*multiplier);
      }
      break;
    }
    case 'rpg:common_magitech_greatsword': {
      const dim=player.dimension, at={...target.location};
      for(let i=0;i<12;i++){
        const angle=i*Math.PI/6;
        particle(dim,'minecraft:basic_crit_particle',{x:at.x+2.5*Math.cos(angle),y:at.y+.15,z:at.z+2.5*Math.sin(angle)});
      }
      system.runTimeout(()=>{
        if(!player.isValid || player.dimension.id!==dim.id) return;
        particle(dim,'minecraft:huge_explosion_emitter',at);
        for(const enemy of enemies(player,at,2.5)) deal(player,enemy,damage*.65);
      },16); break;
    }
    case 'rpg:common_battle_spear':
      temporary(guards,player.id,{},60); break;
    case 'rpg:common_frost_greatsword':
      applyStatus(target,'slowness',40,{amplifier:1,showParticles:true});
      temporary(marks,key,{damage},40); break;
    case 'rpg:common_flame_greatsword':
      ignite(player,target,damage); break;
    case 'rpg:common_beast_axe': {
      const execute=healthBefore<=health(target).effectiveMax*.30;
      deal(player,target,damage*(execute ? .75 : .30));
      if(execute){const hp=health(player);hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+2));}
      break;
    }
  }
}
