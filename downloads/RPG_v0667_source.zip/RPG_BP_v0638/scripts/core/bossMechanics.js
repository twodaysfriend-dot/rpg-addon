import {world,system,EntityDamageCause} from '@minecraft/server';
import {monsterAttackMultiplier} from '../data/monsterLevels.js';
import {clearBlockPath,dist3,healthAlive,particle,sound} from './util.js';
import {isTimeFrozen} from './timeStopDamage.js';
import {bossMechanicActive,playBossMotion} from './bossMotion.js';

const DIMENSIONS = ['overworld','nether','the_end'];
const FIRE = 'minecraft:basic_flame_particle';
const STONE = 'minecraft:basic_smoke_particle';
const SPARK = 'minecraft:critical_hit_emitter';
const PATTERNS = {
  'rpg:rock_golem_boss': {motion:'eruption', range:16, windup:24, cooldown:220, damage:14, radius:3, fx:STONE},
  'rpg:cyclops_boss': {motion:'eye_beam', range:23, windup:22, cooldown:230, damage:16, width:0.8, height:5.44, fx:SPARK},
  'rpg:hydra_boss': {motion:'fire_breath', range:38, windup:18, cooldown:80, damage:13, width:1, height:3, fx:FIRE},
  'rpg:tech_block_golem_boss': {motion:'arc_field', range:20, windup:22, cooldown:175, damage:15, radius:2, fx:SPARK},
  'rpg:elite_deathworm': {motion:'sand_rupture', range:14, windup:20, cooldown:145, damage:9, width:1.35, height:0.4, fx:STONE},
};
const TAIL = {motion:'tail_sweep', range:5, windup:17, cooldown:115, damage:10, radius:4, fx:STONE};

const raise = (point,y) => ({...point,y:point.y+y});
const pointAt = (a,b,t) => ({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t});
function alive(entity) {
  try { return entity.isValid !== false && healthAlive(entity); }
  catch { return false; }
}
function validPlayer(player) {
  const mode = String(player.getGameMode?.()).toLowerCase();
  return mode !== 'creative' && mode !== 'spectator' && alive(player);
}
export function nearestBossPlayer(boss, players, range, height) {
  const origin = raise(boss.location,height);
  return players.filter(p => p.dimension.id === boss.dimension.id && validPlayer(p) && dist3(boss.location,p.location) <= range)
    .sort((a,b) => dist3(boss.location,a.location)-dist3(boss.location,b.location))
    .find(p => clearBlockPath(boss.dimension,origin,raise(p.location,0.9)));
}

function attackArea(boss,target,pattern) {
  const base = {...boss.location}, aim = {...target.location};
  if (pattern.radius) {
    const circles = [pattern === TAIL ? base : aim];
    if (pattern.motion === 'arc_field') {
      const dx=aim.x-base.x,dz=aim.z-base.z,length=Math.hypot(dx,dz)||1;
      for (const side of [-3,3]) circles.push({...aim,x:aim.x-dz/length*side,z:aim.z+dx/length*side});
    }
    return {circles,origin:raise(base,1)};
  }

  const origin = raise(base,pattern.height);
  const fire = pattern.motion === 'fire_breath';
  // A locked straight path, extended for the breath so players behind the target can also dodge it.
  let endpoint = raise(aim,pattern.motion === 'sand_rupture' ? 0.4 : 0.9);
  if (fire) {
    const length=dist3(origin,endpoint)||1;
    endpoint=pointAt(origin,endpoint,Math.max(length,Math.min(pattern.range,length+3))/length);
  }
  const steps = Math.max(1,Math.ceil(dist3(origin,endpoint)*2));
  let end=origin;
  for (let step=1;step<=steps;step++) {
    const next=pointAt(origin,endpoint,step/steps);
    if (!clearBlockPath(boss.dimension,end,next)) break;
    end=next;
  }
  return {origin,end};
}

function showArea(dim,pattern,area,impact) {
  if (area.circles) {
    for (const center of area.circles) {
      const count=impact?18:12;
      for (let i=0;i<count;i++) {
        const a=2*Math.PI*i/count;
        particle(dim,pattern.fx,{x:center.x+Math.cos(a)*pattern.radius,y:center.y+0.2,z:center.z+Math.sin(a)*pattern.radius});
      }
    }
    return;
  }
  const count=Math.min(40,Math.max(1,Math.ceil(dist3(area.origin,area.end)*(impact?1.2:0.65))));
  for (let i=0;i<=count;i++) {
    const p=pointAt(area.origin,area.end,i/count);
    particle(dim,pattern.fx,p);
    if (pattern.motion === 'fire_breath') {
      const dx=area.end.x-area.origin.x,dz=area.end.z-area.origin.z,length=Math.hypot(dx,dz)||1;
      const spread=i/count*1.8;
      for (const side of [-spread,spread]) particle(dim,FIRE,{x:p.x-dz/length*side,y:p.y,z:p.z+dx/length*side});
    }
  }
}

function insideArea(dim,player,pattern,area) {
  const pos=player.location;
  if (area.circles) {
    return area.circles.some(center => Math.abs(pos.y-center.y)<=2.5 &&
      Math.hypot(pos.x-center.x,pos.z-center.z)<=pattern.radius &&
      clearBlockPath(dim,raise(center,0.9),raise(pos,0.9)));
  }
  const body=raise(pos,pattern.motion === 'sand_rupture' ? 0.4 : 0.9);
  const a=area.origin,b=area.end,dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z;
  const lenSq=dx*dx+dy*dy+dz*dz;
  if (lenSq < 0.01) return false;
  const t=((body.x-a.x)*dx+(body.y-a.y)*dy+(body.z-a.z)*dz)/lenSq;
  const width=pattern.width+(pattern.motion === 'fire_breath' ? 1.8*t : 0);
  return t>=0 && t<=1 && dist3(body,pointAt(a,b,t))<=width &&
    clearBlockPath(dim,a,body);
}

function cast(boss,target,pattern) {
  const dim=boss.dimension,area=attackArea(boss,target,pattern);
  const x=target.location.x-boss.location.x,z=target.location.z-boss.location.z;
  if (Math.hypot(x,z)>0.01) try { boss.setRotation({x:0,y:Math.atan2(-x,z)*180/Math.PI}); } catch {}
  playBossMotion(boss,pattern.motion);
  showArea(dim,pattern,area,false);
  sound(dim,pattern.motion==='fire_breath'?'mob.blaze.breathe':'mob.irongolem.throw',boss.location,{volume:1,pitch:0.65});

  system.runTimeout(() => {
    if (!alive(boss) || boss.dimension.id !== dim.id || isTimeFrozen(boss)) return;
    showArea(dim,pattern,area,true);
    const fire=pattern.motion==='fire_breath';
    sound(dim,fire?'mob.blaze.shoot':'random.explode',area.origin,{volume:1,pitch:0.75});
    for (const player of dim.getPlayers()) {
      if (!validPlayer(player) || !insideArea(dim,player,pattern,area)) continue;
      try {
        const hit=player.applyDamage(pattern.damage*monsterAttackMultiplier(boss),{
          cause:fire?EntityDamageCause.fire:EntityDamageCause.magic,damagingEntity:boss,
        });
        if (hit === false) continue;
        if (fire) player.setOnFire(3,true);
        if (pattern.motion==='sand_rupture' || pattern.motion==='arc_field') {
          player.addEffect('slowness',40,{amplifier:0,showParticles:false});
        }
      } catch {}
    }
  },pattern.windup);
}

export function registerBossMechanics() {
  const nextCast=new Map();
  system.runInterval(()=>{
    const now=system.currentTick,loaded=new Set();
    for (const name of DIMENSIONS) {
      let dim,players;
      try { dim=world.getDimension(name); players=dim.getPlayers(); } catch { continue; }
      if (!players.length) continue;
      for (const [type,definition] of Object.entries(PATTERNS)) {
        let bosses;
        try { bosses=dim.getEntities({type}); } catch { continue; }
        for (const boss of bosses) {
          if (!alive(boss)) continue;
          loaded.add(boss.id);
          if (!nextCast.has(boss.id)) nextCast.set(boss.id,now+40);
          if (now<nextCast.get(boss.id) || isTimeFrozen(boss) || bossMechanicActive(boss)) continue;
          const target=nearestBossPlayer(boss,players,definition.range,definition.height??1);
          if (!target) continue;
          const pattern=type==='rpg:hydra_boss' && dist3(boss.location,target.location)<5 ? TAIL : definition;
          nextCast.set(boss.id,now+pattern.cooldown);
          cast(boss,target,pattern);
        }
      }
    }
    for (const id of nextCast.keys()) if (!loaded.has(id)) nextCast.delete(id);
  },5);
}
