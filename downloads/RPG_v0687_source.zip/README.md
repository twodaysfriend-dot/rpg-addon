# RPG v0.6.87 · 피의 창 내구도

피의 창의 최대 내구도를 6에서 10으로 늘렸습니다. 근접 타격과 찌르기가 같은 횟수를 사용하며 10번째 사용 시 창이 소멸합니다. 기존 창은 사용한 횟수를 유지하고, 다음 명중 후 설명에 새 최대 횟수가 표시됩니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.87로 활성화하고 월드를 다시 여세요. 모의 테스트에서 두 공격을 섞어 10회 사용했을 때의 소멸과 기존 창의 사용 횟수 유지를 확인했습니다. 실제 Bedrock 월드에서는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0687
```
