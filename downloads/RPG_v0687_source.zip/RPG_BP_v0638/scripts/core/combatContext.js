import {activeBloodPlague,blocksBloodedgeDamage,creditBarrierBlock,isBloodedgePool} from './bloodedgeState.js';
import {abyssalDamageMultiplier} from './abyssalArmor.js';
import {undeadMonsterDamageMultiplier} from './races.js';
import {tryResurrection} from './resurrection.js';
import {blockTownVillagerDamage} from './townVillagers.js';
import {isTimeFrozen} from './timeStopDamage.js';
import {system} from '@minecraft/server';
import {notePvpAttack} from './pvp.js';
import {SUPER_SANDBAG_ID,recordSuperSandbagDamage} from './superSandbag.js';
export function setCombatHealth(target,source,hp,next,options={}){
 if(isTimeFrozen(source)||blockTownVillagerDamage(target,source))return;
 const before=hp.currentValue;
 let damage=Math.max(0,before-next);
 if(damage>0&&source&&isBloodedgePool(target))return;
 if(damage>0&&source&&blocksBloodedgeDamage(target,source)){
  creditBarrierBlock(target,damage);
  return;
 }
 const plague=damage>0?activeBloodPlague(target):undefined;
 if(plague&&!options.plagueIncluded)damage*=1+plague.def.vulnerability;
 if(damage>0){
  if(!options.raceIncluded)damage*=undeadMonsterDamageMultiplier(target,source)??1;
  if(!options.armorIncluded)damage*=abyssalDamageMultiplier(target);
  if(target.typeId===SUPER_SANDBAG_ID){
   recordSuperSandbagDamage(target,source,damage);
   if(plague)plague.damage+=damage;
   return;
  }
  next=Math.max(0,before-damage);
 }
 notePvpAttack(source,target,Math.max(0,before-next));
 if(next<=0&&tryResurrection(target,source,next))return;
 if(next<=0&&source)rememberScriptKiller(source,target);
 hp.setCurrentValue(next);
 if(plague)plague.damage+=Math.max(0,before-hp.currentValue);
}
export const BLACK_FLASH_KEY='rpg:black_flash_ready';
const hits=[],pending=[],credits=new Map();let onManual=()=>{},basicHandler=()=>{},manualObserver=()=>{},manualMultiplier=()=>1;
export function setManualDamageMultiplier(fn){manualMultiplier=fn;}
export function setManualDamageObserver(fn){manualObserver=fn;}
export function setUnreportedDamageHandler(fn){onManual=fn;}
export function setBasicHitHandler(fn){basicHandler=fn;}
export function handleBasicHit(ev,scripted){basicHandler(ev,scripted);}
const same=(h,s,t)=>h.source?.id===s?.id&&h.target?.id===t?.id;
export function currentScriptHit(source,target){return [...hits].reverse().find(h=>same(h,source,target));}
function prune(){for(let i=pending.length-1;i>=0;i--)if(pending[i].until<system.currentTick)pending.splice(i,1);}
export function plagueAdjustedHit(source,target){
 prune();
 const h=currentScriptHit(source,target)??pending.find(hit=>same(hit,source,target));
 return h?.plagueIncluded===true;
}
export function markDamageReported(source,target){
 prune();const h=currentScriptHit(source,target)??pending.find(h=>same(h,source,target));if(h){h.reported=true;const i=pending.indexOf(h);if(i>=0)pending.splice(i,1);}return h;
}
export function noteManualDamage(source,target,damage,{incomingScaled=false}={}){
 if(!incomingScaled&&damage>0){try{const hp=target.getComponent('minecraft:health'),extra=Math.min(hp?.currentValue??0,damage*Math.max(0,manualMultiplier(target)-1));if(extra>0){if(extra>=hp.currentValue&&source)rememberScriptKiller(source,target);setCombatHealth(target,source,hp,Math.max(0,hp.currentValue-extra));damage+=extra;}}catch{}}
 const h=currentScriptHit(source,target);if(h)h.manualDamage=(h.manualDamage??0)+damage;try{manualObserver(source,target,damage);}catch{}
}

export function rememberScriptKiller(source,target){for(const [id,c]of credits)if(c.until<system.currentTick)credits.delete(id);credits.set(target.id,{source,until:system.currentTick+4});}
export function scriptKiller(target){const c=credits.get(target?.id);credits.delete(target?.id);return c&&c.until>=system.currentTick?c.source:undefined;}
export function scriptedHit(target,source,fn){
 if(isTimeFrozen(source)||blockTownVillagerDamage(target,source))return false;
 let before;try{before=target.getComponent('minecraft:health')?.currentValue;}catch{}
 prune();const h={source,target,before,reported:false,until:system.currentTick+2};hits.push(h);pending.push(h);let result;
 try{result=fn();return result;}finally{
  hits.pop();if(h.manualDamage>0){try{onManual(source,target,h.manualDamage);}catch{}h.reported=true;}
  if(h.reported||result===false){const i=pending.indexOf(h);if(i>=0)pending.splice(i,1);}
 }
}
