import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {calculate,targetSummary} from '../tools/compare_enhancement_costs.mjs';
import {HUNT_REWARDS,WAVES,DUNGEON_TIERS,encounterTypes,dungeonBlock} from '../RPG_BP_v0567/scripts/data/dungeons.js';
import {player,players} from './minecraftMock.mjs';
import {currencyReward,grantKillCurrencies} from '../RPG_BP_v0567/scripts/core/economy.js';
test('catalyst buff speeds up dungeon enhancement while retaining the unassisted hunt economy',()=>{
 const [hunt,dungeon]=targetSummary();assert.ok(hunt.normalHoursWithoutCatalystSourcing>19.5&&hunt.normalHoursWithoutCatalystSourcing<21);assert.ok(dungeon.dungeonHours>0&&dungeon.dungeonHours<19);assert.ok(dungeon.allRunes.catalysts>0);assert.ok(dungeon.dungeonClears>5);assert.equal(dungeon.killPlusClearReward.gold,13100);assert.equal(dungeon.killPlusClearReward.stone,162);assert.ok(Math.abs(dungeon.killPlusClearReward.dust-20.5)<1e-9);
 const costs=calculate();assert.ok(costs[0].allRunes.gold>1600000&&costs[0].allRunes.gold<1750000);assert.ok(costs[1].allRunes.gold<250000);
});
test('each wave mob has a persistent event and every supply item exists in the actual pack',()=>{
 for(const type of new Set(WAVES.flatMap(w=>w.types))){const e=JSON.parse(fs.readFileSync(new URL('../RPG_BP_v0567/entities/'+type+'.json',import.meta.url)))['minecraft:entity'];assert.deepEqual(e.events['rpg:dungeon_persistent'].add.component_groups,['rpg:dungeon_persistent']);assert.deepEqual(e.component_groups['rpg:dungeon_persistent'],{'minecraft:persistent':{},'minecraft:experience_reward':{on_death:0}});assert.ok(currencyReward('rpg:'+type).gold>0);}
 assert.equal(currencyReward('minecraft:zombie',()=>0).gold,HUNT_REWARDS.normal.gold);
});

test('higher normal rewards do not turn every normal kill into a chat notification',()=>{
 const p=player('quiet-hunt');players.push(p);for(let i=0;i<5;i++)grantKillCurrencies(p,{typeId:'minecraft:zombie'},()=>.5);
 assert.equal(p.messages.length,1);grantKillCurrencies(p,{typeId:'rpg:elite_green_goblin'});assert.equal(p.messages.length,1);grantKillCurrencies(p,{typeId:'rpg:rock_golem_boss'});assert.equal(p.messages.length,1);
});

test('ten difficulties have 50 normal, 5 elite and 1 boss with native HP and melee scaling',()=>{
 assert.equal(DUNGEON_TIERS.length,10);
 for(const tier of DUNGEON_TIERS){
  const ids=encounterTypes(tier.tier);assert.equal(ids.length,56);assert.equal(ids.filter(id=>id.startsWith('elite_')).length,5);assert.equal(ids.filter(id=>id.endsWith('_boss')).length,1);
  for(const id of new Set(ids)){
   const entity=JSON.parse(fs.readFileSync(new URL('../RPG_BP_v0567/entities/'+id+'.json',import.meta.url)))['minecraft:entity'],group=entity.component_groups['rpg:dungeon_tier_'+tier.tier];
   const expected=Math.round(entity.components['minecraft:health'].max*tier.hpMultiplier*100)/100;assert.equal(group['minecraft:health'].max,expected);assert.equal(group['minecraft:health'].value,expected);
   assert.deepEqual(entity.events['rpg:dungeon_tier_'+tier.tier].add.component_groups,['rpg:dungeon_persistent','rpg:dungeon_tier_'+tier.tier]);
   const base=entity.components['minecraft:attack']?.damage;if(typeof base==='number')assert.equal(group['minecraft:attack'].damage,Math.round(base*tier.attackMultiplier*100)/100);
  }
 }
});

test('floor lighting keeps natural dark-spawn enemies out of the fixed-count arena',()=>{
 const lamps=[];for(let x=-32;x<=32;x++)for(let z=-32;z<=32;z++)if(dungeonBlock(x,0,z)==='minecraft:sea_lantern')lamps.push([x,z]);
 for(let x=-29;x<=29;x++)for(let z=-29;z<=29;z++)if(Math.hypot(x,z)<30){const distance=Math.min(...lamps.map(([lx,lz])=>Math.abs(x-lx)+Math.abs(z-lz)));assert.ok(14-distance>7);}
 const directory=new URL('../RPG_BP_v0567/spawn_rules/',import.meta.url);
 for(const name of fs.readdirSync(directory))if(name.endsWith('.json')){
  const rules=JSON.parse(fs.readFileSync(new URL(name,directory)))['minecraft:spawn_rules'];
  if(!rules.description.identifier.startsWith('rpg:'))continue;
  for(const condition of rules.conditions){const blocks=condition['minecraft:spawns_on_block_filter']?.blocks;if(!blocks||blocks.some(b=>['minecraft:deepslate_tiles','minecraft:sea_lantern'].includes(b)))assert.ok(condition['minecraft:brightness_filter'].max<=7,name);}
 }
});
