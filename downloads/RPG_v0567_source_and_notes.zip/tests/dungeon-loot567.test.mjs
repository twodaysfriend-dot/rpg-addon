import test,{afterEach} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,players,world,ItemStack,timeouts} from './minecraftMock.mjs';
import {rollDungeonEliteDiamonds,netheriteChanceForTier,rollDungeonNetherite} from '../RPG_BP_v0567/scripts/data/dungeons.js';
import {dungeonRuns} from '../RPG_BP_v0567/scripts/core/dungeonState.js';
import {recordDungeonDamage,recordDungeonHealing,contributionShares,splitContribution,settleDungeonGroundLoot,claimSharedDungeonLoot,LOOT_CACHE} from '../RPG_BP_v0567/scripts/core/dungeonSharedLoot.js';
import {creditDungeonClear,readDungeonLoot,DUNGEON_LOOT_KEY} from '../RPG_BP_v0567/scripts/core/dungeonRewards.js';
import {dungeonDeath,flushRewards,DUNGEON_KEY} from '../RPG_BP_v0567/scripts/core/dungeons.js';
import {getWallet} from '../RPG_BP_v0567/scripts/core/wallet.js';

let serial=0;const entities=new Map();
ItemStack.prototype.isStackableWith=function(other){return this.typeId===other?.typeId&&this.nameTag===other.nameTag&&JSON.stringify([...this.props])===JSON.stringify([...other.props])&&JSON.stringify(this.lore)===JSON.stringify(other.lore)&&JSON.stringify(this.enchantments)===JSON.stringify(other.enchantments);};
Object.defineProperty(ItemStack.prototype,'maxAmount',{get(){return this.typeId.includes('sword')||this.typeId.includes('book')?1:64;}});
const dim={id:'minecraft:overworld',getBlock:()=>({isSolid:false}),runCommand:()=>({successCount:1}),
 getEntities:()=>[...entities.values()],
 spawnEntity(typeId,at){
  assert.equal(typeId,LOOT_CACHE);const values=new Map(),slots=Array(27);const e={id:'cache'+(++serial),typeId,dimension:dim,location:{...at},isValid:true,
   getDynamicProperty:k=>values.get(k),setDynamicProperty:(k,v)=>values.set(k,v),remove(){entities.delete(this.id);this.isValid=false;},
   getComponent:k=>k==='minecraft:inventory'?{container:{size:27,getItem:i=>slots[i]?.clone(),setItem:(i,item)=>{slots[i]=item?.clone();}}}:undefined};
  entities.set(e.id,e);return e;
 },spawnItem(item,at){return ground(item,at);}};
world.getDimension=()=>dim;world.getEntity=id=>entities.get(id);
function ground(item,at={x:0,y:81,z:0}){const e={id:'drop'+(++serial),typeId:'minecraft:item',dimension:dim,location:at,getComponent:k=>k==='minecraft:item'?{itemStack:item.clone()}:undefined,remove(){entities.delete(this.id);}};entities.set(e.id,e);return e;}
function run(kind='elite',tier=6){
 const a=player('a'+(++serial),30,{dimension:dim,location:{x:0,y:81,z:0}}),b=player('b'+serial,30,{dimension:dim,location:{x:1,y:81,z:0}});players.push(a,b);
 const enemy={id:'enemy'+serial,typeId:kind==='boss'?'rpg:hydra_boss':'rpg:elite_mantis',dimension:dim,location:{x:2,y:81,z:0},health:100,getComponent:k=>k==='minecraft:health'?{currentValue:enemy.health}:undefined};
 const r={id:10000+serial,d:{id:'dungeon_'+tier,tier,dimId:dim.id,x:0,y:80,z:0,shape:'cave_v2'},members:[{id:a.id},{id:b.id}],participants:[{id:a.id},{id:b.id}],phase:kind==='boss'?'boss':'mobs',live:new Map([[enemy.id,{kind,mob:enemy}]]),normalSpawned:50,eliteSpawned:5,normalKilled:0,eliteKilled:0,nextNormalAt:Infinity,nextEliteAt:Infinity,deadline:Date.now()+300000,health:new Map([[enemy.id,100]]),contribution:new Map(),engaged:new Set(),vanillaXp:0,anchors:new Map(),initialPartySize:2};
 if(kind==='boss')r.bossId=enemy.id;dungeonRuns.set(r.d.id,r);return {a,b,enemy,r};
}
afterEach(()=>{dungeonRuns.clear();players.length=0;entities.clear();timeouts.length=0;});

test('elite mineral roll is exclusive 40% one, 10% three, 50% none at every boundary',()=>{
 for(const [n,count]of [[0,1],[.399999,1],[.4,3],[.499999,3],[.5,0],[.999999,0]])assert.equal(rollDungeonEliteDiamonds(()=>n),count);
 const histogram=[0,0,0,0];for(let i=0;i<10000;i++)histogram[rollDungeonEliteDiamonds(()=>i/10000)]++;
 assert.deepEqual(histogram,[5000,4000,0,1000]);
 for(const invalid of [-1,1,NaN,Infinity])assert.throws(()=>rollDungeonEliteDiamonds(()=>invalid));
});
test('only tiers six to ten grant one ingot with exact increasing probabilities',()=>{
 for(let tier=1;tier<=10;tier++){const chance=netheriteChanceForTier(tier);assert.equal(chance,tier<6?0:[.1,.15,.2,.25,.3][tier-6]);assert.equal(rollDungeonNetherite(tier,()=>0),tier<6?0:1);assert.equal(rollDungeonNetherite(tier,()=>chance),0);}
 for(const invalid of [0,11,6.5,'6',NaN])assert.equal(netheriteChanceForTier(invalid),0);
});
test('tracked elite dies once, normals and expired or untracked mobs never mint diamond loot',()=>{
 const {r,enemy}=run();const random=Math.random;Math.random=()=>.4;
 try{dungeonDeath({deadEntity:enemy});dungeonDeath({deadEntity:enemy});dungeonDeath({deadEntity:{...enemy,id:'wild'}});}finally{Math.random=random;}
 assert.equal(r.eliteKilled,1);assert.equal([...entities.values()].filter(e=>e.typeId==='minecraft:item').length,1);
 assert.equal([...entities.values()][0].getComponent('minecraft:item').itemStack.amount,3);
});
test('netherite payout preserves original stored roll through failed credit and duplicate retry',()=>{
 const {a,r,enemy}=run('boss',10);a.slots.fill(new ItemStack('minecraft:stone',64));const write=a.setDynamicProperty.bind(a);let fail=true;
 a.setDynamicProperty=(k,v)=>{if(k===DUNGEON_LOOT_KEY&&fail){fail=false;throw Error('retry');}write(k,v);};
 const random=Math.random;Math.random=()=>0;try{dungeonDeath({deadEntity:enemy});}finally{Math.random=random;}
 const state=JSON.parse(world.getDynamicProperty(DUNGEON_KEY));assert.equal(state.outbox.find(x=>x.playerId===a.id).netherite,1);
 Math.random=()=>{throw Error('payout must not reroll');};try{flushRewards();flushRewards();}finally{Math.random=random;}
 assert.equal(readDungeonLoot(a).pending['minecraft:netherite_ingot'],1);assert.equal(readDungeonLoot(a).clears,1);assert.ok(getWallet(a).gold>0);
});
test('effective damage caps overkill, effective allied healing counts only during combat',()=>{
 const {a,b,enemy,r}=run();recordDungeonHealing(b,a,100);assert.equal(r.contribution.size,0);
 enemy.health=25;recordDungeonDamage(a,enemy,75);recordDungeonHealing(b,a,25);
 enemy.health=0;recordDungeonDamage(a,enemy,500);recordDungeonDamage(a,enemy,500);
 assert.equal(r.contribution.get(a.id),100);assert.equal(r.contribution.get(b.id),25);
 recordDungeonHealing(a,a,500);assert.equal(r.contribution.get(a.id),100);
});
test('item and XP allocation conserves totals and honors a 75/25 contribution ratio',()=>{
 const shares=[{id:'a',weight:75},{id:'b',weight:25}];assert.deepEqual(splitContribution(100,shares),[{id:'a',amount:75},{id:'b',amount:25}]);
 for(let total=0;total<200;total++)assert.equal(splitContribution(total,shares).reduce((n,s)=>n+s.amount,0),total);
 assert.deepEqual(splitContribution(1,[{id:'a',weight:1},{id:'b',weight:1}],1),[{id:'a',amount:0},{id:'b',amount:1}]);
 const carry=new Map(),counts={a:0,b:0};for(let i=0;i<4;i++)for(const s of splitContribution(1,shares,i,carry))counts[s.id]+=s.amount;
 assert.deepEqual(counts,{a:3,b:1});
});
test('settlement keeps exact named enchanted upgraded items in full-bag native storage and claims once',()=>{
 const {a,b,r}=run();r.contribution.set(a.id,75);r.contribution.set(b.id,25);r.vanillaXp=100;
 const sword=new ItemStack('minecraft:diamond_sword');sword.nameTag='kept exactly';sword.enchantments=[{type:{id:'sharpness'},level:5}];sword.setLore(['original lore']);sword.setDynamicProperty('rpg:weapon_upgrade',10);
 a.slots.fill(new ItemStack('minecraft:stone',64));b.slots.fill(new ItemStack('minecraft:stone',64));
 ground(new ItemStack('minecraft:diamond',64));ground(new ItemStack('minecraft:diamond',36));ground(sword);ground(new ItemStack('minecraft:diamond',99),{x:99,y:81,z:0});
 assert.equal(settleDungeonGroundLoot(r),101);assert.equal(a.nativeXp,75);assert.equal(b.nativeXp,25);
 assert.equal([...entities.values()].filter(e=>e.typeId==='minecraft:item').length,1);
 a.slots.fill(undefined);b.slots.fill(undefined);claimSharedDungeonLoot(a);claimSharedDungeonLoot(b);claimSharedDungeonLoot(a);
 const items=[...a.slots,...b.slots].filter(Boolean);assert.equal(items.filter(i=>i.typeId==='minecraft:diamond').reduce((n,i)=>n+i.amount,0),100);
 const result=items.find(i=>i.typeId==='minecraft:diamond_sword');assert.equal(result.nameTag,sword.nameTag);assert.deepEqual(result.enchantments,sword.enchantments);assert.equal(result.getDynamicProperty('rpg:weapon_upgrade'),10);assert.deepEqual(result.getLore(),sword.getLore());
 assert.equal(a.nativeXp+b.nativeXp,100);assert.equal(a.slots[0],undefined);
});
test('native XP grant failure preserves the cache and retry grants exactly once',()=>{
 const {a,r}=run();r.members=r.participants=[{id:a.id}];r.vanillaXp=42;
 const add=a.addExperience.bind(a);let fail=true;a.addExperience=n=>{if(fail){fail=false;throw Error('xp');}add(n);};
 settleDungeonGroundLoot(r);assert.equal(a.nativeXp,0);assert.equal(entities.size,1);
 claimSharedDungeonLoot(a);claimSharedDungeonLoot(a);assert.equal(a.nativeXp,42);assert.equal(entities.size,0);
});
test('dead participants retain their earned share until respawn',()=>{
 const {a,r}=run();r.members=r.participants=[{id:a.id}];r.vanillaXp=42;a.health=0;
 settleDungeonGroundLoot(r);assert.equal(a.nativeXp,0);assert.equal(entities.size,1);
 a.health=20;claimSharedDungeonLoot(a);assert.equal(a.nativeXp,42);assert.equal(entities.size,0);
});
test('all 16 fitted armor models use valid solid original texels and no repeated icon UV panels',()=>{
 const models=JSON.parse(fs.readFileSync(new URL('../RPG_RP_v0567/models/entity/rpg_worn_armor.geo.json',import.meta.url)))['minecraft:geometry'];assert.equal(models.length,16);
 for(const g of models){assert.equal(g.description.texture_width,128);assert.equal(g.description.texture_height,128);for(const b of g.bones)for(const cube of b.cubes??[])for(const face of Object.values(cube.uv)){assert.deepEqual(face.uv_size,[1,1]);assert.ok(face.uv.every(n=>n>=0&&n<128));}}
});
