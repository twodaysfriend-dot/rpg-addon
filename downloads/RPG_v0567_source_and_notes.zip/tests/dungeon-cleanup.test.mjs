import test from 'node:test';
import assert from 'node:assert/strict';
import {cleanDungeonMobs} from '../RPG_BP_v0567/scripts/core/dungeonCleanup.js';
const d={id:'dungeon_1',shape:'cave_v2',dimId:'minecraft:overworld',x:0,y:80,z:0};let serial=0;
function mob(typeId,{x=0,y=81,z=0,tags=[],health=true,dimId=d.dimId,fail=false}={}){return {id:'m'+serial++,typeId,location:{x,y,z},dimension:{id:dimId},tags,getComponent:id=>id==='minecraft:health'&&health?{}:undefined,remove(){if(fail)throw Error('invalid');this.removed=true;}};}
function dimension(entities){return {getEntities:q=>entities.filter(e=>!q.tags||q.tags.every(t=>e.tags.includes(t)))};}
test('failed cave cleanup removes all living mobs inside even with no dungeon tag, while preserving players/NPCs/items',()=>{
 const enemies=['minecraft:zombie','minecraft:skeleton','minecraft:cow','rpg:elite_green_goblin','rpg:hydra_boss','rpg:bone_minion'].map(id=>mob(id));
 const protectedEntities=['minecraft:player','rpg:hito_sword','rpg:hito_war_god','rpg:gpt_guide','minecraft:armor_stand','minecraft:item','minecraft:xp_orb'].map(id=>mob(id));const arrow=mob('minecraft:arrow',{health:false});
 assert.equal(cleanDungeonMobs(dimension([...enemies,...protectedEntities,arrow]),d,{allInside:true}),enemies.length);assert.ok(enemies.every(e=>e.removed));assert.ok(protectedEntities.every(e=>!e.removed));assert.equal(arrow.removed,undefined);
});
test('cleanup does not reach another dungeon, cave corners, the surface below or another dimension',()=>{
 const entities=[mob('minecraft:zombie',{x:80}),mob('minecraft:zombie',{x:31,z:31}),mob('minecraft:zombie',{y:60}),mob('minecraft:zombie',{y:140}),mob('minecraft:zombie',{dimId:'minecraft:nether'})];assert.equal(cleanDungeonMobs(dimension(entities),d,{allInside:true}),0);assert.ok(entities.every(e=>!e.removed));
});
test('tracked or correctly tagged escaped dungeon mobs are removed, but unrelated tagged mobs outside remain',()=>{
 const ours=mob('rpg:green_goblin',{x:100,tags:['rpg_dungeon_mob','rpg_dungeon_dungeon_1']}),other=mob('rpg:green_goblin',{x:80,tags:['rpg_dungeon_mob','rpg_dungeon_dungeon_2']}),tracked=mob('rpg:hydra_boss',{x:120,tags:[]});assert.equal(cleanDungeonMobs(dimension([ours,other]),d,{allInside:true,tracked:[tracked]}),2);assert.ok(ours.removed);assert.ok(tracked.removed);assert.equal(other.removed,undefined);
});
test('one invalid entity cannot stop the remaining mob cleanup, and cleanup never calls kill or applyDamage',()=>{
 const bad=mob('minecraft:zombie',{fail:true}),good=mob('minecraft:skeleton');good.kill=good.applyDamage=()=>{throw Error('kill rewards must not fire');};assert.equal(cleanDungeonMobs(dimension([bad,good]),d,{allInside:true}),1);assert.ok(good.removed);
});
