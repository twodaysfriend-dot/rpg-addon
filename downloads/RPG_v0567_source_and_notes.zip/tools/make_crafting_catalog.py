"""Generate game-readable crafting descriptions from the real recipe JSON."""
from pathlib import Path
from collections import Counter
import json

ROOT=Path(__file__).resolve().parents[1]
BP=ROOT/'RPG_BP_v0567'
NAMES={'minecraft:packed_ice':'꽁꽁 언 얼음','minecraft:diamond_sword':'다이아몬드 검','minecraft:diamond_axe':'다이아몬드 도끼','minecraft:blaze_powder':'블레이즈 가루','minecraft:magma_cream':'마그마 크림','minecraft:bone':'뼈','minecraft:prismarine_crystals':'프리즈머린 수정','minecraft:iron_ingot':'철 주괴','minecraft:copper_ingot':'구리 주괴','minecraft:emerald':'에메랄드',
    'minecraft:oak_planks':'참나무 판자','minecraft:amethyst_shard':'자수정 조각','minecraft:lapis_lazuli':'청금석',
    'minecraft:redstone':'레드스톤','minecraft:ender_pearl':'엔더 진주','minecraft:golden_apple':'황금사과',
    'minecraft:sugar':'설탕','minecraft:nether_star':'네더의 별','minecraft:diamond':'다이아몬드','minecraft:hay_block':'건초 더미','minecraft:paper':'종이','minecraft:gold_ingot':'금 주괴','minecraft:ink_sac':'먹물 주머니','minecraft:netherite_ingot':'네더라이트 주괴','minecraft:stick':'막대기'}
items={}
for path in (BP/'items').glob('*.json'):
    item=json.loads(path.read_text())['minecraft:item'];items[item['description']['identifier']]=item
    NAMES[item['description']['identifier']]=item['components'].get('minecraft:display_name',{}).get('value',item['description']['identifier'])

def generate_catalog():
    catalog=[]
    for path in sorted((BP/'recipes').glob('*.json')):
        document=json.loads(path.read_text())
        shaped='minecraft:recipe_shaped' in document
        recipe=document.get('minecraft:recipe_shaped') or document.get('minecraft:recipe_shapeless')
        if not recipe:continue
        identifier=recipe['result']['item']
        if identifier in ['rpg:stat_reset_scroll','rpg:job_waiver']:category='recovery'
        elif identifier=='rpg:sandbag_spawner':category='training'
        elif identifier.startswith('rpg:common_'):category='weapon'
        elif identifier.startswith('rpg:rune_'):category='rune'
        elif identifier=='rpg:enhancement_catalyst':category='catalyst'
        elif identifier.startswith(('rpg:adventurer_','rpg:warden_','rpg:astral_','rpg:abyssal_')):category='armor'
        else:continue
        counts=Counter()
        if shaped:
            for row in recipe['pattern']:
                for symbol in row:
                    if symbol!=' ':counts[recipe['key'][symbol]['item']]+=1
            grid=[' '.join({'I':'철','C':'구','H':'건',' ':'□'}[c] for c in row.ljust(3)) for row in recipe['pattern']]
            grid+=['□ □ □']*(3-len(grid))
            placement=('배치도 (건=건초 더미):\n' if 'H' in recipe['key'] else '배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n')+'\n'.join(grid)
        else:
            for entry in recipe['ingredients']:counts[entry['item']]+=entry.get('count',1)
            placement='작업대에 배치 순서와 관계없이 넣으세요.'
        materials='\n'.join(f'{NAMES.get(item,item)} ×{count}' for item,count in counts.items())
        warning='\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다.' if any(k.startswith(('rpg:adventurer_','rpg:warden_')) for k in counts) else ''
        text=f'작업대 제작 → {NAMES[identifier]} ×{recipe["result"].get("count",1)}\n\n재료:\n{materials}\n\n{placement}{warning}'
        catalog.append({'id':identifier,'category':category,'name':NAMES[identifier],'text':text})
    return catalog

if __name__=='__main__':
    catalog=generate_catalog()
    (BP/'scripts/data/crafting.js').write_text('// Generated from recipes by tools/make_crafting_catalog.py.\nexport const CRAFTING_RECIPES = '+json.dumps(catalog,ensure_ascii=False,indent=2)+';\n')
    print(f'Generated {len(catalog)} crafting guide entries from actual recipes.')
