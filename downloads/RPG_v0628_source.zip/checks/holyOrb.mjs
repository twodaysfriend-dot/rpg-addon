import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0628';
const base=root+'/RPG_BP_v0628/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}


const defs=(await load('scripts/data/skills.js')).SKILLS;
for(const job of ['cleric','angel','michael','chameleon']){
 const callbacks=new Map(),particles=[],effects=[],regen=[],removed=[];let next=0;
 const system={currentTick:0,runInterval:(fn,n)=>{callbacks.set(++next,{fn,n});return next;},clearRun:i=>callbacks.delete(i)};
 const dimension={id:'minecraft:overworld'};
 const p={id:'caster',job,typeId:'minecraft:player',isValid:true,alive:true,location:{x:0,y:0,z:0},dimension,removeEffect:id=>removed.push('caster:'+id)};
 const t={id:'ally',typeId:'minecraft:player',isValid:true,alive:true,location:{x:20,y:0,z:0},dimension,getHeadLocation:()=>({x:t.location.x,y:1.7,z:0}),removeEffect:id=>removed.push('target:'+id)};
 const holy=await load('scripts/skills/holy.js',{system,world:{},CONFIG:{pvp:false},healthAlive:e=>e?.alive,areAllies:(p,t)=>t.id==='ally',getJobId:p=>p.job,hasBorrowedSkill:()=>job==='chameleon',dist3:(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z),applyStatus:(entity,id,ticks,options)=>effects.push({entity,id,ticks,...options}),applyHolyRegeneration:(caster,target,ticks,amp)=>regen.push({ticks,amp}),particle:(dim,id,at)=>particles.push({dim,id,at})});
 const def=defs.holy_orb;
 holy.RUNNERS.holy_orb(p,{id:job},def,t);
 assert.equal(holy.RUNNERS.holy_orb(p,{id:job},def,t),false);
 for(let tick=2;tick<=100;tick+=2){system.currentTick=tick;for(const {fn}of [...callbacks.values()])fn();}
 assert.equal(particles.length,50);assert.ok(particles.every(v=>v.id==='rpg:holy_blessing_orb'&&v.at.x===20&&Math.abs(v.at.y-2.6)<1e-8&&v.at.z===0));
 assert.equal(regen.length,10);assert.ok(regen.every(r=>r.ticks===40&&r.amp===(def.regenByJob[job]??2)-1));
 assert.equal(effects.filter(e=>e.id==='absorption').length,1);assert.equal(effects.filter(e=>e.id==='speed').length,10);assert.equal(effects.filter(e=>e.id==='hunger').length,10);assert.ok(effects.every(e=>e.showParticles===false));
 t.location.x=21;for(const {fn}of [...callbacks.values()])fn();assert.equal(particles.at(-1).at.x,21);
 t.location.x=def.maxDistance+1;for(let n=0;n<5;n++)for(const {fn}of [...callbacks.values()])fn();assert.equal(callbacks.size,0);assert.deepEqual(removed.sort(),['caster:hunger','target:absorption','target:regeneration','target:speed'].sort());
 const before=particles.length;for(const {fn}of callbacks.values())fn();assert.equal(particles.length,before);
}
const particle=JSON.parse(fs.readFileSync(root+'/RPG_RP_v0628/particles/rpg_holy_blessing_orb.json','utf8')).particle_effect;
assert.equal(particle.description.identifier,'rpg:holy_blessing_orb');assert.equal(particle.components['minecraft:emitter_rate_instant'].num_particles,1);assert.equal(particle.components['minecraft:particle_lifetime_expression'].max_lifetime,.1);assert.equal(particle.components['minecraft:particle_initial_speed'],0);assert.ok(fs.existsSync(root+'/RPG_RP_v0628/'+particle.description.basic_render_parameters.texture+'.png'));
console.log('Blessing orb: all 3 holy classes + Chameleon emit only 1 overhead sprite per 2 ticks; no beam/halo/totem/effect swirls; regen/speed/hunger cadence + one-time absorption unchanged; single-target cap, position following and distance cleanup passed');
