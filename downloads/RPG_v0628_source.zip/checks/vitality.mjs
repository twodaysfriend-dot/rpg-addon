import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0628';
const base=root+'/RPG_BP_v0628/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}


let gear=0;
const stats=await load('scripts/core/stats.js',{getEquipmentBonuses:()=>({health:gear})});
const check=vit=>{
 const applied=[];let removed=0;
 const p={getDynamicProperty:k=>k==='rpg:stat_values'?JSON.stringify({str:5,mag:5,int:5,vit}):undefined,addEffect:(id,ticks,options)=>applied.push({id,ticks,...options}),getEffect:()=>({}),removeEffect:()=>removed++};
 stats.applyVitality(p);return {hp:20+(applied.length?4*(applied[0].amplifier+1):0),applied,removed};
};
assert.equal(check(5).hp,20);assert.equal(check(5).removed,1);
assert.equal(check(50).hp,120);assert.equal(check(50).applied[0].showParticles,false);
assert.equal(stats.VITALITY_HP_PER_POINT*45,100);
let previous=20;for(let vit=5;vit<=100;vit++){const n=check(vit).hp;assert.ok(n>=previous);previous=n;}
gear=20;assert.equal(check(50).hp,140);gear=0;assert.equal(check(50).hp,120);
console.log('Vitality: 5=20 HP, 50=120 HP without gear; monotonic growth, gear added separately, removing gear recomputes without stacking; passive health particles hidden');
