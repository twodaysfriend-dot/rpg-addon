# RPG v0.6.83 · 진홍의 군주와 난식 충격파

## 진홍의 군주

블라디미르로 5단계 이상 던전을 혼자 클리어하고 RPG 레벨 45를 달성한 뒤 창셀혼에게 말을 걸면 2차 전직할 수 있습니다. 피의 낫과 장비 데이터를 유지합니다.

- 진홍의 맥박은 실제로 막은 피해 1당 혈기 1을 방어막 한 번에 최대 40까지, 적혈의 포식으로 실제 피해를 주면 20씩 얻습니다. 최대 혈기는 100입니다. 롱기누스 · 심판 또는 진홍의 성역을 쓸 때 혈기가 60 이상이면 60을 소모해 강화합니다.
- 이지스 상귀니스 6초 및 해제 피해 40, 루브룸 버스트 발당 6.2, 롱기누스 · 심판 피해 72(혈기 강화 90·폭발 반경 12칸), 혈월의 사슬 반경 12칸과 속박당 최초 난사 추가 피해 12입니다.
- 적혈의 포식 피해 28 및 실제 피해의 40% 회복, 크림슨 페스트 받는 피해 +25% 및 종료 기준 누적 피해 7%, 적린개방 힘 IV·성급함 IV, 진홍의 성역 초당 피해 12(혈기 강화 지름 16칸·실제 피해의 65% 회복)입니다.
- 혈영 보법은 최대 7칸 이동하며 경로의 적에게 피해 18을 줍니다. MP 45, 쿨타임 8초입니다.
- 핏빛 제단은 16칸 내 지면에 설치합니다. 반경 5칸의 적에게 초당 피해 12, 아군에게 초당 HP 3 회복을 5초간 적용합니다. MP 100, 쿨타임 22초입니다.
- 마법 피해는 스탯 및 장비 적용 전 기본값입니다. 스킬 효과는 `/rpg:skillguide`에서 확인할 수 있습니다.

## 투신 난식

시선 기준 120° 부채꼴에 청백색 충격파 산탄 32발을 한 번에 발사합니다. 발당 기본 물리 피해 17, 사거리 25칸, 대상당 최대 10발까지 적중합니다. 천멸격이 준비된 경우 스킬 전체의 피해가 2배가 됩니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.83으로 활성화하고 월드를 다시 여세요. 모의 테스트에서 솔로 보스 처치 기록, 전직, 혈기, 10개 스킬과 입력, 충격파 산탄의 각도·피해·벽 충돌을 확인했습니다. 실제 Bedrock 월드에서의 조작과 파티클 렌더링은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0683
```
