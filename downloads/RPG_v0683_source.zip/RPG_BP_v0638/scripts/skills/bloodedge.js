import {world,system,MolangVariableMap} from '@minecraft/server';
import {isBloodedgeJob} from '../data/jobs.js';
import {SKILLS} from '../data/skills.js';
import {shotgunDirections} from '../core/shotgun.js';
import {checkSkillMovement,teleportForSkill} from '../core/dungeonMovement.js';
import {projectileMotion} from '../core/combatRunes.js';
import {rpgMaxHealth} from '../core/healthLimits.js';
import {CONFIG} from '../config.js';
import {actualHurtAmount} from '../core/damageAmounts.js';
import {plagueAdjustedHit,setCombatHealth} from '../core/combatContext.js';
import {areAllies} from '../core/social.js';
import {getJobId,getMana,spendMana} from '../core/playerData.js';
import {isJailed} from '../core/prison.js';
import {isTimeFrozen} from '../core/timeStopDamage.js';
import {ccTicks} from '../core/crowdControl.js';
import {BLOODEDGE_POOL_TAG,BLOODEDGE_MEASURE_TAG,blocksBloodedgeDamage,isBloodedgePool,isShieldFront,shieldSessions,activeBloodPlague,plagueSessions,clearBloodReserve,gainBloodReserve,spendBloodReserve,creditBarrierBlock} from '../core/bloodedgeState.js';
import {clearBlockPath,dist3,flatDir,getTargets,headPos,healthAlive,hurt,isSolidAt,knockback,norm3,particle,sound} from '../core/util.js';
import {notify} from '../core/hud.js';

const SPARK='rpg:blood_spark',BURST='rpg:blood_burst',SIGIL='rpg:blood_sigil';
const SLOTS=16;
const POOL_INVISIBILITY='rpg:bloodedge_pool_invisibility';
const guardTag=slot=>'rpg_be_guard_'+slot;
const frontTag=slot=>'rpg_be_front_'+slot;
const pools=new Map(),pins=new Map(),awakenings=new Map(),altars=new Map();
const AWAKEN_EFFECTS=[['strength',2,30],['resistance',1,30],['night_vision',0,240],['haste',2,30]];
let registered=false;

const offset=(p,dy)=>({...p,y:p.y+dy});
function active(p,dimension) {
  try {
    return p.isValid!==false && p.dimension.id===dimension && healthAlive(p) &&
      isBloodedgeJob(getJobId(p)) && !isJailed(p);
  } catch { return false; }
}
function usable(p,dimension) { return active(p,dimension) && !isTimeFrozen(p); }

function ownsEffect(state,id,effect){
  const ours=state.effects.get(id);
  return ours && effect?.amplifier===ours.amp && Math.abs(system.currentTick+effect.duration-ours.until)<=2;
}

function maintainAwakeningEffect(state,id,amp,duration){
  const p=state.player,now=system.currentTick,current=p.getEffect(id);
  const ours=ownsEffect(state,id,current);
  if(current && !ours && current.amplifier>=amp)return;
  if(ours && current.duration>duration-15)return;
  const prior=ours?state.effects.get(id).prior:current?{amp:current.amplifier,until:now+current.duration}:state.effects.get(id)?.prior;
  p.addEffect(id,duration,{amplifier:amp,showParticles:false});
  state.effects.set(id,{amp,until:now+duration,prior});
}

function stopAwakening(id,player,restore=true){
  const state=awakenings.get(id);
  if(!state)return false;
  awakenings.delete(id);
  const p=player??state.player;
  for(const [effect,{prior}] of state.effects)try{
    const current=p.getEffect(effect);
    if(current && !ownsEffect(state,effect,current))continue;
    if(current)p.removeEffect(effect);
    const ticks=(prior?.until??0)-system.currentTick;
    if(restore && ticks>0)p.addEffect(effect,ticks,{amplifier:prior.amp,showParticles:false});
  }catch{}
  return true;
}

function awaken(p,_job,def){
  if(!isBloodedgeJob(getJobId(p)))return false;
  if(stopAwakening(p.id,p)){notify(p,'§7'+def.name+' 해제');return true;}
  if(!usable(p,p.dimension.id))return false;
  if(getMana(p)<def.manaPerSecond/20){notify(p,'§c'+def.name+'을 유지할 마나가 부족합니다.');return false;}
  const profile=AWAKEN_EFFECTS.map(([id,amp,ticks])=>[id,def[id]??amp,ticks]);
  const now=system.currentTick,state={player:p,dimension:p.dimension.id,def,profile,start:now,paidThrough:now,effects:new Map()};
  awakenings.set(p.id,state);
  try{
    for(const args of profile)maintainAwakeningEffect(state,...args);
  }catch{stopAwakening(p.id,p);return false;}
  ring(p.dimension,offset(p.location,0.6),0.75,10,SPARK);
  notify(p,'§c'+def.name+' 활성화 · 초당 MP '+def.manaPerSecond);
  return true;
}

function tickAwakening(state,now){
  const p=state.player,{def}=state;
  if(!active(p,state.dimension)){stopAwakening(p.id,p,healthAlive(p));return;}
  const due=(now-state.paidThrough)*def.manaPerSecond/20;
  if(due>0){
    if(getMana(p)<due){stopAwakening(p.id,p);notify(p,'§7마나 부족 · '+def.name+' 해제');return;}
    spendMana(p,due);
    state.paidThrough=now;
  }
  const elapsed=now-state.start;
  if(elapsed>=def.warningTicks && state.nextLoss===undefined){
    state.nextLoss=now;
    try{p.sendMessage('§c1분간 '+def.name+'을 사용하여 서서히 죽어간다!');}catch{}
  }
  if(elapsed%10===0)for(const args of state.profile)maintainAwakeningEffect(state,...args);
  if(state.nextLoss===undefined)return;
  maintainAwakeningEffect(state,'wither',4,30);
  if(now<state.nextLoss)return;
  const hp=p.getComponent('minecraft:health');
  if(hp?.currentValue>0)hp.setCurrentValue(Math.max(0,hp.currentValue-rpgMaxHealth(p,hp)*def.healthLossRatio));
  state.nextLoss=now+20;
}
function ring(dim,center,radius,count,fx=SIGIL) {
  for(let i=0;i<count;i++){
    const a=i*Math.PI*2/count;
    particle(dim,fx,{x:center.x+Math.cos(a)*radius,y:center.y,z:center.z+Math.sin(a)*radius});
  }
}
function enemies(p,loc,radius) {
  return getTargets(p,loc,radius).filter(target=>{
    if(dist3(loc,target.location)>radius)return false;
    const mode=String(target.getGameMode?.()).toLowerCase();
    return mode!=='creative' && mode!=='spectator';
  });
}

function drawBarrier(p,flash=false) {
  const dim=p.dimension,front=flatDir(p),head=headPos(p);
  const center={x:head.x+front.x*1.85,y:head.y-0.38,z:head.z+front.z*1.85};
  if(flash){
    particle(dim,BURST,center);
    particle(dim,'rpg:bloodedge_guard_flash',center);
    sound(dim,'item.shield.block',center,{volume:0.65,pitch:0.82});
    return;
  }
  const phase=system.currentTick*0.09;
  for(let i=0;i<6;i++){
    const angle=phase+i*Math.PI/3,across=Math.cos(angle)*1.14;
    particle(dim,SPARK,{x:center.x+front.z*across,y:center.y+Math.sin(angle)*0.99,z:center.z-front.x*across});
  }
  particle(dim,'rpg:bloodedge_barrier',center);
}

function flashBarrier(p) {
  const session=shieldSessions.get(p?.id);
  if(!session || session.until<=system.currentTick || system.currentTick-(session.flashTick??-100)<3)return;
  session.flashTick=system.currentTick;
  drawBarrier(p,true);
}

function clearShield(s) {
  shieldSessions.delete(s.player.id);
  try { s.player.removeTag(guardTag(s.slot)); } catch {}
  try { s.player.removeTag(BLOODEDGE_MEASURE_TAG); } catch {}
  for(const entity of s.marked.values())try{entity.removeTag(frontTag(s.slot));}catch{}
}
function markShieldFront(s){
  const p=s.player,tag=frontTag(s.slot),next=new Map();
  for(const entity of p.dimension.getEntities({location:p.location,maxDistance:48,excludeTypes:['minecraft:item','minecraft:xp_orb']})){
    if(entity.id===p.id)continue;
    try{
      if(!isShieldFront(p,entity)){
        if(entity.hasTag(tag))entity.removeTag(tag);
        continue;
      }
      if(!entity.hasTag(tag))entity.addTag(tag);
      next.set(entity.id,entity);
    }catch{}
  }
  for(const [id,entity] of s.marked)if(!next.has(id))try{entity.removeTag(tag);}catch{}
  s.marked=next;
}
function shield(p,_job,def) {
  if(shieldSessions.has(p.id))return false;
  const taken=new Set(Array.from(shieldSessions.values(),state=>state.slot));
  const slot=Array.from({length:SLOTS},(_,index)=>index).find(index=>!taken.has(index));
  if(slot===undefined){notify(p,'§7지금은 '+def.name+'을 펼칠 수 없습니다.');return false;}
  const state={player:p,def,slot,dimension:p.dimension.id,until:system.currentTick+def.duration,marked:new Map()};
  try{
    markShieldFront(state);
    p.addTag(guardTag(slot));
    if(def.bloodReserve&&!world.beforeEvents?.entityHurt)p.addTag(BLOODEDGE_MEASURE_TAG);
  }catch{clearShield(state);return false;}
  shieldSessions.set(p.id,state);
  drawBarrier(p);
  notify(p,'§c'+def.name+' · '+def.duration/20+'초');
  return true;
}
function endShield(s,burst) {
  clearShield(s);
  if(!burst)return;
  const p=s.player,origin=p.location;
  try{
    const variables=new MolangVariableMap();
    variables.setFloat('variable.barrier_radius',s.def.radius);
    particle(p.dimension,'rpg:bloodedge_rupture',offset(origin,0.16),variables);
  }catch{particle(p.dimension,'rpg:bloodedge_rupture',offset(origin,0.16));}
  particle(p.dimension,'rpg:bloodedge_guard_flash',offset(origin,0.95));
  sound(p.dimension,'random.explode',origin,{volume:0.75,pitch:0.6});
  for(const target of enemies(p,origin,s.def.radius)){
    if(!clearBlockPath(p.dimension,offset(origin,0.9),offset(target.location,0.9)))continue;
    if(!hurt(target,p,s.def.damage,'magic',{ignoreInvulnerability:true}))continue;
    knockback(target,target.location.x-origin.x,target.location.z-origin.z,s.def.knockback,0.35);
  }
}

const flightOptions={ignoreInvulnerability:true,immediatePlague:true};

function visibleEnemy(p,origin,target,height=0.9) {
  return clearBlockPath(p.dimension,origin,offset(target.location,height));
}

function volley(p,_job,def) {
  const dim=p.dimension,origin=headPos(p);
  const motion=projectileMotion(p,def.speed,3);
  const aim=norm3(p.getViewDirection());
  const rays=shotgunDirections(aim,flatDir(p),def.shots,def.spread).map(dir=>({at:origin,dir}));
  const flashAt={x:origin.x+aim.x*0.85,y:origin.y+aim.y*0.85,z:origin.z+aim.z*0.85};
  const burstAt=clearBlockPath(dim,origin,flashAt)?flashAt:origin;
  particle(dim,'rpg:bloodedge_guard_flash',burstAt);
  particle(dim,BURST,burstAt);
  const hits=new Map();
  let traveled=0,activeRays=rays;
  const timer=system.runInterval(()=>{
    if(!usable(p,dim.id) || traveled>=def.range || activeRays.length===0){system.clearRun(timer);return;}
    // One query per volley tick. Intersect each pellet independently so overlapping rays
    // count separately while the per-target cap applies across the entire volley.
    const distance=Math.min(motion.speed,def.range-traveled);
    const targets=enemies(p,offset(origin,-0.9),traveled+distance+def.radius+1).filter(target=>{
      const body=offset(target.location,0.9);
      return (body.x-origin.x)*aim.x+(body.y-origin.y)*aim.y+(body.z-origin.z)*aim.z>=0;
    });
    const step=distance/motion.steps;
    activeRays=activeRays.filter(ray=>{
      let trail;
      for(let sub=0;sub<motion.steps;sub++){
        const next={x:ray.at.x+ray.dir.x*step,y:ray.at.y+ray.dir.y*step,z:ray.at.z+ray.dir.z*step};
        if(!clearBlockPath(dim,ray.at,next)){particle(dim,BURST,ray.at);return false;}
        ray.at=next;
        if(sub===Math.floor(motion.steps/2))trail=next;
        let contact,closest=def.radius;
        for(const target of targets){
          if(!healthAlive(target))continue;
          const gap=dist3(next,offset(target.location,0.9));
          if(gap<=closest && visibleEnemy(p,next,target)){contact=target;closest=gap;}
        }
        if(contact){
          const count=hits.get(contact.id)??0;
          if(count<def.maxHits && hurt(contact,p,def.damage,'magic',flightOptions)){
            hits.set(contact.id,count+1);
            const pin=pins.get(contact.id);
            if(def.bindBonus&&pin?.royal&&pin.owner.id===p.id&&pin.until>system.currentTick&&!pin.volleyBonus){
              pin.volleyBonus=true;
              hurt(contact,p,def.bindBonus,'magic',flightOptions);
            }
          }
          particle(dim,BURST,next);
          return false;
        }
      }
      particle(dim,SPARK,trail??ray.at);
      particle(dim,'rpg:bloodedge_shard',ray.at);
      return true;
    });
    traveled+=distance;
  },1);
  sound(dim,'mob.blaze.shoot',origin,{volume:0.7,pitch:1.6});
  return true;
}

function lanceOrb(dim,center,radius) {
  try{
    const variables=new MolangVariableMap();
    variables.setFloat('variable.bloodedge_radius',radius);
    particle(dim,'rpg:bloodedge_lance',center,variables);
  }catch{}
}

function lanceImpact(p,dim,center,def){
  ring(dim,center,def.blastRadius,30,BURST);
  lanceOrb(dim,center,def.orbRadius);
  sound(dim,'random.explode',center,{volume:1,pitch:0.6});
  for(const target of enemies(p,center,def.blastRadius+1)){
    if(dist3(center,offset(target.location,0.9))<=def.blastRadius && visibleEnemy(p,center,target)){
      hurt(target,p,def.damage,'magic',flightOptions);
    }
  }
}

function launchLance(p,dim,center,target,def) {
  const aim=offset(target.location,0.9);
  const direction=norm3({x:aim.x-center.x,y:aim.y-center.y,z:aim.z-center.z});
  const motion=projectileMotion(p,def.speed,3);
  let at=center,travel=0;
  sound(dim,'mob.blaze.shoot',center,{volume:1,pitch:0.55});
  const timer=system.runInterval(()=>{
    if(!usable(p,dim.id)){system.clearRun(timer);return;}
    for(let sub=0;sub<motion.steps;sub++){
      const step=Math.min(motion.step,def.range-travel);
      const next={x:at.x+direction.x*step,y:at.y+direction.y*step,z:at.z+direction.z*step};
      const clear=clearBlockPath(dim,at,next);
      if(clear){at=next;travel+=step;}
      const touches=enemies(p,at,def.orbRadius+1).some(e=>
        dist3(at,offset(e.location,0.9))<=def.orbRadius && visibleEnemy(p,at,e));
      if(!clear || touches || travel>=def.range){
        system.clearRun(timer);lanceImpact(p,dim,at,def);return;
      }
    }
    lanceOrb(dim,at,def.orbRadius);
  },1);
}

function lance(p,_job,def) {
  def=bloodBoost(p,def);
  const dim=p.dimension,start=system.currentTick;
  const timer=system.runInterval(()=>{
    if(!usable(p,dim.id)){system.clearRun(timer);return;}
    const elapsed=system.currentTick-start;
    const radius=def.orbRadius*Math.max(0.08,Math.min(1,elapsed/def.charge));
    const center=offset(headPos(p),radius+0.4);
    lanceOrb(dim,center,radius);
    if(elapsed<def.charge)return;
    system.clearRun(timer);
    const origin=p.location;
    const target=!isSolidAt(dim,center) && enemies(p,origin,def.range)
      .sort((a,b)=>dist3(origin,a.location)-dist3(origin,b.location))
      .find(e=>visibleEnemy(p,center,e));
    if(target)launchLance(p,dim,center,target,def);
    else notify(p,'§7'+def.name+'을 던질 적이 없습니다.');
  },1);
  return true;
}
function bind(p,_job,def,target){
  const targets=enemies(p,p.location,def.radius);
  if(!target || !targets.some(enemy=>enemy.id===target.id)){
    notify(p,'§7'+def.name+'을 쓰려면 적을 좌클릭으로 맞히세요.');return false;
  }
  const now=system.currentTick;
  for(const enemy of targets){
    const duration=ccTicks(enemy,def.duration),anchor={...enemy.location};
    pins.set(enemy.id,{owner:p,target:enemy,anchor,dimension:enemy.dimension.id,until:now+duration,royal:!!def.evolvesFrom});
    ring(p.dimension,offset(anchor,0.5),0.8,12);
  }
  return true;
}

function actualMagicDamage(p,target,amount) {
  const health=target.getComponent('minecraft:health'),before=health?.currentValue??0;
  if(before<=0 || !hurt(target,p,amount,'magic',flightOptions))return 0;
  let after=0;
  try { after=health.currentValue; } catch {}
  return Math.max(0,before-after);
}
function healFromDamage(player,amount) {
  const hp=player.getComponent('minecraft:health');
  if(hp?.currentValue>0 && amount>0)hp.setCurrentValue(Math.min(rpgMaxHealth(player,hp),hp.currentValue+amount));
}
function transfusion(p,_job,def) {
  const origin=p.location;
  const target=enemies(p,origin,def.range)
    .sort((a,b)=>rpgMaxHealth(b,b.getComponent('minecraft:health'))-rpgMaxHealth(a,a.getComponent('minecraft:health')) ||
      dist3(origin,a.location)-dist3(origin,b.location))
    .find(e=>visibleEnemy(p,headPos(p),e));
  if(!target){notify(p,'§7'+def.name+'을 사용할 적이 없습니다.');return false;}
  const amount=actualMagicDamage(p,target,def.damage);
  if(amount>0&&def.bloodGain&&target.typeId!=='rpg:sandbag_entity'&&target.typeId!=='rpg:super_sandbag')gainBloodReserve(p,def.bloodGain);
  healFromDamage(p,amount*def.healRatio);
  ring(p.dimension,offset(p.location,0.7),0.75,12,SPARK);
  return true;
}
function plague(p,_job,def) {
  const dimension=p.dimension.id;
  const targets=enemies(p,p.location,def.radius).filter(e=>
    !plagueSessions.has(e.id) && visibleEnemy(p,headPos(p),e));
  if(!targets.length){notify(p,'§7'+def.name+'에 감염시킬 적이 없습니다.');return false;}
  for(const target of targets){
    plagueSessions.set(target.id,{player:p,target,def,dimension,until:system.currentTick+def.duration,damage:0});
    ring(target.dimension,offset(target.location,0.45),1,12);
  }
  return true;
}

function onPlagueHurt(ev) {
  const target=ev.hurtEntity,mark=activeBloodPlague(target);
  if(!mark || !(ev.damage>0))return;
  const source=ev.damageSource?.damagingEntity,projectile=ev.damageSource?.damagingProjectile;
  if(isBloodedgePool(target) || blocksBloodedgeDamage(target,projectile??source))return;
  const hp=target.getComponent('minecraft:health');
  if(!hp || hp.currentValue<=0)return;
  const amount=actualHurtAmount(ev,undefined,{peek:true});
  mark.damage+=amount;
  if(!plagueAdjustedHit(source,target) && amount>0){
    setCombatHealth(target,source,hp,Math.max(0,hp.currentValue-amount*mark.def.vulnerability),
      {plagueIncluded:true,raceIncluded:true,armorIncluded:true});
  }
}

function removePoolAppearance(p){
  if(!p.hasTag(BLOODEDGE_POOL_TAG))return;
  p.triggerEvent('rpg:bloodedge_pool_off');
  p.removeTag(BLOODEDGE_POOL_TAG);
  if(p.getDynamicProperty(POOL_INVISIBILITY)===true && p.getEffect?.('invisibility')?.amplifier===1)p.removeEffect('invisibility');
  p.setDynamicProperty(POOL_INVISIBILITY,undefined);
}
function endPool(s,heal){
  const p=s.player;
  pools.delete(p.id);
  try{removePoolAppearance(p);}catch{}
  if(!heal)return;
  healFromDamage(p,s.damage*s.def.healRatio);
}
function bloodBoost(p,def){
  if(!def.bloodBoost||!spendBloodReserve(p))return def;
  notify(p,'§c혈기 60 소모 · '+def.name+' 강화');
  return {...def,...def.bloodBoost,boosted:true};
}
function pool(p,_job,def){
  if(pools.has(p.id))return false;
  try{
    p.addTag(BLOODEDGE_POOL_TAG);
    p.triggerEvent('rpg:bloodedge_pool_on');
    if(!p.getEffect?.('invisibility')){
      p.addEffect('invisibility',def.duration,{amplifier:1,showParticles:false});
      p.setDynamicProperty(POOL_INVISIBILITY,true);
    }
  }catch{
    try{removePoolAppearance(p);}catch{}
    return false;
  }
  def=bloodBoost(p,def);
  const start=system.currentTick;
  pools.set(p.id,{player:p,def,dimension:p.dimension.id,until:start+def.duration,next:start+20,damage:0});
  if(!def.boosted)notify(p,'§c'+def.name+' · '+def.duration/20+'초');
  return true;
}

function bloodStep(p,_job,def){
  const dim=p.dimension,origin={...p.location},dir=norm3(p.getViewDirection());
  const options={dimension:dim,keepVelocity:false,checkForBlocks:true};
  let distance=0,landing=origin;
  const steps=Math.ceil(def.range/.35);
  const corners=[[-.28,-.28],[-.28,.28],[.28,-.28],[.28,.28]];
  for(let i=1;i<=steps;i++){
    const reach=def.range*i/steps;
    const at={x:origin.x+dir.x*reach,y:origin.y+dir.y*reach,z:origin.z+dir.z*reach};
    if(corners.some(([x,z])=>[.1,1.55].some(y=>isSolidAt(dim,{x:at.x+x,y:at.y+y,z:at.z+z}))))break;
    try{checkSkillMovement(p,at,options);}catch{break;}
    landing=at;distance=reach;
  }
  if(!distance)return false;
  try{teleportForSkill(p,landing,options);}catch{return false;}
  const start=offset(origin,.9);
  for(const target of enemies(p,origin,distance+def.radius+1)){
    const at=offset(target.location,.9);
    const along=Math.max(0,Math.min(distance,(at.x-start.x)*dir.x+(at.y-start.y)*dir.y+(at.z-start.z)*dir.z));
    const closest={x:start.x+dir.x*along,y:start.y+dir.y*along,z:start.z+dir.z*along};
    if(dist3(closest,at)<=def.radius&&visibleEnemy(p,closest,target))hurt(target,p,def.damage,'magic',flightOptions);
  }
  for(let d=0;d<distance;d+=.5)particle(dim,SPARK,{x:start.x+dir.x*d,y:start.y+dir.y*d,z:start.z+dir.z*d});
  particle(dim,BURST,offset(landing,.9));
  return true;
}

function altar(p,_job,def){
  const dim=p.dimension,hit=p.getBlockFromViewDirection({maxDistance:def.range});
  if(!hit||String(hit.face).toLowerCase()!=='up'){
    notify(p,'§7'+def.name+'을 설치할 지면을 바라보세요.');return false;
  }
  const block=hit.block.location,center={x:block.x+.5,y:block.y+1,z:block.z+.5},now=system.currentTick;
  if(isSolidAt(dim,offset(center,.1)))return false;
  altars.set(p.id,{player:p,def,dimension:dim.id,center,until:now+def.duration,next:now+20});
  ring(dim,offset(center,.15),def.radius,24);
  particle(dim,BURST,offset(center,.5));
  return true;
}

function pulseAltar({player:p,def,center}){
  const origin=offset(center,.4);
  for(const target of enemies(p,center,def.radius)){
    if(visibleEnemy(p,origin,target))hurt(target,p,def.damage,'magic',flightOptions);
  }
  for(const ally of p.dimension.getPlayers({location:center,maxDistance:def.radius})){
    if(areAllies(p,ally)&&visibleEnemy(p,origin,ally))healFromDamage(ally,def.heal);
  }
}
function pulsePool(s){
  const p=s.player,origin=p.location;
  for(const target of enemies(p,origin,s.def.radius+1)){
    const pos=target.location;
    if(Math.hypot(pos.x-origin.x,pos.z-origin.z)>s.def.radius || pos.y-origin.y<-.65 ||
       pos.y-origin.y>1.25 || !clearBlockPath(p.dimension,offset(origin,0.6),offset(pos,0.6)))continue;
    s.damage+=actualMagicDamage(p,target,s.def.damage);
  }
}
function tick(){
  const now=system.currentTick;
  for(const [id,state] of awakenings){
    try{tickAwakening(state,now);}catch{stopAwakening(id);}
  }
  for(const s of shieldSessions.values()){
    try{
      if(!active(s.player,s.dimension) || now>=s.until){
        endShield(s,now>=s.until && usable(s.player,s.dimension));continue;
      }
      markShieldFront(s);
      if(now%3===0)drawBarrier(s.player);
    }catch{clearShield(s);}
  }
  for(const [id,s] of pins){
    try{
      if(now>=s.until || !usable(s.owner,s.dimension) || !healthAlive(s.target) ||
        s.target.dimension.id!==s.dimension || areAllies(s.owner,s.target) || isBloodedgePool(s.target) ||
        dist3(s.target.location,s.anchor)>12){
        pins.delete(id);continue;
      }
      if(dist3(s.target.location,s.anchor)>.05)
        s.target.teleport(s.anchor,{dimension:s.target.dimension,keepVelocity:false,checkForBlocks:true});
      s.target.clearVelocity?.();
      if(now%6===0)ring(s.target.dimension,offset(s.anchor,0.3),0.65,8);
    }catch{pins.delete(id);}
  }
  for(const s of pools.values()){
    try{
      const p=s.player;
      if(!active(p,s.dimension)){endPool(s,false);continue;}
      if(!isTimeFrozen(p)){
        if(now%4===0){
          const center=offset(p.location,0.1);
          particle(p.dimension,'rpg:bloodedge_pool',center);
          ring(p.dimension,center,s.def.radius,24);
        }
        if(now>=s.next){pulsePool(s);s.next=now+20;}
      }else if(now>=s.next){s.next=now+20;}
      if(now>=s.until)endPool(s,true);
    }catch{endPool(s,false);}
  }
  for(const [id,state] of altars){
    try{
      if(!active(state.player,state.dimension)){altars.delete(id);continue;}
      if(usable(state.player,state.dimension)&&now<=state.until){
        if(now%8===0)ring(state.player.dimension,offset(state.center,.12),state.def.radius,18,SPARK);
        if(now>=state.next){pulseAltar(state);state.next=now+20;}
      }
      if(now>=state.until)altars.delete(id);
    }catch{altars.delete(id);}
  }
  for(const [id,mark] of plagueSessions){
    try{
      const {player,target,def,dimension}=mark;
      if(!active(player,dimension) || !healthAlive(target) || target.dimension.id!==dimension ||
        areAllies(player,target) || isBloodedgePool(target) || (!CONFIG.pvp && target.typeId==='minecraft:player')){
        plagueSessions.delete(id);continue;
      }
      if(now>=mark.until){
        plagueSessions.delete(id);
        if(mark.damage>0 && usable(player,dimension)){
          hurt(target,player,mark.damage*def.burstRatio,'magic',flightOptions);
          ring(target.dimension,offset(target.location,0.7),1.2,18,BURST);
        }
      }else if(now%10===0)particle(target.dimension,SIGIL,offset(target.location,1.2));
    }catch{plagueSessions.delete(id);}
  }
}
function resetPlayer(p){
  clearBloodReserve(p.id);
  altars.delete(p.id);
  try{
    stopAwakening(p.id,p,false);
    const s=shieldSessions.get(p.id);if(s)clearShield(s);
    const state=pools.get(p.id);if(state)endPool(state,false);
    for(let i=0;i<SLOTS;i++)if(p.hasTag(guardTag(i)))p.removeTag(guardTag(i));
    p.removeTag(BLOODEDGE_MEASURE_TAG);
    removePoolAppearance(p);
  }catch{}
}
export function registerBloodedge(){
  if(registered)return;registered=true;
  world.beforeEvents?.entityHurt?.subscribe(ev=>{
    const p=ev.hurtEntity,source=ev.damageSource;
    try{
      if(blocksBloodedgeDamage(p,source?.damagingProjectile??source?.damagingEntity)){
        ev.cancel=true;
        creditBarrierBlock(p,ev.damage);
        system.run(()=>{try{flashBarrier(p);}catch{}});
      }
    }catch{}
  });
  world.afterEvents.entityHurt.subscribe(ev=>{
    const p=ev.hurtEntity,source=ev.damageSource;
    try{
      if(!blocksBloodedgeDamage(p,source?.damagingProjectile??source?.damagingEntity)){onPlagueHurt(ev);return;}
      flashBarrier(p);
      creditBarrierBlock(p,ev.damage);
      const hp=p.getComponent('minecraft:health');
      if(hp?.currentValue>0 && ev.damage>0)hp.setCurrentValue(Math.min(rpgMaxHealth(p,hp),hp.currentValue+ev.damage));
    }catch{}
  });
  world.afterEvents.dataDrivenEntityTrigger?.subscribe(({entity,eventId})=>{
    if(eventId!=='rpg:bloodedge_block_front')return;
    try{
      if(entity.hasTag(BLOODEDGE_MEASURE_TAG)){
        // The native fatal-hit event omits damage; the HP it would have removed is the known amount.
        creditBarrierBlock(entity,entity.getComponent('minecraft:health')?.currentValue);
      }
      flashBarrier(entity);
    }catch{}
  },{entityTypes:['minecraft:player'],eventTypes:['rpg:bloodedge_block_front']});
  world.afterEvents.entityLoad?.subscribe(({entity})=>{
    try{
      for(const tag of entity.getTags())if(tag.startsWith('rpg_be_front_'))entity.removeTag(tag);
    }catch{}
  });
  world.afterEvents.playerLeave.subscribe(({playerId})=>{
    clearBloodReserve(playerId);
    altars.delete(playerId);
    stopAwakening(playerId);
    const shield=shieldSessions.get(playerId);if(shield)clearShield(shield);
    pools.delete(playerId);
    for(const [id,mark] of plagueSessions)if(id===playerId||mark.player.id===playerId)plagueSessions.delete(id);
    for(const [id,s] of pins)if(id===playerId||s.owner.id===playerId)pins.delete(id);
  });
  world.afterEvents.playerSpawn.subscribe(({player})=>resetPlayer(player));
  world.afterEvents.entityDie.subscribe(({deadEntity})=>{
    pins.delete(deadEntity.id);
    plagueSessions.delete(deadEntity.id);
    if(deadEntity.typeId==='minecraft:player')resetPlayer(deadEntity);
  });
  system.run(()=>{for(const p of world.getAllPlayers())resetPlayer(p);});
  system.runInterval(tick,1);
}

export const RUNNERS={
  bloodedge_shield:shield,bloodedge_volley:volley,bloodedge_lance:lance,bloodedge_bind:bind,bloodedge_pool:pool,
  bloodedge_transfusion:transfusion,bloodedge_plague:plague,bloodedge_awakening:awaken,
  crimson_step:bloodStep,crimson_altar:altar,
};
for(const def of Object.values(SKILLS))if(RUNNERS[def.evolvesFrom])RUNNERS[def.id]=RUNNERS[def.evolvesFrom];
