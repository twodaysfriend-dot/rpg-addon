"""Compose abyssal armor with existing native race, ward and resurrection sensors.

Keep native armor and Protection enchantments. Above Bedrock's 20 armor cap,
each overflow point reduces remaining damage by 4%; toughness adds 1% per point.
Damage sensor triggers are mutually exclusive; resurrection triggers stay intact.
"""
import copy
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
path = root / 'RPG_BP_v0638/entities/player.json'
original = path.read_text()
data = json.loads(original)
entity = data['minecraft:entity']
profiles = [(0, 0)] + [(n, overflow) for n in (1, 2, 3) for overflow in range(n * 2 + 1)] + [(4, 8)]
prefix = 'rpg_abyssal_'

# Each active Bloodedge shield has a slot; only entities marked in front of that
# specific player match. Slots let two players face the same attacker independently.
guard = {'any_of': [
    {'all_of': [
        {'test': 'has_tag', 'subject': 'self', 'value': f'rpg_be_guard_{slot}'},
        {'any_of': [{'test': 'has_tag', 'subject': subject, 'value': f'rpg_be_front_{slot}'}
                    for subject in ('other', 'damager')]},
    ]}
    for slot in range(16)
]}
guard_event = 'rpg:bloodedge_block_front'
# Stable Script API measures the promoted shield's nonfatal hits in the hurt event.
# Keep lethal hits blocked in the native sensor even during that measurement.
measure = {'test': 'has_tag', 'subject': 'self', 'value': 'rpg_be_measure'}
protected_guard = {'all_of': [guard, {'any_of': [{'none_of': [measure]}, {'test': 'has_damage', 'value': 'fatal'}]}]}

for container in [entity['components'], *entity['component_groups'].values()]:
    sensor = container.get('minecraft:damage_sensor')
    if not sensor:
        continue
    templates = []
    for trigger in sensor['triggers']:
        trigger = copy.deepcopy(trigger)
        on_damage = trigger.get('on_damage', {})
        if on_damage.get('event') == guard_event:
            continue
        f = on_damage.get('filters', {})
        if f.get('all_of', [{}])[-1] in ({'none_of': [guard]}, {'none_of': [protected_guard]}):
            f = f['all_of'][0]
            on_damage['filters'] = f
        tail = f.get('all_of', [{}])[-1]
        if tail.get('test') == 'has_tag' and str(tail.get('value', '')).startswith(prefix):
            continue
        if 'none_of' in tail and any(str(x.get('value', '')).startswith(prefix) for x in tail['none_of']):
            trigger['on_damage']['filters'] = f['all_of'][0]
        templates.append(trigger)
    result = []
    for template in templates:
        if 'damage_multiplier' not in template:
            result.append(template)
            continue
        for count, overflow in profiles:
            trigger = copy.deepcopy(template)
            condition = ({'none_of': [{'test': 'has_tag', 'subject': 'self', 'value': 'rpg_abyssal_active'}]}
                         if not count else {'test': 'has_tag', 'subject': 'self', 'value': prefix + str(count * 9 + overflow)})
            trigger['on_damage']['filters'] = {'all_of': [template['on_damage']['filters'], condition]}
            trigger['damage_multiplier'] = round(template['damage_multiplier'] * (1 - overflow * .04) * (1 - count * .04), 10)
            result.append(trigger)
    # Prevent a blocked fatal hit from consuming the resurrection mark.
    for trigger in result:
        gate = trigger.get('on_damage', {})
        if gate.get('event') == 'rpg:resurrection_save':
            gate['filters'] = {'all_of': [gate['filters'], {'none_of': [protected_guard]}]}
    sensor['triggers'] = [{
        'cause': 'all', 'deals_damage': False,
        'on_damage': {'event': guard_event, 'target': 'self', 'filters': protected_guard},
    }, *result]

groups = [f'rpg:abyssal_knockback_{n}' for n in range(5)]
for count, key in enumerate(groups):
    entity['component_groups'][key] = {'minecraft:knockback_resistance': {'value': round(count * .2, 2)}}
    entity['events'][key] = {'sequence': [{'remove': {'component_groups': groups}}, {'add': {'component_groups': [key]}}]}
entity['events'][guard_event] = {}
pool_group = 'rpg:bloodedge_untargetable'
entity['component_groups'][pool_group] = {
    'minecraft:cannot_be_attacked': {}, 'minecraft:is_hidden_when_invisible': {},
}
entity['events']['rpg:bloodedge_pool_on'] = {'add': {'component_groups': [pool_group]}}
entity['events']['rpg:bloodedge_pool_off'] = {'remove': {'component_groups': [pool_group]}}
# Native profile combinations repeat filters; compact JSON keeps the pack small.
output = json.dumps(data, ensure_ascii=False, separators=(',', ':')) + '\n'
if '--check' in sys.argv:
    assert output == original, 'Stale generated abyssal armor sensors'
else:
    path.write_text(output)
print('Verified' if '--check' in sys.argv else 'Generated', '17 armor profiles across native race/ward sensors; knockback 0/20/40/60/80%')
