"""Export the generated reference-book artwork on a hard 32px logical grid."""
from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parents[1]
sprite=Image.open(root/'art/skillbook_generated.png').convert('RGBA').resize((32,32),Image.Resampling.NEAREST)
sprite.putdata([(r,g,b,255) if a>=128 else (0,0,0,0) for r,g,b,a in sprite.get_flattened_data()])
sprite=sprite.quantize(colors=24,method=Image.Quantize.FASTOCTREE,dither=Image.Dither.NONE).convert('RGBA')
sprite.resize((128,128),Image.Resampling.NEAREST).save(root/'RPG_RP_v0566/textures/items/rpg_equipment/random_skillbook.png')
