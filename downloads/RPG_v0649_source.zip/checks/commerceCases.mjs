// Real module transactions exercised through the shared Minecraft API fixture.
export default async function commerceCases({assert,mod,player,ItemStack,Form,world,signal}){
 const wallet=mod('core/wallet.js'),runes=mod('core/runeInventory.js'),auto=mod('core/runeAuto.js'),batch=mod('core/runeBatch.js'),transfer=mod('core/currencyTransfer.js'),shop=mod('core/xpShop.js'),up=mod('data/upgrades.js');
 const plain=x=>JSON.parse(JSON.stringify(x));
 const funds=p=>wallet.setWallet(p,{gold:10000000,stone:77,dust:10000});
 const seed=(p,entries)=>{const bag=runes.readRuneBag(p);for(const [id,level,grade]of entries)runes.addRuneRecord(bag,id,level,grade);runes.writeRuneBag(p,bag);return bag;};
 const inventoryState=inv=>Array.from({length:inv.size},(_,i)=>{const t=inv.getItem(i);return t?{id:t.typeId,n:t.amount,props:[...t.props]}:null;});
 {
  const a=player().p,b=player().p;a.id='payer';b.id='receiver';a.name='Payer';b.name='Receiver';const online=world.getAllPlayers;world.getAllPlayers=()=>[a,b];
  try{
   wallet.setWallet(a,{gold:1000,stone:1000,dust:1000});wallet.setWallet(b,{gold:10,stone:10,dust:10});
   for(const k of ['gold','stone','dust']){const beforeA=wallet.getWallet(a),beforeB=wallet.getWallet(b);assert.equal(transfer.transferCurrency(a,b,k,125).ok,true);assert.equal(wallet.getWallet(a)[k],beforeA[k]-125);assert.equal(wallet.getWallet(b)[k],beforeB[k]+125);for(const other of ['gold','stone','dust'].filter(c=>c!==k)){assert.equal(wallet.getWallet(a)[other],beforeA[other]);assert.equal(wallet.getWallet(b)[other],beforeB[other]);}}
   const unchanged=()=>JSON.stringify([wallet.getWallet(a),wallet.getWallet(b)]);let old=unchanged();
   for(const n of [0,-1,1.5,NaN,Infinity,Number.MAX_SAFE_INTEGER])assert.equal(transfer.transferCurrency(a,b,'gold',n).ok,false);
   assert.equal(transfer.transferCurrency(a,b,'toString',1).ok,false);assert.equal(transfer.transferCurrency(a,a,'gold',1).ok,false);assert.equal(transfer.transferCurrency(a,b,'gold',10000).ok,false);assert.equal(unchanged(),old);
   wallet.setWallet(b,{gold:wallet.BALANCE_MAX,stone:10,dust:10});old=unchanged();assert.equal(transfer.transferCurrency(a,b,'gold',1).ok,false);assert.equal(unchanged(),old);
   world.getAllPlayers=()=>[a];assert.equal(transfer.transferCurrency(a,b,'dust',1).ok,false);world.getAllPlayers=()=>[a,b];
   // Receiver storage throws after modifying data: both wallets must roll back.
   const setter=b.setDynamicProperty;let fail=true;b.setDynamicProperty=(key,v)=>{setter(key,v);if(key===wallet.WALLET_KEY&&fail){fail=false;throw Error('receiver storage failed');}};
   old=unchanged();assert.equal(transfer.transferCurrency(a,b,'dust',5).ok,false);assert.equal(unchanged(),old);b.setDynamicProperty=setter;
   const senderSetter=a.setDynamicProperty;let nested;a.setDynamicProperty=(key,v)=>{if(key===wallet.WALLET_KEY)nested=transfer.transferCurrency(a,b,'stone',1);senderSetter(key,v);};assert.equal(transfer.transferCurrency(a,b,'stone',2).ok,true);assert.equal(nested.ok,false);a.setDynamicProperty=senderSetter;
   const oldShow=Form.prototype.show;const replies=[{selection:0},{selection:2},{formValues:['7']},{selection:1}];Form.prototype.show=()=>Promise.resolve(replies.shift()??{canceled:true});
   try{const before=wallet.getWallet(b).dust;await transfer.openCurrencyTransfer(a);assert.equal(wallet.getWallet(b).dust,before+7);assert.equal(replies.length,0);}finally{Form.prototype.show=oldShow;}
  }finally{world.getAllPlayers=online;}
  console.log('Commerce: three-currency conservation, input/funds/cap/offline rejection, reentrancy guard, recipient-write rollback and real transfer modal passed');
 }
 {
  const index=shop.XP_PRODUCTS.findIndex(p=>p.walletReward?.dust===200);assert.ok(index>=0);assert.equal(shop.XP_PRODUCTS[index].price,40);
  function customer(level){const f=player();let xp=level*100+17;f.p.level=level;f.p.getTotalXp=()=>xp;f.p.addLevels=n=>{f.p.level+=n;xp+=n*100;};f.p.addExperience=n=>{xp+=n;f.p.level=Math.floor(xp/100);};return f;}
  const {p,inv}=customer(40);for(let i=0;i<inv.size;i++)inv.setItem(i,new ItemStack('minecraft:stone',64));wallet.setWallet(p,{gold:3,stone:4,dust:5});const items=inventoryState(inv);assert.equal(shop.purchaseXpProduct(p,index).ok,true);assert.equal(p.level,0);assert.equal(p.getTotalXp(),17);assert.deepEqual(plain(wallet.getWallet(p)),{gold:3,stone:4,dust:205});assert.deepEqual(inventoryState(inv),items);
  const poor=customer(39);assert.equal(shop.purchaseXpProduct(poor.p,index).ok,false);assert.equal(poor.p.level,39);assert.equal(wallet.getWallet(poor.p).dust,0);
  const rich=customer(50);wallet.setWallet(rich.p,{gold:3,stone:4,dust:wallet.BALANCE_MAX-199});assert.equal(shop.purchaseXpProduct(rich.p,index).ok,false);assert.equal(rich.p.level,50);
  const broken=customer(45);funds(broken.p);const setter=broken.p.setDynamicProperty,before=plain(wallet.getWallet(broken.p)),xp=broken.p.getTotalXp();let fail=true;
  broken.p.setDynamicProperty=(key,v)=>{setter(key,v);if(key===wallet.WALLET_KEY&&fail){fail=false;throw Error('dust storage failed');}};assert.equal(shop.purchaseXpProduct(broken.p,index).ok,false);assert.equal(broken.p.getTotalXp(),xp);assert.equal(broken.p.level,45);assert.deepEqual(plain(wallet.getWallet(broken.p)),before);broken.p.setDynamicProperty=setter;
  const native=customer(50),add=native.p.addLevels;native.p.addLevels=n=>{add(n);throw Error('native debit failed after mutation');};assert.equal(shop.purchaseXpProduct(native.p,index).ok,false);assert.equal(native.p.getTotalXp(),5017);assert.equal(native.p.level,50);assert.equal(wallet.getWallet(native.p).dust,0);
  console.log('XP shop: exactly 40 native levels for 200 wallet dust, fractional XP preserved, full inventory allowed, cap/funds checks and partial-write/debit refunds passed');
 }
 {
  const {p,inv}=player();funds(p);seed(p,[['power',1,0],['power',2,0],['power',9,0],['power',10,0]]);inv.setItem(0,new ItemStack(up.CATALYST_ID,4));inv.setItem(1,new ItemStack(up.CATALYST_ID,6));
  let q=batch.runeBatchQuote(p,'power',0,3);assert.equal(q.catalysts,6);assert.deepEqual(plain(q.entries.map(e=>e.catalystCount)),[0,3,3]);let r=batch.executeRuneBatch(p,'power',0,q.fingerprint,{catalystCount:3,random:()=>0});assert.equal(r.ok,true);assert.equal(r.catalysts,6);assert.equal(inv.getItem(0),undefined);assert.equal(inv.getItem(1).amount,4);assert.deepEqual(plain(runes.readRuneBag(p).runes.map(r=>r.level)),[2,3,10,10]);
  const state=JSON.stringify([runes.readRuneBag(p),wallet.getWallet(p),inventoryState(inv)]);q=batch.runeBatchQuote(p,'power',0,3);assert.equal(batch.executeRuneBatch(p,'power',0,q.fingerprint,{catalystCount:3,random:()=>0}).ok,false);assert.equal(JSON.stringify([runes.readRuneBag(p),wallet.getWallet(p),inventoryState(inv)]),state);
  inv.setItem(1,new ItemStack(up.CATALYST_ID,20));q=batch.runeBatchQuote(p,'power',0,3);const before=JSON.stringify([runes.readRuneBag(p),wallet.getWallet(p),inventoryState(inv)]);let draw=0;r=batch.executeRuneBatch(p,'power',0,q.fingerprint,{catalystCount:3,random:()=>{if(++draw===2)throw Error('second attempt failed');return 0;}});assert.equal(r.ok,false);assert.equal(JSON.stringify([runes.readRuneBag(p),wallet.getWallet(p),inventoryState(inv)]),before);
  assert.equal(batch.runeBatchQuote(p,'power',0,6),undefined);assert.equal(batch.executeRuneBatch(p,'power',0,q.fingerprint,{catalystCount:2}).ok,false);
  console.log('Batch catalysts: per-rune +2 gate, multi-stack consumption, shortage preflight, changed-choice rejection and entire-batch rune/wallet/catalyst rollback passed');
 }
 {
  assert.deepEqual(plain(auto.parseRuneAuto('근력 룬','전설','10','5')),{id:'power',grade:5,level:10,catalysts:5});
  for(const args of [['unknown',1,5,0],['힘','',5,0],['힘',7,5,0],['힘',0,11,0],['힘',0,5,-1],['힘',0,5,1.5]])assert.throws(()=>auto.parseRuneAuto(...args));
  const {p,inv}=player();funds(p);inv.setItem(0,new ItemStack('rpg:rune_power',4));inv.setItem(1,new ItemStack(up.CATALYST_ID,64));inv.setItem(2,new ItemStack(up.CATALYST_ID,64));
  const bag=seed(p,[['power',5,0],['ward',10,6],['power',10,3]]);bag.equipped[0]=bag.runes[0].uid;runes.writeRuneBag(p,bag);const protectedRune=plain(bag.runes[0]),other=plain(bag.runes[1]),higher=plain(bag.runes[2]);
  const spec=auto.parseRuneAuto('힘','에픽',3,2),actions=[];let done;for(let i=0;i<150;i++){const r=auto.runeAutoStep(p,spec,{random:()=>0});assert.equal(r.ok,true,r.reason);if(r.done){done=r;break;}actions.push(r.action);}
  assert.ok(done);assert.equal(done.rune.grade,2);assert.equal(done.rune.level,3);assert.equal(actions.filter(x=>x==='deposit').length,4);assert.equal(actions.filter(x=>x==='fuse').length,3);assert.equal(actions.filter(x=>x==='enhance').length,33);assert.equal(inv.getItem(0),undefined);
  const usedCatalysts=2*(4*3+2*3+1);let remaining=0;for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId===up.CATALYST_ID)remaining+=inv.getItem(i).amount;assert.equal(remaining,128-usedCatalysts);
  const final=runes.readRuneBag(p);for(const preserved of [protectedRune,other,higher])assert.deepEqual(plain(final.runes.find(r=>r.uid===preserved.uid)),preserved);assert.equal(final.equipped[0],protectedRune.uid);
  let costs={gold:0,dust:0};for(const [count,target]of [[4,5],[2,5],[1,3]])for(let level=0;level<target;level++){const c=up.upgradeCost('rune',level);costs.gold+=c.gold*count;costs.dust+=c.dust*count;}assert.equal(wallet.getWallet(p).gold,10000000-costs.gold);assert.equal(wallet.getWallet(p).dust,10000-costs.dust);assert.equal(wallet.getWallet(p).stone,77);
  console.log('Rune automation: inventory stack → four common +5 → two rare +5 → epic +3, actual costs/catalysts, equipped/other-kind/higher-grade preservation passed');
 }
 {
  const {p}=player();funds(p);seed(p,[['arcane',5,0],['arcane',5,0]]);const spec=auto.parseRuneAuto('비전',1,0,0),draws=[.99,0];let r=auto.runeAutoStep(p,spec,{random:()=>draws.shift()});assert.equal(r.action,'fuse');assert.equal(r.success,false);assert.equal(r.downgraded,true);assert.deepEqual(plain(runes.readRuneBag(p).runes.map(r=>r.level)),[4,5]);
  r=auto.runeAutoStep(p,spec,{random:()=>0});assert.equal(r.action,'enhance');assert.equal(r.level,5);r=auto.runeAutoStep(p,spec,{random:()=>0});assert.equal(r.success,true);assert.equal(auto.runeAutoStep(p,spec).done,true);
  const doomed=player();funds(doomed.p);seed(doomed.p,[['power',9,0]]);doomed.inv.setItem(0,new ItemStack('rpg:rune_power'));const target=auto.parseRuneAuto('힘',0,10,0);r=auto.runeAutoStep(doomed.p,target,{random:()=>.999});assert.equal(r.outcome,'destroy');assert.equal(runes.readRuneBag(doomed.p).runes.length,0);r=auto.runeAutoStep(doomed.p,target);assert.equal(r.action,'deposit');assert.equal(runes.readRuneBag(doomed.p).runes[0].level,0);
  const poor=player();seed(poor.p,[['power',0,0]]);let old=JSON.stringify([runes.readRuneBag(poor.p),wallet.getWallet(poor.p)]);r=auto.runeAutoStep(poor.p,auto.parseRuneAuto('힘',0,5,0));assert.equal(r.ok,false);assert.match(r.reason,/부족/);assert.equal(JSON.stringify([runes.readRuneBag(poor.p),wallet.getWallet(poor.p)]),old);
  const cat=player();funds(cat.p);seed(cat.p,[['power',0,0]]);const catSpec=auto.parseRuneAuto('힘',0,5,3);assert.equal(auto.runeAutoStep(cat.p,catSpec,{random:()=>0}).ok,true);assert.equal(auto.runeAutoStep(cat.p,catSpec,{random:()=>0}).ok,true);old=JSON.stringify([runes.readRuneBag(cat.p),wallet.getWallet(cat.p)]);r=auto.runeAutoStep(cat.p,catSpec,{random:()=>0});assert.equal(r.ok,false);assert.match(r.reason,/촉매/);assert.equal(JSON.stringify([runes.readRuneBag(cat.p),wallet.getWallet(cat.p)]),old);assert.equal(runes.readRuneBag(cat.p).runes[0].level,2);
  const locked=player();funds(locked.p);const lb=seed(locked.p,[['power',5,0],['power',5,0]]);lb.equipped[0]=lb.runes[0].uid;runes.writeRuneBag(locked.p,lb);assert.equal(auto.runeAutoStep(locked.p,{...spec,id:'power'}).ok,false);
  const full=player();funds(full.p);seed(full.p,Array.from({length:30},()=>['ward',0,0]));full.inv.setItem(0,new ItemStack('rpg:rune_power',2));assert.equal(auto.runeAutoStep(full.p,target).ok,false);assert.equal(full.inv.getItem(0).amount,2);assert.equal(runes.readRuneBag(full.p).runes.length,30);
  for(const fundsOnly of [{gold:100000,stone:0,dust:0},{gold:0,stone:0,dust:1000}]){const f=player();seed(f.p,[['power',0,0]]);wallet.setWallet(f.p,fundsOnly);const snapshot=JSON.stringify([runes.readRuneBag(f.p),wallet.getWallet(f.p)]);assert.equal(auto.runeAutoStep(f.p,target).ok,false);assert.equal(JSON.stringify([runes.readRuneBag(f.p),wallet.getWallet(f.p)]),snapshot);}
  const existing=player();funds(existing.p);seed(existing.p,[['power',0,1]]);const token=new ItemStack('rpg:rune_power');token.setDynamicProperty('rpg:rarity',1);token.setDynamicProperty('rpg:rune_upgrade',8);existing.inv.setItem(0,token);const ew=plain(wallet.getWallet(existing.p));r=auto.runeAutoStep(existing.p,auto.parseRuneAuto('힘',1,8,0));assert.equal(r.action,'deposit');r=auto.runeAutoStep(existing.p,auto.parseRuneAuto('힘',1,8,0));assert.equal(r.done,true);assert.equal(r.rune.grade,1);assert.equal(r.rune.level,8);assert.deepEqual(plain(wallet.getWallet(existing.p)),ew);
  console.log('Rune automation: failed fusion re-enhances +4, destruction uses real replacement, dust/gold/catalyst shortages preserve partial progress, protected materials and full bag stop safely passed');
 }
 {
  const {p,health,messages}=player();p.id='auto-lifecycle';funds(p);seed(p,[['power',0,0]]);const spec=auto.parseRuneAuto('힘',0,5,0);
  assert.equal(auto.startRuneAuto(p,spec).ok,true);assert.equal(auto.startRuneAuto(p,spec).ok,false);assert.equal(auto.stopRuneAuto(p),true);const before=p.getDynamicProperty(runes.RUNE_BAG_KEY);auto.tickRuneAuto();assert.equal(p.getDynamicProperty(runes.RUNE_BAG_KEY),before);
  auto.startRuneAuto(p,spec);health.currentValue=0;auto.tickRuneAuto();assert.equal(auto.stopRuneAuto(p),false);assert.match(messages.at(-1),/생존/);health.currentValue=50;
  auto.registerRuneAuto();auto.startRuneAuto(p,spec);signal('playerLeave').fire({playerId:p.id});assert.equal(auto.stopRuneAuto(p),false);auto.startRuneAuto(p,spec);p.isValid=false;auto.tickRuneAuto();assert.equal(auto.stopRuneAuto(p),false);p.isValid=true;
  const oldShow=Form.prototype.show;const replies=[{formValues:['힘','일반','0','0']},{selection:1}];Form.prototype.show=()=>Promise.resolve(replies.shift()??{canceled:true});try{await auto.openRuneAuto(p);auto.tickRuneAuto();assert.match(messages.at(-1),/목표 완료/);assert.equal(auto.stopRuneAuto(p),false);}finally{Form.prototype.show=oldShow;}
  for(const name of ['pay','runeauto','runeautostop'])assert.match(mod('core/rpgActions.js').runRpgAction.toString(),new RegExp("case '"+name+"'"));
  console.log('Rune automation: duplicate/cancel/death/disconnect/leave cleanup and actual input-confirm-completion UI passed');
 }
}
