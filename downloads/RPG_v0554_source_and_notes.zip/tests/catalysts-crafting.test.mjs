import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,EquipmentSlot,replies,forms} from './minecraftMock.mjs';
import {enhancementRates,CATALYST_ID,ARMOR_LEVEL_KEY} from '../RPG_BP_v0554/scripts/data/upgrades.js';
import {enhanceEquipped,openUpgradeMenu} from '../RPG_BP_v0554/scripts/core/upgrades.js';
import {getWallet,setWallet} from '../RPG_BP_v0554/scripts/core/wallet.js';
import {openCraftingGuide} from '../RPG_BP_v0554/scripts/core/crafting.js';
import {CRAFTING_RECIPES} from '../RPG_BP_v0554/scripts/data/crafting.js';

function ready() {
  const p=player('five');const item=new ItemStack('rpg:adventurer_chestplate');item.setDynamicProperty(ARMOR_LEVEL_KEY,9);
  p.equipment.set(EquipmentSlot.Chest,item);setWallet(p,{gold:100000,stone:1000,dust:1000});return p;
}
test('0–5 catalysts have per-item +5 success/-3 destruction, sum to 100 at all eligible levels',()=>{
  for(const [kind,max]of [['armor',10],['rune',5]])for(let level=0;level<max;level++)for(let count=0;count<=5;count++) {
    const base=enhancementRates(kind,level),rates=enhancementRates(kind,level,count);
    if(count>0&&((kind==='armor'&&level<5)||(kind==='rune'&&level<2))){assert.equal(rates,undefined);continue;}
    assert.equal(rates.success,base.success+5*count);assert.equal(rates.destroy,Math.max(0,base.destroy-3*count));
    assert.equal(rates.downgrade,base.downgrade);assert.ok(Object.values(rates).every(n=>n>=0));
    assert.equal(Object.values(rates).reduce((a,b)=>a+b),100);
  }
  assert.deepEqual(enhancementRates('armor',9,5),{success:40,fail:25,downgrade:32,destroy:3});
});
test('6+, negative, fractional and non-number counts are rejected before spending or rolling',()=>{
  for(const count of [6,100,-1,1.5,NaN,Infinity,'5',true]) {
    const p=ready();p.slots[0]=new ItemStack(CATALYST_ID,64);const before=getWallet(p);let rolled=false;
    assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest,undefined,{catalystCount:count,random:()=>{rolled=true;return 0;}}).ok,false);
    assert.equal(rolled,false);assert.deepEqual(getWallet(p),before);assert.equal(p.slots[0].amount,64);
  }
});
test('5 catalysts are consumed across stacks; insufficient combined stacks never charge',()=>{
  const p=ready();p.slots[0]=new ItemStack(CATALYST_ID,2);p.slots[7]=new ItemStack(CATALYST_ID,4);
  const result=enhanceEquipped(p,'armor',EquipmentSlot.Chest,undefined,{catalystCount:5,random:()=>.5});
  assert.equal(result.ok,true);assert.equal(result.outcome,'fail');assert.equal(result.catalystCount,5);
  assert.equal(p.slots[0],undefined);assert.equal(p.slots[7].amount,1);
  const before=getWallet(p);assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest,undefined,{catalystCount:5}).ok,false);
  assert.deepEqual(getWallet(p),before);assert.equal(p.slots[7].amount,1);
});
test('mid-consumption inventory error restores every stack, wallet and armor',()=>{
  const p=ready();p.slots[0]=new ItemStack(CATALYST_ID,2);p.slots[1]=new ItemStack(CATALYST_ID,3);
  const read=p.getComponent.bind(p),container=read('minecraft:inventory').container,before=getWallet(p);let first=true;
  p.getComponent=name=>name==='minecraft:inventory'?{container:{...container,setItem:(i,item)=>{if(i===1&&first){first=false;throw Error('inventory failure');}container.setItem(i,item);}}}:read(name);
  const result=enhanceEquipped(p,'armor',EquipmentSlot.Chest,undefined,{catalystCount:5,random:()=>.99});
  assert.equal(result.ok,false);assert.equal(p.slots[0].amount,2);assert.equal(p.slots[1].amount,3);
  assert.deepEqual(getWallet(p),before);assert.equal(p.equipment.get(EquipmentSlot.Chest).getDynamicProperty(ARMOR_LEVEL_KEY),9);
});
test('UI offers 0–5, previews exact probabilities and consumes selected 5',async()=>{
  const p=ready();p.slots[0]=new ItemStack(CATALYST_ID,5);const original=Math.random;Math.random=()=>.5;
  try {replies.push({canceled:false,selection:0},{canceled:false,selection:5},{canceled:false,selection:1},{canceled:true});await openUpgradeMenu(p);}
  finally{Math.random=original;}
  assert.equal(p.slots[0],undefined);
  const choices=forms.find(f=>f.heading==='강화 촉매 수량');assert.equal(choices.buttons.length,7);
  assert.match(choices.buttons[5],/성공 40% \/ 파괴 3%/);
  const confirm=forms.find(f=>f.heading==='위험 강화 확인');assert.match(confirm.text,/강화 촉매 5개 사용/);
});
test('crafting catalog covers 12 armor pieces, 5 runes and catalyst with real material counts',()=>{
  assert.equal(CRAFTING_RECIPES.length,28);
  assert.equal(CRAFTING_RECIPES.filter(r=>r.category==='armor').length,16);
  assert.equal(CRAFTING_RECIPES.filter(r=>r.category==='rune').length,6);
  const helmet=CRAFTING_RECIPES.find(r=>r.id==='rpg:adventurer_helmet');
  assert.match(helmet.text,/철 주괴 ×4/);assert.match(helmet.text,/구리 주괴 ×1/);assert.match(helmet.text,/철 구 철/);
  const power=CRAFTING_RECIPES.find(r=>r.id==='rpg:rune_power');assert.match(power.text,/레드스톤 ×2/);
});
test('in-game crafting UI opens armor grid and rune acquisition without granting items',async()=>{
  const p=player('catalog');replies.push({canceled:false,selection:0},{canceled:false,selection:CRAFTING_RECIPES.filter(r=>r.category==='armor').findIndex(r=>r.id==='rpg:adventurer_boots')},{canceled:true},{canceled:true},{canceled:true});
  await openCraftingGuide(p);assert.ok(forms.some(f=>f.text?.includes('배치도')));assert.ok(p.slots.every(i=>i===undefined));
  replies.push({canceled:false,selection:1},{canceled:true},{canceled:true});await openCraftingGuide(p);
  assert.ok(forms.some(f=>f.text?.includes('일반 몬스터: 1%')&&f.text?.includes('3%')));
});
