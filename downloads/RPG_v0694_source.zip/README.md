# RPG v0.6.94 · 카멜레온 100레벨 모방 수련

카멜레온 100레벨부터 `/rpg:skillbook`의 **모방 수련**에서 현재 미션을 확인할 수 있습니다. 10개 중 하나를 무작위로 받고, 완료할 때마다 랜덤 스킬북 1권을 지급하고 다른 미션을 즉시 배정합니다. 일일 제한 없이 이어지며, 진행도는 재접속 후에도 저장됩니다. 가방이 차면 기존 스킬북 대기함에 보관합니다.

| 미션 | 완료 조건 |
| --- | --- |
| 고독한 정복자 | 9단계 던전을 혼자 시작해 클리어 |
| 위더 사냥 | 위더 1마리 처치 |
| 엔드를 다시 위대하게 | 엔드 귀환 포탈에 마지막 엔드 수정을 놓아 드래곤 부활시키기 |
| 다이아 한 세트 | 다이아몬드 64개 채굴. 행운 추가 수량도 집계 |
| 마을의 수호자 | 습격 몹을 처치하고 근처에서 습격 승리 효과 받기 |
| 심해 정복 | 엘더 가디언 3마리 처치 |
| 사막의 포식자 | 엘리트 데스웜 5마리 처치 |
| 네더 발굴 | 고대 잔해 16개 채굴 |
| 엔드 도시 탐험 | 엔드 도시 근처에서 셜커 12마리 처치 |
| 히드라 추적 | 오버월드 X·Z 각각 -500~499의 지정 좌표로 가서 레벨 200 히드라 처치 |

셜커 미션은 엔드 외곽의 퍼퍼 블록과 엔드 석재 벽돌을 기준으로 도시 근처를 판정합니다. 드래곤 부활은 수정 배치 후 드래곤이 다시 등장한 시점에 보상합니다. 이 버전에서 플레이어가 설치한 광석은 채굴 집계에서 제외됩니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.94로 활성화하세요. 모의 테스트에서 10개 미션, 보상 저장, 임무 교체와 레벨 200 적용을 검증했습니다. 실제 Bedrock에서의 이벤트 타이밍과 연출은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0694
```
