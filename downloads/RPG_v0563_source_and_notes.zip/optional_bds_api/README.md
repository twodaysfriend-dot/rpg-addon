# RPG v0.5.63 서버용 API 정보 안내

일반 설치 파일은 `/rpg:ask`로 내장 도감을 검색합니다. API 키와 인터넷 없이 작동합니다. 이 폴더는 **Bedrock Dedicated Server(BDS)**에서만 사용할 수 있는 선택 연결입니다. 일반 월드·친구 초대·Realm에는 적용하지 마세요.

Minecraft 공식 문서: [server-net 지원 환경](https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server-net/minecraft-server-net?view=minecraft-bedrock-experimental). `@minecraft/server-net`은 전용 서버에서만 지원하며 클라이언트·Realm에서는 동작하지 않습니다. 시험 단계 API이므로 설치한 서버가 지원하는 모듈 버전과 설정을 확인해야 합니다.

## 답변 방식

질문 → 이 애드온의 도감에서 후보 자료 검색 → 외부 API가 관련 자료 ID 선택 → 게임이 실제 자료만 표시합니다. 외부 모델이 작성한 임의의 문장을 플레이어에게 전달하지 않습니다. 자료에 없는 정보·다른 게임·일상 질문은 답하지 않습니다. 서식이나 지시문을 질문에 넣어도 명령어나 코드를 실행하지 않습니다.

API 서버로 보내는 내용은 사용자가 명시적으로 입력한 질문(200자 이내)과 관련 도감 자료 최대 6개뿐입니다. 플레이어 이름·UUID·채팅 기록·인벤토리·저장 상태는 보내지 않습니다. 외부 API 장애·시간 초과·잘못된 ID 선택은 내장 도감으로 대체합니다. 모델이 관련 자료 없음으로 응답하면 범위 밖 안내를 표시합니다.

## 준비

- 지원되는 BDS와 해당 서버의 `@minecraft/server-net`, `@minecraft/server-admin` 모듈 버전.
- Node.js 20 이상과 Python 3.9 이상. 추가 npm 패키지는 필요 없습니다.
- 서버에서만 보관할 OpenAI API 키와 24자 이상의 별도 RPG 연결 토큰. 실제 키/토큰을 애드온 파일이나 Git에 넣지 마세요.
- BDS가 API 브리지와 같은 호스트에서 실행되는 기본 구성을 가정합니다. 기본 연결은 `127.0.0.1:8787`입니다. 별도 호스트·서버가 HTTP를 제한하는 버전에서는 신뢰할 수 있는 HTTPS 주소로 어댑터의 ENDPOINT를 조정하고 서버의 허용 주소 설정을 적용해야 합니다.

## 설치

1. 서버 연결 자료 ZIP을 풀거나 전체 소스 ZIP을 풉니다. 전체 소스를 쓴다면 먼저 `python build.py`로 기본 배포 파일을 생성하세요. 서버 연결 자료 ZIP에는 기본 파일이 이미 들어 있습니다.
2. 실제 BDS가 지원하는 버전을 지정해 전용 변형을 만듭니다. 아래 대문자 값은 설명용이며 실제 버전으로 교체해야 합니다.

```sh
python tools/build_bds_assistant.py --net-version NET_MODULE_VERSION --admin-version ADMIN_MODULE_VERSION
```

생성 파일은 `dist/RPG_v0563_BDS_API.mcaddon`입니다. 이 변형은 일반판과 UUID가 같으므로 **한 가지만** 설치하세요. 원본 일반판은 변경하지 않습니다. 잘못된 beta 모듈 버전을 지정하면 BDS가 팩을 로드하지 못하므로, 연결을 쓰지 않는 플레이 환경에는 일반판을 사용하세요.

3. 서버의 스크립트 모듈 권한 설정에서 `@minecraft/server`, `@minecraft/server-ui`, `@minecraft/server-net`, `@minecraft/server-admin`을 허용합니다. 이 애드온의 스크립트 모듈 UUID는 `c41fa3d6-d82c-4a54-9783-68f92fe633a1`입니다. BDS의 해당 모듈용 `permissions.json`/`secrets.json` 위치와 beta 스크립트 설정은 설치한 서버 버전 문서를 따르세요.
4. BDS 서버 비밀 설정에 `rpg_assistant_token`을 저장합니다. 같은 토큰을 브리지의 `RPG_ASSISTANT_TOKEN` 환경 변수에 설정합니다. API 키는 브리지의 `OPENAI_API_KEY` 환경 변수에만 설정합니다. `OPENAI_MODEL`은 선택이며 기본값은 `gpt-4.1-mini`입니다. 셸 기록에 키를 직접 남기는 대신 서버 서비스의 비밀 환경 설정을 사용하세요.
5. 비밀 환경 설정이 적용된 서버 프로세스에서 실행합니다.

```sh
node optional_bds_api/server.mjs
```

브리지는 기본적으로 같은 호스트의 127.0.0.1:8787에만 연결을 받습니다. OpenAI Responses API로 HTTPS 요청을 보냅니다. `RPG_ASSISTANT_PORT`를 바꾸면 어댑터 ENDPOINT도 같은 포트로 바꾸세요. API 사용 비용은 운영자의 API 계정에 청구됩니다.

6. BDS를 재시작하고 `/rpg:ask "월룡륜미 범위"`, `/rpg:ask "검사 전직"`로 확인합니다. API 연결이 실패해도 질문은 내장 도감으로 처리됩니다. 네트워크 제한·잘못된 비밀값·모듈 권한은 서버에서 확인하세요.

## 검증 범위

자료 선택 API 요청 형식, 서버 토큰 검증, 범위 밖 질문, 잘못된 응답, 연결 오류, 동시 요청 제한, 일반판의 외부 HTTP 의존성 부재를 모의 API로 검증했습니다. 실제 OpenAI API 호출과 실제 BDS beta 모듈의 실행은 키·서버가 제공되지 않아 검증하지 못했습니다. 일반판의 게임 내 UI·전투 외형도 실제 Bedrock 클라이언트 검증은 남아 있습니다.


v0.5.63 정책: 효과별 기술 목록은 API 없이 안내합니다. 밸런스 평가·티어·사기 여부 및 히든 전직 방법/조건은 연결 여부와 관계없이 안내하지 않습니다. 전직은 검사·마법사·궁수·무투가·성직자만 공개합니다. 질문과 API 후보 자료에 모두 적용하며 기존 운영자는 브리지와 BDS 팩을 함께 갱신하세요.


v0.5.63: `/rpg:gptnpc`로 생성한 GPT 안내 NPC에서도 같은 API/오프라인 응답을 사용합니다. 직업 기본 피해 계열과 기술별 근력·마력·혼합·고정·비공격 보정 설명을 도감 후보에 포함합니다.
