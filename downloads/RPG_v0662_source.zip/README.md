# RPG v0.6.62 · 세 줄마다 첫 칸에서 시작하는 하트

하트 한 칸은 2 HP이며 한 줄에 10칸, 한 색상에 최대 3줄입니다. 세 줄을 넘으면 이전 색이 사라지고 왼쪽 아래 첫 칸부터 다음 색으로 표시됩니다.

- 60 HP는 빨간 하트 30개, 61 HP는 주황 반 칸, 62 HP는 주황 한 칸입니다.
- 120 HP는 주황 하트 30개, 121 HP는 노란 반 칸, 122 HP는 노란 한 칸입니다.
- 148 HP는 노란 하트 14개입니다. 이후 초록, 하늘, 파랑, 분홍도 같은 방식으로 표시됩니다.

Bedrock 1.21.100 이상에서 세 팩을 모두 v0.6.62로 활성화하세요. 모의 Script API로 체력 구간별 하트 개수와 색상, 피해·회복 경계를 검증했습니다. 모바일 기기에서의 렌더링은 별도 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0662
```
