import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0626';
const base=root+'/RPG_BP_v0626/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}


const close=(a,b,eps=1e-7)=>assert.ok(Math.abs(a-b)<eps,`${a} != ${b}`);
const dungeon=await load('scripts/data/dungeons.js');
const levels=await load('scripts/data/monsterLevels.js',{DUNGEON_TIERS:dungeon.DUNGEON_TIERS});
const leveled=await load('scripts/data/leveledMonsters.js');
const grades=await load('scripts/data/grades.js');
const upgrade=await load('scripts/data/upgrades.js',{gradeRank:grades.gradeRank});
const runes=(await load('scripts/data/equipment.js',{COMMON_WEAPONS:[]})).RUNES;
for(const key of ['power','arcane'])for(let lv=0;lv<=10;lv++)for(let grade=0;grade<=6;grade++){
 const extra=grade<4?0:((lv>=8?.03:0)+(lv>=10?.04:0))*upgrade.EXTRA_SCALE[grade];
 const field=key==='power'?'physical':'magic';
 close(upgrade.upgradedRune(runes[key],lv,grade)[field],1+((.17+lv*.034)*1.5**grade+extra)*.4);
}
close(upgrade.upgradedRune(runes.power,0,1).physical,1.102);
close(upgrade.upgradedRune(runes.power,10,1).physical,1.306);
console.log('Runes: base 100% never rarity-scaled; every damage-rune level/grade and extra perk uses 40% of added damage');
let runeLevel=0;
const stats=await load('scripts/core/stats.js',{world:{},system:{},EquipmentSlot:{Mainhand:'Mainhand'},CONFIG:{skillDamage:{strengthPerLevel:.05}},classWeapon:()=>true,upgradeLevel:()=>6,getEquipmentBonuses:()=>({physical:upgrade.upgradedRune(runes.power,runeLevel,1).physical,magic:1})});
const player=str=>({typeId:'minecraft:player',getDynamicProperty:k=>k==='rpg:stat_values'?JSON.stringify({str,mag:25,vit:5,int:5}):undefined,getEffect:()=>undefined,getComponent:()=>({getEquipment:()=>({typeId:'rpg:chameleon_flame_blade'})})});
const defs=(await load('scripts/data/skills.js')).SKILLS;
const weak=stats.skillDamageFor(player(25),defs.sword_annihilation.damage,'physical');close(weak,98.211932672);assert.ok(weak>98&&weak<99);
runeLevel=10;
const reference=stats.skillDamageFor(player(40),defs.sword_annihilation.damage,'physical');
console.log(`Annihilation: STR25/rare+0/weapon+6=${weak.toFixed(3)}; STR40/rare+10/weapon+6=${reference.toFixed(3)} before target defenses`);
let checked=0;
for(const id of leveled.LEVELED_MONSTERS){
 const entity=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0626/entities/'+id.split(':')[1]+'.json','utf8'))['minecraft:entity'];
 const hp=entity.components['minecraft:health'].max,atk=entity.components['minecraft:attack'].damage;
 for(const level of levels.MONSTER_LEVELS){
  const group=entity.component_groups['rpg:level_'+level];
  close(group['minecraft:health'].max,Number((hp*(1+(level-1)*.035)*.9).toFixed(2)),.011);
  close(group['minecraft:attack'].damage,Number((atk*(1+(level-1)*.018)*.9).toFixed(2)),.011);
  close(group['minecraft:damage_sensor'].triggers[0].damage_multiplier,1/(1+(level-1)*.0036),.00000051);
  checked++;
 }
 for(const tier of dungeon.DUNGEON_TIERS)for(const kind of ['normal','elite','boss'])for(let index=0;index<(kind==='normal'?3:1);index++){
  const ctx={tier:tier.tier,kind,index},level=levels.dungeonMonsterLevel(tier.tier,kind,index),m=levels.monsterCombatMultipliers(level,ctx),key=`rpg:dungeon_scaled_${tier.tier}_${kind}_${index}`,group=entity.component_groups[key];
  close(group['minecraft:health'].max,Number((hp*m.health).toFixed(2)));
  close(group['minecraft:attack'].damage,Number((atk*m.attack).toFixed(2)));
  close(group['minecraft:damage_sensor'].triggers[0].damage_multiplier,m.defense,.00000051);
  const mob={getDynamicProperty:k=>k===levels.MONSTER_LEVEL_KEY?level:k===levels.MONSTER_CONTEXT_KEY?JSON.stringify(ctx):undefined};
  close(levels.monsterDefenseMultiplier(mob),m.defense);close(levels.monsterAttackMultiplier(mob),m.attack);
  assert.ok(entity.events[key].remove.component_groups.includes('rpg:level_1'));
  checked++;
 }
}
assert.equal(checked,1430);
console.log('1430 generated wild/dungeon groups agree with runtime damage/defense functions across all 22 entities; scripted boss attacks use dungeon context');
const mobApi=await load('scripts/core/monsterLevels.js',{MONSTER_CONTEXT_KEY:levels.MONSTER_CONTEXT_KEY,MONSTER_LEVEL_KEY:levels.MONSTER_LEVEL_KEY,MONSTER_LEVELS:levels.MONSTER_LEVELS,LEVELED_MONSTERS:leveled.LEVELED_MONSTERS,MONSTER_NAMES:leveled.MONSTER_NAMES});
{
 const props=new Map([[levels.MONSTER_LEVEL_KEY,20]]);let calls=0;
 const hp={currentValue:25,effectiveMax:50,setCurrentValue(n){this.currentValue=n;}};
 const mob={typeId:'rpg:green_goblin',isValid:true,hasTag:()=>false,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),getComponent:k=>k==='minecraft:health'?hp:undefined,triggerEvent:()=>{calls++;hp.effectiveMax=45;hp.currentValue=45;}};
 assert.equal(mobApi.refreshWildMonsterBalance(mob),true);close(hp.currentValue,22.5);assert.equal(mobApi.refreshWildMonsterBalance(mob),false);assert.equal(calls,1);
 props.delete('rpg:monster_balance_revision');
 mob.hasTag=()=>true;assert.equal(mobApi.refreshWildMonsterBalance(mob),false);
}
{
 const props=new Map(),events=[];const mob={typeId:'rpg:green_goblin',nameTag:'',getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),triggerEvent:s=>events.push(s)};
 assert.equal(mobApi.applyMonsterLevel(mob,20,{tier:2,kind:'normal',index:1}),true);assert.equal(events[0],'rpg:dungeon_scaled_2_normal_1');assert.equal(JSON.parse(props.get(levels.MONSTER_CONTEXT_KEY)).tier,2);
 assert.equal(mobApi.applyMonsterLevel(mob,20),false);
}
console.log('Wild migration keeps current health percentage, runs once and excludes dungeon mobs; dungeon spawn records persistent context and refuses double scaling');
// Offense-only reference, not a claim to simulate movement, mana or survival.
// One native melee hit/second + Annihilation every 5s, 70% attack uptime.
const boss=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0626/entities/rock_golem_boss.json','utf8'))['minecraft:entity'].component_groups['rpg:dungeon_scaled_2_boss_0'];
const defense=boss['minecraft:damage_sensor'].triggers[0].damage_multiplier,hp=boss['minecraft:health'].max,limit=dungeon.dungeonTimeLimit('boss',1)/1000;
const timeFor=(skill,melee)=>hp/((skill/5+melee)*.7*defense);
const referenceTime=timeFor(reference,19*1.306),weakTime=timeFor(weak,19);
assert.ok(referenceTime>limit*.9&&referenceTime<limit);assert.ok(weakTime>limit);
const rows=dungeon.DUNGEON_TIERS.map(t=>({tier:t.tier,hp:t.hpMultiplier,attack:t.attackMultiplier}));
for(let i=1;i<rows.length;i++){assert.ok(rows[i].hp>rows[i-1].hp);assert.ok(rows[i].attack>rows[i-1].attack);}
console.log(`Tier2 boss HP=${hp}, damage=${boss['minecraft:attack'].damage}; solo boss limit ${limit}s; reference offense model ${referenceTime.toFixed(1)}s vs low gear ${weakTime.toFixed(1)}s; all higher tier HP/attack multipliers increase`);
