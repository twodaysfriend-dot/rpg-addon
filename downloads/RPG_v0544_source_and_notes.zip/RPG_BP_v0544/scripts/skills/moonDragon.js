import {system} from '@minecraft/server';
import {getJobId} from '../core/playerData.js';
import {hasBorrowedSkill} from '../core/skillAccess.js';
import {getTargets,flatDir,isSolidAt,hurt,knockback,particle,sound,healthAlive} from '../core/util.js';
export function moonLineClear(dim,from,to){
 const dx=to.x-from.x,dy=to.y-from.y,dz=to.z-from.z,distance=Math.hypot(dx,dy,dz);
 for(let d=.4;d<distance;d+=.4)if(isSolidAt(dim,{x:from.x+dx*d/distance,y:from.y+dy*d/distance,z:from.z+dz*d/distance}))return false;
 return true;
}
export function castMoonDragon(p,job,def){
 if(!['sword_saint','fallen_sword_saint'].includes(getJobId(p))&&!hasBorrowedSkill(p,'sword_moon_dragon'))return false;
 const dim=p.dimension,origin={...p.location},direction=flatDir(p),yaw=Math.atan2(direction.z,direction.x),hit=new Set();let step=0;
 sound(dim,'mob.evocation_fangs.attack',origin,{volume:.9,pitch:.75});sound(dim,'random.swish',origin,{volume:1,pitch:.7});
 const timer=system.runInterval(()=>{
  try{
   if(!p.isValid||!healthAlive(p)||p.dimension.id!==dim.id||step>=def.duration){system.clearRun(timer);return;}
   const radius=def.radius*(step+1)/def.duration;
   // Two sweeping large blades, surrounded by twelve smaller rotating crescents.
   for(let i=0;i<2;i++){const angle=yaw+step*.55+i*Math.PI;particle(dim,'rpg:moon_dragon_large',{x:origin.x+Math.cos(angle)*radius,y:origin.y+1.2,z:origin.z+Math.sin(angle)*radius});}
   for(let i=0;i<12;i++){const angle=yaw+i*Math.PI/6+step*.12,r=radius*(.78+.08*(i%3));particle(dim,'rpg:moon_dragon_small',{x:origin.x+Math.cos(angle)*r,y:origin.y+.45+.7*(i%3),z:origin.z+Math.sin(angle)*r});}
   for(const target of getTargets(p,{x:origin.x,y:origin.y+1,z:origin.z},radius+1,.9)){
    const at=target.location,dx=at.x-origin.x,dz=at.z-origin.z;
    if(hit.has(target.id)||Math.hypot(dx,dz)>radius||Math.abs(at.y-origin.y)>def.height)continue;
    if(!moonLineClear(dim,{x:origin.x,y:origin.y+1,z:origin.z},{x:at.x,y:at.y+.9,z:at.z}))continue;
    if(hurt(target,p,def.damage,'physical')){hit.add(target.id);knockback(target,dx,dz,def.knockback,.2);}
   }
   if(++step>=def.duration)system.clearRun(timer);
  }catch{system.clearRun(timer);}
 },1);return true;
}
