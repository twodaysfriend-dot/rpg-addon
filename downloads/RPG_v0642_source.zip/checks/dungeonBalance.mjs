import fs from 'node:fs';
import assert from 'node:assert/strict';
import {DUNGEON_TIERS} from '../RPG_BP_v0638/scripts/data/dungeons.js';
import {DUNGEON_HEALTH_PRESSURE,MONSTER_LEVELS,dungeonMonsterLevel,monsterCombatMultipliers,monsterDefenseFor} from '../RPG_BP_v0638/scripts/data/monsterLevels.js';
import {LEVELED_MONSTERS} from '../RPG_BP_v0638/scripts/data/leveledMonsters.js';
const root=process.argv[2]??'.';
const close=(a,b,e=1e-6)=>assert.ok(Math.abs(a-b)<e,`${a} != ${b}`);
let cases=0;
for(const id of LEVELED_MONSTERS){
 const e=JSON.parse(fs.readFileSync(`${root}/RPG_BP_v0638/entities/${id.split(':')[1]}.json`))['minecraft:entity'];
 const base=e.components;
 for(const level of MONSTER_LEVELS){
  const g=e.component_groups['rpg:level_'+level];
  close(g['minecraft:health'].max,Number((base['minecraft:health'].max*((1+(level-1)*.035)*.9)).toFixed(2)));
  close(g['minecraft:damage_sensor'].triggers[0].damage_multiplier,1);
  assert.equal(monsterDefenseFor(level),1);
 }
 for(const t of DUNGEON_TIERS)for(const kind of ['normal','elite','boss'])for(let index=0;index<(kind==='normal'?3:1);index++){
  const level=dungeonMonsterLevel(t.tier,kind,index),ctx={tier:t.tier,kind,index};
  const oldReduction=1-1/((1+(level-1)*.004)*(t.tier>=2?1+(t.tier-2)*.04:1));
  const g=e.component_groups[`rpg:dungeon_scaled_${t.tier}_${kind}_${index}`];
  close(1-g['minecraft:damage_sensor'].triggers[0].damage_multiplier,oldReduction*.64);
  const kindHealth=t.tier>=2?(kind==='boss'?2:kind==='elite'?1.35:1):1;
  const expected=base['minecraft:health'].max*(1+(level-1)*.035)*t.hpMultiplier*kindHealth*DUNGEON_HEALTH_PRESSURE[t.tier-1];
  close(g['minecraft:health'].max,Number(expected.toFixed(2)),.011);
  // Attack pressure stays at the previous release's value.
  close(g['minecraft:attack'].damage,Number((base['minecraft:attack'].damage*(1+(level-1)*.018)*t.attackMultiplier).toFixed(2)),.011);
  cases++;
 }
}
let previous=0;
for(const t of DUNGEON_TIERS){
 const g=JSON.parse(fs.readFileSync(`${root}/RPG_BP_v0638/entities/${t.boss}.json`))['minecraft:entity'].component_groups[`rpg:dungeon_scaled_${t.tier}_boss_0`];
 assert.ok(g['minecraft:health'].max>previous,`Boss HP progression at tier ${t.tier}`);previous=g['minecraft:health'].max;
}
assert.equal(previous,40000);
close(monsterDefenseFor(260,{tier:10,kind:'boss'}),.5981377626957195);
console.log(`${cases} dungeon groups: reduction relatively -20% again (original ×0.64), progressive HP compression, unchanged attacks, wild reduction removed; boss HP increases through all ten tiers to exactly 40,000`);
