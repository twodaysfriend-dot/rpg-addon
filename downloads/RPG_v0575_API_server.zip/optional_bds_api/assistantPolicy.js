// Pure policy shared by local answers and the optional BDS API bridge.
export const BALANCE_ANSWER='직업·스킬의 사기 여부, 티어·순위·우열 및 밸런스 평가는 답할 수 없습니다. 기술 효과·피해 수치·전직 조건 같은 도감 정보는 따로 질문해 주세요.';
export function isBalanceQuestion(value){
 const q=String(value??'').normalize('NFKC').toLowerCase().replace(/§./g,'').replace(/[^a-z0-9가-힣]/g,'');
 return /사기(?!술)|밸런스|벨런스|티어|순위|최강|최약|너프|하향|상향|구린|쓰레기|개사기|적폐|오버파워|강캐|약캐|캐릭추천|직업추천|추천직업|스킬추천|추천스킬|더강|더세|더쎄|제일세|제일쎄|가장세|가장쎄|뭐가좋|뭐가강|어느게좋|누가강|누가세|성능비교|우열|최적조합|사기조합|버프해야|버프해줘|강한직업|약한직업/.test(q)||/\b(op|overpowered|underpowered|tier|best class|worst class|balance)\b/i.test(String(value??''));
}

export const HIDDEN_PROMOTION_ANSWER='전직 방법·조건 안내는 검사·마법사·궁수·무투가·성직자 5개 기본 직업만 제공합니다. 그 외 직업의 전직 방법·조건은 공개하지 않습니다.';
const PRIVATE_JOB_NAMES=["war_god", "투신", "sword_saint", "검성", "fallen_sword_saint", "타락검성", "sage", "현자", "heavenly_archer", "천궁", "mangnani", "망나니", "beast", "야수", "frost_controller", "냉기 능력자", "fire_controller", "화염술사", "dragon_knight", "용기사", "demon", "악마", "technomancer", "마법공학사", "hacker", "해커", "blood_mage", "혈술사", "assassin", "암살자", "shadow_assassin", "그림자 암살자", "harpooner", "작살꾼", "revenant", "복수귀", "sun_heir", "해의 후예", "moon_heir", "달의 후예", "chameleon", "카멜레온", "fist_bone", "권골", "angel", "천사", "michael", "미카엘", "fallen_angel", "타락천사"];
export function isHiddenPromotionQuestion(value){
 const q=String(value??'').normalize('NFKC').toLowerCase().replace(/[^a-z0-9가-힣]/g,'');
 const privateName=PRIVATE_JOB_NAMES.some(name=>q.includes(name.replace(/[^a-z0-9가-힣]/g,'')));
 return /히든.*(전직|조건|방법|해금)|숨겨진.*(전직|조건|방법|해금)/.test(q)||(privateName&&/전직|조건|되는법|되는방법|얻는법|얻는방법|해금|선행|필요|재료|어떻게.*돼|어떻게.*되|습득/.test(q));
}
