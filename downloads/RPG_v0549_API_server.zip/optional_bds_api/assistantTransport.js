// BDS ONLY: installed by tools/build_bds_assistant.py, never in the normal build.
import {http,HttpRequest,HttpRequestMethod,HttpHeader} from '@minecraft/server-net';
import {secrets} from '@minecraft/server-admin';
const ENDPOINT='http://127.0.0.1:8787/rpg/ask';
let inFlight=0;
export async function rankKnowledge(question,entries){
 if(inFlight>=4)return undefined;
 inFlight++;
 try{
  const request=new HttpRequest(ENDPOINT);request.method=HttpRequestMethod.Post;request.timeout=8;
  request.headers=[new HttpHeader('Content-Type','application/json'),new HttpHeader('X-RPG-Token',secrets.get('rpg_assistant_token'))];
  // Deliberately omit player names, UUIDs, chat history and save data.
  request.body=JSON.stringify({question,entries:entries.map(({id,title,body})=>({id,title,body}))});
  const result=await http.request(request);if(result.status!==200)return undefined;
  const data=JSON.parse(result.body);return data.ids;
 }catch{return undefined;}
 finally{inFlight--;}
}
