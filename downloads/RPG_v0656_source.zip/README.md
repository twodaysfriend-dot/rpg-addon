# RPG v0.6.56 · 적흑색 깃털 날개와 투신 효과

`/rpg:wings`로 장착하는 천사·미카엘·타락천사 날개를 넓은 깃털 날개로 교체했습니다. 어깨 가까운 붉은 덮깃 아래로 어두운 날개깃이 네 겹으로 포개집니다. 미카엘은 따뜻한 진홍빛, 타락천사는 어두운 자줏빛을 띱니다.

투신 기탄에는 중심광 주위를 흐르는 빛줄기, 주먹·발차기 충격파에는 갈라지는 청백색 잔상을 넣었습니다. 명중 순간과 천멸격 준비 순간에는 섬광 둘레에 빛의 고리가 퍼집니다. 각 효과는 네 프레임으로 움직입니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.56으로 적용하고 월드를 다시 여세요. 날개의 외형은 3인칭 시점에서 볼 수 있습니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0656
```
