import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,EquipmentSlot,intervals,events} from './minecraftMock.mjs';
import {RUNNERS as SWORD} from '../RPG_BP_v0543/scripts/skills/sword.js';
import {RUNNERS as FLAME} from '../RPG_BP_v0543/scripts/skills/swordFlameSpin.js';
import {registerTracking} from '../RPG_BP_v0543/scripts/core/tracking.js';
import {setSkills} from '../RPG_BP_v0543/scripts/core/playerData.js';
import {chameleonCastJob} from '../RPG_BP_v0543/scripts/core/chameleon.js';
import {JOBS} from '../RPG_BP_v0543/scripts/data/jobs.js';
import {SKILLS} from '../RPG_BP_v0543/scripts/data/skills.js';
registerTracking();let serial=0;
function scene(job,str){
 const p=player('damage-'+serial++,40),t=player('target-'+serial,1,{typeId:'minecraft:zombie',health:1000,maxHealth:1000,location:{x:0,y:64,z:2}}),hits=[];
 p.setDynamicProperty('rpg:job',job);p.setDynamicProperty('rpg:stat_values',JSON.stringify({str,vit:5,int:5,mag:5}));
 setSkills(p,['sword_spin','sword_wave','sword_flame_spin','sword_rush']);p.equipment.set(EquipmentSlot.Mainhand,new ItemStack(JOBS[job].weapon));
 const dim={id:'minecraft:overworld',getEntities:()=>[t],getBlock:()=>({isSolid:false,typeId:'minecraft:air'}),spawnParticle(){},playSound(){}};
 p.dimension=t.dimension=dim;p.getViewDirection=()=>({x:0,y:0,z:1});p.getRotation=()=>({x:0,y:0});p.teleport=at=>{p.location={...at};};t.setOnFire=()=>{};t.applyKnockback=()=>{};
 t.applyDamage=(amount)=>{hits.push(amount);t.health-=amount;return true;};return {p,t,hits};
}
for(const [id,multiplier]of [['sword_flame_spin',1.5],['sword_wave',1.5],['sword_rush',1.5],['sword_spin',2]]){
 test(id+' boosts actual Sword Saint hits only and applies STR scaling once',()=>{
  for(const job of ['sword_saint','swordsman','fallen_sword_saint','chameleon']){
   if(job!=='chameleon'&&!JOBS[job].skills.includes(id))continue;
   for(const str of [5,15]){
    const {p,t,hits}=scene(job,str),def=SKILLS[id],runner=(id==='sword_flame_spin'?FLAME:SWORD)[id],before=intervals.length;
    if(id==='sword_rush')for(const fn of events.entityHurt.listeners)fn({hurtEntity:t,damage:1,damageSource:{damagingEntity:p}});
    runner(p,chameleonCastJob(id,JOBS[job]),def);
    if(id!=='sword_spin'){const tick=intervals[before];assert.equal(typeof tick,'function');for(let n=0;n<(id==='sword_rush'?def.hits*def.stepTicks:1);n++)tick();}
    assert.equal(hits.length,id==='sword_rush'?8:1,job);
    const expected=def.damage*(job==='sword_saint'?multiplier:1)*(1+.007*(str-5));
    for(const amount of hits)assert.ok(Math.abs(amount-expected)<1e-8,job+': '+amount+' vs '+expected);
   }
  }
 });
}
