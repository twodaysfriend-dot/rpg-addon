# RPG v0.6.84 · 극번 시왕

진홍의 군주의 핏빛 제단 자리에 **극번 · 시왕**을 추가했습니다. 피의 낫으로 이 스킬을 선택해 우클릭하면 찢어진 나비 형태의 피 날개가 펼쳐집니다.

- 최대 **10초**간 시선 방향으로 비행합니다. 위를 보면 상승하고 아래를 보면 내려갑니다.
- 스킬을 다시 쓰거나 10초가 지나면 날개가 접혀 몸을 감싼 뒤 운석처럼 급강하합니다. 착지할 때 반경 **10칸**의 적에게 **기본 마법 피해 90**을 한 번 줍니다.
- 첫 사용은 기본 MP **100**, 기본 쿨타임 **22초**입니다. 비행 중 같은 스킬을 다시 쓰는 급강하는 추가 MP를 쓰지 않습니다. 스킬로 인한 낙하 피해는 방지합니다.
- 3인칭에서 날개, 펄럭이는 동작과 급강하 때 몸을 감싸는 외형을 볼 수 있습니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.84로 활성화하고 월드를 다시 여세요. 모의 테스트에서 수동·자동 급강하, 착지 1회 피해, 벽 차단, 마나·쿨타임, 이전 제단 설정 이전을 확인했습니다. 실제 Bedrock 월드의 비행과 날개 표시는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0684
```
