# RPG v0.6.64 · v0.6.58 기반 복원판

- 룬은 등급과 강화 단계를 보존한 채 일반 인벤토리로 꺼낼 수 있습니다.
- 연속 공격의 후속 타격과 발사 위치는 해당 시점의 플레이어 위치를 기준으로 정합니다.
- 하트, 장비·기술 표시, 난참 연출과 난식의 공격 패턴은 v0.6.58 기준입니다. 난식은 전방위 16발을 4회 발사합니다.

기존 월드에서 업데이트할 수 있도록 세 팩의 UUID를 유지하고 버전을 v0.6.64로 올렸습니다. Bedrock 1.21.100 이상에서 세 팩을 활성화하세요.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0664
```
