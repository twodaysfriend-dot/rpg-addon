import {lineStatLabel,lineStatText,jobStatText} from '../data/jobStats.js';
import {worldMasteryText} from './worldMastery.js';
import { ActionFormData } from '@minecraft/server-ui';
import { JOBS,APPRENTICE_SKILLS } from '../data/jobs.js';
import { SKILLS } from '../data/skills.js';
import { LINE_NAMES,LINE_NOTES,SKILL_NOTES } from '../data/skillGuide.js';
import {getSkills,getJobId} from './playerData.js';
import { showForm } from './skillMenu.js';
const activeJobs=Object.values(JOBS).filter(j=>!j.placeholder);
const activeIds=new Set([...activeJobs.flatMap(j=>j.skills),...Object.values(APPRENTICE_SKILLS).flat()]);
export function skillGuideGroups(){return Object.entries(LINE_NAMES).map(([line,name])=>({line,name,ids:[...activeIds].filter(id=>SKILLS[id]?.line===line)})).filter(g=>g.ids.length);}
export function skillGuideDetail(id,p){
  if(!activeIds.has(id)||!SKILLS[id]||!SKILL_NOTES[id])return undefined;
  const skill=SKILLS[id],owners=activeJobs.filter(j=>j.skills.includes(id)).map(j=>j.name);
  if(Object.values(APPRENTICE_SKILLS).some(list=>list.includes(id)))owners.unshift('견습');
  return `사용 직업: ${owners.join(', ')}\n${lineStatText(skill.line)}\n기본 MP ${skill.mana} / 쿨 ${skill.cooldown/20}초\n\n${SKILL_NOTES[id]}${p&&id==='world_stop'?'\n\n'+worldMasteryText(p):''}\n\n기본 피해는 스탯·장비 보정 전입니다. 다단 명목 합계는 실제 피해를 보장하지 않습니다.\n스킬 ID: ${id}`;
}
export function isSkillGuideAdmin(p){
 try{if(p.playerPermissionLevel===2)return true;}catch{}
 try{if(typeof p.commandPermissionLevel==='number'&&p.commandPermissionLevel>=1)return true;}catch{}
 try{if(typeof p.isOp==='function'&&p.isOp())return true;}catch{}
 return false;
}
export function visibleSkillGuideGroups(p){
 const owned=new Set(getSkills(p));
 return skillGuideGroups().map(g=>({...g,ids:g.ids.filter(id=>isSkillGuideAdmin(p)||owned.has(id))})).filter(g=>g.ids.length);
}
export function canViewSkillEffect(p,id){return activeIds.has(id)&&(isSkillGuideAdmin(p)||getSkills(p).includes(id));}
const open=new Set();
export async function openSkillGuide(p){
  if(open.has(p.id))return;open.add(p.id);
  try{
    const groups=visibleSkillGuideGroups(p);
    for(let i=0;i<80&&p.isValid;i++){
      const form=new ActionFormData().title(isSkillGuideAdmin(p)?'전체 스킬 효과 · 관리자':'내 스킬 효과').body(jobStatText(JOBS[getJobId(p)])+'\n\n'+(isSkillGuideAdmin(p)?'관리자: 모든 구현 스킬의 효과·마나·쿨타임·패시브를 확인합니다.':(groups.length?'내가 배운 스킬의 효과·마나·쿨타임·패시브를 확인합니다.':'아직 배운 스킬이 없습니다. 직업 아이템을 받은 뒤 다시 확인하세요.')));
      for(const g of groups)form.button(`${g.name} (${g.ids.length})\n추천 스탯: ${lineStatLabel(g.line)}`);form.button('닫기');
      const res=await showForm(form,p);if(!res||res.canceled||(!Number.isInteger(res.selection)||res.selection<0)||res.selection>=groups.length)return;
      const group=groups[res.selection];
      group.ids=group.ids.filter(id=>canViewSkillEffect(p,id));
      for(let j=0;j<80&&p.isValid;j++){
        const form=new ActionFormData().title(group.name).body(lineStatText(group.line)+'\n\n'+LINE_NOTES[group.line]);
        for(const id of group.ids)form.button(SKILLS[id].name);form.button('뒤로');
        const pick=await showForm(form,p);if(!pick||pick.canceled||(!Number.isInteger(pick.selection)||pick.selection<0)||pick.selection>=group.ids.length)break;
        const id=group.ids[pick.selection];if(!canViewSkillEffect(p,id))continue;await showForm(new ActionFormData().title(SKILLS[id].name).body(skillGuideDetail(id,p)).button('돌아가기'),p);
      }
    }
  }catch(error){try{p.sendMessage('§c스킬 도감: '+String(error));}catch{}}
  finally{open.delete(p.id);}
}
