import {hasBloodCard} from './bloodCard.js';
import {hasChameleonCard} from './chameleonCard.js';
import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData, MessageFormData } from "@minecraft/server-ui";
import { JOBS } from "../data/jobs.js";
import { getJobId } from "./playerData.js";
import { checkAdvance, requirementStatus, requestAdvance, applyAdvance } from "./advance.js";
import { openLotoDialogue, clearLotoRuntime } from "./loto.js";


export const HITO_LINES = [
  {id:"the_world",label:"더 월드",hidden:true,jobs:["the_world"]},
  {id:"war_god",label:"투신",hidden:true,jobs:["war_god"]},
  {id:"nen",label:"넨",hidden:true,jobs:["nen"]},
  {"id": "sword", "label": "검", "hidden": false, "jobs": ["swordsman", "sword_saint", "fallen_sword_saint"]},
  {"id": "mage", "label": "마법", "hidden": false, "jobs": ["mage", "sage"]},
  {"id": "archer", "label": "궁수", "hidden": false, "jobs": ["archer", "heavenly_archer"]},
  {"id": "holy", "label": "성직", "hidden": false, "jobs": ["cleric", "angel", "michael", "fallen_angel"]},
  {"id": "fist", "label": "격투", "hidden": false, "jobs": ["fighter", "fist_bone"]},
  {"id": "assassin", "label": "암살", "hidden": true, "jobs": ["assassin", "shadow_assassin"]},
  {"id": "harpoon", "label": "작살", "hidden": true, "jobs": ["harpooner", "revenant"]},
  {"id": "berserker", "label": "광전사", "hidden": true, "jobs": ["mangnani", "beast"]},
  {"id": "celestial", "label": "천체", "hidden": true, "jobs": ["sun_heir", "moon_heir"]},
  {"id": "tech", "label": "마법공학", "hidden": true, "jobs": ["technomancer"]},
  {"id": "blood", "label": "혈술사", "hidden": true, "jobs": ["blood_mage"]},
  {"id": "hacker", "label": "해킹", "hidden": true, "jobs": ["hacker"]},
  {"id": "demon", "label": "악마", "hidden": true, "jobs": ["demon"]},
  {"id": "chameleon", "label": "구욱", "hidden": true, "jobs": ["chameleon"]},
  {"id": "frost", "label": "냉기", "hidden": true, "jobs": ["frost_controller"]},
  {"id": "fire", "label": "화염", "hidden": true, "jobs": ["fire_controller"]},
  {"id": "dragon", "label": "용", "hidden": true, "jobs": ["dragon_knight"]}
];
const LINES=HITO_LINES;
const BY_ID = new Map(LINES.map(line => [line.id, line]));
const BY_ENTITY = new Map(LINES.map(line => ["rpg:hito_" + line.id, line]));
const menuActive = new Set();
const lastClick = new Map();
let started = false;

const ALIASES = {
  "검":"sword", "검사":"sword", "검성":"sword", "sword":"sword", "swordsman":"sword",
  "마법":"mage", "마법사":"mage", "현자":"mage", "mage":"mage", "magic":"mage",
  "궁수":"archer", "천궁":"archer", "활":"archer", "archer":"archer", "bow":"archer",
  "성직":"holy", "성직자":"holy", "천사":"holy", "미카엘":"holy", "holy":"holy", "cleric":"holy",
  "격투":"fist", "무투가":"fist", "권골":"fist", "fist":"fist", "fighter":"fist",
  "암살":"assassin", "암살자":"assassin", "그림자암살자":"assassin", "assassin":"assassin",
  "작살":"harpoon", "작살꾼":"harpoon", "복수귀":"harpoon", "harpoon":"harpoon",
  "광전사":"berserker", "망나니":"berserker", "야수":"berserker", "berserker":"berserker", "beast":"berserker",
  "천체":"celestial", "해":"celestial", "달":"celestial", "해의후예":"celestial", "달의후예":"celestial", "celestial":"celestial",
  "마법공학":"tech", "마공학":"tech", "마법공학사":"tech", "tech":"tech", "technomancer":"tech",
  "혈술":"blood", "혈술사":"blood", "blood":"blood", "bloodmage":"blood",
  "해킹":"hacker", "해커":"hacker", "hacker":"hacker",
  "악마":"demon", "demon":"demon",
  "구욱":"chameleon", "카멜레온":"chameleon", "chameleon":"chameleon",
  "냉기":"frost", "냉기능력자":"frost", "frost":"frost",
  "화염":"fire", "화염술사":"fire", "fire":"fire",
  "투신":"war_god", "wargod":"war_god",
  "더월드":"the_world", "theworld":"the_world", "world":"the_world",
  "넨":"nen", "넨능력자":"nen", "nen":"nen",
  "용":"dragon", "용기사":"dragon", "dragon":"dragon", "dragonknight":"dragon"
};

function normalize(s) { return String(s ?? "").trim().toLowerCase().replace(/[\s_-]+/g, ""); }
function lineFor(value) {
  const key = normalize(value);
  return BY_ID.get(key) ?? BY_ID.get(ALIASES[key]);
}
export function listHitoLines(player) {
  const normal = LINES.filter(l => !l.hidden).map(l => l.label).join(", ");
  const hidden = LINES.filter(l => l.hidden).map(l => l.label).join(", ");
  player.sendMessage("§b[전직관] §f사용법: §e/hito <직업계열> §7(또는 /rpg:hito <계열>)");
  player.sendMessage("§a일반: §f" + normal);
  player.sendMessage("§d히든: §f" + hidden);
  player.sendMessage("§7소환알을 바닥에 사용해 배치한 NPC를 우클릭하거나 모바일에서 '전직 상담'을 눌러 전직할 수 있습니다.");
}
export function giveHitoEgg(player,value){
 const line=lineFor(value);if(!line){listHitoLines(player);return false;}
 try{
  const inv=player.getComponent('minecraft:inventory')?.container;if(!inv)throw Error('인벤토리 접근 불가');
  let slot=-1;for(let i=1;i<inv.size;i++)if(!inv.getItem(i)){slot=i;break;}
  if(slot<0){player.sendMessage('§e전직관 소환알을 받을 빈 인벤토리 칸이 필요합니다.');return false;}
  const egg=new ItemStack('rpg:hito_'+line.id+'_spawn_egg',1);inv.setItem(slot,egg);
  player.sendMessage('§a'+(line.id==='chameleon'?'구욱':line.id==='hacker'?'로토':line.label+' 전직관')+' 소환알을 받았습니다. 원하는 곳의 바닥에 사용해 배치하세요.');return true;
 }catch(error){player.sendMessage('§c전직관 소환알 지급 실패: '+String(error).slice(0,180));return false;}
}
// Retained export for scripts using the previous command entry point.
export const spawnHito=giveHitoEgg;
export async function openHitoEggMenu(player){
 const f=new ActionFormData().title('전직관 소환알').body('원하는 전직관 소환알을 받아 바닥에 사용하세요. NPC는 배치된 곳에 머무릅니다.');
 for(const line of LINES)f.button(line.id==='chameleon'?'구욱':line.id==='hacker'?'로토':line.label+' 전직관');f.button('닫기');
 const answer=await safeForm(f,player);if(!answer||answer.canceled||answer.selection==null||answer.selection>=LINES.length)return;
 giveHitoEgg(player,LINES[answer.selection].id);
}
function labelHito(npc){const line=BY_ENTITY.get(npc?.typeId);if(!line)return;try{npc.nameTag=line.id==='chameleon'?'구욱':line.id==='hacker'?'로토':(line.hidden?'§d':'§b')+'[전직관] '+line.label;}catch{}}
async function safeForm(form,player){
  for(let tries=0; tries<8; tries++){
    if(!player?.isValid) return;
    const result=await form.show(player);
    if(!result?.canceled || String(result.cancelationReason)!=="UserBusy") return result;
    await new Promise(r=>system.runTimeout(r,8));
  }
}
function jobLine(j) {
   // celestial consists of two independent branches
   return j.line;
}
function status(player,job,line){
   const cur=getJobId(player);
   if(cur===job.id) return "§a현재 직업";
   if(job.placeholder) return "§8미구현";

   const chk=checkAdvance(player,job);
   if(chk.ok) return "§a전직 가능";
   const req=requirementStatus(player,job);
   if(req && !req.met) return `§e${req.have}/${req.need}`;
   return "§7전직 조건 확인";
}
async function transferHidden(player,job,line){await requestAdvance(player,job);}
export async function openHitoMenu(player,line){
  if(!player?.isValid || !line || menuActive.has(player.id))return;
  if(line.id==='chameleon'&&!hasChameleonCard(player)){await safeForm(new ActionFormData().title('구욱').body('구욱은 조용히 당신을 바라봅니다.').button('닫기'),player);return;}
  if(line.id==='blood'&&!hasBloodCard(player)){await safeForm(new ActionFormData().title('혈술사 전직관').body('혈술사 전직 카드를 손에 들고 다시 대화하세요.').button('닫기'),player);return;}
  menuActive.add(player.id);
  try {
    const cur=JOBS[getJobId(player)];
    const list=line.jobs.map(id=>JOBS[id]).filter(Boolean);
    if(!list.length){player.sendMessage("§7이 계열에는 등록된 직업이 없어.");return;}
    const body=(line.hidden?"§d히든 계열§r - 별도 견습 없음":"§b일반 전직 계열§r - 기본 직업과 상위 직업")+"\n현재 직업: §e"+(cur?.name??"알 수 없음")+"\n\n§7전직 조건을 만족하는 직업만 선택할 수 있어.";
    const form=new ActionFormData().title(line.id==='chameleon'?'구욱':line.label+" 전직관").body(body);
    for(const job of list) form.button(job.name+(job.hidden?' [히든]':' [일반]')+" §7("+job.tier+"차)\n"+status(player,job,line));
    form.button("닫기");
    const ans=await safeForm(form,player);
    if(!ans || ans.canceled || ans.selection==null || ans.selection>=list.length)return;
    const chosen=list[ans.selection];
    if(chosen.id===getJobId(player)){player.sendMessage("§7이미 "+chosen.name+"이야.");return;}
    if(line.hidden) await transferHidden(player,chosen,line);
    else await requestAdvance(player,chosen);
  }catch(err){
    try{player.sendMessage("§c전직관 메뉴 오류: "+String(err).slice(0,220));}catch{}
  }finally{menuActive.delete(player.id);}
}
export function registerHito(){
  if(started)return;started=true;
  const rename=()=>{for(const id of ['overworld','nether','the_end'])try{for(const type of ['rpg:hito_chameleon','rpg:hito_blood'])for(const npc of world.getDimension(id).getEntities({type}))labelHito(npc);}catch{}};
  system.run(rename);system.runInterval(rename,100);
  world.afterEvents.entitySpawn?.subscribe(ev=>{if(BY_ENTITY.has(ev.entity?.typeId))system.run(()=>labelHito(ev.entity));});
  const e=world.afterEvents.playerInteractWithEntity;
  if(!e?.subscribe){console.warn("[RPG HITO] playerInteractWithEntity unavailable");return;}
  e.subscribe(event=>{
    const line=BY_ENTITY.get(event.target?.typeId);
    if(!line)return;
    const p=event.player;
    if(!p || p.typeId!=="minecraft:player")return;
    const now=system.currentTick;
    if(now-(lastClick.get(p.id)??-100)>7){
       lastClick.set(p.id,now);
       if(line.id === "hacker") {
          try {event.target.nameTag = "로토";} catch {}
          system.run(()=>openLotoDialogue(p));
       } else {

          system.run(()=>openHitoMenu(p,line));
       }
    }
  });
  world.afterEvents.playerLeave.subscribe(ev=>{
    lastClick.delete(ev.playerId);
    menuActive.delete(ev.playerId);
    clearLotoRuntime(ev.playerId);
  });
}
