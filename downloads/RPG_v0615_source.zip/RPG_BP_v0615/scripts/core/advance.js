import {bloodCardRequirement} from './bloodCard.js';
import {chameleonCardRequirement} from './chameleonCard.js';
import {maintainWeaponBinding} from './weaponBinding.js';
import { jobTrialStatus } from './jobTrials.js';
import {upgradeLevel} from '../data/upgrades.js';
import {setGearLevel} from './gearState.js';
import { ItemStack, ItemLockMode } from "@minecraft/server";
import { ActionFormData,MessageFormData } from "@minecraft/server-ui";
import { JOB_TRIALS } from '../data/jobTrials.js';
import { JOBS, ALL_WEAPON_IDS, STARTER_BY_LINE, APPRENTICE_SKILLS } from "../data/jobs.js";
import { SKILLS } from "../data/skills.js";
import {
  getJobId, setJobId, getSkills, setSkills, setMana, setIndex, maxManaOf, getProgress, getDisabled, setDisabled,addProgress,
} from "./playerData.js";
import { sound } from "./util.js";
import { showForm } from "./skillMenu.js";
import { beginnerAdvanceUnlocked } from './beginnerData.js';
import { ALL_EQUIPMENT_IDS } from '../data/equipment.js';
import { recordBasicJobAdvance } from './newTrials.js';

// 전직 조건 진행도 (조건이 없으면 null)
export function requirementStatus(player, target) {
  if(target?.id==='blood_mage')return bloodCardRequirement(player);
  if(target?.id==='chameleon')return chameleonCardRequirement(player);
  if(target?.unlockPending)return {met:false,have:0,need:1,label:'해금 조건 미정 · 관리자 /rpg:force the_world로 시험 가능'};
  if(target?.id==='hacker')return {met:false,have:0,need:1,label:'로토와 23회 대화 후 퀴즈 정답 · 월드 최초 정답자 1명만 전직'};
  const trial=jobTrialStatus(player,target);if(trial)return trial;
  if (!target?.req) return null;
  if (beginnerAdvanceUnlocked(player, target)) return {have:5, need:5, label:'첫 사냥 (모험 안내)', met:true};
  const have = Math.min(getProgress(player)[target.req.key] ?? 0, target.req.need);
  return { have, need: target.req.need, label: target.req.label, met: have >= target.req.need };
}

// 전직 가능 여부: 직전 직업 + 전직 조건
export function checkAdvance(player, target) {
  if(target?.unlockPending)return {ok:false,reason:'더 월드는 해금 조건이 미정입니다. 현재 관리자 강제 전직만 지원합니다.'};
  if (!target) return { ok: false, reason: "존재하지 않는 직업입니다." };
  if(target.id==='hacker')return {ok:false,reason:'해커는 로토와 23회 대화 후 퀴즈를 맞힌 월드 최초 1명만 전직할 수 있습니다. 로토에게 말을 걸어 주세요.'};

  if (target.placeholder) {
    return { ok: false, reason: `${target.name}은(는) 아직 구현되지 않았습니다.` };
  }
  if(target.id==='blood_mage'){const r=bloodCardRequirement(player);return r.met?{ok:true}:{ok:false,reason:r.label};}
  if(target.id==='chameleon'){const r=chameleonCardRequirement(player);return r.met?{ok:true}:{ok:false,reason:r.label};}
  const cur = getJobId(player);
  const hiddenStart=target.hidden&&target.parent===null;
  if(hiddenStart&&((JOBS[cur]?.tier??0)<2)&&!(cur==='apprentice'&&JOB_TRIALS[target.id]?.fromApprentice))return {ok:false,reason:'히든 직업은 2차 이상 직업에서 시작할 수 있습니다.'};
  const allowedFrom=JOB_TRIALS[target.id]?.allowedFrom;
  const renouncedHoly=target.id==='fallen_angel'&&cur==='apprentice'&&player.getDynamicProperty('rpg:renounced_holy')===true;
  if (allowedFrom ? !allowedFrom.includes(cur)&&!renouncedHoly : !hiddenStart && target.parent !== cur) {
    const from = allowedFrom?.map(id=>JOBS[id].name).join("·") ?? JOBS[target.parent]?.name ?? "?";
    return { ok: false, reason: `${target.name}은(는) ${from}에서만 전직할 수 있습니다.` };
  }

  const st = requirementStatus(player, target);
  if (st && !st.met) {
    return {
      ok: false,
      reason: `전직 조건 미달: ${st.label} ${st.have}/${st.need}`,
    };
  }
  return { ok: true };
}

// 2차 전직 때 사라질 스킬 id 목록 (선택한 계열 밖의 스킬)
export function skillsLostOnAdvance(player, target) {
  if (target.tier !== 2) return [];
  return getSkills(player).filter((id) => SKILLS[id]?.line !== target.line);
}

function ensureMoonFocus(player, container) {
  if (getJobId(player) !== "moon_heir") return;
  for (let i=0;i<container.size;i++) if (container.getItem(i)?.typeId === "rpg:moon_heir_focus") return;
  const focus = new ItemStack("rpg:moon_heir_focus", 1);
  focus.keepOnDeath = true;
  const remainder = container.addItem(focus);
  if (remainder) player.dimension.spawnItem(remainder, player.location);
}

function moveOrDrop(player, container, item) {
  for (let i = 1; i < container.size; i++) {
    if (!container.getItem(i)) {
      container.setItem(i, item);
      return;
    }
  }
  player.dimension.spawnItem(item, player.location);
}

// 직업 무기를 1번 칸에 고정해서 지급합니다. 이전 RPG 무기(견습 시작 아이템 포함)는 모두 회수합니다.
export function giveWeapon(player, job) {
  if(maintainWeaponBinding(player))return;
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c) return;
  const previous=c.getItem(0),matching=Array.from({length:c.size},(_,i)=>c.getItem(i)).find(i=>i?.typeId===job.weapon);
  const preserved=matching?.clone(),inherited=Math.max(upgradeLevel(matching,'weapon'),upgradeLevel(ALL_WEAPON_IDS.includes(previous?.typeId)?previous:undefined,'weapon'));

  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it && (ALL_WEAPON_IDS.includes(it.typeId) || it.typeId === "rpg:moon_heir_focus")) c.setItem(i, undefined);
  }
  if (!job.weapon) return;

  const old = c.getItem(0);
  if (old) {
    c.setItem(0, undefined);
    moveOrDrop(player, c, old);
  }

  const weapon = preserved&&upgradeLevel(preserved,'weapon')>=inherited?preserved:setGearLevel(preserved??new ItemStack(job.weapon, 1),'weapon',inherited);
  weapon.lockMode = ItemLockMode?.slot ?? "slot";
  weapon.keepOnDeath = true;
  c.setItem(0, weapon);
  if (job.id === "moon_heir") ensureMoonFocus(player, c);
}

// 1번 칸에 무기가 없으면 다시 지급 (사망/크리에이티브 조작 등 대비)
export function ensureWeapon(player) {
  if(maintainWeaponBinding(player))return;
  const job = JOBS[getJobId(player)];
  if (!job?.weapon) return;
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c) return;
  if (c.getItem(0)?.typeId === job.weapon || (job.id === "chameleon" && c.getItem(0)?.typeId === job.altWeapon)) {
    if (job.id === "moon_heir") ensureMoonFocus(player, c);
    return;
  }
  giveWeapon(player, job);
}

// 견습 시작 아이템 지급 + 그 계열의 견습 스킬 습득 (초반 지역의 상자/NPC/명령 블록에서 호출)
export function giveStarter(player, line) {
  const itemId = STARTER_BY_LINE[line];
  if (!itemId) return { ok: false, reason: "알 수 없는 계열입니다. (sword, mage, holy, fist, archer)" };
  if (getJobId(player) !== "apprentice") {
    return { ok: false, reason: "견습만 받을 수 있습니다." };
  }

  const learned = getSkills(player);
  for (const id of APPRENTICE_SKILLS[line] ?? []) {
    if (!learned.includes(id)) learned.push(id);
  }
  setSkills(player, learned);

  const c = player.getComponent("minecraft:inventory")?.container;
  if (c) {
    let has = false;
    for (let i = 0; i < c.size; i++) if (c.getItem(i)?.typeId === itemId) has = true;
    if (!has) {
      const left = c.addItem(new ItemStack(itemId, 1));
      if (left) player.dimension.spawnItem(left, player.location);
    }
  }
  if (line === "archer" && c) {
    const arrows = c.addItem(new ItemStack("minecraft:arrow", 64));
    if (arrows) player.dimension.spawnItem(arrows, player.location);
  }
  return { ok: true };
}

// 애드온 전용 아이템 전부를 인벤토리에 지급 (이미 가진 아이템은 건너뜀)
export function giveAllItems(player) {
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c) return 0;
  const have = new Set();
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it) have.add(it.typeId);
  }
  let n = 0;
  for (const id of new Set([...ALL_WEAPON_IDS, ...ALL_EQUIPMENT_IDS, "rpg:stone_mask", "rpg:stone_mask_fragment", "rpg:blessing_light", "rpg:holy_water", "rpg:sandbag_spawner", "rpg:angel_wing_toggle", "rpg:michael_wing_toggle", "rpg:fallen_wing_toggle", "rpg:mangnani_contract", "rpg:blood_spear"])) {
    if (have.has(id)) continue;
    const left = c.addItem(new ItemStack(id, 1));
    if (left) player.dimension.spawnItem(left, player.location);
    n++;
  }
  return n;
}

export function applyAdvance(player, target) {
  let skills = getSkills(player);
  if(target.id==='fallen_angel'){skills=[];setDisabled(player,[]);}
  if (target.tier === 2) {
    skills = skills.filter((id) => SKILLS[id]?.line === target.line);
  }
  if (target.tier >= 3) {
    // 견습 마법처럼 낮은 차수까지만 쓰는 스킬은 목록에서 제외
    skills = skills.filter((id) => (SKILLS[id]?.maxTier ?? 99) >= target.tier);
  }
  // 천궁 전직 시 궁수 전용 불 화살이 폭탄 화살로 교체됩니다.
  if (target.id === "heavenly_archer") {
    skills = skills.filter(id => id !== "archer_fire" && id !== "archer_triple");
    const disabled = getDisabled(player);
    if (disabled.includes("archer_fire")) setDisabled(player, disabled.filter(id => id !== "archer_fire"));
  }
  // 검성 계열 전직 시 발도를 제거합니다. 섬멸은 검성만 보유합니다.
  if (target.id === "sword_saint" || target.id === "fallen_sword_saint") {
    skills = skills.filter((id) => id !== "sword_draw");
    const off = getDisabled(player);
    if (off.includes("sword_draw")) setDisabled(player, off.filter((id) => id !== "sword_draw"));
  }
  if (target.id === "fallen_sword_saint") {
    skills = skills.filter((id) => id !== "sword_annihilation");
    const off = getDisabled(player);
    if (off.includes("sword_annihilation")) setDisabled(player, off.filter((id) => id !== "sword_annihilation"));
  }
  for (const id of target.skills) if (!skills.includes(id)) skills.push(id);

  setSkills(player, skills);
  setJobId(player, target.id);
  try{recordBasicJobAdvance(player,target.id);}catch{}
  if(target.id==='fallen_angel')player.setDynamicProperty('rpg:renounced_holy',undefined);
  setIndex(player, 0);
  setMana(player, maxManaOf(player));
  giveWeapon(player, target);
  if (target.line === "archer") {
    try {
      const c = player.getComponent("minecraft:inventory")?.container;
      const arrows = c?.addItem(new ItemStack("minecraft:arrow", 64));
      if (arrows) player.dimension.spawnItem(arrows, player.location);
    } catch { /* 인벤토리가 준비되지 않은 경우 */ }
  }

  try {
    player.onScreenDisplay.setTitle(`${target.corrupt ? "§c" : "§b"}${target.name}`, {
      subtitle: "전직 완료",
      fadeInDuration: 10,
      stayDuration: 50,
      fadeOutDuration: 10,
    });
  } catch {
    player.sendMessage(`§e전직 완료: ${target.name}`);
  }
  sound(player.dimension, "random.levelup", player.location, { volume: 1, pitch: 1 });
}

export function resetToApprentice(player) {
  setJobId(player, "apprentice");
  setSkills(player, []);
  setDisabled(player, []);
  setIndex(player, 0);
  setMana(player, maxManaOf(player));
  giveWeapon(player, JOBS.apprentice);
}

// 전직 요청. 사라지는 스킬이 있으면 확인창을 먼저 띄웁니다.
// force=true 는 테스트용으로 조건 검사를 건너뜁니다.
export async function requestAdvance(player, target, force = false) {
  if(!force&&target?.id==='cleric'&&getJobId(player)==='apprentice'){
    if((Number(player.getDynamicProperty('rpg:rpg_level'))||1)<10){player.sendMessage('§e성직자 전직은 레벨 10부터입니다.');return;}
    const answer=await showForm(new MessageFormData().title('성직 전직관').body('회복과 지원의 길을 선택하시겠습니까?\n성직자로 전직하며 다른 계열의 견습 기술은 정리됩니다.').button1('아직 결정하지 않음').button2('확실하게 성직자로 전직'),player);
    if(!answer||answer.canceled||answer.selection!==1)return;
    if(getJobId(player)!=='apprentice')return;
    addProgress(player,'holy_consulted',1);
  }
  if (!force) {
    const r = checkAdvance(player, target);
    if (!r.ok) {
      player.sendMessage(`§c${r.reason}`);
      return;
    }
  }
  if(!force&&target?.id==='fallen_angel'){
    const answer=await showForm(new MessageFormData().title('성직 포기 · 타락천사').body('치유한 플레이어의 사망을 다섯 번 목격했습니다.\n성직을 포기하고 기존 성직 기술을 잃은 뒤 타락천사로 전직합니다.').button1('성직 유지').button2('성직을 포기하고 타락'),player);
    if(!answer||answer.canceled||answer.selection!==1)return;
    const current=checkAdvance(player,target);if(!current.ok){player.sendMessage(current.reason);return;}
  }

  const lost = skillsLostOnAdvance(player, target);
  if (lost.length === 0) {
    applyAdvance(player, target);
    return;
  }

  const names = lost.map((id) => SKILLS[id]?.name ?? id).join(", ");
  const form = new ActionFormData()
    .title("전직 확인")
    .body(
      `${target.name}(으)로 전직하면 다음 스킬이 사라집니다.\n\n§c${names}§r\n\n되돌릴 수 없습니다. 전직할까요?`
    )
    .button("전직한다")
    .button("취소");

  const res = await showForm(form, player);
  if (!res || res.canceled) {
    player.sendMessage("§7전직창이 닫혔습니다. 채팅창을 닫고 다시 시도해 주세요.");
    return;
  }
  if (res.selection !== 0) return;

  // 확인창이 떠 있는 동안 상태가 바뀌었을 수 있으니 다시 확인
  if (!force) {
    const r = checkAdvance(player, target);
    if (!r.ok) {
      player.sendMessage(`§c${r.reason}`);
      return;
    }
  }
  applyAdvance(player, target);
}
