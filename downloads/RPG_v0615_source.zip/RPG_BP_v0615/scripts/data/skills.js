// 스킬 데이터. cooldown 은 틱(20틱 = 1초), mana 는 소모 마나, damage 는 체력 수치(하트 1칸 = 2).
//   maxTier : 이 차수까지만 쓰는 스킬 (마법사 견습 스킬은 3차 전직 시 목록에서 빠짐)
// 실제 동작은 skills/ 폴더의 같은 id 함수가 담당합니다.
export const SKILLS = {
  world_blood:{id:'world_blood',name:'흡혈',line:'the_world',mana:60,cooldown:600,range:5.5,autoRadius:6},
  world_muda:{id:'world_muda',name:'무다!×8',line:'the_world',mana:65,cooldown:140,range:4,width:2,hits:8,interval:5,damagePerHit:6,kick:false},
  world_finish:{id:'world_finish',name:'무다!!!',line:'the_world',mana:70,cooldown:23,range:4,width:1.8,hits:1,interval:5,damagePerHit:10,kick:true},
  world_roller:{id:'world_roller',name:'로드로러다!!',line:'the_world',mana:90,cooldown:240,range:4,width:2,hits:1,interval:5,damagePerHit:35,kick:true},
  world_high:{id:'world_high',name:'High한 기분',line:'the_world',mana:80,cooldown:400,duration:160},
  world_stop:{id:'world_stop',name:'더 월드!',line:'the_world',mana:320,cooldown:400,duration:20,maxDuration:120,masteryPerUse:2,masteryUses:50,bloodMultiplier:1.5,radius:20,ultimate:true},

 // 넨 능력자: 오라 = 마나. 소모량은 지능 효율(최대 50%)을 적용받습니다.
 nen_ten:{id:'nen_ten',name:'전(纏)',line:'nen',mana:40,cooldown:600,duration:400,resistAmp:1},
 nen_in:{id:'nen_in',name:'은(隱)',line:'nen',mana:50,cooldown:500,duration:160,firstHitMult:1.5},
 nen_ko:{id:'nen_ko',name:'경(硬)',line:'nen',mana:70,cooldown:240,damage:60,window:200},
 nen_shu:{id:'nen_shu',name:'주(周)',line:'nen',mana:60,cooldown:480,duration:160,damage:10,knock:0.8},
 nen_hatsu:{id:'nen_hatsu',name:'발(發) 구체',line:'nen',mana:100,cooldown:280,damage:55,speed:1.4,range:30,hitRadius:1.3,radius:4,knockback:1.4},
 // 방출(放出) 4종: 강화계와 방출계는 이웃 계통(효율 80%)이라 마나 소모를 ×1.25 로 잡은 최종값입니다. 지능 감소는 여기에 적용됩니다.
 nen_renda:{id:'nen_renda',name:'방출 · 연탄',line:'nen',mana:90,cooldown:160,shots:3,gap:6,damage:30,speed:1.6,range:28,hitRadius:1,radius:2.5,knockback:.8},
 nen_ho:{id:'nen_ho',name:'방출 · 오라포',line:'nen',mana:160,cooldown:300,charge:20,slowAmp:3,damage:110,range:30,hitRadius:1.3,knockback:1.2},
 nen_zan:{id:'nen_zan',name:'방출 · 참격파',line:'nen',mana:70,cooldown:120,damage:55,range:8,halfAngle:60,knockback:1.1},
 nen_boku:{id:'nen_boku',name:'방출 · 오라 폭주 (궁극기)',line:'nen',mana:400,cooldown:900,damage:160,radius:10,knockback:2.2,guard:60,resistAmp:1,ultimate:true},
 nen_en:{id:'nen_en',name:'원(円) (궁극기)',line:'nen',mana:250,cooldown:1800,duration:300,radius:25,speedAmp:1,critMult:1.5,ultimate:true},
 war_god_punch:{id:'war_god_punch',name:'폭멸타',line:'war_god',mana:60,cooldown:120,damagePerHit:40,hits:1,interval:0,range:4,width:2,kick:false},
 war_god_slash:{id:'war_god_slash',name:'난참',line:'war_god',mana:120,cooldown:200,damagePerHit:10,hits:6,interval:5,range:4,width:2,kick:false},
 war_god_flurry:{id:'war_god_flurry',name:'난식',line:'war_god',mana:120,cooldown:200,damage:34,projectiles:8,speed:1.5,spread:1.2217304764,hitRadius:.9,range:25,kick:false},
 war_god_kick:{id:'war_god_kick',name:'폭열권',line:'war_god',mana:90,cooldown:160,damagePerHit:48,hits:1,interval:0,range:6,width:2.5,kick:true},
 war_god_kick_flurry:{id:'war_god_kick_flurry',name:'파황각',line:'war_god',mana:160,cooldown:320,damagePerHit:18,hits:4,interval:8,range:5.5,width:2.5,kick:true},
 war_god_black_flash:{id:'war_god_black_flash',name:'천멸격 (궁극기)',buffOnlyUltimate:true,line:'war_god',mana:300,cooldown:1800,ultimate:true},
  // 카멜레온 흑염 대검 전용: 충돌 20 고정 피해 / 처치 시 연속 재사용 최대 3회.
  chameleon_crimson_dash: {
    id: "chameleon_crimson_dash", name: "적섬 돌진", line: "chameleon",
    mana: 0, cooldown: 140, damage: 20, duration: 100,
    speedAmplifier: 4, maxChain: 3, finishCooldown: 400, collisionRadius: 1.2,
  },
  chameleon_ground_slam: {
    id: "chameleon_ground_slam", name: "지면강타", line: "chameleon",
    mana: 0, cooldown: 140, damage: 18, radius: 4.6, pulses: 7, pulseStep: 0.34,
  },
  // 해의 후예: 유저 지정 기술. 지정 없는 수치는 임시 밸런스.
  sun_charge: {id:"sun_charge",name:"햇빛 충전",line:"celestial_sun",mana:0,cooldown:100,restore:35},
  sun_slash: {id:"sun_slash",name:"일륜참",line:"celestial_sun",mana:65,cooldown:160,damageMultiplier:4,slowTicks:20,slowAmp:2},
  sun_blessing: {id:"sun_blessing",name:"해의 가호",line:"celestial_sun",mana:110,cooldown:600,duration:400},
  // 해의 축복: 3분(3600틱)간 부정적 상태이상 면역, 최초 3초(60틱) 공격 무적시간 우회.
  sun_divine_blessing: {id:"sun_divine_blessing",name:"해의 축복",line:"celestial_sun",mana:155,cooldown:4200,immunityTicks:3600,pierceTicks:60},
  sun_meteor_drive: {id:"sun_meteor_drive",name:"메테오드라이브",line:"celestial_sun",mana:125,cooldown:300,range:22,beamDamage:14,impactDamage:26},
  sun_radiant_beam: {id:"sun_radiant_beam",name:"방사열선",line:"celestial_sun",mana:180,cooldown:600,chargeTicks:20,duration:100,range:10,damagePerPulse:1,pulsesPerSecond:20},
  sun_descent: {id:"sun_descent",name:"일륜강림 (궁극기)",line:"celestial_sun",mana:320,cooldown:1200,damage:20,radius:12,buffTicks:300,ultimate:true},
  // 달의 후예: 이전 버전 스킬 복원.
  moon_charge: {id:"moon_charge",name:"달빛 충전",line:"celestial_moon",mana:0,cooldown:100,restore:35},
  moon_slash: {id:"moon_slash",name:"초승달 참격",line:"celestial_moon",mana:65,cooldown:160,damage:30,range:5.5},
  moon_moonlight: {id:"moon_moonlight",name:"달빛",line:"celestial_moon",mana:250,cooldown:1200,healRatio:0.5,lightRatio:0.30},
  moon_homing: {id:"moon_homing",name:"월광 차크람",line:"celestial_moon",mana:75,cooldown:100,damage:28,range:10},
  // 달의 차크람을 실제 투척할 때마다 작은 차크람 3개를 추가 발사한다. 60초 유지.
  moon_chakram_split: {id:"moon_chakram_split",name:"차크람 분열",line:"celestial_moon",mana:90,cooldown:1500,duration:1200,smallCount:3,smallDamage:4},
  moon_veil: {id:"moon_veil",name:"밤의 장막",line:"celestial_moon",mana:95,cooldown:450,duration:400},
  moon_fullwave: {id:"moon_fullwave",name:"만월의 파동 (궁극기)",line:"celestial_moon",mana:310,cooldown:1200,damage:50,radius:11,slowTicks:60,ultimate:true},

  // ---------- 악마 (임시 피해량·마나·쿨타임) ----------
  demon_fear: { id:"demon_fear", name:"공포", line:"demon", mana:60, cooldown:160, damage:16, range:26, speed:1.25, fearTicks:80 },
  demon_vampirism: { id:"demon_vampirism", name:"흡혈", line:"demon", mana:90, cooldown:240, damage:12, radius:10, regenerationTicks:140, maxLevel:50 },
  demon_reap: { id:"demon_reap", name:"수확", line:"demon", mana:55, cooldown:120, damage:36, range:4.6 },
  demon_contract: { id:"demon_contract", name:"계약 (우클릭 자신 / 좌클릭 적)", line:"demon", trigger:"hybrid", mana:80, cooldown:400, healthCost:10, enemyDamage:14, enemyStrengthTicks:100, buffTicks:2400 },
  demon_storm: { id:"demon_storm", name:"공포의 폭풍 (궁극기)", line:"demon", mana:280, cooldown:1200, radius:10, duration:200, damagePerSecond:6, ultimate:true },
  demon_domain: { id:"demon_domain", name:"영역전개", line:"demon", mana:240, cooldown:900, radius:7.5, duration:200, hungerAmplifier:4, hungerRefresh:50 },

  // 마법공학사: 임시 피해량/마나/쿨타임. 사용자 요구는 행동/효과를 우선 적용.
  tech_ray: { id:"tech_ray",name:"마공학 광선",line:"tech",mana:90,cooldown:160,damage:18,range:26,groundTicks:80 },
  tech_prison: { id:"tech_prison",name:"마공학 감옥",line:"tech",mana:125,cooldown:340,radius:4,castRange:16,duration:120 },
  tech_sphere: { id:"tech_sphere",name:"마공학 구체",line:"tech",mana:70,cooldown:140,range:36,damage:22,speed:2.25 },
  tech_bomb: { id:"tech_bomb",name:"마공학 폭탄",line:"tech",mana:95,cooldown:220,range:32,damage:30,splashRadius:2.6,splashDamage:9,fuseTicks:40 },
  tech_storm: { id:"tech_storm",name:"마공학 폭풍 (궁극기)",line:"tech",mana:340,cooldown:1200,radius:5,followRange:36,duration:200,damagePerPulse:5,ultimate:true },
  // ---------- 암살자 / 그림자 암살자 (마나·미지정 쿨타임은 임시 밸런스) ----------
  assassin_spin: { id:"assassin_spin",name:"회전베기",line:"assassin",mana:60,cooldown:180,teleport:3,radius:3,damage: 24 },
  assassin_dagger_wave: { id:"assassin_dagger_wave",name:"몰아치는 단검",line:"assassin",mana:70,cooldown:160,damage:25,range:22,speed:1.45,hitRadius:1.1,slowTicks:40 },
  assassin_pierce: { id:"assassin_pierce",name:"피어스",line:"assassin",mana:65,cooldown:240,damage:15,range:4.5,noHealTicks:200 },
  assassin_stealth: { id:"assassin_stealth",name:"은신",line:"assassin",mana:70,cooldown:400,range:12 },
  assassin_mark: { id:"assassin_mark",name:"표식",line:"assassin",mana:75,cooldown:280,range:24,duration:200,damageMultiplier:1.3 },
  shadow_assassinate: { id:"shadow_assassinate",name:"그림자 암살 (궁극기)",line:"assassin",mana:280,cooldown:1000,damage:38,delay:60,range:25,ultimate:true },

  // ---------- 히든 직업 화염술사: 화염 저항 I 상시 패시브, 액티브 5종 ----------
  // 단위: 20틱=1초, 피해량은 체력 수치. 임시 밸런스.
  fire_ignite: { id:"fire_ignite", name:"자연발화", line:"fire", mana:55, cooldown:120, damage:15, radius:7, burnSeconds:5 },
  fire_pillar: { id:"fire_pillar", name:"불기둥", line:"fire", mana:110, cooldown:320, damage:22, range:22, radius:3, launch:1.0, burnSeconds:3 },
  fire_wheel: { id:"fire_wheel", name:"화염바퀴", line:"fire", mana:95, cooldown:220, damage:18, range:8, speed:1.3, wheelRadius:.75, hitRadius:1.5, burnSeconds:4 },
  fire_armor: { id:"fire_armor", name:"화갑", line:"fire", mana:100, cooldown:500, duration:200 },
  fire_emperor: { id:"fire_emperor", name:"염제 (궁극기)", line:"fire", mana:300, cooldown:1200, damage:36, radius:12, burnSeconds:5, zoneTicks:100, zoneDamage:4, buffTicks:300, ultimate:true },

  // ---------- 히든 냉기 능력자 (임시 밸런스: 피해는 체력 수치) ----------
  frost_shard: { id:"frost_shard",name:"서리탄",line:"frost",mana:35,cooldown:60,damage:14,range:32,speed:1.65,slowTicks:80 },
  frost_grasp: { id:"frost_grasp",name:"빙결의 손",line:"frost",mana:55,cooldown:160,damage:12,range:7,freezeTicks:40 },
  frost_barrage: { id:"frost_barrage",name:"빙주난사",line:"frost",mana:95,cooldown:240,shots:5,damage:7,range:24,speed:1.8,spread:.16 },
  frost_step: { id:"frost_step",name:"빙하보",line:"frost",mana:55,cooldown:200,distance:6,buffTicks:100 },
  frost_field: { id:"frost_field",name:"설한결계",line:"frost",mana:120,cooldown:400,radius:7,duration:100,damage:10 },
  frost_great_release: { id:"frost_great_release",name:"대빙해소",line:"frost",mana:100,cooldown:280,range:10,chargeTicks:8,dashSpeed:1.8,damage:42,freezeTicks:60 },
  frost_absolute: { id:"frost_absolute",name:"영점빙옥 (궁극기)",line:"frost",mana:300,cooldown:900,radius:12,damage:38,freezeTicks:100,ultimate:true },
  // ---------- 작살꾼 / 복수귀 ----------
  harpoon_throw: { id:"harpoon_throw",name:"작살",line:"harpoon",mana:50,cooldown:160,damage:12,range:30,speed:1.35 },
  harpoon_dive: { id:"harpoon_dive",name:"잠수",line:"harpoon",mana:70,cooldown:400,duration:100 },
  harpoon_charge: { id:"harpoon_charge",name:"돌진",line:"harpoon",mana:100,cooldown:300,damage:28,length:5,width:2.5 },
  soul_harpoon: { id:"soul_harpoon",name:"영혼작살",line:"harpoon",mana:75,cooldown:200,damage: 32,range:34,speed:1.45 },
  soul_separation: { id:"soul_separation",name:"영혼분리",line:"harpoon",mana:150,cooldown:600,range:7,delay:20,radius:3,stun:60 },
  revenant_deep_pierce: {id:'revenant_deep_pierce',name:'딥 피어스',line:'harpoon',mana:18,cooldown:50,damage:18,range:5.5,halfWidth:.9},
  revenant_rend: {id:'revenant_rend',name:'찢어내기',line:'harpoon',mana:24,cooldown:80,damage:16,range:4.5,halfWidth:2.4,bleedDamage:3,bleedHits:3,bleedInterval:20},
  revenant_execution: { id:"revenant_execution",name:"처형 (궁극기)",line:"harpoon",mana:200,cooldown:1200,successCooldown:100,failDamage:50,healthThreshold:.25,radius:4,ultimate:true },

  // ---------- 혈술사: 혈액 기반 마법 (임시 밸런스, 단위는 게임 틱) ----------
  blood_spear: { id:"blood_spear",name:"피의 창 제작",line:"blood",mana:40,cooldown:100,damage: 14,range:6,durability:5,witherTicks:60 },
  blood_tentacle:{id:'blood_tentacle',name:'혈촉수',line:'blood',mana:100,cooldown:100,duration:60,radius:20,damage:28},
  blood_orb: { id:"blood_orb",name:"혈성뢰",line:"blood",mana:75,cooldown:100,damage:18,splashDamage:8,burstRadius:2.5,range:30,speed:1.2 },
  blood_supernova: { id:"blood_supernova",name:"초신성",line:"blood",mana:120,cooldown:300,damage:30,burstRadius:5,forward:3,detonateTicks:15 },
  blood_mark: { id:"blood_mark",name:"혈인 (근거리·원거리)",line:"blood",mana:60,cooldown:120,meleeRange:4,meleeDamage:17,rangedDamage:15,range:27 },
  blood_awaken: { id:"blood_awaken",name:"혁린약동•재",line:"blood",mana:180,cooldown:900,warningTicks: 1200,strengthAmp:2,resistanceAmp:2,hungerAmp:2 },
  blood_bind: { id:"blood_bind",name:"적박 (궁극기)",line:"blood",mana:250,cooldown:1300,duration:100,damage:10,healCap:12,radius:16,ultimate:true },
  // ---------- 해커: v0.4.37 기능 복원 ----------
  hacker_hack: { id:"hacker_hack",name:"해킹",line:"hacker",mana:40,cooldown:120,range:32 },
  hacker_dummy_data: { id:"hacker_dummy_data",name:"더미데이터",line:"hacker",mana:30,cooldown:40,range:20,damage: 26,speed:1.65,hitRadius:0.9,lifetime:50 },
  hacker_reboot: { id:"hacker_reboot",name:"시스템 재부팅",line:"hacker",mana:150,cooldown:800,radius:30 },
  hacker_stealth: { id:"hacker_stealth",name:"은신",line:"hacker",mana:60,cooldown:400 },
  hacker_copy: { id:"hacker_copy",name:"카피",line:"hacker",mana:200,cooldown:1200 },
  hacker_ddos: { id:"hacker_ddos",name:"디도스",line:"hacker",mana:110,cooldown:240,radius:10,damage:30 },
  hacker_emp: { id:"hacker_emp",name:"EMP (궁극기)",line:"hacker",mana:350,cooldown:1800,radius:30,duration:100,ultimate:true },

  // ---------- 히든 직업 용기사 ----------
  dragon_triple_strike: { id:"dragon_triple_strike", name:"삼조격", line:"dragon", mana:70, cooldown:220, duration:200, bonusDamage:12, thirdStun:20 },
  dragon_gaze: { id:"dragon_gaze", name:"용의 시선", line:"dragon", mana:85, cooldown:180, damage:20, range:28, speed:1.5, markDuration:200, markMultiplier:1.3 },
  dragon_charge: { id:"dragon_charge", name:"무쌍돌격", line:"dragon", mana:110, cooldown:320, damage:18, range:26, speed:1.75 },
  // 5초 강제 질주: 21블록/초 = 1.05블록/틱. 충돌한 서로 다른 적에 대해 14 × 1.5^(n-1).
  dragon_sprint: { id:"dragon_sprint", name:"용의 질주", line:"dragon", mana:110, cooldown:400, duration:100, speed:21, damage:14, multiplier:1.5, hitRadius:1.35 },
  dragon_domain: { id:"dragon_domain", name:"현월수룡 (궁극기)", line:"dragon", mana:320, cooldown:1200, radius:7, duration:200, entryDamage:20, pulseDamage:8, allyBuffTicks:60, ultimate:true },
  dragon_breath: { id:"dragon_breath", name:"용의 브레스", line:"dragon", mana:120, cooldown:280, damage:24, range:28, speed:1.45, hitRadius:1.3, burnSeconds:4 },

  // ---------- 검 계열 ----------
  // 검사 계열 공통 스킬: 작골염양. 미지정 수치는 임시 밸런스(틱 단위).
  sword_flame_spin: {
    id: "sword_flame_spin", name: "작골염양", line: "sword", damageByJob: { sword_saint: 18.9 },
    mana: 50, cooldown: 160, damage: 12.6,
    duration: 28, hits: 3, hitInterval: 10, radius: 3.4, burnSeconds: 4,
    dashRange: 7, dashSpeed: 1.0,
  },
  // 검성·타락검성 공용: 세로 방향 호 참격을 3회 연속 발동. 수치는 임시 밸런스.
  sword_kenho_rando: {
    id: "sword_kenho_rando", name: "검호 난도", line: "sword",
    mana: 65, cooldown: 220, damagePerSlash: 12,
    slashes: 3, slashInterval: 12, reach: 5.5, halfWidth: 1.9,
  },
  // 검성·타락검성 공용: 시전 전방 180도로 확장되는 큰 초승달·작은 달 참격.
  sword_moon_dragon: {
    id: "sword_moon_dragon", name: "월룡륜미", line: "sword",
    mana: 70, cooldown: 180, damage: 28,
    range: 12, radius:12, duration:12, height:3, knockback: 0.8,
  },
  sword_spin: {
    id: "sword_spin", name: "360도 휘두르기", line: "sword", damageByJob: { sword_saint: 20 },
    mana: 20, cooldown: 30,
    damage: 10, radius: 4.5, knockback: 1.3,
  },
  sword_wave: {
    id: "sword_wave", name: "검기 방출", line: "sword", damageByJob: { sword_saint: 21 },
    mana: 30, cooldown: 60,
    damage: 14, range: 18, speed: 1.0, width: 2.5, hitRadius: 2.6, knockback: 1.0,
  },
  sword_annihilation: {
    id: "sword_annihilation", name: "섬멸", line: "sword",
    // 발도를 대체하는 검성 전용 광역 참격. 전방 15블록 순간이동, 이동 경로 반경 4블록, 대상별 1회 피해.
    mana: 40, cooldown: 100,
    damage: 52, range: 15, hitRadius: 4, knockback: 1.15,
  },
  sword_rush: {
    id: "sword_rush", name: "러쉬 (궁극기)", line: "sword", damageByJob: { sword_saint: 6 },
    mana: 80, cooldown: 300,
    damage: 4, radius: 10, hits: 8, stepTicks: 4, // 40% of original 10 damage per hit
  },
  fallen_sword_frenzy: {
    id: "fallen_sword_frenzy", name: "광분화", line: "sword",
    mana: 100, cooldown: 1200, // 60초 쿨타임
    duration: 400, lifesteal: 0.30, // 20초간 모든 직접 피해의 30% 흡혈
  },

  // ---------- 히든 흑마법사 / 반물질의 신 ----------
  // 피해량·마나·쿨타임은 추후 밸런싱하기 쉽도록 이곳에서 수정합니다.
  dark_energy: {
    id: "dark_energy", name: "암흑 에너지", line: "necro",
    mana: 55, cooldown: 80, damage: 12, range: 28, speed: 1.35, radius: 1.5, burstRadius: 3, burstDamage: 12,
  },
  event_horizon: {
    id: "event_horizon", name: "사건의 지평선", line: "necro",
    mana: 120, cooldown: 360, size: 5, duration: 100, stunTicks: 60, range: 22,
  },
  dark_chains: {
    id: "dark_chains", name: "암흑사슬", line: "necro",
    mana: 140, cooldown: 360, delay: 60, damage: 36, range: 35,
  },
  dark_touch: {
    id: "dark_touch", name: "어둠의 손길", line: "necro",
    mana: 85, cooldown: 200, damage: 18, range: 35, pullDistance: 2.25,
  },
  // '암흑 에너지' 스킬은 흑마법사=투사체, 반물질의 신=지름 6 범위 공격으로 나뉩니다.
  // 범위형은 아래 burstRadius/burstDamage로 독립 밸런싱할 수 있습니다.
  death_domain: {
    id: "death_domain", name: "죽음의 영역", line: "necro",
    mana: 250, cooldown: 900, duration: 240, radius: 5, range: 32,
    darknessLevel: 0, weaknessLevel: 1, // 나약함 II = amplifier 1
  },

  // ---------- 히든 망나니 / 야수 ----------
  // 패시브: 엔티티 처치 시 5초간 신속 III + 재생 III (망나니/야수 공통)
  berserker_charge: {
    id: "berserker_charge", name: "돌진", line: "berserker",
    mana: 70, cooldown: 160, damage: 14, range: 17, wallHitDistance: 2.5,
    wallStunTicks: 40, wallDamageMultiplier: 2,
  },
  berserker_slam: {
    id: "berserker_slam", name: "내려찍기", line: "berserker",
    mana: 80, cooldown: 240, radius: 5, riseBlocks: 10,
    damage: 18,
  },
  berserker_execute: {
    id: "berserker_execute", name: "참수", line: "berserker",
    mana: 90, cooldown: 360, nextMeleeMultiplier: 4, executeThreshold: 0.15,
  },
  beast_berserk: {
    id: "beast_berserk", name: "광분화", line: "berserker",
    mana: 180, cooldown: 1000, duration: 400,
    hungerAmp: 2, strengthAmp: 3, resistanceAmp: 1, speedAmp: 1,
    beastLifesteal: 0.15, beastAbsorptionAmp: 3, // 야수 전용 추가 피해 흡수 IV (20초)
  },
  berserker_triple_slash: {
    id: "berserker_triple_slash", name: "3연베기", line: "berserker",
    mana: 70, cooldown: 200, damagePerHit: 12,
    slashes: 3, slashInterval: 10, stepDistance: 1.1, range: 3.5, halfWidth: 2.2,
  },
  beast_flame_burst: {
    id: "beast_flame_burst", name: "화염방사", line: "berserker",
    mana: 110, cooldown: 240, shots: 3, shotInterval: 7,
    damagePerShot: 15, range: 26, speed: 1.6, hitRadius: 1.3, burnSeconds: 3,
  },
  beast_grand_explosion: {
    id: "beast_grand_explosion", name: "대폭발 (궁극기)", line: "berserker",
    mana: 280, cooldown: 1200, delay: 20, radius: 15, damage: 70, ultimate: true,
  },

  // ---------- 궁수 계열 ----------
  // 활은 화살을 사용해 평타 사격을 할 수 있습니다. 스킬은 활을 당겼다 놓으면 추가 발동합니다.
  archer_airwalk: {
    id: "archer_airwalk", name: "에어워크", line: "archer",
    mana: 45, cooldown: 300, // 견습 3초 / 궁수 8초 / 천궁 15초
  },
  archer_rapid: {
    id: "archer_rapid", name: "연사", line: "archer",
    mana: 35, cooldown: 60, // 견습 2발 / 궁수 3발 / 천궁 5발
  },
  archer_fire: {
    id: "archer_fire", name: "불 화살", line: "archer", maxTier: 2,
    mana: 50, cooldown: 100, burnSeconds: 5,
  },
  archer_ice: {
    id: "archer_ice", name: "얼음 화살", line: "archer",
    mana: 60, cooldown: 110, slowAmp: 2, extraDamage: 3,
  },
  archer_lightning: {
    id: "archer_lightning", name: "전기 화살", line: "archer",
    mana: 65, cooldown: 120, stunTicks: 20,
  },
  archer_homing: {
    id: "archer_homing", name: "유도 화살 활성화", line: "archer",
    mana: 160, cooldown: 2600, duration: 2400,
  },
  archer_bomb: {
    id: "archer_bomb", name: "폭탄 화살", line: "archer",
    mana: 90, cooldown: 140, extraDamage: 14,
  },
  archer_triple: {
    id: "archer_triple", name: "삼연사", line: "archer",
    mana: 45, cooldown: 80, damage: 7, range: 30, spread: 0.15,
  },
  archer_pierce: {
    id: "archer_pierce", name: "관통 화살", line: "archer",
    mana: 65, cooldown: 140, damage: 18, range: 38, hitRadius: 1.3,
  },
  archer_judgement: {
    id: "archer_judgement", name: "심판", line: "archer",
    // 내가 가장 최근 피해를 준 살아 있는 대상에게 대형 빛의 화살 발사 (65피해, 35초, 300MP).
    mana: 300, cooldown: 700, damage: 65, range: 96, speed: 2.6,
  },
  archer_heavenly: {
    id: "archer_heavenly", name: "천공의 일격 (궁극기)", line: "archer",
    mana: 260, cooldown: 600, damage: 42, range: 52, hitRadius: 2.3, burstDamage: 18, burstRadius: 5,
  },

  // ---------- 무투가 계열 ----------
  // 모든 피해에는 힘 버프 증가분이 더해지고, 강펀치가 켜져 있으면 그 합계가 2배가 됩니다.
  fist_strong: {
    id: "fist_strong", name: "강펀치", line: "fist",
    mana: 30, cooldown: 200,
    hits: 3, duration: 600, // 다음 3번 공격 2배 (30초 안에 못 쓰면 사라짐)
  },
  fist_flurry: {
    id: "fist_flurry", name: "난타", line: "fist",
    mana: 80, cooldown: 300,
    damage: 20, hits: 10, stepTicks: 2, radius: 10, range: 8, returnToOrigin: false, // damage 는 전체 합계 (체력 10칸)
  },
  fist_smash: {
    id: "fist_smash", name: "스매쉬", line: "fist",
    mana: 60, cooldown: 200, // 쿨타임 10초
    damage: 28, range: 32, charge: 20, dashSpeed: 3.5, coneDot: 0.85, knockback: 1.6,
  },

  // ---------- 무투가 계열: 권골 ----------
  fist_wind: {
    id: "fist_wind", name: "풍압", line: "fist",
    mana: 90, cooldown: 260, // 마법 피해, 쿨타임 13초
    damage: 20, damageType: "magic", range: 12, coneDot: 0.5, knockback: 6.4, vertical: 1.8,
  },
  fist_face: {
    id: "fist_face", name: "안면강타", line: "fist",
    mana: 100, cooldown: 400,
    radius: 6, stun: 20, damage: 0, // 6블럭 안 모두 끌어오고 1초 기절
  },
  fist_stance: {
    id: "fist_stance", name: "강자의 자세", line: "fist",
    mana: 100, cooldown: 600,
    freeze: 20, buffTicks: 300, strengthAmp: 1, resistanceAmp: 1, // 1초 자기 둔화, 15초간 힘 2 / 저항 2
  },
  fist_finale: {
    id: "fist_finale", name: "대미장식 (궁극기)", line: "fist",
    mana: 300, cooldown: 1200,
    damage: 60, radius: 12, rise: 15, riseTicks: 20, hoverTicks: 10, holdOffset: 2.0, slamSpeed: 3, // 체력 30칸 고정 피해
  },

  // ---------- 마법 계열: 견습 ----------
  mage_fireball: {
    id: "mage_fireball", name: "파이어볼", line: "mage", maxTier: 2,
    mana: 15, cooldown: 20,
    damage: 6, speed: 1.2, range: 40, radius: 3, hitRadius: 1.2,
  },
  mage_lightning: {
    id: "mage_lightning", name: "라이트닝", line: "mage", maxTier: 2,
    mana: 40, cooldown: 60,
    damage: 8, range: 24,
  },

  // ---------- 마법 계열: 2차 ----------
  mage_flame_on: {
    id: "mage_flame_on", name: "플레임온", line: "mage",
    mana: 150, cooldown: 240,
    damage: 10, radius: 15, burn: 5,
  },
  mage_thunder: {
    id: "mage_thunder", name: "번개", line: "mage",
    mana: 200, cooldown: 300,
    damage: 25, strikes: 3, interval: 8, range: 20, // damage 는 3번 합계
  },
  mage_ice_fire: {
    id: "mage_ice_fire", name: "아이스불", line: "mage",
    mana: 180, cooldown: 280,
    damage: 12, radius: 10, slowAmp: 5, duration: 80,
  },
  mage_gravity: {
    id: "mage_gravity", name: "그래비티", line: "mage",
    mana: 160, cooldown: 280,
    damage: 10, radius: 10, slowAmp: 3, duration: 100, // 구속 4단계 = amplifier 3
  },
  mage_bombaye: {
    id: "mage_bombaye", name: "봄바예", line: "mage",
    mana: 120, cooldown: 120,
    damage: 14, shots: 4, damageMultiplier: 0.3,
    speed: 0.9, range: 30, seekRadius: 25, turn: 0.25, hitRadius: 1.4,
  },

  // ---------- 마법 계열: 3차 ----------
  sage_meteor: {
    id: "sage_meteor", name: "메테오", line: "mage",
    mana: 700, cooldown: 400,
    damage: 58, radius: 8, delay: 40, range: 40,
    homingRange: 60, // 마지막으로 맞춘 대상이 이 거리 안에 있으면 그 대상에게 낙하
  },
  sage_raiyoung: {
    id: "sage_raiyoung", name: "뇌영", line: "mage",
    mana: 450, cooldown: 100,
    damage: 28.8, speed: 2.2, range: 35, hitRadius: 2.0, burst: 4, // 36의 0.8배
  },
  sage_zero: {
    id: "sage_zero", name: "절대영도", line: "mage",
    mana: 1000, cooldown: 450,
    damage: 38.4, radius: 20, freeze: 100, // 48의 0.8배
  },
  sage_blackhole: {
    id: "sage_blackhole", name: "블랙홀", line: "mage",
    mana: 900, cooldown: 500,
    damage: 50, radius: 12, duration: 120, range: 30, homingRange: 60, // damage 는 지속 시간 동안의 합계
  },
  sage_sphere: {
    id: "sage_sphere", name: "초구체", line: "mage",
    mana: 750, cooldown: 250,
    damage: 50, speed: 1.6, range: 32, hitRadius: 2.2, radius: 7, // 기본 피해 50
  },
  sage_zoltraak: {
    id: "sage_zoltraak", name: "졸트라크", line: "mage",
    mana: 1000, cooldown: 600,
    damage: 96, range: 50, width: 5, // 120의 0.8배
  },

  // ---------- 성직자 계열 ----------
  // trigger: "hit" 이면 우클릭이 아니라 '좌클릭으로 엔티티를 때릴 때' 발동합니다.
  // 맞은 엔티티를 즉시 치유. 회복량은 직업별 하트 칸 수(견습 2 / 성직자 4 / 천사 5 / 미카엘 8칸)
  holy_heal: {
    id: "holy_heal", name: "힐", line: "holy", trigger: "hit",
    mana: 30, cooldown: 20,
    healByJob: { apprentice: 2, cleric: 4, angel: 5, michael: 8 }, // 하트 칸 수
  },
  // 저항/힘 단계는 표시 단계(1=I, 2=II, 3=III) 기준입니다. 성직자 1 / 천사 2 / 미카엘 3
  holy_shield: {
    id: "holy_shield", name: "불굴의 방패", line: "holy",
    mana: 60, cooldown: 400,
    absorption: 4, duration: 6000, radius: 8, // absorption 은 효과 단계(0=1단계)
    resistanceByJob: { cleric: 1, angel: 2, michael: 3 },
  },
  holy_sword: {
    id: "holy_sword", name: "불굴의 검", line: "holy",
    mana: 70, cooldown: 400,
    duration: 6000, radius: 8,
    strengthByJob: { cleric: 1, angel: 2, michael: 3 },
  },
  // 좌클릭으로 엔티티 1명에게 부착. 성직자와 maxDistance 칸 넘게 떨어지면 사라집니다.
  // 붙어 있는 동안 성직자는 허기, 대상은 재생/신속/흡수 (표시 단계, 전직할수록 +1)
  holy_orb: {
    id: "holy_orb", name: "축복의 구슬", line: "holy", trigger: "hit",
    mana: 90, cooldown: 160,
    maxDistance: 30,
    hunger: 2, // 성직자에게 걸리는 허기 단계(표시 단계)
    regenByJob: { cleric: 2, angel: 3, michael: 4 },
    speedByJob: { cleric: 2, angel: 3, michael: 4 },
    absorbByJob: { cleric: 8, angel: 9, michael: 10 },
  },
  holy_pray: {
    id: "holy_pray", name: "기도", line: "holy",
    mana: 0, cooldown: 24000, // 게임 시간 하루(20분)에 1번
    duration: 200, // 기도 중 실명/구속 시간(틱)
  },
  angel_bless: {
    id: "angel_bless", name: "천사의 축복", line: "holy",
    mana: 250, cooldown: 1200,
    heal: 20, regen: 2, resistance: 1, speed: 1, duration: 6000, radius: 12,
  },
  angel_zone: {
    id: "angel_zone", name: "축복 영역", line: "holy",
    mana: 300, cooldown: 3000,
    heal: 2, radius: 8, duration: 300, slowAmp: 1,
    regen: 4,
  },

  // ---------- 성직자 계열: 타락천사 ----------
  // 좌클릭으로 적을 때리면 발동: 상대에게 하트 8칸(damage 16) 피해 (다른 효과 없음)
  fallen_sacrifice: {
    id: "fallen_sacrifice", name: "Sacrifice", line: "holy", trigger: "hit",
    mana: 50, cooldown: 100,
    damage: 16, // 하트 8칸
  },
  fallen_sword: {
    id: "fallen_sword", name: "파멸의 검", line: "holy",
    mana: 120, cooldown: 200,
    damage: 38, range: 18, width: 1.8, wither: 1, witherTicks: 100,
  },
  fallen_shield: {
    id: "fallen_shield", name: "저주의 방패", line: "holy",
    mana: 100, cooldown: 400,
    resistance: 2, duration: 100, reflect: 1.0, witherTicks: 60, // 5초간 받은 피해의 100% 반사
  },
  fallen_curse: {
    id: "fallen_curse", name: "타천의 저주", line: "holy",
    mana: 130, cooldown: 240,
    damage: 10, range: 30, duration: 200,
  },
  fallen_orb: {
    id: "fallen_orb", name: "저주의 구슬", line: "holy",
    mana: 150, cooldown: 200,
    damage: 16, speed: 1.1, range: 35, hitRadius: 1.4, radius: 5, duration: 200,
    maxDistance: 30, vulnerability: 0.35, witherAmp: 2,
  },
  fallen_zone: {
    id: "fallen_zone", name: "저주 영역", line: "holy",
    mana: 300, cooldown: 800,
    damage: 3, radius: 9, duration: 300,
  },
  fallen_end: {
    id: "fallen_end", name: "종말 (궁극기)", line: "holy",
    mana: 800, cooldown: 1200,
    damage: 60, radius: 25, charge: 80, chargeSlowAmp: 0, // charge 동안 종말이 타천을 따라다니며 내부 적을 사슬로 묶음(구속 1)
  },
};

// Use the real player job, including when a borrowed skill supplies another job context.
export function damageForJob(def,jobId){return def.damageByJob?.[jobId]??def.damage;}
