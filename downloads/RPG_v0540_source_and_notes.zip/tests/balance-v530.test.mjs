import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,system,intervals,EquipmentSlot,events,players} from './minecraftMock.mjs';
import {SKILLS} from '../RPG_BP_v0540/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0540/scripts/data/jobs.js';
import {RUNNERS as FIST} from '../RPG_BP_v0540/scripts/skills/fist.js';
import {RUNNERS as BLOOD} from '../RPG_BP_v0540/scripts/skills/blood.js';
import {RUNNERS as HOLY} from '../RPG_BP_v0540/scripts/skills/holy.js';
import {RUNNERS as HARPOON} from '../RPG_BP_v0540/scripts/skills/harpoon.js';
import {RUNNERS as ARCHER,shootHeavenlyInstant,registerArcher,heavenlyAmmoCost,MANA_ARROW_ID} from '../RPG_BP_v0540/scripts/skills/archer.js';
import {RUNNERS as ASSASSIN,registerAssassin} from '../RPG_BP_v0540/scripts/skills/assassin.js';
import {RUNNERS as HACKER} from '../RPG_BP_v0540/scripts/skills/hacker.js';
import {registerInput} from '../RPG_BP_v0540/scripts/core/input.js';
import {giveDoubleBuff,doubleLeft} from '../RPG_BP_v0540/scripts/core/fistState.js';
import {getMana,setMana,setSkills,setIndex,cooldownLeft,startCooldown,resetCooldowns} from '../RPG_BP_v0540/scripts/core/playerData.js';
import {getContext} from '../RPG_BP_v0540/scripts/core/context.js';
import {purchaseChameleonSkill,executeChameleonSkill,remainingSkillUses} from '../RPG_BP_v0540/scripts/core/chameleonProgress.js';
let serial=0;
function scene(job='heavenly_archer'){
  const p=player('scenario'+serial++,40),targets=[],spawned=[],particles=[];
  p.setDynamicProperty('rpg:job',job);setSkills(p,[...JOBS[job].skills]);
  p.getViewDirection=()=>({x:0,y:0,z:1});p.getHeadLocation=()=>({x:p.location.x,y:p.location.y+1.6,z:p.location.z});
  p.teleport=pos=>{p.location={...pos};};p.getTags=()=>[];p.hasTag=()=>false;
  const dim={id:'minecraft:overworld',getPlayers:()=>[],getBlock:()=>({isSolid:false,isAir:true,typeId:'minecraft:air'}),spawnParticle:(id,pos)=>particles.push({id,pos}),playSound(){},
    getEntities(q={}){return targets.filter(t=>!q.type||t.typeId===q.type).filter(t=>!q.excludeTypes?.includes(t.typeId)).filter(t=>!q.location||Math.hypot(t.location.x-q.location.x,t.location.y-q.location.y,t.location.z-q.location.z)<=(q.maxDistance??Infinity));},
    spawnEntity(typeId,pos){const e={id:'projectile'+serial++,typeId,isValid:true,location:{...pos},dimension:dim,remove(){this.isValid=false;},teleport(pos){this.location={...pos};},getComponent(){return {shoot(){}};}};spawned.push(e);return e;},
  };p.dimension=dim;
  function mob(x=0,z=3,hp=1000){const e=player('mob'+serial++,1,{typeId:'minecraft:zombie',location:{x,y:64,z},health:hp,maxHealth:1000,dimension:dim});e.damage=[];e.knocks=[];e.applyDamage=(n,options)=>{e.damage.push({n,options});e.health-=n;return true;};e.applyKnockback=(...args)=>e.knocks.push(args);e.kill=()=>{e.health=0;e.killed=true;};e.getTags=()=>[];e.hasTag=()=>false;e.teleport=pos=>{e.location={...pos};};targets.push(e);return e;}
  return {p,dim,mob,targets,spawned,particles};
}
test('requested damage, mana, cooldown, radius and one-second stance values',()=>{
  assert.deepEqual([SKILLS.fallen_end.damage,SKILLS.fallen_end.mana],[60,800]);assert.equal(SKILLS.fist_stance.freeze,20);
  assert.deepEqual([SKILLS.fist_wind.damage,SKILLS.fist_wind.cooldown,SKILLS.fist_wind.knockback,SKILLS.fist_wind.vertical],[20,260,6.4,1.8]);
  assert.deepEqual([SKILLS.sage_meteor.damage,SKILLS.sage_meteor.mana],[58,700]);assert.equal(SKILLS.revenant_execution.radius,4);
});
test('wind uses magic scaling, doubled knockback and preserves strong-punch charges',()=>{
  const {p,mob}=scene('fist_bone'),enemy=mob();p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:205,vit:5,int:5,mag:105}));giveDoubleBuff(p,3,600);
  FIST.fist_wind(p,JOBS.fist_bone,SKILLS.fist_wind);assert.equal(enemy.damage.length,1);assert.ok(Math.abs(enemy.damage[0].n-34)<1e-9);assert.equal(doubleLeft(p),3);
  assert.deepEqual(enemy.knocks[0],[{x:0,z:6.4},1.8]);
});
test('stance applies one-second self slow and keeps fifteen-second buffs',()=>{
  const {p}=scene('fist_bone');FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);assert.equal(p.effects.get('slowness').duration,20);assert.equal(p.effects.get('strength').duration,300);assert.equal(p.effects.get('resistance').amplifier,1);
});
test('end slows nearby enemies during charge before sixty damage detonates',()=>{
  const {p,mob}=scene('fallen_angel'),near=mob(),far=mob(0,26);const start=intervals.length;HOLY.fallen_end(p,JOBS.fallen_angel,SKILLS.fallen_end);const tick=intervals[start];tick();tick();
  assert.equal(near.effects.get('slowness').amplifier,0);assert.equal(near.damage.length,0);assert.equal(far.effects.has('slowness'),false);
  for(let i=2;i<40;i++)tick();assert.equal(near.damage[0].n,60);assert.equal(far.damage.length,0);
});
test('shotgun resolves eleven pellets at five damage as one fifty-five damage hit',()=>{
  const {p,mob,dim}=scene('blood_mage'),target=mob();dim.getEntities=()=>[target];
  BLOOD.blood_supernova(p,JOBS.blood_mage,SKILLS.blood_supernova);assert.equal(target.damage.length,1);assert.equal(target.damage[0].n,55);
});
test('shotgun cannot shoot through a solid wall or exceed 55 across targets',()=>{
  const {p,mob,dim}=scene('blood_mage'),target=mob();dim.getEntities=()=>[target];dim.getBlock=()=>({isSolid:true});BLOOD.blood_supernova(p,JOBS.blood_mage,SKILLS.blood_supernova);assert.equal(target.damage.length,0);
  dim.getBlock=()=>({isSolid:false});const other=mob(2);let query=0;dim.getEntities=()=>[++query%2?target:other];BLOOD.blood_supernova(p,JOBS.blood_mage,SKILLS.blood_supernova);
  assert.equal([...target.damage,...other.damage].reduce((n,h)=>n+h.n,0),55);
});
test('execution affects threshold enemies only within four blocks including edge, not square corners or far targets',()=>{
  const {p,mob}=scene('revenant'),near=mob(0,3,200),edge=mob(4,0,250),corner=mob(3,3,200),far=mob(0,1000,200),healthy=mob(0,2,300);
  const r=HARPOON.revenant_execution(p,JOBS.revenant,SKILLS.revenant_execution);assert.equal(r.cooldown,100);assert.equal(near.killed,true);assert.equal(edge.killed,true);
  for(const e of [corner,far,healthy])assert.equal(e.killed,undefined);
});
test('execution failure attack cannot select an enemy outside four blocks',()=>{
  const {p,mob}=scene('revenant'),near=mob(0,3),far=mob(0,6);
  HARPOON.revenant_execution(p,JOBS.revenant,SKILLS.revenant_execution);assert.equal(near.damage[0].n,50);assert.equal(far.damage.length,0);
});
test('heavenly bow prioritizes physical arrows and refunds on spawn failure',()=>{
  const {p,dim,spawned}=scene();p.slots[2]=new ItemStack('minecraft:arrow',2);setMana(p,100);assert.equal(shootHeavenlyInstant(p),true);assert.equal(p.slots[2].amount,1);assert.equal(getMana(p),100);assert.equal(spawned[0].typeId,'minecraft:arrow');
  dim.spawnEntity=()=>{throw Error('spawn failed');};assert.equal(shootHeavenlyInstant(p),false);assert.equal(p.slots[2].amount,1);assert.equal(getMana(p),100);
});
test('empty bow creates a non-pickup mana projectile for exactly 20 MP, unaffected by INT',()=>{
  const {p,spawned}=scene();p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:5,vit:5,int:50,mag:5}));setMana(p,40);
  assert.equal(heavenlyAmmoCost(p),20);assert.equal(shootHeavenlyInstant(p),true);assert.equal(shootHeavenlyInstant(p),true);assert.equal(getMana(p),0);assert.ok(spawned.every(e=>e.typeId===MANA_ARROW_ID));assert.equal(shootHeavenlyInstant(p),false);
});
test('mana arrow spawn/save failures refund mana and creative bypasses cost',()=>{
  const {p,dim,spawned}=scene();setMana(p,100);const spawn=dim.spawnEntity;dim.spawnEntity=()=>{throw Error('spawn');};assert.equal(shootHeavenlyInstant(p),false);assert.equal(getMana(p),100);
  dim.spawnEntity=spawn;const save=p.setDynamicProperty.bind(p);let fail=true;p.setDynamicProperty=(k,v)=>{if(k==='rpg:mana'&&fail){fail=false;throw Error('save');}save(k,v);};assert.equal(shootHeavenlyInstant(p),false);assert.equal(getMana(p),100);assert.equal(spawned.at(-1).isValid,false);
  p.getGameMode=()=> 'creative';assert.equal(shootHeavenlyInstant(p),true);assert.equal(getMana(p),100);assert.equal(spawned.at(-1).typeId,'minecraft:arrow');
});
test('mana-arrow passive belongs only to heavenly archer; rapid extras each cost twenty',()=>{
  const {p,spawned}=scene();setMana(p,200);ARCHER.archer_rapid(p,JOBS.heavenly_archer,SKILLS.archer_rapid);assert.equal(spawned.length,4);assert.equal(getMana(p),120);assert.equal(shootHeavenlyInstant(p),true);assert.equal(getMana(p),100);
  p.setDynamicProperty('rpg:job','chameleon');assert.equal(shootHeavenlyInstant(p),false);assert.equal(getMana(p),100);
});
test('actual heavenly input budgets five mana arrows plus skill, falls back to basic shot with low mana',()=>{
  registerInput();const {p,spawned}=scene();p.equipment.set(EquipmentSlot.Mainhand,new ItemStack(JOBS.heavenly_archer.weapon));setIndex(p,getContext(p).skills.indexOf('archer_rapid'));setMana(p,135);system.currentTick+=20;
  for(const fn of events.itemUse.listeners)fn({source:p,itemStack:new ItemStack(JOBS.heavenly_archer.weapon)});
  assert.equal(spawned.length,5);assert.equal(getMana(p),0);assert.ok(cooldownLeft(p,'archer_rapid')>0);
  resetCooldowns(p);setMana(p,120);system.currentTick+=20;for(const fn of events.itemUse.listeners)fn({source:p,itemStack:new ItemStack(JOBS.heavenly_archer.weapon)});
  assert.equal(spawned.length,6);assert.equal(getMana(p),100);assert.equal(cooldownLeft(p,'archer_rapid'),0);
});
test('mana projectile hits once then disappears, with no inventory arrow granted',()=>{
  registerArcher();const tick=intervals.at(-1),{p,mob,spawned}=scene(),enemy=mob(0,2);setMana(p,20);assert.equal(shootHeavenlyInstant(p),true);tick();
  assert.equal(enemy.damage.length,1);assert.equal(enemy.damage[0].n,6);assert.equal(spawned[0].isValid,false);assert.equal(p.slots.filter(Boolean).length,0);
});
test('Chameleon stealth plus mark multiplies a qualifying received skill hit by 3.9',()=>{
  registerAssassin();const {p,mob}=scene('chameleon'),enemy=mob(0,4);for(const id of ['assassin_stealth','assassin_mark'])assert.equal(purchaseChameleonSkill(p,id).ok,true);
  assert.equal(ASSASSIN.assassin_mark(p,JOBS.shadow_assassin,SKILLS.assassin_mark),true);assert.equal(ASSASSIN.assassin_stealth(p,JOBS.shadow_assassin,SKILLS.assassin_stealth),true);
  enemy.health-=52;for(const fn of events.entityHurt.listeners)fn({hurtEntity:enemy,damage:52,damageSource:{damagingEntity:p,cause:'entityAttack'}});
  assert.ok(Math.abs(1000-enemy.health-202.8)<1e-9);
});
test('reboot leaves Chameleon charges spent while resetting selected existing cooldowns',()=>{
  const {p}=scene('chameleon');purchaseChameleonSkill(p,'hacker_reboot');players.push(p);startCooldown(p,'sword_annihilation',500);startCooldown(p,'sun_descent',500);
  executeChameleonSkill(p,'hacker_reboot',()=>HACKER.hacker_reboot(p,JOBS.hacker,SKILLS.hacker_reboot));assert.equal(cooldownLeft(p,'sword_annihilation'),0);assert.equal(cooldownLeft(p,'sun_descent'),0);assert.equal(remainingSkillUses(p,'hacker_reboot'),9);
});
