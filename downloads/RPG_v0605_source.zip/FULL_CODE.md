# RPG v0.6.5 변경 파일 전체 코드

## RPG_BP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon BP v0.6.0",
    "description": "RPG v0.6.5 · 룬·갑옷·무기 강화 분리 · 룬 종류별 강화",
    "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
    "version": [
      0,
      6,
      5
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "data",
      "uuid": "cc5d6e3c-5285-4787-8a59-a8e2856f2aec",
      "version": [
        0,
        6,
        5
      ]
    },
    {
      "type": "script",
      "language": "javascript",
      "uuid": "c41fa3d6-d82c-4a54-9783-68f92fe633a1",
      "entry": "scripts/gameplayEntry.js",
      "version": [
        0,
        6,
        5
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
      "version": [
        0,
        6,
        5
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    },
    {
      "module_name": "@minecraft/server-ui",
      "version": "2.0.0"
    }
  ]
}

```

## RPG_BP_v0603/scripts/core/equipment.js

```js
import {itemGrade,ARMOR_GRADE_HP} from '../data/grades.js';
import {rarityBadge,armorRarity} from '../data/rarity.js';
import { world, system, EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { ARMOR_SETS, RUNES, RUNE_KEY, armorInfo } from '../data/equipment.js';
import { showForm } from './skillMenu.js';
import { RUNE_LEVEL_KEY, upgradeLevel, upgradedRune } from '../data/upgrades.js';
import { openUpgradeMenu } from './upgrades.js';
import { openCraftingGuide } from './crafting.js';
import { equippedRunes, migrateChestRune, migrateRetiredRunes } from './runeInventory.js';
import { openRuneMenu } from './runeMenu.js';

const neutral = () => ({physical:1, magic:1, health:0, defense:0, manaRegen:0, manaRegenPercent:0, ward:false, speed:false, lifesteal:0, wardAmplifier:0, speedAmplifier:0, auras:{}});
export function getEquipmentBonuses(player) {
  const result = neutral();
  try {
    const eq = player.getComponent('minecraft:equippable');
    if (!eq) return result;
    const items = [EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet].map(slot=>eq.getEquipment(slot));
    const parts = ['helmet','chestplate','leggings','boots'];
    for (let i=0;i<items.length;i++) if (armorInfo(items[i]?.typeId)?.part === parts[i]) result.health += upgradeLevel(items[i],'armor')+ARMOR_GRADE_HP[itemGrade(items[i])];
    for (const [set, data] of Object.entries(ARMOR_SETS)) {
      if (!items.every((item,i)=>item?.typeId===`rpg:${set}_${parts[i]}`)) continue;
      result.ward ||= data.ward===true;
      result.physical *= data.physical ?? 1;
      result.magic *= data.magic ?? 1;
      result.health += data.health ?? 0;
      result.manaRegen += data.manaRegen ?? 0;
    }
    for(const stored of equippedRunes(player)) {
      const rune=upgradedRune(RUNES[stored.id],stored.level,stored.grade);
      result.physical*=rune.physical??1;result.magic*=rune.magic??1;
      result.health+=rune.health??0;result.defense+=rune.defense??0;result.manaRegen+=rune.manaRegen??0;result.manaRegenPercent+=rune.manaRegenPercent??0;
      result.lifesteal=Math.max(result.lifesteal,rune.lifesteal??0);
      result.ward ||= rune.ward===true;result.speed ||= rune.speed===true;
      result.wardAmplifier=Math.max(result.wardAmplifier,rune.wardAmplifier??0);
      result.speedAmplifier=Math.max(result.speedAmplifier,rune.speedAmplifier??0);
      for(const [eid,amp] of Object.entries(rune.auras??{}))result.auras[eid]=Math.max(result.auras[eid]??-1,amp);
    }
  } catch { return neutral(); }
  return result;
}

export async function openEquipmentMenu(player) {
  try {
    const form=new ActionFormData().title('RPG 장비').body('룬은 전용 보관함에서 최대 3개를 장착합니다. 같은 종류는 하나만 장착할 수 있습니다.\n'+Object.entries(ARMOR_SETS).map(([id,s])=>rarityBadge(armorRarity(id))+' '+s.name+': '+s.description).join('\n'))
      .button('룬 보관함 · 장착').button('강화 메뉴 · 룬 / 갑옷 / 무기').button('획득·제작 도감').button('닫기');
    const res=await showForm(form,player);if(!res||res.canceled)return;
    if(res.selection===0)await openRuneMenu(player);
    else if(res.selection===1)await openUpgradeMenu(player);
    else if(res.selection===2)await openCraftingGuide(player);
  }catch(error){try{player.sendMessage('§c[RPG] '+String(error));}catch{}}
}

function refreshAura(player, id, amplifier=0) {
  const effect = player.getEffect(id);
  if (!effect || effect.amplifier < amplifier || (effect.amplifier === amplifier && effect.duration < 60)) player.addEffect(id,60,{amplifier,showParticles:false});
}
export function registerEquipment() {
  system.runInterval(()=>{
    for (const player of world.getAllPlayers()) {
      try {
        migrateRetiredRunes(player);
        migrateChestRune(player);
        const bonuses = getEquipmentBonuses(player);
        if (bonuses.ward) refreshAura(player,'resistance',bonuses.wardAmplifier);
        if (bonuses.speed) refreshAura(player,'speed',bonuses.speedAmplifier);
        for (const [eid,amp] of Object.entries(bonuses.auras??{})) refreshAura(player,eid,amp);
      } catch {}
    }
  },20);

}

```

## RPG_BP_v0603/scripts/core/runeMenu.js

```js
import {runeRarity,rarityBadge} from '../data/rarity.js';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { RUNES } from '../data/equipment.js';
import { readRuneBag,depositRune,equipRune,unequipRune,withdrawRune,removeRune,migrateChestRune,migrateRetiredRunes,RUNE_CAPACITY } from './runeInventory.js';
import { describeRune,openRuneUpgradeMenu } from './upgrades.js';
import { showForm } from './skillMenu.js';
const open=new Set();
export async function openRuneMenu(p){
  if(open.has(p.id))return;open.add(p.id);
  try{
    migrateRetiredRunes(p);
    const migration=migrateChestRune(p);if(!migration.ok)p.sendMessage('§e'+migration.reason);
    for(let loop=0;loop<80&&p.isValid;loop++){
      const bag=readRuneBag(p);
      const slots=bag.equipped.map((uid,i)=>{const r=bag.runes.find(r=>r.uid===uid);return `${i+1}번: ${r?rarityBadge(runeRarity(r.grade))+' '+RUNES[r.id].name+' +'+r.level:'비어 있음'}`;}).join('\n');
      const form=new ActionFormData().title('룬 전용 보관함').body(`${bag.runes.length}/${RUNE_CAPACITY}칸\n${slots}\n\n3개 장착·같은 종류 중복 불가. 갑옷과 독립적으로 효과를 받습니다.\n강화한 룬은 보관함에서 관리하며 일반 등급 +0 룬만 일반 가방으로 꺼낼 수 있습니다.`);
      form.button('일반 가방의 룬 넣기');form.button('룬 강화');
      for(const r of bag.runes)form.button(`${bag.equipped.includes(r.uid)?'§a[장착] ':''}${RUNES[r.id].name} +${r.level}\n${describeRune(r.id,r.level,r.grade)}`);
      form.button('닫기');const choice=await showForm(form,p);
      if(!choice||choice.canceled||choice.selection==null||choice.selection>=bag.runes.length+2)return;
      if(choice.selection===0){
        const inv=p.getComponent('minecraft:inventory')?.container,entries=[];
        const f=new ActionFormData().title('룬 넣기').body('한 번 선택하면 룬 1개를 보관합니다.');
        if(inv)for(let i=0;i<inv.size;i++){const t=inv.getItem(i),id=t?.typeId?.replace('rpg:rune_','');if(t?.typeId==='rpg:rune_'+id&&RUNES[id]){entries.push(i);f.button(RUNES[id].name+' ×'+t.amount);}}
        f.button('뒤로');const r=await showForm(f,p);if(r&&!r.canceled&&r.selection<entries.length){const result=depositRune(p,entries[r.selection]);if(!result.ok)p.sendMessage('§c'+result.reason);}continue;
      }
      if(choice.selection===1){await openRuneUpgradeMenu(p);continue;}
      const rune=bag.runes[choice.selection-2];
      const f=new ActionFormData().title(RUNES[rune.id].name+' +'+rune.level).body(describeRune(rune.id,rune.level,rune.grade));
      f.button('1번 칸 장착').button('2번 칸 장착').button('3번 칸 장착').button('장착 해제').button('일반 가방으로 꺼내기 (일반 +0)').button('룬 삭제').button('뒤로');
      const r=await showForm(f,p);if(!r||r.canceled)continue;
      if(r.selection<3){const result=equipRune(p,rune.uid,r.selection);if(!result.ok)p.sendMessage('§c'+result.reason);}
      else if(r.selection===3)unequipRune(p,rune.uid);
      else if(r.selection===4){const result=withdrawRune(p,rune.uid);if(!result.ok)p.sendMessage('§c'+result.reason);}
      else if(r.selection===5){const yes=await showForm(new MessageFormData().title('룬 삭제').body('이 룬과 강화 단계가 영구 삭제됩니다.').button1('취소').button2('삭제'),p);if(yes&&!yes.canceled&&yes.selection===1)removeRune(p,rune.uid);}
    }
  }catch(error){try{p.sendMessage('§c[RPG] '+String(error));}catch{}}
  finally{open.delete(p.id);}
}

```

## RPG_BP_v0603/scripts/core/statusTablet.js

```js
import {world,system,ItemStack} from '@minecraft/server';
import {ActionFormData} from '@minecraft/server-ui';
import {getJobId,getMana,maxManaOf} from './playerData.js';
import {getLevel,getXp,xpForNext,getStats,LEVEL_MAX} from './stats.js';
import {JOBS} from '../data/jobs.js';
import {showForm} from './skillMenu.js';

export const STATUS_TABLET='rpg:status_tablet';
export const STATUS_TITLE='§bSTATUS §8| §f상태창';
const GIVEN='rpg:status_tablet_given_v1';
const open=new Map(),lastUse=new Map();
const OPEN_STUCK_TICKS=600; // 열림 상태가 30초 넘게 남아 있으면 고장으로 보고 초기화
let actionHandler,registered=false;
export const STATUS_ACTIONS=Object.freeze([
 {action:'dungeon',text:'§b던전 입장\n§8던전 목록'},
 {action:'party',text:'§b파티\n§8생성 · 초대'},
 {action:'runes',text:'§b룬 장착\n§8보관 · 관리'},
 {action:'skillguide',text:'§b스킬 효과\n§8효과 · MP · 쿨'},
 {action:'craft',text:'§b아이템 조합법\n§8재료 · 배치'},
 {action:'guild',text:'§b길드 확인\n§8생성 · 멤버'},
 {action:'stats',text:'§b스탯 배분\n§8능력치 · SP'},
 {action:'equipment',text:'§b장비 정보\n§8갑옷 · 효과'},
 {action:'upgrade',text:'§b강화 메뉴\n§8룬 · 갑옷 · 무기'},
 {action:'jobs',text:'§b전직 안내\n§8직업 · 조건'},
 {action:'pvp',text:'§bPvP 결투\n§8플레이어 선택'},
 {action:'wallet',text:'§b지갑 · XP 상점\n§8포션 · 촉매 구매'},
 {action:'invites',text:'§b받은 초대\n§8파티 · 길드'},
 {action:'transfer',text:'§b강화 이전\n§8추출 · 적용'},
 {action:'tpa',text:'§b이동 요청 TPA\n§8이동 시 1,000골드'},
 {action:'tpaaccept',text:'§b받은 이동 요청\n§8수락 · 거절'},
 {action:'refresh',text:'§a새로고침\n§8내 정보 갱신'},
 {action:'close',text:'§7닫기\n§8모험으로 돌아가기'}
]);
export function resourceBar(value,max,color='§b'){
 const ratio=Number.isFinite(value)&&Number.isFinite(max)&&max>0?Math.max(0,Math.min(1,value/max)):0;
 const n=Math.round(ratio*10);return color+'■'.repeat(n)+'§8'+'■'.repeat(10-n)+'§r';
}
const number=n=>String(Math.round(Number.isFinite(n)?n:0));
export function statusBody(p){
 const h=p.getComponent('minecraft:health'),mp=getMana(p),maxMp=maxManaOf(p);
 const level=getLevel(p),xp=getXp(p),next=xpForNext(level),s=getStats(p),capped=level>=LEVEL_MAX;
 const name=String(p.name).replace(/§./g,'').slice(0,22);
 return `§f${name}\n§b${JOBS[getJobId(p)]?.name??'견습'} §fLv.${level}\n\n`+
  `§fHP ${number(h?.currentValue??0)} / ${number(h?.effectiveMax??20)}\n${resourceBar(h?.currentValue??0,h?.effectiveMax??20)}\n`+
  `§fMP ${number(mp)} / ${number(maxMp)}\n${resourceBar(mp,maxMp)}\n`+
  `§fEXP ${capped?'MAX':number(xp)+' / '+number(next)}\n${resourceBar(capped?1:xp,capped?1:next,'§d')}\n\n`+
  `§7근력 §f${s.str}  §7마력 §f${s.mag}\n§7체력 §f${s.vit}  §7지능 §f${s.int}`;
}
export async function openStatusTablet(p){
 if(!p?.isValid)return;
 if(open.has(p.id)){if(system.currentTick-open.get(p.id)<OPEN_STUCK_TICKS)return;open.delete(p.id);}
 open.set(p.id,system.currentTick);
 let next;
 try{
  while(p.isValid){
   const form=new ActionFormData().title(STATUS_TITLE).body(statusBody(p));
   for(const entry of STATUS_ACTIONS)form.button(entry.text);
   const res=await showForm(form,p);
   if(!res||res.canceled||!Number.isInteger(res.selection)||res.selection<0||res.selection>=STATUS_ACTIONS.length)return;
   const selected=STATUS_ACTIONS[res.selection].action;
   if(selected==='refresh')continue;
   if(selected!=='close')next=selected;
   break;
  }
 }catch(error){try{p.sendMessage('§c[상태창] '+String(error.message??error));}catch{}}
 finally{open.delete(p.id);}
 // Defer the next form so Bedrock can close this form first.
 if(next&&!actionHandler){try{p.sendMessage('§c[상태창] 아직 준비되지 않았습니다. 잠시 후 다시 시도하세요.');}catch{}return;}
 if(next&&p.isValid)system.run(()=>{try{const result=actionHandler(next,p);Promise.resolve(result).catch(error=>{try{p.sendMessage('§c[상태창] '+String(error));}catch{}});}catch(error){try{p.sendMessage('§c[상태창] '+String(error));}catch{}}});
}
export function giveStatusTablet(p){
 if(!p?.isValid)return;
 const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return;
 for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId===STATUS_TABLET){p.setDynamicProperty(GIVEN,true);return;}
 const first=!p.getDynamicProperty(GIVEN),item=new ItemStack(STATUS_TABLET,1);try{item.keepOnDeath=true;}catch{}
 const remainder=inv.addItem(item);
 if(remainder){p.sendMessage('§e[상태창] 인벤토리를 비운 후 재접속하면 지급됩니다. /rpg:menu로도 열 수 있습니다.');return;}
 p.setDynamicProperty(GIVEN,true);
 p.sendMessage(first?'§b[상태창] 상태창 아이템을 지급했습니다. 손에 들고 사용해 모험 메뉴를 여세요.':'§b[상태창] 상태창을 다시 지급했습니다. (/rpg:menu 로도 열 수 있습니다)');
}
function useTablet(p){
 if(!p?.isValid||(lastUse.get(p.id)??-100)>system.currentTick-5)return;
 lastUse.set(p.id,system.currentTick);system.runTimeout(()=>{try{openStatusTablet(p);}catch(error){try{p.sendMessage('§c[상태창] '+String(error));}catch{}}},2);
}
// Register the component in startup, before item definitions are used.
system.beforeEvents.startup.subscribe(event=>{
 try{event.itemComponentRegistry.registerCustomComponent('rpg:status_tablet',{onUse(e){useTablet(e.source);}});}
 catch(error){console.warn('[RPG status tablet component] '+error);}
});
export function registerStatusTablet(handler){
 actionHandler=handler;if(registered)return;registered=true;
 world.afterEvents.itemUse.subscribe(e=>{if(e.itemStack?.typeId===STATUS_TABLET)useTablet(e.source);});
 world.afterEvents.playerSpawn.subscribe(e=>system.runTimeout(()=>{try{giveStatusTablet(e.player);}catch(error){console.warn('[RPG status tablet grant] '+error);}},40));
 world.afterEvents.playerLeave.subscribe(e=>{open.delete(e.playerId);lastUse.delete(e.playerId);});
 system.runTimeout(()=>{for(const p of world.getAllPlayers())try{giveStatusTablet(p);}catch(error){console.warn('[RPG status tablet grant] '+error);}},40);
}

```

## RPG_BP_v0603/scripts/core/upgrades.js

```js
import {itemGrade} from '../data/grades.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {classWeapon} from '../data/classWeapons.js';
import {gearFingerprint,setGearLevel} from './gearState.js';
import {openFusionMenu} from './fusion.js';
import {runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {decorateRarity} from './rarityLabels.js';
import {openArmorTransfer} from './armorTransfer.js';
import { EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { armorInfo, RUNES, RUNE_KEY } from '../data/equipment.js';
import { ARMOR_LEVEL_KEY, RUNE_LEVEL_KEY, upgradeLevel, upgradeCost, upgradedRune, enhancementRates, rollEnhancement, catalystAllowed, CATALYST_ID, MAX_CATALYSTS } from '../data/upgrades.js';
import { getWallet, setWallet, canAfford, walletText } from './wallet.js';
import { showForm } from './skillMenu.js';
import { readRuneBag, writeRuneBag, migrateChestRune } from './runeInventory.js';

const SLOTS = () => [
  {slot:EquipmentSlot.Head, part:'helmet', name:'투구'},
  {slot:EquipmentSlot.Chest, part:'chestplate', name:'흉갑'},
  {slot:EquipmentSlot.Legs, part:'leggings', name:'각반'},
  {slot:EquipmentSlot.Feet, part:'boots', name:'장화'},
];
export function describeRune(id, rank, grade=0) {
  const r = upgradedRune(RUNES[id],rank,grade);
  if (!r) return '없음';
  const values = [];
  if (r.physical && r.physical>1) values.push(`물리 스킬 +${Number(((r.physical-1)*100).toFixed(1))}%`);
  if (r.magic && r.magic>1) values.push(`마법 스킬 +${Number(((r.magic-1)*100).toFixed(1))}%`);
  if(rank>0&&['power','arcane'].includes(id))values.push('공용·직업 무기 근접 평타 +'+Number((((r.physical??r.magic)-1)*100).toFixed(1))+'%');
  if (r.defense) values.push('RPG 방어력 +'+Number(r.defense.toFixed(1))+' (피해 감소 '+Number((r.defense*.35).toFixed(2))+'%)');
  if (r.health) values.push(`최대 HP +${Number(r.health.toFixed(2))}`);
  if (r.manaRegenPercent) values.push(`초당 최대 마나의 +${Number((r.manaRegenPercent*100).toFixed(1))}% 회복`);
  if (r.lifesteal) values.push('준 피해의 '+Number((r.lifesteal*100).toFixed(1))+'% 흡혈');
  if (r.ward) values.push('저항 '+(r.wardAmplifier+1));
  if (r.speed) values.push('신속 '+(r.speedAmplifier+1));
  for (const t of r.extraText??[]) values.push(t);
  return rarityBadge(runeRarity(grade))+' · '+values.join(', ');
}

function fingerprint(item) {return gearFingerprint(item);}
export function enhancementQuote(player,kind,slot) {
  if(kind==='rune') {
    const rune=readRuneBag(player).runes.find(r=>r.uid===slot);if(!rune)return undefined;
    return {kind,slot,level:rune.level,runeId:rune.id,fingerprint:JSON.stringify(rune),cost:upgradeCost(kind,rune.level),name:RUNES[rune.id].name,
      effect:describeRune(rune.id,rune.level,rune.grade)+'\n→ '+describeRune(rune.id,rune.level+1,rune.grade)};
  }
  if(kind==='weapon'){
    if(slot!==EquipmentSlot.Mainhand)return undefined;
    const item=player.getComponent('minecraft:equippable')?.getEquipment(slot),jobWeapon=classWeapon(item?.typeId),w=COMMON_WEAPONS.find(w=>w.id===item?.typeId)??jobWeapon;
    if(!w||item.amount!==1)return undefined;const level=upgradeLevel(item,kind);
    return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:w.name,effect:jobWeapon?`직업 무기 · 등급·승급 없음\n근접 피해 +${level} → +${level+1}\n물리·마법 스킬 피해 +${level*2}% → +${(level+1)*2}%`:`${rarityBadge(itemGrade(item))} 등급 유지 · 강화 근접 피해 +${level} → +${level+1}`};
  }
  if(kind!=='armor')return undefined;
  const definition=SLOTS().find(s=>s.slot===slot),item=player.getComponent('minecraft:equippable')?.getEquipment(slot);
  const info=armorInfo(item?.typeId);if(!definition||info?.part!==definition.part)return undefined;
  const level=upgradeLevel(item,'armor');return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:info.name+' '+definition.name,effect:`${rarityBadge(itemGrade(item))} 등급 유지\n부위 강화 HP +${level} → +${level+1}`};
}

export function enhanceEquipped(player,kind,slot,expectedFingerprint,options={}) {
  try {
    const quote=enhancementQuote(player,kind,slot);
    if (!quote) return {ok:false,reason:'강화할 RPG 갑옷·공용·직업 무기·보관 룬이 없습니다.'};
    if (!quote.cost) return {ok:false,reason:'이미 최대 강화 단계입니다.'};
    if (expectedFingerprint!==undefined&&quote.fingerprint!==expectedFingerprint) return {ok:false,reason:'장비 또는 강화 단계가 변경됐습니다. 다시 선택하세요.'};
    const catalystCount=options.catalystCount??0;
    const rates=enhancementRates(kind,quote.level,catalystCount);
    if (!rates) return {ok:false,reason:'촉매 수량은 0~5개이며, 갑옷·무기 +5·룬 +2부터 사용할 수 있습니다.'};
    const wallet=getWallet(player);
    if (!canAfford(wallet,quote.cost)) return {ok:false,reason:'강화에 필요한 재화가 부족합니다.'};
    const eq=player.getComponent('minecraft:equippable');
    const inventory=player.getComponent('minecraft:inventory')?.container;
    const catalysts=[];
    let needed=catalystCount;
    if(needed>0&&inventory)for(let i=0;i<inventory.size&&needed>0;i++) {
      const token=inventory.getItem(i);
      if(token?.typeId!==CATALYST_ID||token.amount<1)continue;
      const take=Math.min(needed,token.amount);
      catalysts.push({slot:i,original:token.clone(),take});needed-=take;
    }
    if(needed>0)return {ok:false,reason:`강화 촉매 ${catalystCount}개가 필요합니다.`};
    const original=kind!=='rune'?eq.getEquipment(slot).clone():readRuneBag(player);
    const outcome=rollEnhancement(rates,options.random??Math.random);
    let level=quote.level,target;
    if(outcome==='success')level++;
    if(outcome==='downgrade')level=Math.max(0,level-1);
    if(kind!=='rune') {
      target=original.clone();
      if(outcome==='destroy'){target=undefined;level=0;}
      else target=setGearLevel(target,kind,level);
    }else{
      target=JSON.parse(JSON.stringify(original));
      if(outcome==='destroy'){level=0;target.runes=target.runes.filter(r=>r.uid!==slot);target.equipped=target.equipped.map(uid=>uid===slot?null:uid);}
      else target.runes.find(r=>r.uid===slot).level=level;
    }
    const next=Object.fromEntries(Object.entries(wallet).map(([k,v])=>[k,v-quote.cost[k]]));
    let debited=false,catalystTouched=false;
    try {
      setWallet(player,next);debited=true;
      if(catalysts.length) {
        catalystTouched=true;
        for(const entry of catalysts) {
          if(entry.original.amount===entry.take)inventory.setItem(entry.slot,undefined);
          else {const remaining=entry.original.clone();remaining.amount-=entry.take;inventory.setItem(entry.slot,remaining);}
        }
      }
      if(kind!=='rune'){if(!eq.setEquipment(slot,target))throw Error('장비 저장 실패');}else writeRuneBag(player,target);
    } catch(error) {
      let recovered=true;
      try {if(kind!=='rune'){if(!eq.setEquipment(slot,original))recovered=false;}else writeRuneBag(player,original);}catch{recovered=false;}
      if(catalystTouched)for(const entry of catalysts)try{inventory.setItem(entry.slot,entry.original);}catch{recovered=false;}
      if(debited)try{setWallet(player,wallet);}catch{recovered=false;}
      if(!recovered)console.error('[RPG upgrade] rollback incomplete: '+String(error));
      return {ok:false,reason:recovered?'강화를 저장하지 못해 취소하고 재화를 복구했습니다.':'강화 복구에 실패했습니다. 관리자에게 콘텐츠 로그 확인을 요청하세요.'};
    }
    return {ok:true,outcome,level,cost:quote.cost,rates,catalystCount};
  }catch(error){return {ok:false,reason:'강화 오류: '+String(error)};}
}

const menus = new Set();
const KIND_NAMES = {rune:'룬',armor:'갑옷',weapon:'무기'};
function costText(cost) {
  if(!cost)return '§a최대 강화 +10';
  return `골드 ${cost.gold.toLocaleString()}`+(cost.stone?` · 강화석 ${cost.stone}`:'')+(cost.dust?` · 룬 가루 ${cost.dust}`:'');
}
function quoteButton(quote) {
  return `${quote.name} +${quote.level}\n${costText(quote.cost)}`;
}
async function attemptUpgrade(player,quote) {
  if (!quote.cost) {player.sendMessage('§e[RPG] 이미 최대 강화 단계입니다.');return;}
  let catalystCount=0;
  if(catalystAllowed(quote.kind,quote.level)) {
    const inventory=player.getComponent('minecraft:inventory')?.container;
    let owned=0;
    if(inventory)for(let i=0;i<inventory.size;i++){const token=inventory.getItem(i);if(token?.typeId===CATALYST_ID)owned+=token.amount;}
    const maximum=Math.min(MAX_CATALYSTS,owned);
    const form=new ActionFormData().title('강화 촉매 수량')
      .body(`보유 촉매 ${owned}개. 한 번에 최대 5개 사용.\n1개당 성공률 +9%p, 파괴확률 -3%p (최소 0%).\n완료된 모든 결과에서 선택 수량을 소비합니다.`);
    for(let count=0;count<=maximum;count++) {
      const preview=enhancementRates(quote.kind,quote.level,count);
      form.button(`${count===0?'촉매 사용 안 함':count+'개 사용'}\n성공 ${preview.success}% / 파괴 ${preview.destroy}%`);
    }
    form.button('취소');
    const choice=await showForm(form,player);
    if(!choice||choice.canceled||choice.selection==null||choice.selection>maximum)return;
    catalystCount=choice.selection;
  }
  const rates=enhancementRates(quote.kind,quote.level,catalystCount);
  const percentages=`성공 ${rates.success}% / 유지 실패 ${rates.fail}%\n1단계 강등 ${rates.downgrade}% / 파괴 ${rates.destroy}%`;
  const destruction=quote.kind!=='rune'?'장비 파괴 시 해당 장비만 소멸하고 전용 보관함 룬은 유지됩니다.':'룬 파괴 시 해당 보관 룬만 소멸하며 장착도 해제됩니다.';
  const confirm=await showForm(new MessageFormData().title('위험 강화 확인')
    .body(`${quote.name} +${quote.level} → +${quote.level+1}\n${quote.effect}\n\n${percentages}\n${destruction}\n\n비용: ${costText(quote.cost)}\n${catalystCount?'강화 촉매 '+catalystCount+'개 사용\n':''}모든 결과에서 비용이 소비됩니다.`)
    .button1('취소').button2('강화'),player);
  if(!confirm||confirm.canceled||confirm.selection!==1)return;
  const attempt=enhanceEquipped(player,quote.kind,quote.slot,quote.fingerprint,{catalystCount});
  if(!attempt.ok)player.sendMessage('§c[RPG] '+attempt.reason);
  else {
    const messages={success:`§a강화 성공! +${attempt.level}`,fail:'§e강화 실패: 단계 유지',downgrade:`§6강등: +${attempt.level}`,destroy:quote.kind!=='rune'?'§c장비 파괴: 해당 장비 소멸':'§c룬 파괴: 해당 보관 룬 소멸'};
    player.sendMessage('[RPG] '+quote.name+' · '+messages[attempt.outcome]);
  }
}

export async function openUpgradeMenu(player) {await upgradeSession(player,'root');}
export async function openRuneUpgradeMenu(player) {await upgradeSession(player,'runeTypes');}
export async function openArmorUpgradeMenu(player) {await upgradeSession(player,'armor');}
export async function openWeaponUpgradeMenu(player) {await upgradeSession(player,'weapon');}

async function upgradeSession(player,initialPage) {
  if(menus.has(player.id))return;
  menus.add(player.id);
  try {
    const migration=migrateChestRune(player);if(!migration.ok)player.sendMessage('§e'+migration.reason);
    let page=initialPage,runeId;
    for(let count=0;count<160&&player.isValid;count++) {
      const form=new ActionFormData();
      let options=[];
      const wallet=walletText(getWallet(player));
      if(page==='root') {
        form.title('RPG 강화 메뉴').body(wallet+'\n\n강화할 종류를 선택하세요.\n룬·갑옷·무기는 각각의 화면에서 관리합니다.');
        form.button('§d룬 강화\n종류 선택 · 보관 룬 강화')
          .button('§b갑옷 강화\n착용 부위별 강화 · 강화 이전')
          .button('§6무기 강화\n손에 든 공용·직업 무기 강화')
          .button('장비 등급 합성').button('닫기');
      } else if(page==='runeTypes') {
        const bag=readRuneBag(player);
        options=Object.entries(RUNES);
        form.title('룬 강화 · 종류 선택').body(wallet+'\n\n강화할 룬 종류를 고르세요.\n장착하지 않은 보관 룬도 강화할 수 있습니다.\n일반 가방의 룬은 룬 보관함에 넣어 주세요.');
        for(const [id,definition] of options) {
          const runes=bag.runes.filter(r=>r.id===id);
          form.button(`${definition.name}\n보유 ${runes.length}개 · 강화 가능 ${runes.filter(r=>r.level<10).length}개`);
        }
        form.button('강화 메뉴로');
      } else if(page==='runes') {
        const bag=readRuneBag(player);
        options=bag.runes.filter(r=>r.id===runeId).map(r=>({rune:r,quote:enhancementQuote(player,'rune',r.uid)}));
        form.title('룬 강화 · '+RUNES[runeId].name).body(wallet+'\n\n강화할 룬 1개를 선택하세요.\n같은 종류도 등급·강화 단계·보관 번호로 구분합니다.\n촉매는 현재 +2부터 최대 5개 사용할 수 있습니다.'+(options.length?'':'\n\n이 종류의 룬이 보관함에 없습니다.'));
        for(const {rune,quote} of options) {
          const slot=bag.equipped.indexOf(rune.uid);
          form.button(`${slot>=0?'§a['+(slot+1)+'번 장착] ':''}${rarityBadge(runeRarity(rune.grade))} +${rune.level} · 보관 #${rune.uid}\n${costText(quote.cost)}`);
        }
        form.button('룬 종류 선택으로');
      } else {
        const kind=page;
        form.title(KIND_NAMES[kind]+' 강화').body(wallet+(kind==='armor'?
          '\n\n착용 중인 RPG 갑옷 부위를 선택하세요.\n최대 +10 · 부위 강화당 최대 HP +1\n총 HP는 게임 효과에 따라 4 HP 단위로 근사합니다.':
          '\n\n주 손에 공용·직업 무기 1개를 들고 선택하세요.\n최대 +10 · 강화당 근접 피해 +1\n직업 무기는 단계당 물리·마법 스킬 피해 +2%')+
          '\n촉매는 현재 +5부터 최대 5개 사용할 수 있습니다.');
        options=kind==='armor'?SLOTS().map(s=>({name:s.name,quote:enhancementQuote(player,kind,s.slot)})):
          [{name:'주 손 무기',quote:enhancementQuote(player,kind,EquipmentSlot.Mainhand)}];
        for(const {name,quote} of options)form.button(quote?quoteButton(quote):name+'\n강화할 RPG 장비 없음');
        if(kind==='armor')form.button('갑옷 강화 이전');
        form.button('강화 메뉴로');
      }
      const choice=await showForm(form,player);
      if(!choice||choice.canceled||choice.selection==null)return;
      const selected=choice.selection;
      if(page==='root') {
        if(selected===0)page='runeTypes';
        else if(selected===1)page='armor';
        else if(selected===2)page='weapon';
        else if(selected===3)await openFusionMenu(player);
        else return;
      } else if(page==='runeTypes') {
        if(selected===options.length){page='root';continue;}
        if(!options[selected])return;
        runeId=options[selected][0];page='runes';
      } else if(page==='runes') {
        if(selected===options.length){page='runeTypes';continue;}
        if(!options[selected])return;
        await attemptUpgrade(player,options[selected].quote);
      } else {
        if(selected<options.length) {
          const entry=options[selected];if(!entry)return;
          if(entry.quote)await attemptUpgrade(player,entry.quote);
          else player.sendMessage('§e[RPG] '+entry.name+'에 강화할 RPG 장비가 없습니다.');
        } else if(page==='armor'&&selected===options.length)await openArmorTransfer(player);
        else page='root';
      }
    }
  } catch(error) {try{player.sendMessage('§c[RPG] 강화 메뉴 오류: '+String(error));}catch{}}
  finally {menus.delete(player.id);}
}

```

## RPG_BP_v0603/scripts/gameplayEntry.js

```js
// RPG gameplay module - independent from slash-command registration pack.
import * as mc from "@minecraft/server";
import { initializeGameplay } from "./main.js";
let started = false;
function safeStart() {
  if (started) return;
  started = true;
  try { initializeGameplay(); }
  catch (e) { console.error("[RPG v0.6.5 gameplay] initialization failed: " + String(e?.stack ?? e)); }
}
try { mc.system.run(safeStart); }
catch (e) { console.error("[RPG v0.6.5 gameplay] schedule failed: " + String(e)); }
try {
  mc.world.afterEvents.worldLoad.subscribe(() => {
    if (!started) mc.system.run(safeStart);
  });
} catch (e) { console.warn("[RPG v0.6.5 gameplay] worldLoad recovery unavailable: " + String(e)); }

// Hydra: guard against any existing burning visual effects after pack upgrade.
// Fire immunity is configured in entities/hydra_boss.json.
try {
  mc.system.runInterval(() => {
    for (const id of ["overworld", "nether", "the_end"]) {
      try {
        const dim = mc.world.getDimension(id);
        for (const hydra of dim.getEntities({ type: "rpg:hydra_boss" })) {
          try {
            if (hydra.getComponent("minecraft:onfire")) hydra.extinguishFire(false);
          } catch (_) { /* invalid or unloaded entity */ }
        }
      } catch (_) { /* unloaded or inaccessible dimension */ }
    }
  }, 10);
} catch (e) { console.warn("[RPG] hydra fire cleanup unavailable: " + String(e)); }

```

## RPG_Commands_BP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Commands BP v0.6.0",
    "description": "RPG v0.6.5 · 룬·갑옷·무기 강화 분리 · 룬 종류별 강화",
    "uuid": "533cff27-4591-48cb-85fb-540c8bcbcc72",
    "version": [
      0,
      6,
      5
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "script",
      "language": "javascript",
      "uuid": "9518dff9-cc69-4ea4-adb6-2762b6291c45",
      "entry": "scripts/commands.js",
      "version": [
        0,
        6,
        5
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
      "version": [
        0,
        6,
        5
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    }
  ]
}

```

## RPG_Commands_BP_v0603/scripts/commands.js

```js
// RPG command registry, isolated in a separate behavior pack.
// Even if complex RPG combat/skill imports fail, /rpg:ping can still register.
import * as mc from "@minecraft/server";
const VERSION = "0.6.5";
const commands = [
  ['tpa','플레이어 이동 요청 · 이동 성공 시 1000골드'],
  ['tpaaccept','받은 플레이어 이동 요청 수락·거절'],
  ['pvpcreate','관리자: 1000 250 1000에 PvP장 생성',null,true],
  ['pkclear','관리자: 플레이어 PK 패널티 해제','player',true],
  ['peace','관리자: 현재 위치 반경 200 평화구역 설정·해제','mode',true],
  ['pvp','결투 신청·수락·항복·PK 상태','player'],
  ['gptnpc','관리자: GPT RPG 질문 NPC 생성',null,true],
  ['temple','천체 신전 위치·활성 제단·후예 전직'],
  ['templecreate','관리자: 앞쪽 빈 지역에 천체 신전 생성',null,true],
  ['templeremove','관리자: 신전 등록 해제·건물 보존',null,true],
  ['fuse','RPG 장비 등급 합성'],
  ['transfer','RPG 갑옷 강화 추출·이전'],
  ['ask','이 애드온의 직업·스킬·제작·던전 정보 질문','question'],
  ['dungeoncreate','관리자: 난이도 1~10 또는 all 동굴 생성·누락 복구','difficulty',true],
  ['dungeonremove','관리자: 던전 등록 해제 (건축물 보존)','name',true],
  ['dungeon','난이도 목록·파티장 입장 시 파티원 자동 등록','difficulty'],
  ['dungeonstart','대기실 인원 1~4명 출발'],
  ['dungeonsolo','해당 난이도 혼자 바로 시작','difficulty'],
  ['dungeonleave','대기 취소·사망 후 귀환 (전투 중 불가)'],
  ['dungeonloot','보관된 던전 보급품 받기'],
  ['skillguide','모든 직업·스킬 상세 도감'],
  ['runes','룬 전용 보관함·장착'],
  ['jobs','직업별 전직 조건·시련'],
  ['craft', '갑옷·룬 제작법과 획득 도감'],
  ['upgrade', '갑옷·룬·공용 무기 강화'],
  ['wallet', '골드·강화석·룬 가루 지갑'],
  ['equipment', 'RPG 갑옷·룬 보관·장착'],
  ['guide', '모험 시작·견습 5계열 자유 체험'],
  ["rulebook", "RPG 서버 종합 룰북"],
  ["ping", "명령어 등록 진단"],
  ["diag", "명령어 및 스크립트 진단"],
  ["menu", "카멜레온 스킬 메뉴"],
  ["job", "전직", "job"],
  ["help", "명령어 도움말"],
  ["status", "캐릭터 상태"],
  ["stats", "레벨·스탯 분배"],
  ["admin", "운영자 설정 도구", null, true],
  ["setlevel", "관리자: 레벨 설정", "level", true],
  ["setmana", "관리자: 최대 마나 설정", "amount", true],
  ["skills", "스킬 켜기·끄기"],
  ["skillbook", "스킬 도감"],
  ["learn", "스킬 습득", "skill"],
  ["swap", "카멜레온 무기 전환"],
  ["offer", "검과 책을 바칩니다"],
  ["bless", "미카엘 전직: 축복의 빛 192개 공물"],
  ["holywater", "성수 제작"],
  ["force", "관리자: 강제 전직", "job", true],
  ["reset", "관리자: 초기화", null, true],
  ["starter", "관리자: 견습 장비", "line", true],
  ["charge", "관리자: 마나·쿨타임 회복", null, true],
  ["items", "관리자: 전용 아이템", null, true],
  ["egg", "관리자: 몬스터 스폰알", null, true],
  ["hito", "관리자: 전직관 소환알 지급", "line", true],
  ["wings", "날개 켜기·끄기"],
  ["wingcheck", "날개 상태"],
  ["wingrefresh", "날개 새로고침"],
  ["guild", "길드 메뉴"],
  ["party", "파티 메뉴"],
  ["invites", "초대 확인"],
  ["boss", "관리자: 바위 골렘", null, true],
  ["cyclops", "관리자: 외눈 거인", null, true],
  ["hydra", "관리자: 히드라", null, true],
  ["techgolem", "관리자: 마공학 골렘", null, true],
  ["fistcheck", "주먹 강화 상태"]
];
const registered = new Set();
let startupDone = false;
let failures = [];
function isPlayer(p) { return !!p && p.typeId === "minecraft:player"; }
function tell(p, msg) { try { p.sendMessage(msg); } catch (e) { console.warn("[RPG commands] message: " + e); } }
function handle(action, p, arg="") {
  if (!isPlayer(p)) return;
  if (action === "ping") {
    tell(p, "§a[RPG v"+VERSION+"] 명령어 스크립트 실행 정상. 등록 "+registered.size+"/"+commands.length);
    return;
  }
  if (action === "diag") {
    tell(p,"§e[RPG v"+VERSION+"] 명령어 팩 실행 정상 ("+registered.size+"/"+commands.length+"). RPG 본체 확인: /rpg:status");
    if(failures.length) failures.slice(0,4).forEach(x=>tell(p,"§c"+x));
    tell(p,"§7게임플레이 오류는 설정 → 제작자 → 콘텐츠 로그에서 확인 가능. /function rpg_hydra 로 히드라 소환 검사 가능");
    return;
  }
  // The RPG gameplay BP independently handles this script event. It is run as
  // the player so event.sourceEntity is the correct player object.
  const message = String(arg??"").replace(/[\r\n]/g," ").trim();
  try {
    p.runCommand("scriptevent rpg:"+action+(message?" "+message:""));
  } catch (e) {
    tell(p,"§c[RPG] 명령어 전달 실패: "+String(e));
  }
}
mc.system.beforeEvents.startup.subscribe(ev => {
  startupDone = true;
  const registry = ev.customCommandRegistry;
  if(!registry){ console.error("[RPG commands] customCommandRegistry unavailable"); return; }
  const levels = mc.CommandPermissionLevel ?? mc.CustomCommandPermissionLevel;
  const params = mc.CustomCommandParamType;
  const statuses = mc.CustomCommandStatus;
  if(!levels || !params || !statuses){ console.error("[RPG commands] Script API command enums unavailable"); return; }
  for(const [name, description, arg, admin] of commands){
    try{
      const def={name:"rpg:"+name,description,permissionLevel: admin?levels.GameDirectors:levels.Any,cheatsRequired:false};
      if(arg){
        const t = name === "setlevel" ? params.Integer : params.String;
        if(name === "hito" || name === "dungeon" || name === "ask" || name === "pvp" || name === "peace" || name === "pkclear") def.optionalParameters=[{name:arg,type:t}];
        else def.mandatoryParameters=[{name:arg,type:t}];
      }
      registry.registerCommand(def,(origin,...args)=>{
        const p=origin.sourceEntity??origin.initiator;
        if(!isPlayer(p)) return {status:statuses.Failure,message:"플레이어 전용 명령어"};
        const raw=Array.isArray(args[0])?args[0][0]:args[0];
        mc.system.run(()=>handle(name,p,raw==null?"":String(raw)));
        return {status:statuses.Success};
      });
      registered.add(name);
    }catch(e){
      const msg="/rpg:"+name+" 등록 실패: "+String(e);
      failures.push(msg);console.error("[RPG commands] "+msg);
    }
  }
  try{registry.registerCommand({name:'pvp',description:'결투 신청',permissionLevel:levels.Any,cheatsRequired:false,optionalParameters:[{name:'player',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvp',p,arg??''));return {status:statuses.Success};});}catch{ /* Namespace-free aliases are unsupported on some Bedrock versions. */ }
  try{registry.registerCommand({name:'peace',description:'관리자: 반경 200 평화구역',permissionLevel:levels.GameDirectors,cheatsRequired:false,optionalParameters:[{name:'mode',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('peace',p,arg??''));return {status:statuses.Success};});}catch{console.warn('[RPG] /peace 별칭 미지원: /rpg:peace 사용');}
  try{registry.registerCommand({name:'pvpcreate',description:'관리자: PvP장 생성',permissionLevel:levels.GameDirectors,cheatsRequired:false},origin=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvpcreate',p,''));return {status:statuses.Success};});}catch{console.warn('[RPG] /pvpcreate 별칭 미지원: /rpg:pvpcreate 사용');}
  console.warn("[RPG v"+VERSION+"] registered "+registered.size+"/"+commands.length+" commands");
});
// Allow commands even if a particular client doesn't display slash commands.
try {
  const chat=mc.world.beforeEvents?.chatSend;
  if(chat?.subscribe) chat.subscribe(ev=>{
    const msg=String(ev.message??"").trim();
    if(!/^!(?:rpg|rulebook|hito|pvp)(?:\s|$)/i.test(msg))return;
    ev.cancel=true;
    let action="help",arg="";
    if(/^!pvp(?:\s|$)/i.test(msg)){action='pvp';arg=msg.replace(/^!pvp\s*/i,'');}
    else if(/^!rulebook$/i.test(msg))action="rulebook";
    else if(/^!hito(?:\s|$)/i.test(msg)){action="hito";arg=msg.replace(/^!hito\s*/i,"");}
    else {const parts=msg.replace(/^!rpg\s*/i,"").trim().split(/\s+/);action=(parts.shift()||"help").toLowerCase();arg=parts.join(" ");}
    const p=ev.sender;
    mc.system.run(()=>handle(action,p,arg));
  });
}catch(e){console.warn("[RPG commands] chat fallback disabled: "+e);}
// Direct /scriptevent rpg:ping and rpg:diag allow diagnosing even if custom
// command registration is unsupported on the current Bedrock version.
try {
  mc.system.afterEvents.scriptEventReceive.subscribe(ev=>{
    if(ev.id!=="rpg:ping"&&ev.id!=="rpg:diag") return;
    if(isPlayer(ev.sourceEntity))mc.system.run(()=>handle(ev.id.slice(4),ev.sourceEntity));
  });
}catch(e){console.warn("[RPG commands] event diagnostic fallback disabled: "+e);}

```

## RPG_RP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon RP v0.6.0",
    "description": "RPG v0.6.5 · 룬·갑옷·무기 강화 분리 · 룬 종류별 강화",
    "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
    "version": [
      0,
      6,
      5
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "resources",
      "uuid": "7ede5e36-9a5f-44d1-9aa0-9dc38822fa99",
      "version": [
        0,
        6,
        5
      ]
    }
  ]
}

```

