# RPG v0.6.79 · 피의 낫과 슈퍼 샌드백

- 블라디미르의 **피의 낫** 기본 공격력을 8에서 20으로 높였습니다.
- **슈퍼 샌드백**은 공격을 받아도 체력을 즉시 회복합니다. 머리 위에 마지막으로 공격하거나 초기화한 플레이어의 이름과 누적 피해가 표시됩니다. 샌드백마다 플레이어별 기록을 따로 저장합니다.
- 샌드백을 바라보고 **웅크린 채 우클릭**하면 본인의 누적 피해만 0으로 초기화됩니다.
- 작업대에 **훈련용 샌드백 소환 ×1 + 네더의 별 ×1**을 순서에 관계없이 놓으면 소환 아이템을 제작할 수 있습니다. 소환 아이템을 블록에 사용해 설치하세요.
- 샌드백 외형은 첨부 스킨 이미지를 바탕으로 복원한 64×64 텍스처를 사용합니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.79로 활성화하고 월드를 다시 여세요. 모의 테스트에서 근접·투사체·스킬 피해 누적, 큰 피해 처리, 플레이어별 기록과 웅크리기 초기화, 피의 낫 공격력 데이터를 확인했습니다. 실제 Bedrock에서의 외형과 상호작용은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0679
```
