import test from 'node:test';
import assert from 'node:assert/strict';
import {skillGuideGroups,skillGuideDetail,openSkillGuide} from '../RPG_BP_v0548/scripts/core/skillGuide.js';
import {SKILL_NOTES,LINE_NOTES} from '../RPG_BP_v0548/scripts/data/skillGuide.js';
import {player,replies,forms} from './minecraftMock.mjs';
test('all 129 active skills in 18 lines have current descriptions, owners, cost and cooldown',()=>{
  const groups=skillGuideGroups(),ids=groups.flatMap(g=>g.ids);assert.equal(groups.length,19);assert.equal(ids.length,136);assert.equal(new Set(ids).size,136);assert.deepEqual(new Set(ids),new Set(Object.keys(SKILL_NOTES)));
  for(const g of groups){assert.ok(LINE_NOTES[g.line]);for(const id of g.ids){const detail=skillGuideDetail(id);assert.match(detail,/사용 직업:/);assert.match(detail,/기본 MP/);assert.match(detail,/쿨 .*초/);assert.ok(SKILL_NOTES[id].length>20);}}
  assert.match(skillGuideDetail('fist_wind'),/MP 90 \/ 쿨 13초/);assert.match(skillGuideDetail('sage_meteor'),/MP 700/);assert.match(skillGuideDetail('fallen_end'),/MP 800/);assert.equal(skillGuideDetail('missing'),undefined);
});
test('skill guide navigates through a line and skill without granting or learning anything',async()=>{
  const p=player('guide');replies.push({canceled:false,selection:0},{canceled:false,selection:0},{canceled:false,selection:0},{canceled:true},{canceled:true});await openSkillGuide(p);
  assert.ok(forms.some(f=>f.heading==='직업 계열별 스킬 도감'));assert.ok(forms.some(f=>f.text?.includes('스킬 ID: sword_spin')));assert.equal(p.getDynamicProperty('rpg:skills'),undefined);assert.equal(p.slots.filter(Boolean).length,0);
});
