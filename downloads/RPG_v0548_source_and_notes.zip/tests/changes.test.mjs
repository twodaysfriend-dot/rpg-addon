import test from 'node:test';
import assert from 'node:assert/strict';
import {world, players, player, replies, forms, events, timeouts} from './minecraftMock.mjs';
import {personalKillXp, isXpRecipient} from '../RPG_BP_v0548/scripts/core/xpDistribution.js';
import {distributeKillXp, getXp, getLevel, registerRpgStats} from '../RPG_BP_v0548/scripts/core/stats.js';
import {chooseBeginnerLine, recordBeginnerKill, claimBeginnerReward, openBeginnerGuide, registerBeginnerGuide} from '../RPG_BP_v0548/scripts/core/beginner.js';
import {getBeginnerState, isBeginnerTarget} from '../RPG_BP_v0548/scripts/core/beginnerData.js';
import {checkAdvance, requirementStatus} from '../RPG_BP_v0548/scripts/core/advance.js';
import {JOBS} from '../RPG_BP_v0548/scripts/data/jobs.js';

test('party members each receive 75%, independent of level and party size', () => {
  assert.equal(personalKillXp(90,true),67.5);
  assert.equal(personalKillXp(90,false),90);
  for (const count of [1,2,3,4]) assert.deepEqual(Array.from({length:count},()=>personalKillXp(90,true)),Array(count).fill(67.5));
  assert.equal(personalKillXp(0,true),0);
});
test('distance, dimension, death, game mode, validity and max-level exclusions', () => {
  const origin={x:0,y:64,z:0};
  const eligible=p=>isXpRecipient(p,origin,'minecraft:overworld',getLevel(p),100,32);
  assert.equal(eligible(player('at-edge',10,{location:{x:32,y:64,z:0}})),true);
  for (const p of [
    player('far',10,{location:{x:33,y:64,z:0}}),player('vertical',10,{location:{x:0,y:97,z:0}}),
    player('other-dim',10,{dimension:{id:'minecraft:nether'}}),player('dead',10,{health:0}),
    player('creative',10,{getGameMode:()=> 'creative'}),player('spectator',10,{getGameMode:()=> 'spectator'}),
    player('invalid',10,{isValid:false}),player('max',100),player('admin-max',100000),
  ]) assert.equal(eligible(p),false,p.id);
});

// Seed before the social module first reads its lazy saved state.
const a=player('a',10),b=player('b',20),far=player('far',20,{location:{x:100,y:64,z:0}}),
  max=player('max',100),guildOnly=player('guildOnly',10),offline=player('offline',20);
world.setDynamicProperty('rpg:social_v1',JSON.stringify({version:1,nextId:3,
  parties:[{id:1,leader:'a',members:['a','b','far','max','offline']}],
  guilds:[{id:2,name:'guild',leader:'a',members:['a','guildOnly']}]}));
players.push(a,b,far,max,guildOnly);

test('kill payout uses actual saved party membership; no guild/offline/out-of-range dilution', () => {
  assert.deepEqual(distributeKillXp(a,90),[{id:'a',amount:67.5},{id:'b',amount:67.5}]);
  assert.equal(getXp(a),67.5);assert.equal(getXp(b),67.5);
  for (const p of [far,max,guildOnly,offline]) assert.equal(getXp(p),0);
  assert.deepEqual(distributeKillXp(guildOnly,20),[{id:'guildOnly',amount:20}]);
});
test('level differences and level-ups do not change party payout', () => {
  a.setDynamicProperty('rpg:rpg_level',1); b.setDynamicProperty('rpg:rpg_level',1);
  a.setDynamicProperty('rpg:rpg_xp',79); b.setDynamicProperty('rpg:rpg_xp',0);
  assert.deepEqual(distributeKillXp(a,20),[{id:'a',amount:15},{id:'b',amount:15}]);
  assert.equal(getLevel(a),2);assert.equal(getXp(a),14);assert.equal(getXp(b),15);
});
test('each starting line grants a valid kit and skills exactly once', () => {
  for (const line of ['sword','mage','holy','fist','archer']) {
    const p=player(line); assert.equal(chooseBeginnerLine(p,line).ok,true);
    assert.equal(p.slots[0].keepOnDeath,true);
    assert.equal(p.slots[1].typeId,'minecraft:bread');assert.equal(p.slots[1].amount,16);
    if (line==='archer') assert.equal(p.slots[2].amount,64);
    const before=JSON.stringify(p.slots);
    assert.equal(chooseBeginnerLine(p,line).ok,false);
    assert.equal(JSON.stringify(p.slots),before);
    assert.equal(getBeginnerState(p).line,line);
  }
});
test('full inventory cannot overwrite items or consume the one-time selection', () => {
  const p=player('full');for(let i=0;i<36;i++)p.slots[i]={typeId:'minecraft:stone',amount:64};
  const before=JSON.stringify(p.slots);
  assert.equal(chooseBeginnerLine(p,'mage').ok,false);
  assert.equal(JSON.stringify(p.slots),before);assert.equal(getBeginnerState(p).line,undefined);
  p.slots[0]=undefined;p.slots[1]=undefined;
  assert.equal(chooseBeginnerLine(p,'mage').ok,true);
});
test('failed kit persistence rolls back the items and permits a clean retry', () => {
  const p=player('failure'),save=p.setDynamicProperty.bind(p);let fail=true;
  p.setDynamicProperty=(key,value)=>{if(key==='rpg:intro_v1'&&fail){fail=false;throw Error('test failure');}save(key,value);};
  assert.equal(chooseBeginnerLine(p,'archer').ok,false);
  assert.ok(p.slots.every(i=>i===undefined));assert.equal(getBeginnerState(p).line,undefined);
  assert.equal(chooseBeginnerLine(p,'archer').ok,true);
});
test('existing advanced characters and invalid lines cannot receive beginner kits', () => {
  const p=player('advanced');p.setDynamicProperty('rpg:job','mage');
  assert.equal(chooseBeginnerLine(p,'sword').ok,false);
  assert.equal(chooseBeginnerLine(player('bad'),'invalid').ok,false);
});
test('first hunt ignores animals, players, NPCs, dummies, and creative kills', () => {
  const p=player('hunter');chooseBeginnerLine(p,'sword');
  for (const typeId of ['minecraft:chicken','minecraft:villager','minecraft:player','rpg:hito_sword','rpg:sandbag_entity']) {
    assert.equal(isBeginnerTarget(typeId),false);recordBeginnerKill(p,{typeId});
  }
  assert.equal(getBeginnerState(p).kills,0);
  p.getGameMode=()=> 'creative';recordBeginnerKill(p,{typeId:'minecraft:zombie'});
  assert.equal(getBeginnerState(p).kills,0);
  assert.equal(claimBeginnerReward(p),false);
});
test('first hunt reward remains one-time and cannot bypass level ten advancement trials', () => {
  const p=player('graduate');chooseBeginnerLine(p,'sword');
  assert.equal(checkAdvance(p,JOBS.swordsman).ok,false);
  for(let i=0;i<6;i++)recordBeginnerKill(p,{typeId:'rpg:green_goblin'});
  assert.equal(getBeginnerState(p).kills,5);assert.equal(claimBeginnerReward(p),true);
  assert.equal(getLevel(p),2);assert.equal(getXp(p),20);
  assert.equal(checkAdvance(p,JOBS.swordsman).ok,false);
  assert.equal(requirementStatus(p,JOBS.swordsman).met,false);
  assert.equal(checkAdvance(p,JOBS.mage).ok,false);
  assert.equal(checkAdvance(p,JOBS.sword_saint).ok,false);
  assert.equal(checkAdvance(p,JOBS.assassin).ok,false);
  assert.equal(claimBeginnerReward(p),false);assert.equal(getXp(p),20);
  const rejoined=player('graduate');for(const [k,v] of p.values)rejoined.setDynamicProperty(k,v);
  assert.equal(chooseBeginnerLine(rejoined,'mage').ok,false);
  assert.equal(claimBeginnerReward(rejoined),false);assert.equal(checkAdvance(rejoined,JOBS.swordsman).ok,false);
});
test('UI cancel can be reopened; selection and reward paths work without OP', async () => {
  const p=player('ui');replies.push({canceled:true});await openBeginnerGuide(p);
  assert.equal(getBeginnerState(p).offered,true);assert.equal(getBeginnerState(p).line,undefined);
  replies.push({canceled:false,selection:4},{canceled:true});await openBeginnerGuide(p);
  assert.equal(getBeginnerState(p).line,'archer');
  for(let i=0;i<5;i++)recordBeginnerKill(p,{typeId:'minecraft:zombie'});
  replies.push({canceled:false,selection:0});await openBeginnerGuide(p);
  assert.equal(getBeginnerState(p).rewarded,true);
  assert.ok(forms.some(f=>f.buttons.includes('첫 사냥 보상 받기')));
  p.setDynamicProperty('rpg:rpg_level',10);p.setDynamicProperty('rpg:progress',JSON.stringify({archer_target20:1}));
  replies.push({canceled:false,selection:0});await openBeginnerGuide(p);
  assert.equal(p.getDynamicProperty('rpg:job'),'archer');
  assert.equal(p.slots[0].typeId,'rpg:archer_bow');
});
test('initial join and gameplay initialization never auto-open a line selector; registration remains idempotent', async () => {
  const p=player('welcome');players.push(p);
  const spawnCount=events.playerSpawn.listeners.length,leaveCount=events.playerLeave.listeners.length;
  const queued=timeouts.length,formCount=forms.length;
  registerBeginnerGuide();registerBeginnerGuide();
  assert.equal(events.playerSpawn.listeners.length,spawnCount);
  assert.equal(events.playerLeave.listeners.length,leaveCount+1);
  assert.equal(timeouts.length,queued);
  for(const initialSpawn of [true,false])for(const handler of events.playerSpawn.listeners)handler({player:p,initialSpawn});
  await new Promise(r=>setImmediate(r));
  assert.equal(forms.length,formCount);assert.equal(getBeginnerState(p).offered,false);
  assert.equal(getBeginnerState(p).line,undefined);assert.equal(p.slots.filter(Boolean).length,0);
});
test('death event awards shared XP and intro objective to killer only, including projectile owner fallback', () => {
  registerRpgStats(recordBeginnerKill);
  const killer=player('event-killer');chooseBeginnerLine(killer,'mage');
  const emit=events.entityDie.listeners.at(-1);
  emit({deadEntity:{typeId:'minecraft:zombie'},damageSource:{damagingEntity:killer}});
  assert.equal(getXp(killer),30);assert.equal(getBeginnerState(killer).kills,1);
  emit({deadEntity:{typeId:'minecraft:skeleton'},damageSource:{damagingProjectile:{getComponent:()=>({owner:killer})}}});
  assert.equal(getXp(killer),60);assert.equal(getBeginnerState(killer).kills,2);
});
