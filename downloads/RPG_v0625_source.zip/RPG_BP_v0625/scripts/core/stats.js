import {wardDefenseValue,wardDamageReduction} from './wardDefense.js';
import {rpgXpMultiplier} from './xpBoost.js';
import {scriptKiller} from './combatContext.js';
import {recordTrialKillExtras} from './newTrials.js';
import {awardPartyTrialKill} from './combatContribution.js';
import {mobXp} from '../data/mobXp.js';
import {recordPvpDeath,pvpOwner} from './pvp.js';
import {classWeapon} from '../data/classWeapons.js';
import {upgradeLevel} from '../data/upgrades.js';
import {levelRewardMultiplier} from '../data/monsterLevels.js';
import { learningSpent,awardChameleonLevels } from './chameleonProgress.js';
// RPG 전용 레벨과 4종 능력치 (월드 재접속 시 플레이어 동적 속성으로 유지).
// 힘=물리 스킬, 체력=최대 HP, 지능=마나 소모 감소, 마력=마법 피해/직접 회복량.
import { world, system, EquipmentSlot } from '@minecraft/server';
import * as UI from '@minecraft/server-ui';
import { CONFIG } from '../config.js';
import { partyMembership } from './social.js';
import { personalKillXp, isXpRecipient } from './xpDistribution.js';
import { getEquipmentBonuses } from './equipment.js';
import { grantKillCurrencies } from './economy.js';

export const STAT_BASE = 5;
export const STAT_BUFF = 5.6; // 근력·마력 계산의 기존 배율
export const VITALITY_HP_PER_POINT = 100 / (50 - STAT_BASE); // VIT 50 => base HP 20 + 100
export const LEVEL_MAX = 100; // 자연 성장 상한
export const ADMIN_LEVEL_MAX = 100000; // 관리자 명령어 전용
export const STAT_MAX = Object.freeze({ str:null, vit:null, int:50, mag:null });
const STAT_NAMES = Object.freeze({ str:'근력', vit:'체력', int:'지능', mag:'마력' });
const STATS_KEY='rpg:stat_values';
const LEVEL_KEY='rpg:rpg_level';
const XP_KEY='rpg:rpg_xp';
const DEFAULT = Object.freeze({str:5,vit:5,int:5,mag:5});
const REGEN_HEALTH_REFRESH=100;
const formOpen=new Set();

export function getLevel(p){
  try{const n=p.getDynamicProperty(LEVEL_KEY);return Number.isInteger(n)?Math.min(ADMIN_LEVEL_MAX,Math.max(1,n)):1;}catch{return 1;}
}
// 관리자 설정: RPG 레벨 직접 지정. 자연 경험치 획득은 100레벨에서 멈춘다.
export function forceSetLevel(p,number){
  // Require an actual decimal integer, never silently convert blanks to 0.
  const raw=String(number??'').trim();
  const n=/^[0-9]+$/.test(raw)?Number(raw):NaN;
  if(!Number.isSafeInteger(n)||n<1||n>ADMIN_LEVEL_MAX)
    return {ok:false,reason:`레벨은 1~${ADMIN_LEVEL_MAX.toLocaleString()} 정수만 설정할 수 있습니다.`};
  try{
    const old=getLevel(p);
    p.setDynamicProperty(LEVEL_KEY,n);
    p.setDynamicProperty(XP_KEY,0);
    // 낮은 레벨로 강제 조정할 때 초과 배분 스탯이 남지 않도록 정리.
    let resetStats=false;
    const allocated=Object.values(getStats(p)).reduce((sum,v)=>sum+v-STAT_BASE,0);
    if(allocated>Math.max(0,(n-1)*3-learningSpent(p))){
      p.setDynamicProperty(STATS_KEY,JSON.stringify(DEFAULT));
      applyVitality(p);
      resetStats=true;
    }
    const saved=getLevel(p);
    if(saved!==n) return {ok:false,reason:`레벨 저장 확인 실패 (현재 ${saved})`};
    return {ok:true,old,level:saved,resetStats};
  }catch(error){return {ok:false,reason:'레벨 저장 실패: '+String(error)};}
}
export function getXp(p){
  try{const n=p.getDynamicProperty(XP_KEY);return typeof n==='number'&&Number.isFinite(n)?Math.max(0,n):0;}catch{return 0;}
}
export function xpForNext(level){return Math.floor(80+20*(level-1)+2*(level-1)*(level-1));}
export function getStats(p){
  let raw={};
  try{const v=p.getDynamicProperty(STATS_KEY);if(typeof v==='string')raw=JSON.parse(v)??{};}catch{}
  const result={};
  for(const id of Object.keys(DEFAULT)){
    const n=Number(raw[id]);result[id]=Number.isSafeInteger(n)?Math.max(STAT_BASE,STAT_MAX[id]===null?n:Math.min(STAT_MAX[id],n)):STAT_BASE;
  }
  return result;
}
export function totalStatPoints(p){return (getLevel(p)-1)*3;}
export function resetAllocatedStats(p){
 const allocated=Object.values(getStats(p)).reduce((sum,n)=>sum+n-STAT_BASE,0);
 if(allocated<=0)return 0;
 p.setDynamicProperty(STATS_KEY,JSON.stringify(DEFAULT));applyVitality(p);return allocated;
}
export function unspentPoints(p){
  const s=getStats(p);
  return Math.max(0,totalStatPoints(p)-learningSpent(p)-Object.values(s).reduce((a,n)=>a+n-STAT_BASE,0));
}
export function allocateStat(p, id, count=1){
  if(!Object.prototype.hasOwnProperty.call(STAT_MAX,id))return {ok:false,reason:'없는 스탯'};
  const n=Number(count);if(!Number.isSafeInteger(n)||n<1)return {ok:false,reason:'잘못된 포인트 수'};
  const s=getStats(p), remain=unspentPoints(p);
  if(n>remain)return {ok:false,reason:'스탯 포인트 부족'};
  if(!Number.isSafeInteger(s[id]+n))return {ok:false,reason:'저장 가능한 정수 범위를 넘었습니다.'};
  if(STAT_MAX[id]!==null && s[id]+n>STAT_MAX[id])return {ok:false,reason:`${STAT_NAMES[id]} 최대 ${STAT_MAX[id]}`} ;
  s[id]+=n;
  try{p.setDynamicProperty(STATS_KEY,JSON.stringify(s));if(id==='vit')applyVitality(p);}
  catch{return {ok:false,reason:'저장 실패'};}
  return {ok:true,stat:s[id],left:remain-n};
}
// 초기 지능 5를 기준으로 45포인트 더 찍을 수 있음. 최대 마나 소모 감소 40%.
export function manaCostFor(p,base){
  const int=getStats(p).int;
  // 넨 능력자는 오라 효율이 1.25배: 지능 45포인트를 모두 찍으면 소모 50% 감소.
  let nen=false;try{nen=p.getDynamicProperty('rpg:job')==='nen';}catch{}
  const maxCut=nen?0.5:0.4;
  return Math.max(base>0?1:0,Math.ceil(Math.max(0,base)*(1-Math.min(maxCut,(int-STAT_BASE)*maxCut/(50-STAT_BASE)))-1e-9));
}
export function healingFor(p,base){
  const mag=getStats(p).mag;
  return Math.max(0,base)*(1+0.0035*STAT_BUFF*(mag-STAT_BASE));
}
// Bedrock Strength amplifiers are zero-based; each level adds 5% skill damage.
// Read the live effect so expiry, removal and a changed buff level take effect immediately.
export function strengthDamageMultiplier(p){
  try{
    const effect=p.getEffect('strength');
    return Number.isInteger(effect?.amplifier)&&effect.amplifier>=0
      ? 1+(effect.amplifier+1)*CONFIG.skillDamage.strengthPerLevel : 1;
  }catch{return 1;}
}
export function skillDamageFor(p,base,type,{strengthIncluded=false}={}){
  if(type==='fixed'||!p||p.typeId!=='minecraft:player')return base;
  const s=getStats(p);
  const magic=type==='magic';
  const stat=magic?s.mag:s.str;
  const gear=getEquipmentBonuses(p);
  const damage=Math.max(0,base);
  // Fist skills already include Strength before their strong-punch multiplier.
  const strength=!strengthIncluded?strengthDamageMultiplier(p):1;
  const held=p.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand);
  const weaponBonus=classWeapon(held?.typeId)?1+upgradeLevel(held,'weapon')*.02:1;
  const statPerPoint=0.021*STAT_BUFF*(magic?1:0.4);
  return damage*strength*(1+statPerPoint*(stat-STAT_BASE))*(magic?gear.magic:gear.physical)*weaponBonus;
}
const MAGICAL_LINES=new Set(['mage','holy','necro','fire','frost','tech','demon','blood','hacker','celestial_sun']);
export function defaultDamageTypeFor(p){
  try{
    const j=p.getDynamicProperty('rpg:job');
    const magicalJobs=new Set(['mage','sage','cleric','angel','michael','fallen_angel','necromancer','deathlord','fire_controller','frost_controller','technomancer','demon','blood_mage','blood','hacker','sun_heir']);
    return magicalJobs.has(j)?'magic':'physical';
  }catch{return 'physical';}
}
// VIT starts at 5; +45 allocated points grant +100 HP (120 total before gear).
// The native health_boost effect rounds the combined bonus to increments of 4 HP.
export function applyVitality(p){
  try{
    const bonusHP=(getStats(p).vit-STAT_BASE)*VITALITY_HP_PER_POINT+getEquipmentBonuses(p).health;
    // No gameplay VIT cap; the native effect API permits amplifiers 0..255.
    const steps=Math.min(256,Math.round(bonusHP/4));
    if(steps>0)p.addEffect('health_boost',REGEN_HEALTH_REFRESH+80,{amplifier:steps-1,showParticles:false});
    else if(p.getEffect('health_boost'))p.removeEffect('health_boost');
  }catch{}
}
export function gainRpgXp(p,amount){
  if(p?.typeId!=='minecraft:player'||!Number.isFinite(amount)||amount<=0)return;
  let level=getLevel(p),xp=getXp(p)+amount*rpgXpMultiplier(p),levels=0;
  while(level<LEVEL_MAX && xp>=xpForNext(level)){
    xp-=xpForNext(level);level++;levels++;
  }
  if(level>=LEVEL_MAX)xp=0;
  try{
    p.setDynamicProperty(LEVEL_KEY,level);
    p.setDynamicProperty(XP_KEY,xp);
    if(levels){
      try{awardChameleonLevels(p,levels);}catch(error){console.warn('[RPG skillbook] '+String(error));}
      p.sendMessage(`§a[RPG] 레벨 ${level}! §e스탯 포인트 +${levels*3} §7(/rpg:stats)`);
      try{p.dimension.playSound('random.levelup',p.location,{volume:.55,pitch:1.1});}catch{}
    }
  }catch{}
}
function killReward(entity){return Math.round(mobXp(entity?.typeId)*levelRewardMultiplier(entity));}

export function levelDefenseValue(p){
  const lv=getLevel(p);
  return Math.max(0, Math.min(ADMIN_LEVEL_MAX, lv))+wardDefenseValue(p);
}
export function levelDefenseReduction(p){
  const lv=getLevel(p);
  return Math.max(0, Math.min(0.45, lv*0.0035)); // 레벨당 0.35%, 최대 45%
}
function pretty(p){
  const s=getStats(p),lv=getLevel(p);
  const exp=lv>LEVEL_MAX?'관리자 설정':lv>=LEVEL_MAX?'MAX':`${getXp(p)}/${xpForNext(lv)}`;
  const defPct=(levelDefenseReduction(p)*100).toFixed(1);
  return `§eLv.${lv} §7RPG XP ${exp}
§a남은 SP: ${unspentPoints(p)}
§7방어력 ${levelDefenseValue(p)} §8(레벨 피해감소 ${defPct}% / 룬 방어력 +${wardDefenseValue(p)}·추가 감소 ${(wardDamageReduction(p)*100).toFixed(2)}%)
§c근력 ${s.str}§r  §6체력 ${s.vit}§r  §b지능 ${s.int}/50§r  §d마력 ${s.mag}`;
}
export function statsSummary(p){return pretty(p);}
async function show(p,form){
  const busy=UI.FormCancelationReason?.UserBusy??'UserBusy';
  for(let i=0;i<12;i++){
    const r=await form.show(p);
    if(!r.canceled||r.cancelationReason!==busy)return r;
    await new Promise(resolve=>system.runTimeout(resolve,10));
  }
  return undefined;
}
// 스탯 선택 즉시 직접 수량 입력: +1/+5/+10/최대 배분 선택창 없음.
// 근력·체력·마력에는 게임 규칙 상한이 없고, 지능만 50을 유지한다.
const STAT_ORDER=['str','vit','int','mag'];
export async function openStatsMenu(p){
  if(formOpen.has(p.id))return;
  formOpen.add(p.id);
  try{
    for(let j=0;j<120;j++){
      if(!p.isValid)break;
      const s=getStats(p);
      const f=new UI.ActionFormData().title('RPG 레벨 · 스탯').body(pretty(p)+
        '\n§7레벨 기반 방어력: 레벨당 피해 감소 0.35% (최대 45%)\n§7근력: 물리 피해 4.704%/점\n§7체력: 최대 HP 약 2.222/점 · 체력 50이면 기본 최대 HP 120 (장비 별도)\n§7지능: 추가 1점당 마나 절약 약 0.889%p (지능 50에서 최대 40%)\n§7마력: 마법 피해 11.76%, 회복량 1.96%/점');
      for(const id of STAT_ORDER)f.button(`${STAT_NAMES[id]} 직접 입력  §7(${s[id]}/${STAT_MAX[id]===null?'상한 없음':STAT_MAX[id]})`);
      f.button('닫기');
      const response=await show(p,f);
      if(!response||response.canceled||response.selection>=STAT_ORDER.length)break;
      const id=STAT_ORDER[response.selection];
      const remaining=unspentPoints(p);
      const available=Math.max(0,Math.min(remaining,STAT_MAX[id]===null?Infinity:STAT_MAX[id]-getStats(p)[id]));
      if(available<=0){
        p.sendMessage('§e[RPG] 배분할 수 있는 포인트가 없거나 이 스탯이 최대치입니다.');
        continue;
      }
      const form=new UI.ModalFormData().title(`${STAT_NAMES[id]} 스탯 직접 입력`)
        .textField(`배분할 포인트 (1~${available})`,'숫자 입력',{defaultValue:'1'})
        .submitButton('포인트 배분');
      const reply=await show(p,form);
      if(!reply||reply.canceled)continue;
      const raw=String(reply.formValues?.[0]??'').normalize('NFKC').trim();
      const count=/^[0-9]+$/.test(raw)?Number(raw):NaN;
      // Empty/invalid submissions return quietly without spending stat points.
      if(!Number.isSafeInteger(count)||count<1)continue;
      const result=allocateStat(p,id,count);
      if(!result.ok)p.sendMessage('§c[RPG] '+result.reason);
      else p.sendMessage(`§a[RPG] ${STAT_NAMES[id]} +${count} → ${result.stat}, 남은 포인트 ${result.left}`);
    }
  }catch(e){try{p.sendMessage('§c스탯 메뉴 오류: '+String(e));}catch{}}
  finally{formOpen.delete(p.id);}
}

export function distributeKillXp(killer, amount) {
  const origin = killer.location;
  const dimensionId = killer.dimension.id;
  const party = partyMembership(killer);
  const members = party.members
    .map(player => ({player, id: player.id, level: getLevel(player)}))
    .filter(m => isXpRecipient(m.player, origin, dimensionId, m.level, LEVEL_MAX, CONFIG.partyXp.radius))
    .sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  const shares = members.map(m => ({id:m.id, amount:personalKillXp(amount, party.inParty, CONFIG.partyXp.multiplier)}));
  for (const share of shares) {
    if (share.amount > 0) gainRpgXp(members.find(m => m.id === share.id).player, share.amount);
  }
  return shares;
}

export function registerRpgStats(onPlayerKill){
  world.afterEvents.entityDie.subscribe(ev=>{
    try{
      let killer=ev.damageSource?.damagingEntity;
      killer=pvpOwner(killer);
      if(killer?.typeId!=='minecraft:player')killer=ev.damageSource?.damagingProjectile?.getComponent('minecraft:projectile')?.owner;
      if(killer?.typeId!=='minecraft:player')killer=scriptKiller(ev.deadEntity);
      if(ev.deadEntity?.typeId==='minecraft:player'){if(killer?.typeId==='minecraft:player')try{recordTrialKillExtras(killer,ev.deadEntity);}catch{}recordPvpDeath(killer,ev.deadEntity);return;}
      if(killer?.typeId!=='minecraft:player')return;
      try{recordTrialKillExtras(killer,ev.deadEntity);}catch(error){console.warn('[RPG new trials] '+String(error));}
      const reward=killReward(ev.deadEntity);
      if(reward>0)distributeKillXp(killer,reward);
      try {grantKillCurrencies(killer,ev.deadEntity);} catch(error) {console.warn('[RPG economy] '+String(error));}
      try{awardPartyTrialKill(killer,ev.deadEntity);}catch(error){console.warn('[RPG job trials] '+String(error));}
      // Intro objectives credit the killer only, independently of shared XP.
      if (typeof onPlayerKill === 'function') onPlayerKill(killer, ev.deadEntity);
    }catch{}
  });
  try{
    world.beforeEvents.entityHurt?.subscribe(ev=>{
      try{
        const victim=ev.hurtEntity;
        if(victim?.typeId!=='minecraft:player')return;
        ev.damage = Math.max(0, ev.damage * (1 - levelDefenseReduction(victim)));
      }catch{}
    });
  }catch{}
  system.runInterval(()=>{
    for(const p of world.getAllPlayers()){
      applyVitality(p);
    }
  },REGEN_HEALTH_REFRESH);
}
