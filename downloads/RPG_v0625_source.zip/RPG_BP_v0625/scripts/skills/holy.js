import {sunDamageMultiplier} from '../core/races.js';
import {isTrialTarget} from '../core/jobTrials.js';
import {setCombatHealth} from '../core/combatContext.js';
import {scriptedHit,noteManualDamage,rememberScriptKiller,setManualDamageMultiplier} from '../core/combatContext.js';
import {isBloodSpearHit} from './blood.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import {healHolyAlly,applyHolyRegeneration} from '../core/holyRecovery.js';
import {isHealingAlly} from '../core/supportAllies.js';
import { hasBorrowedSkill } from '../core/skillAccess.js';
import { healingFor } from "../core/stats.js";
import { recordHealedPlayer } from '../core/jobQuests.js';
import { areAllies } from "../core/social.js";
import { system, world, ItemStack } from "@minecraft/server";
import {
  getTargets, hurt as hurtBase, knockback, particle, sound, dist3, norm3, headPos, isSolidAt, healthAlive,
  firstTargetInView,
} from "../core/util.js";
import { CONFIG } from "../config.js";
import { notify } from "../core/hud.js";
import {
  addProgress, getJobId, getMana, setMana, cooldownLeft, startCooldown,
} from "../core/playerData.js";

// ---------------------------------------------------------------------------
// 성직자 계열 스킬. 모든 이펙트는 파티클이라 블록에는 아무 영향이 없습니다.
// 지원 버프는 본인·아군 전용. 단일 힐만 적에게도 사용할 수 있습니다.
// ---------------------------------------------------------------------------

const HOLY = ["minecraft:endrod"];
const CURSE = ["minecraft:redstone_ore_dust_particle", "minecraft:soul_particle"];

function fx(dim, ids, pos) {
  for (const id of ids) particle(dim, id, pos);
}

function ring(dim, center, r, ids, dy = 0.2, n = 28) {
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    fx(dim, ids, { x: center.x + Math.cos(a) * r, y: center.y + dy, z: center.z + Math.sin(a) * r });
  }
}

function pillar(dim, pos, ids, h = 3) {
  for (let y = 0; y <= h; y += 0.5) fx(dim, ids, { x: pos.x, y: pos.y + y, z: pos.z });
}

export function holyMonsterDamage(caster,target,amount,scaled=true){
 if(!target||target.typeId==='minecraft:player'||isHealingAlly(caster,target)||!isTrialTarget(target.typeId)||!healthAlive(target))return false;
 return hurtBase(target,caster,(scaled?healingFor(caster,amount):amount)*3,'fixed',{ignoreInvulnerability:true});
}
function healEntity(e,amount,caster){try{return healHolyAlly(caster,e,amount);}catch{return 0;}}

function addFx(e, id, ticks, amp = 0, showParticles = true) {
  try {
    applyStatus(e,id, ticks, { amplifier: amp, showParticles });
  } catch {
    // 효과를 받을 수 없는 대상
  }
}

// center 주변의 아군(플레이어, 시전자 포함)
function alliesAround(player, center, radius) {
  const out = new Map();
  out.set(player.id, player);
  try {
    const query={location:center,maxDistance:radius};
    for (const p of [...(player.dimension.getPlayers?.(query)??[]),...(player.dimension.getEntities?.(query)??[])]) {
      if (healthAlive(p) && isHealingAlly(player,p)) out.set(p.id, p);
    }
  } catch {
    // 무시
  }
  return [...out.values()];
}

// 적 = getTargets (시전자 제외, PvP 설정을 따름). 아군 플레이어는 제외합니다.
function enemiesAround(player, center, radius, bodyOffset = 0) {
  return getTargets(player, center, radius, bodyOffset).filter(e=>!isHealingAlly(player,e));
}

function viewShot(player) {
  const d = norm3(player.getViewDirection());
  const h = headPos(player);
  return { d, origin: { x: h.x + d.x, y: h.y - 0.2 + d.y, z: h.z + d.z } };
}

// 날아가는 구슬. 적/벽에 닿거나 사거리가 끝나면 onImpact.
function flyOrb(player, o) {
  const dim = player.dimension;
  let pos = { ...o.origin };
  const dir = norm3(o.dir);
  let dist = 0;
  const id = system.runInterval(() => {
    try {
      const next = {
        x: pos.x + dir.x * o.speed, y: pos.y + dir.y * o.speed, z: pos.z + dir.z * o.speed,
      };
      dist += o.speed;
      if (isSolidAt(dim, next)) {
        system.clearRun(id);
        o.onImpact(pos);
        return;
      }
      pos = next;
      fx(dim, o.trail, pos);
      const hits = getTargets(player, pos, o.hitRadius, 0.9);
      if (hits.length > 0) {
        system.clearRun(id);
        o.onImpact(pos);
        return;
      }
      if (dist >= o.range) {
        system.clearRun(id);
        o.onImpact(pos);
      }
    } catch {
      system.clearRun(id);
    }
  }, 1);
}

// 일정 시간 동안 interval 틱마다 tick(count)를 부르는 영역
function zone(player, duration, interval, tick) {
  let t = 0;
  const id = system.runInterval(() => {
    try {
      tick(t);
      t += interval;
      if (t >= duration) system.clearRun(id);
    } catch {
      system.clearRun(id);
    }
  }, interval);
}

// ---- 상태 (메모리) ----
const curseShield = new Map(); // playerId -> 끝나는 틱
let reflecting = false;

function blessCount() {
  // (이전 전직 조건용 카운터 — 지금은 사용하지 않음)
}

// ---- 축복의 구슬: 성직자 1명당 대상 1명에게만 부착 ----
const orbs = new Map(); // casterId -> { player, target, runId }

// 직업별 표시 단계 표에서 값을 꺼냄 (없으면 fallback)
function lvl(table, job, fallback = 1) {
  return table?.[job.id] ?? fallback;
}

function detachOrb(casterId, msg) {
  const o = orbs.get(casterId);
  if (!o) return;
  orbs.delete(casterId);
  system.clearRun(o.runId);
  for (const id of ["regeneration", "speed", "absorption"]) {
    try {
      o.target.removeEffect(id);
    } catch {
      // 이미 사라진 대상
    }
  }
  try {
    o.player.removeEffect("hunger");
  } catch {
    // 이미 나간 플레이어
  }
  if (msg) notify(o.player, msg);
}

// One curse per caster; multiple casters never stack the vulnerability multiplier.
const curseOrbs=new Map();
function curseValid(o){try{return healthAlive(o.player)&&healthAlive(o.target)&&o.player.isValid!==false&&o.target.isValid!==false&&o.player.dimension.id===o.target.dimension.id&&dist3(o.player.location,o.target.location)<o.def.maxDistance&&!isHealingAlly(o.player,o.target)&&(CONFIG.pvp||o.target.typeId!=="minecraft:player");}catch{return false;}}
function detachCurseOrb(id){const o=curseOrbs.get(id);if(o){system.clearRun(o.runId);curseOrbs.delete(id);}}
function attachCurseOrb(player,target,def){
 const o={player,target,def,runId:0};if(!curseValid(o))return false;
 detachCurseOrb(player.id);
 hurt(target,player,def.damage);curseOrbs.set(player.id,o);
 addFx(target,"wither",def.duration,def.witherAmp);
 o.runId=system.runInterval(()=>{
  if(!curseValid(o)){detachCurseOrb(player.id);return;}
  const p=target.location;fx(target.dimension,CURSE,{x:p.x,y:p.y+2.5,z:p.z});
 },2);return true;
}
export function curseVulnerability(target){let rate=0;for(const [id,o]of curseOrbs){if(!curseValid(o)){detachCurseOrb(id);continue;}if(o.target.id===target.id)rate=Math.max(rate,o.def.vulnerability);}return rate;}
function amplifyCurseHit(ev){
 // The spear native hit is replaced by its own scripted hit, which is amplified once.
 if(isBloodSpearHit(ev))return;
 const target=ev.hurtEntity,rate=curseVulnerability(target);if(!rate||!(ev.damage>0))return;
 const hp=target.getComponent("minecraft:health"),source=ev.damageSource?.damagingEntity;
 if(!hp||hp.currentValue<=0)return;
 scriptedHit(target,source,()=>{const extra=Math.min(hp.currentValue,ev.damage*rate);if(extra>=hp.currentValue&&source)rememberScriptKiller(source,target);setCombatHealth(target,source,hp,Math.max(0,hp.currentValue-extra));noteManualDamage(source,target,extra,{incomingScaled:true});return true;});
}

// 기도로 받는 축복의 빛 개수
const PRAY_LIGHT = { cleric: 1, angel: 2, michael: 3 };
const PRAY_KEY = "rpg:pray_day";

function giveItem(player, id, n) {
  const c = player.getComponent("minecraft:inventory")?.container;
  const stack = new ItemStack(id, n);
  const left = c?.addItem(stack);
  if (left) player.dimension.spawnItem(left, player.location);
}

// ---------------------------------------------------------------------------
export const RUNNERS = {
  // ---------- 성직자 ----------
  // 아이템으로 엔티티를 좌클릭(타격)하면 발동: 맞은 엔티티의 체력을 직업별 하트 칸 수만큼 즉시 회복
  holy_heal(player, job, def, target) {
    if (!healthAlive(target)) return false;
    // 단일 힐은 예외적으로 적에게도 사용 가능. 적 치유는 아군 기여로 계산하지 않음.
    const dim = player.dimension;
    const hearts = def.healByJob[job.id] ?? 2;
    if(isHealingAlly(player,target))healEntity(target,hearts*2,player);
    else if(!holyMonsterDamage(player,target,hearts*2))return false;
    const l = target.location;
    particle(dim, "minecraft:heart_particle", { x: l.x, y: l.y + 2, z: l.z });
    ring(dim, l, 1, HOLY, 0.2, 12);
    sound(dim, "random.orb", l, { volume: 0.8, pitch: 1.2 });
    addProgress(player, "heals");
  },

  holy_shield(player, job, def) {
    const dim = player.dimension;
    for (const a of alliesAround(player, player.location, def.radius)) {
      addFx(a, "absorption", def.duration, def.absorption);
      addFx(a, "resistance", def.duration, lvl(def.resistanceByJob, job) - 1);
      pillar(dim, a.location, HOLY, 2);
    }
    ring(dim, player.location, 2.5, HOLY, 1.0, 20);
    sound(dim, "random.anvil_use", player.location, { volume: 0.5, pitch: 1.6 });
  },

  holy_sword(player, job, def) {
    const dim = player.dimension;
    for (const a of alliesAround(player, player.location, def.radius)) {
      addFx(a, "strength", def.duration, lvl(def.strengthByJob, job) - 1);
      pillar(dim, a.location, ["minecraft:villager_happy"], 2);
    }
    ring(dim, player.location, 2.5, HOLY, 1.0, 20);
    sound(dim, "random.levelup", player.location, { volume: 0.6, pitch: 1.4 });
  },

  // 좌클릭으로 엔티티에 부착. 1명에게만 쓸 수 있고, 성직자와 def.maxDistance 칸 넘게 떨어지면 사라집니다.
  // 붙어 있는 동안: 성직자는 허기 / 대상은 재생 + 신속 + 흡수 (전직할수록 1단계씩 증가)
  holy_orb(player, job, def, target) {
    // 축복 구슬은 아군 대상 지원기. 같은 길드 또는 파티가 아니면 발동 불가.
    if (target.id === player.id || target.typeId !== "minecraft:player" ||
        !healthAlive(target) || !areAllies(player, target)) return false;
    if (orbs.has(player.id)) {
      notify(player, "§7축복의 구슬은 한 명에게만 쓸 수 있습니다.");
      return false;
    }
    const regenAmp = lvl(def.regenByJob, job, 2) - 1;
    const speedAmp = lvl(def.speedByJob, job, 2) - 1;
    const absorbAmp = lvl(def.absorbByJob, job, 8) - 1;
    const hungerAmp = def.hunger - 1;
    const dim = player.dimension;

    const entry = { player, target, runId: 0 };
    orbs.set(player.id, entry);
    // 흡수는 한 번만 걸고(갱신하면 계속 차오르므로), 떨어질 때 직접 지웁니다.
    addFx(target, "absorption", 6000, absorbAmp, false);
    sound(dim, "random.orb", target.location, { volume: 0.8, pitch: 1.4 });
    notify(player, "§e축복의 구슬을 부착했습니다.");

    let n = 0;
    entry.runId = system.runInterval(() => {
      try {
        // 대상 머리 위에 떠 있는 구슬 (2틱마다 갱신)
        let hy = target.location.y + 1.8;
        try {
          hy = target.getHeadLocation().y;
        } catch {
          // 머리 위치를 못 읽으면 대략적인 높이 사용
        }
        const cx = target.location.x;
        const cz = target.location.z;
        const cy = hy + 0.9;
        // One short-lived sprite above the head: no halo, totem spray or link beam.
        particle(dim, "rpg:holy_blessing_orb", { x: cx, y: cy, z: cz });

        n++;
        if (n % 5 !== 1) return; // 아래는 10틱마다

        const holyJob = ["cleric", "angel", "michael"].includes(getJobId(player)) || hasBorrowedSkill(player,"holy_orb");
        if (!holyJob || !healthAlive(player) || !healthAlive(target) || !areAllies(player, target)) {
          detachOrb(player.id, "§7축복의 구슬이 사라졌습니다.");
          return;
        }
        if (target.dimension.id !== player.dimension.id || dist3(player.location, target.location) > def.maxDistance) {
          detachOrb(player.id, `§7축복의 구슬이 사라졌습니다. (${def.maxDistance}칸 이상 멀어짐)`);
          return;
        }
        applyHolyRegeneration(player,target,40,regenAmp);
        addFx(target, "speed", 40, speedAmp, false);
        addFx(player, "hunger", 40, hungerAmp, false);

      } catch {
        detachOrb(player.id);
      }
    }, 2);
  },

  // 기도: 게임 시간 하루에 1번. 10초간 실명 + 움직일 수 없고, 끝나면 축복의 빛을 받습니다.
  // (성직자 1개 / 천사 2개 / 미카엘 3개)
  holy_pray(player, job, def) {
    const day = world.getDay();
    if (player.getDynamicProperty(PRAY_KEY) === day) {
      notify(player, "§7오늘은 이미 기도했습니다. 내일 다시 기도할 수 있습니다.");
      return false;
    }
    player.setDynamicProperty(PRAY_KEY, day);
    const dim = player.dimension;
    const n = PRAY_LIGHT[job.id] ?? 1;
    try {
      applyStatus(player,"blindness", def.duration, { amplifier: 0, showParticles: false });
      applyStatus(player,"slowness", def.duration, { amplifier: 6, showParticles: false });
      applyStatus(player,"jump_boost", def.duration, { amplifier: 128, showParticles: false });
    } catch {
      // 효과를 걸 수 없는 경우
    }
    sound(dim, "beacon.activate", player.location, { volume: 1, pitch: 1.0 });
    notify(player, "§e기도하는 중입니다...");
    let t = 0;
    const id = system.runInterval(() => {
      try {
        t += 10;
        const p = player.location;
        ring(dim, p, 1.2 + (t % 40) / 40, HOLY, 0.2 + (t / def.duration) * 2.5, 16);
        pillar(dim, p, HOLY, 3);
        if (t < def.duration) return;
        system.clearRun(id);
        giveItem(player, "rpg:blessing_light", n);
        particle(dim, "minecraft:totem_particle", { x: p.x, y: p.y + 1, z: p.z });
        sound(dim, "random.totem", p, { volume: 0.8, pitch: 1.3 });
        notify(player, `§e기도가 끝났습니다. §6축복의 빛 ${n}개§e를 받았습니다.`);
      } catch {
        system.clearRun(id);
      }
    }, 10);
  },

  // ---------- 천사 ----------
  angel_bless(player, job, def) {
    const dim = player.dimension;
    for (const a of alliesAround(player, player.location, def.radius)) {
      healEntity(a, def.heal, player);
      applyHolyRegeneration(player,a,def.duration,def.regen);
      addFx(a, "resistance", def.duration, def.resistance);
      addFx(a, "speed", def.duration, def.speed);
      try {
        a.removeEffect("wither");
        a.removeEffect("poison");
        a.removeEffect("weakness");
      } catch {
        // 효과 없음
      }
      pillar(dim, a.location, HOLY, 4);
      particle(dim, "minecraft:totem_particle", { x: a.location.x, y: a.location.y + 1, z: a.location.z });
    }
    for(const t of enemiesAround(player,player.location,def.radius))holyMonsterDamage(player,t,def.heal);
    ring(dim, player.location, def.radius * 0.5, HOLY, 0.3, 36);
    sound(dim, "random.totem", player.location, { volume: 1, pitch: 1.2 });
    blessCount(player);
  },

  angel_zone(player, job, def) {
    const dim = player.dimension;
    const center = { ...player.location };
    sound(dim, "beacon.activate", center, { volume: 0.8, pitch: 1.2 });
    zone(player, def.duration, 20, () => {
      ring(dim, center, def.radius, HOLY, 0.2, 36);
      ring(dim, center, def.radius * 0.5, ["minecraft:villager_happy"], 0.5, 12);
      for (const a of alliesAround(player, center, def.radius)) {
        if (dist3(a.location, center) > def.radius) continue;
        healEntity(a, def.heal, player);
        applyHolyRegeneration(player,a,40,Math.max(4,def.regen??4));
        addFx(a, "resistance", 40, 0);
      }
      for (const t of enemiesAround(player, center, def.radius)) {
        // enemiesAround already excludes party/guild/team allies.
        if (dist3(t.location, center) > def.radius) continue;
        holyMonsterDamage(player,t,def.heal);
        addFx(t, "slowness", 40, def.slowAmp);
      }
    });
    blessCount(player);
  },

  // ---------- 타락천사 ----------
  // 적을 좌클릭(타격)하면 발동: 상대에게 하트 8칸 피해 (다른 효과 없음)
  fallen_sacrifice(player, job, def, target) {
    if (target.id === player.id || !healthAlive(target) || areAllies(player, target)) return false;
    if (!CONFIG.pvp && target.typeId === "minecraft:player") return false;
    const dim = player.dimension;
    hurt(target, player, def.damage);
    pillar(dim, target.location, CURSE, 3);
    particle(dim, "minecraft:huge_explosion_emitter", target.location);
    sound(dim, "mob.wither.hurt", target.location, { volume: 0.7, pitch: 0.8 });
  },

  // 앞으로 뻗는 파멸의 검기: 닿는 모든 적에게 피해 + 위더
  fallen_sword(player, job, def) {
    const dim = player.dimension;
    const { d, origin } = viewShot(player);
    const hit = new Set();
    sound(dim, "mob.wither.shoot", player.location, { volume: 0.8, pitch: 0.8 });
    for (let t = 0; t <= def.range; t += 0.8) {
      const p = { x: origin.x + d.x * t, y: origin.y + d.y * t, z: origin.z + d.z * t };
      if (isSolidAt(dim, p)) break;
      particle(dim, "rpg:fallen_sword_saint_slash", p);
      particle(dim, "minecraft:redstone_ore_dust_particle", p);
      for (const e of getTargets(player, p, def.width, 0.9)) {
        if (hit.has(e.id)) continue;
        hit.add(e.id);
        hurt(e, player, def.damage);
        addFx(e, "wither", def.witherTicks, def.wither);
        knockback(e, d.x, d.z, 0.8, 0.3);
      }
    }
  },

  // 방패 지속 시간 동안 받은 피해의 일부를 공격자에게 되돌려줌
  fallen_shield(player, job, def) {
    addFx(player, "resistance", def.duration, def.resistance);
    curseShield.set(player.id, { until: system.currentTick + def.duration, def });
    pillar(player.dimension, player.location, CURSE, 2);
    ring(player.dimension, player.location, 1.5, CURSE, 1.0, 16);
    sound(player.dimension, "mob.wither.ambient", player.location, { volume: 0.4, pitch: 1.4 });
  },

  fallen_curse(player, job, def) {
    const t = firstTargetInView(player, def.range);
    if (!t) {
      notify(player, "§7시선 앞에 대상이 없습니다.");
      return false;
    }
    const dim = player.dimension;
    hurt(t, player, def.damage);
    addFx(t, "wither", def.duration, 2);
    addFx(t, "weakness", def.duration, 1);
    addFx(t, "slowness", def.duration, 1);
    pillar(dim, t.location, CURSE, 3);
    sound(dim, "mob.wither.hurt", t.location, { volume: 0.7, pitch: 0.8 });
  },

  fallen_orb(player, job, def, target) {
    if(target)return attachCurseOrb(player,target,def);
    const dim=player.dimension,{d,origin}=viewShot(player);
    sound(dim,"mob.wither.shoot",player.location,{volume:.6,pitch:1.2});
    flyOrb(player,{origin,dir:d,speed:def.speed,range:Math.min(def.range,def.maxDistance-1),hitRadius:def.hitRadius,trail:CURSE,
      onImpact(pos){const t=enemiesAround(player,pos,def.hitRadius+1,.9).find(t=>dist3(player.location,t.location)<def.maxDistance);if(t)attachCurseOrb(player,t,def);}
    });
  },

  fallen_zone(player, job, def) {
    const dim = player.dimension;
    const center = { ...player.location };
    sound(dim, "mob.wither.ambient", center, { volume: 0.8, pitch: 0.7 });
    zone(player, def.duration, 20, () => {
      ring(dim, center, def.radius, CURSE, 0.2, 36);
      ring(dim, center, def.radius * 0.5, CURSE, 0.5, 14);
      for (const t of enemiesAround(player, center, def.radius)) {
        if (dist3(t.location, center) > def.radius) continue;
        hurt(t, player, def.damage);
        addFx(t, "wither", 40, 0);
        addFx(t, "slowness", 40, 1);
      }
    });
  },

  // 궁극기: 종말이 타천을 따라다니며 내부의 적을 사슬로 묶고(타천 제외 구속 1),
  // 힘을 다 모으면 반경 전체에 종말을 내립니다. (블록은 파괴하지 않음)
  fallen_end(player, job, def) {
    let dim = player.dimension;
    let center = { ...player.location };
    addFx(player, "resistance", def.charge + 40, 4);
    sound(dim, "mob.wither.spawn", center, { volume: 1.2, pitch: 0.6 });
    let t = 0;
    const id = system.runInterval(() => {
      try {
        if (!healthAlive(player)) {
          system.clearRun(id);
          return;
        }
        t += 2;
        dim = player.dimension;
        center = { ...player.location }; // 타천이 움직이면 종말도 같이 움직임
        const r = (t / def.charge) * def.radius;
        ring(dim, center, Math.min(r, def.radius), CURSE, 0.3, 40);
        pillar(dim, center, CURSE, 6);

        // 내부의 적을 사슬로 묶고 구속 1
        if (t % 4 === 0) {
          const from = { x: center.x, y: center.y + 1, z: center.z };
          let n = 0;
          for (const e of enemiesAround(player, center, def.radius)) {
            if (dist3(e.location, center) > def.radius) continue;
            addFx(e, "slowness", 10, def.chargeSlowAmp ?? 0);
            if (n++ >= 16) continue; // 사슬 이펙트는 최대 16개까지만 그림
            const to = { x: e.location.x, y: e.location.y + 1, z: e.location.z };
            const steps = Math.max(1, Math.floor(dist3(from, to) / 1.2));
            for (let i = 1; i < steps; i++) {
              const k = i / steps;
              fx(dim, CURSE, {
                x: from.x + (to.x - from.x) * k, y: from.y + (to.y - from.y) * k, z: from.z + (to.z - from.z) * k,
              });
            }
          }
        }

        if (t < def.charge) return;
        system.clearRun(id);

        sound(dim, "random.explode", center, { volume: 2, pitch: 0.5 });
        sound(dim, "mob.wither.death", center, { volume: 1.5, pitch: 0.8 });
        particle(dim, "minecraft:huge_explosion_emitter", center);
        for (let i = 0; i < 10; i++) {
          const a = (i / 10) * Math.PI * 2;
          const rr = def.radius * 0.6;
          const p = { x: center.x + Math.cos(a) * rr, y: center.y + 0.5, z: center.z + Math.sin(a) * rr };
          particle(dim, "minecraft:huge_explosion_emitter", p);
          pillar(dim, p, CURSE, 8);
        }
        for (const e of enemiesAround(player, center, def.radius)) {
          hurt(e, player, def.damage);
          addFx(e, "wither", 100, 2);
          knockback(e, e.location.x - center.x, e.location.z - center.z, 1.2, 0.5);
          pillar(dim, e.location, CURSE, 4);
        }
      } catch {
        system.clearRun(id);
      }
    }, 2);
  },
};

// ---------------------------------------------------------------------------
// 패시브 / 이벤트
//  - 미카엘 '불사': 체력이 크게 떨어지면 한 번 완전히 회복하고 잠깐 무적에 가까워짐 (쿨타임 있음)
//  - 저주의 방패: 받은 피해의 일부를 공격자에게 반사
// ---------------------------------------------------------------------------
const UNDYING_KEY = "michael_undying";
const UNDYING_COOLDOWN = 1200; // 60초
const UNDYING_THRESHOLD = 6; // 체력이 이 이하로 떨어지면 발동 (하트 3칸)

function checkUndying(p) {
  try {
    if (getJobId(p) !== "michael") return;
    const hp = p.getComponent("minecraft:health");
    if (!hp || hp.currentValue <= 0 || hp.currentValue > UNDYING_THRESHOLD) return;
    if (cooldownLeft(p, UNDYING_KEY) > 0) return;
    startCooldown(p, UNDYING_KEY, UNDYING_COOLDOWN);
    hp.setCurrentValue(hp.effectiveMax);
    addFx(p, "resistance", 80, 4);
    addFx(p, "regeneration", 100, 2);
    addFx(p, "fire_resistance", 100, 0);
    const dim = p.dimension;
    particle(dim, "minecraft:totem_particle", { x: p.location.x, y: p.location.y + 1, z: p.location.z });
    pillar(dim, p.location, HOLY, 4);
    ring(dim, p.location, 3, HOLY, 0.5, 24);
    sound(dim, "random.totem", p.location, { volume: 1, pitch: 1 });
    notify(p, "§e불사: 죽음을 거부했습니다.");
  } catch {
    // 플레이어 상태를 읽을 수 없음
  }
}

const BAD_EFFECTS = [
  "slowness", "mining_fatigue", "nausea", "blindness", "hunger", "weakness", "poison",
  "wither", "levitation", "darkness", "fatal_poison", "bad_omen", "infested", "oozing", "weaving", "wind_charged",
];

// 성수: 모든 직업이 쓸 수 있음. 디버프 제거 + 10초간 재생 2
function drinkHolyWater(p) {
  try {
    for (const e of p.getEffects()) {
      if (BAD_EFFECTS.includes(e.typeId)) p.removeEffect(e.typeId);
    }
  } catch {
    // 효과 목록을 읽을 수 없음
  }
  addFx(p, "regeneration", 200, 1);
  particle(p.dimension, "minecraft:totem_particle", { x: p.location.x, y: p.location.y + 1, z: p.location.z });
  pillar(p.dimension, p.location, HOLY, 3);
  sound(p.dimension, "random.orb", p.location, { volume: 0.8, pitch: 1.2 });
}

export function registerHoly() {
  setManualDamageMultiplier(target=>(1+curseVulnerability(target))*sunDamageMultiplier(target));
  world.afterEvents.playerLeave.subscribe((ev) => {detachOrb(ev.playerId);detachCurseOrb(ev.playerId);});

  world.afterEvents.itemCompleteUse?.subscribe((ev) => {
    if (ev.itemStack?.typeId === "rpg:holy_water" && ev.source?.typeId === "minecraft:player") {
      drinkHolyWater(ev.source);
    }
  });

  world.afterEvents.entityHurt.subscribe((ev) => {
    amplifyCurseHit(ev);
    const victim = ev.hurtEntity;
    if (victim?.typeId !== "minecraft:player") return;

    checkUndying(victim);

    // 저주의 방패 반사
    const s = curseShield.get(victim.id);
    if (!s || s.until <= system.currentTick || reflecting) return;
    const attacker = ev.damageSource?.damagingEntity;
    if (!attacker || attacker.id === victim.id || !healthAlive(attacker)) return;
    reflecting = true;
    try {
      hurt(attacker, victim, Math.max(1, ev.damage * s.def.reflect));
      addFx(attacker, "wither", s.def.witherTicks, 0);
      particle(victim.dimension, "minecraft:redstone_ore_dust_particle", {
        x: attacker.location.x, y: attacker.location.y + 1, z: attacker.location.z,
      });
    } finally {
      reflecting = false;
    }
  });

  // 큰 피해를 연속으로 받는 경우를 대비해 짧은 주기로도 확인
  system.runInterval(() => {
    for (const p of world.getAllPlayers()) checkUndying(p);
  }, 2);
}

// Borrowed spells use MAG just like their original spell class.
function hurt(target,source,amount,type="magic"){return hurtBase(target,source,amount,type);}
