import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve('.'),rp=path.join(root,'RPG_RP_v0576'),bp=path.join(root,'RPG_BP_v0576');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const pose=read(path.join(root,'held_weapon_pose.json'));
const animations=read(path.join(rp,'animations/native_weapons.animation.json')).animations;
const stock=read(path.join(root,'vanilla_player_client_base.json'));
const player=read(path.join(rp,'entity/player.entity.json'));
const eps=1e-7,near=(a,b)=>a.forEach((v,i)=>assert.ok(Math.abs(v-b[i])<eps,`${a} != ${b}`));
function rotate(v,native){
 const [a,b,c]=[-native[0],-native[1],native[2]].map(x=>x*Math.PI/180);
 let [x,y,z]=v;[y,z]=[y*Math.cos(a)-z*Math.sin(a),y*Math.sin(a)+z*Math.cos(a)];
 [x,z]=[x*Math.cos(b)+z*Math.sin(b),-x*Math.sin(b)+z*Math.cos(b)];
 return [x*Math.cos(c)-y*Math.sin(c),x*Math.sin(c)+y*Math.cos(c),z];
}
test('all 39 visible RPG items use the real native handheld renderer',()=>{
 assert.equal(pose.mode,'native_handheld');assert.equal(pose.items.length,39);assert.equal(new Set(pose.items).size,39);
 for(const id of pose.items)for(const pack of [rp,bp]){
  const file=path.join(pack,'items',id.slice(4)+'.json');if(pack===rp&&!fs.existsSync(file))continue;
  const c=read(file)['minecraft:item'].components;
  assert.equal(c['minecraft:hand_equipped'],true);assert.equal(c['minecraft:render_offsets'],undefined);
 }
});
test('replacement hand meshes and attachables cannot override native item placement',()=>{
 for(const name of fs.readdirSync(path.join(rp,'attachables'))){const id=read(path.join(rp,'attachables',name))['minecraft:attachable'].description.identifier;assert.ok(!pose.items.includes(id),name);}
 for(const f of ['models/entity/upright_weapons.geo.json','animations/upright_weapons.animation.json','animations/held_weapons.animation.json'])assert.equal(fs.existsSync(path.join(rp,f)),false,f);
});
test('the Mojang player definition, skins, rendering and native animations remain intact',()=>{
 const modified=structuredClone(player),desc=modified['minecraft:client_entity'].description;
 for(const key of ['rpg_native_weapon_first','rpg_native_weapon_third'])delete desc.animations[key];
 const extra=desc.scripts.animate.splice(-2);assert.equal(extra.length,2);assert.deepEqual(modified,stock);
 assert.equal(player['minecraft:client_entity'].description.enable_attachables,true);
});
test('the adjustment only animates the hand item with a ten-degree delta and 2x scale',()=>{
 assert.equal(pose.additionalRollDegrees,-10);assert.equal(pose.heldScale,2);
 for(const [name,anim]of Object.entries(animations)){
  assert.equal(anim.override_previous_animation,undefined);assert.deepEqual(Object.keys(anim.bones),['rightItem']);
  const bone=anim.bones.rightItem;assert.equal(bone.position,undefined);assert.equal(bone.scale,2);
  const r=bone.rotation;const ex=rotate([1,0,0],r),ey=rotate([0,1,0],r),ez=rotate([0,0,1],r);
  const angle=Math.acos(Math.max(-1,Math.min(1,(ex[0]+ey[1]+ez[2]-1)/2)))*180/Math.PI;
  assert.ok(Math.abs(angle-10)<1e-6,name);
 }
});
test('selectors affect only held RPG items and keep vanilla swords, private fists, and off-hand items untouched',()=>{
 const desc=player['minecraft:client_entity'].description;
 for(const mode of ['first','third']){
  const alias='rpg_native_weapon_'+mode;
  assert.equal(desc.animations[alias],'animation.rpg.native_weapon.'+mode);
  const condition=desc.scripts.animate.find(x=>typeof x==='object'&&x[alias])?.[alias];assert.ok(condition);
  const selected=[...condition.matchAll(/'(rpg:[^']+)'/g)].map(m=>m[1]);assert.deepEqual(selected,pose.items);
  assert.ok(condition.includes("'slot.weapon.mainhand'"));assert.ok(!condition.includes('offhand'));
  assert.ok(condition.endsWith(mode==='first'?'&& variable.is_first_person':'&& !variable.is_first_person'));
  assert.ok(condition.includes('!variable.is_paperdoll')&&condition.includes('!variable.map_face_icon'));
  for(const id of ['minecraft:iron_sword','minecraft:diamond_sword','rpg:war_god_gauntlets','rpg:fighter_fist','rpg:fist_bone_fist','rpg:apprentice_fist'])assert.ok(!selected.includes(id));
 }
});
test('the extra ten degrees compose with any native sword pose instead of replacing its baseline',()=>{
 const nativeVectors=[[1,0,0],[0,1,0],[0,0,1],[.7,.7,0],[-.3,.4,.8]];
 for(const mode of ['first','third']){
  const parent=mode==='first'?pose.firstParentNative:pose.thirdParentNative;
  const delta=animations['animation.rpg.native_weapon.'+mode].bones.rightItem.rotation;
  for(const v of nativeVectors){
   const baseline=rotate(v,parent),expected=rotate(baseline,[0,0,-10]);
   const actual=rotate(rotate(v,delta),parent);near(actual,expected);
  }
 }
});
test('original common icons and all 39 native-rendered PNGs remain exact',()=>{
 const profiles=read(path.join(root,'weapon_hand_profiles.json')).items;
 assert.deepEqual(new Set(profiles.map(s=>s.id)),new Set(pose.items));
 for(const spec of profiles)assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(rp,spec.texture+'.png'))).digest('hex'),spec.sha256);
 for(const r of read(path.join(root,'original_weapon_texture_mapping.json')))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(rp,'textures/items/common_weapons',r.target))).digest('hex'),r.sha256);
});
test('War God privacy and the invisible fist attachables are preserved separately',()=>{
 const gauntlet=read(path.join(rp,'attachables/war_god_gauntlets.json'));
 assert.match(JSON.stringify(gauntlet),/context.is_first_person/);
 assert.deepEqual(read(path.join(rp,'models/entity/war_god_private.geo.json'))['minecraft:geometry'][0].bones[0].cubes[0].size,[16,16,.2]);
 for(const id of ['fighter_fist','fist_bone_fist','apprentice_fist'])assert.ok(fs.existsSync(path.join(rp,'attachables',id+'.entity.json')));
});
