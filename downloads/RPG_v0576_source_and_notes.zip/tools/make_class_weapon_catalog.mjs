import fs from 'node:fs';
import {ALL_WEAPON_IDS} from '../RPG_BP_v0576/scripts/data/jobs.js';
const rows=[...new Set(ALL_WEAPON_IDS)].map(id=>{const item=JSON.parse(fs.readFileSync(`RPG_BP_v0576/items/${id.slice(4)}.json`))['minecraft:item'];return {id,name:item.components['minecraft:display_name']?.value??id,damage:item.components['minecraft:damage']??0};});
fs.writeFileSync('RPG_BP_v0576/scripts/data/classWeapons.js','// Class items have enhancement only; deliberately absent from itemRarity.\nexport const CLASS_WEAPONS=Object.freeze('+JSON.stringify(rows,null,2)+');\nexport const classWeapon=id=>CLASS_WEAPONS.find(w=>w.id===id);\n');
console.log(`Generated ${rows.length} class weapon definitions.`);
