import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,EquipmentSlot,HudVisibility,system,replies,forms} from './minecraftMock.mjs';
import {enhancementRates,rollEnhancement,CATALYST_ID,ARMOR_LEVEL_KEY,RUNE_LEVEL_KEY} from '../RPG_BP_v0568/scripts/data/upgrades.js';
import {enhanceEquipped,enhancementQuote,openUpgradeMenu} from '../RPG_BP_v0568/scripts/core/upgrades.js';
import {getWallet,setWallet} from '../RPG_BP_v0568/scripts/core/wallet.js';
import {RUNE_KEY} from '../RPG_BP_v0568/scripts/data/equipment.js';
import {getStats,allocateStat,forceSetLevel,applyVitality,STAT_MAX} from '../RPG_BP_v0568/scripts/core/stats.js';
import {healthText,updateHealthHud,resetHealthHud} from '../RPG_BP_v0568/scripts/core/healthHud.js';
import {refreshHud,notify} from '../RPG_BP_v0568/scripts/core/hud.js';

function ready(kind) {
  const p=player('risk-'+kind),item=new ItemStack('rpg:adventurer_chestplate');
  item.setDynamicProperty(ARMOR_LEVEL_KEY,kind==='armor'?9:7);
  item.setDynamicProperty(RUNE_KEY,'power');item.setDynamicProperty(RUNE_LEVEL_KEY,4);
  p.equipment.set(EquipmentSlot.Chest,item);setWallet(p,{gold:100000,stone:1000,dust:1000});
  return p;
}
test('all chance rows sum to 100 and worsening risks are explicit',()=>{
  for(const [kind,max] of [['armor',10],['rune',10]]) {
    let last;
    for(let level=0;level<max;level++) {
      const row=enhancementRates(kind,level);
      assert.equal(Object.values(row).reduce((a,b)=>a+b),100);
      if(last){assert.ok(row.success<=last.success);assert.ok(row.downgrade>=last.downgrade);assert.ok(row.destroy>=last.destroy);}
      last=row;
      const boosted=enhancementRates(kind,level,1);
      if(boosted){assert.equal(boosted.success,row.success+9);assert.equal(boosted.destroy,Math.max(0,row.destroy-3));assert.equal(Object.values(boosted).reduce((a,b)=>a+b),100);}
    }
    assert.equal(enhancementRates(kind,max),undefined);
  }
});
test('probability boundary rolls map to exactly one outcome; invalid randomness is rejected',()=>{
  const rates=enhancementRates('armor',9);
  for(const [roll,result] of [[0,'success'],[.149999,'success'],[.15,'fail'],[.49999,'fail'],[.50,'downgrade'],[.81999,'downgrade'],[.82,'destroy'],[.99999,'destroy']])assert.equal(rollEnhancement(rates,()=>roll),result);
  for(const roll of [-.1,1,NaN,Infinity])assert.throws(()=>rollEnhancement(rates,()=>roll));
});
test('success, unchanged failure and downgrade charge the same quoted cost',()=>{
  for(const kind of ['armor'])for(const [roll,outcome]of [[.1,'success'],[.3,'fail'],[.6,'downgrade']]) {
    const p=ready(kind),q=enhancementQuote(p,kind,EquipmentSlot.Chest);
    const result=enhanceEquipped(p,kind,EquipmentSlot.Chest,q.fingerprint,{random:()=>roll});
    assert.equal(result.ok,true);assert.equal(result.outcome,outcome);
    assert.equal(result.level,q.level+(outcome==='success'?1:outcome==='downgrade'?-1:0));
    assert.deepEqual(getWallet(p),{gold:100000-q.cost.gold,stone:1000-q.cost.stone,dust:1000-q.cost.dust});
  }
});
test('armor destruction removes armor but not independent rune bag',()=>{const p=ready('armor');const result=enhanceEquipped(p,'armor',EquipmentSlot.Chest,undefined,{random:()=>.99});assert.equal(result.outcome,'destroy');assert.equal(p.equipment.get(EquipmentSlot.Chest),undefined);});
test('catalyst improves outcomes, reduces destruction by 3 points, consumes one on any outcome',()=>{
  for(const kind of ['armor'])for(const roll of [.19,.4,.6,.99]) {
    const p=ready(kind);p.slots[3]=new ItemStack(CATALYST_ID,3);
    const result=enhanceEquipped(p,kind,EquipmentSlot.Chest,undefined,{catalystCount:1,random:()=>roll});
    assert.equal(result.ok,true);assert.equal(result.catalystCount,1);assert.equal(p.slots[3].amount,2);
    assert.equal(result.rates.destroy,15);
    if(roll===.19)assert.equal(result.outcome,'success');
    if(roll===.99)assert.equal(result.outcome,'destroy');
  }
});
test('catalyst is optional, cannot be spent below minimum, and missing catalyst never charges',()=>{
  const p=ready('armor'),before=getWallet(p);
  assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest,undefined,{catalystCount:1}).ok,false);
  assert.deepEqual(getWallet(p),before);
  p.slots[0]=new ItemStack(CATALYST_ID,1);p.equipment.get(EquipmentSlot.Chest).setDynamicProperty(ARMOR_LEVEL_KEY,4);
  assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest,undefined,{catalystCount:1}).ok,false);
  assert.equal(p.slots[0].amount,1);assert.deepEqual(getWallet(p),before);
  const result=enhanceEquipped(p,'armor',EquipmentSlot.Chest,undefined,{random:()=>0});
  assert.equal(result.ok,true);assert.equal(p.slots[0].amount,1);
});
test('high-level UI uses catalyst, displays adjusted risks and consumes a single-item stack',async()=>{
  const p=ready('armor');p.slots[0]=new ItemStack(CATALYST_ID,1);
  const original=Math.random;Math.random=()=>.99;
  try {
    replies.push({canceled:false,selection:0},{canceled:false,selection:1},{canceled:false,selection:1},{canceled:true});
    await openUpgradeMenu(p);
  } finally {Math.random=original;}
  assert.equal(p.slots[0],undefined);assert.equal(p.equipment.get(EquipmentSlot.Chest),undefined);
  const confirmation=forms.find(f=>f.heading==='위험 강화 확인');
  assert.match(confirmation.text,/성공 24%/);assert.match(confirmation.text,/파괴 15%/);
});
test('destructive attempt storage failure restores equipment, wallet and catalyst',()=>{
  const p=ready('armor');p.slots[0]=new ItemStack(CATALYST_ID,2);const wallet=getWallet(p);
  const read=p.getComponent.bind(p),eq=read('minecraft:equippable');let fail=true;
  p.getComponent=name=>name==='minecraft:equippable'?{...eq,setEquipment:(slot,item)=>{if(fail){fail=false;return false;}return eq.setEquipment(slot,item);}}:read(name);
  const result=enhanceEquipped(p,'armor',EquipmentSlot.Chest,undefined,{catalystCount:1,random:()=>.99});
  assert.equal(result.ok,false);assert.deepEqual(getWallet(p),wallet);assert.equal(p.slots[0].amount,2);
  assert.equal(p.equipment.get(EquipmentSlot.Chest).getDynamicProperty(ARMOR_LEVEL_KEY),9);
});
test('STR VIT MAG exceed old caps, INT stays capped and points remain required',()=>{
  assert.deepEqual(STAT_MAX,{str:null,vit:null,int:50,mag:null});
  const p=player('stats');forceSetLevel(p,1000);
  for(const stat of ['str','vit','mag'])assert.equal(allocateStat(p,stat,500).ok,true);
  assert.deepEqual(getStats(p),{str:505,vit:505,int:5,mag:505});
  assert.equal(allocateStat(p,'int',45).ok,true);assert.equal(allocateStat(p,'int',1).ok,false);
  assert.equal(allocateStat(p,'str',1.5).ok,false);assert.equal(allocateStat(p,'str',99999).ok,false);
  const reload=player('reload');reload.setDynamicProperty('rpg:stat_values',p.getDynamicProperty('rpg:stat_values'));
  assert.equal(getStats(reload).str,505);
});
test('extreme VIT keeps stored stat value and uses a valid native effect amplifier',()=>{
  const p=player('native-limit');forceSetLevel(p,100000);assert.equal(allocateStat(p,'vit',100000).ok,true);
  applyVitality(p);assert.equal(getStats(p).vit,100005);assert.equal(p.effects.get('health_boost').amplifier,255);
});
test('60 HP threshold is maximum health, hides only hearts and restores default below threshold',()=>{
  const p=player('threshold',1,{maxHealth:60});assert.equal(healthText(p),'');
  assert.equal(updateHealthHud(p).text,'');assert.deepEqual(p.hudChanges[0],{visibility:HudVisibility.Hide,elements:[1,11]});
  p.maxHealth=64;p.health=5;assert.equal(updateHealthHud(p).text,'§cHP 5/64§r');
  assert.deepEqual(p.hudChanges.at(-1),{visibility:HudVisibility.Hide,elements:[6]});
  updateHealthHud(p);assert.equal(p.hudChanges.length,2);
  p.maxHealth=60;assert.equal(updateHealthHud(p).text,'');assert.equal(p.hudChanges.at(-1).visibility,HudVisibility.Reset);
});
test('numeric HP is visible empty-handed and updates while notices are active',()=>{
  const p=player('empty',1,{maxHealth:80});refreshHud(p);assert.match(p.actionBars.at(-1),/HP 20\/80/);
  notify(p,'새로운 알림');p.health=12;system.currentTick++;refreshHud(p);
  assert.match(p.actionBars.at(-1),/HP 12\/80/);assert.match(p.actionBars.at(-1),/새로운 알림/);
  resetHealthHud(p);assert.equal(p.hudChanges.at(-1).visibility,HudVisibility.Reset);
});
