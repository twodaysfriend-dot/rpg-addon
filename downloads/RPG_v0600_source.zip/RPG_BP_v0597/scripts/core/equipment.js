import {itemGrade,ARMOR_GRADE_HP} from '../data/grades.js';
import {rarityBadge,armorRarity} from '../data/rarity.js';
import { world, system, EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { ARMOR_SETS, RUNES, RUNE_KEY, armorInfo } from '../data/equipment.js';
import { showForm } from './skillMenu.js';
import { RUNE_LEVEL_KEY, upgradeLevel, upgradedRune } from '../data/upgrades.js';
import { openUpgradeMenu } from './upgrades.js';
import { openCraftingGuide } from './crafting.js';
import { equippedRunes, migrateChestRune, migrateRetiredRunes } from './runeInventory.js';
import { openRuneMenu } from './runeMenu.js';

const neutral = () => ({physical:1, magic:1, health:0, defense:0, manaRegen:0, manaRegenPercent:0, ward:false, speed:false, lifesteal:0, wardAmplifier:0, speedAmplifier:0});
export function getEquipmentBonuses(player) {
  const result = neutral();
  try {
    const eq = player.getComponent('minecraft:equippable');
    if (!eq) return result;
    const items = [EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet].map(slot=>eq.getEquipment(slot));
    const parts = ['helmet','chestplate','leggings','boots'];
    for (let i=0;i<items.length;i++) if (armorInfo(items[i]?.typeId)?.part === parts[i]) result.health += upgradeLevel(items[i],'armor')+ARMOR_GRADE_HP[itemGrade(items[i])];
    for (const [set, data] of Object.entries(ARMOR_SETS)) {
      if (!items.every((item,i)=>item?.typeId===`rpg:${set}_${parts[i]}`)) continue;
      result.ward ||= data.ward===true;
      result.physical *= data.physical ?? 1;
      result.magic *= data.magic ?? 1;
      result.health += data.health ?? 0;
      result.manaRegen += data.manaRegen ?? 0;
    }
    for(const stored of equippedRunes(player)) {
      const rune=upgradedRune(RUNES[stored.id],stored.level,stored.grade);
      result.physical*=rune.physical??1;result.magic*=rune.magic??1;
      result.health+=rune.health??0;result.defense+=rune.defense??0;result.manaRegen+=rune.manaRegen??0;result.manaRegenPercent+=rune.manaRegenPercent??0;
      result.lifesteal=Math.max(result.lifesteal,rune.lifesteal??0);
      result.ward ||= rune.ward===true;result.speed ||= rune.speed===true;
      result.wardAmplifier=Math.max(result.wardAmplifier,rune.wardAmplifier??0);
      result.speedAmplifier=Math.max(result.speedAmplifier,rune.speedAmplifier??0);
    }
  } catch { return neutral(); }
  return result;
}

export async function openEquipmentMenu(player) {
  try {
    const form=new ActionFormData().title('RPG 장비').body('룬은 전용 보관함에서 최대 3개를 장착합니다. 같은 종류는 하나만 장착할 수 있습니다.\n'+Object.entries(ARMOR_SETS).map(([id,s])=>rarityBadge(armorRarity(id))+' '+s.name+': '+s.description).join('\n'))
      .button('룬 보관함 · 장착').button('갑옷·룬·무기 강화 / 합성').button('획득·제작 도감').button('닫기');
    const res=await showForm(form,player);if(!res||res.canceled)return;
    if(res.selection===0)await openRuneMenu(player);
    else if(res.selection===1)await openUpgradeMenu(player);
    else if(res.selection===2)await openCraftingGuide(player);
  }catch(error){try{player.sendMessage('§c[RPG] '+String(error));}catch{}}
}

function refreshAura(player, id, amplifier=0) {
  const effect = player.getEffect(id);
  if (!effect || effect.amplifier < amplifier || (effect.amplifier === amplifier && effect.duration < 60)) player.addEffect(id,60,{amplifier,showParticles:false});
}
export function registerEquipment() {
  system.runInterval(()=>{
    for (const player of world.getAllPlayers()) {
      try {
        migrateRetiredRunes(player);
        migrateChestRune(player);
        const bonuses = getEquipmentBonuses(player);
        if (bonuses.ward) refreshAura(player,'resistance',bonuses.wardAmplifier);
        if (bonuses.speed) refreshAura(player,'speed',bonuses.speedAmplifier);
      } catch {}
    }
  },20);

}
