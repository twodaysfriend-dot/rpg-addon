# 수정·신규 파일 전체 코드

## RPG_BP_v0597/entities/player.json

```json
{
  "format_version": "1.21.0",
  "minecraft:entity": {
    "description": {
      "identifier": "minecraft:player",
      "spawn_category": "creature",
      "is_spawnable": false,
      "is_summonable": false
    },
    "component_groups": {
      "minecraft:add_raid_omen": {
        "minecraft:spell_effects": {
          "add_effects": [
            {
              "effect": "raid_omen",
              "duration": 30,
              "display_on_screen_animation": true
            }
          ],
          "remove_effects": "bad_omen"
        },
        "minecraft:timer": {
          "time": [
            0.0,
            0.0
          ],
          "looping": false,
          "time_down_event": {
            "event": "minecraft:clear_add_raid_omen",
            "target": "self"
          }
        }
      },
      "minecraft:clear_raid_omen_spell_effect": {
        "minecraft:spell_effects": {}
      },
      "minecraft:raid_trigger": {
        "minecraft:raid_trigger": {
          "triggered_event": {
            "event": "minecraft:remove_raid_trigger",
            "target": "self"
          }
        }
      },
      "rpg:duel_safe": {
        "minecraft:health": {
          "value": 20,
          "max": 20,
          "min": 1
        }
      },
      "rpg:duel_normal": {
        "minecraft:health": {
          "value": 20,
          "max": 20,
          "min": 0
        }
      },
      "rpg:ward_defense_0": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 1.0
            }
          ]
        }
      },
      "rpg:ward_defense_40": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.986
            }
          ]
        }
      },
      "rpg:ward_defense_44": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9846
            }
          ]
        }
      },
      "rpg:ward_defense_48": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9832
            }
          ]
        }
      },
      "rpg:ward_defense_54": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9811
            }
          ]
        }
      },
      "rpg:ward_defense_60": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.979
            }
          ]
        }
      },
      "rpg:ward_defense_66": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9769
            }
          ]
        }
      },
      "rpg:ward_defense_70": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9755
            }
          ]
        }
      },
      "rpg:ward_defense_72": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9748
            }
          ]
        }
      },
      "rpg:ward_defense_80": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.972
            }
          ]
        }
      },
      "rpg:ward_defense_81": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.97165
            }
          ]
        }
      },
      "rpg:ward_defense_88": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9692
            }
          ]
        }
      },
      "rpg:ward_defense_90": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9685
            }
          ]
        }
      },
      "rpg:ward_defense_96": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9664
            }
          ]
        }
      },
      "rpg:ward_defense_100": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.965
            }
          ]
        }
      },
      "rpg:ward_defense_105": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.96325
            }
          ]
        }
      },
      "rpg:ward_defense_108": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9622
            }
          ]
        }
      },
      "rpg:ward_defense_110": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9615
            }
          ]
        }
      },
      "rpg:ward_defense_120": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.958
            }
          ]
        }
      },
      "rpg:ward_defense_132": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9538
            }
          ]
        }
      },
      "rpg:ward_defense_135": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.95275
            }
          ]
        }
      },
      "rpg:ward_defense_140": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.951
            }
          ]
        }
      },
      "rpg:ward_defense_144": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9496
            }
          ]
        }
      },
      "rpg:ward_defense_150": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9475
            }
          ]
        }
      },
      "rpg:ward_defense_154": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9461
            }
          ]
        }
      },
      "rpg:ward_defense_160": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.944
            }
          ]
        }
      },
      "rpg:ward_defense_162": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9433
            }
          ]
        }
      },
      "rpg:ward_defense_168": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9412
            }
          ]
        }
      },
      "rpg:ward_defense_175": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.93875
            }
          ]
        }
      },
      "rpg:ward_defense_176": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9384
            }
          ]
        }
      },
      "rpg:ward_defense_180": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.937
            }
          ]
        }
      },
      "rpg:ward_defense_189": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.93385
            }
          ]
        }
      },
      "rpg:ward_defense_192": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9328
            }
          ]
        }
      },
      "rpg:ward_defense_198": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9307
            }
          ]
        }
      },
      "rpg:ward_defense_200": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.93
            }
          ]
        }
      },
      "rpg:ward_defense_210": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9265
            }
          ]
        }
      },
      "rpg:ward_defense_216": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9244
            }
          ]
        }
      },
      "rpg:ward_defense_220": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.923
            }
          ]
        }
      },
      "rpg:ward_defense_240": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.916
            }
          ]
        }
      },
      "rpg:ward_defense_242": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9153
            }
          ]
        }
      },
      "rpg:ward_defense_243": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.91495
            }
          ]
        }
      },
      "rpg:ward_defense_245": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.91425
            }
          ]
        }
      },
      "rpg:ward_defense_264": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9076
            }
          ]
        }
      },
      "rpg:ward_defense_270": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9055
            }
          ]
        }
      },
      "rpg:ward_defense_280": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.902
            }
          ]
        }
      },
      "rpg:ward_defense_288": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.8992
            }
          ]
        }
      },
      "rpg:ward_defense_297": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.89605
            }
          ]
        }
      },
      "rpg:ward_defense_300": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.895
            }
          ]
        }
      },
      "rpg:ward_defense_315": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.88975
            }
          ]
        }
      },
      "rpg:ward_defense_320": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.888
            }
          ]
        }
      },
      "rpg:ward_defense_324": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.8866
            }
          ]
        }
      },
      "rpg:ward_defense_330": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.8845
            }
          ]
        }
      },
      "rpg:ward_defense_350": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.8775
            }
          ]
        }
      },
      "rpg:ward_defense_360": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.874
            }
          ]
        }
      },
      "rpg:ward_defense_385": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.86525
            }
          ]
        }
      },
      "rpg:ward_defense_400": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.86
            }
          ]
        }
      },
      "rpg:ward_defense_420": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.853
            }
          ]
        }
      },
      "rpg:ward_defense_440": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.846
            }
          ]
        }
      },
      "rpg:ward_defense_480": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.832
            }
          ]
        }
      }
    },
    "components": {
      "minecraft:experience_reward": {
        "on_death": "Math.Min(query.player_level * 7, 100)"
      },
      "minecraft:type_family": {
        "family": [
          "player"
        ]
      },
      "minecraft:is_hidden_when_invisible": {},
      "minecraft:loot": {
        "table": "loot_tables/empty.json"
      },
      "minecraft:collision_box": {
        "width": 0.6,
        "height": 1.8
      },
      "minecraft:can_climb": {},
      "minecraft:movement": {
        "value": 0.1
      },
      "minecraft:hurt_on_condition": {
        "damage_conditions": [
          {
            "filters": {
              "test": "in_lava",
              "subject": "self",
              "operator": "==",
              "value": true
            },
            "cause": "lava",
            "damage_per_tick": 4
          }
        ]
      },
      "minecraft:attack": {
        "damage": 1
      },
      "minecraft:exhaustion_values": {
        "heal": 6,
        "jump": 0.05,
        "sprint_jump": 0.2,
        "mine": 0.005,
        "attack": 0.1,
        "damage": 0.1,
        "walk": 0.0,
        "sprint": 0.1,
        "swim": 0.01
      },
      "minecraft:player.saturation": {
        "value": 5,
        "max": 20
      },
      "minecraft:player.exhaustion": {
        "value": 0,
        "max": 20
      },
      "minecraft:player.level": {
        "value": 0,
        "max": 24791
      },
      "minecraft:player.experience": {
        "value": 0,
        "max": 1
      },
      "minecraft:breathable": {
        "total_supply": 15,
        "suffocate_time": -1,
        "inhale_time": 3.75,
        "generates_bubbles": false
      },
      "minecraft:nameable": {
        "always_show": true,
        "allow_name_tag_renaming": false
      },
      "minecraft:physics": {
        "push_towards_closest_space": true
      },
      "minecraft:pushable": {
        "is_pushable": false,
        "is_pushable_by_piston": true
      },
      "minecraft:insomnia": {
        "days_until_insomnia": 3
      },
      "minecraft:rideable": {
        "seat_count": 2,
        "family_types": [
          "parrot_tame"
        ],
        "pull_in_entities": true,
        "seats": [
          {
            "position": [
              0.4,
              -0.2,
              -0.1
            ],
            "min_rider_count": 0,
            "max_rider_count": 0,
            "lock_rider_rotation": 0
          },
          {
            "position": [
              -0.4,
              -0.2,
              -0.1
            ],
            "min_rider_count": 1,
            "max_rider_count": 2,
            "lock_rider_rotation": 0
          }
        ]
      },
      "minecraft:conditional_bandwidth_optimization": {},
      "minecraft:block_climber": {},
      "minecraft:environment_sensor": {
        "triggers": {
          "filters": {
            "all_of": [
              {
                "test": "has_mob_effect",
                "subject": "self",
                "value": "bad_omen"
              },
              {
                "test": "is_in_village",
                "subject": "self",
                "value": true
              }
            ]
          },
          "event": "minecraft:gain_raid_omen"
        }
      },
      "minecraft:health": {
        "value": 20,
        "max": 20,
        "min": 0
      }
    },
    "events": {
      "minecraft:gain_raid_omen": {
        "add": {
          "component_groups": [
            "minecraft:add_raid_omen"
          ]
        }
      },
      "minecraft:clear_add_raid_omen": {
        "remove": {
          "component_groups": [
            "minecraft:add_raid_omen"
          ]
        },
        "add": {
          "component_groups": [
            "minecraft:clear_raid_omen_spell_effect"
          ]
        }
      },
      "minecraft:trigger_raid": {
        "add": {
          "component_groups": [
            "minecraft:raid_trigger"
          ]
        }
      },
      "minecraft:remove_raid_trigger": {
        "remove": {
          "component_groups": [
            "minecraft:raid_trigger"
          ]
        }
      },
      "rpg:duel_enter": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:duel_safe",
                "rpg:duel_normal"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:duel_safe"
              ]
            }
          }
        ]
      },
      "rpg:duel_exit": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:duel_safe",
                "rpg:duel_normal"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:duel_normal"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_0": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_0"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_40": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_40"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_44": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_44"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_48": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_48"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_54": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_54"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_60": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_60"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_66": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_66"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_70": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_70"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_72": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_72"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_80": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_80"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_81": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_81"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_88": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_88"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_90": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_90"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_96": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_96"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_100": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_100"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_105": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_105"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_108": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_108"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_110": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_110"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_120": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_120"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_132": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_132"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_135": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_135"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_140": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_140"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_144": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_144"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_150": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_150"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_154": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_154"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_160": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_160"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_162": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_162"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_168": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_168"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_175": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_175"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_176": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_176"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_180": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_180"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_189": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_189"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_192": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_192"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_198": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_198"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_200": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_200"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_210": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_210"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_216": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_216"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_220": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_220"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_240": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_240"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_242": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_242"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_243": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_243"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_245": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_245"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_264": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_264"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_270": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_270"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_280": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_280"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_288": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_288"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_297": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_297"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_300": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_300"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_315": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_315"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_320": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_320"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_324": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_324"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_330": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_330"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_350": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_350"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_360": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_360"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_385": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_385"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_400": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_400"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_420": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_420"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_440": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_440"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_480": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_480"
              ]
            }
          }
        ]
      }
    }
  }
}
```

## RPG_BP_v0597/items/blood_spear.json

```json
{
  "format_version": "1.21.90",
  "minecraft:item": {
    "description": {
      "identifier": "rpg:blood_spear",
      "menu_category": {
        "category": "equipment"
      }
    },
    "components": {
      "minecraft:max_stack_size": 1,
      "minecraft:icon": "rpg_blood_spear",
      "minecraft:hand_equipped": true,
      "minecraft:damage": 0,
      "minecraft:durability": {
        "max_durability": 5,
        "damage_chance": {
          "min": 0,
          "max": 0
        }
      },
      "minecraft:display_name": {
        "value": "피의 창"
      },
      "minecraft:use_modifiers": {
        "use_duration": 0.1,
        "movement_modifier": 1
      },
      "rpg:blood_spear_reach": {}
    }
  }
}
```

## RPG_BP_v0597/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon BP v0.6.0",
    "description": "RPG v0.6.0 · 흡혈 복구·혈촉수·피의 창 5회·수호 방어력·TPA 직접 이동",
    "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
    "version": [
      0,
      6,
      0
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "data",
      "uuid": "cc5d6e3c-5285-4787-8a59-a8e2856f2aec",
      "version": [
        0,
        6,
        0
      ]
    },
    {
      "type": "script",
      "language": "javascript",
      "uuid": "c41fa3d6-d82c-4a54-9783-68f92fe633a1",
      "entry": "scripts/gameplayEntry.js",
      "version": [
        0,
        6,
        0
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
      "version": [
        0,
        6,
        0
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    },
    {
      "module_name": "@minecraft/server-ui",
      "version": "2.0.0"
    }
  ]
}
```

## RPG_BP_v0597/scripts/core/context.js

```javascript
import { syncChameleonLoadout } from './chameleonProgress.js';
import { JOBS, STARTER_ITEMS, APPRENTICE_SKILLS } from "../data/jobs.js";
import { SKILLS } from "../data/skills.js";
import { getJobId, getSkills, setSkills, getDisabled, setDisabled, setJobId, setIndex } from "./playerData.js";
import { heldItemId } from "./util.js";

// 지금 들고 있는 아이템으로 정해지는 "스킬 사용 상태".
//  - 견습: 계열별 시작 아이템(검/마법책)을 들면 그 계열의 스킬 목록
//  - 2차 이상: 직업 무기를 들었을 때만 직업 스킬 목록
// 해당 없으면 undefined.
export function getContext(player) {
  const currentJobId = getJobId(player);
  let job = JOBS[currentJobId];
  if (!job) {
    if (currentJobId === "necromancer" || currentJobId === "deathlord") {
      setJobId(player, "apprentice");
      setSkills(player, []);
      setDisabled(player, []);
      job = JOBS.apprentice;
    } else {
      return undefined;
    }
  }

  // 기존 저장 데이터도 새 스킬을 습득하도록 호환 마이그레이션합니다.
  const isSwordSaint = job.id === "sword_saint" || job.id === "fallen_sword_saint";
  const autoLearn = job.id === "the_world" ? job.skills
    : job.id === "blood_mage" ? ["blood_tentacle"]
    : job.id === "swordsman"
    ? ["sword_spin", "sword_wave", "sword_flame_spin"]
    : job.id === "fallen_sword_saint"
      ? ["sword_spin", "sword_wave", "sword_flame_spin", "sword_kenho_rando", "sword_moon_dragon", "sword_rush", "fallen_sword_frenzy"]
      : job.id === "sword_saint"
        ? ["sword_spin", "sword_wave", "sword_flame_spin", "sword_kenho_rando", "sword_moon_dragon", "sword_rush", "sword_annihilation"]
        : [];
  // v0.4.83: 이미 카멜레온으로 전직한 월드에도 신규 검 스킬 지급.
  if (job.id === "chameleon") {
    syncChameleonLoadout(player);
    const learned = getSkills(player);
    const wanted = [...learned];
    if (!wanted.includes("chameleon_crimson_dash")) wanted.push("chameleon_crimson_dash");
    if (!wanted.includes("chameleon_ground_slam")) wanted.push("chameleon_ground_slam");
    if (wanted.length !== learned.length) setSkills(player, wanted);
  }
  // 기존 망나니·야수 저장 스킬을 새 기술 구성으로 이전.
  if (job.id === "mangnani" || job.id === "beast") {
    const learned = getSkills(player);
    const revised = [...job.skills];
    if (JSON.stringify(learned) !== JSON.stringify(revised)) setSkills(player, revised);
    const off = getDisabled(player);
    const cleaned = off.filter(id => revised.includes(id));
    if (cleaned.length !== off.length) setDisabled(player, cleaned);
  }
  // Existing Revenants gain the new attacks and use the same attack/buff/ultimate order.
  if(job.id==='revenant'){
    const wanted=[...job.skills];
    if(JSON.stringify(getSkills(player))!==JSON.stringify(wanted)){setSkills(player,wanted);setIndex(player,0);}
    const off=getDisabled(player),clean=off.filter(id=>wanted.includes(id));
    if(clean.length!==off.length)setDisabled(player,clean);
  }
  // v0.4.36~37의 빈 직업 스킬 데이터도 신버전에 자동 등록합니다.
  if (job.id === "blood_mage" || job.id === "hacker" || job.id === "assassin" || job.id === "shadow_assassin" || job.id === "frost_controller" || job.id === "fire_controller" || job.id === "dragon_knight" || job.id === "technomancer" || job.id === "demon" || job.id === "sun_heir" || job.id === "moon_heir") {
    const learned = getSkills(player);
    const wanted = [...job.skills];
    if (JSON.stringify(learned) !== JSON.stringify(wanted)) setSkills(player, wanted);
    const disabled = getDisabled(player);
    const cleaned = disabled.filter(id => wanted.includes(id));
    if (cleaned.length !== disabled.length) setDisabled(player, cleaned);
  }
  // v0.4.16에서 이미 전직한 궁수에게 새 스킬을 자동 지급합니다.
  const isArcher = job.line === "archer" && job.id !== "apprentice";
  if (isArcher) {
    const learned = getSkills(player);
    const allowed = new Set(job.skills);
    const revised = learned.filter(id => id !== "archer_triple" && id !== "archer_rain" && (job.id !== "heavenly_archer" || id !== "archer_fire"));
    for (const id of allowed) if (!revised.includes(id)) revised.push(id);
    if (JSON.stringify(revised) !== JSON.stringify(learned)) setSkills(player, revised);
    const disabled = getDisabled(player);
    const cleanDisabled = disabled.filter(id => id !== "archer_rain" && (job.id !== "heavenly_archer" || id !== "archer_fire"));
    if (cleanDisabled.length !== disabled.length) setDisabled(player, cleanDisabled);
  }
  if (job.id === "apprentice") {
    const item=heldItemId(player);
    if (item === "rpg:apprentice_bow") {
      const learned=getSkills(player);
      const revised=[...learned];
      for(const id of APPRENTICE_SKILLS.archer) if(!revised.includes(id)) revised.push(id);
      if(revised.length!==learned.length)setSkills(player,revised);
    }
  }
  if (autoLearn.length > 0 || isSwordSaint) {
    let learnedNow = getSkills(player);
    let changed = false;
    // 기존 저장 데이터에 남아 있을 수 있는 '발도'를 제거합니다.
    if (isSwordSaint && learnedNow.includes("sword_draw")) {
      learnedNow = learnedNow.filter((id) => id !== "sword_draw");
      changed = true;
    }
    // 섬멸은 검성 전용. 이전 저장 데이터에서 타락검성에게 남은 섬멸을 정리합니다.
    if (job.id === "fallen_sword_saint" && learnedNow.includes("sword_annihilation")) {
      learnedNow = learnedNow.filter((id) => id !== "sword_annihilation");
      changed = true;
    }
    for (const id of autoLearn) {
      if (!learnedNow.includes(id)) {
        learnedNow.push(id);
        changed = true;
      }
    }
    if (changed) setSkills(player, learnedNow);
    if (isSwordSaint) {
      const off = getDisabled(player);
      const remove = job.id === "fallen_sword_saint" ? new Set(["sword_draw", "sword_annihilation"]) : new Set(["sword_draw"]);
      if (off.some((id) => remove.has(id))) setDisabled(player, off.filter((id) => !remove.has(id)));
    }
  }

  const held = heldItemId(player);
  if (!held) return undefined;

  let line;
  let ids;
  if (job.id === "apprentice") {
    line = STARTER_ITEMS[held];
    if (!line) return undefined;
    ids = APPRENTICE_SKILLS[line] ?? [];
  } else {
    // 카멜레온은 두 무기 어느 쪽에서도 배운 스킬만 사용한다.
    if (job.id === "chameleon") {
      if (held !== job.weapon && held !== job.altWeapon) return undefined;
    } else
    // 달의 차크람은 던지는 무기, 달빛 인장은 스킬 전용 입력 도구이다.
    if (job.id === "moon_heir") {
      if (held !== "rpg:moon_heir_focus") return undefined;
    } else if (!job.weapon || held !== job.weapon) return undefined;
    line = job.line;
    ids = job.id === "chameleon"
      ? getSkills(player).filter(id => typeof id === "string" && !!SKILLS[id] &&
          ((id !== "chameleon_crimson_dash" || held === "rpg:chameleon_flame_blade") && (id !== "chameleon_ground_slam" || held === "rpg:chameleon_moon_scythe")))
      : job.skills;
  }

  const learned = getSkills(player);
  const off = getDisabled(player);
  // all : 배운 스킬 전체(설정창에 표시), skills : 그중 켜 둔 스킬(전환/발동 대상)
  const all = job.id==="apprentice"?ids:ids.filter((id) => learned.includes(id));
  return { job, line, held, all, skills: all.filter((id) => !off.includes(id)) };
}
```

## RPG_BP_v0597/scripts/core/equipment.js

```javascript
import {itemGrade,ARMOR_GRADE_HP} from '../data/grades.js';
import {rarityBadge,armorRarity} from '../data/rarity.js';
import { world, system, EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { ARMOR_SETS, RUNES, RUNE_KEY, armorInfo } from '../data/equipment.js';
import { showForm } from './skillMenu.js';
import { RUNE_LEVEL_KEY, upgradeLevel, upgradedRune } from '../data/upgrades.js';
import { openUpgradeMenu } from './upgrades.js';
import { openCraftingGuide } from './crafting.js';
import { equippedRunes, migrateChestRune, migrateRetiredRunes } from './runeInventory.js';
import { openRuneMenu } from './runeMenu.js';

const neutral = () => ({physical:1, magic:1, health:0, defense:0, manaRegen:0, manaRegenPercent:0, ward:false, speed:false, lifesteal:0, wardAmplifier:0, speedAmplifier:0});
export function getEquipmentBonuses(player) {
  const result = neutral();
  try {
    const eq = player.getComponent('minecraft:equippable');
    if (!eq) return result;
    const items = [EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet].map(slot=>eq.getEquipment(slot));
    const parts = ['helmet','chestplate','leggings','boots'];
    for (let i=0;i<items.length;i++) if (armorInfo(items[i]?.typeId)?.part === parts[i]) result.health += upgradeLevel(items[i],'armor')+ARMOR_GRADE_HP[itemGrade(items[i])];
    for (const [set, data] of Object.entries(ARMOR_SETS)) {
      if (!items.every((item,i)=>item?.typeId===`rpg:${set}_${parts[i]}`)) continue;
      result.ward ||= data.ward===true;
      result.physical *= data.physical ?? 1;
      result.magic *= data.magic ?? 1;
      result.health += data.health ?? 0;
      result.manaRegen += data.manaRegen ?? 0;
    }
    for(const stored of equippedRunes(player)) {
      const rune=upgradedRune(RUNES[stored.id],stored.level,stored.grade);
      result.physical*=rune.physical??1;result.magic*=rune.magic??1;
      result.health+=rune.health??0;result.defense+=rune.defense??0;result.manaRegen+=rune.manaRegen??0;result.manaRegenPercent+=rune.manaRegenPercent??0;
      result.lifesteal=Math.max(result.lifesteal,rune.lifesteal??0);
      result.ward ||= rune.ward===true;result.speed ||= rune.speed===true;
      result.wardAmplifier=Math.max(result.wardAmplifier,rune.wardAmplifier??0);
      result.speedAmplifier=Math.max(result.speedAmplifier,rune.speedAmplifier??0);
    }
  } catch { return neutral(); }
  return result;
}

export async function openEquipmentMenu(player) {
  try {
    const form=new ActionFormData().title('RPG 장비').body('룬은 전용 보관함에서 최대 3개를 장착합니다. 같은 종류는 하나만 장착할 수 있습니다.\n'+Object.entries(ARMOR_SETS).map(([id,s])=>rarityBadge(armorRarity(id))+' '+s.name+': '+s.description).join('\n'))
      .button('룬 보관함 · 장착').button('갑옷·룬·무기 강화 / 합성').button('획득·제작 도감').button('닫기');
    const res=await showForm(form,player);if(!res||res.canceled)return;
    if(res.selection===0)await openRuneMenu(player);
    else if(res.selection===1)await openUpgradeMenu(player);
    else if(res.selection===2)await openCraftingGuide(player);
  }catch(error){try{player.sendMessage('§c[RPG] '+String(error));}catch{}}
}

function refreshAura(player, id, amplifier=0) {
  const effect = player.getEffect(id);
  if (!effect || effect.amplifier < amplifier || (effect.amplifier === amplifier && effect.duration < 60)) player.addEffect(id,60,{amplifier,showParticles:false});
}
export function registerEquipment() {
  system.runInterval(()=>{
    for (const player of world.getAllPlayers()) {
      try {
        migrateRetiredRunes(player);
        migrateChestRune(player);
        const bonuses = getEquipmentBonuses(player);
        if (bonuses.ward) refreshAura(player,'resistance',bonuses.wardAmplifier);
        if (bonuses.speed) refreshAura(player,'speed',bonuses.speedAmplifier);
      } catch {}
    }
  },20);

}
```

## RPG_BP_v0597/scripts/core/input.js

```javascript
import {RUNNERS as WORLD_RUNNERS} from '../skills/theWorld.js';
import {isTimeFrozen} from './timeStopDamage.js';
import {useProgressionItem} from './progressionItems.js';
import {RUNNERS as WAR_GOD_RUNNERS} from '../skills/warGod.js';
import { executeChameleonSkill,skillBookItemUse,SKILLBOOK_ID } from './chameleonProgress.js';
import { world, system } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { areAllies } from "./social.js";
import { SKILLS } from "../data/skills.js";
import { RUNNERS as SWORD_RUNNERS, fireBasic } from "../skills/sword.js";
import { RUNNERS as FLAME_SPIN_RUNNERS } from "../skills/swordFlameSpin.js";
import { RUNNERS as MAGE_RUNNERS } from "../skills/mage.js";
import { RUNNERS as HOLY_RUNNERS } from "../skills/holy.js";
import { RUNNERS as FIST_RUNNERS } from "../skills/fist.js";
import { RUNNERS as ARCHER_RUNNERS, shootHeavenlyInstant, clearPreparedBowMode,heavenlyAmmoCost } from "../skills/archer.js";
import { RUNNERS as NECRO_RUNNERS } from "../skills/necro.js";
import { RUNNERS as DARK_RUNNERS } from "../skills/dark.js";
import { RUNNERS as BERSERKER_RUNNERS } from "../skills/berserker.js";
import { RUNNERS as BLOOD_RUNNERS, bloodAwakenIsActive, bloodAwakenStop } from "../skills/blood.js";
import { RUNNERS as HACKER_RUNNERS, isHackerStealthActive, stopHackerStealth } from "../skills/hacker.js";
import { RUNNERS as HARPOON_RUNNERS } from "../skills/harpoon.js";
import { RUNNERS as FROST_RUNNERS } from "../skills/frost.js";
import { RUNNERS as FIRE_RUNNERS } from "../skills/fire.js";
import { RUNNERS as ASSASSIN_RUNNERS, assassinStealthIsActive, stopAssassinStealth } from "../skills/assassin.js";
import { RUNNERS as TECH_RUNNERS } from "../skills/technomancer.js";
import { RUNNERS as DEMON_RUNNERS } from "../skills/demon.js";
import { RUNNERS as CELESTIAL_RUNNERS, throwMoonWeapon, tryBorrowedMoonThrow } from "../skills/celestial.js";
import { RUNNERS as DRAGON_RUNNERS } from "../skills/dragon.js";
import { chameleonCastJob, swapChameleonWeapon } from "./chameleon.js";
import { openAdminTool, ADMIN_TOOL_ID } from "./adminTool.js";
import { RUNNERS as CHAMELEON_RUNNERS, registerChameleonDash } from "../skills/chameleonDash.js";
import {
  getIndex, setIndex, getMana, spendMana, cooldownLeft, startCooldown,
} from "./playerData.js";
import { sound, particle, heldItemId } from "./util.js";
import { manaCostFor } from "./stats.js";
import { getContext } from "./context.js";
import { notify, refreshHud } from "./hud.js";
import { openSkillMenu } from "./skillMenu.js";

const RUNNERS = { ...WORLD_RUNNERS, ...WAR_GOD_RUNNERS, ...SWORD_RUNNERS, ...FLAME_SPIN_RUNNERS, ...MAGE_RUNNERS, ...HOLY_RUNNERS, ...FIST_RUNNERS, ...ARCHER_RUNNERS, ...NECRO_RUNNERS, ...DARK_RUNNERS, ...BERSERKER_RUNNERS, ...BLOOD_RUNNERS, ...HACKER_RUNNERS, ...HARPOON_RUNNERS, ...FROST_RUNNERS, ...FIRE_RUNNERS, ...ASSASSIN_RUNNERS, ...TECH_RUNNERS, ...DEMON_RUNNERS, ...CELESTIAL_RUNNERS, ...DRAGON_RUNNERS, ...CHAMELEON_RUNNERS };
const isPlayer = (e) => e?.typeId === "minecraft:player";

const CHAMELEON_SWORD = "rpg:chameleon_flame_blade";
const CHAMELEON_SCYTHE = "rpg:chameleon_moon_scythe";
const CHAMELEON_SWING_CRIMSON = "rpg:chameleon_crimson_swing";
const CHAMELEON_SWING_PLATINUM = "rpg:chameleon_platinum_swing";
const swingFxTick = new Map();

function emitChameleonSwing(player) {
  try {
    if (!isPlayer(player)) return;
    const held = heldItemId(player);
    const fx = held === CHAMELEON_SWORD ? CHAMELEON_SWING_CRIMSON
      : held === CHAMELEON_SCYTHE ? CHAMELEON_SWING_PLATINUM : undefined;
    if (!fx) return;
    const now = system.currentTick;
    if (now - (swingFxTick.get(player.id) ?? -100) < 3) return;
    swingFxTick.set(player.id, now);
    // Three small, spinning slash billboards sweep in an arc in front of the hand.
    // Keep them visual-only: they do not alter melee damage or skill mechanics.
    const dim = player.dimension;
    for (let phase = 0; phase < 3; phase++) {
      system.runTimeout(() => {
        try {
          if (!player.isValid || player.dimension.id !== dim.id || heldItemId(player) !== held) return;
          const head = player.getHeadLocation();
          const view = player.getViewDirection();
          const length = Math.hypot(view.x, view.z) || 1;
          const front = { x: view.x / length, z: view.z / length };
          const right = { x: -front.z, z: front.x };
          const side = (phase - 1) * 0.42;
          const pos = {
            x: head.x + front.x * (0.95 + 0.08 * phase) + right.x * side,
            y: head.y - 0.42 + (phase - 1) * 0.22,
            z: head.z + front.z * (0.95 + 0.08 * phase) + right.z * side,
          };
          particle(dim, fx, pos);
        } catch { /* player unavailable */ }
      }, phase);
    }
  } catch {}
}

// 아군에게 발동 가능한 왼쪽 클릭 기술만 허용. 동일한 공격이
// beforeEvents.entityHurt + afterEvents.entityHitEntity 양쪽에서 관측되더라도
// 한 번만 발동하도록 2틱 중복 방지.
const friendlyHitTick = new Map();
export function handleFriendlyHit(player, target) {
  if (!isPlayer(player) || !isPlayer(target) || player.id === target.id ||
      (!areAllies(player,target)&&CONFIG.pvp)) return;
  const ctx = getContext(player);
  if (!ctx?.skills?.length) return;
  const def = SKILLS[ctx.skills[getIndex(player) % ctx.skills.length]];
  if (!def || !(def.id === "hacker_hack" || def.id === "holy_heal" || def.id === "holy_orb")) return;
  if(!areAllies(player,target)&&def.id!=="holy_heal")return;
  const key = `${player.id}:${target.id}`;
  const now = system.currentTick;
  if (now - (friendlyHitTick.get(key) ?? -100) < 3) return;
  friendlyHitTick.set(key, now);
  cast(player, ctx, target);
}

// 우클릭: 현재 선택된 스킬 발동
// 좌클릭으로 엔티티를 때려서 쓰는 스킬(trigger: "hit")은 때린 대상(target)이 있을 때만 발동합니다.
function cast(player, ctx, target) {
  if(isTimeFrozen(player))return;
  const list = ctx.skills;
  if (list.length === 0) return;

  const def = SKILLS[list[getIndex(player) % list.length]];
  const runner = RUNNERS[def.id];
  if (!runner) return;
  if(!CONFIG.pvp&&isPlayer(target)&&!(["holy_heal","holy_orb","hacker_hack"].includes(def.id)))return;

  const isHit = def.trigger === "hit";
  // 해킹: 적에게는 우클릭 해킹, 같은 길드/파티원에게는 좌클릭 지원.
  const allyHack = def.id === "hacker_hack" && isPlayer(target) &&
    target.id !== player.id && areAllies(player, target);
  if (isHit && !target) {
    notify(player, `§7${def.name}: 엔티티를 좌클릭해서 사용합니다.`);
    return;
  }
  // 계약은 우클릭 자가 강화와 좌클릭 적 대상 효과를 모두 사용합니다.
  if (!isHit && target && !allyHack && def.id !== "demon_contract" && def.id !== "fallen_orb" && def.id !== "world_blood") return;

  // 해제 입력은 쿨타임·마나를 쓰지 않고 바로 상태를 해제합니다.
  if (def.id === "blood_awaken" && bloodAwakenIsActive(player)) {
    bloodAwakenStop(player); refreshHud(player, true); return;
  }
  if (def.id === "hacker_stealth" && isHackerStealthActive(player)) {
    stopHackerStealth(player); refreshHud(player, true); return;
  }
  if (def.id === "assassin_stealth" && assassinStealthIsActive(player)) {
    stopAssassinStealth(player); refreshHud(player, true); return;
  }
  if(def.id === "moon_chakram_split" && tryBorrowedMoonThrow(player)){refreshHud(player,true);return;}
  const left = cooldownLeft(player, def.id);
  if (left > 0) {
    notify(player, `§c${def.name} 쿨타임 ${(left / 20).toFixed(1)}초`);
    return;
  }
  const adjustedMana = def.id==='world_stop'?Math.max(300,manaCostFor(player,def.mana)):manaCostFor(player, def.mana);
  if (getMana(player) < adjustedMana) {
    notify(player, "§c마나가 부족합니다.");
    return;
  }

  const charged=executeChameleonSkill(player,def.id,()=>runner(player,chameleonCastJob(def.id,ctx.job),def,target));
  if(!charged.ok){notify(player,'§c'+charged.message);return;}
  const castResult=charged.result;
  if (castResult === false) return;

  spendMana(player, adjustedMana);
  // 복수귀 처형은 성공과 실패의 재사용 대기시간이 다릅니다.
  startCooldown(player, def.id, castResult && typeof castResult.cooldown === "number" ? castResult.cooldown : def.cooldown);
  refreshHud(player, true);
}

// 휘두르기: 푸른 에너지 (3차 이상 검 계열)
function onSwing(player) {
  emitChameleonSwing(player);
  const ctx = getContext(player);
  if (!ctx?.job.basic || ctx.job.id === "apprentice") return;
  if (cooldownLeft(player, "basic") > 0) return;
  startCooldown(player, "basic", CONFIG.basic.cooldown);
  fireBasic(player, ctx.job);
}

// 웅크리기: 스킬 전환 (설정창을 열려고 웅크린 경우를 되돌릴 수 있게 직전 번호를 기억)
const sneakLog = new Map(); // playerId -> { tick, prev }

function onSneakStart(player) {
  const ctx = getContext(player);
  if (!ctx || ctx.skills.length === 0) return;
  sneakLog.set(player.id, { tick: system.currentTick, prev: getIndex(player) });
  setIndex(player, (getIndex(player) + 1) % ctx.skills.length);
  sound(player.dimension, "random.click", player.location, { volume: 0.6, pitch: 1.3 });
  refreshHud(player, true);
}

// Instant heavenly bow shoots at fully charged velocity. Limit successful
// shots to one per 10 ticks (0.5 sec), also preventing duplicate item events.
const instantShotTick = new Map();
const gadgetCastTick = new Map();
function gadgetClick(p) {
  if (!isPlayer(p)) return;
  const ctx=getContext(p);
  if (!ctx || !['blood','hacker','harpoon','frost','fire','assassin','tech','demon','dragon','celestial_sun','celestial_moon','chameleon','war_god','the_world'].includes(ctx.line)) return;
  const now=system.currentTick;
  if(now-(gadgetCastTick.get(p.id)??-100)<3)return;
  gadgetCastTick.set(p.id,now);
  try {
    // 카멜레온: 웅크리고 무기 우클릭하면 즉시 장비 전환.
    if (ctx.job.id === 'chameleon' && p.isSneaking) {
      const log=sneakLog.get(p.id);
      if(log && now-log.tick<=20)setIndex(p,log.prev);
      const result=swapChameleonWeapon(p);
      notify(p,result.message);
      return;
    }
    if(CONFIG.skillMenuOnSneakUse && p.isSneaking){
      const log=sneakLog.get(p.id);
      if(log && now-log.tick<=20)setIndex(p,log.prev);
      openSkillMenu(p);
      return;
    }
  } catch {}
  cast(p,ctx);
}
function heavenlyClick(p) {
  if (!isPlayer(p)) return;
  const ctx=getContext(p);
  if(!ctx||ctx.job.id!=="heavenly_archer"||ctx.held!=="rpg:heavenly_bow")return;
  const now=system.currentTick;
  if(now-(instantShotTick.get(p.id)??-100)<10)return;
  try{
    if(CONFIG.skillMenuOnSneakUse && p.isSneaking){
      const log=sneakLog.get(p.id);
      if(log&&now-log.tick<=20)setIndex(p,log.prev);
      openSkillMenu(p);
      return;
    }
  }catch{}
  const basicAmmo=heavenlyAmmoCost(p);
  if(getMana(p)<basicAmmo){notify(p,'§c화살이 없습니다. 마나 화살 1발에 MP 20이 필요합니다.');return;}
  const def=SKILLS[ctx.skills[getIndex(p)%ctx.skills.length]];
  // Reserve the entire volley and skill cost before the runner spawns extras.
  // With too little MP for the selected skill, a basic 20-MP shot still works.
  const volleyCost=heavenlyAmmoCost(p,def?.id==='archer_rapid'?5:1);
  const canCast=def&&getMana(p)>=volleyCost+manaCostFor(p,def.mana);
  clearPreparedBowMode(p);
  if(canCast)cast(p,ctx);
  if(shootHeavenlyInstant(p))instantShotTick.set(p.id,now);
  else notify(p,"§c화살을 발사하지 못했습니다.");
}

// Custom item components must be registered during startup. Each is isolated:
// an unsupported/duplicate item component must never interrupt RPG commands.
system.beforeEvents.startup.subscribe(e=>{
  const registry = e?.itemComponentRegistry;
  if (!registry || typeof registry.registerCustomComponent !== "function") {
    console.warn("[RPG] ItemComponentRegistry unavailable; command registration remains active");
    return;
  }
  const safe = (name, handler) => {
    try { registry.registerCustomComponent(name, handler); }
    catch (error) { console.warn("[RPG] item component " + name + ": " + String(error)); }
  };
  safe("rpg:progression_item",{onUse(e){system.run(()=>useProgressionItem(e.source,e.itemStack?.typeId??heldItemId(e.source)));}});
  safe("rpg:random_skillbook",{onUse(e){system.run(()=>skillBookItemUse(e.source,system.currentTick));}});
  safe("rpg:throw_moon_chakram", {
    onUse(e) { system.run(() => throwMoonWeapon(e.source)); },
  });
  safe("rpg:cast_item",{
    onUse(e){system.run(()=>gadgetClick(e.source));},
  });
  safe("rpg:admin_settings", {
    onUse(e) { system.run(() => openAdminTool(e.source)); },
  });
  safe("rpg:instant_bow",{
    onUse(e){system.run(()=>heavenlyClick(e.source));},
    onCompleteUse(e){system.run(()=>heavenlyClick(e.source));},
  });
});

export function registerInput() {
  registerChameleonDash();
  // 커스텀 활을 당겼다가 놓았을 때 일반 화살 사격 + 현재 궁수 스킬을 사용합니다.
  // shooter 발사와 별개로 스킬 코드는 같은 입력으로 한 번만 실행됩니다.
  world.afterEvents.itemReleaseUse?.subscribe((ev) => {
    const p = ev.source;
    if (!isPlayer(p)) return;
    const ctx = getContext(p);
    if (!ctx || ctx.line !== "archer" || ev.itemStack?.typeId !== ctx.held) return;
    if(ctx.job.id==="heavenly_archer")return; // instant bow is handled on use, not release
    try {
      if (p.isSneaking) { openSkillMenu(p); return; }
    } catch { /* 사용 가능 */ }
    cast(p, ctx);
  });

  world.afterEvents.itemUse.subscribe((ev) => {
    const p = ev.source;
    if (!isPlayer(p)) return;
    if(ev.itemStack?.typeId===SKILLBOOK_ID){system.run(()=>skillBookItemUse(p,system.currentTick));return;}
    if (ev.itemStack?.typeId === ADMIN_TOOL_ID) { openAdminTool(p); return; }
    const ctx = getContext(p);
    if (!ctx) return;
    if(ctx.line === 'blood' || ctx.line === 'hacker' || ctx.line === 'harpoon' || ctx.line === 'frost' || ctx.line === 'fire' || ctx.line === 'assassin' || ctx.line === 'demon' || ctx.line === 'dragon' || ctx.line === 'celestial_sun' || ctx.line === 'celestial_moon' || ctx.line === 'chameleon' || ctx.line === 'war_god' || ctx.line === 'the_world'){
      gadgetClick(p);return;
    }
    if (ctx.line === "archer") {
      // Item event fallback if the platform forwards item use but not custom onUse.
      if(ctx.job.id==="heavenly_archer"&&ev.itemStack?.typeId==="rpg:heavenly_bow")heavenlyClick(p);
      return;
    }

    // 웅크린 채로 우클릭: 스킬 설정창 (발동하지 않음)
    let sneaking = false;
    try {
      sneaking = p.isSneaking;
    } catch {
      // 상태를 읽을 수 없으면 일반 발동
    }
    if (CONFIG.skillMenuOnSneakUse && sneaking) {
      // 방금 웅크리면서 전환된 스킬 번호는 원래대로 돌려놓습니다.
      const log = sneakLog.get(p.id);
      if (log && system.currentTick - log.tick <= 20) setIndex(p, log.prev);
      openSkillMenu(p);
      return;
    }
    cast(p, ctx);
  });

  // 허공을 휘두르는 동작은 버전에 따라 이벤트 지원이 달라서, 있을 때만 구독합니다.
  world.afterEvents.playerLeave.subscribe((ev) => {
    sneakLog.delete(ev.playerId);instantShotTick.delete(ev.playerId);gadgetCastTick.delete(ev.playerId);swingFxTick.delete(ev.playerId);
    for (const key of friendlyHitTick.keys()) if (key.startsWith(`${ev.playerId}:`) || key.endsWith(`:${ev.playerId}`)) friendlyHitTick.delete(key);
  });

  world.afterEvents.playerSwingStart?.subscribe((ev) => {
    onSwing(ev.player);
    try{
      const hits=ev.player.getEntitiesFromViewDirection({maxDistance:4,ignoreBlockCollision:false}).sort((a,b)=>a.distance-b.distance);
      if(isPlayer(hits[0]?.entity)&&(areAllies(ev.player,hits[0].entity)||!CONFIG.pvp))handleFriendlyHit(ev.player,hits[0].entity);
    }catch{}
  });

  // 대상/블록을 맞춘 휘두르기는 항상 감지됩니다. (쿨타임으로 중복 발동 방지)
  world.afterEvents.entityHitEntity.subscribe((ev) => {
    const p = ev.damagingEntity;
    if (!isPlayer(p)) return;
    onSwing(p);
    // 좌클릭으로 때려서 쓰는 스킬 (힐 / 축복의 구슬 / Sacrifice)
    const ctx = getContext(p);
    if (ctx && ev.hitEntity) {
      if (isPlayer(ev.hitEntity) && (areAllies(p, ev.hitEntity)||!CONFIG.pvp)) handleFriendlyHit(p, ev.hitEntity);
      else cast(p, ctx, ev.hitEntity);
    }
  });
  world.afterEvents.entityHitBlock.subscribe((ev) => {
    if (isPlayer(ev.damagingEntity)) onSwing(ev.damagingEntity);
  });

  // 웅크리기 시작 순간 감지
  const wasSneaking = new Map();
  system.runInterval(() => {
    for (const p of world.getAllPlayers()) {
      let now = false;
      try {
        now = p.isSneaking;
      } catch {
        continue;
      }
      if (now && !wasSneaking.get(p.id)) onSneakStart(p);
      wasSneaking.set(p.id, now);
    }
  }, 1);
}
```

## RPG_BP_v0597/scripts/core/rpgKnowledge.js

```javascript
import {dungeonMonsterLevel} from '../data/monsterLevels.js';
import {PROMOTION_RATES,GRADE_MULTIPLIERS,ARMOR_GRADE_HP} from '../data/grades.js';
import {RARITIES,itemRarity,runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {skillScalingInfo} from '../data/skillScaling.js';
import {isBalanceQuestion,isHiddenPromotionQuestion} from './assistantPolicy.js';
import {JOBS,APPRENTICE_SKILLS} from '../data/jobs.js';
import {SKILLS} from '../data/skills.js';
import {LINE_NOTES,SKILL_NOTES} from '../data/skillGuide.js';
import {JOB_TRIALS} from '../data/jobTrials.js';
import {CRAFTING_RECIPES} from '../data/crafting.js';
import {RUNES,ARMOR_SETS} from '../data/equipment.js';
import {upgradedRune,RUNE_MAX,ARMOR_MAX,MAX_CATALYSTS,upgradeCost,enhancementRates} from '../data/upgrades.js';
import {DUNGEON,DUNGEON_TIERS,clearRewardForTier,netheriteChanceForTier} from '../data/dungeons.js';
import {CONFIG} from '../config.js';
import {defaultDamageTypeFor} from './stats.js';
export const QUESTION_LIMIT=200;
export const UNKNOWN_ANSWER='이 애드온의 직업·스킬·룬·갑옷·제작·강화·던전·성장 정보만 안내합니다. 도감에 없는 내용은 확인할 수 없습니다. 예: 월룡륜미 범위 / 검사 전직 / 생명의 룬 / 샌드백 제작';
export const normalizeQuestion=s=>String(s??'').normalize('NFKC').toLowerCase().replace(/§./g,'').replace(/[^a-z0-9가-힣]/g,'');
const clean=s=>String(s??'').replace(/§./g,'').replace(/[\u0000-\u0008\u000b-\u001f]/g,'');
const bossName=id=>({rock_golem_boss:'바위 골렘',cyclops_boss:'외눈 거인',hydra_boss:'히드라',tech_block_golem_boss:'마공학 골렘'}[id]??'던전 보스');
const percent=n=>Number((n*100).toFixed(3))+'%';
function runeEffects(r){
 const a=[];if(r.physical)a.push('물리 피해 +'+percent(r.physical-1));if(r.magic)a.push('마법 피해 +'+percent(r.magic-1));
 if(r.defense)a.push('RPG 방어력 +'+Number(r.defense.toFixed(1))+' (피해 감소 '+percent(r.defense*.0035)+')');if(r.health)a.push('최대 HP +'+r.health);if(r.manaRegenPercent)a.push('초당 최대 MP의 '+percent(r.manaRegenPercent)+' 추가 회복');
 if(r.lifesteal)a.push('준 피해의 '+percent(r.lifesteal)+' HP 회복');if(r.ward)a.push('저항 '+(r.wardAmplifier+1)+'단계 유지');return a.join(', ');
}
const EFFECT_GROUPS=[
 {id:'damagebuff',title:'피해 증가·공격 강화 기술',match:q=>/딜뻥|공증|뎀증|힘버프|공격력버프|((데미지|대미지|피해|공격력|딜).*(버프|증가|강화|올려|높여))/.test(q),groups:[
 ['힘 효과를 주는 기술',['holy_sword','fist_stance','beast_berserk','blood_awaken','fire_armor','fire_emperor','sun_descent']],
 ['평타·후속 타격을 강화하는 기술',['war_god_black_flash','sun_slash','fist_strong','berserker_execute','assassin_stealth','dragon_triple_strike']],
 ['적이 받는 피해를 늘리는 기술',['assassin_mark','fallen_orb','berserker_charge']],
 ['적에게 힘을 주는 예외: 자가 공격 강화용 지원기가 아님',['demon_contract']]]},
 {id:'healing',title:'회복·흡혈 기술',match:q=>/회복|힐|치유|흡혈/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|있는|주는/.test(q),groups:[['회복·재생·흡혈 효과',['holy_heal','holy_orb','angel_bless','angel_zone','demon_vampirism','fallen_sword_frenzy','beast_berserk','moon_moonlight','sun_descent']]]},
 {id:'defense',title:'보호·방어 강화 기술',match:q=>/보호막|방어버프|저항버프|피해흡수/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['보호·저항·피해 흡수',['holy_shield','holy_orb','angel_bless','angel_zone','fallen_shield','fist_stance','fire_armor','sun_blessing','sun_descent','demon_contract']]]},
 {id:'control',title:'적 제어 기술',match:q=>/기절|동결|빙결|속박|둔화|cc/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['제어 효과를 갖는 기술 예시',['fist_face','frost_grasp','frost_absolute','blood_bind','tech_prison','sage_zero','moon_fullwave','sun_slash']]]}
];
function effectKnowledge(q){
 const g=EFFECT_GROUPS.find(g=>g.match(q));if(!g)return undefined;
 
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder&&j.id!=='chameleon');
 const groups=g.groups.map(([title,ids])=>title+'\n'+ids.filter(id=>SKILLS[id]&&SKILL_NOTES[id]).map(id=>{
 const skill=SKILLS[id],owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name).join('·');
 return '• '+skill.name+' ('+owners+'): '+SKILL_NOTES[id].split(/\.\s+(?=[가-힣A-Z])/)[0]+'.';
 }).join('\n')).join('\n\n');
 return Object.freeze({id:'effect:'+g.id,title:g.title,aliases:[],body:groups+'\n\n효과별 안내이며 강함·티어 순위가 아닙니다. 개별 기술명으로 상세 수치·조건을 확인하세요.',source:'data/skills.js · data/skillGuide.js · data/jobs.js'});
}
const PUBLIC_JOBS=new Set(['swordsman','mage','archer','fighter','cleric']);
let catalog;
export function knowledgeEntries(){
 if(catalog)return catalog;
 const entries=[];
 const add=(id,title,aliases,body,source)=>entries.push(Object.freeze({id,title,aliases:Object.freeze([...new Set([title,...aliases].map(normalizeQuestion).filter(x=>x.length>=2))]),body:clean(body),source}));
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder),active=new Set([...jobs.flatMap(j=>j.skills),...Object.values(APPRENTICE_SKILLS).flat()]);
 for(const id of active){
  const s=SKILLS[id];if(!s||!SKILL_NOTES[id])continue;
  const owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name);
  add('skill:'+id,s.name,[id,s.name.replace(/\s*\([^)]*\)/g,''),s.name.replace(/\s*제작$/,'')],`피해 보정: ${skillScalingInfo(id)}\n기본 MP ${s.mana} / 쿨 ${s.cooldown/20}초\n${SKILL_NOTES[id]}\n사용 직업: ${owners.join('·')}\n피해 수치는 스탯·힘 버프·장비 보정 전입니다.`, 'data/skills.js · data/skillGuide.js');
 }
 for(const j of jobs){
  const publicPromotion=PUBLIC_JOBS.has(j.id);
  const trial=publicPromotion?JOB_TRIALS[j.id]:undefined,condition=trial?`레벨 ${trial.level}\n`+['all','any'].filter(k=>trial[k]).map(k=>trial[k].map(c=>`${c.label} ${c.need}`).join(k==='all'?' + ':' 또는 ')).join('\n'):'견습 시작 직업';
  const from=trial?.allowedFrom?.map(id=>JOBS[id].name).join('·')??(j.hidden&&j.parent===null?'아무 2차 이상 직업':JOBS[j.parent]?.name??'없음');
  const type=defaultDamageTypeFor({getDynamicProperty:()=>j.id});
  const special=!publicPromotion?'전직 방법·조건은 공개하지 않습니다.':j.id==='hacker'?'전직: 로토와 23회 대화 후 퀴즈 정답. 월드 최초 정답자 1명만 전직 가능. 직업·레벨 제한 없음.':`직전 직업: ${from}\n전직 조건: ${condition}`;
  const shrine=trial?.shrine?`\n전직 장소: 천체 신전의 ${trial.shrine==='sun'?'해 제단·낮':'달 제단·밤'} 4칸 안. /rpg:temple에서 위치 확인.`:'';
  const extra='';
  add('job:'+j.id,j.name,[j.id],`${special}${extra}${shrine}\n기본 피해 계열: ${type==='magic'?'마력(마법)':'근력(물리)'}. 개별 기술에 다른 피해 판정이 있으면 해당 판정을 따릅니다.\n보유 기술: ${j.skills.map(id=>SKILLS[id]?.name??id).join('·')||'시작 장비에 따라 사용'}\n${j.id==='chameleon'?LINE_NOTES.chameleon:''}`,'data/jobs.js · data/jobTrials.js · data/skillGuide.js');
 }
 for(const [id,r]of Object.entries(RUNES)){
  const recipe=CRAFTING_RECIPES.find(c=>c.id==='rpg:rune_'+id);
  add('rune:'+id,r.name,[r.name.replace('의 ',''),'rune_'+id],`등급: 일반~신화, 강화와 별개인 합성 승급. 힘·비전 룬은 +1부터 공용·직업 무기 근접 평타에도 추가 피해를 줍니다. 두 룬의 평타 추가 피해율은 합산합니다. 아래는 일반 등급 기준\n기본: ${runeEffects(upgradedRune(r,0))}\n최대 +${RUNE_MAX}: ${runeEffects(upgradedRune(r,RUNE_MAX))}\n/rpg:runes 보관함에서 장착해야 효과를 받습니다.\n${recipe?.text??'룬 드롭으로 획득'}`,'data/equipment.js · data/upgrades.js · data/crafting.js');
 }
 for(const [id,a]of Object.entries(ARMOR_SETS))add('armor:'+id,a.name+' 갑옷',[a.name,id,...(id==='abyssal'?['심연갑옷','상위갑옷','네더라이트이상']:[])],`${a.description}\n등급: 일반~신화. 부위당 등급 추가 HP ${ARMOR_GRADE_HP.join(' / ')}\n부위별 방어력: ${a.protection.join(' / ')}\n최대 강화 +${ARMOR_MAX}. 부위별 제작법은 /rpg:craft에서 확인하세요.`,'data/equipment.js · data/upgrades.js');
 for(const r of CRAFTING_RECIPES)add('craft:'+r.id,r.name+' 제작법',[r.name,r.id,r.name.replace('훈련용 ','').replace(' 소환',''),...(r.id==='rpg:stat_reset_scroll'?['스탯초기화']:[])],r.text,'data/crafting.js (실제 조합법에서 생성)');
 add('rule:offer','검과 책 바치기',['공물','바치기','검바치기','책바치기'], '/rpg:offer: 검과 책을 바칩니다. 인벤토리에서 현재 직업과 진행도에 맞게 소비합니다. 바친 아이템은 사라집니다. 효과부여 책은 시련과 마나 공물 중 현재 필요한 용도로 사용됩니다.','core/offer.js');
 add('rule:huntingzones','사냥 구역과 자연 출현',['사냥구역','초반사냥','중반사냥','후반사냥','몹스폰','몬스터출현'], '오버월드 X·Z 중 절댓값이 큰 좌표를 기준으로 초반 ±1500, 초반 밖 중반 ±4000, 중반 밖 후반 ±10000입니다. 경계는 안쪽 구역에 포함하고 10000 밖도 후반을 유지합니다. 밤에는 구역에 맞는 RPG 몬스터가 출현합니다. 바닐라 적대 몹 자연 출현은 동굴로 제한합니다. 사막 몬스터는 사막에서 밤낮·좌표 제한 없이 출현합니다.','data/huntingZones.js · spawn_rules');
 add('rule:rarity','아이템 등급·합성',['등급','아이템등급','무기등급','갑옷등급','룬등급','희귀도','합성','승급'],RARITIES.join(' → ')+'\n룬·RPG 갑옷·공용 무기 7종은 모두 일반~신화가 존재합니다. 같은 종류·같은 등급의 +5 이상 두 개를 /rpg:fuse에서 합성합니다. 성공하면 다음 등급 +0, 실패하면 두 장비를 보존하며 50% 확률로 주장비만 -1강. 둘 다 +10이면 성공률 100%. 신화는 최종 등급. 갑옷은 보호 IV 책 1권, 공용 무기는 날카로움 V 책 1권이 추가로 필요하고 성공·실패 모두 소모합니다. 룬은 책이 필요 없습니다.\n다음 등급 성공률: '+PROMOTION_RATES.join(' / ')+'%. 무기 기본 피해·룬 수치 효과 배율: '+GRADE_MULTIPLIERS.join(' / ')+'. 갑옷 부위당 추가 HP: '+ARMOR_GRADE_HP.join(' / ')+'. 직업 기본 무기는 등급·승급 없이 +10 강화만 가능하며, 강화 단계당 근접 피해 +1·물리/마법 스킬 피해 +2%. 고정 피해·회복량은 제외. 바닐라 장비는 제외.','data/grades.js · core/fusion.js');
 add('rule:armor','갑옷 종류·제작',['갑옷','방어구'],Object.values(ARMOR_SETS).map(a=>a.name+': '+a.description).join('\n')+'\n4부위를 같은 세트로 입어야 세트 효과를 받습니다. /rpg:craft에서 부위별 제작법, /rpg:upgrade에서 강화를 확인하세요.','data/equipment.js · data/crafting.js');
 add('rule:scalingjobs','근력·마력 직업 안내',['근력직업','마력직업','근력캐','마력캐','힘캐','마법직업'],['근력(물리) 기본 계열: '+jobs.filter(j=>j.id!=='apprentice'&&defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='physical').map(j=>j.name).join('·'),'마력(마법) 기본 계열: '+jobs.filter(j=>defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='magic').map(j=>j.name).join('·'),'직업 기본 계열과 개별 기술은 다를 수 있습니다. 풍압·용의 브레스는 마력, 달 계열 공격은 근력, 메테오드라이브/혈인은 혼합, 대미장식은 고정 피해입니다. 스킬명과 함께 물어보세요.'].join('\n'),'core/stats.js · data/skillScaling.js');
 add('rule:damage','피해 계산·힘 버프',['힘버프','힘효과','힘스킬','마법딜','고정피해','마법피해','피해계산'],`힘 효과는 물리·마법 스킬 피해를 단계당 ${CONFIG.skillDamage.strengthPerLevel*100}% 증가시킵니다. 힘 I +5%·II +10%·III +15%. 단타와 연타 총합에 같은 비율로 적용합니다. 이후 물리는 근력, 마법은 마력과 장비·룬 보정을 받습니다. 고정 피해는 유지합니다.\n무투가 기존 힘 계산 및 평타 배수에는 중복 적용하지 않습니다. 기본 평타의 힘 효과는 마인크래프트 엔진 규칙입니다.`,'core/stats.js · skills/fist.js');
 add('rule:transfer','갑옷 강화 이전',['강화이전','이전서','강화추출'],`/rpg:transfer에서 제작 전에 강화를 이전서로 추출하세요. 단계당 골드 500, 원래 갑옷은 +0. 새 RPG 갑옷을 만든 뒤 같은 부위에 100% 적용하며 이전서는 소모됩니다. 기존 단계보다 높은 이전서만 적용하며 합산하지 않습니다. 인챈트·내구도는 대상 장비 것을 유지합니다.`,'core/armorTransfer.js');
 add('rule:bosscc','보스 CC 저항',['보스cc','보스기절','보스빙결','보스둔화'],`커스텀 보스 4종·드래곤·위더·워든에게 기절·빙결·둔화·속박 1회 지속시간은 50%, 넉백·끌어당김 강도는 50%입니다. 일반 몬스터와 플레이어는 그대로입니다. 장판에서 CC를 다시 적용하는 동작은 유지하며, 피해·화상·독은 CC 감소 대상이 아닙니다.`,'core/crowdControl.js');
 add('rule:farm','좀벌레 보상',['좀벌레','좀벌레팜','공장'],`좀벌레는 XP 5, 골드 2, 강화석·룬 가루 0, 룬 확률 0.1%입니다. 일반 적과 다른 전용 보상을 적용합니다.`,'core/economy.js · core/runeDrops.js');
 add('rule:commonweapons','공용 전투 무기',['공용무기','무기제작','평타무기'],COMMON_WEAPONS.map(w=>w.name+': 추가 근접 피해 설정 '+w.damage+'·내구도 '+w.durability).join('\n')+'\n누구나 제작하는 평타용 무기입니다. 직업 스킬은 기존 전용 아이템으로 사용합니다. /rpg:craft에서 재료를 확인하세요.','data/commonWeapons.js · data/crafting.js');
 for(const w of COMMON_WEAPONS)add('weapon:'+w.key,w.name,[w.key,w.id],`공용 RPG 평타 무기. 일반~신화 합성 승급 가능, 최대 +10 강화(단계당 추가 근접 피해 +1) · 추가 근접 피해 설정 ${w.damage}·내구도 ${w.durability}. 직업 제한 없음. /rpg:craft에서 제작법을 확인하세요. 직업 스킬은 전용 아이템을 사용합니다.`,'data/commonWeapons.js');
 add('rule:stats','레벨·스탯',['스탯','근력','마력','지능','체력스탯','레벨업'],`자연 성장 최대 레벨 100, 레벨마다 SP 3. 근력·체력·마력 투자 상한 없음. 지능 최대 50이며 마나 소모 감소는 최대 40%.\n근력은 물리 피해, 마력은 마법 피해·회복량, 체력은 최대 HP입니다. /rpg:stats에서 분배합니다.`,'core/stats.js');
 add('rule:pvp','PvP·결투·PK',['pvp','피케이','결투','현상금','pk패널티'], '일반 PvP 허용. /rpg:pvp 또는 지원되는 환경의 /pvp로 신청하고 서로 수락하면 PvP장으로 이동하여 최대 HP로 회복 후 3초 뒤 결투 시작, 패배 직전 비살상 종료합니다. 결투 밖 플레이어 살인은 PK 표식. PK 플레이어를 죽이면 그 지갑에서 최대 50,000골드를 지급하고 새 PK가 되지 않습니다. 잔액만 지급하며 부족분은 생성하지 않습니다. PK는 플레이어에게 처치돼야 해제됩니다. 던전에서는 결투 불가.','core/pvp.js');
 add('rule:party','파티 경험치',['파티','경험치','쩔','xp'],`최대 4명. 같은 차원·처치자 ${CONFIG.partyXp.radius}칸 안·생존한 파티원은 각자 원래 XP의 ${percent(CONFIG.partyXp.multiplier)} 획득. 90 XP 몹이면 각자 ${90*CONFIG.partyXp.multiplier} XP.\n일반 마크 생물 10, 대부분 적대 몹 30, 좀벌레·좀비화 피글린 5 XP. 커스텀 몹/보스는 별도 값.\n전직 처치는 최근 30초 공격·탱킹·유효 회복에 기여한 같은 차원·시체 32칸 안 생존 파티원도 인정합니다.`,'config.js · data/mobXp.js · core/combatContribution.js');
 add('rule:runes','룬 획득·장착',['룬','룬획득','룬드랍','룬드롭','룬장착'],`일반 몬스터 1%·RPG 엘리트 3%·보스 30% 확률로 룬 드롭(좀벌레만 0.1%). 현재 룬 ${Object.values(RUNES).map(r=>r.name).join('·')}.\n/rpg:runes 전용 보관함 30칸, 장착 3개. 같은 종류는 하나만 장착. 원하는 룬은 /rpg:craft 제작법을 확인하세요.`,'core/runeDrops.js · loot_tables/rpg · core/runeInventory.js');
 const ar=enhancementRates('armor',ARMOR_MAX-1),rr=enhancementRates('rune',RUNE_MAX-1),ac=upgradeCost('armor',ARMOR_MAX-1),rc=upgradeCost('rune',RUNE_MAX-1);
 add('rule:classweapon','직업 기본 무기 강화',['직업무기강화','기본무기강화','직업무기등급'], '직업·견습 기본 무기 36종은 /rpg:upgrade에서 +10까지 강화합니다. 등급·승급은 없습니다. 강화당 근접 피해 +1, 그 무기를 들고 사용하는 물리·마법 스킬 피해 +2%(+10은 +20%). 고정 피해와 회복량은 증가하지 않습니다. 공용 무기와 같은 비용·실패·강등·파괴·촉매 규칙입니다. 카멜레온 무기 전환과 직업 무기 재지급·전직 시 강화 단계를 유지합니다.','data/classWeapons.js · core/upgrades.js');
 add('rule:upgrade','강화·촉매·재화',['강화','촉매','골드','강화석','룬가루'],`/rpg:upgrade에서 갑옷·공용·직업 무기 최대 +${ARMOR_MAX}, 룬 최대 +${RUNE_MAX}. 실패·강등·파괴에도 비용 소모.\n갑옷 마지막 단계: 골드 ${ac.gold}·강화석 ${ac.stone}, 성공 ${ar.success}% / 유지 ${ar.fail}% / 강등 ${ar.downgrade}% / 파괴 ${ar.destroy}%.\n룬 마지막 단계: 골드 ${rc.gold}·룬 가루 ${rc.dust}, 성공 ${rr.success}% / 유지 ${rr.fail}% / 강등 ${rr.downgrade}% / 파괴 ${rr.destroy}%.\n촉매는 갑옷·무기 +5·룬 +2부터 1회 최대 ${MAX_CATALYSTS}개, 1개당 성공 +9%p·파괴 -3%p(파괴 0% 하한). 최종 확률은 확인창에 표시.`,'data/upgrades.js');
 add('rule:monsterlevels','몬스터 레벨',['몬스터레벨','몹레벨','필드레벨','던전난이도'], 'RPG 몬스터 22종은 레벨에 따라 체력·공격·방어가 증가합니다. 초반 필드 Lv.1/5/10/15, 중반 Lv.20/30/40/55, 후반 Lv.70/90/115/145. 같은 종도 여러 레벨로 등장합니다. 10단계는 일반 Lv.145~220, 엘리트 Lv.220, 보스 Lv.260입니다. 무기·RPG 갑옷·장착 룬 전설 +10 수준의 4인 파티 권장선이며 장비 입장 제한은 없습니다. 고정 피해는 레벨 방어를 상쇄합니다.','data/monsterLevels.js');
 add('rule:dungeon','던전 입장·진행',['던전','던젼','보스제한시간','솔플','솔로보상','혼자던전'],`난이도 ${DUNGEON_TIERS.length}개. /rpg:dungeon에서 참가, /rpg:dungeonstart로 최대 ${DUNGEON.maxParty}명 출발. 혼자는 /rpg:dungeonsolo 1. 처음부터 혼자 출발하면 클리어 골드·강화석·룬 가루·촉매 1.5배(올림). 룬·보급품·처치 보상은 그대로입니다.\n파티는 일반 ${DUNGEON.normalCount}·엘리트 ${DUNGEON.eliteCount}마리를 ${DUNGEON.mobLimitMs/60000}분 안에 처치한 뒤 보스 1마리를 ${DUNGEON.bossLimitMs/60000}분 안에 잡습니다. 혼자 출발하면 전반 7분 30초·보스 4분 30초입니다. 몹이 없으면 후속 몹이 일찍 나옵니다. 전투 중 임의 퇴장 불가, 사망·완료·제한시간 종료로 귀환.\n종료 시 남은 아이템과 몹의 마크 XP를 피해+유효 회복 기여도에 따라 분배합니다. RPG 처치 XP는 기존 방식이며 가방 부족 전리품은 /rpg:dungeonloot로 받습니다.\n관리자 생성: /rpg:dungeoncreate 1 또는 all.`,'data/dungeons.js · core/dungeons.js');
 for(const d of DUNGEON_TIERS){const r=clearRewardForTier(d.tier),solo=clearRewardForTier(d.tier,true);add('dungeon:'+d.tier,`던전 ${d.tier} ${d.name}`,[d.name,'던전'+d.tier,d.tier+'번던전',d.tier+'단계던전',d.tier+'티어던전'],`난이도 ${d.tier}. 일반 Lv.${dungeonMonsterLevel(d.tier,'normal',0)}~${dungeonMonsterLevel(d.tier,'normal',2)}, 엘리트 Lv.${dungeonMonsterLevel(d.tier,'elite')}, 보스 Lv.${dungeonMonsterLevel(d.tier,'boss')}. 10단계는 전설 +10 세트 권장, 입장 제한 없음. 보스: ${bossName(d.boss)}.\n클리어 보상: 골드 ${r.gold}·강화석 ${r.stone}·룬 가루 ${r.dust}·촉매 ${r.catalysts}·룬 ${r.runes}개. 보급품 ${r.supplyMultiplier}배. 솔로 클리어는 골드 ${solo.gold}·강화석 ${solo.stone}·룬 가루 ${solo.dust}·촉매 ${solo.catalysts}입니다. 던전 엘리트는 다이아 1개 40%·3개 10%·없음 50%로 공동 전리품을 남깁니다. 클리어 시 네더라이트 주괴 1개 확률 ${Math.round(netheriteChanceForTier(d.tier)*100)}%(6~10단계 한정, 각자 추첨). 개별 몬스터 처치 재화는 별도.`,'data/dungeons.js');}
 add('rule:temple','해·달의 신전',['신전','해의신전','달의신전','천체신전'],'낮에는 해의 제단, 밤에는 달의 제단이 활성화되는 구조물입니다. 히든 직업의 전직 방법·조건은 안내하지 않습니다.','data/temple.js');
 add('rule:melee','추가 근접 피해 없는 기본 아이템',['근접피해없는직업','근접데미지없는직업','기본아이템피해'],`기본 아이템에 추가 근접 피해 설정이 없는 직업은 마법사·현자·궁수·천궁·성직자·천사·미카엘·타락천사입니다. 공격이 완전히 0인 뜻은 아니며 맨손 수준 기본 피해·힘·인챈트와 화살/스킬 피해는 별도입니다. 공용 전투검/전투창으로 근접 사냥을 보완할 수 있습니다.`,'items/*.json · data/jobs.js');
 add('rule:start','처음 시작',['초보','시작','처음','막혔','막힘'],`/rpg:guide의 견습 5계열 체험에서 시작 계열과 관계없이 검·마법·활·격투·회복 견습 장비를 바꿔 사용할 수 있습니다. 빵과 화살은 처음 한 번만 지급합니다. 첫 전직은 레벨 10과 각 직업 시련이 필요합니다. /rpg:jobs에서 현재 전직 조건, /rpg:craft에서 재료, /rpg:skillguide에서 기술을 확인하세요.`,'core/beginner.js · core/jobMenu.js');
 catalog=Object.freeze(entries);return catalog;
}
export function lookupRpgQuestion(question){
 const raw=String(question??'').trim();if(!raw)return {status:'empty',entries:[]};
 if(raw.length>QUESTION_LIMIT)return {status:'too_long',entries:[]};
 if(isBalanceQuestion(raw))return {status:'balance',entries:[]};
 if(isHiddenPromotionQuestion(raw))return {status:'hidden',entries:[]};
 const q=normalizeQuestion(raw);if(!q)return {status:'unknown',entries:[]};
 if(/전직(방법|조건|하는법|하려면|알려)|직업.*조건/.test(q)&&!Object.values(JOBS).some(j=>j.id!=='apprentice'&&q.includes(normalizeQuestion(j.name)))){return {status:'answer',entries:[{id:'rule:publicpromotions',title:'공개 전직 안내: 기본 직업 5종',body:knowledgeEntries().filter(e=>['job:swordsman','job:mage','job:archer','job:fighter','job:cleric'].includes(e.id)).map(e=>e.title+'\n'+e.body).join('\n\n'),source:'data/jobTrials.js'}],effect:true};}
 const named=knowledgeEntries().some(e=>e.id.startsWith('skill:')&&e.aliases.some(a=>q.includes(a)));
 const effect=!named&&effectKnowledge(q);if(effect)return {status:'answer',entries:[effect],effect:true};
 const ranked=knowledgeEntries().map(e=>({entry:e,score:Math.max(0,...e.aliases.filter(a=>q.includes(a)&&(!/[0-9]$/.test(a)||new RegExp(a+'(?![0-9])').test(q))).map(a=>a.length*10+(/등급|희귀도/.test(q)&&/^(weapon|armor|rune):/.test(e.id)?100:0)+(named&&/근력|마력|물리|마법|피해계열/.test(q)&&e.id.startsWith('skill:')?100:0)+(e.id.startsWith('skill:')?2:e.id.startsWith('rune:')?3:0)+(e.id.startsWith('craft:')&&/제작|만드|만들|조합|재료/.test(q)?5:0)))})).filter(e=>e.score>0).sort((a,b)=>b.score-a.score||a.entry.id.localeCompare(b.entry.id));
 return {status:ranked.length?'answer':'unknown',entries:ranked.slice(0,6).map(r=>r.entry)};
}
// Only canonical records may be rendered; remote services cannot inject answer text.
export function selectKnowledgeEntries(candidates,ids){
 if(!Array.isArray(ids)||ids.length>3||ids.some(id=>typeof id!=='string'))return undefined;
 const unique=[...new Set(ids)],selected=unique.map(id=>candidates.find(e=>e.id===id));
 return selected.some(e=>!e)?undefined:selected;
}
export function formatKnowledge(entries){
 if(!entries?.length)return UNKNOWN_ANSWER;
 return entries.slice(0,3).map(e=>`${e.title}\n${e.body}`).join('\n\n')+'\n\n자료: 이 애드온의 게임 도감 v0.5.78';
}
```

## RPG_BP_v0597/scripts/core/rulebook.js

```javascript
import {layoutRulebook} from '../data/rulebookLayout.js';
// 명령어 책 페이지는 v0.4.82의 실제 등록 명령어 목록을 기반으로 작성.
// ItemBookComponent는 @minecraft/server 2.2.0부터 지원.
import { ItemStack } from "@minecraft/server";

export const RULEBOOK_SECTIONS = [
  "§l§61. RPG 서버 종합 룰북§r\n\n일반 PvP가 허용됩니다. 결투는 /rpg:pvp 메뉴에서 신청하고 상대가 수락해야 합니다. 두 사람의 체력을 채운 뒤 3초 후 시작하며 패배 직전 비살상 종료합니다.\n\n결투 밖 살인은 PK 표식·현상금 패널티. 건축물 훼손·약탈은 하지 마세요. 던전·신전 보호는 유지합니다.",
  "§l§62. 목차§r\n\n기초 지식·사냥 구역\n시작 안내·전투 조작·공물\n전직·스탯·파티·길드\n재화·룬·갑옷·무기\n강화·촉매·등급·합성\n던전·신전·초기화 아이템\n정보 질문·서바이벌 명령어\n\n주제 번호순으로 정리했습니다.",
  "§l§63. 기초 지식§r\n\nRPG 경험치와 바닐라 초록 경험치바는 별개입니다.\n/rpg:stats에서 RPG 레벨·SP를 확인하세요.\n\nRPG 레벨이 오를 때 SP 3개를 받습니다. 자연 성장은 레벨 100까지입니다.\nHP 2는 하트 1칸입니다.",
  "§l§64. 사냥 구역 기준§r\n\n오버월드 X·Z 중 절댓값이 큰 좌표로 구분합니다. 높이 Y는 무관합니다.\n\n초반: -1,500~+1,500\n중반: 초반 밖, -4,000~+4,000\n후반: 중반 밖, -10,000~+10,000\n\n경계는 안쪽 구역. 1만 밖도 후반 몬스터가 계속 나옵니다.",
  "§l§65. 밤의 사냥§r\n\n밤에는 현재 사냥 구역에 맞는 RPG 몬스터가 나옵니다. 바깥 구역일수록 강한 적을 만나게 됩니다.\n\n초반: 버섯·초록 고블린\n중반: 빨강·황금 고블린·대장\n후반: 엘리트 버섯·고블린\n\n밤이 되어도 조명·공간·몹 수에 따라 출현량은 달라집니다.",
  "§l§66. 동굴과 사막§r\n\n바닐라 적대 몹은 오버월드 동굴에서 자연 출현합니다.\n\n사막에서는 밤낮과 사냥 구역 좌표에 상관없이 사막 몬스터가 나옵니다.\n전갈·사마귀·데스웜과 엘리트가 있으니 초반에도 주의하세요.\n\n동물은 먹거리와 목장 운영에 활용하세요.",
  "§l§67. 처음 시작하기§r\n\n/rpg:guide\n원할 때 시작 장비와 안내를 받습니다. 첫 접속에 계열 선택창은 자동으로 뜨지 않습니다.\n\n/rpg:guide의 견습 5계열 체험에서 시작 계열과 관계없이 장비를 바꿔 써보세요. 빵과 화살은 처음 한 번만 지급합니다. 첫 사냥 5마리를 완료하면 같은 안내창에서 보상을 받으세요.",
  "§l§68. 전투 조작§r\n\n직업 전용 아이템을 손에 들고 사용하세요. 웅크리면 다음 기술로 전환합니다.\n\n대부분 우클릭/아이템 사용으로 시전합니다. 활과 대상 지정 회복 등은 조작이 다릅니다.\n/rpg:skills에서 기술을 켜거나 끕니다.\n/rpg:skillguide에서 효과·MP·쿨타임을 확인하세요.",
  "§l§69. 검과 책을 바칩니다§r\n\n/rpg:offer\n\n인벤토리의 검과 효과부여 책을 현재 직업·진행도에 맞게 바칩니다. 바친 아이템은 소비됩니다.\n\n검사 기본 시련에는 다이아몬드 검을 사용합니다. 마법사 기본 시련에는 효과부여 책을 사용합니다.\n검은 시련 수량까지만 소비합니다. 책은 직업에 따라 마나 공물로도 사용됩니다.",
  "§l§610. 기본 직업과 정보§r\n\n검사·마법사·궁수·무투가·성직자가 기본 직업입니다. 첫 전직은 레벨 10과 직업별 시련이 필요합니다.\n\n/rpg:job <직업>\n전직을 요청합니다.\n/rpg:jobs\n직업 정보를 확인합니다.\n\n이 책에는 히든 직업의 전직 방법을 적지 않습니다.",
  "§l§611. 스탯과 마나§r\n\n근력: 물리 스킬 피해\n마력: 마법 스킬 피해·직접 회복\n체력: 최대 HP\n지능: 기술 MP 소모 감소\n\n지능 할인은 최대 40%입니다. 근력·마력·체력은 투자 상한이 없습니다.\n마법·성직 고마나 직업은 책 공물로 최대 마나를 늘릴 수 있습니다.",
  "§l§612. 파티 사냥§r\n\n/rpg:party · /rpg:invites\n파티를 만들고 초대를 수락하세요. 최대 4명입니다.\n\n같은 차원·처치자 32칸 안·생존 중인 파티원은 각자 원래 XP의 75%를 받습니다.\n예: 90 XP 몹 → 각자 67.5 XP.\n레벨 차이로 나눠 갖는 방식은 아닙니다.",
  "§l§613. 길드와 전직 기여§r\n\n/rpg:guild\n길드 생성·초대·관리를 합니다. 길드만 같다고 XP를 공유하지는 않습니다.\n\n전직용 처치는 최근 30초간 공격·탱킹·유효 회복에 기여한 파티원도 인정됩니다. 같은 차원·처치 위치 32칸·생존 조건을 충족해야 합니다.",
  "§l§614. 재화와 제작§r\n\n/rpg:wallet\n골드·강화석·룬 가루를 확인합니다.\n골드: 공통 강화 비용\n강화석: 갑옷·공용 무기 강화\n룬 가루: 룬 강화\n\n/rpg:craft\n실제 조합법과 획득법을 봅니다. 제작은 작업대에서 합니다.",
  "§l§615. 룬 획득§r\n\n일반 몬스터: 1%\n엘리트 몬스터: 3%\n보스 몬스터: 30%\n좀벌레: 0.1%\n\n드롭 룬은 바닥에 1개이며 파티원별로 복제되지 않습니다.\n원하는 룬은 /rpg:craft에서 재료를 확인해 제작할 수도 있습니다.",
  "§l§616. 룬 보관·장착§r\n\n/rpg:runes\n일반 가방의 룬을 전용 보관함에 넣고 장착하세요. 들고만 있어서는 효과를 받지 않습니다.\n\n보관 30칸·장착 3개. 같은 종류는 1개만 장착합니다.\n갑옷과 독립적입니다. 강화·승급 룬은 전용 보관함에서 관리합니다.",
  "§l§617. 힘·비전의 룬§r\n\n일반 등급 기준\n\n힘의 룬: 물리 스킬 피해 +10% → +10 강화 시 +30%.\n\n비전의 룬: 마법 스킬 피해 +10% → +10 강화 시 +30%.\n\n고정 피해에는 일반 피해 증가 보정이 적용되지 않습니다.",
  "§l§618. 샘·생명의 룬§r\n\n일반 등급 기준\n\n샘의 룬: 초당 최대 마나의 1% 추가 회복 → +10 강화 시 3%.\n\n생명의 룬: 최대 HP +4 → +10 강화 시 +24.\n실제 최대 HP는 기존 엔진 효과에 따라 4 HP 단위로 근사됩니다.",
  "§l§619. 수호·흡수의 룬§r\n\n일반 등급 기준\n\n수호의 룬: RPG 방어력 +4, 강화마다 +2. 일반 +10은 방어력 +24(룬 피해 감소 8.4%)와 기존 HP 보너스. 저항 효과는 부여하지 않습니다.\n\n흡수의 룬: 적에게 준 실제 피해의 5%를 HP로 회복 → +10에서 12%.\n받는 피해를 줄이는 룬이 아닙니다.",
  "§l§620. RPG 갑옷§r\n\n같은 종류의 갑옷 4부위를 착용해야 세트 효과를 받습니다.\n\n모험가: 물리 스킬 +8%\n숲 수호자: 최대 HP +8\n별빛 술사: 마법 스킬 +8%, 초당 MP +3\n심연 수호자: 최대 HP +16, 물리·마법 +8%, 저항 I\n\n/rpg:equipment에서 관리하세요.",
  "§l§621. 공용 무기 7종§r\n\n적월선\n마공학 검\n마공학 대검\n정예기사의 대검\n빙설의 대검\n화염의 대검\n마수의 도끼\n\n직업 제한 없이 제작하는 평타 무기입니다. 직업 기술은 기존 전용 아이템을 사용하세요. 제작법은 /rpg:craft.",
  "§l§622. 강화와 위험§r\n\n/rpg:upgrade\n착용 RPG 갑옷·손에 든 공용·직업 무기·보관함 룬을 최대 +10까지 강화합니다.\n\n성공·유지 실패·1단계 강등·파괴가 있습니다. 높은 단계일수록 위험합니다. 모든 완료된 시도에서 비용이 소비됩니다. 확인창을 읽고 진행하세요.",
  "§l§623. 촉매와 이전§r\n\n촉매는 한 번에 최대 5개. 개당 성공률 +9%p·파괴 확률 -3%p입니다. 강등·파괴를 제외한 확률 상한을 적용합니다.\n갑옷·무기 +5, 룬 +2부터 사용합니다.\n\n/rpg:transfer\n갑옷 강화는 제작 전에 이전서로 추출하세요. 같은 부위에 강화 단계만 이전하며 등급·인챈트는 옮기지 않습니다.",
  "§l§624. 장비 등급§r\n\n일반 → 레어 → 에픽 → 고대 → 영웅 → 전설 → 신화\n\n룬·RPG 갑옷·공용 무기에 각각 등급이 있습니다. 직업 전용 아이템은 등급·승급 없이 +10 강화만 가능합니다. 단계당 근접 피해 +1·물리/마법 스킬 +2%입니다.\n\n등급은 무기 기본 피해·룬 수치형 효과·갑옷 추가 HP에 영향을 줍니다. 일반 강화만으로 등급이 오르지는 않습니다.",
  "§l§625. 장비 합성§r\n\n/rpg:fuse\n같은 종류·같은 등급의 +5 이상 장비 두 개를 합성합니다. 갑옷은 세트·부위도 같아야 합니다.\n\n성공: 다음 등급 +0\n실패: 두 장비 보존, 50%로 주장비 -1강. 둘 다 +10이면 확정 승급\n\n갑옷은 보호 IV 책, 공용 무기는 날카로움 V 책 1권 추가. 성공·실패 모두 소모하며 룬은 제외합니다.\n\n승급 확률은 순서대로 90/85/80/75/70/60%. 신화가 최종 등급입니다.",
  "§l§626. 던전 입장§r\n\n/rpg:dungeon\n난이도 1~10 중 본인이 원하는 대기실에 참가합니다. 몬스터 레벨은 후반일수록 높습니다. 10단계는 무기·갑옷·장착 룬 전설 +10 세트 권장, 입장 제한 없음.\n/rpg:dungeonstart\n대기실 첫 참가자가 1~4명으로 출발합니다.\n/rpg:dungeonsolo <1~10>\n혼자 바로 출발합니다. 파티원을 자동으로 이동시키지 않습니다.",
  "§l§627. 던전 진행·실패§r\n\n일반 몬스터 50마리·엘리트 5마리를 5분 안에 잡으세요. 모두 잡으면 보스 1마리가 나옵니다. 보스는 등장 후 3분 제한입니다. 혼자 출발하면 일반·엘리트 7분 30초, 보스 4분 30초입니다.\n\n시간 초과·전원 사망이면 실패하며 내부 몹을 보상 없이 정리합니다. 전직관·GPT NPC는 보존됩니다.",
  "§l§628. 던전 귀환·보상§r\n\n종료 시 남은 아이템·몹의 마크 XP를 피해+유효 회복 기여도로 나눕니다. RPG 처치 XP는 기존 방식입니다.\n\n전투 중 임의로 나갈 수 없습니다. 경계 밖으로 이탈하면 복귀됩니다.\n/rpg:dungeonleave\n대기를 취소하거나 사망 후 귀환합니다.\n/rpg:dungeonloot\n가방 부족으로 보관된 보급품과 분배 전리품을 받습니다.\n\n처음부터 혼자 출발하면 주요 클리어 재화가 1.5배입니다.\n\n던전 엘리트 다이아: 1개 40%·3개 10%·없음 50%(공동 전리품).\n6~10단계 클리어: 각자 네더라이트 주괴 1개를 10/15/20/25/30% 확률로 받습니다.",
  "§l§629. 신전·구조물 보호§r\n\n낮에는 해의 제단, 밤에는 달의 제단이 활성화됩니다.\n/rpg:temple\n신전의 위치와 현재 상태를 확인합니다.\n\n등록된 던전·신전은 채굴·폭발·블록 변형으로부터 보호됩니다. 제단과 전직관을 사용하는 것은 가능합니다.",
  "§l§630. 성장 초기화 아이템§r\n\n스탯 초기화 주문서: 배분한 스탯 SP를 되돌립니다.\n전직 포기각서: 현재 직업을 포기하고 견습으로 돌아갑니다.\n\n제작법은 /rpg:craft. 사용 확인창을 읽으세요. 전직 포기는 기술 구성을 바꾸지만 레벨·재화·장비를 삭제하지 않습니다.",
  "§l§631. 정보 질문과 도감§r\n\n/rpg:ask <질문>\n또는 GPT NPC와 대화하세요.\n기술 효과·물리/마법 판정·제작·룬·던전 정보를 안내합니다.\n\n밸런스 순위·사기 직업 평가는 하지 않습니다. 전직 방법 안내는 기본 5직업만 제공합니다.\n/rpg:skillguide: 기술 상세 도감",
  "§l§632. 서바이벌 명령어 1§r\n\n/rpg:guide 시작 안내\n/rpg:status 내 상태\n/rpg:stats 스탯 배분\n/rpg:skills 기술 켜기/끄기\n/rpg:offer 검과 책을 바칩니다\n/rpg:craft 제작·획득 도감\n/rpg:wallet 지갑\n/rpg:equipment 장비 메뉴\n/rpg:runes 룬 보관·장착",
  "§l§633. 서바이벌 명령어 2§r\n\n/rpg:upgrade 강화\n/rpg:fuse 등급 합성\n/rpg:transfer 갑옷 강화 이전\n/rpg:party 파티\n/rpg:guild 길드\n/rpg:invites 초대 확인\n/rpg:dungeon 던전\n/rpg:temple 신전 정보\n/rpg:rulebook 이 책 다시 받기",
  "§l§634. 직업 전용 기능§r\n\n/rpg:skillbook: 카멜레온 학습·분해·횟수 충전\n/rpg:learn <스킬ID>: 학습\n/rpg:swap: 카멜레온 무기 전환\n/rpg:wings: 날개 전환\n/rpg:wingcheck: 날개 상태\n/rpg:wingrefresh: 날개 재장착\n/rpg:fistcheck: 격투 상태\n\n해당 직업·기능을 보유해야 사용할 수 있습니다.",
  "§l§635. 안내를 다시 볼 때§r\n\nRPG v0.5.78 PvP·PK 서버용\n\n/rpg:rulebook으로 최신 종합 룰북을 다시 받으세요. 업데이트 전의 책은 옛 내용이 남아 있습니다.\n\n기술 사용이 막히면 직업 아이템·켜 둔 기술·MP·쿨타임을 먼저 확인하세요. 막힌 내용은 /rpg:ask로 질문할 수 있습니다.",
  "§l§636. 결투·PK 상세§r\n\n/rpg:pvp 신청·수락·항복\n서로 동의한 결투는 사망·아이템·XP 손실 없이 끝납니다. 던전 진행 중에는 결투 불가.\n\nPK 상태 플레이어를 죽이면 상대 지갑에서 최대 50,000골드를 받으며 추가 PK가 되지 않습니다. 잔액이 부족하면 있는 만큼만 지급합니다. PK는 플레이어에게 처치되면 해제되며 환경 사망·재접속으로 지워지지 않습니다."
];

export const RULEBOOK_PAGES=layoutRulebook(RULEBOOK_SECTIONS);

export function giveRulebook(player) {
  try {
    const book = new ItemStack("minecraft:writable_book", 1);
    const pages = book.getComponent("minecraft:book");
    if (!pages || typeof pages.setContents !== "function") {
      player.sendMessage("§c[RPG] 책 페이지 API가 없는 버전입니다. @minecraft/server 2.2.0 이상을 사용하세요.");
      return false;
    }
    pages.setContents(RULEBOOK_PAGES);
    if(typeof pages.signBook==="function")pages.signBook("RPG 서버 종합 룰북","RPG 서버");
    book.nameTag = "§6RPG 서버 종합 룰북";
    book.setLore(["§7서바이벌·성장·룬·던전 · " + RULEBOOK_PAGES.length + "쪽", "§7/rulebook 또는 /rpg:rulebook"]);
    const inventory = player.getComponent("minecraft:inventory")?.container;
    if (!inventory) {
      player.sendMessage("§c[RPG] 인벤토리를 찾지 못했습니다.");
      return false;
    }
    const leftover = inventory.addItem(book);
    if (leftover) {
      // 가방이 꽉 차도 책이 사라지지 않게 플레이어 발밑에 드롭합니다.
      const loc = player.location;
      player.dimension.spawnItem(leftover, { x: loc.x, y: loc.y + 0.5, z: loc.z });
      player.sendMessage("§e[RPG] 인벤토리가 가득 차서 명령어 책이 발밑에 떨어졌습니다.");
    } else {
      player.sendMessage("§a[RPG] 'RPG 서버 종합 룰북'을 받았습니다! (" + RULEBOOK_PAGES.length + "쪽)");
    }
    return true;
  } catch (error) {
    player.sendMessage("§c[RPG] 안내서 지급 실패: " + String(error));
    return false;
  }
}
```

## RPG_BP_v0597/scripts/core/stats.js

```javascript
import {wardDefenseValue,wardDamageReduction} from './wardDefense.js';
import {rpgXpMultiplier} from './xpBoost.js';
import {scriptKiller} from './combatContext.js';
import {recordTrialKillExtras} from './newTrials.js';
import {awardPartyTrialKill} from './combatContribution.js';
import {mobXp} from '../data/mobXp.js';
import {recordPvpDeath,pvpOwner} from './pvp.js';
import {classWeapon} from '../data/classWeapons.js';
import {upgradeLevel} from '../data/upgrades.js';
import {levelRewardMultiplier} from '../data/monsterLevels.js';
import { learningSpent,awardChameleonLevels } from './chameleonProgress.js';
// RPG 전용 레벨과 4종 능력치 (월드 재접속 시 플레이어 동적 속성으로 유지).
// 힘=물리 스킬, 체력=최대 HP, 지능=마나 소모 감소, 마력=마법 피해/직접 회복량.
import { world, system, EquipmentSlot } from '@minecraft/server';
import * as UI from '@minecraft/server-ui';
import { CONFIG } from '../config.js';
import { partyMembership } from './social.js';
import { personalKillXp, isXpRecipient } from './xpDistribution.js';
import { getEquipmentBonuses } from './equipment.js';
import { grantKillCurrencies } from './economy.js';

export const STAT_BASE = 5;
export const STAT_BUFF = 5.6; // 근력·체력·마력의 점당 효과 배율 (지능은 그대로)
export const LEVEL_MAX = 100; // 자연 성장 상한
export const ADMIN_LEVEL_MAX = 100000; // 관리자 명령어 전용
export const STAT_MAX = Object.freeze({ str:null, vit:null, int:50, mag:null });
const STAT_NAMES = Object.freeze({ str:'근력', vit:'체력', int:'지능', mag:'마력' });
const STATS_KEY='rpg:stat_values';
const LEVEL_KEY='rpg:rpg_level';
const XP_KEY='rpg:rpg_xp';
const DEFAULT = Object.freeze({str:5,vit:5,int:5,mag:5});
const REGEN_HEALTH_REFRESH=100;
const formOpen=new Set();

export function getLevel(p){
  try{const n=p.getDynamicProperty(LEVEL_KEY);return Number.isInteger(n)?Math.min(ADMIN_LEVEL_MAX,Math.max(1,n)):1;}catch{return 1;}
}
// 관리자 설정: RPG 레벨 직접 지정. 자연 경험치 획득은 100레벨에서 멈춘다.
export function forceSetLevel(p,number){
  // Require an actual decimal integer, never silently convert blanks to 0.
  const raw=String(number??'').trim();
  const n=/^[0-9]+$/.test(raw)?Number(raw):NaN;
  if(!Number.isSafeInteger(n)||n<1||n>ADMIN_LEVEL_MAX)
    return {ok:false,reason:`레벨은 1~${ADMIN_LEVEL_MAX.toLocaleString()} 정수만 설정할 수 있습니다.`};
  try{
    const old=getLevel(p);
    p.setDynamicProperty(LEVEL_KEY,n);
    p.setDynamicProperty(XP_KEY,0);
    // 낮은 레벨로 강제 조정할 때 초과 배분 스탯이 남지 않도록 정리.
    let resetStats=false;
    const allocated=Object.values(getStats(p)).reduce((sum,v)=>sum+v-STAT_BASE,0);
    if(allocated>Math.max(0,(n-1)*3-learningSpent(p))){
      p.setDynamicProperty(STATS_KEY,JSON.stringify(DEFAULT));
      applyVitality(p);
      resetStats=true;
    }
    const saved=getLevel(p);
    if(saved!==n) return {ok:false,reason:`레벨 저장 확인 실패 (현재 ${saved})`};
    return {ok:true,old,level:saved,resetStats};
  }catch(error){return {ok:false,reason:'레벨 저장 실패: '+String(error)};}
}
export function getXp(p){
  try{const n=p.getDynamicProperty(XP_KEY);return typeof n==='number'&&Number.isFinite(n)?Math.max(0,n):0;}catch{return 0;}
}
export function xpForNext(level){return Math.floor(80+20*(level-1)+2*(level-1)*(level-1));}
export function getStats(p){
  let raw={};
  try{const v=p.getDynamicProperty(STATS_KEY);if(typeof v==='string')raw=JSON.parse(v)??{};}catch{}
  const result={};
  for(const id of Object.keys(DEFAULT)){
    const n=Number(raw[id]);result[id]=Number.isSafeInteger(n)?Math.max(STAT_BASE,STAT_MAX[id]===null?n:Math.min(STAT_MAX[id],n)):STAT_BASE;
  }
  return result;
}
export function totalStatPoints(p){return (getLevel(p)-1)*3;}
export function resetAllocatedStats(p){
 const allocated=Object.values(getStats(p)).reduce((sum,n)=>sum+n-STAT_BASE,0);
 if(allocated<=0)return 0;
 p.setDynamicProperty(STATS_KEY,JSON.stringify(DEFAULT));applyVitality(p);return allocated;
}
export function unspentPoints(p){
  const s=getStats(p);
  return Math.max(0,totalStatPoints(p)-learningSpent(p)-Object.values(s).reduce((a,n)=>a+n-STAT_BASE,0));
}
export function allocateStat(p, id, count=1){
  if(!Object.prototype.hasOwnProperty.call(STAT_MAX,id))return {ok:false,reason:'없는 스탯'};
  const n=Number(count);if(!Number.isSafeInteger(n)||n<1)return {ok:false,reason:'잘못된 포인트 수'};
  const s=getStats(p), remain=unspentPoints(p);
  if(n>remain)return {ok:false,reason:'스탯 포인트 부족'};
  if(!Number.isSafeInteger(s[id]+n))return {ok:false,reason:'저장 가능한 정수 범위를 넘었습니다.'};
  if(STAT_MAX[id]!==null && s[id]+n>STAT_MAX[id])return {ok:false,reason:`${STAT_NAMES[id]} 최대 ${STAT_MAX[id]}`} ;
  s[id]+=n;
  try{p.setDynamicProperty(STATS_KEY,JSON.stringify(s));if(id==='vit')applyVitality(p);}
  catch{return {ok:false,reason:'저장 실패'};}
  return {ok:true,stat:s[id],left:remain-n};
}
// 초기 지능 5를 기준으로 45포인트 더 찍을 수 있음. 최대 마나 소모 감소 40%.
export function manaCostFor(p,base){
  const int=getStats(p).int;
  return Math.max(base>0?1:0,Math.ceil(Math.max(0,base)*(1-Math.min(0.4,(int-STAT_BASE)*0.4/(50-STAT_BASE)))-1e-9));
}
export function healingFor(p,base){
  const mag=getStats(p).mag;
  return Math.max(0,base)*(1+0.0035*STAT_BUFF*(mag-STAT_BASE));
}
// Bedrock Strength amplifiers are zero-based; each level adds 5% skill damage.
// Read the live effect so expiry, removal and a changed buff level take effect immediately.
export function strengthDamageMultiplier(p){
  try{
    const effect=p.getEffect('strength');
    return Number.isInteger(effect?.amplifier)&&effect.amplifier>=0
      ? 1+(effect.amplifier+1)*CONFIG.skillDamage.strengthPerLevel : 1;
  }catch{return 1;}
}
export function skillDamageFor(p,base,type,{strengthIncluded=false}={}){
  if(type==='fixed'||!p||p.typeId!=='minecraft:player')return base;
  const s=getStats(p);
  const magic=type==='magic';
  const stat=magic?s.mag:s.str;
  const gear=getEquipmentBonuses(p);
  const damage=Math.max(0,base);
  // Fist skills already include Strength before their strong-punch multiplier.
  const strength=!strengthIncluded?strengthDamageMultiplier(p):1;
  const held=p.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand);
  const weaponBonus=classWeapon(held?.typeId)?1+upgradeLevel(held,'weapon')*.02:1;
  return damage*strength*(1+0.007*STAT_BUFF*(stat-STAT_BASE))*(magic?gear.magic:gear.physical)*weaponBonus;
}
const MAGICAL_LINES=new Set(['mage','holy','necro','fire','frost','tech','demon','blood','hacker','celestial_sun']);
export function defaultDamageTypeFor(p){
  try{
    const j=p.getDynamicProperty('rpg:job');
    const magicalJobs=new Set(['mage','sage','cleric','angel','michael','fallen_angel','necromancer','deathlord','fire_controller','frost_controller','technomancer','demon','blood_mage','blood','hacker','sun_heir']);
    return magicalJobs.has(j)?'magic':'physical';
  }catch{return 'physical';}
}
// 체력 보정: health_boost 1단계마다 HP+4이므로 10 VIT 단위로 부여.
// 디테일 스탯 값은 0.4HP 단위로 저장하되 게임 이펙트는 4HP 단위로 근사.
export function applyVitality(p){
  try{
    const bonusHP=(getStats(p).vit-STAT_BASE)*0.4*STAT_BUFF+getEquipmentBonuses(p).health;
    // No gameplay VIT cap; the native effect API permits amplifiers 0..255.
    const steps=Math.min(256,Math.round(bonusHP/4));
    if(steps>0)p.addEffect('health_boost',REGEN_HEALTH_REFRESH+80,{amplifier:steps-1,showParticles:false});
    else if(p.getEffect('health_boost'))p.removeEffect('health_boost');
  }catch{}
}
export function gainRpgXp(p,amount){
  if(p?.typeId!=='minecraft:player'||!Number.isFinite(amount)||amount<=0)return;
  let level=getLevel(p),xp=getXp(p)+amount*rpgXpMultiplier(p),levels=0;
  while(level<LEVEL_MAX && xp>=xpForNext(level)){
    xp-=xpForNext(level);level++;levels++;
  }
  if(level>=LEVEL_MAX)xp=0;
  try{
    p.setDynamicProperty(LEVEL_KEY,level);
    p.setDynamicProperty(XP_KEY,xp);
    if(levels){
      try{awardChameleonLevels(p,levels);}catch(error){console.warn('[RPG skillbook] '+String(error));}
      p.sendMessage(`§a[RPG] 레벨 ${level}! §e스탯 포인트 +${levels*3} §7(/rpg:stats)`);
      try{p.dimension.playSound('random.levelup',p.location,{volume:.55,pitch:1.1});}catch{}
    }
  }catch{}
}
function killReward(entity){return Math.round(mobXp(entity?.typeId)*levelRewardMultiplier(entity));}

export function levelDefenseValue(p){
  const lv=getLevel(p);
  return Math.max(0, Math.min(ADMIN_LEVEL_MAX, lv))+wardDefenseValue(p);
}
export function levelDefenseReduction(p){
  const lv=getLevel(p);
  return Math.max(0, Math.min(0.45, lv*0.0035)); // 레벨당 0.35%, 최대 45%
}
function pretty(p){
  const s=getStats(p),lv=getLevel(p);
  const exp=lv>LEVEL_MAX?'관리자 설정':lv>=LEVEL_MAX?'MAX':`${getXp(p)}/${xpForNext(lv)}`;
  const defPct=(levelDefenseReduction(p)*100).toFixed(1);
  return `§eLv.${lv} §7RPG XP ${exp}
§a남은 SP: ${unspentPoints(p)}
§7방어력 ${levelDefenseValue(p)} §8(레벨 피해감소 ${defPct}% / 룬 방어력 +${wardDefenseValue(p)}·추가 감소 ${(wardDamageReduction(p)*100).toFixed(2)}%)
§c근력 ${s.str}§r  §6체력 ${s.vit}§r  §b지능 ${s.int}/50§r  §d마력 ${s.mag}`;
}
export function statsSummary(p){return pretty(p);}
async function show(p,form){
  const busy=UI.FormCancelationReason?.UserBusy??'UserBusy';
  for(let i=0;i<12;i++){
    const r=await form.show(p);
    if(!r.canceled||r.cancelationReason!==busy)return r;
    await new Promise(resolve=>system.runTimeout(resolve,10));
  }
  return undefined;
}
// 스탯 선택 즉시 직접 수량 입력: +1/+5/+10/최대 배분 선택창 없음.
// 근력·체력·마력에는 게임 규칙 상한이 없고, 지능만 50을 유지한다.
const STAT_ORDER=['str','vit','int','mag'];
export async function openStatsMenu(p){
  if(formOpen.has(p.id))return;
  formOpen.add(p.id);
  try{
    for(let j=0;j<120;j++){
      if(!p.isValid)break;
      const s=getStats(p);
      const f=new UI.ActionFormData().title('RPG 레벨 · 스탯').body(pretty(p)+
        '\n§7레벨 기반 방어력: 레벨당 피해 감소 0.35% (최대 45%)\n§7근력: 물리 피해 3.92%/점 (5.6배)\n§7체력: 최대 HP 2.24/점 (5.6배)\n§7지능: 추가 1점당 마나 절약 약 0.889%p (지능 50에서 최대 40%)\n§7마력: 마법 피해 3.92%, 회복량 1.96%/점 (5.6배)');
      for(const id of STAT_ORDER)f.button(`${STAT_NAMES[id]} 직접 입력  §7(${s[id]}/${STAT_MAX[id]===null?'상한 없음':STAT_MAX[id]})`);
      f.button('닫기');
      const response=await show(p,f);
      if(!response||response.canceled||response.selection>=STAT_ORDER.length)break;
      const id=STAT_ORDER[response.selection];
      const remaining=unspentPoints(p);
      const available=Math.max(0,Math.min(remaining,STAT_MAX[id]===null?Infinity:STAT_MAX[id]-getStats(p)[id]));
      if(available<=0){
        p.sendMessage('§e[RPG] 배분할 수 있는 포인트가 없거나 이 스탯이 최대치입니다.');
        continue;
      }
      const form=new UI.ModalFormData().title(`${STAT_NAMES[id]} 스탯 직접 입력`)
        .textField(`배분할 포인트 (1~${available})`,'숫자 입력',{defaultValue:'1'})
        .submitButton('포인트 배분');
      const reply=await show(p,form);
      if(!reply||reply.canceled)continue;
      const raw=String(reply.formValues?.[0]??'').trim();
      const count=/^[0-9]+$/.test(raw)?Number(raw):NaN;
      if(!Number.isSafeInteger(count)||count<1){
        p.sendMessage('§c[RPG] 1 이상의 정수를 입력하세요.');
        continue;
      }
      const result=allocateStat(p,id,count);
      if(!result.ok)p.sendMessage('§c[RPG] '+result.reason);
      else p.sendMessage(`§a[RPG] ${STAT_NAMES[id]} +${count} → ${result.stat}, 남은 포인트 ${result.left}`);
    }
  }catch(e){try{p.sendMessage('§c스탯 메뉴 오류: '+String(e));}catch{}}
  finally{formOpen.delete(p.id);}
}

export function distributeKillXp(killer, amount) {
  const origin = killer.location;
  const dimensionId = killer.dimension.id;
  const party = partyMembership(killer);
  const members = party.members
    .map(player => ({player, id: player.id, level: getLevel(player)}))
    .filter(m => isXpRecipient(m.player, origin, dimensionId, m.level, LEVEL_MAX, CONFIG.partyXp.radius))
    .sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  const shares = members.map(m => ({id:m.id, amount:personalKillXp(amount, party.inParty, CONFIG.partyXp.multiplier)}));
  for (const share of shares) {
    if (share.amount > 0) gainRpgXp(members.find(m => m.id === share.id).player, share.amount);
  }
  return shares;
}

export function registerRpgStats(onPlayerKill){
  world.afterEvents.entityDie.subscribe(ev=>{
    try{
      let killer=ev.damageSource?.damagingEntity;
      killer=pvpOwner(killer);
      if(killer?.typeId!=='minecraft:player')killer=ev.damageSource?.damagingProjectile?.getComponent('minecraft:projectile')?.owner;
      if(killer?.typeId!=='minecraft:player')killer=scriptKiller(ev.deadEntity);
      if(ev.deadEntity?.typeId==='minecraft:player'){if(killer?.typeId==='minecraft:player')try{recordTrialKillExtras(killer,ev.deadEntity);}catch{}recordPvpDeath(killer,ev.deadEntity);return;}
      if(killer?.typeId!=='minecraft:player')return;
      try{recordTrialKillExtras(killer,ev.deadEntity);}catch(error){console.warn('[RPG new trials] '+String(error));}
      const reward=killReward(ev.deadEntity);
      if(reward>0)distributeKillXp(killer,reward);
      try {grantKillCurrencies(killer,ev.deadEntity);} catch(error) {console.warn('[RPG economy] '+String(error));}
      try{awardPartyTrialKill(killer,ev.deadEntity);}catch(error){console.warn('[RPG job trials] '+String(error));}
      // Intro objectives credit the killer only, independently of shared XP.
      if (typeof onPlayerKill === 'function') onPlayerKill(killer, ev.deadEntity);
    }catch{}
  });
  try{
    world.beforeEvents.entityHurt?.subscribe(ev=>{
      try{
        const victim=ev.hurtEntity;
        if(victim?.typeId!=='minecraft:player')return;
        ev.damage = Math.max(0, ev.damage * (1 - levelDefenseReduction(victim)));
      }catch{}
    });
  }catch{}
  system.runInterval(()=>{
    for(const p of world.getAllPlayers()){
      applyVitality(p);
    }
  },REGEN_HEALTH_REFRESH);
}
```

## RPG_BP_v0597/scripts/core/tpa.js

```javascript
import {world,system} from '@minecraft/server';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {showForm} from './skillMenu.js';
import {getWallet,setWallet} from './wallet.js';
import {duelOf} from './pvp.js';
import {dungeonRuns,dungeonLobbies} from './dungeonState.js';
import {isTimeFrozen} from './timeStopDamage.js';
export const TPA_PRICE=1000;const requests=new Map(),menus=new Set();let registered=false;
const online=id=>world.getAllPlayers().find(p=>p.id===id);
function unavailable(p){return !p?.isValid||(p.getComponent('minecraft:health')?.currentValue??0)<=0||duelOf(p)||isTimeFrozen(p)||[...dungeonRuns.values(),...dungeonLobbies.values()].some(r=>r.members.some(m=>m.id===p.id))||p.getDynamicProperty('rpg:pvp_arena_return_v1')!==undefined||p.getDynamicProperty('rpg:dungeon_return_v1')!==undefined;}
export function requestTpa(p,target){
 if(p.id===target.id||unavailable(p)||unavailable(target))throw Error('던전·결투·시간 정지·사망 중에는 이동 요청을 할 수 없습니다.');
 if(getWallet(p).gold<TPA_PRICE)throw Error('이동 시 사용할 1,000골드가 필요합니다.');
 requests.set(p.id,{from:p.id,to:target.id,until:Date.now()+30000});p.sendMessage('§b'+target.name+'님에게 이동을 요청했습니다. 수락·이동 성공 시 1,000골드를 사용합니다.');target.sendMessage('§e'+p.name+'님의 이동 요청입니다. 상태창의 받은 이동 요청 또는 /rpg:tpaaccept에서 30초 안에 수락하세요.');
}
export function tpaDestination(target){return {...target.location};}
export function acceptTpa(target,fromId){
 const request=requests.get(fromId),p=online(fromId);
 if(!request||request.to!==target.id||request.until<Date.now())throw Error('유효한 이동 요청이 없습니다.');
 if(unavailable(p)||unavailable(target))throw Error('참가자의 던전·결투·시간 정지·생존 상태를 확인하세요.');
 const before=getWallet(p);if(before.gold<TPA_PRICE)throw Error('요청자의 골드가 부족합니다.');
 const at=tpaDestination(target),origin={dimension:p.dimension,location:{...p.location},rotation:p.getRotation()};requests.delete(fromId);let moved=false;
 try{p.teleport(at,{dimension:target.dimension,keepVelocity:false});moved=true;setWallet(p,{...before,gold:before.gold-TPA_PRICE});}
 catch(error){try{setWallet(p,before);}catch{}if(moved)try{p.teleport(origin.location,{dimension:origin.dimension,rotation:origin.rotation,keepVelocity:false});}catch(rollback){console.error('[RPG TPA return] '+rollback);}throw error;}
 p.sendMessage('§a이동 완료 · 1,000골드를 사용했습니다.');target.sendMessage('§a'+p.name+'님이 이동했습니다.');return true;
}
export async function openTpa(p){
 if(menus.has(p.id))return;menus.add(p.id);
 try{const targets=world.getAllPlayers().filter(t=>t.id!==p.id);const f=new ActionFormData().title('플레이어 이동 요청 · TPA').body('상대가 수락하면 상대의 현재 위치로 이동합니다. 안전한 착지 공간 검사는 하지 않습니다.\n이동 성공 시 요청자의 RPG 골드 1,000을 사용합니다.\n요청·거절·만료에는 비용이 들지 않습니다.');for(const t of targets)f.button(t.name);f.button('닫기');const r=await showForm(f,p);if(r&&!r.canceled&&Number.isInteger(r.selection)&&r.selection>=0&&r.selection<targets.length)requestTpa(p,targets[r.selection]);}
 catch(error){p.sendMessage('§e[TPA] '+String(error.message??error));}finally{menus.delete(p.id);}
}
export async function openTpaInbox(p){
 if(menus.has(p.id))return;menus.add(p.id);
 try{const pending=[...requests.values()].filter(r=>r.to===p.id&&r.until>Date.now()&&online(r.from));const f=new ActionFormData().title('받은 이동 요청').body(pending.length?'요청자를 선택해 수락하거나 거절하세요.':'받은 이동 요청이 없습니다.');for(const r of pending)f.button(online(r.from).name);f.button('닫기');const pick=await showForm(f,p);if(!pick||pick.canceled||!Number.isInteger(pick.selection)||pick.selection<0||pick.selection>=pending.length)return;const req=pending[pick.selection];const reply=await showForm(new MessageFormData().title('이동 요청 수락').body(online(req.from).name+'님을 내 주변으로 이동시킬까요? 상대방이 1,000골드를 사용합니다.').button1('거절').button2('수락'),p);if(reply&&!reply.canceled){if(reply.selection===1)acceptTpa(p,req.from);else requests.delete(req.from);}}
 catch(error){p.sendMessage('§e[TPA] '+String(error.message??error));}finally{menus.delete(p.id);}
}
export function registerTpa(){if(registered)return;registered=true;world.afterEvents.playerLeave.subscribe(e=>{menus.delete(e.playerId);requests.delete(e.playerId);for(const [id,r]of requests)if(r.to===e.playerId)requests.delete(id);});system.runInterval(()=>{for(const [id,r]of requests)if(r.until<Date.now())requests.delete(id);},100);}
```

## RPG_BP_v0597/scripts/core/upgrades.js

```javascript
import {itemGrade} from '../data/grades.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {classWeapon} from '../data/classWeapons.js';
import {gearFingerprint,setGearLevel} from './gearState.js';
import {openFusionMenu} from './fusion.js';
import {runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {decorateRarity} from './rarityLabels.js';
import {openArmorTransfer} from './armorTransfer.js';
import { EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { armorInfo, RUNES, RUNE_KEY } from '../data/equipment.js';
import { ARMOR_LEVEL_KEY, RUNE_LEVEL_KEY, upgradeLevel, upgradeCost, upgradedRune, enhancementRates, rollEnhancement, catalystAllowed, CATALYST_ID, MAX_CATALYSTS } from '../data/upgrades.js';
import { getWallet, setWallet, canAfford, walletText } from './wallet.js';
import { showForm } from './skillMenu.js';
import { readRuneBag, writeRuneBag, migrateChestRune } from './runeInventory.js';

const SLOTS = () => [
  {slot:EquipmentSlot.Head, part:'helmet', name:'투구'},
  {slot:EquipmentSlot.Chest, part:'chestplate', name:'흉갑'},
  {slot:EquipmentSlot.Legs, part:'leggings', name:'각반'},
  {slot:EquipmentSlot.Feet, part:'boots', name:'장화'},
];
export function describeRune(id, rank, grade=0) {
  const r = upgradedRune(RUNES[id],rank,grade);
  if (!r) return '없음';
  const values = [];
  if (r.physical && r.physical>1) values.push(`물리 스킬 +${Number(((r.physical-1)*100).toFixed(1))}%`);
  if (r.magic && r.magic>1) values.push(`마법 스킬 +${Number(((r.magic-1)*100).toFixed(1))}%`);
  if(rank>0&&['power','arcane'].includes(id))values.push('공용·직업 무기 근접 평타 +'+Number((((r.physical??r.magic)-1)*100).toFixed(1))+'%');
  if (r.defense) values.push('RPG 방어력 +'+Number(r.defense.toFixed(1))+' (피해 감소 '+Number((r.defense*.35).toFixed(2))+'%)');
  if (r.health) values.push(`최대 HP +${r.health}`);
  if (r.manaRegenPercent) values.push(`초당 최대 마나의 +${Number((r.manaRegenPercent*100).toFixed(1))}% 회복`);
  if (r.lifesteal) values.push('준 피해의 '+Number((r.lifesteal*100).toFixed(1))+'% 흡혈');
  if (r.ward) values.push('저항 '+(r.wardAmplifier+1));
  if (r.speed) values.push('신속 '+(r.speedAmplifier+1));
  return rarityBadge(runeRarity(grade))+' · '+values.join(', ');
}

function fingerprint(item) {return gearFingerprint(item);}
export function enhancementQuote(player,kind,slot) {
  if(kind==='rune') {
    const rune=readRuneBag(player).runes.find(r=>r.uid===slot);if(!rune)return undefined;
    return {kind,slot,level:rune.level,runeId:rune.id,fingerprint:JSON.stringify(rune),cost:upgradeCost(kind,rune.level),name:RUNES[rune.id].name,
      effect:describeRune(rune.id,rune.level,rune.grade)+'\n→ '+describeRune(rune.id,rune.level+1,rune.grade)};
  }
  if(kind==='weapon'){
    if(slot!==EquipmentSlot.Mainhand)return undefined;
    const item=player.getComponent('minecraft:equippable')?.getEquipment(slot),jobWeapon=classWeapon(item?.typeId),w=COMMON_WEAPONS.find(w=>w.id===item?.typeId)??jobWeapon;
    if(!w||item.amount!==1)return undefined;const level=upgradeLevel(item,kind);
    return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:w.name,effect:jobWeapon?`직업 무기 · 등급·승급 없음\n근접 피해 +${level} → +${level+1}\n물리·마법 스킬 피해 +${level*2}% → +${(level+1)*2}%`:`${rarityBadge(itemGrade(item))} 등급 유지 · 강화 근접 피해 +${level} → +${level+1}`};
  }
  if(kind!=='armor')return undefined;
  const definition=SLOTS().find(s=>s.slot===slot),item=player.getComponent('minecraft:equippable')?.getEquipment(slot);
  const info=armorInfo(item?.typeId);if(!definition||info?.part!==definition.part)return undefined;
  const level=upgradeLevel(item,'armor');return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:info.name+' '+definition.name,effect:`${rarityBadge(itemGrade(item))} 등급 유지\n부위 강화 HP +${level} → +${level+1}`};
}

export function enhanceEquipped(player,kind,slot,expectedFingerprint,options={}) {
  try {
    const quote=enhancementQuote(player,kind,slot);
    if (!quote) return {ok:false,reason:'강화할 RPG 갑옷·공용·직업 무기·보관 룬이 없습니다.'};
    if (!quote.cost) return {ok:false,reason:'이미 최대 강화 단계입니다.'};
    if (expectedFingerprint!==undefined&&quote.fingerprint!==expectedFingerprint) return {ok:false,reason:'장비 또는 강화 단계가 변경됐습니다. 다시 선택하세요.'};
    const catalystCount=options.catalystCount??0;
    const rates=enhancementRates(kind,quote.level,catalystCount);
    if (!rates) return {ok:false,reason:'촉매 수량은 0~5개이며, 갑옷·무기 +5·룬 +2부터 사용할 수 있습니다.'};
    const wallet=getWallet(player);
    if (!canAfford(wallet,quote.cost)) return {ok:false,reason:'강화에 필요한 재화가 부족합니다.'};
    const eq=player.getComponent('minecraft:equippable');
    const inventory=player.getComponent('minecraft:inventory')?.container;
    const catalysts=[];
    let needed=catalystCount;
    if(needed>0&&inventory)for(let i=0;i<inventory.size&&needed>0;i++) {
      const token=inventory.getItem(i);
      if(token?.typeId!==CATALYST_ID||token.amount<1)continue;
      const take=Math.min(needed,token.amount);
      catalysts.push({slot:i,original:token.clone(),take});needed-=take;
    }
    if(needed>0)return {ok:false,reason:`강화 촉매 ${catalystCount}개가 필요합니다.`};
    const original=kind!=='rune'?eq.getEquipment(slot).clone():readRuneBag(player);
    const outcome=rollEnhancement(rates,options.random??Math.random);
    let level=quote.level,target;
    if(outcome==='success')level++;
    if(outcome==='downgrade')level=Math.max(0,level-1);
    if(kind!=='rune') {
      target=original.clone();
      if(outcome==='destroy'){target=undefined;level=0;}
      else target=setGearLevel(target,kind,level);
    }else{
      target=JSON.parse(JSON.stringify(original));
      if(outcome==='destroy'){level=0;target.runes=target.runes.filter(r=>r.uid!==slot);target.equipped=target.equipped.map(uid=>uid===slot?null:uid);}
      else target.runes.find(r=>r.uid===slot).level=level;
    }
    const next=Object.fromEntries(Object.entries(wallet).map(([k,v])=>[k,v-quote.cost[k]]));
    let debited=false,catalystTouched=false;
    try {
      setWallet(player,next);debited=true;
      if(catalysts.length) {
        catalystTouched=true;
        for(const entry of catalysts) {
          if(entry.original.amount===entry.take)inventory.setItem(entry.slot,undefined);
          else {const remaining=entry.original.clone();remaining.amount-=entry.take;inventory.setItem(entry.slot,remaining);}
        }
      }
      if(kind!=='rune'){if(!eq.setEquipment(slot,target))throw Error('장비 저장 실패');}else writeRuneBag(player,target);
    } catch(error) {
      let recovered=true;
      try {if(kind!=='rune'){if(!eq.setEquipment(slot,original))recovered=false;}else writeRuneBag(player,original);}catch{recovered=false;}
      if(catalystTouched)for(const entry of catalysts)try{inventory.setItem(entry.slot,entry.original);}catch{recovered=false;}
      if(debited)try{setWallet(player,wallet);}catch{recovered=false;}
      if(!recovered)console.error('[RPG upgrade] rollback incomplete: '+String(error));
      return {ok:false,reason:recovered?'강화를 저장하지 못해 취소하고 재화를 복구했습니다.':'강화 복구에 실패했습니다. 관리자에게 콘텐츠 로그 확인을 요청하세요.'};
    }
    return {ok:true,outcome,level,cost:quote.cost,rates,catalystCount};
  }catch(error){return {ok:false,reason:'강화 오류: '+String(error)};}
}

const menus = new Set();
export async function openUpgradeMenu(player) {
  if (menus.has(player.id)) return;
  menus.add(player.id);
  try {
    const migration=migrateChestRune(player);if(!migration.ok)player.sendMessage('§e'+migration.reason);
    for (let count=0;count<40&&player.isValid;count++) {
      const options = SLOTS().map(s=>enhancementQuote(player,'armor',s.slot)).filter(Boolean);
      const weapon=enhancementQuote(player,'weapon',EquipmentSlot.Mainhand);if(weapon)options.push(weapon);
      for(const rune of readRuneBag(player).runes)options.push(enhancementQuote(player,'rune',rune.uid));
      const form = new ActionFormData().title('RPG 장비 강화 · 합성').body(walletText(getWallet(player))+
        '\n\n단계가 높아질수록 실패·강등·파괴 위험 증가\n갑옷 최대 +10: 부위당 단계별 최대 HP +1\n룬·공용 무기도 최대 +10. 무기: 강화당 근접 피해 +1'+
        '\nHP는 게임 효과 특성상 총합을 4 HP 단위로 근사합니다.\n착용 중인 장비를 선택하세요. 룬은 전용 보관함에 넣은 뒤 강화합니다.\n촉매: 갑옷·무기 +5 / 룬 +2부터 최대 5개. 1개당 성공률 +9%p, 파괴확률 -3%p.');
      for (const q of options) form.button(`${q.kind==='armor'?'갑옷':q.kind==='weapon'?'무기':'룬'}: ${q.name} +${q.level}\n`+(q.cost?`다음 단계: 골드 ${q.cost.gold} / ${q.cost.stone?'강화석 '+q.cost.stone:'룬 가루 '+q.cost.dust}`:'최대 단계'));
      form.button('갑옷 강화 이전');form.button('장비 등급 합성');form.button('닫기');
      const result = await showForm(form,player);
      if (!result || result.canceled || result.selection==null || result.selection>options.length+1) return;
      if(result.selection===options.length){await openArmorTransfer(player);continue;}
      if(result.selection===options.length+1){await openFusionMenu(player);continue;}
      const quote = options[result.selection];
      if (!quote.cost) {player.sendMessage('§e[RPG] 이미 최대 강화 단계입니다.');continue;}
      let catalystCount=0;
      if(catalystAllowed(quote.kind,quote.level)) {
        const inventory=player.getComponent('minecraft:inventory')?.container;
        let owned=0;
        if(inventory)for(let i=0;i<inventory.size;i++){const token=inventory.getItem(i);if(token?.typeId===CATALYST_ID)owned+=token.amount;}
        const maximum=Math.min(MAX_CATALYSTS,owned);
        const form=new ActionFormData().title('강화 촉매 수량')
          .body(`보유 촉매 ${owned}개. 한 번에 최대 5개 사용.\n1개당 성공률 +9%p, 파괴확률 -3%p (최소 0%).\n완료된 모든 결과에서 선택 수량을 소비합니다.`);
        for(let count=0;count<=maximum;count++) {
          const preview=enhancementRates(quote.kind,quote.level,count);
          form.button(`${count===0?'촉매 사용 안 함':count+'개 사용'}\n성공 ${preview.success}% / 파괴 ${preview.destroy}%`);
        }
        form.button('취소');
        const choice=await showForm(form,player);
        if(!choice||choice.canceled||choice.selection==null||choice.selection>maximum)continue;
        catalystCount=choice.selection;
      }
      const rates=enhancementRates(quote.kind,quote.level,catalystCount);
      const percentages=`성공 ${rates.success}% / 유지 실패 ${rates.fail}%\n1단계 강등 ${rates.downgrade}% / 파괴 ${rates.destroy}%`;
      const destruction=quote.kind!=='rune'?'장비 파괴 시 해당 장비만 소멸하고 전용 보관함 룬은 유지됩니다.':'룬 파괴 시 해당 보관 룬만 소멸하며 장착도 해제됩니다.';
      const confirm=await showForm(new MessageFormData().title('위험 강화 확인')
        .body(`${quote.name} +${quote.level} → +${quote.level+1}\n${quote.effect}\n\n${percentages}\n${destruction}\n\n비용: 골드 ${quote.cost.gold}, 강화석 ${quote.cost.stone}, 룬 가루 ${quote.cost.dust}\n${catalystCount?'강화 촉매 '+catalystCount+'개 사용\n':''}모든 결과에서 비용이 소비됩니다.`)
        .button1('취소').button2('강화'),player);
      if(!confirm||confirm.canceled||confirm.selection!==1)continue;
      const attempt=enhanceEquipped(player,quote.kind,quote.slot,quote.fingerprint,{catalystCount});
      if(!attempt.ok)player.sendMessage('§c[RPG] '+attempt.reason);
      else {
        const messages={success:`§a강화 성공! +${attempt.level}`,fail:'§e강화 실패: 단계 유지',downgrade:`§6강등: +${attempt.level}`,destroy:quote.kind!=='rune'?'§c장비 파괴: 해당 장비 소멸':'§c룬 파괴: 해당 보관 룬 소멸'};
        player.sendMessage('[RPG] '+quote.name+' · '+messages[attempt.outcome]);
      }
    }
  } catch(error) {try {player.sendMessage('§c[RPG] 강화 메뉴 오류: '+String(error));} catch {}}
  finally {menus.delete(player.id);}
}
```

## RPG_BP_v0597/scripts/core/wardDefense.js

```javascript
import {world,system} from '@minecraft/server';
import {equippedRunes} from './runeInventory.js';
import {RUNES} from '../data/equipment.js';
import {upgradedRune} from '../data/upgrades.js';
const APPLIED='rpg:ward_defense_applied_v1';let registered=false;
export const WARD_REDUCTION_PER_POINT=.0035;
export function wardDefenseValue(p){let value=0;for(const r of equippedRunes(p))if(r.id==='ward')value+=upgradedRune(RUNES.ward,r.level,r.grade).defense??0;return Number(value.toFixed(1));}
export function wardDamageReduction(p){return Math.min(.8,wardDefenseValue(p)*WARD_REDUCTION_PER_POINT);}
export function applyWardDefense(p,force=false){const value=wardDefenseValue(p),index=Math.round(value*10);if(!force&&p.getDynamicProperty(APPLIED)===index)return value;p.triggerEvent('rpg:ward_defense_'+index);p.setDynamicProperty(APPLIED,index);return value;}
export function registerWardDefense(){if(registered)return;registered=true;system.run(()=>{for(const p of world.getAllPlayers())try{applyWardDefense(p,true);}catch(error){console.warn('[RPG ward] '+error);}});world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{try{applyWardDefense(ev.player,true);}catch(error){console.warn('[RPG ward] '+error);}},2));system.runInterval(()=>{for(const p of world.getAllPlayers())try{applyWardDefense(p);}catch(error){console.warn('[RPG ward] '+error);}},20);}
```

## RPG_BP_v0597/scripts/data/equipment.js

```javascript
import {COMMON_WEAPONS} from './commonWeapons.js';
export const ARMOR_SETS = {
  abyssal:{name:'심연 수호자',protection:[3,8,6,3],durability:[550,800,750,650],health:16,physical:1.08,magic:1.08,ward:true,description:'4세트: 최대 HP +16, 물리·마법 스킬 +8%, 저항 I 유지. 기본 방어 합계 20·내구도 네더라이트 이상'},
  adventurer: {name:'모험가', protection:[2,5,4,2], durability:[220,320,300,220], physical:1.08, description:'4세트: 물리 스킬 피해 +8%'},
  warden: {name:'숲 수호자', protection:[3,6,5,2], durability:[300,450,420,300], health:8, description:'4세트: 최대 HP +8'},
  astral: {name:'별빛 술사', protection:[2,5,4,2], durability:[260,400,375,260], magic:1.08, manaRegen:3, description:'4세트: 마법 스킬 피해 +8%, 초당 마나 +3'},
};
export const ARMOR_PARTS = ['helmet','chestplate','leggings','boots'];
export const PART_NAMES = ['투구','흉갑','각반','장화'];
export const RUNES = {
  power:{name:'힘의 룬', description:'물리 스킬 피해 +17%, 강화마다 +3.4%p. +1부터 공용·직업 무기 근접 평타에도 추가 피해', physical:1.17},
  ward:{name:'수호의 룬', description:'RPG 방어력 +4, 강화마다 +2 (일반 +10: +24). 방어력 1당 피해 감소 0.35%p. 저항 효과는 부여하지 않음', defense:4},
  mana:{name:'샘의 룬', description:'초당 최대 마나의 1% 추가 회복', manaRegenPercent:0.01},
  arcane:{name:'비전의 룬', description:'마법 스킬 피해 +17%, 강화마다 +3.4%p. +1부터 공용·직업 무기 근접 평타에도 추가 피해', magic:1.17},
  vitality:{name:'생명의 룬', description:'최대 HP +4, 강화마다 +2 (일반 +10: +24)', health:4},
  absorption:{name:'흡수의 룬',description:'적에게 준 피해의 5%를 HP로 회복, 최대 강화 12%',lifesteal:.05},
};
export const RUNE_KEY = 'rpg:chest_rune';
export const ALL_EQUIPMENT_IDS = [
  'rpg:armor_transfer_seal',...COMMON_WEAPONS.map(w=>w.id), 'rpg:enhancement_catalyst', 'rpg:random_skillbook', 'rpg:stat_reset_scroll', 'rpg:job_waiver',
  ...Object.keys(ARMOR_SETS).flatMap(set=>ARMOR_PARTS.map(part=>`rpg:${set}_${part}`)),
  ...Object.keys(RUNES).map(rune=>`rpg:rune_${rune}`),
];
export function armorInfo(typeId) {
  for (const [set, data] of Object.entries(ARMOR_SETS)) {
    for (let i=0;i<ARMOR_PARTS.length;i++) if (typeId === `rpg:${set}_${ARMOR_PARTS[i]}`) return {set, part:ARMOR_PARTS[i], ...data};
  }
  return undefined;
}
```

## RPG_BP_v0597/scripts/data/jobs.js

```javascript
// v0.5.78 실제 전직 시련은 data/jobTrials.js를 사용합니다. req는 이전 저장값과 일부 명중 안내용 메타데이터입니다.
// 직업 트리. 새 직업/4차 전직은 여기에 항목만 추가하면 됩니다.
//   tier     : 전직 차수 (1=견습, 2, 3 ...)
//   line     : 계열. 2차 전직 시 이 계열 밖의 스킬은 사라집니다.
//   parent   : 이 직업으로 전직하기 직전의 직업
//   weapon   : 전직 시 1번 칸에 고정되는 무기 아이템 (없으면 null)
//   skills   : 이 직업이 쓰는 스킬 id 목록 (웅크리기로 순서대로 전환)
//   basic    : 휘두르기로 푸른 에너지를 쏘는지
//   corrupt  : 타락 직업 여부
//   highMana : 마법사/성직자 계열 (마나 상한 2000, 책 1권당 +20)
//   theme    : 이펙트 색 (blue / red)
//   req      : 전직 조건 { key(진행도 이름), need(필요 수), label(설명) }
//   placeholder : true 면 아직 구현 전인 직업 (전직 불가)

// 견습이 계열별로 받는 시작 아이템. 든 아이템에 따라 쓸 수 있는 스킬 목록이 달라집니다.
export const STARTER_ITEMS = {
  "rpg:apprentice_sword": "sword",
  "rpg:apprentice_book": "mage",
  "rpg:apprentice_cross": "holy",
  "rpg:apprentice_fist": "fist",
  "rpg:apprentice_bow": "archer",
};
export const STARTER_BY_LINE = {
  sword: "rpg:apprentice_sword",
  mage: "rpg:apprentice_book",
  holy: "rpg:apprentice_cross",
  fist: "rpg:apprentice_fist",
  archer: "rpg:apprentice_bow",
};
// 견습이 시작 아이템과 함께 배우는 스킬
export const APPRENTICE_SKILLS = {
  sword: [],
  mage: ["mage_fireball", "mage_lightning"],
  holy: ["holy_heal"],
  fist: [],
  archer: ["archer_airwalk", "archer_rapid"],
};

const SWORD_SAINT_SKILLS = ["sword_spin", "sword_wave", "sword_flame_spin", "sword_kenho_rando", "sword_moon_dragon", "sword_annihilation", "sword_rush"];
// 타락검성은 섬멸을 사용할 수 없고 광분화를 배웁니다.
const FALLEN_SWORD_SKILLS = ["sword_spin", "sword_wave", "sword_flame_spin", "sword_kenho_rando", "sword_moon_dragon", "sword_rush", "fallen_sword_frenzy"];

const MAGE_2 = ["mage_flame_on", "mage_thunder", "mage_ice_fire", "mage_gravity", "mage_bombaye"];
const SAGE_3 = [
  "sage_meteor", "sage_raiyoung", "sage_zero", "sage_blackhole", "sage_sphere", "sage_zoltraak",
];

// 성직자 계열
const CLERIC_SKILLS = ["holy_heal", "holy_shield", "holy_sword", "holy_orb", "holy_pray"];
const ANGEL_SKILLS = [...CLERIC_SKILLS, "angel_bless", "angel_zone"];
const FALLEN_SKILLS = [
  "fallen_sacrifice", "fallen_sword", "fallen_shield", "fallen_curse",
  "fallen_orb", "fallen_zone", "fallen_end",
];

// 무투가 계열 (견습 → 무투가 → 권골)
const FIGHTER_SKILLS = ["fist_strong", "fist_flurry", "fist_smash"];
const FIST_BONE_SKILLS = [
  ...FIGHTER_SKILLS, "fist_wind", "fist_face", "fist_stance", "fist_finale",
];

function stub(id, name, tier, line, parent, extra = {}) {
  return {
    id, name, tier, line, parent,
    weapon: null, skills: [], basic: false, corrupt: false, highMana: false, theme: "blue",
    placeholder: true,
    ...extra,
  };
}

export const JOBS = {
  the_world:{id:'the_world',name:'더 월드',tier:2,line:'the_world',parent:null,hidden:true,unlockPending:true,weapon:'rpg:the_world_arrow',skills:['world_blood','world_muda','world_finish','world_roller','world_high','world_stop'],basic:false,corrupt:false,highMana:false,theme:'red'},
  war_god:{id:'war_god',name:'투신',tier:2,line:'war_god',parent:null,hidden:true,weapon:'rpg:war_god_gauntlets',skills:['war_god_punch','war_god_flurry','war_god_kick','war_god_kick_flurry','war_god_black_flash'],basic:false,corrupt:false,highMana:false,theme:'red'},
  apprentice: {
    id: "apprentice", name: "견습", tier: 1, line: "all", parent: null,
    weapon: null, skills: [], basic: false, corrupt: false, highMana: false, theme: "blue",
  },

  // ---- 검 계열 ----
  swordsman: {
    id: "swordsman", name: "검사", tier: 2, line: "sword", parent: "apprentice",
    weapon: "rpg:swordsman_sword", skills: ["sword_spin", "sword_wave", "sword_flame_spin"], basic: false, corrupt: false, highMana: false, theme: "blue",
    req: { key: "sword_kills", need: 100, label: "검으로 엔티티 처치" },
  },
  sword_saint: {
    id: "sword_saint", name: "검성", tier: 3, line: "sword", parent: "swordsman",
    weapon: "rpg:sword_saint_sword", skills: SWORD_SAINT_SKILLS, basic: true, corrupt: false, highMana: false, theme: "blue",
    req: { key: "diamond_swords", need: 100, label: "다이아몬드 검 바치기 (/rpg:offer)" },
  },
  // 타락검성은 검성의 스킬과 전용 액티브 '광분화'를 사용합니다.
  fallen_sword_saint: {
    id: "fallen_sword_saint", name: "타락검성", tier: 3, line: "sword", parent: "sword_saint",
    weapon: "rpg:fallen_sword_saint_sword", skills: FALLEN_SWORD_SKILLS, basic: true, corrupt: true, highMana: false, theme: "red",
    req: { key: "villager_kills", need: 100, label: "검성 상태에서 주민 처치" },
  },

  // ---- 마법 계열 ----
  mage: {
    id: "mage", name: "마법사", tier: 2, line: "mage", parent: "apprentice",
    weapon: "rpg:mage_book", skills: ["mage_fireball", "mage_lightning", ...MAGE_2],
    basic: false, corrupt: false, highMana: true, theme: "blue",
    req: { key: "books", need: 64, label: "인챈트 책 바치기 (/rpg:offer)" },
  },
  sage: {
    id: "sage", name: "현자", tier: 3, line: "mage", parent: "mage",
    weapon: "rpg:sage_staff", skills: [...MAGE_2, ...SAGE_3],
    basic: false, corrupt: false, highMana: true, theme: "blue",
    req: { key: "mana_spent", need: 30000, label: "마법사 상태에서 마나 사용" },
  },

  // ---- 궁수 계열: 견습 궁수 → 궁수 → 천궁 ----
  archer: {
    id: "archer", name: "궁수", tier: 2, line: "archer", parent: "apprentice",
    weapon: "rpg:archer_bow", skills: ["archer_airwalk", "archer_rapid", "archer_fire", "archer_ice", "archer_lightning", "archer_pierce"],
    basic: false, corrupt: false, highMana: false, theme: "blue",
    req: { key: "apprentice_arrow_hits", need: 20, label: "견습 활 명중" },
  },
  heavenly_archer: {
    id: "heavenly_archer", name: "천궁", tier: 3, line: "archer", parent: "archer",
    weapon: "rpg:heavenly_bow", skills: ["archer_airwalk", "archer_rapid", "archer_ice", "archer_lightning", "archer_pierce", "archer_homing", "archer_bomb", "archer_judgement", "archer_heavenly"],
    basic: false, corrupt: false, highMana: false, theme: "blue",
    req: { key: "archer_arrow_hits", need: 80, label: "궁수 활 명중" },
  },


  // ---- 히든 망나니 -> 야수 (망나니 스킬 승계) ----
  mangnani: {
    id: "mangnani", name: "망나니", tier: 2, line: "berserker", parent: null,
    hidden: true, weapon: "rpg:mangnani_axe", skills: ["berserker_charge", "berserker_slam", "berserker_execute", "beast_berserk", "berserker_triple_slash"],
    passive: "berserker_kill",
    basic: false, corrupt: true, highMana: false, theme: "red",
  },
  beast: {
    id: "beast", name: "야수", tier: 3, line: "berserker", parent: "mangnani",
    weapon: "rpg:beast_axe", skills: ["berserker_charge", "berserker_slam", "berserker_execute", "beast_berserk", "berserker_triple_slash", "beast_flame_burst", "beast_grand_explosion"],
    passive: "berserker_kill",
    basic: false, corrupt: true, highMana: false, theme: "red",
  },

  // ---- 히든 직업 냉기 능력자 (해금 방법은 사용자가 나중에 지정) ----
  frost_controller: {
    id: "frost_controller", name: "냉기 능력자", tier: 2, line: "frost", parent: null,
    hidden: true, weapon: "rpg:frost_gauntlet",
    skills: ["frost_shard", "frost_grasp", "frost_barrage", "frost_step", "frost_field", "frost_great_release", "frost_absolute"],
    basic: false, corrupt: false, highMana: true, theme: "blue",
  },

  // ---- 히든 직업 화염술사 (해금 조건 추후 결정) ----
  fire_controller: {
    id: "fire_controller", name: "화염술사", tier: 2, line: "fire", parent: null,
    hidden: true, weapon: "rpg:fire_gauntlet",
    skills: ["fire_ignite", "fire_pillar", "fire_wheel", "fire_armor", "fire_emperor"],
    basic: false, corrupt: false, highMana: true, theme: "red",
  },


  // ---- 히든 직업 용기사 ----
  dragon_knight: {
    id: "dragon_knight", name: "용기사", tier: 2, line: "dragon", parent: null,
    hidden: true, weapon: "rpg:dragon_knight_lance",
    skills: ["dragon_triple_strike", "dragon_gaze", "dragon_charge", "dragon_sprint", "dragon_breath", "dragon_domain"],
    passive: "dragon_third_strike",
    basic: false, corrupt: false, highMana: false, theme: "blue",
  },

  // ---- 악마: 검붉은 낫과 영혼 수확 패시브 ----
  demon: {
    id: "demon", name: "악마", tier: 2, line: "demon", parent: null, hidden: true,
    weapon: "rpg:demon_scythe",
    skills: ["demon_fear", "demon_vampirism", "demon_reap", "demon_contract", "demon_storm", "demon_domain"],
    passive: "demon_soul_harvest", basic: false, corrupt: true, highMana: true, theme: "red",
  },

  // ---- 마법공학사: 등 뒤의 보조 기계팔 + 표식 기반 기계 마법 ----
  technomancer: {
    id: "technomancer", name: "마법공학사", tier: 2, line: "tech", parent: null, hidden: true,
    weapon: "rpg:tech_staff", skills: ["tech_ray","tech_prison","tech_sphere","tech_bomb","tech_storm"],
    basic: false, corrupt: false, highMana: true, theme: "blue",
  },

  // ---- 신규 직업: 해커 / 혈술사 / 암살자 -> 그림자 암살자 ----
  // 해금 조건과 전용 스킬은 사용자 설정을 위해 현재 미지정.
  hacker: {
    id: "hacker", name: "해커", tier: 2, line: "hacker", parent: null, hidden: true,
    weapon: "rpg:hacker_core", skills: ["hacker_hack", "hacker_dummy_data", "hacker_reboot", "hacker_stealth", "hacker_copy", "hacker_ddos", "hacker_emp"], basic: false, corrupt: false, highMana: true, theme: "blue",
  },
  blood_mage: {
    id: "blood_mage", name: "혈술사", tier: 2, line: "blood", parent: null, hidden: true,
    weapon: "rpg:blood_crystal", skills: ["blood_spear", "blood_tentacle", "blood_orb", "blood_supernova", "blood_mark", "blood_awaken", "blood_bind"], basic: false, corrupt: false, highMana: true, theme: "red",
  },
  assassin: {
    id: "assassin", name: "암살자", tier: 2, line: "assassin", parent: null, hidden: true,
    weapon: "rpg:assassin_blade", skills: ["assassin_spin", "assassin_dagger_wave", "assassin_pierce"], basic: false, corrupt: false, highMana: false, theme: "blue",
  },
  shadow_assassin: {
    id: "shadow_assassin", name: "그림자 암살자", tier: 3, line: "assassin", parent: "assassin",
    weapon: "rpg:shadow_assassin_blade", skills: ["assassin_spin", "assassin_dagger_wave", "assassin_pierce", "assassin_stealth", "assassin_mark", "shadow_assassinate"], basic: false, corrupt: false, highMana: false, theme: "red",
  },

  // ---- 작살 계열: 작살꾼 → 복수귀 ----
  harpooner: {
    id: "harpooner", name: "작살꾼", tier: 2, line: "harpoon", parent: null, hidden: true,
    weapon: "rpg:harpooner_harpoon", skills: ["harpoon_throw", "harpoon_dive", "harpoon_charge"],
    basic: false, corrupt: false, highMana: false, theme: "blue",
  },
  revenant: {
    id: "revenant", name: "복수귀", tier: 3, line: "harpoon", parent: "harpooner",
    weapon: "rpg:revenant_harpoon", skills: ["revenant_deep_pierce", "revenant_rend", "harpoon_throw", "harpoon_charge", "soul_harpoon", "harpoon_dive", "soul_separation", "revenant_execution"],
    basic: false, corrupt: true, highMana: false, theme: "blue",
  },

  // ---- 해의 후예 / 달의 후예: 지상의 햇빛·달빛 충전 계열 ----
  sun_heir: {
    id:"sun_heir", name:"해의 후예", tier:2, line:"celestial_sun", parent:null,
    weapon:"rpg:sun_heir_axe", highMana:true, hidden:true, basic:false, corrupt:false, theme:"red",
    skills:["sun_charge","sun_slash","sun_blessing","sun_divine_blessing","sun_meteor_drive","sun_radiant_beam","sun_descent"],
  },
  moon_heir: {
    id:"moon_heir", name:"달의 후예", tier:2, line:"celestial_moon", parent:null,
    weapon:"rpg:moon_heir_blade", highMana:true, hidden:true, basic:false, corrupt:false, theme:"blue",
    skills:["moon_charge","moon_slash","moon_moonlight","moon_homing","moon_chakram_split","moon_veil","moon_fullwave"],
  },

  // ---- 카멜레온: 두 무기 전환 / 다른 직업의 모든 액티브 스킬 학습 ----
  chameleon: {
    id: "chameleon", name: "카멜레온", tier: 2, line: "chameleon", parent: null, hidden: true,
    weapon: "rpg:chameleon_flame_blade", altWeapon: "rpg:chameleon_moon_scythe",
    skills: ["chameleon_crimson_dash", "chameleon_ground_slam"], basic: false, corrupt: false, highMana: true, theme: "red",
  },

  // ---- 환수종 (미구현 자리 표시자, 전직 불가) ----
  // 삭제한 반인반수와의 전직 연결은 끊었습니다.
  beast_lord: stub("beast_lord", "환수종", 3, "beast", null),

  // ---- 무투가 계열 ----  (두 직업 모두 낙하 피해 없음)
  fighter: {
    id: "fighter", name: "무투가", tier: 2, line: "fist", parent: "apprentice",
    weapon: "rpg:fighter_fist", skills: FIGHTER_SKILLS, basic: false, corrupt: false, highMana: false, theme: "red",
    req: { key: "apprentice_sandbags", need: 1, label: "견습 상태에서 샌드백 파괴" },
  },
  fist_bone: {
    id: "fist_bone", name: "권골", tier: 3, line: "fist", parent: "fighter",
    weapon: "rpg:fist_bone_fist", skills: FIST_BONE_SKILLS, basic: false, corrupt: false, highMana: false, theme: "red",
    req: { key: "fighter_sandbags", need: 10, label: "무투가 상태에서 샌드백 10개 파괴" },
  },

  // ---- 성직자 계열 ----
  cleric: {
    id: "cleric", name: "성직자", tier: 2, line: "holy", parent: "apprentice",
    weapon: "rpg:cleric_cross", skills: CLERIC_SKILLS, basic: false, corrupt: false, highMana: true, theme: "blue",
  },
  angel: {
    id: "angel", name: "천사", tier: 3, line: "holy", parent: "cleric",
    weapon: "rpg:angel_hands", skills: ANGEL_SKILLS, basic: false, corrupt: false, highMana: true, theme: "blue",
    req: { key: "light_angel", need: 64, label: "축복의 빛 1세트 바치기 (/rpg:bless)" },
  },
  // 미카엘: 천사 스킬 + 패시브 '불사'
  michael: {
    id: "michael", name: "미카엘", tier: 4, line: "holy", parent: "angel",
    weapon: "rpg:michael_wings", skills: ANGEL_SKILLS, basic: false, corrupt: false, highMana: true, theme: "blue",
    passive: "undying",
    req: { key: "light_michael", need: 192, label: "축복의 빛 3세트 바치기 (/rpg:bless)" },
  },
  fallen_angel: {
    id: "fallen_angel", name: "타락천사", tier: 4, line: "holy", parent: "angel",
    weapon: "rpg:fallen_angel_wings", skills: FALLEN_SKILLS, basic: false, corrupt: true, highMana: true, theme: "red",
    req: { key: "angel_villager_kills", need: 100, label: "천사 상태에서 주민 처치" },
  },
};

export const BASIC_JOB_IDS=['swordsman','mage','archer','fighter','cleric'];
export const NORMAL_JOB_IDS=Object.freeze([...BASIC_JOB_IDS,'sword_saint','fallen_sword_saint','sage','heavenly_archer','angel','michael','fallen_angel','fist_bone']);
for(const job of Object.values(JOBS))if(job.id!=='apprentice'&&!job.placeholder)job.hidden=!NORMAL_JOB_IDS.includes(job.id);

export const ALL_WEAPON_IDS = [
  ...Object.keys(STARTER_ITEMS),
  ...Object.values(JOBS).map((j) => j.weapon).filter(Boolean),
  ...Object.values(JOBS).map((j) => j.altWeapon).filter(Boolean),
];

// id("sword_saint") 또는 이름("검성")으로 직업 찾기
export function findJob(input) {
  if (input === undefined || input === null) return null;
  const s = String(input).trim();
  if (!s) return null;
  if (JOBS[s]) return JOBS[s];
  // 명령어에서 한글 직업명의 띄어쓰기를 생략해도 동일하게 인식합니다.
  // 예: /force 반물질의신, /rpg:force 반물질의 신
  const normalized = s.replace(/\s+/g, "");
  if (["타락검사", "타락 검사", "fallen_swordsman"].includes(normalized)) return JOBS.fallen_sword_saint;
  return Object.values(JOBS).find((j) => j.name.replace(/\s+/g, "") === normalized || j.id === normalized) ?? null;
}
```

## RPG_BP_v0597/scripts/data/skillGuide.js

```javascript
// Descriptions checked against the active runners, not unused historical skills.
export const LINE_NAMES={the_world:'더 월드',sword:'검사·검성·타락검성',mage:'마법사·현자',archer:'궁수·천궁',holy:'천사는 아군의 실제 HP 회복을 누적해 300마다 축복의 빛 1개를 받습니다. 자가 회복·초과 회복·자연 재생·외부 재생 포션은 제외하고 성직 재생 기술은 집계합니다. 길들인 아군 동물도 지원합니다. 성직자·천사·미카엘·타락천사',fist:'무투가·권골',berserker:'망나니·야수',assassin:'암살자·그림자 암살자',harpoon:'작살꾼·복수귀',blood:'혈술사',hacker:'해커',dragon:'용기사',frost:'냉기 능력자',fire:'화염술사',tech:'마법공학사',demon:'악마',celestial_sun:'해의 후예',celestial_moon:'달의 후예',chameleon:'카멜레온',war_god:'투신'};
export const LINE_NOTES={the_world:'해금 조건 미정인 근접 격투 히든 직업. 관리자 /rpg:force the_world로 시험합니다. 황금 화살은 전용 건틀릿 매개이며 손에서는 숨겨집니다. 시간 정지 중 피해는 종료 시 적용합니다. 사망·접속 종료·차원 이동 취소 시 누적 피해는 취소됩니다.',
 war_god:'무투가와 별개인 독립 근력 기반 히든 직업. 무투가(권골 제외)에서 레벨 40·5단계 이상 던전 솔로 클리어 조건. 검붉은 건틀릿을 사용합니다. 천멸격은 다음에 사용하는 공격 스킬 한 번의 피해를 3배로 만듭니다. 대상이 없어 빗나가면 소모하지 않습니다.',
 sword:'검성·타락검성은 휘두르기 기본 참격을 사용합니다. 검성의 섬멸은 타락 전직 시 사라지고 광분화로 교체됩니다. 타락검성은 검성의 무조건 상위호환이 아닙니다.',
 mage:'고마나 계열: 기본 MP 200＋바친 인챈트 책 1권당 MP 20. 현자로 전직하면 견습 파이어볼·라이트닝은 사용 목록에서 빠집니다. 다단 피해는 전탄 명중 상한과 실제 피격 무적을 구분해야 합니다.',
 archer:'기본 화살은 엔진 투사체 피해입니다. 천궁은 차징 없이 발사하며 실물 화살이 없으면 발당 고정 MP 20으로 회수 불가 마나 화살(기본 피해 6)을 발사합니다. 연사 5발은 MP 100＋연사 스킬 비용. 마나 화살에는 지능 할인이 없으며 천궁 고유 패시브라 카멜레온이 기술을 배워도 얻지 않습니다.',
 holy:'천사 계열 날개와 미카엘 불사는 직업 고유 기능입니다. 불사는 생존 HP가 6 이하일 때 최대 HP 회복·저항 V 4초·재생 III/화염 저항 5초, 재사용 60초이며 이미 사망한 캐릭터를 부활시키지는 않습니다. 광역 회복·보호·힘 버프는 자신과 파티·길드·팀 아군에게만 적용됩니다.',
 fist:'강펀치는 평타와 일부 물리 격투 기술을 강화합니다. 풍압은 마력 판정이며 힘 버프 피해 증가도 받지만 강펀치 횟수는 소비하지 않습니다. 낙하 피해 방지 등 일부 방어 이벤트는 실행 중인 Bedrock API의 지원 여부에 영향을 받습니다.',
 berserker:'망나니·야수는 처치 시 신속 III·재생 III를 5초 얻습니다. 카멜레온도 배운 참수·3연베기·야수 화염방사·대폭발을 전용 무기로 사용합니다. 광분화 학습 카멜레온의 처치 버프는 기존 동작대로 유지합니다.',
 assassin:'그림자 은신의 3배 기습과 표식의 1.3배가 함께 작동하면 조건을 만족하는 한 번의 피해가 3.9배입니다. 현재 entityAttack 원인의 스킬도 기습으로 판정될 수 있습니다. 카멜레온은 배운 그림자 은신의 유지·기습을 사용할 수 있습니다.',
 harpoon:'복수귀 순서: 딥 피어스 → 찢어내기 → 작살 → 돌진 → 영혼작살 → 잠수 → 영혼분리 → 처형. 공격 기술을 앞에, 버프·유틸을 뒤에 두고 처형을 마지막에 배치합니다. 새 두 공격은 짧은 쿨타임·일반 3 SP 학습·사용 횟수 제한 없음. 처형은 반경 4칸 기준입니다.',
 blood:'혁린약동·재는 사용 시 재생 II 1분을 부여합니다. 적박만 자체 흡혈하며 시전당 최대 6하트를 회복합니다.',
 hacker:'전직은 로토와 23회 대화 후 퀴즈를 맞힌 월드 최초 1명에게만 허용됩니다. 이후 정답자는 인챈트된 황금사과 1개를 받습니다. 레벨·엘리트 처치 조건은 없습니다. 재부팅과 계약 관련 밸런스는 이번 요청에서 유지했습니다. 재부팅은 현재 제외 목록에 없는 일부 궁극기와 재부팅 자체도 초기화합니다. 카멜레온의 학습 사용 횟수는 초기화하지 않습니다. EMP는 기술 봉인·마나 삭제가 아닙니다.',
 dragon:'용기사는 근접 3타마다 추가 피해 10＋HP 6 회복을 얻습니다. 카멜레온도 배운 삼조격·질주·브레스를 사용하지만 용기사의 근접 3타 패시브는 얻지 않습니다. 일부 방어 효과는 before-hurt API가 필요합니다.',
 frost:'동결은 둔화·무력화와 위치 복귀로 대상을 묶습니다. 절대영도의 단순 둔화와 다르며, 현재 CC 점감·보스별 동결 내성은 따로 없습니다.',
 fire:'화염술사는 상시 화염 저항 I. 화상 추가 피해는 화염 면역 적에게 약하지만 직접 기술 피해까지 전부 화염 피해인 것은 아닙니다. 화갑 반격은 카멜레온 학습자도 유지합니다.',
 tech:'마공학 감옥이 표식을 공급하고 구체·폭탄이 표식 대상을 추적합니다. 폭풍은 표식 없이도 지정 위치에 생성됩니다. 보조 기계팔은 마법공학사 전용 장착물입니다.',
 demon:'악마는 적 처치 시 HP 6 즉시 회복＋재생 II 5초를 얻습니다. 이 영혼 수확 패시브는 카멜레온에게 자동 승계되지 않습니다. 자가 계약과 적 대상 계약의 효과가 다릅니다.',
 celestial_sun:'해의 후예 전직은 천체 신전의 해 제단 4칸 안에서 낮에만 가능합니다(레벨 20·낮 적 60). /rpg:temple로 위치를 확인하세요. 빛 최대 저장량 500. 오버월드 낮·하늘이 열린 장소에서는 해당 빛 비용을 면제하고, 그 외에는 저장 빛을 소비합니다. MP는 별도로 듭니다. 충전도 해당 환경에서만 가능합니다. 축복의 상태이상 면역은 위치 고정/강제 이동까지 모두 해제하는 완전 CC 면역이 아닙니다.',
 celestial_moon:'달의 후예의 공격 기술은 근력·물리 피해 보정을 받습니다. 달의 후예 전직은 천체 신전의 달 제단 4칸 안에서 밤에만 가능합니다(레벨 20·밤 적 60). /rpg:temple로 위치를 확인하세요. 달빛 최대 저장량 500. 오버월드 밤·하늘이 열린 장소에서는 일반 기술 빛 비용을 면제합니다. MP는 별도입니다. 카멜레온이 차크람 분열을 배우면 버프 중 해당 기술을 재사용하여 전용 무기로 투척합니다.',
 chameleon:'기본 기술 2개는 무료. 선택 학습은 일반 3 SP·중요 9 SP·궁극기/카피 15 SP. 중요 기술 10회, 궁극기/카피 3회이며 다이아 1개로 각각 +5/+1회 충전합니다. 실제 5레벨 상승마다 궁극기 제외 랜덤 책 1권. 스킬 분해 시 일반 3·중요 9·궁극기/카피 15 SP를 환급하며 스킬북 기술도 대상입니다. 재학습해도 남은 사용 횟수·쿨타임은 이어집니다. 다른 직업 고유 패시브는 자동 승계되지 않습니다.',
};
export const SKILL_NOTES={
 world_blood:'흡혈(첫 번째 스킬, 사용 버튼 또는 근접 타격으로 발동): 전방 5칸 가장 가까운 적을 물어 기본 12 피해를 주고 HP 8을 회복합니다. 사용 시 재생 II 10초·저항 II 30초(대상이 없어도 적용). 기존 더 월드 캐릭터도 자동 습득합니다. 보스·데스웜(샌드웜)·대장 고블린(대왕 고블린)을 흡혈하면 60초 안에 쓰는 다음 더 월드!가 6초 대신 9초로 늘어납니다. 보스 정지는 절반. MP 60·쿨 30초.',
 world_muda:'전방 4칸 부채꼴, 0.25초 간격 8회. 기본 물리 피해 6씩 최대 48. High한 기분 중 시전하면 16회 타격. 투신 난참과 같은 공격 판정·근력·장비 보정을 사용합니다.',
 world_finish:'전방 4칸 기본 물리 피해 10(High한 기분 중 시전하면 20)과 강한 밀치기·1초 둔화. 기존 쿨 9초의 1/8을 틱 단위로 올림해 1.15초.',
 world_roller:'벽을 확인하며 전방 최대 3칸 이동한 뒤 기본 물리 피해 35. 블록을 파괴하지 않습니다.',
 world_high:'8초간 신속 II·힘 II. 무다×8은 16회, 단발 무다 강타 기본 피해는 10에서 20으로 증가합니다. 힘 보정은 별도 적용되며 더 강한 기존 힘 효과는 낮추지 않습니다. 전용 화살 평타의 최소 간격이 0.5초에서 0.25초로 줄어듭니다. 스킬 강화는 시전 시점 기준이며 쿨타임·연타 간격은 유지합니다.',
 world_stop:'더 월드!: 시전 순간 플레이어 중심 반경 20칸의 적·투사체 최대 60개를 6초 정지. 보스 3초. 정지된 적은 공격·아이템 사용·예약 스크립트 공격이 차단됩니다. 이동·시점 입력 차단과 위치 고정. 시전자 전용 공격의 피해는 정지 해제 순간에 적용합니다. 쿨 20초, 기본 MP 320·지능 보정 후에도 최소 300. 사망·접속 종료·차원 이동 시 즉시 해제하며 이때 누적 피해는 취소됩니다. 아군은 제외합니다. 정지 중 시전자는 모든 적의 공격을 받지 않습니다(저항 V). 종료 후 기존 저항 효과는 복원됩니다.',

 war_god_punch:'청백색 부채꼴 충격파를 내뿜으며 전방 4칸·반폭 2칸에 기본 물리 피해 40. 밀치기와 짧은 둔화. 벽 너머 적은 제외합니다.',
 war_god_flurry:'청백색 충격파와 타격 섬광을 반복하며 전방 4칸에 0.25초 간격으로 6회, 기본 피해 10씩 명목 합계 60. 매 회차 범위를 다시 검사하므로 적이 벗어나면 남은 타격은 빗나갑니다.',
 war_god_kick:'아래에서 위로 솟는 청백색 발차기 궤적. 전방 6칸·반폭 2.5칸에 기본 물리 피해 48. 강한 밀치기와 1초 둔화. 블록은 파괴하지 않습니다.',
 war_god_kick_flurry:'발차기 궤적과 청백색 폭발을 교차시키며 전방 5.5칸에 0.4초 간격으로 4회, 기본 물리 피해 18씩 합계 72. 마지막 발차기에 강한 밀치기와 1초 둔화.',
 war_god_black_flash:'다음에 사용하는 투신 공격 스킬(폭멸타·난참·폭열권·파황각) 한 번의 피해를 3배로 강화합니다. 연타 스킬은 모든 타격에 3배가 적용됩니다. 평타는 강화되지 않으며, 대상이 없어 빗나간 스킬은 소비하지 않습니다. 이미 준비 중이면 다시 시전할 수 없습니다. 준비 상태와 쿨타임은 재접속해도 유지됩니다.',
 sword_spin:'시전자 주변 반경 4.5칸을 360도로 베어 기본 피해는 검사·타락검성·카멜레온 10, 검성 20(2배)과 밀치기. 광역 적에게 각각 한 번 피해를 줍니다.',
 sword_wave:'전방 사거리 18칸의 검기 투사체. 기본 피해는 검사·타락검성·카멜레온 14, 검성 21(1.5배). 폭 2.5칸으로 경로의 적을 공격하고 밀어냅니다.',
 sword_flame_spin:'약 1.4초 동안 회전하며 전진하는 불꽃 참격. 반경 3.4칸에 0.5초 간격으로 최대 3회 베기. 타격당 기본 피해 12.6(검성 18.9), 전부 맞으면 37.8(검성 56.7)과 4초 화상. 최대 돌진 거리 7칸. 점프 입력과 연동하는 공중 연출이 있습니다.',
 sword_kenho_rando:'큰 청록 초승달과 작은 보랏빛 참격이 겹치는 사거리 5.5칸의 세로 호 참격 3회. 각 기본 피해 12, 0.6초 간격이며 전부 맞으면 합계 36입니다.',
 sword_moon_dragon:'시전 시 바라본 방향의 전방 180도·반경 12칸에 0.6초 동안 큰 청록 초승달과 작은 보랏빛 달이 퍼집니다. 기본 물리 피해 28, 적마다 사용 1회당 한 번만 타격합니다. 높이 차 3칸·벽 가림을 검사하며 달의 개수로 피해가 중복되지 않습니다.',
 sword_annihilation:'전방 최대 15칸 이동하며 이동 경로 반경 4칸을 벱니다. 대상별 기본 피해 52를 한 번 적용하고 밀어냅니다. 검성 전용, 타락검성은 보유하지 않습니다.',
 sword_rush:'반경 10칸의 최근 타격 대상을 붙잡아 기본 피해는 검성 6씩 8회(합계 48), 타락검성·카멜레온은 4씩 8회(합계 32) 시도합니다. 연타 동안 저항 V를 얻어 공격과 방어를 함께 수행합니다.',
 fallen_sword_frenzy:'20초 동안 직접 준 피해의 30%를 흡혈합니다. 날개 강제 활성화는 원래 타락검성 직업에 제한되며 카멜레온에게 날개까지 자동 지급하지 않습니다.',
 mage_fireball:'사거리 40칸의 화염 투사체. 충돌 지점 반경 3칸에 기본 피해 6을 주는 견습·마법사 기술입니다.',
 mage_lightning:'시선 앞 사거리 24칸의 대상에 기본 피해 8. 현재 단일 번개 기술이며 유도탄 4발 기술은 봄바예입니다.',
 mage_flame_on:'시전자 주변 반경 15칸에 기본 피해 10과 화상 5초. 넓은 몰이용이며 직접 피해 효율은 낮습니다.',
 mage_thunder:'사거리 20칸 대상에게 번개를 3번, 0.4초 간격으로 시도합니다. 데이터 피해 25는 3회 합계입니다. 실제 벼락 소환 성공 시 벼락 추정 피해를 빼서 직접 피해를 계산합니다.',
 mage_ice_fire:'반경 10칸에 기본 피해 12와 둔화 VI를 4초 적용하는 광역 제어기입니다.',
 mage_gravity:'반경 10칸에 기본 피해 10과 둔화 IV를 5초 적용하고 아래 방향으로 계속 누릅니다. 중심으로 끌어모으는 블랙홀이나 위치 고정형 동결과는 다릅니다.',
 mage_bombaye:'주변 25칸에서 적을 탐색해 유도탄 4발을 발사합니다. 발당 14×0.3=4.2, 전탄 명목 합계 16.8. 비행 사거리 30칸이며 빗나가도 끝에서 작은 폭발을 만듭니다.',
 sage_meteor:'최근 마법 명중 대상이 60칸 안에 있으면 추적하고, 없으면 조준 지점에 낙하합니다. 준비 2초, 폭발 반경 8칸. 중심 기본 피해 58, 가장자리까지 선형으로 최대 50% 감소합니다.',
 sage_raiyoung:'사거리 35칸의 빠른 번개 구체. 기본 피해 28.8, 적중 위치의 폭발 연출과 번개 효과를 사용합니다.',
 sage_zero:'반경 20칸 적을 5초간 강한 둔화로 묶고, 시간이 끝나면 기본 피해 38.4. 위치 복귀로 강제 고정하는 냉기 직업의 동결과는 다릅니다.',
 sage_blackhole:'반경 12칸 블랙홀을 6초 유지해 적을 끌어당깁니다. 0.5초마다 기본 피해 약 4.1667, 전부 유지하면 합계 50.',
 sage_sphere:'사거리 32칸 큰 구체가 충돌하거나 사거리 끝에 도달하면 반경 7칸에 기본 피해 50와 밀치기.',
 sage_zoltraak:'전방 마법진에서 약 1초 준비 후 사거리 50칸·전체 명중 폭 10칸(중심에서 좌우 5칸)의 광선을 발사합니다. 기본 피해 96. 데이터 이름에 궁극기가 없지만 기존 궁극기로 분류하여 랜덤 책에서 제외합니다.',
 archer_airwalk:'지속 중 공중에서 점프 입력으로 다시 도약합니다. 견습 3초·궁수 8초·천궁 15초이며 비행을 무제한 상시 제공하지 않습니다.',
 archer_rapid:'일반 화살을 한 번에 견습 2발·궁수 3발·천궁 5발 발사합니다. 천궁의 마나 화살 모드에서는 5발 모두 발당 MP 20이 필요합니다. 실제 화살 사용 시 기존 한 묶음당 실물 1개 규칙을 유지합니다.',
 archer_fire:'이번 사격을 불 화살로 준비해 명중 대상에 5초 화상. 천궁 전직 시 폭탄 화살로 교체됩니다. 기본 화살 피해와 화상은 별도입니다.',
 archer_ice:'이번 사격 명중 대상에 둔화 III 5초와 추가 피해 3을 적용합니다.',
 archer_lightning:'이번 사격 명중 대상을 1초간 둔화·약화와 위치 복귀로 기절시킵니다.',
 archer_homing:'2분간 비행 중인 화살이 주변 24칸에서 적을 찾아 궤도를 수정합니다. 화살 자체 수명은 발사 후 5초입니다.',
 archer_bomb:'이번 사격 명중 대상에게 추가 피해 14. 폭발은 시각 효과이며 주변 전체 광역 피해나 블록 파괴는 없습니다.',
 archer_pierce:'사거리 38칸의 관통 궤적을 발사해 경로의 적에게 기본 피해 18. 실제 화살 아이템 대신 별도 광선 판정을 사용하는 기술입니다.',
 archer_judgement:'최근 피해를 준 살아 있는 적을 추적하는 전용 화살. 기본 피해 65를 한 번 주고 벽에 막히면 사라집니다. 표기 추적 사거리 96칸이며 최근 대상이 없으면 발동을 취소합니다.',
 archer_heavenly:'사거리 52칸의 관통 광선에 기본 피해 42. 첫 적중 위치에서 한 번만 반경 5칸 폭발을 만들고, 그 첫 대상 이외의 주변 적에게 추가 피해 18을 줍니다.',
 fist_strong:'30초 안의 다음 3회 공격을 2배로 강화합니다. 일부 물리 격투 기술도 횟수를 소비합니다. 풍압은 마법 기술로 변경되어 제외됩니다.',
 fist_flurry:'목표에게 접근하여 0.1초 간격으로 10회 공격합니다. 기본 피해 20은 10회 총합이며, 힘 효과와 강펀치는 별도로 반영합니다.',
 fist_smash:'1초 준비 후 전방 적에게 돌진해 기본 피해 28과 밀치기. 최대 탐색 사거리 32칸.',
 fist_wind:'전방 사거리 12칸·약 120도 부채꼴에 기본 마법 피해 20. 수평 밀치기 6.4·수직 1.8로 이전 값의 2배. 마력·마법 룬을 적용하고 힘 효과를 적용하지만 강펀치 횟수는 소비하지 않습니다.',
 fist_face:'반경 6칸 적을 시전자 정면으로 끌어오고 1초 기절시킵니다. 직접 피해는 0이며 지형·공간 검사 때문에 벽이나 낭떠러지를 강제로 관통해 끌지는 않습니다.',
 fist_stance:'자신에게 강한 둔화를 1초 적용하고 힘 II·저항 II를 15초 얻습니다. 준비 부담을 기존 3초에서 줄였습니다.',
 fist_finale:'반경 12칸 안의 최근 타격 대상을 고정해 상승·낙하 연출 후 고정 피해 60. 실제 대상을 높은 Y좌표로 옮기지는 않습니다. 근력·물리 룬에 따라 피해가 증가하지 않습니다.',
 holy_heal:'좌클릭한 생존 대상의 체력을 직업별 수치만큼 회복합니다. 힐은 예외적으로 적에게도 사용할 수 있지만, 적 회복은 아군 치유 기여·축복의 빛으로 계산하지 않습니다.',
 holy_shield:'반경 8칸에 흡수 V와 저항을 300초 부여합니다. 저항은 성직자 I·천사 II·미카엘 III. 자신과 같은 파티·길드·팀 아군에게만 적용합니다.',
 holy_sword:'반경 8칸 플레이어에게 성직자 힘 I·천사 II·미카엘 III를 300초 부여합니다. 자신과 같은 파티·길드·팀 아군에게만 적용합니다.',
 holy_orb:'아군 플레이어 한 명에게 부착해 재생·신속·흡수를 유지하고 시전자는 허기 II를 받습니다. 성직자 재생/신속 II·흡수 VIII, 천사 III/IX, 미카엘 IV/X. 거리 30칸·차원·생존·아군 조건을 벗어나면 해제됩니다. 카멜레온 학습자도 성직자 단계로 유지합니다.',
 holy_pray:'게임 시간 하루 한 번, 10초 실명·강한 둔화 후 축복의 빛을 성직자 1·천사 2·미카엘 3개 지급합니다. 전투 회복기가 아닌 제작 재료 획득기입니다.',
 angel_bless:'반경 12칸 플레이어 HP 20 회복, 재생 III·저항 II·신속 II 300초와 시듦·독·약화 제거. 자신과 같은 파티·길드·팀 아군만 지원합니다.',
 angel_zone:'반경 8칸에 15초 영역. 아군에게 1초마다 HP 2 회복, 최소 재생 V·저항 I 유지. 적에게 둔화 II. 쿨타임 150초. 적에게 지원 버프를 주지 않습니다.',
 fallen_sacrifice:'적을 좌클릭해 기본 피해 16을 줍니다. 추가 회복이나 흡혈 효과는 없습니다.',
 fallen_sword:'사거리 18칸 관통 검기로 기본 마법 피해 38, 시듦 II 5초와 밀치기.',
 fallen_shield:'5초 동안 저항 III. 받은 피해의 100%를 공격자에게 반사하고 시듦 I 3초.',
 fallen_curse:'시선 앞 사거리 30칸 적에게 기본 피해 10, 시듦 III·약화 II·둔화 II를 10초 적용합니다.',
 fallen_orb:'좌클릭으로 적에게 부착하거나 우클릭으로 구슬을 발사합니다. 기본 마법 피해 16, 최초 부착 시 시듦 III 10초. 부착 중 받는 피해 +35%. 시전자와 30칸 이상 떨어지거나 사망·차원 변경 시 해제. 시전자당 대상 하나, 중첩 불가.',
 fallen_zone:'시전 지점 반경 9칸에 15초 저주 영역. 1초마다 기본 피해 3과 시듦 I·둔화 II. 이론상 지속 피해 45이며 영역 체류와 피격 무적의 영향을 받습니다.',
 fallen_end:'4초 준비 중 시전자 저항 V, 주변 반경 25칸 적에게 둔화 I를 반복 적용합니다. 범위는 시전자를 따라 이동하고 마지막에 기본 피해 60·시듦 III 5초·밀치기. MP 800으로 조정했습니다.',
 berserker_charge:'전방 17칸에서 대상을 찾아 돌진·기본 피해 14. 벽 가까운 적에게 2초 기절과 추가 피해 배율 표식을 적용합니다.',
 berserker_slam:'반경 5칸에 기본 물리 폭발 피해 18을 먼저 주고 생존한 적을 위로 최대 10칸 띄웁니다. 천장을 통과하지 않으며 보스 띄우기는 절반.',
 berserker_execute:'다음 기본 근접 공격 ×4. 적의 타격 직전 체력이 최대 체력의 15% 미만이면 처형합니다. 정확히 15%는 즉사 조건이 아닙니다. 망나니·야수의 원래 무기와 학습한 카멜레온 무기로 사용.',
 beast_berserk:'20초 동안 허기 III·힘 IV·저항 II·신속 II. 야수는 추가 피해 흡수 IV와 흡혈 15%를 받습니다. 흡수의 룬과 흡혈 비율은 높은 값 하나를 사용합니다. 카멜레온은 기존 공통 버프를 받습니다.',
 berserker_triple_slash:'짧게 전진하며 기본 피해 12씩 3회, 0.5초 간격 참격. 명목 합계 36. 카멜레온 학습자도 3회의 후속 참격을 사용합니다.',
 beast_flame_burst:'전방으로 화염 구체 3발을 순차 발사. 발당 기본 물리 피해 15, 최대 합계 45와 3초 화상.',
 beast_grand_explosion:'약 1초 후 반경 15칸 폭발로 기본 피해 70. 블록을 파괴하는 실제 폭발이 아닌 스킬 피해·파티클입니다. 카멜레온 학습자도 발동합니다.',
 assassin_spin:'약 3칸 이동하며 반경 3칸에 기본 피해 24의 회전 참격. 벽 안으로 이동하지 않습니다.',
 assassin_dagger_wave:'사거리 22칸 단검 투사체. 기본 피해 25와 2초 둔화.',
 assassin_pierce:'전방 4.5칸 적에게 기본 피해 15와 10초 회복 봉쇄. 5틱마다 HP를 기록 상한 이하로 되돌리며 이후 피해를 받으면 상한도 내려갑니다.',
 assassin_stealth:'전방 12칸의 적 그림자로 이동하고 은신을 유지합니다. 다음 entityAttack 원인 피해를 3배로 증폭한 뒤 은신을 해제합니다. 적이 없으면 발동하지 않습니다.',
 assassin_mark:'전방 24칸 적에게 10초 동안 받는 피해 30% 증가 표식. 현재 추가 피해는 실제 받은 피해를 기준으로 HP를 직접 줄여 적용합니다.',
 shadow_assassinate:'25칸 안의 표식 대상이 필요합니다. 3초 동안 적을 따라가며 보호·은신 연출 후 기본 피해 38을 주고 안전한 주변 위치로 빠집니다.',
 revenant_deep_pierce:'전방 5.5칸·반폭 0.9칸을 찔러 기본 물리 피해 18. 벽에 가리지 않은 경로의 적을 관통하며 별도 대상 지정이 필요 없습니다. MP 18·쿨 2.5초.',
 revenant_rend:'전방 4.5칸·반폭 2.4칸을 베어 기본 물리 피해 16. 적중한 적에게 1초마다 3씩 세 번 추가해 명목 합계 25. 같은 시전자의 출혈은 중첩하지 않고 갱신합니다. MP 24·쿨 4초.',
 harpoon_throw:'사거리 30칸 작살 투사체에 기본 피해 12. 끌어오기 효과는 복수귀의 영혼작살에 있습니다.',
 harpoon_dive:'작살꾼은 5초 투명화·신속 III, 복수귀는 10초 투명화·신속 IV·재생 II를 얻습니다.',
 harpoon_charge:'전방 길이 5칸·폭 2.5칸의 직사각형 범위를 공격하며 5칸 이동합니다. 범위 안 적에게 기본 피해 28. 현재 지면·벽 검사가 부족해 이동 시 주의해야 합니다.',
 soul_harpoon:'사거리 34칸에 기본 마법 피해 32의 영혼 작살. 적중 대상을 시전자 쪽으로 끌어옵니다.',
 soul_separation:'바닥 조건 없이 전방 7칸으로 이동한 뒤 1초 후 귀환 경로를 따라 반경 3칸에 걸린 적을 3초 고정·기절시킵니다. 직접 피해보다 접근·광역 제어용입니다. 경로와 도착 위치의 벽은 통과하지 않습니다.',
 revenant_execution:'시전자 반경 4칸 안에서 HP 25% 이하 적들을 처형합니다. 성공하면 재생 III 5초·쿨 5초. 대상이 없으면 같은 반경의 최근 타격/조준 적에게 기본 피해 50, 쿨 60초. 직접 kill 처치의 보상 귀속은 실제 엔진 확인이 필요합니다.',
 blood_spear:'5회 공격 가능한 피의 창. 손에 들고 사용하면 6칸 찌르기. 기본 마법 피해 14·시듦 I 3초.',
 blood_tentacle:'3초간 시전자 주변 반경 20칸을 피의 채찍 네 갈래로 휘두릅니다. 적마다 한 시전에 기본 마법 피해 28을 1회 적용합니다. 벽 너머·아군 제외. MP 100·쿨 5초.',
 blood_orb:'쿨타임 5초. 사거리 30칸 구체. 직접 피해 18, 반경 2.5칸 파편 피해 8.',
 blood_supernova:'정면 최대 3칸 앞에 혈액 구체를 소환하고 0.75초 뒤 폭발시킵니다. 반경 5칸 기본 마법 피해 30, 쿨타임 15초.',
 blood_mark:'4칸 이내 근거리 기본 물리 피해 17, 원거리 사거리 27칸 기본 피해 15.',
 blood_awaken:'사용 시 재생 II 1분. 활성화 중 힘 III·저항 III·허기 III 유지. 1분 후 시듦 V. 다시 사용하면 해제합니다.',
 blood_bind:'반경 16칸 기본 마법 피해 10과 5초 속박. 실제로 준 피해만큼 시전당 최대 6하트 회복. 보스 속박은 기존 제어 저항을 따릅니다.',
 hacker_hack:'우클릭은 32칸 안 최근 타격 적에게 약화 IV·둔화 III·실명 3초. 아군을 8칸 안에서 좌클릭하면 재생 III·저항 III·포화를 20초 지원합니다. 자가 지원 해킹은 불가합니다.',
 hacker_dummy_data:'사거리 20칸 적을 자동 탐색하는 유도 패킷. 기본 마법 피해 26, 추적 수명 2.5초.',
 hacker_reboot:'반경 30칸의 자신·길드·파티·팀 아군 일반 기술 쿨타임을 초기화합니다. 기존 제외 목록에 없는 일부 궁극기와 재부팅 자체도 초기화합니다. 카멜레온 사용 횟수는 복구하지 않습니다.',
 hacker_stealth:'투명화·신속·허기 효과를 유지하는 토글 은신입니다. 그림자 암살자의 다음 공격 3배 기습 기능은 없습니다. 다시 사용하면 해제합니다.',
 hacker_copy:'현재 등록된 공격·제어 궁극기 중 실행 가능한 기술을 무작위로 발동합니다. 순수 버프 궁극기(다음 평타를 강화하는 천멸격 포함)는 제외합니다. 공격과 버프가 함께 있는 궁극기는 포함하며, 표식·대상·빛 등 원래 조건을 충족해야 합니다.',
 hacker_ddos:'시전자 반경 10칸 적들에게 기본 마법 피해 30. 마나를 삭제하거나 기술을 봉인하는 효과는 없습니다.',
 hacker_emp:'시전 지점 반경 30칸에 5초 영역. 적에게 약화 IV·둔화 III·실명을 갱신하고, 진입한 아군에 한 번씩 재생 III·저항 III 20초. 스킬 사용 금지 효과는 없습니다.',
 dragon_triple_strike:'10초 안의 다음 3타에 추가 피해 12씩, 세 번째에 1초 기절을 준비합니다. 카멜레온도 배운 기술의 후속 강화 3타를 사용할 수 있습니다.',
 dragon_gaze:'사거리 28칸 투사체로 기본 피해 20. 용기사 표식 후속 이벤트가 작동하면 10초 받는 피해 +30%; 해당 이벤트의 직업·API 제한을 확인해야 합니다.',
 dragon_charge:'사거리 26칸에 창을 던지고 닿은 엔티티 또는 벽 직전으로 이동합니다. 적에게 기본 물리 피해 18, 아군은 이동 목표로만 사용합니다. 음수 Y에서도 작동하며 바닥·안전 지형을 요구하지 않습니다.',
 dragon_sprint:'5초 동안 전방으로 초당 21칸 질주합니다. 서로 다른 적에게 최초 충돌 시 14×1.5^(누적 적 수−1) 기본 물리 피해. 적 수에 따른 상한은 없으며 카멜레온 학습자도 발동합니다. 음수 Y·공중에서도 작동하고 벽에서 정지합니다.',
 dragon_domain:'반경 7칸 수룡 영역을 10초 전개합니다. 진입 기본 피해 20과 주기 피해 8, 아군 저항 V. 카멜레온 학습자도 전개합니다. 외부 투사체 차단은 before-hurt API 지원 여부에 제한됩니다.',
 dragon_breath:'사거리 28칸의 용 브레스 투사체. 기본 피해 24·화상 4초. 카멜레온 학습자도 발사·후속 명중 효과를 사용합니다.',
 frost_shard:'사거리 32칸 서리 투사체. 기본 피해 14와 4초 둔화.',
 frost_grasp:'정면 7칸의 벽에 가리지 않은 적 한 명에게 기본 피해 12와 2초 동결. 시야 밖 또는 벽 뒤 적은 잡지 않습니다.',
 frost_barrage:'사거리 24칸 안의 적을 향해 얼음 유도탄 5발을 발사합니다. 날아가는 동안 이동 중인 적을 추적하고 여러 적이 있으면 분산합니다. 발당 기본 마법 피해 7·전탄 명목 합계 35와 둔화 II 2.5초. 벽에 닿거나 비행 거리가 끝나면 소멸합니다.',
 frost_step:'바닥·안전 지형 조건 없이 전방 6칸으로 이동하고 신속 III·저항 I를 5초 얻습니다.',
 frost_field:'시전 지점 반경 7칸에 5초 결계. 적에게 처음 닿을 때 기본 피해 10, 머무는 동안 둔화 III를 갱신합니다. 매번 10씩 반복 피해를 주지는 않습니다.',
 frost_great_release:'0.4초 준비 후 전방 10칸의 적에게 돌진해 기본 마법 피해 42와 3초 동결.',
 frost_absolute:'반경 12칸 적에게 기본 마법 피해 38과 5초 위치 고정형 동결. 보스 제어 시간은 절반.',
 fire_ignite:'시전자 주변 반경 7칸에 기본 피해 15와 5초 화상.',
 fire_pillar:'사거리 22칸의 조준 지점 반경 3칸에 기본 피해 22·위로 밀치기·3초 화상.',
 fire_wheel:'최대 8칸 전진하는 화염바퀴로 경로의 적에게 기본 피해 18과 4초 화상.',
 fire_armor:'10초 힘 II·저항 II. 3.2칸 안의 근접 공격자에게 3초 화상 반격. 상시 화염 저항은 실제 화염술사의 별도 패시브입니다.',
 fire_emperor:'반경 12칸에 기본 피해 36·5초 화상. 5초간 주변 영역이 매초 기본 피해 4를 시도하고, 자신은 힘 III·저항 II를 15초 얻습니다.',
 tech_ray:'사거리 26칸 관통 광선으로 대상별 기본 마법 피해 18과 10초 표식을 부착합니다. 지면에 4초 에너지 흔적을 남겨 주기적으로 기본 피해 4.',
 tech_prison:'사거리 16칸의 표식 적을 우선하고, 없으면 가장 가까운 적의 위치에 반경 4칸 감옥을 6초 설치합니다. 적이 없으면 발동하지 않습니다. 내부 적에게 둔화 IV와 10초 표식을 반복 갱신합니다.',
 tech_sphere:'36칸 안의 표식 적을 찾아 유도 구체로 기본 피해 22. 표식이 없으면 발동을 취소합니다.',
 tech_bomb:'32칸 안의 표식 대상에 폭탄을 부착합니다. 약 2초 뒤 대상에 기본 피해 30, 반경 2.6칸의 다른 적에 피해 9. 표식 없이 발동하지 않습니다.',
 tech_storm:'반경 5칸에 10초 폭풍을 생성해 0.5초마다 기본 피해 5를 시도합니다. 명목 합계 100. 36칸 안 표식 대상을 추적하고 표식이 끝나면 그 자리에 남습니다.',
 demon_fear:'사거리 26칸 공포 투사체로 기본 피해 16, 둔화 III·약화 II·실명 4초와 밀치기. 몬스터의 완전한 강제 도주와 같지는 않습니다.',
 demon_vampirism:'반경 10칸 안의 모든 적에게 빨대를 연결하는 영혼 궤적. 각각 기본 마법 피해 12, 적중 수만큼 재생 단계(최대 50)를 7초 얻습니다. 빨대는 최대 7초 표시되며 추가 지속 피해는 없습니다. 아군·사망·차원 변경·반경 이탈 시 해당 연결은 종료합니다.',
 demon_reap:'전방 사거리 4.6칸의 낫 참격으로 기본 물리 피해 36.',
 demon_contract:'우클릭 자신: HP 10을 내고 저항 III·흡수 X 120초. HP가 10 이하면 취소. 좌클릭 적: 고정 피해 14를 주지만 적도 힘 III를 5초 얻습니다. 이번 버전에서 수치·동작을 유지했습니다.',
 demon_storm:'자신의 디버프를 정화하고 반경 10칸 공포 폭풍을 10초 유지하며 초당 기본 피해 6을 시도합니다. 전부 적중할 때 명목 합계 60입니다.',
 demon_domain:'반경 7.5칸에서 시전자와 선택한 적 하나를 남겨 10초 격리합니다. 나머지 살아 있는 엔티티를 밖으로 밀고 재진입을 막으며 선택 적에 허기 V. 단순 광역 피해기가 아닙니다.',
 sun_charge:'오버월드 낮·열린 하늘에서 햇빛 35를 충전합니다. 최대 500. 자연 충전은 기존 초당 4 유지. 마나 충전과 별도입니다.',
 sun_slash:'7초 안의 다음 전용 도끼 기본 타격을 총 4배로 강화하고 둔화 III 1초. 저장 햇빛 비용 10, 적절한 환경에서는 빛 비용 면제.',
 sun_blessing:'20초 저항 II·흡수 IV, 최초 한 번 받은 공격의 100% 반사. 환경 비용 면제가 없으면 햇빛 15 소비.',
 sun_divine_blessing:'디버프 제거와 3분 부정 상태이상 면역, 처음 3초는 공격 피격 무적시간 우회. 저장 햇빛 비용 20. 위치 고정형 CC를 전부 해제하지는 않습니다.',
 sun_meteor_drive:'전방 22칸 적을 찾아 마법 광선 피해 14 후 짧게 돌진해 물리 피해 26. 명목 합계 40, 저장 햇빛 비용 15.',
 sun_radiant_beam:'1초 준비 후 바라보는 방향으로 10칸 레이저를 5초 발사합니다. 발사 중 시선을 돌리거나 위아래를 보면 광선과 타격 방향도 따라 바뀝니다. 매 틱(정상 20 TPS 기준 초당 20회) 기본 마법 피해 1·명목 합계 100, 피격 무적 시간 우회와 화상·약화 II. 저장 햇빛 비용 20.',
 sun_descent:'반경 12칸에 기본 마법 피해 20, 자신에게 힘 III·재생 II·포화·흡수 X를 15초. 저장 햇빛 비용 25.',
 moon_charge:'오버월드 밤·열린 하늘에서 달빛 35를 충전합니다. 최대 500. 자연 충전은 기존 초당 4 유지. 마나 충전과 별도입니다.',
 moon_slash:'전방 사거리 5.5칸 부채꼴에 기본 물리 피해 30. 근력·물리 장비와 힘 버프 보정. 저장 달빛 비용 10.',
 moon_moonlight:'최대 HP의 50%를 회복하고 보유 달빛의 30%를 소비합니다. 마력 배율로 늘리는 일반 힐과 별도 계산입니다. 야외 밤이 아니면 저장 달빛이 있어야 하며 최대 HP에서는 취소합니다.',
 moon_homing:'주변 10칸의 적을 유도 차크람으로 추적해 기본 물리 피해 28을 한 번 줍니다. 수명 약 2.25초. 저장 달빛 비용 12. 일반 무기 투척과 별도.',
 moon_chakram_split:'60초 동안 차크람 투척마다 소형 차크람 3개(각각 기본 물리 피해 4, 근력·물리 장비 보정)를 추가합니다. 카멜레온은 켜자마자 투척하고, 효과 중 같은 기술 재사용으로 반복 투척합니다. 투척 간격 0.75초이며 반복 투척은 추가 MP·학습 횟수를 쓰지 않습니다. 저장 달빛 비용 15.',
 moon_veil:'20초 투명화·신속 IV. 저장 달빛 비용 15. 그림자 은신의 3배 기습 효과는 없습니다.',
 moon_fullwave:'반경 11칸에 기본 물리 피해 50과 둔화 III 3초. 저장 달빛 비용 25.',
 chameleon_crimson_dash:'흑염 대검에서 5초 신속 V와 접촉 고정 피해 20. 이 기술로 처치하면 연속 재사용 기회를 얻고 최대 3연속, 마지막은 20초 쿨. 일반 쿨은 7초입니다.',
 chameleon_ground_slam:'백월의 낫에서 반경 4.6칸으로 지면 충격파. 기본 피해 18이며 시각 파동 7개를 피해 18×7로 계산하지 않습니다. MP 무료·쿨 7초.',
};
```

## RPG_BP_v0597/scripts/data/skills.js

```javascript
// 스킬 데이터. cooldown 은 틱(20틱 = 1초), mana 는 소모 마나, damage 는 체력 수치(하트 1칸 = 2).
//   maxTier : 이 차수까지만 쓰는 스킬 (마법사 견습 스킬은 3차 전직 시 목록에서 빠짐)
// 실제 동작은 skills/ 폴더의 같은 id 함수가 담당합니다.
export const SKILLS = {
  world_blood:{id:'world_blood',name:'흡혈',line:'the_world',mana:60,cooldown:600,range:5},
  world_muda:{id:'world_muda',name:'무다!×8',line:'the_world',mana:65,cooldown:140,range:4,width:2,hits:8,interval:5,damagePerHit:6,kick:false},
  world_finish:{id:'world_finish',name:'무다!!!',line:'the_world',mana:70,cooldown:23,range:4,width:1.8,hits:1,interval:5,damagePerHit:10,kick:true},
  world_roller:{id:'world_roller',name:'로드로러다!!',line:'the_world',mana:90,cooldown:240,range:4,width:2,hits:1,interval:5,damagePerHit:35,kick:true},
  world_high:{id:'world_high',name:'High한 기분',line:'the_world',mana:80,cooldown:400,duration:160},
  world_stop:{id:'world_stop',name:'더 월드!',line:'the_world',mana:320,cooldown:400,duration:120,bloodDuration:180,radius:20,ultimate:true},

 war_god_punch:{id:'war_god_punch',name:'폭멸타',line:'war_god',mana:60,cooldown:120,damagePerHit:40,hits:1,interval:0,range:4,width:2,kick:false},
 war_god_flurry:{id:'war_god_flurry',name:'난참',line:'war_god',mana:120,cooldown:200,damagePerHit:10,hits:6,interval:5,range:4,width:2,kick:false},
 war_god_kick:{id:'war_god_kick',name:'폭열권',line:'war_god',mana:90,cooldown:160,damagePerHit:48,hits:1,interval:0,range:6,width:2.5,kick:true},
 war_god_kick_flurry:{id:'war_god_kick_flurry',name:'파황각',line:'war_god',mana:160,cooldown:320,damagePerHit:18,hits:4,interval:8,range:5.5,width:2.5,kick:true},
 war_god_black_flash:{id:'war_god_black_flash',name:'천멸격 (궁극기)',buffOnlyUltimate:true,line:'war_god',mana:300,cooldown:1800,ultimate:true},
  // 카멜레온 흑염 대검 전용: 충돌 20 고정 피해 / 처치 시 연속 재사용 최대 3회.
  chameleon_crimson_dash: {
    id: "chameleon_crimson_dash", name: "적섬 돌진", line: "chameleon",
    mana: 0, cooldown: 140, damage: 20, duration: 100,
    speedAmplifier: 4, maxChain: 3, finishCooldown: 400, collisionRadius: 1.2,
  },
  chameleon_ground_slam: {
    id: "chameleon_ground_slam", name: "지면강타", line: "chameleon",
    mana: 0, cooldown: 140, damage: 18, radius: 4.6, pulses: 7, pulseStep: 0.34,
  },
  // 해의 후예: 유저 지정 기술. 지정 없는 수치는 임시 밸런스.
  sun_charge: {id:"sun_charge",name:"햇빛 충전",line:"celestial_sun",mana:0,cooldown:100,restore:35},
  sun_slash: {id:"sun_slash",name:"일륜참",line:"celestial_sun",mana:65,cooldown:160,damageMultiplier:4,slowTicks:20,slowAmp:2},
  sun_blessing: {id:"sun_blessing",name:"해의 가호",line:"celestial_sun",mana:110,cooldown:600,duration:400},
  // 해의 축복: 3분(3600틱)간 부정적 상태이상 면역, 최초 3초(60틱) 공격 무적시간 우회.
  sun_divine_blessing: {id:"sun_divine_blessing",name:"해의 축복",line:"celestial_sun",mana:155,cooldown:4200,immunityTicks:3600,pierceTicks:60},
  sun_meteor_drive: {id:"sun_meteor_drive",name:"메테오드라이브",line:"celestial_sun",mana:125,cooldown:300,range:22,beamDamage:14,impactDamage:26},
  sun_radiant_beam: {id:"sun_radiant_beam",name:"방사열선",line:"celestial_sun",mana:180,cooldown:600,chargeTicks:20,duration:100,range:10,damagePerPulse:1,pulsesPerSecond:20},
  sun_descent: {id:"sun_descent",name:"일륜강림 (궁극기)",line:"celestial_sun",mana:320,cooldown:1200,damage:20,radius:12,buffTicks:300,ultimate:true},
  // 달의 후예: 이전 버전 스킬 복원.
  moon_charge: {id:"moon_charge",name:"달빛 충전",line:"celestial_moon",mana:0,cooldown:100,restore:35},
  moon_slash: {id:"moon_slash",name:"초승달 참격",line:"celestial_moon",mana:65,cooldown:160,damage:30,range:5.5},
  moon_moonlight: {id:"moon_moonlight",name:"달빛",line:"celestial_moon",mana:250,cooldown:1200,healRatio:0.5,lightRatio:0.30},
  moon_homing: {id:"moon_homing",name:"월광 차크람",line:"celestial_moon",mana:75,cooldown:100,damage:28,range:10},
  // 달의 차크람을 실제 투척할 때마다 작은 차크람 3개를 추가 발사한다. 60초 유지.
  moon_chakram_split: {id:"moon_chakram_split",name:"차크람 분열",line:"celestial_moon",mana:90,cooldown:1500,duration:1200,smallCount:3,smallDamage:4},
  moon_veil: {id:"moon_veil",name:"밤의 장막",line:"celestial_moon",mana:95,cooldown:450,duration:400},
  moon_fullwave: {id:"moon_fullwave",name:"만월의 파동 (궁극기)",line:"celestial_moon",mana:310,cooldown:1200,damage:50,radius:11,slowTicks:60,ultimate:true},

  // ---------- 악마 (임시 피해량·마나·쿨타임) ----------
  demon_fear: { id:"demon_fear", name:"공포", line:"demon", mana:60, cooldown:160, damage:16, range:26, speed:1.25, fearTicks:80 },
  demon_vampirism: { id:"demon_vampirism", name:"흡혈", line:"demon", mana:90, cooldown:240, damage:12, radius:10, regenerationTicks:140, maxLevel:50 },
  demon_reap: { id:"demon_reap", name:"수확", line:"demon", mana:55, cooldown:120, damage:36, range:4.6 },
  demon_contract: { id:"demon_contract", name:"계약 (우클릭 자신 / 좌클릭 적)", line:"demon", trigger:"hybrid", mana:80, cooldown:400, healthCost:10, enemyDamage:14, enemyStrengthTicks:100, buffTicks:2400 },
  demon_storm: { id:"demon_storm", name:"공포의 폭풍 (궁극기)", line:"demon", mana:280, cooldown:1200, radius:10, duration:200, damagePerSecond:6, ultimate:true },
  demon_domain: { id:"demon_domain", name:"영역전개", line:"demon", mana:240, cooldown:900, radius:7.5, duration:200, hungerAmplifier:4, hungerRefresh:50 },

  // 마법공학사: 임시 피해량/마나/쿨타임. 사용자 요구는 행동/효과를 우선 적용.
  tech_ray: { id:"tech_ray",name:"마공학 광선",line:"tech",mana:90,cooldown:160,damage:18,range:26,groundTicks:80 },
  tech_prison: { id:"tech_prison",name:"마공학 감옥",line:"tech",mana:125,cooldown:340,radius:4,castRange:16,duration:120 },
  tech_sphere: { id:"tech_sphere",name:"마공학 구체",line:"tech",mana:70,cooldown:140,range:36,damage:22,speed:2.25 },
  tech_bomb: { id:"tech_bomb",name:"마공학 폭탄",line:"tech",mana:95,cooldown:220,range:32,damage:30,splashRadius:2.6,splashDamage:9,fuseTicks:40 },
  tech_storm: { id:"tech_storm",name:"마공학 폭풍 (궁극기)",line:"tech",mana:340,cooldown:1200,radius:5,followRange:36,duration:200,damagePerPulse:5,ultimate:true },
  // ---------- 암살자 / 그림자 암살자 (마나·미지정 쿨타임은 임시 밸런스) ----------
  assassin_spin: { id:"assassin_spin",name:"회전베기",line:"assassin",mana:60,cooldown:180,teleport:3,radius:3,damage: 24 },
  assassin_dagger_wave: { id:"assassin_dagger_wave",name:"몰아치는 단검",line:"assassin",mana:70,cooldown:160,damage:25,range:22,speed:1.45,hitRadius:1.1,slowTicks:40 },
  assassin_pierce: { id:"assassin_pierce",name:"피어스",line:"assassin",mana:65,cooldown:240,damage:15,range:4.5,noHealTicks:200 },
  assassin_stealth: { id:"assassin_stealth",name:"은신",line:"assassin",mana:70,cooldown:400,range:12 },
  assassin_mark: { id:"assassin_mark",name:"표식",line:"assassin",mana:75,cooldown:280,range:24,duration:200,damageMultiplier:1.3 },
  shadow_assassinate: { id:"shadow_assassinate",name:"그림자 암살 (궁극기)",line:"assassin",mana:280,cooldown:1000,damage:38,delay:60,range:25,ultimate:true },

  // ---------- 히든 직업 화염술사: 화염 저항 I 상시 패시브, 액티브 5종 ----------
  // 단위: 20틱=1초, 피해량은 체력 수치. 임시 밸런스.
  fire_ignite: { id:"fire_ignite", name:"자연발화", line:"fire", mana:55, cooldown:120, damage:15, radius:7, burnSeconds:5 },
  fire_pillar: { id:"fire_pillar", name:"불기둥", line:"fire", mana:110, cooldown:320, damage:22, range:22, radius:3, launch:1.0, burnSeconds:3 },
  fire_wheel: { id:"fire_wheel", name:"화염바퀴", line:"fire", mana:95, cooldown:220, damage:18, range:8, speed:1.3, wheelRadius:.75, hitRadius:1.5, burnSeconds:4 },
  fire_armor: { id:"fire_armor", name:"화갑", line:"fire", mana:100, cooldown:500, duration:200 },
  fire_emperor: { id:"fire_emperor", name:"염제 (궁극기)", line:"fire", mana:300, cooldown:1200, damage:36, radius:12, burnSeconds:5, zoneTicks:100, zoneDamage:4, buffTicks:300, ultimate:true },

  // ---------- 히든 냉기 능력자 (임시 밸런스: 피해는 체력 수치) ----------
  frost_shard: { id:"frost_shard",name:"서리탄",line:"frost",mana:35,cooldown:60,damage:14,range:32,speed:1.65,slowTicks:80 },
  frost_grasp: { id:"frost_grasp",name:"빙결의 손",line:"frost",mana:55,cooldown:160,damage:12,range:7,freezeTicks:40 },
  frost_barrage: { id:"frost_barrage",name:"빙주난사",line:"frost",mana:95,cooldown:240,shots:5,damage:7,range:24,speed:1.8,spread:.16 },
  frost_step: { id:"frost_step",name:"빙하보",line:"frost",mana:55,cooldown:200,distance:6,buffTicks:100 },
  frost_field: { id:"frost_field",name:"설한결계",line:"frost",mana:120,cooldown:400,radius:7,duration:100,damage:10 },
  frost_great_release: { id:"frost_great_release",name:"대빙해소",line:"frost",mana:100,cooldown:280,range:10,chargeTicks:8,dashSpeed:1.8,damage:42,freezeTicks:60 },
  frost_absolute: { id:"frost_absolute",name:"영점빙옥 (궁극기)",line:"frost",mana:300,cooldown:900,radius:12,damage:38,freezeTicks:100,ultimate:true },
  // ---------- 작살꾼 / 복수귀 ----------
  harpoon_throw: { id:"harpoon_throw",name:"작살",line:"harpoon",mana:50,cooldown:160,damage:12,range:30,speed:1.35 },
  harpoon_dive: { id:"harpoon_dive",name:"잠수",line:"harpoon",mana:70,cooldown:400,duration:100 },
  harpoon_charge: { id:"harpoon_charge",name:"돌진",line:"harpoon",mana:100,cooldown:300,damage:28,length:5,width:2.5 },
  soul_harpoon: { id:"soul_harpoon",name:"영혼작살",line:"harpoon",mana:75,cooldown:200,damage: 32,range:34,speed:1.45 },
  soul_separation: { id:"soul_separation",name:"영혼분리",line:"harpoon",mana:150,cooldown:600,range:7,delay:20,radius:3,stun:60 },
  revenant_deep_pierce: {id:'revenant_deep_pierce',name:'딥 피어스',line:'harpoon',mana:18,cooldown:50,damage:18,range:5.5,halfWidth:.9},
  revenant_rend: {id:'revenant_rend',name:'찢어내기',line:'harpoon',mana:24,cooldown:80,damage:16,range:4.5,halfWidth:2.4,bleedDamage:3,bleedHits:3,bleedInterval:20},
  revenant_execution: { id:"revenant_execution",name:"처형 (궁극기)",line:"harpoon",mana:200,cooldown:1200,successCooldown:100,failDamage:50,healthThreshold:.25,radius:4,ultimate:true },

  // ---------- 혈술사: 혈액 기반 마법 (임시 밸런스, 단위는 게임 틱) ----------
  blood_spear: { id:"blood_spear",name:"피의 창 제작",line:"blood",mana:40,cooldown:100,damage: 14,range:6,durability:5,witherTicks:60 },
  blood_tentacle:{id:'blood_tentacle',name:'혈촉수',line:'blood',mana:100,cooldown:100,duration:60,radius:20,damage:28},
  blood_orb: { id:"blood_orb",name:"혈성뢰",line:"blood",mana:75,cooldown:100,damage:18,splashDamage:8,burstRadius:2.5,range:30,speed:1.2 },
  blood_supernova: { id:"blood_supernova",name:"초신성",line:"blood",mana:120,cooldown:300,damage:30,burstRadius:5,forward:3,detonateTicks:15 },
  blood_mark: { id:"blood_mark",name:"혈인 (근거리·원거리)",line:"blood",mana:60,cooldown:120,meleeRange:4,meleeDamage:17,rangedDamage:15,range:27 },
  blood_awaken: { id:"blood_awaken",name:"혁린약동•재",line:"blood",mana:180,cooldown:900,warningTicks: 1200,strengthAmp:2,resistanceAmp:2,hungerAmp:2 },
  blood_bind: { id:"blood_bind",name:"적박 (궁극기)",line:"blood",mana:250,cooldown:1300,duration:100,damage:10,healCap:12,radius:16,ultimate:true },
  // ---------- 해커: v0.4.37 기능 복원 ----------
  hacker_hack: { id:"hacker_hack",name:"해킹",line:"hacker",mana:40,cooldown:120,range:32 },
  hacker_dummy_data: { id:"hacker_dummy_data",name:"더미데이터",line:"hacker",mana:30,cooldown:40,range:20,damage: 26,speed:1.65,hitRadius:0.9,lifetime:50 },
  hacker_reboot: { id:"hacker_reboot",name:"시스템 재부팅",line:"hacker",mana:150,cooldown:800,radius:30 },
  hacker_stealth: { id:"hacker_stealth",name:"은신",line:"hacker",mana:60,cooldown:400 },
  hacker_copy: { id:"hacker_copy",name:"카피",line:"hacker",mana:200,cooldown:1200 },
  hacker_ddos: { id:"hacker_ddos",name:"디도스",line:"hacker",mana:110,cooldown:240,radius:10,damage:30 },
  hacker_emp: { id:"hacker_emp",name:"EMP (궁극기)",line:"hacker",mana:350,cooldown:1800,radius:30,duration:100,ultimate:true },

  // ---------- 히든 직업 용기사 ----------
  dragon_triple_strike: { id:"dragon_triple_strike", name:"삼조격", line:"dragon", mana:70, cooldown:220, duration:200, bonusDamage:12, thirdStun:20 },
  dragon_gaze: { id:"dragon_gaze", name:"용의 시선", line:"dragon", mana:85, cooldown:180, damage:20, range:28, speed:1.5, markDuration:200, markMultiplier:1.3 },
  dragon_charge: { id:"dragon_charge", name:"무쌍돌격", line:"dragon", mana:110, cooldown:320, damage:18, range:26, speed:1.75 },
  // 5초 강제 질주: 21블록/초 = 1.05블록/틱. 충돌한 서로 다른 적에 대해 14 × 1.5^(n-1).
  dragon_sprint: { id:"dragon_sprint", name:"용의 질주", line:"dragon", mana:110, cooldown:400, duration:100, speed:21, damage:14, multiplier:1.5, hitRadius:1.35 },
  dragon_domain: { id:"dragon_domain", name:"현월수룡 (궁극기)", line:"dragon", mana:320, cooldown:1200, radius:7, duration:200, entryDamage:20, pulseDamage:8, allyBuffTicks:60, ultimate:true },
  dragon_breath: { id:"dragon_breath", name:"용의 브레스", line:"dragon", mana:120, cooldown:280, damage:24, range:28, speed:1.45, hitRadius:1.3, burnSeconds:4 },

  // ---------- 검 계열 ----------
  // 검사 계열 공통 스킬: 작골염양. 미지정 수치는 임시 밸런스(틱 단위).
  sword_flame_spin: {
    id: "sword_flame_spin", name: "작골염양", line: "sword", damageByJob: { sword_saint: 18.9 },
    mana: 50, cooldown: 160, damage: 12.6,
    duration: 28, hits: 3, hitInterval: 10, radius: 3.4, burnSeconds: 4,
    dashRange: 7, dashSpeed: 1.0,
  },
  // 검성·타락검성 공용: 세로 방향 호 참격을 3회 연속 발동. 수치는 임시 밸런스.
  sword_kenho_rando: {
    id: "sword_kenho_rando", name: "검호 난도", line: "sword",
    mana: 65, cooldown: 220, damagePerSlash: 12,
    slashes: 3, slashInterval: 12, reach: 5.5, halfWidth: 1.9,
  },
  // 검성·타락검성 공용: 시전 전방 180도로 확장되는 큰 초승달·작은 달 참격.
  sword_moon_dragon: {
    id: "sword_moon_dragon", name: "월룡륜미", line: "sword",
    mana: 70, cooldown: 180, damage: 28,
    range: 12, radius:12, duration:12, height:3, knockback: 0.8,
  },
  sword_spin: {
    id: "sword_spin", name: "360도 휘두르기", line: "sword", damageByJob: { sword_saint: 20 },
    mana: 20, cooldown: 30,
    damage: 10, radius: 4.5, knockback: 1.3,
  },
  sword_wave: {
    id: "sword_wave", name: "검기 방출", line: "sword", damageByJob: { sword_saint: 21 },
    mana: 30, cooldown: 60,
    damage: 14, range: 18, speed: 1.0, width: 2.5, hitRadius: 2.6, knockback: 1.0,
  },
  sword_annihilation: {
    id: "sword_annihilation", name: "섬멸", line: "sword",
    // 발도를 대체하는 검성 전용 광역 참격. 전방 15블록 순간이동, 이동 경로 반경 4블록, 대상별 1회 피해.
    mana: 40, cooldown: 100,
    damage: 52, range: 15, hitRadius: 4, knockback: 1.15,
  },
  sword_rush: {
    id: "sword_rush", name: "러쉬 (궁극기)", line: "sword", damageByJob: { sword_saint: 6 },
    mana: 80, cooldown: 300,
    damage: 4, radius: 10, hits: 8, stepTicks: 4, // 40% of original 10 damage per hit
  },
  fallen_sword_frenzy: {
    id: "fallen_sword_frenzy", name: "광분화", line: "sword",
    mana: 100, cooldown: 1200, // 60초 쿨타임
    duration: 400, lifesteal: 0.30, // 20초간 모든 직접 피해의 30% 흡혈
  },

  // ---------- 히든 흑마법사 / 반물질의 신 ----------
  // 피해량·마나·쿨타임은 추후 밸런싱하기 쉽도록 이곳에서 수정합니다.
  dark_energy: {
    id: "dark_energy", name: "암흑 에너지", line: "necro",
    mana: 55, cooldown: 80, damage: 12, range: 28, speed: 1.35, radius: 1.5, burstRadius: 3, burstDamage: 12,
  },
  event_horizon: {
    id: "event_horizon", name: "사건의 지평선", line: "necro",
    mana: 120, cooldown: 360, size: 5, duration: 100, stunTicks: 60, range: 22,
  },
  dark_chains: {
    id: "dark_chains", name: "암흑사슬", line: "necro",
    mana: 140, cooldown: 360, delay: 60, damage: 36, range: 35,
  },
  dark_touch: {
    id: "dark_touch", name: "어둠의 손길", line: "necro",
    mana: 85, cooldown: 200, damage: 18, range: 35, pullDistance: 2.25,
  },
  // '암흑 에너지' 스킬은 흑마법사=투사체, 반물질의 신=지름 6 범위 공격으로 나뉩니다.
  // 범위형은 아래 burstRadius/burstDamage로 독립 밸런싱할 수 있습니다.
  death_domain: {
    id: "death_domain", name: "죽음의 영역", line: "necro",
    mana: 250, cooldown: 900, duration: 240, radius: 5, range: 32,
    darknessLevel: 0, weaknessLevel: 1, // 나약함 II = amplifier 1
  },

  // ---------- 히든 망나니 / 야수 ----------
  // 패시브: 엔티티 처치 시 5초간 신속 III + 재생 III (망나니/야수 공통)
  berserker_charge: {
    id: "berserker_charge", name: "돌진", line: "berserker",
    mana: 70, cooldown: 160, damage: 14, range: 17, wallHitDistance: 2.5,
    wallStunTicks: 40, wallDamageMultiplier: 2,
  },
  berserker_slam: {
    id: "berserker_slam", name: "내려찍기", line: "berserker",
    mana: 80, cooldown: 240, radius: 5, riseBlocks: 10,
    damage: 18,
  },
  berserker_execute: {
    id: "berserker_execute", name: "참수", line: "berserker",
    mana: 90, cooldown: 360, nextMeleeMultiplier: 4, executeThreshold: 0.15,
  },
  beast_berserk: {
    id: "beast_berserk", name: "광분화", line: "berserker",
    mana: 180, cooldown: 1000, duration: 400,
    hungerAmp: 2, strengthAmp: 3, resistanceAmp: 1, speedAmp: 1,
    beastLifesteal: 0.15, beastAbsorptionAmp: 3, // 야수 전용 추가 피해 흡수 IV (20초)
  },
  berserker_triple_slash: {
    id: "berserker_triple_slash", name: "3연베기", line: "berserker",
    mana: 70, cooldown: 200, damagePerHit: 12,
    slashes: 3, slashInterval: 10, stepDistance: 1.1, range: 3.5, halfWidth: 2.2,
  },
  beast_flame_burst: {
    id: "beast_flame_burst", name: "화염방사", line: "berserker",
    mana: 110, cooldown: 240, shots: 3, shotInterval: 7,
    damagePerShot: 15, range: 26, speed: 1.6, hitRadius: 1.3, burnSeconds: 3,
  },
  beast_grand_explosion: {
    id: "beast_grand_explosion", name: "대폭발 (궁극기)", line: "berserker",
    mana: 280, cooldown: 1200, delay: 20, radius: 15, damage: 70, ultimate: true,
  },

  // ---------- 궁수 계열 ----------
  // 활은 화살을 사용해 평타 사격을 할 수 있습니다. 스킬은 활을 당겼다 놓으면 추가 발동합니다.
  archer_airwalk: {
    id: "archer_airwalk", name: "에어워크", line: "archer",
    mana: 45, cooldown: 300, // 견습 3초 / 궁수 8초 / 천궁 15초
  },
  archer_rapid: {
    id: "archer_rapid", name: "연사", line: "archer",
    mana: 35, cooldown: 60, // 견습 2발 / 궁수 3발 / 천궁 5발
  },
  archer_fire: {
    id: "archer_fire", name: "불 화살", line: "archer", maxTier: 2,
    mana: 50, cooldown: 100, burnSeconds: 5,
  },
  archer_ice: {
    id: "archer_ice", name: "얼음 화살", line: "archer",
    mana: 60, cooldown: 110, slowAmp: 2, extraDamage: 3,
  },
  archer_lightning: {
    id: "archer_lightning", name: "전기 화살", line: "archer",
    mana: 65, cooldown: 120, stunTicks: 20,
  },
  archer_homing: {
    id: "archer_homing", name: "유도 화살 활성화", line: "archer",
    mana: 160, cooldown: 2600, duration: 2400,
  },
  archer_bomb: {
    id: "archer_bomb", name: "폭탄 화살", line: "archer",
    mana: 90, cooldown: 140, extraDamage: 14,
  },
  archer_triple: {
    id: "archer_triple", name: "삼연사", line: "archer",
    mana: 45, cooldown: 80, damage: 7, range: 30, spread: 0.15,
  },
  archer_pierce: {
    id: "archer_pierce", name: "관통 화살", line: "archer",
    mana: 65, cooldown: 140, damage: 18, range: 38, hitRadius: 1.3,
  },
  archer_judgement: {
    id: "archer_judgement", name: "심판", line: "archer",
    // 내가 가장 최근 피해를 준 살아 있는 대상에게 대형 빛의 화살 발사 (65피해, 35초, 300MP).
    mana: 300, cooldown: 700, damage: 65, range: 96, speed: 2.6,
  },
  archer_heavenly: {
    id: "archer_heavenly", name: "천공의 일격 (궁극기)", line: "archer",
    mana: 260, cooldown: 600, damage: 42, range: 52, hitRadius: 2.3, burstDamage: 18, burstRadius: 5,
  },

  // ---------- 무투가 계열 ----------
  // 모든 피해에는 힘 버프 증가분이 더해지고, 강펀치가 켜져 있으면 그 합계가 2배가 됩니다.
  fist_strong: {
    id: "fist_strong", name: "강펀치", line: "fist",
    mana: 30, cooldown: 200,
    hits: 3, duration: 600, // 다음 3번 공격 2배 (30초 안에 못 쓰면 사라짐)
  },
  fist_flurry: {
    id: "fist_flurry", name: "난타", line: "fist",
    mana: 80, cooldown: 300,
    damage: 20, hits: 10, stepTicks: 2, radius: 10, range: 8, returnToOrigin: false, // damage 는 전체 합계 (체력 10칸)
  },
  fist_smash: {
    id: "fist_smash", name: "스매쉬", line: "fist",
    mana: 60, cooldown: 200, // 쿨타임 10초
    damage: 28, range: 32, charge: 20, dashSpeed: 3.5, coneDot: 0.85, knockback: 1.6,
  },

  // ---------- 무투가 계열: 권골 ----------
  fist_wind: {
    id: "fist_wind", name: "풍압", line: "fist",
    mana: 90, cooldown: 260, // 마법 피해, 쿨타임 13초
    damage: 20, damageType: "magic", range: 12, coneDot: 0.5, knockback: 6.4, vertical: 1.8,
  },
  fist_face: {
    id: "fist_face", name: "안면강타", line: "fist",
    mana: 100, cooldown: 400,
    radius: 6, stun: 20, damage: 0, // 6블럭 안 모두 끌어오고 1초 기절
  },
  fist_stance: {
    id: "fist_stance", name: "강자의 자세", line: "fist",
    mana: 100, cooldown: 600,
    freeze: 20, buffTicks: 300, strengthAmp: 1, resistanceAmp: 1, // 1초 자기 둔화, 15초간 힘 2 / 저항 2
  },
  fist_finale: {
    id: "fist_finale", name: "대미장식 (궁극기)", line: "fist",
    mana: 300, cooldown: 1200,
    damage: 60, radius: 12, rise: 15, riseTicks: 20, hoverTicks: 10, holdOffset: 2.0, slamSpeed: 3, // 체력 30칸 고정 피해
  },

  // ---------- 마법 계열: 견습 ----------
  mage_fireball: {
    id: "mage_fireball", name: "파이어볼", line: "mage", maxTier: 2,
    mana: 15, cooldown: 20,
    damage: 6, speed: 1.2, range: 40, radius: 3, hitRadius: 1.2,
  },
  mage_lightning: {
    id: "mage_lightning", name: "라이트닝", line: "mage", maxTier: 2,
    mana: 40, cooldown: 60,
    damage: 8, range: 24,
  },

  // ---------- 마법 계열: 2차 ----------
  mage_flame_on: {
    id: "mage_flame_on", name: "플레임온", line: "mage",
    mana: 150, cooldown: 240,
    damage: 10, radius: 15, burn: 5,
  },
  mage_thunder: {
    id: "mage_thunder", name: "번개", line: "mage",
    mana: 200, cooldown: 300,
    damage: 25, strikes: 3, interval: 8, range: 20, // damage 는 3번 합계
  },
  mage_ice_fire: {
    id: "mage_ice_fire", name: "아이스불", line: "mage",
    mana: 180, cooldown: 280,
    damage: 12, radius: 10, slowAmp: 5, duration: 80,
  },
  mage_gravity: {
    id: "mage_gravity", name: "그래비티", line: "mage",
    mana: 160, cooldown: 280,
    damage: 10, radius: 10, slowAmp: 3, duration: 100, // 구속 4단계 = amplifier 3
  },
  mage_bombaye: {
    id: "mage_bombaye", name: "봄바예", line: "mage",
    mana: 120, cooldown: 120,
    damage: 14, shots: 4, damageMultiplier: 0.3,
    speed: 0.9, range: 30, seekRadius: 25, turn: 0.25, hitRadius: 1.4,
  },

  // ---------- 마법 계열: 3차 ----------
  sage_meteor: {
    id: "sage_meteor", name: "메테오", line: "mage",
    mana: 700, cooldown: 400,
    damage: 58, radius: 8, delay: 40, range: 40,
    homingRange: 60, // 마지막으로 맞춘 대상이 이 거리 안에 있으면 그 대상에게 낙하
  },
  sage_raiyoung: {
    id: "sage_raiyoung", name: "뇌영", line: "mage",
    mana: 450, cooldown: 100,
    damage: 28.8, speed: 2.2, range: 35, hitRadius: 2.0, burst: 4, // 36의 0.8배
  },
  sage_zero: {
    id: "sage_zero", name: "절대영도", line: "mage",
    mana: 1000, cooldown: 450,
    damage: 38.4, radius: 20, freeze: 100, // 48의 0.8배
  },
  sage_blackhole: {
    id: "sage_blackhole", name: "블랙홀", line: "mage",
    mana: 900, cooldown: 500,
    damage: 50, radius: 12, duration: 120, range: 30, homingRange: 60, // damage 는 지속 시간 동안의 합계
  },
  sage_sphere: {
    id: "sage_sphere", name: "초구체", line: "mage",
    mana: 750, cooldown: 250,
    damage: 50, speed: 1.6, range: 32, hitRadius: 2.2, radius: 7, // 기본 피해 50
  },
  sage_zoltraak: {
    id: "sage_zoltraak", name: "졸트라크", line: "mage",
    mana: 1000, cooldown: 600,
    damage: 96, range: 50, width: 5, // 120의 0.8배
  },

  // ---------- 성직자 계열 ----------
  // trigger: "hit" 이면 우클릭이 아니라 '좌클릭으로 엔티티를 때릴 때' 발동합니다.
  // 맞은 엔티티를 즉시 치유. 회복량은 직업별 하트 칸 수(견습 2 / 성직자 4 / 천사 5 / 미카엘 8칸)
  holy_heal: {
    id: "holy_heal", name: "힐", line: "holy", trigger: "hit",
    mana: 30, cooldown: 20,
    healByJob: { apprentice: 2, cleric: 4, angel: 5, michael: 8 }, // 하트 칸 수
  },
  // 저항/힘 단계는 표시 단계(1=I, 2=II, 3=III) 기준입니다. 성직자 1 / 천사 2 / 미카엘 3
  holy_shield: {
    id: "holy_shield", name: "불굴의 방패", line: "holy",
    mana: 60, cooldown: 400,
    absorption: 4, duration: 6000, radius: 8, // absorption 은 효과 단계(0=1단계)
    resistanceByJob: { cleric: 1, angel: 2, michael: 3 },
  },
  holy_sword: {
    id: "holy_sword", name: "불굴의 검", line: "holy",
    mana: 70, cooldown: 400,
    duration: 6000, radius: 8,
    strengthByJob: { cleric: 1, angel: 2, michael: 3 },
  },
  // 좌클릭으로 엔티티 1명에게 부착. 성직자와 maxDistance 칸 넘게 떨어지면 사라집니다.
  // 붙어 있는 동안 성직자는 허기, 대상은 재생/신속/흡수 (표시 단계, 전직할수록 +1)
  holy_orb: {
    id: "holy_orb", name: "축복의 구슬", line: "holy", trigger: "hit",
    mana: 90, cooldown: 160,
    maxDistance: 30,
    hunger: 2, // 성직자에게 걸리는 허기 단계(표시 단계)
    regenByJob: { cleric: 2, angel: 3, michael: 4 },
    speedByJob: { cleric: 2, angel: 3, michael: 4 },
    absorbByJob: { cleric: 8, angel: 9, michael: 10 },
  },
  holy_pray: {
    id: "holy_pray", name: "기도", line: "holy",
    mana: 0, cooldown: 24000, // 게임 시간 하루(20분)에 1번
    duration: 200, // 기도 중 실명/구속 시간(틱)
  },
  angel_bless: {
    id: "angel_bless", name: "천사의 축복", line: "holy",
    mana: 250, cooldown: 1200,
    heal: 20, regen: 2, resistance: 1, speed: 1, duration: 6000, radius: 12,
  },
  angel_zone: {
    id: "angel_zone", name: "축복 영역", line: "holy",
    mana: 300, cooldown: 3000,
    heal: 2, radius: 8, duration: 300, slowAmp: 1,
    regen: 4,
  },

  // ---------- 성직자 계열: 타락천사 ----------
  // 좌클릭으로 적을 때리면 발동: 상대에게 하트 8칸(damage 16) 피해 (다른 효과 없음)
  fallen_sacrifice: {
    id: "fallen_sacrifice", name: "Sacrifice", line: "holy", trigger: "hit",
    mana: 50, cooldown: 100,
    damage: 16, // 하트 8칸
  },
  fallen_sword: {
    id: "fallen_sword", name: "파멸의 검", line: "holy",
    mana: 120, cooldown: 200,
    damage: 38, range: 18, width: 1.8, wither: 1, witherTicks: 100,
  },
  fallen_shield: {
    id: "fallen_shield", name: "저주의 방패", line: "holy",
    mana: 100, cooldown: 400,
    resistance: 2, duration: 100, reflect: 1.0, witherTicks: 60, // 5초간 받은 피해의 100% 반사
  },
  fallen_curse: {
    id: "fallen_curse", name: "타천의 저주", line: "holy",
    mana: 130, cooldown: 240,
    damage: 10, range: 30, duration: 200,
  },
  fallen_orb: {
    id: "fallen_orb", name: "저주의 구슬", line: "holy",
    mana: 150, cooldown: 200,
    damage: 16, speed: 1.1, range: 35, hitRadius: 1.4, radius: 5, duration: 200,
    maxDistance: 30, vulnerability: 0.35, witherAmp: 2,
  },
  fallen_zone: {
    id: "fallen_zone", name: "저주 영역", line: "holy",
    mana: 300, cooldown: 800,
    damage: 3, radius: 9, duration: 300,
  },
  fallen_end: {
    id: "fallen_end", name: "종말 (궁극기)", line: "holy",
    mana: 800, cooldown: 1200,
    damage: 60, radius: 25, charge: 80, chargeSlowAmp: 0, // charge 동안 종말이 타천을 따라다니며 내부 적을 사슬로 묶음(구속 1)
  },
};

// Use the real player job, including when a borrowed skill supplies another job context.
export function damageForJob(def,jobId){return def.damageByJob?.[jobId]??def.damage;}
```

## RPG_BP_v0597/scripts/data/upgrades.js

```javascript
import {GRADE_MULTIPLIERS,gradeRank} from './grades.js';
export const ARMOR_LEVEL_KEY = 'rpg:armor_upgrade';
export const RUNE_LEVEL_KEY = 'rpg:rune_upgrade';
export const ARMOR_MAX = 10;
export const RUNE_MAX = 10;
export const WEAPON_MAX = 10;
export const WEAPON_LEVEL_KEY = 'rpg:weapon_upgrade';

export function upgradeLevel(item, kind) {
  const key = kind === 'armor' ? ARMOR_LEVEL_KEY : kind === 'weapon' ? WEAPON_LEVEL_KEY : RUNE_LEVEL_KEY;
  const max = kind === 'armor' ? ARMOR_MAX : RUNE_MAX;
  const value = item?.getDynamicProperty(key);
  return Number.isInteger(value) ? Math.max(0, Math.min(max, value)) : 0;
}

export const RUNE_DUST_COSTS=Object.freeze([1,1,2,3,5,5,5,6,6,7]);
// Costs refer to the NEXT level, and are consumed for all completed attempts.
export function upgradeCost(kind, current) {
  const max = ['armor','weapon','rune'].includes(kind) ? 10 : 0;
  if (!Number.isInteger(current) || current < 0 || current >= max) return undefined;
  const next = current + 1;
  return kind !== 'rune'
    ? {gold:200*next*next, stone:2*next, dust:0}
    : {gold:Math.round(2.5*next*next)*5, stone:0, dust:RUNE_DUST_COSTS[current]};
}

export const CATALYST_ID = 'rpg:enhancement_catalyst';
export const MAX_CATALYSTS = 5;
// Rows are success / unchanged failure / downgrade / destruction, in percent.
const ARMOR_RATES = [
  [95,5,0,0], [90,10,0,0], [80,18,2,0], [70,23,7,0], [60,28,10,2],
  [50,30,16,4], [40,32,22,6], [30,34,27,9], [22,35,30,13], [15,35,32,18],
];
// +10 rune curve follows the armor curve; catalysts remain available from +2.
const RUNE_RATES = [[95,5,0,0],[90,10,0,0],[70,28,2,0],[65,28,7,0],...ARMOR_RATES.slice(4)];
export function catalystAllowed(kind,current) {return kind==='armor'||kind==='weapon'?current>=5:kind==='rune'&&current>=2;}
export function enhancementRates(kind,current,catalystCount=0) {
  if (!Number.isInteger(catalystCount)||catalystCount<0||catalystCount>MAX_CATALYSTS) return undefined;
  const row = (kind==='armor'||kind==='weapon'?ARMOR_RATES:kind==='rune'?RUNE_RATES:[])[current];
  if (!row) return undefined;
  let [success,fail,downgrade,destroy] = row;
  if (catalystCount>0) {
    if (!catalystAllowed(kind,current)) return undefined;
    destroy = Math.max(0,destroy-3*catalystCount);
    success = Math.min(success+9*catalystCount,100-downgrade-destroy);
    fail = 100-success-downgrade-destroy;
  }
  return {success,fail,downgrade,destroy};
}
export function rollEnhancement(rates,random=Math.random) {
  const value=random();
  if (!Number.isFinite(value)||value<0||value>=1) throw Error('강화 난수 범위 오류');
  const roll=value*100;
  if (roll<rates.success) return 'success';
  if (roll<rates.success+rates.fail) return 'fail';
  if (roll<rates.success+rates.fail+rates.downgrade) return 'downgrade';
  return 'destroy';
}

export function upgradedRune(rune, level, grade=0) {
  if (!rune) return undefined;
  const rank = Math.max(0, Math.min(RUNE_MAX, Number.isInteger(level) ? level : 0));
  const result = {...rune, wardAmplifier:0, speedAmplifier:0};
  if (rune.physical) result.physical += rank*0.034;
  if (rune.magic) result.magic += rank*0.034;
  if (rune.manaRegenPercent) result.manaRegenPercent = (10+rank*2)/1000;
  if (rune.health) result.health = rune.health+rank*2;
  if (rune.lifesteal) result.lifesteal=(50+rank*7)/1000;
  if (rune.defense) {
    result.health=rank;
    result.defense=rune.defense+rank*2;
  }
  const multiplier=GRADE_MULTIPLIERS[gradeRank(grade)];
  for(const key of ['physical','magic'])if(result[key])result[key]=1+(result[key]-1)*multiplier;
  for(const key of ['health','manaRegen','manaRegenPercent','lifesteal','defense'])if(result[key])result[key]*=multiplier;
  return result;
}
```

## RPG_BP_v0597/scripts/gameplayEntry.js

```javascript
// RPG gameplay module - independent from slash-command registration pack.
import * as mc from "@minecraft/server";
import { initializeGameplay } from "./main.js";
let started = false;
function safeStart() {
  if (started) return;
  started = true;
  try { initializeGameplay(); }
  catch (e) { console.error("[RPG v0.6.0 gameplay] initialization failed: " + String(e?.stack ?? e)); }
}
try { mc.system.run(safeStart); }
catch (e) { console.error("[RPG v0.6.0 gameplay] schedule failed: " + String(e)); }
try {
  mc.world.afterEvents.worldLoad.subscribe(() => {
    if (!started) mc.system.run(safeStart);
  });
} catch (e) { console.warn("[RPG v0.6.0 gameplay] worldLoad recovery unavailable: " + String(e)); }

// Hydra: guard against any existing burning visual effects after pack upgrade.
// Fire immunity is configured in entities/hydra_boss.json.
try {
  mc.system.runInterval(() => {
    for (const id of ["overworld", "nether", "the_end"]) {
      try {
        const dim = mc.world.getDimension(id);
        for (const hydra of dim.getEntities({ type: "rpg:hydra_boss" })) {
          try {
            if (hydra.getComponent("minecraft:onfire")) hydra.extinguishFire(false);
          } catch (_) { /* invalid or unloaded entity */ }
        }
      } catch (_) { /* unloaded or inaccessible dimension */ }
    }
  }, 10);
} catch (e) { console.warn("[RPG] hydra fire cleanup unavailable: " + String(e)); }
```

## RPG_BP_v0597/scripts/main.js

```javascript
import {registerWardDefense} from './core/wardDefense.js';
import {registerTheWorld} from './skills/theWorld.js';
import {registerTheWorldStand} from './core/theWorldStand.js';
import {registerTpa} from './core/tpa.js';
import {registerPvpArena} from './core/pvpArena.js';
import {restoreFullHealth} from './core/healthRecovery.js';
import {registerPeaceZones} from './core/peaceZones.js';
import {registerXpShop} from './core/xpShop.js';
import {registerStatusTablet} from './core/statusTablet.js';
import {registerNightMobs} from './core/nightMobs.js';
import {registerHuntingZones} from './core/huntingZones.js';
import {registerPeaceServer} from './core/peaceServer.js';
import {registerPvp} from './core/pvp.js';
import {registerRarityLabels} from './core/rarityLabels.js';
import {registerBossMotion} from './core/bossMotion.js';
import {registerGptNpc} from './core/gptNpc.js';
import {registerTemples} from './core/temples.js';
import {registerProgressionItems} from './core/progressionItems.js';
import {registerHolyRecovery} from './core/holyRecovery.js';
import {registerAngelHealing} from './core/angelHealing.js';
import {registerCombatContributions} from './core/combatContribution.js';
import {registerLifesteal} from './core/lifesteal.js';
import {registerWarGod} from './skills/warGod.js';
import {registerDungeons} from './core/dungeons.js';
import { world, system } from "@minecraft/server";
import { CONFIG } from "./config.js";
import { JOBS, findJob } from "./data/jobs.js";
import { SKILLS } from "./data/skills.js";
import {
  getJobId, setJobId, setSkills, getSkills, getMana, setMana, maxManaOf, getProgress,
  clearPlayerRuntime, getDisabled,
} from "./core/playerData.js";
import {
  requestAdvance, ensureWeapon, resetToApprentice, giveStarter, requirementStatus,
} from "./core/advance.js";
import { registerInput, handleFriendlyHit } from "./core/input.js";
import { registerTracking } from "./core/tracking.js";
import { registerHoly } from "./skills/holy.js";
import { registerFist } from "./skills/fist.js";
import { registerFistCoating } from "./core/fistCoating.js";
import { registerArcher } from "./skills/archer.js";
import { registerNecromancer } from "./skills/necro.js";
import { registerDarkMagic } from "./skills/dark.js";
import { registerSandbag } from "./core/sandbag.js";
import { registerWings } from "./core/wings.js";
import { registerFrenzy } from "./core/frenzy.js";
import { registerBerserker } from "./skills/berserker.js";
import { registerBloodMagic } from "./skills/blood.js";
import { registerHacker } from "./skills/hacker.js";
import { registerHarpoon } from "./skills/harpoon.js";
import { registerFrost } from "./skills/frost.js";
import { registerFire } from "./skills/fire.js";
import { registerAssassin } from "./skills/assassin.js";
import { registerTechnomancer } from "./skills/technomancer.js";
import { registerDemon } from "./skills/demon.js";
import { registerCelestial } from "./skills/celestial.js";
import { registerHito } from "./core/hito.js";
import { registerSwordFlameSpin } from "./skills/swordFlameSpin.js";
import { registerDragon } from "./skills/dragon.js";

import { registerSocial } from "./core/social.js";
import { registerFriendlyFire } from "./core/friendlyFire.js";
import { registerGolemBoss } from "./core/golemBoss.js";
import { registerCyclopsBoss } from "./core/cyclopsBoss.js";
import { runRpgAction } from "./core/rpgActions.js";
import { setCommandHandler, setGameplayStatus } from "./core/commandBridge.js";
import { startHud } from "./core/hud.js";
import { registerRpgStats, applyVitality } from "./core/stats.js";
import { registerBeginnerGuide, recordBeginnerKill } from './core/beginner.js';
import { getEquipmentBonuses, registerEquipment } from './core/equipment.js';
import { registerRuneDrops } from './core/runeDrops.js';
import {registerMonsterLevels} from './core/monsterLevels.js';
import { registerJobQuests } from './core/jobQuests.js';
import { registerNewTrials } from './core/newTrials.js';

// 처음 들어온 플레이어는 견습으로 시작
function initPlayer(player) {
  if (getJobId(player)) return;
  setJobId(player, "apprentice");
  setSkills(player, []);
  setMana(player, maxManaOf(player));
}

// Start gameplay from the same static ES module graph as command registration.
// Each feature is isolated so a single faulty handler does not disable commands.
let gameplayInitialized = false;
export function initializeGameplay() {
  if (gameplayInitialized) return { state: "ready", errors: [] };
  gameplayInitialized = true;
  const errors = [];
  const safe = (name, fn) => {
    try { fn(); }
    catch (error) {
      const info = name + ": " + String(error?.stack ?? error);
      errors.push(info);
      console.warn("[rpg/gameplay] " + info);
    }
  };

  // Link the command bridge even if a nonessential skill system fails.
  setCommandHandler(runRpgAction);
  safe('hunting zones',registerHuntingZones);
  safe('monster levels',registerMonsterLevels);
  safe('peace server',registerPeaceServer);
  safe('peace zones',registerPeaceZones);
  safe('ward rune defense',registerWardDefense);
  safe('The World',registerTheWorld);
  safe('The World stand',registerTheWorldStand);
  safe('TPA',registerTpa);
  safe('PvP arena',registerPvpArena);
  safe('PvP and PK',registerPvp);
  safe('XP shop and potion',registerXpShop);
  safe('status tablet',()=>registerStatusTablet(runRpgAction));
  safe('night mobs',registerNightMobs);
  safe('celestial temple',registerTemples);
  safe('GPT guide NPC',registerGptNpc);
  safe('item rarity labels',registerRarityLabels);
  safe('boss motions',registerBossMotion);
  safe("playerSpawn", () => world.afterEvents.playerSpawn.subscribe((ev) => {
    const p = ev.player;
    system.runTimeout(() => {
      try {
        initPlayer(p);
        ensureWeapon(p);
        applyVitality(p);
        if(!ev.initialSpawn){restoreFullHealth(p);system.runTimeout(()=>{try{restoreFullHealth(p);}catch{}},2);}
      } catch { /* player unavailable */ }
    }, 20);
  }));
  safe("playerLeave", () => world.afterEvents.playerLeave.subscribe((ev) => clearPlayerRuntime(ev.playerId)));
  safe("manaRegen", () => system.runInterval(() => {
    for (const p of world.getAllPlayers()) {
      try {
        initPlayer(p);
        const max = maxManaOf(p);
        const mana = getMana(p);
        if (mana < max) {const gear=getEquipmentBonuses(p);setMana(p,mana+Math.max(1,max*CONFIG.mana.regenRate)+gear.manaRegen+max*gear.manaRegenPercent);}
        ensureWeapon(p);
      } catch { /* player not ready */ }
    }
  }, 20));

  const features = [
    ["rune lifesteal",()=>registerLifesteal()],
    ["war god",()=>registerWarGod()],
    ["combat contribution", () => registerCombatContributions()],
    ["holy recovery", () => registerHolyRecovery()],
    ["angel healing rewards", () => registerAngelHealing()],
    ["progression items", () => registerProgressionItems()],
    ["RPG stats", () => registerRpgStats(recordBeginnerKill)],
    ["beginner guide", () => registerBeginnerGuide()],
    ['RPG equipment', () => registerEquipment()],
    ['vanilla rune drops', () => registerRuneDrops()],
    ['job quests', () => registerJobQuests()],
    ['new job trials', () => registerNewTrials()],
    ['party dungeons', () => registerDungeons()],
    ["social", () => registerSocial()],
    ["friendly fire", () => registerFriendlyFire(handleFriendlyHit)],
    ["golem boss", () => registerGolemBoss()],
    ["cyclops boss", () => registerCyclopsBoss()],
    ["input", () => registerInput()],
    ["작골염양 점프 감지", () => registerSwordFlameSpin()],
    ["tracking", () => registerTracking()],
    ["holy", () => registerHoly()],
    ["fist", () => registerFist()],
    ["fist coating", () => registerFistCoating()],
    ["archer", () => registerArcher()],
    ["necromancer", () => registerNecromancer()],
    ["dark magic", () => registerDarkMagic()],
    ["sandbag", () => registerSandbag()],
    ["wings", () => registerWings()],
    ["frenzy", () => registerFrenzy()],
    ["berserker", () => registerBerserker()],
    ["blood magic", () => registerBloodMagic()],
    ["hacker", () => registerHacker()],
    ["harpoon", () => registerHarpoon()],
    ["frost", () => registerFrost()],
    ["fire", () => registerFire()],
    ["assassin", () => registerAssassin()],
    ["technomancer", () => registerTechnomancer()],
    ["demon", () => registerDemon()],
    ["celestial", () => registerCelestial()],
    ["dragon knight", () => registerDragon()],
    ["job NPC / hito", () => registerHito()],
    ["HUD", () => startHud()],
  ];
  for (const [name, start] of features) safe(name, start);

  safe("script events", () => system.afterEvents.scriptEventReceive.subscribe((ev) => {
    if (!ev.id.startsWith("rpg:") || ["rpg:ping", "rpg:diag"].includes(ev.id)) return;
    const p = ev.sourceEntity;
    if (!p || p.typeId !== "minecraft:player") return;
    try { runRpgAction(ev.id.slice(4), p, ev.message); }
    catch (error) { console.warn("[rpg/script-event] " + String(error)); }
  }));
  setGameplayStatus(errors.length ? "partial" : "ready", errors);
  console.warn("[rpg/gameplay] initialized; errors=" + errors.length);
  return { state: errors.length ? "partial" : "ready", errors };
}
```

## RPG_BP_v0597/scripts/skills/blood.js

```javascript
import {SKILLS} from '../data/skills.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import { areAllies } from "../core/social.js";
import { world, system, ItemStack, EquipmentSlot } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { getJobId, getSkills } from "../core/playerData.js";
import { getTargets, hurt as hurtBase, particle, sound, headPos, norm3, dist3, isSolidAt, firstTargetInView } from "../core/util.js";
import { notify } from "../core/hud.js";

const BLOOD = "rpg:blood_spark";
const SIGIL = "rpg:blood_sigil";
const BURST = "rpg:blood_burst";
const SPEAR = "rpg:blood_spear";
const bursts = new Map();
const spearNativeReplaced=new Map();
const spearKey=(p,t)=>p.id+":"+t.id;
export function isBloodSpearHit(ev){try{return ev.damageSource?.cause==='entityAttack' && ev.damageSource?.damagingEntity?.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand)?.typeId===SPEAR;}catch{return false;}}
export function replaceBloodSpearHit(ev){
 if(!isBloodSpearHit(ev))return false;const p=ev.damageSource.damagingEntity,t=ev.hurtEntity;
 const eq=p.getComponent('minecraft:equippable'),weapon=eq?.getEquipment(EquipmentSlot.Mainhand);
 if(Number(weapon?.getDynamicProperty('rpg:spear_hits')??0)>=SKILLS.blood_spear.durability){const h=t.getComponent('minecraft:health');if(h?.currentValue>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));eq?.setEquipment(EquipmentSlot.Mainhand,undefined);return true;}
 if(!enemy(p,t))return true;
 for(const [key,tick]of spearNativeReplaced)if(tick<system.currentTick-2)spearNativeReplaced.delete(key);
 spearNativeReplaced.set(spearKey(p,t),system.currentTick);
 const hp=t.getComponent('minecraft:health');if(hp?.currentValue>0)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+ev.damage));
 hurtBase(t,p,SKILLS.blood_spear.damage,'magic',{strengthIncluded:true,ignoreInvulnerability:true});return true;
}

const pinned = new Map();
let installed = false;

function valid(e) { try {return !!e?.isValid && (e.getComponent('minecraft:health')?.currentValue ?? 0)>0;}catch{return false;} }
function enemy(p,e){return valid(e) && e.id!==p.id && !areAllies(p,e) && (e.typeId!=="minecraft:player" || CONFIG.pvp);}
function pos(p,y=1){let a=p.location; return {x:a.x,y:a.y+y,z:a.z};}
function emit(dim,location,id=BLOOD,n=1){for(let i=0;i<n;i++)particle(dim,id,{x:location.x+(i%3-1)*0.10,y:location.y+((i*3)%5)*0.09,z:location.z+(i%5-2)*0.10});}
function trace(dim,a,b,id=BLOOD,step=.6){const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z; const total=Math.hypot(dx,dy,dz);for(let k=0;k<=Math.min(64,Math.ceil(total/step));k++){let t=k/Math.max(1,Math.ceil(total/step));particle(dim,id,{x:a.x+dx*t,y:a.y+dy*t,z:a.z+dz*t});}}
function shot(player,dir,range,velocity,hitRadius,onImpact,fx=BLOOD){
  const dim=player.dimension,source=headPos(player),from={x:source.x+dir.x*.75,y:source.y+dir.y*.75,z:source.z+dir.z*.75};
  let travel=0;
  const ticker=system.runInterval(()=>{
    try{
      if(!player.isValid || travel>=range){system.clearRun(ticker);return;}
      for(let sub=0;sub<3;sub++){
        travel+=velocity/3;
        const pt={x:from.x+dir.x*travel,y:from.y+dir.y*travel,z:from.z+dir.z*travel};
        if(isSolidAt(dim,pt)){emit(dim,pt,SIGIL,4);system.clearRun(ticker);return;}
        if(sub===0 || sub===2) particle(dim,fx,pt);
        const targets=getTargets(player,pt,hitRadius,.8).filter(e=>enemy(player,e));
        if(targets.length){onImpact(targets[0],pt);emit(dim,pt,SIGIL,8);system.clearRun(ticker);return;}
      }
    }catch{system.clearRun(ticker);}
  },1);
}

function spear(player,job,def){
  try{
    const item=new ItemStack(SPEAR,1);
    item.setDynamicProperty("rpg:spear_hits",0);
    item.setLore(["§c피의 창§r", "§7사용: 6칸 찌르기 · 마법 피해 14 · 시듦 I 3초", "§7남은 사용 횟수: 5/5"]);
    const container=player.getComponent('minecraft:inventory')?.container;
    if(!container)return false;
    const leftover=container.addItem(item);
    if(leftover)player.dimension.spawnItem(leftover,pos(player,.5));
    emit(player.dimension,pos(player,1),SIGIL,12);
    notify(player,"§c피의 창 생성! §7사용하면 6칸 찌르기 · 5회 공격 가능합니다.");
    sound(player.dimension,'mob.blaze.shoot',player.location,{volume:.65,pitch:.65});
    return true;
  }catch{return false;}
}
function orb(player,job,def){
  const d=norm3(player.getViewDirection());
  shot(player,d,def.range,def.speed,1.5,(target,point)=>{
    hurt(target,player,def.damage);
    const list=getTargets(player,point,def.burstRadius,.7).filter(e=>enemy(player,e)&&e.id!==target.id);
    for(const e of list)hurt(e,player,def.splashDamage);
    for(let j=0;j<12;j++){
      const a=j*Math.PI*2/12;
      particle(player.dimension,BURST,{x:point.x+Math.cos(a)*0.8,y:point.y+0.1,z:point.z+Math.sin(a)*0.8});
    }
    emit(player.dimension,point,SIGIL,4);
    sound(player.dimension,'random.explode',point,{volume:.8,pitch:.5});
  },SIGIL);
  emit(player.dimension,pos(player,1.2),BURST,3);
  sound(player.dimension,'mob.blaze.shoot',player.location,{volume:1,pitch:.45});return true;
}
function supernova(player,job,def){
 const dim=player.dimension,v=norm3(player.getViewDirection()),base=headPos(player);
 let center={...base};
 for(let t=.5;t<=def.forward;t+=.5){const point={x:base.x+v.x*t,y:base.y+v.y*t,z:base.z+v.z*t};if(isSolidAt(dim,point))break;center=point;}
 // A short-lived blood sphere detonates at its summoned position.
 let elapsed=0;const timer=system.runInterval(()=>{try{
  if(!valid(player)||player.dimension.id!==dim.id){system.clearRun(timer);return;}
  emit(dim,center,SIGIL,12);elapsed+=3;
  if(elapsed<def.detonateTicks)return;system.clearRun(timer);
  for(const e of getTargets(player,center,def.burstRadius).filter(e=>enemy(player,e)))hurt(e,player,def.damage);
  emit(dim,center,BURST,24);sound(dim,'random.explode',center,{volume:1,pitch:.6});
 }catch{system.clearRun(timer);}},3);return true;
}
function bloodMark(player,job,def){
  const target=firstTargetInView(player,def.range);
  if(target && enemy(player,target) && dist3(player.location,target.location)<=def.meleeRange){
    trace(player.dimension,pos(player,1.25),pos(target,1.0),SIGIL,.25);
    emit(player.dimension,pos(target,1.0),BURST,5);
    hurt(target,player,def.meleeDamage,"physical");
    sound(player.dimension,'random.anvil_land',target.location,{volume:.35,pitch:1.7});
    notify(player,'§c혈인: 근거리 혈검');return true;
  }
  const dir=norm3(player.getViewDirection());
  shot(player,dir,def.range,1.45,1.45,(e,hit)=>{
    hurt(e,player,def.rangedDamage);
    for(let j=0;j<16;j++){
      const a=j*Math.PI*2/16;
      particle(player.dimension,SIGIL,{x:hit.x+Math.cos(a)*1.25,y:hit.y+Math.sin(a)*0.15,z:hit.z+Math.sin(a)*0.15});
      if(j%2===0) particle(player.dimension,BURST,{x:hit.x+Math.cos(a)*0.9,y:hit.y,z:hit.z+Math.sin(a)*0.9});
    }
    emit(player.dimension,hit,BLOOD,6);
  },BURST);
  sound(player.dimension,'mob.blaze.shoot',player.location,{volume:.5,pitch:1.6});
  notify(player,'§c혈인: 원거리 혈원반');return true;
}
export function bloodAwakenIsActive(p){return bursts.has(p.id);}
export function bloodAwakenStop(p){
  if(!bursts.delete(p.id))return false;
  for(const effect of ['strength','resistance','hunger','wither'])try{p.removeEffect(effect);}catch{}
  notify(p,'§7혁린약동•재 해제');return true;
}
function awaken(player,job,def){
  if(bursts.has(player.id)){bloodAwakenStop(player);return false;}
  bursts.set(player.id,{start:system.currentTick,def});
  applyStatus(player,'regeneration',1200,{amplifier:1,showParticles:false});
  notify(player,'§c혁린약동•재 활성화! §7다시 사용하면 해제합니다.');
  return true;
}
function bloodBind(player,job,def){
  const dim=player.dimension, targets=getTargets(player,player.location,def.radius).filter(e=>enemy(player,e));
  let total=0,drained=0;
  for(const e of targets){
    const before=e.getComponent('minecraft:health')?.currentValue??0;
    hurt(e,player,def.damage);
    const after=e.getComponent('minecraft:health')?.currentValue??0;
    drained+=Math.min(before,Math.max(0,before-after));
    const anchor={...e.location};
    pinned.set(e.id,{entity:e,owner:player,anchor,until:system.currentTick+ccTicks(e,def.duration),dimensionId:dim.id});
    try{applyStatus(e,'slowness',def.duration,{amplifier:255,showParticles:true});}catch{}
    for(let j=0;j<14;j++){
      const angle=j*Math.PI*2/14;
      particle(dim,SIGIL,{x:anchor.x+Math.cos(angle)*.7,y:anchor.y+.5+(j%3)*.4,z:anchor.z+Math.sin(angle)*.7});
    }
    total++;
  }
  if(!total){notify(player,'§716블럭 안에 묶을 대상이 없습니다.');return false;}
  const hp=player.getComponent('minecraft:health');if(hp?.currentValue>0)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+Math.min(def.healCap,drained)));
  sound(dim,'mob.endermen.portal',player.location,{volume:.8,pitch:.6});
  notify(player,`§c적박: §f${total}마리 5초 결박 · 최대 6하트 흡혈`);return true;
}
// Blood whips sweep around the caster for three seconds. Each enemy is hit once.
const tentacles=new Map();
export function bloodTentacle(p,job,def){
 if(tentacles.has(p.id))return false;
 const session={player:p,dimension:p.dimension.id,start:system.currentTick,until:system.currentTick+def.duration,hit:new Set(),def};
 tentacles.set(p.id,session);sound(p.dimension,'mob.slime.attack',p.location,{volume:.9,pitch:.6});return true;
}
export function tickBloodTentacles(){
 for(const [id,s]of tentacles){
  const p=s.player;if(!valid(p)||p.dimension.id!==s.dimension||system.currentTick>=s.until||(getJobId(p)!=='blood_mage'&&!(getJobId(p)==='chameleon'&&getSkills(p).includes('blood_tentacle')))){tentacles.delete(id);continue;}
  const spin=(system.currentTick-s.start)/s.def.duration*Math.PI*2,origin={x:p.location.x,y:p.location.y+1,z:p.location.z};
  for(let arm=0;arm<4;arm++){
   const angle=spin+arm*Math.PI/2;
   for(let step=1;step<=12;step++){const radius=step*s.def.radius/12,curve=Math.sin(step*.65-spin*2)*.12,at={x:origin.x+Math.cos(angle+curve)*radius,y:origin.y+Math.sin(step*.55+spin)*.5,z:origin.z+Math.sin(angle+curve)*radius};if(isSolidAt(p.dimension,at))break;particle(p.dimension,'rpg:blood_tentacle_whip',at);}
  }
  for(const e of getTargets(p,p.location,s.def.radius).filter(e=>enemy(p,e))){
   if(s.hit.has(e.id))continue;
   const dx=e.location.x-p.location.x,dz=e.location.z-p.location.z,angle=Math.atan2(dz,dx);
   let touching=Math.hypot(dx,dz)<=2;
   for(let arm=0;arm<4&&!touching;arm++){const diff=angle-(spin+arm*Math.PI/2);touching=Math.abs(Math.atan2(Math.sin(diff),Math.cos(diff)))<.4;}
   if(!touching)continue;
   const target=pos(e,.8),distance=Math.hypot(target.x-origin.x,target.y-origin.y,target.z-origin.z);
   let blocked=false;for(let t=1;t<distance;t++){const scale=t/distance;if(isSolidAt(p.dimension,{x:origin.x+(target.x-origin.x)*scale,y:origin.y+(target.y-origin.y)*scale,z:origin.z+(target.z-origin.z)*scale})){blocked=true;break;}}
   if(blocked)continue;
   if(hurt(e,p,s.def.damage,'magic')){s.hit.add(e.id);emit(p.dimension,target,BURST,5);}
  }
 }
}
export const RUNNERS={
  blood_spear:spear,
  blood_tentacle:bloodTentacle,
  blood_orb:orb,
  blood_supernova:supernova,
  blood_mark:bloodMark,
  blood_awaken:awaken,
  blood_bind:bloodBind,
};

const reachTicks=new Map();
export function useBloodSpear(p){
 if((reachTicks.get(p.id)??-100)>system.currentTick-10)return;
 const eq=p.getComponent('minecraft:equippable'),weapon=eq?.getEquipment(EquipmentSlot.Mainhand);
 if(weapon?.typeId!==SPEAR)return;
 if(Number(weapon.getDynamicProperty('rpg:spear_hits')??0)>=SKILLS.blood_spear.durability){eq.setEquipment(EquipmentSlot.Mainhand,undefined);return;}
 const target=firstTargetInView(p,SKILLS.blood_spear.range);if(!target||!enemy(p,target))return;
 reachTicks.set(p.id,system.currentTick);
 if(!hurtBase(target,p,SKILLS.blood_spear.damage,'magic',{strengthIncluded:true,ignoreInvulnerability:true}))return;
 applyStatus(target,'wither',60,{amplifier:0,showParticles:true});trace(p.dimension,headPos(p),pos(target),SIGIL,.3);
 const hits=Number(weapon.getDynamicProperty('rpg:spear_hits')??0)+1;
 if(hits>=SKILLS.blood_spear.durability)eq.setEquipment(EquipmentSlot.Mainhand,undefined);
 else{weapon.setDynamicProperty('rpg:spear_hits',hits);const durability=weapon.getComponent('minecraft:durability');if(durability)durability.damage=Math.min(hits,4);weapon.setLore(['§c피의 창§r','§7사용: 6칸 찌르기 · 마법 피해 14',`§7남은 사용 횟수: ${Math.max(0,SKILLS.blood_spear.durability-hits)}/5`]);eq.setEquipment(EquipmentSlot.Mainhand,weapon);}
}
system.beforeEvents.startup.subscribe(e=>{try{e.itemComponentRegistry.registerCustomComponent('rpg:blood_spear_reach',{onUse(ev){system.run(()=>useBloodSpear(ev.source));}});}catch(error){console.warn('[RPG blood reach] '+error);}});
export function registerBloodMagic(){
  if(installed)return;installed=true;
  system.runInterval(tickBloodTentacles,3);
  world.afterEvents.entityHitEntity.subscribe(event=>{
    const p=event.damagingEntity;
    if(p?.typeId!=='minecraft:player'||!event.hitEntity)return;
    try{
      const eq=p.getComponent('minecraft:equippable');
      const weapon=eq?.getEquipment(EquipmentSlot.Mainhand);
      if(weapon?.typeId!==SPEAR)return;
 if(Number(weapon.getDynamicProperty('rpg:spear_hits')??0)>=SKILLS.blood_spear.durability){eq.setEquipment(EquipmentSlot.Mainhand,undefined);return;}
      if(enemy(p,event.hitEntity)){
        const key=spearKey(p,event.hitEntity),nativeTick=spearNativeReplaced.get(key);spearNativeReplaced.delete(key);
        // Rejected vanilla hits still emit entityHitEntity: explicitly bypass immunity.
        if(nativeTick!==system.currentTick)hurtBase(event.hitEntity,p,SKILLS.blood_spear.damage,'magic',{strengthIncluded:true,ignoreInvulnerability:true});
        applyStatus(event.hitEntity,'wither',60,{amplifier:0,showParticles:true});
      }
      const hits=Number(weapon.getDynamicProperty('rpg:spear_hits')??0)+1;
      if(hits>=SKILLS.blood_spear.durability){eq.setEquipment(EquipmentSlot.Mainhand,undefined);notify(p,'§7피의 창이 소멸했습니다.');}
      else{
        weapon.setDynamicProperty('rpg:spear_hits',hits);
        const d=weapon.getComponent('minecraft:durability');
        if(d)d.damage=Math.min(hits,4);
        weapon.setLore(['§c피의 창§r','§7기본 마법 피해 14 · 시듦 I 3초',`§7남은 사용 횟수: ${Math.max(0,SKILLS.blood_spear.durability-hits)}/5`]);
        eq.setEquipment(EquipmentSlot.Mainhand,weapon);
      }
    }catch{}
  });
  system.runInterval(()=>{
    const now=system.currentTick;
    for(const [id,s] of bursts){
      const p=world.getAllPlayers().find(x=>x.id===id);
      if(!p || (getJobId(p)!=='blood_mage' && !(getJobId(p)==='chameleon' && getSkills(p).includes('blood_awaken')))){bursts.delete(id);continue;}
      try{
        for(const [name,level] of [['strength',2],['resistance',2],['hunger',2]])applyStatus(p,name,35,{amplifier:level,showParticles:false});
        if(now-s.start>=s.def.warningTicks){applyStatus(p,'wither',35,{amplifier:4,showParticles:false});}
      }catch{bursts.delete(id);}
    }
    for(const [id,s] of pinned){
      if(now>=s.until || !valid(s.entity) || areAllies(s.owner,s.entity)){
        if(areAllies(s.owner,s.entity)) try{s.entity.removeEffect('slowness');}catch{}
        pinned.delete(id);continue;
      }
      try{
        if(s.entity.dimension.id!==s.dimensionId){pinned.delete(id);continue;}
        const here=s.entity.location;
        if(dist3(here,s.anchor)>.35)s.entity.teleport(s.anchor,{dimension:s.entity.dimension,keepVelocity:false});
        if(now%10===0)emit(s.entity.dimension,pos(s.entity,1),SIGIL,4);
      }catch{pinned.delete(id);}
    }
  },5);
  world.afterEvents.playerLeave.subscribe(ev=>{bursts.delete(ev.playerId);reachTicks.delete(ev.playerId);tentacles.delete(ev.playerId);});
  world.afterEvents.entityDie.subscribe(ev=>{if(ev.deadEntity?.typeId==='minecraft:player')bursts.delete(ev.deadEntity.id);});
}

// Borrowed spells use MAG just like their original spell class.
function hurt(target,source,amount,type="magic"){return hurtBase(target,source,amount,type);}
```

## RPG_BP_v0597/scripts/skills/theWorld.js

```javascript
import {scriptedMeleeRuneFactor} from '../core/runeMelee.js';
import {duelOf} from '../core/pvp.js';
import {world,system,InputPermissionCategory,EntityDamageCause} from '@minecraft/server';
import {attack as martialAttack} from './warGod.js';
import {SKILLS} from '../data/skills.js';
import {getJobId} from '../core/playerData.js';
import {getTargets,flatDir,isSolidAt,knockback,heldItemId,hurt} from '../core/util.js';
import {areAllies} from '../core/social.js';
import {isBoss} from '../core/crowdControl.js';
import {scriptedHit,setCombatHealth,noteManualDamage} from '../core/combatContext.js';
import {registerStoppedTarget,takeStoppedDamage,isTimeFrozen} from '../core/timeStopDamage.js';
export {isTimeFrozen};
const MARK='rpg:the_world_freeze_v1',TAG='rpg_the_world_frozen',WEAK='rpg:the_world_native_guard',HIGH='rpg:the_world_high_until',BLOOD='rpg:the_world_blood_until';
const sessions=new Map(),frames=new Map(),basics=new Map();let registered=false;
const valid=e=>{try{return Boolean(e?.isValid);}catch{return false;}};
const living=e=>valid(e)&&(e.getComponent('minecraft:health')?.currentValue??0)>0;
const effectData=(e,name)=>{const f=e.getEffect(name);return f?{duration:f.duration,amplifier:f.amplifier}:null;};
function enemy(p,e){return valid(e)&&p.id!==e.id&&e.typeId!=='rpg:the_world_stand'&&!areAllies(p,e)&&!e.typeId.startsWith('rpg:hito_')&&e.typeId!=='rpg:gpt_guide'&&(e.typeId!=='minecraft:player'||!['creative','spectator'].includes(String(e.getGameMode?.()).toLowerCase()));}
export function restoreFrozenEntity(e){
 const raw=e.getDynamicProperty(MARK);if(raw===undefined){try{e.removeTag(TAG);}catch{}return true;}
 let saved;try{saved=JSON.parse(raw);}catch{console.warn('[The World] corrupt recovery marker');return false;}
 let okay=true;const elapsed=Math.max(0,Math.floor((Date.now()-saved.at)/50));
 for(const name of ['slowness','weakness'])try{e.removeEffect(name);const old=saved.effects[name];if(old&&old.duration>elapsed)e.addEffect(name,old.duration-elapsed,{amplifier:old.amplifier,showParticles:false});}catch{okay=false;}
 if(e.typeId==='minecraft:player')for(const [category,enabled]of saved.permissions??[])try{e.inputPermissions.setPermissionCategory(category,enabled);}catch{okay=false;}
 try{e.clearVelocity();const projectile=e.getComponent('minecraft:projectile');if(projectile)projectile.shoot(saved.velocity);else e.applyImpulse(saved.velocity);}catch{okay=false;}
 if(okay){e.setDynamicProperty(MARK,undefined);e.removeTag(TAG);}return okay;
}
function sharedGuild(a,b){try{return a?.typeId==='minecraft:player'&&b?.typeId==='minecraft:player'&&a.getTags().some(t=>t.startsWith('rpg_guild_')&&b.hasTag(t));}catch{return false;}}
function freeze(p,e,session){
 const base=session.duration??SKILLS.world_stop.duration;
 if(frames.has(e.id)||!enemy(p,e)||sharedGuild(p,e))return false;
 const projectile=e.getComponent('minecraft:projectile');
 if(projectile?.owner&&(projectile.owner.id===p.id||areAllies(p,projectile.owner)||sharedGuild(p,projectile.owner)))return false;
 if(!projectile&&!living(e))return false;
 if(e.getDynamicProperty(MARK)!==undefined&&!restoreFrozenEntity(e))return false;
 const saved={at:Date.now(),effects:{slowness:effectData(e,'slowness'),weakness:effectData(e,'weakness')},velocity:e.getVelocity(),permissions:[]};
 if(e.typeId==='minecraft:player')try{for(const category of [...new Set([InputPermissionCategory.Movement,InputPermissionCategory.Camera,...Object.values(InputPermissionCategory).filter(v=>typeof v==='number')])])saved.permissions.push([category,e.inputPermissions.isPermissionCategoryEnabled(category)]);}catch{saved.permissions=[];}
 e.setDynamicProperty(MARK,JSON.stringify(saved));e.addTag(TAG);e.clearVelocity();
 let mode='position';
 if(saved.permissions.length>=2)try{for(const category of [InputPermissionCategory.Movement,InputPermissionCategory.Camera])e.inputPermissions.setPermissionCategory(category,false);mode='inputPermissions';}catch{mode='position';}
 const duration=Math.ceil(base*(isBoss(e)?.5:1));
 if(!projectile){e.addEffect('slowness',duration,{amplifier:255,showParticles:false});e.addEffect('weakness',duration,{amplifier:255,showParticles:false});}
 frames.set(e.id,{entity:e,owner:p,location:{...e.location},rotation:e.getRotation(),dimension:e.dimension.id,until:system.currentTick+duration,duel:duelOf(p),mode});session.ids.add(e.id);registerStoppedTarget(e,p);return true;
}
function releaseFrame(id,applyDamage=true){
 const f=frames.get(id);frames.delete(id);const deferred=takeStoppedDamage(id);if(!f)return;
 try{if(valid(f.entity))restoreFrozenEntity(f.entity);}catch(error){console.warn('[The World restore] '+error);}
 if(!applyDamage||!deferred?.damage||!living(f.entity)||!living(f.owner)||areAllies(f.owner,f.entity)||(f.duel&&(f.duel.finished||duelOf(f.owner)!==f.duel||duelOf(f.entity)!==f.duel)))return;
 const target=f.entity,source=f.owner,amount=deferred.damage;
 scriptedHit(target,source,()=>{try{if(target.applyDamage(amount,{cause:EntityDamageCause.override,damagingEntity:source})!==false)return true;}catch{}
  const hp=target.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return false;const before=hp.currentValue;setCombatHealth(target,source,hp,Math.max(0,before-amount));noteManualDamage(source,target,Math.min(before,amount));return true;});
}
function restoreWorldGuard(id,session){
 try{const pl=world.getAllPlayers().find(x=>x.id===id);if(!pl||!valid(pl)||!session.guard)return;
  pl.removeEffect('resistance');const prev=session.guard.prev;
  if(prev){const left=prev.endTick-system.currentTick;if(left>0)pl.addEffect('resistance',left,{amplifier:prev.amplifier,showParticles:false});}
 }catch{}
}
export function stopTheWorld(p,applyDamage=true){const session=sessions.get(p.id);if(!session)return false;sessions.delete(p.id);restoreWorldGuard(p.id,session);for(const id of session.ids)releaseFrame(id,applyDamage);return true;}
export function startTheWorld(p){
 if(sessions.has(p.id))return false;
 let duration=SKILLS.world_stop.duration,extended=false;
 try{if(Number(p.getDynamicProperty(BLOOD)??0)>Date.now()){duration=SKILLS.world_stop.bloodDuration;extended=true;}p.setDynamicProperty(BLOOD,undefined);}catch{}
 const session={ids:new Set(),dimension:p.dimension.id,duration,until:system.currentTick+duration};sessions.set(p.id,session);
 // 시간 정지 중 시전자는 어떤 적의 공격도 받지 않음(저항 V = 피해 100% 감소). 기존 저항 효과는 종료 후 복원.
 try{const old=p.getEffect('resistance');session.guard={prev:old?{amplifier:old.amplifier,endTick:system.currentTick+old.duration}:null};p.addEffect('resistance',duration+10,{amplifier:4,showParticles:false});}catch(error){console.warn('[The World guard] '+error);}
 try{for(const e of p.dimension.getEntities({location:p.location,maxDistance:SKILLS.world_stop.radius})){if(session.ids.size>=60)break;try{freeze(p,e,session);}catch(error){try{restoreFrozenEntity(e);}catch{}console.warn('[The World freeze] '+error);}}}
 catch(error){stopTheWorld(p,false);throw error;}
 p.sendMessage(extended?'§6더 월드! §c흡혈의 힘으로 §e9초§7간 시간이 멈춥니다.':'§6더 월드! §7시간이 멈췄습니다.');return true;
}
export function tickTheWorld(){
 for(const [id,s]of sessions){const p=world.getAllPlayers().find(p=>p.id===id);if(!living(p)||p.dimension.id!==s.dimension||system.currentTick>=s.until||getJobId(p)!=='the_world'){stopTheWorld(p??{id},living(p)&&p.dimension.id===s.dimension&&getJobId(p)==='the_world');continue;}}
 for(const [id,f]of frames){
  if(!valid(f.entity)||!living(f.owner)||f.entity.dimension.id!==f.dimension||system.currentTick>=f.until||areAllies(f.owner,f.entity)){releaseFrame(id);continue;}
  try{f.entity.teleport(f.location,{dimension:f.entity.dimension,rotation:f.rotation,keepVelocity:false});f.entity.clearVelocity();}catch{releaseFrame(id);}
 }
}
export function recoverStoppedEntities(){
 for(const name of ['overworld','nether','the_end'])try{for(const e of world.getDimension(name).getEntities({tags:[TAG]}))if(!frames.has(e.id))try{restoreFrozenEntity(e);}catch(error){console.warn('[The World recovery] '+error);}}catch{}
 for(const p of world.getAllPlayers())if(!frames.has(p.id)&&p.getDynamicProperty(MARK)!==undefined)try{restoreFrozenEntity(p);}catch{}
}
function saveNativeGuard(p){if(p.getDynamicProperty(WEAK)===undefined)p.setDynamicProperty(WEAK,JSON.stringify({at:Date.now(),effect:effectData(p,'weakness')}));p.addEffect('weakness',40,{amplifier:255,showParticles:false});}
function restoreNativeGuard(p){const raw=p.getDynamicProperty(WEAK);if(raw===undefined)return;const saved=JSON.parse(raw);p.removeEffect('weakness');const ticks=(Date.now()-saved.at)/50;if(saved.effect?.duration>ticks)p.addEffect('weakness',Math.ceil(saved.effect.duration-ticks),{amplifier:saved.effect.amplifier,showParticles:false});p.setDynamicProperty(WEAK,undefined);}
export function tickWorldGuards(){for(const p of world.getAllPlayers())try{if(isTimeFrozen(p))continue;if(getJobId(p)==='the_world'&&(heldItemId(p)==='rpg:the_world_arrow'||sessions.has(p.id))&&!isTimeFrozen(p))saveNativeGuard(p);else restoreNativeGuard(p);}catch(error){console.warn('[The World melee guard] '+error);}}
export function isWorldHighActive(p){return Number(p.getDynamicProperty(HIGH)??0)>Date.now();}
function punch(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,hits:d.hits*2}:d);}
function finisher(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,damagePerHit:d.damagePerHit*2}:d);}
function roller(p,job,d){const dir=flatDir(p),origin=p.location;let at=origin;for(let n=.5;n<=3;n+=.5){const q={x:origin.x+dir.x*n,y:origin.y,z:origin.z+dir.z*n};if(isSolidAt(p.dimension,q)||isSolidAt(p.dimension,{...q,y:q.y+1}))break;at=q;}p.teleport(at,{dimension:p.dimension,keepVelocity:false});return martialAttack(p,job,d);}
function high(p){p.setDynamicProperty(HIGH,Date.now()+8000);p.addEffect('speed',160,{amplifier:1,showParticles:false});const strength=p.getEffect('strength');if(!strength||strength.amplifier<1||(strength.amplifier===1&&strength.duration<160))p.addEffect('strength',160,{amplifier:1,showParticles:false});return true;}
// 흡혈: 전방 근접 대상을 물어 체력을 회복하고 재생 II 10초·저항 II 30초.
// 보스·데스웜(샌드웜)·대장 고블린(대왕 고블린)을 흡혈하면 60초 안에 쓰는 다음 더 월드가 9초로 증가.
const BLOOD_BIG=new Set(['rpg:deathworm','rpg:elite_deathworm','rpg:goblin_captain','rpg:elite_goblin_captain']);
function bloodTarget(p){
 const dir=p.getViewDirection(),origin={x:p.location.x,y:p.location.y+1,z:p.location.z};let best,bestD=Infinity;
 for(const e of getTargets(p,origin,5.5,0)){
  if(!enemy(p,e)||!living(e))continue;
  const dx=e.location.x-origin.x,dy=e.location.y+(e.getComponent('minecraft:health')?1:0)*.8-origin.y,dz=e.location.z-origin.z,d=Math.hypot(dx,dy,dz)||.01;
  if((dx*dir.x+dy*dir.y+dz*dir.z)/d<.35)continue;
  if(d<bestD){best=e;bestD=d;}
 }
 return best;
}
function blood(p,job,def,hitTarget){
 const target=hitTarget&&enemy(p,hitTarget)&&living(hitTarget)&&p.dimension.id===hitTarget.dimension.id&&Math.hypot(p.location.x-hitTarget.location.x,p.location.y-hitTarget.location.y,p.location.z-hitTarget.location.z)<=5.5?hitTarget:bloodTarget(p);
 p.addEffect('regeneration',200,{amplifier:1,showParticles:true});
 p.addEffect('resistance',600,{amplifier:1,showParticles:true});
 if(!target){p.sendMessage('§c흡혈! §7(대상 없음 · 재생 II 10초 / 저항 II 30초)');return true;}
 hurt(target,p,12,'physical',{ignoreInvulnerability:true});
 try{const hp=p.getComponent('minecraft:health');if(hp)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+8));}catch{}
 try{p.dimension.spawnParticle('minecraft:redstone_ore_dust_particle',{x:target.location.x,y:target.location.y+1,z:target.location.z});}catch{}
 if(isBoss(target)||BLOOD_BIG.has(target.typeId)){
  p.setDynamicProperty(BLOOD,Date.now()+60000);
  p.sendMessage('§4흡혈! §7강대한 피를 마셨습니다. §e60초 안의 더 월드가 9초로 증가합니다.');
 }else p.sendMessage('§c흡혈! §7재생 II 10초 / 저항 II 30초');
 return true;
}
export const RUNNERS={world_blood:blood,world_muda:punch,world_finish:finisher,world_roller:roller,world_high:high,world_stop:startTheWorld};
export function registerTheWorld(){
 if(registered)return;registered=true;
 world.beforeEvents.itemUse.subscribe(e=>{if(isTimeFrozen(e.source)||(sessions.has(e.source.id)&&e.itemStack?.typeId!=='rpg:the_world_arrow'))e.cancel=true;});
 system.runInterval(tickTheWorld,1);system.runInterval(tickWorldGuards,1);system.runInterval(recoverStoppedEntities,100);system.run(recoverStoppedEntities);
 world.afterEvents.entitySpawn.subscribe(ev=>system.run(()=>{try{const owner=ev.entity.getComponent('minecraft:projectile')?.owner;if(owner&&isTimeFrozen(owner))ev.entity.remove();}catch{}}));
 // Stable 2.2.0 has no before-hurt cancellation. Weakness/projectile suppression
 // prevent normal attacks; refund any surviving native damage that still reports.
 world.afterEvents.entityHurt.subscribe(ev=>{
  const src=ev.damageSource,projectile=src?.damagingProjectile;
  let attacker=src?.damagingEntity;
  try{attacker=attacker??projectile?.getComponent('minecraft:projectile')?.owner;}catch{}
  try{const victim=ev.hurtEntity;if(victim?.typeId==='minecraft:player'&&sessions.has(victim.id)&&ev.damage>0&&attacker?.id!==victim.id){const h=victim.getComponent('minecraft:health');if(h&&h.currentValue>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));}}catch{}
  if(!isTimeFrozen(attacker)&&!isTimeFrozen(projectile))return;
  try{const h=ev.hurtEntity.getComponent('minecraft:health');if(h?.currentValue>0&&ev.damage>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));}catch{}
 });
 world.afterEvents.entityLoad.subscribe(ev=>{if(!frames.has(ev.entity.id))try{restoreFrozenEntity(ev.entity);}catch{}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.run(()=>{try{if(!frames.has(ev.player.id))restoreFrozenEntity(ev.player);restoreNativeGuard(ev.player);}catch{}}));
 world.afterEvents.playerDimensionChange.subscribe(ev=>stopTheWorld(ev.player,false));
 world.afterEvents.playerLeave.subscribe(ev=>{stopTheWorld({id:ev.playerId},false);basics.delete(ev.playerId);});
 world.afterEvents.entityDie.subscribe(ev=>{stopTheWorld(ev.deadEntity,false);if(frames.has(ev.deadEntity.id))releaseFrame(ev.deadEntity.id,false);});
 world.afterEvents.entityHitEntity.subscribe(ev=>{const p=ev.damagingEntity,t=ev.hitEntity;if(p?.typeId!=='minecraft:player'||getJobId(p)!=='the_world'||heldItemId(p)!=='rpg:the_world_arrow'||isTimeFrozen(p)||!enemy(p,t))return;
  const gap=isWorldHighActive(p)?5:10;if((basics.get(p.id)??-100)>system.currentTick-gap)return;basics.set(p.id,system.currentTick);hurt(t,p,8*scriptedMeleeRuneFactor(p),'physical',{ignoreInvulnerability:true});});
}
```

## RPG_Commands_BP_v0597/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Commands BP v0.6.0",
    "description": "RPG v0.6.0 · 흡혈 복구·혈촉수·피의 창 5회·수호 방어력·TPA 직접 이동",
    "uuid": "533cff27-4591-48cb-85fb-540c8bcbcc72",
    "version": [
      0,
      6,
      0
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "script",
      "language": "javascript",
      "uuid": "9518dff9-cc69-4ea4-adb6-2762b6291c45",
      "entry": "scripts/commands.js",
      "version": [
        0,
        6,
        0
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
      "version": [
        0,
        6,
        0
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    }
  ]
}
```

## RPG_Commands_BP_v0597/scripts/commands.js

```javascript
// RPG command registry, isolated in a separate behavior pack.
// Even if complex RPG combat/skill imports fail, /rpg:ping can still register.
import * as mc from "@minecraft/server";
const VERSION = "0.6.0";
const commands = [
  ['tpa','플레이어 이동 요청 · 이동 성공 시 1000골드'],
  ['tpaaccept','받은 플레이어 이동 요청 수락·거절'],
  ['pvpcreate','관리자: 1000 250 1000에 PvP장 생성',null,true],
  ['pkclear','관리자: 플레이어 PK 패널티 해제','player',true],
  ['peace','관리자: 현재 위치 반경 200 평화구역 설정·해제','mode',true],
  ['pvp','결투 신청·수락·항복·PK 상태','player'],
  ['gptnpc','관리자: GPT RPG 질문 NPC 생성',null,true],
  ['temple','천체 신전 위치·활성 제단·후예 전직'],
  ['templecreate','관리자: 앞쪽 빈 지역에 천체 신전 생성',null,true],
  ['templeremove','관리자: 신전 등록 해제·건물 보존',null,true],
  ['fuse','RPG 장비 등급 합성'],
  ['transfer','RPG 갑옷 강화 추출·이전'],
  ['ask','이 애드온의 직업·스킬·제작·던전 정보 질문','question'],
  ['dungeoncreate','관리자: 난이도 1~10 또는 all 동굴 생성·누락 복구','difficulty',true],
  ['dungeonremove','관리자: 던전 등록 해제 (건축물 보존)','name',true],
  ['dungeon','난이도 목록·파티장 입장 시 파티원 자동 등록','difficulty'],
  ['dungeonstart','대기실 인원 1~4명 출발'],
  ['dungeonsolo','해당 난이도 혼자 바로 시작','difficulty'],
  ['dungeonleave','대기 취소·사망 후 귀환 (전투 중 불가)'],
  ['dungeonloot','보관된 던전 보급품 받기'],
  ['skillguide','모든 직업·스킬 상세 도감'],
  ['runes','룬 전용 보관함·장착'],
  ['jobs','직업별 전직 조건·시련'],
  ['craft', '갑옷·룬 제작법과 획득 도감'],
  ['upgrade', '갑옷·룬·공용 무기 강화'],
  ['wallet', '골드·강화석·룬 가루 지갑'],
  ['equipment', 'RPG 갑옷·룬 보관·장착'],
  ['guide', '모험 시작·견습 5계열 자유 체험'],
  ["rulebook", "RPG 서버 종합 룰북"],
  ["ping", "명령어 등록 진단"],
  ["diag", "명령어 및 스크립트 진단"],
  ["menu", "카멜레온 스킬 메뉴"],
  ["job", "전직", "job"],
  ["help", "명령어 도움말"],
  ["status", "캐릭터 상태"],
  ["stats", "레벨·스탯 분배"],
  ["admin", "운영자 설정 도구", null, true],
  ["setlevel", "관리자: 레벨 설정", "level", true],
  ["setmana", "관리자: 최대 마나 설정", "amount", true],
  ["skills", "스킬 켜기·끄기"],
  ["skillbook", "스킬 도감"],
  ["learn", "스킬 습득", "skill"],
  ["swap", "카멜레온 무기 전환"],
  ["offer", "검과 책을 바칩니다"],
  ["bless", "미카엘 전직: 축복의 빛 192개 공물"],
  ["holywater", "성수 제작"],
  ["force", "관리자: 강제 전직", "job", true],
  ["reset", "관리자: 초기화", null, true],
  ["starter", "관리자: 견습 장비", "line", true],
  ["charge", "관리자: 마나·쿨타임 회복", null, true],
  ["items", "관리자: 전용 아이템", null, true],
  ["egg", "관리자: 몬스터 스폰알", null, true],
  ["hito", "관리자: 전직관 소환알 지급", "line", true],
  ["wings", "날개 켜기·끄기"],
  ["wingcheck", "날개 상태"],
  ["wingrefresh", "날개 새로고침"],
  ["guild", "길드 메뉴"],
  ["party", "파티 메뉴"],
  ["invites", "초대 확인"],
  ["boss", "관리자: 바위 골렘", null, true],
  ["cyclops", "관리자: 외눈 거인", null, true],
  ["hydra", "관리자: 히드라", null, true],
  ["techgolem", "관리자: 마공학 골렘", null, true],
  ["fistcheck", "주먹 강화 상태"]
];
const registered = new Set();
let startupDone = false;
let failures = [];
function isPlayer(p) { return !!p && p.typeId === "minecraft:player"; }
function tell(p, msg) { try { p.sendMessage(msg); } catch (e) { console.warn("[RPG commands] message: " + e); } }
function handle(action, p, arg="") {
  if (!isPlayer(p)) return;
  if (action === "ping") {
    tell(p, "§a[RPG v"+VERSION+"] 명령어 스크립트 실행 정상. 등록 "+registered.size+"/"+commands.length);
    return;
  }
  if (action === "diag") {
    tell(p,"§e[RPG v"+VERSION+"] 명령어 팩 실행 정상 ("+registered.size+"/"+commands.length+"). RPG 본체 확인: /rpg:status");
    if(failures.length) failures.slice(0,4).forEach(x=>tell(p,"§c"+x));
    tell(p,"§7게임플레이 오류는 설정 → 제작자 → 콘텐츠 로그에서 확인 가능. /function rpg_hydra 로 히드라 소환 검사 가능");
    return;
  }
  // The RPG gameplay BP independently handles this script event. It is run as
  // the player so event.sourceEntity is the correct player object.
  const message = String(arg??"").replace(/[\r\n]/g," ").trim();
  try {
    p.runCommand("scriptevent rpg:"+action+(message?" "+message:""));
  } catch (e) {
    tell(p,"§c[RPG] 명령어 전달 실패: "+String(e));
  }
}
mc.system.beforeEvents.startup.subscribe(ev => {
  startupDone = true;
  const registry = ev.customCommandRegistry;
  if(!registry){ console.error("[RPG commands] customCommandRegistry unavailable"); return; }
  const levels = mc.CommandPermissionLevel ?? mc.CustomCommandPermissionLevel;
  const params = mc.CustomCommandParamType;
  const statuses = mc.CustomCommandStatus;
  if(!levels || !params || !statuses){ console.error("[RPG commands] Script API command enums unavailable"); return; }
  for(const [name, description, arg, admin] of commands){
    try{
      const def={name:"rpg:"+name,description,permissionLevel: admin?levels.GameDirectors:levels.Any,cheatsRequired:false};
      if(arg){
        const t = name === "setlevel" ? params.Integer : params.String;
        if(name === "hito" || name === "dungeon" || name === "ask" || name === "pvp" || name === "peace" || name === "pkclear") def.optionalParameters=[{name:arg,type:t}];
        else def.mandatoryParameters=[{name:arg,type:t}];
      }
      registry.registerCommand(def,(origin,...args)=>{
        const p=origin.sourceEntity??origin.initiator;
        if(!isPlayer(p)) return {status:statuses.Failure,message:"플레이어 전용 명령어"};
        const raw=Array.isArray(args[0])?args[0][0]:args[0];
        mc.system.run(()=>handle(name,p,raw==null?"":String(raw)));
        return {status:statuses.Success};
      });
      registered.add(name);
    }catch(e){
      const msg="/rpg:"+name+" 등록 실패: "+String(e);
      failures.push(msg);console.error("[RPG commands] "+msg);
    }
  }
  try{registry.registerCommand({name:'pvp',description:'결투 신청',permissionLevel:levels.Any,cheatsRequired:false,optionalParameters:[{name:'player',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvp',p,arg??''));return {status:statuses.Success};});}catch{ /* Namespace-free aliases are unsupported on some Bedrock versions. */ }
  try{registry.registerCommand({name:'peace',description:'관리자: 반경 200 평화구역',permissionLevel:levels.GameDirectors,cheatsRequired:false,optionalParameters:[{name:'mode',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('peace',p,arg??''));return {status:statuses.Success};});}catch{console.warn('[RPG] /peace 별칭 미지원: /rpg:peace 사용');}
  try{registry.registerCommand({name:'pvpcreate',description:'관리자: PvP장 생성',permissionLevel:levels.GameDirectors,cheatsRequired:false},origin=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvpcreate',p,''));return {status:statuses.Success};});}catch{console.warn('[RPG] /pvpcreate 별칭 미지원: /rpg:pvpcreate 사용');}
  console.warn("[RPG v"+VERSION+"] registered "+registered.size+"/"+commands.length+" commands");
});
// Allow commands even if a particular client doesn't display slash commands.
try {
  const chat=mc.world.beforeEvents?.chatSend;
  if(chat?.subscribe) chat.subscribe(ev=>{
    const msg=String(ev.message??"").trim();
    if(!/^!(?:rpg|rulebook|hito|pvp)(?:\s|$)/i.test(msg))return;
    ev.cancel=true;
    let action="help",arg="";
    if(/^!pvp(?:\s|$)/i.test(msg)){action='pvp';arg=msg.replace(/^!pvp\s*/i,'');}
    else if(/^!rulebook$/i.test(msg))action="rulebook";
    else if(/^!hito(?:\s|$)/i.test(msg)){action="hito";arg=msg.replace(/^!hito\s*/i,"");}
    else {const parts=msg.replace(/^!rpg\s*/i,"").trim().split(/\s+/);action=(parts.shift()||"help").toLowerCase();arg=parts.join(" ");}
    const p=ev.sender;
    mc.system.run(()=>handle(action,p,arg));
  });
}catch(e){console.warn("[RPG commands] chat fallback disabled: "+e);}
// Direct /scriptevent rpg:ping and rpg:diag allow diagnosing even if custom
// command registration is unsupported on the current Bedrock version.
try {
  mc.system.afterEvents.scriptEventReceive.subscribe(ev=>{
    if(ev.id!=="rpg:ping"&&ev.id!=="rpg:diag") return;
    if(isPlayer(ev.sourceEntity))mc.system.run(()=>handle(ev.id.slice(4),ev.sourceEntity));
  });
}catch(e){console.warn("[RPG commands] event diagnostic fallback disabled: "+e);}
```

## RPG_RP_v0597/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon RP v0.6.0",
    "description": "RPG v0.6.0 · 흡혈 복구·혈촉수·피의 창 5회·수호 방어력·TPA 직접 이동",
    "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
    "version": [
      0,
      6,
      0
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "resources",
      "uuid": "7ede5e36-9a5f-44d1-9aa0-9dc38822fa99",
      "version": [
        0,
        6,
        0
      ]
    }
  ]
}
```

## RPG_RP_v0597/particles/rpg_blood_tentacle_whip.json

```json
{
  "format_version": "1.10.0",
  "particle_effect": {
    "description": {
      "identifier": "rpg:blood_tentacle_whip",
      "basic_render_parameters": {
        "material": "particles_add",
        "texture": "textures/particles/rpg_blood_spark"
      }
    },
    "components": {
      "minecraft:emitter_rate_instant": {
        "num_particles": 1
      },
      "minecraft:emitter_lifetime_once": {
        "active_time": 0.01
      },
      "minecraft:emitter_shape_point": {},
      "minecraft:particle_lifetime_expression": {
        "max_lifetime": 0.18
      },
      "minecraft:particle_initial_speed": 0,
      "minecraft:particle_motion_dynamic": {},
      "minecraft:particle_appearance_billboard": {
        "size": [
          0.13,
          0.19
        ],
        "facing_camera_mode": "lookat_xyz",
        "uv": {
          "texture_width": 16,
          "texture_height": 16,
          "uv": [
            0,
            0
          ],
          "uv_size": [
            16,
            16
          ]
        }
      },
      "minecraft:particle_appearance_tinting": {
        "color": [
          1,
          0.04,
          0.1,
          "1-variable.particle_age/variable.particle_lifetime"
        ]
      }
    }
  }
}
```
