import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0619'),base=root+'/RPG_BP_v0619/scripts/';
const source=fs.readFileSync(base+'data/fantasyCity.js','utf8'),context=vm.createContext({console});const data=new vm.SourceTextModule(source,{context});await data.link(()=>{});await data.evaluate();
const planner=data.namespace,{operations,houses}=planner.makeFantasyCityPlan();let area=0,clipped=0,volume=0;const sum=o=>(o.x2-o.x+1)*(o.y2-o.y+1)*(o.z2-o.z+1);
for(const o of operations){assert.ok(o.x>=0&&o.z>=0&&o.x2<250&&o.z2<250&&o.y>=-1&&o.y2<=30,JSON.stringify(o));volume+=sum(o);}
for(let i=0;i<16;i++){const t=planner.cityTile(i);area+=(t.x2-t.x+1)*(t.z2-t.z+1);for(const op of planner.tileOperations(operations,t))clipped+=sum(op);}
assert.equal(area,62500);assert.equal(clipped,volume);assert.ok(houses>=20);
const material=(x,y,z)=>operations.find(o=>x>=o.x&&x<=o.x2&&y>=o.y&&y<=o.y2&&z>=o.z&&z<=o.z2)?.type;
assert.equal(material(249,-1,249),'minecraft:stone_bricks');assert.equal(material(125,1,0),undefined);assert.equal(material(0,1,50),'minecraft:stone_bricks');assert.equal(material(38,1,30),undefined);assert.equal(material(33,3,30),'minecraft:glass');assert.equal(material(125,0,125),'minecraft:gold_block');assert.equal(material(125,1,125),undefined);
for(const [id,x,z]of planner.CITY_TRAINERS){assert.ok(material(x,0,z));assert.equal(material(x,1,z),undefined);}
console.log(`Compact city: 250x250, ${houses} buildings, ${volume} placement visits, 16 tiles, usable gates/windows/NPCs and center spawn passed`);
async function runtime(store=new Map(),options={}){
 const messages=[],commands=[],npcs=[],writes=[],timers=[];let count=0,queries=0,now=100000;
 const p={id:'admin',location:{x:1000.8,y:65.9,z:-700.2},dimension:{id:'minecraft:overworld'},sendMessage:s=>messages.push(s)};
 const dim={runCommand:s=>{commands.push(s);return {successCount:options.loadFailure?0:1};},getTopmostBlock:()=>{queries++;return {location:{y:options.top??63}};},getBlock:location=>{const key=[location.x,location.y,location.z].join(',');return {get isAir(){return options.blocks?!options.blocks.has(key):!options.existing;},get typeId(){return options.blocks?options.blocks.get(key)??'minecraft:air':options.existing?'minecraft:chest':'minecraft:air';},getComponent:()=>options.containers?.get(key),setPermutation:permutation=>{count++;if(options.blocks){if(permutation.type==='minecraft:air')options.blocks.delete(key);else options.blocks.set(key,permutation.type);}if(writes.length<512)writes.push({location,permutation});}};},getEntities:q=>npcs.filter(n=>n.type===q.type&&Math.hypot(n.location.x-q.location.x,n.location.z-q.location.z)<=q.maxDistance),spawnEntity:(type,location)=>npcs.push({type,location})};
 const world={getDimension:()=>dim,getAllPlayers:()=>options.offline?[]:[p,...(options.players??[])],getDefaultSpawnLocation:()=>({x:9999,y:200,z:9999}),setDefaultSpawnLocation:pos=>options.newSpawn=pos,getDynamicProperty:k=>store.get(k),setDynamicProperty:(k,v)=>v===undefined?store.delete(k):store.set(k,v)};
 const system={currentTick:0,run:fn=>timers.push(fn),runInterval:()=>1},ctx=vm.createContext({console,Date:class extends Date{static now(){return now;}}});
 const m=new vm.SourceTextModule(fs.readFileSync(base+'core/fantasyCity.js','utf8'),{context:ctx}),plan=new vm.SourceTextModule(source,{context:ctx});await plan.link(()=>{});
 const ext=new vm.SyntheticModule(['world','system','BlockPermutation'],function(){this.setExport('world',world);this.setExport('system',system);this.setExport('BlockPermutation',{resolve:(type,states)=>({type,states})});},{context:ctx});
 const legacy=new vm.SourceTextModule(fs.readFileSync(base+'data/fantasyCityLegacy.js','utf8'),{context:ctx});await legacy.link(()=>{});
 const trimModule=new vm.SourceTextModule(fs.readFileSync(base+'core/cityTrim.js','utf8'),{context:ctx});await trimModule.link(s=>s.startsWith('.')?legacy:ext);
 const region=new vm.SyntheticModule(['setSpawnRegion'],function(){this.setExport('setSpawnRegion',s=>store.set('region',JSON.stringify(s)));},{context:ctx});const oldPlan=new vm.SourceTextModule(fs.readFileSync(base+'data/fantasyCityV1.js','utf8'),{context:ctx});await oldPlan.link(()=>{});
 const decor=new vm.SourceTextModule(fs.readFileSync(base+'core/cityDecor.js','utf8'),{context:ctx});await decor.link(s=>s.includes('V1')?oldPlan:plan);
 await m.link(s=>s.includes('cityDecor')?decor:s.includes('V1')?oldPlan:s.includes('cityTrim')?trimModule:s.includes('spawnEffects')?region:s.startsWith('.')?plan:ext);await m.evaluate();const api=m.namespace;
 return {api,decorApi:decor.namespace,oldPlan:oldPlan.namespace,trimApi:trimModule.namespace,legacy:legacy.namespace,p,store,options,messages,commands,npcs,writes,timers,get count(){return count;},get queries(){return queries;},tick(){now+=50;system.currentTick++;api.tickFantasyCity();},saved(){return JSON.parse(store.get(api.CITY_KEY));}};
}
{
 const t=await runtime();assert.equal(t.api.createFantasyCity(t.p,''),true);assert.equal(t.saved().x,875);assert.equal(t.saved().z,-826);assert.equal(t.saved().y,64);let n=0;
 while(t.saved().phase!=='done'&&n++<10000)t.tick();assert.equal(t.saved().phase,'done');assert.equal(t.queries,62500);assert.equal(t.npcs.length,8);assert.equal(t.options.newSpawn.x,1000);assert.equal(t.options.newSpawn.z,-701);assert.equal(t.options.newSpawn.y,65);assert.ok(t.commands.every(s=>s.includes('rpg_city_build_v1')));assert.ok(t.writes.every(w=>w.location.x>=875&&w.location.x<1125&&w.location.z>=-826&&w.location.z< -576));
 console.log(`Compact full simulated build completed in ${n} ticks at caller's X/Z, 8 NPCs, and no resume request`);
}
{
 const t=await runtime(new Map(),{top:210});t.api.createFantasyCity(t.p,'');let n=0;while(t.saved().phase==='survey'&&n++<10000)t.tick();assert.equal(t.saved().phase,'build');assert.equal(t.saved().y,211);assert.equal(t.count,0);
 while(t.count===0&&n++<11000)t.tick();assert.ok(t.count>0);t.api.stopFantasyCity(t.p);const count=t.count;t.tick();assert.equal(t.count,count);assert.equal(t.saved().manualPause,true);t.api.resumeFantasyCity(t.p);assert.equal(t.saved().manualPause,false);
 const copy=JSON.parse(t.store.get(t.api.CITY_KEY));copy.manualPause=false;t.store.set(t.api.CITY_KEY,JSON.stringify(copy));const restored=await runtime(t.store);restored.api.registerFantasyCity();restored.timers[0]();assert.equal(restored.saved().manualPause,false);for(let i=0;i<25;i++)restored.tick();assert.ok(restored.count>0);
 console.log('Automatic height adjustment and world-restart continuation passed; explicit manual stop still respected');
}
{
 const opts={loadFailure:true},t=await runtime(new Map(),opts);t.api.createFantasyCity(t.p,'');t.tick();assert.ok(t.saved().error);assert.equal(t.count,0);opts.loadFailure=false;for(let i=0;i<150;i++)t.tick();assert.ok(t.queries>0);assert.equal(t.saved().manualPause,false);
 const off={offline:true},u=await runtime(new Map(),off);u.api.createFantasyCity(u.p,'');for(let i=0;i<25;i++)u.tick();assert.equal(u.queries,0);off.offline=false;for(let i=0;i<25;i++)u.tick();assert.ok(u.queries>0);
 console.log('Chunk-load failure and offline idle automatically continue without /cityresume');
}
{
 const store=new Map([['rpg:fantasy_city_v1',JSON.stringify({version:1,phase:'done',x:0,z:0,y:200})]]),t=await runtime(store);t.api.registerFantasyCity();t.timers[0]();assert.ok(store.has('rpg:fantasy_city_1000_archive'));assert.equal(store.has(t.api.CITY_KEY),false);assert.equal(JSON.parse(store.get('region')).x,9874);assert.equal(t.api.createFantasyCity(t.p,''),true);assert.equal(t.saved().size,250);assert.equal(t.saved().x,875);
 const options={existing:true},v=await runtime(new Map(),options);v.api.createFantasyCity(v.p,'');let n=0;while(v.saved().phase==='survey'&&n++<10000)v.tick();for(let i=0;i<25;i++)v.tick();assert.equal(v.count,0);
 console.log('Legacy 1000-city metadata archives safely; new compact city starts at caller; occupied building blocks preserved');
}

{
 const old={version:1,phase:'done',x:500,y:200,z:-1200},s={version:2,size:250,x:875,y:240,z:-826,owner:'admin',phase:'trim',tile:16,op:0,offset:0,manualPause:false,retries:0,trimTile:0,trimOffset:0,trimRemoved:0};
 const blocks=new Map(),containers=new Map(),store=new Map([['rpg:fantasy_city_v1',JSON.stringify(s)],['rpg:fantasy_city_1000_archive',JSON.stringify(old)]]);
 let moved=0;const spectator={dimension:{id:'minecraft:overworld'},location:{x:600,y:201,z:-1100},getGameMode:()=> 'survival',teleport:pos=>{spectator.location=pos;moved++;}};
 const t=await runtime(store,{blocks,containers,players:[spectator]});
 const expected=t.trimApi.trimContext(old,0,s);while(!t.trimApi.prepareTrim(expected,256)){}const first=[...expected.expected.values()];assert.ok(first.length>0);const key=p=>[p.x,p.y,p.z].join(',');blocks.set(key(first[0]),first[0].type);blocks.set(key(first[1]),'minecraft:diamond_block');
 const inner={x:900,y:200,z:-800};blocks.set(key(inner),'minecraft:gold_block');
 const chests=t.legacy.makeFantasyCityPlan().operations.filter(o=>o.type==='minecraft:chest').slice(0,2).map(o=>({x:old.x+o.x,y:old.y+o.y,z:old.z+o.z,type:o.type}));
 for(const p of chests)blocks.set(key(p),p.type);containers.set(key(chests[0]),{container:{size:1,getItem:()=>({typeId:'minecraft:diamond'})}});containers.set(key(chests[1]),{container:{size:1,getItem:()=>undefined}});
 t.api.registerFantasyCity();t.timers[0]();let n=0;while(t.saved().phase!=='done'&&n++<50000)t.tick();assert.equal(t.saved().phase,'done');assert.equal(blocks.has(key(first[0])),false);assert.equal(blocks.get(key(first[1])),'minecraft:diamond_block');assert.equal(blocks.get(key(inner)),'minecraft:gold_block');assert.equal(blocks.get(key(chests[0])),'minecraft:chest');assert.equal(blocks.has(key(chests[1])),false);assert.equal(JSON.parse(store.get('rpg:fantasy_city_1000_archive')).trimmed,true);assert.equal(moved,1);
 console.log(`Automatic old-city trim: ${n} ticks; outer generated blocks removed, changed blocks/inner 250 area/filled chest preserved; survival player relocated safely`);
}
{
 const t=await runtime(),old={version:1,phase:'build',x:500,y:200,z:-1200,tile:0,op:0,offset:7},keep={x:875,z:-826};
 const ops=t.legacy.tileOperations(t.legacy.makeFantasyCityPlan().operations,t.legacy.cityTile(0));old.op=ops.findIndex(o=>o.type.endsWith('_planks')&&o.y>=7&&(o.x2-o.x+1)*(o.y2-o.y+1)*(o.z2-o.z+1)>7);assert.ok(old.op>=0);
 const before=t.trimApi.trimContext({...old,offset:0},0,keep);while(!t.trimApi.prepareTrim(before,256)){}
 assert.equal(t.trimApi.oldTrimTileLimit(old),1);const part=t.trimApi.trimContext(old,0,keep);while(!t.trimApi.prepareTrim(part,256)){}assert.equal(part.expected.size,before.expected.size+7);
 const full=t.trimApi.trimContext({...old,phase:'done'},0,keep);while(!t.trimApi.prepareTrim(full,256)){}assert.deepEqual([...part.expected.keys()],[...full.expected.keys()].slice(0,part.expected.size));assert.equal(t.trimApi.oldTrimTileLimit({...old,tile:2,op:1,offset:0}),3);assert.equal(t.trimApi.oldTrimTileLimit({...old,phase:'survey'}),0);
 console.log('Partial old-city cleanup includes only completed tiles and the recorded operation prefix; unbuilt sites excluded');
}
{
 const t=await runtime(),old=t.oldPlan.makeFantasyCityPlan().operations,blockMap=new Map(),s={version:2,size:250,x:875,y:64,z:-826,owner:'admin',phase:'done',tile:16,op:0,offset:0,manualPause:false,retries:0};
 const worldKey=p=>[s.x+p.x,s.y+p.y,s.z+p.z].join(',');
 for(const o of old)for(let y=o.y;y<=o.y2;y++)for(let z=o.z;z<=o.z2;z++)for(let x=o.x;x<=o.x2;x++){const k=worldKey({x,y,z});if(!blockMap.has(k))blockMap.set(k,o.type);}
 const c=t.decorApi.decorContext(planner.cityTile(0));while(!t.decorApi.prepareDecor(c,256)){}const changes=[...c.iterator],floor=changes.find(d=>d.location.y===0&&d.old&&d.target),roof=changes.find(d=>d.location.y>=7&&d.target?.type.endsWith('_stairs')),removed=changes.find(d=>d.old?.type.endsWith('_planks')&&!d.target);assert.ok(floor&&roof&&removed);
 const modified=changes.find(d=>d.old?.type.endsWith('_planks')&&d!==roof&&d!==removed),editedKey=worldKey(modified.location);blockMap.set(editedKey,'minecraft:diamond_block');
 assert.equal(t.decorApi.canDecorate({typeId:roof.old?.type??'minecraft:air',isAir:!roof.old,getComponent:()=>({container:{}})},roof),false);
 const store=new Map([['rpg:fantasy_city_v1',JSON.stringify(s)]]),u=await runtime(store,{blocks:blockMap});u.api.registerFantasyCity();u.timers[0]();assert.equal(u.saved().phase,'decorate');
 let n=0;while(u.saved().tile===0&&n++<5000)u.tick();assert.equal(u.saved().tile,1);assert.equal(blockMap.get(worldKey(floor.location)),floor.target.type);assert.equal(blockMap.get(worldKey(roof.location)),roof.target.type);assert.equal(blockMap.has(worldKey(removed.location)),false);assert.equal(blockMap.get(editedKey),'minecraft:diamond_block');
 const restarted=await runtime(store,{blocks:blockMap});restarted.api.registerFantasyCity();restarted.timers[0]();while(restarted.saved().phase!=='done'&&n++<15000)restarted.tick();assert.equal(restarted.saved().phase,'done');assert.equal(restarted.saved().designRevision,2);assert.equal(blockMap.get(editedKey),'minecraft:diamond_block');
 const done=await runtime(store,{blocks:blockMap});done.api.registerFantasyCity();done.timers[0]();done.tick();assert.equal(done.saved().phase,'done');assert.equal(done.count,0);
 console.log(`Existing 250 village: automatic decoration + restart completed in ${n} ticks; old roof removed, stairs/paving installed, player edits/containers preserved, revision prevents repeated rebuild`);
}
{
 const roofs=operations.filter(o=>o.y>=6&&o.type.endsWith('_stairs')),floor=operations.filter(o=>o.y===0&&o.y2===0),floors=new Set(floor.map(o=>o.type));
 assert.ok(roofs.length>200);assert.ok(roofs.some(o=>o.states.weirdo_direction===0&&!o.states.upside_down_bit));assert.ok(roofs.some(o=>o.states.weirdo_direction===1&&!o.states.upside_down_bit));assert.ok(roofs.some(o=>o.states.upside_down_bit));
 for(const type of ['minecraft:mossy_cobblestone','minecraft:mossy_stone_bricks','minecraft:moss_block','minecraft:andesite','minecraft:chiseled_stone_bricks','minecraft:polished_blackstone_bricks'])assert.ok(floors.has(type),type);
 assert.ok(floor.some(o=>o.type.endsWith('_stairs')&&o.states.upside_down_bit));assert.equal(material(30,7,35),'minecraft:dark_oak_planks');
 console.log(`Village decoration geometry: ${roofs.length} oriented roof/eave stair operations, flat-topped stair pavement, ${floors.size} floor materials, closed eaves and clear routes`);
}
{
 const schema=JSON.parse(fs.readFileSync(new URL('./city_blocks.json',import.meta.url),'utf8')).blocks;
 for(const op of operations){assert.ok(schema[op.type],op.type);for(const [key,value]of Object.entries(op.states??{}))assert.ok(schema[op.type][key]?.includes(value),op.type+' '+key+' '+value);}
 assert.equal(operations.filter(o=>o.type==='minecraft:oak_leaves'&&o.states?.persistent_bit).length,30);assert.equal(operations.filter(o=>o.type==='minecraft:flowering_azalea').length,24);
 console.log('All planned vanilla block IDs and explicit states match bundled Mojang metadata; planted yards, benches and two market canopies verified');
}
