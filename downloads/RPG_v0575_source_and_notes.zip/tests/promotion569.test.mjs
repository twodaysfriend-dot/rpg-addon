import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack} from './minecraftMock.mjs';
import {SKILLS} from '../RPG_BP_v0575/scripts/data/skills.js';
import {dungeonTimeLimit} from '../RPG_BP_v0575/scripts/data/dungeons.js';
import {fusionQuote,fuseEquipment} from '../RPG_BP_v0575/scripts/core/fusion.js';
import {addRuneRecord,readRuneBag,writeRuneBag,equipRune} from '../RPG_BP_v0575/scripts/core/runeInventory.js';
import {WEAPON_LEVEL_KEY} from '../RPG_BP_v0575/scripts/data/upgrades.js';

function pair(a=5,b=5,grade=1){const p=player('pair'),bag=readRuneBag(p),main=addRuneRecord(bag,'power',a,grade),material=addRuneRecord(bag,'power',b,grade);writeRuneBag(p,bag);equipRune(p,main.uid,0);return {p,a:{kind:'rune',slot:main.uid},b:{kind:'rune',slot:material.uid}};}
test('requested damage constants and continuous damage totals use the requested values',()=>{
 assert.equal(SKILLS.archer_judgement.damage,65);assert.equal(SKILLS.mage_thunder.damage,25);
 assert.equal(SKILLS.sage_blackhole.damage,50);assert.equal(SKILLS.sage_sphere.damage,50);
 assert.equal(SKILLS.mage_thunder.strikes,3);assert.equal(SKILLS.sage_blackhole.duration,120);
});
test('only initially solo runs get 7:30 mobs and 4:30 boss budgets',()=>{
 assert.equal(dungeonTimeLimit('mobs',1),450000);assert.equal(dungeonTimeLimit('boss',1),270000);
 for(const n of [2,3,4]){assert.equal(dungeonTimeLimit('mobs',n),300000);assert.equal(dungeonTimeLimit('boss',n),180000);}
});
test('all +5 through +9 levels qualify, mixed +10/+5 remains probabilistic, and below +5 is rejected',()=>{
 for(let level=5;level<=9;level++){const s=pair(level,level);assert.equal(fusionQuote(s.p,s.a,s.b).chance,85);}
 const mixed=pair(10,5);assert.equal(fusionQuote(mixed.p,mixed.a,mixed.b).chance,85);
 for(const levels of [[4,5],[10,4]]){const s=pair(...levels);assert.equal(fusionQuote(s.p,s.a,s.b),undefined);}
});
test('two +10 items guarantee promotion at every grade without drawing random numbers',()=>{
 for(let grade=0;grade<6;grade++){const s=pair(10,10,grade);assert.equal(fusionQuote(s.p,s.a,s.b).chance,100);const result=fuseEquipment(s.p,s.a,s.b,undefined,{random:()=>{throw Error('must not roll');}});assert.equal(result.success,true);assert.equal(readRuneBag(s.p).runes.length,1);assert.equal(result.level,0);assert.equal(result.grade,grade+1);}
});
test('failed rune promotion preserves both runes and equipped UID, downgrade occurs on exactly half of failure rolls',()=>{
 for(const [roll,level]of [[0,4],[.499999,4],[.5,5],[.99999,5]]){
  const s=pair();let i=0;const result=fuseEquipment(s.p,s.a,s.b,undefined,{random:()=>i++===0?.99:roll});
  assert.equal(result.success,false);assert.equal(result.level,level);const bag=readRuneBag(s.p);
  assert.equal(bag.runes.length,2);assert.equal(bag.runes.find(r=>r.uid===s.b.slot).level,5);assert.equal(bag.equipped[0],s.a.slot);assert.equal(bag.runes.find(r=>r.uid===s.a.slot).level,level);
 }
});
test('failed weapon promotion preserves both instances and consumes the required book',()=>{
 const p=player('weapon');for(const slot of [3,4]){const item=new ItemStack('rpg:common_redmoon_blade');item.setDynamicProperty(WEAPON_LEVEL_KEY,5);p.slots[slot]=item;}
 const book=new ItemStack('minecraft:enchanted_book');book.enchantments=[{type:{id:'sharpness'},level:5}];p.slots[9]=book;
 let i=0;const result=fuseEquipment(p,{kind:'inventory',slot:3},{kind:'inventory',slot:4},undefined,{random:()=>i++===0?.99:0});
 assert.equal(result.success,false);assert.equal(p.slots[3].getDynamicProperty(WEAPON_LEVEL_KEY),4);assert.equal(p.slots[4].getDynamicProperty(WEAPON_LEVEL_KEY),5);assert.equal(p.slots[9],undefined);
});
test('invalid downgrade randomness fails before mutating rune data',()=>{
 const s=pair(),before=s.p.getDynamicProperty('rpg:rune_bag_v1');let i=0;const result=fuseEquipment(s.p,s.a,s.b,undefined,{random:()=>i++===0?.99:NaN});assert.equal(result.ok,false);assert.equal(s.p.getDynamicProperty('rpg:rune_bag_v1'),before);
});
