import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,EquipmentSlot,replies,forms} from './minecraftMock.mjs';
import {RARITY_KEY,PROMOTION_RATES} from '../RPG_BP_v0575/scripts/data/grades.js';
import {COMMON_WEAPONS} from '../RPG_BP_v0575/scripts/data/commonWeapons.js';
import {ARMOR_LEVEL_KEY,WEAPON_LEVEL_KEY,upgradeLevel} from '../RPG_BP_v0575/scripts/data/upgrades.js';
import {fuseEquipment,fusionQuote,openFusionMenu} from '../RPG_BP_v0575/scripts/core/fusion.js';
import {gearFingerprint} from '../RPG_BP_v0575/scripts/core/gearState.js';
import {readRuneBag,writeRuneBag,addRuneRecord,equipRune,withdrawRune,depositRune} from '../RPG_BP_v0575/scripts/core/runeInventory.js';
import {getEquipmentBonuses} from '../RPG_BP_v0575/scripts/core/equipment.js';
import {enhanceEquipped,enhancementQuote} from '../RPG_BP_v0575/scripts/core/upgrades.js';
import {getWallet,setWallet} from '../RPG_BP_v0575/scripts/core/wallet.js';
const inv=slot=>({kind:'inventory',slot});
const rune=slot=>({kind:'rune',slot});
function item(id,grade=1,level=10){const i=new ItemStack(id);i.setDynamicProperty(RARITY_KEY,grade);i.setDynamicProperty(id.includes('common_')?WEAPON_LEVEL_KEY:ARMOR_LEVEL_KEY,level);return i;}
function pair(id=COMMON_WEAPONS[0].id,grade=1,level=10){const p=player('fusion');p.slots[3]=item(id,grade,level);p.slots[4]=item(id,grade,level);p.slots[9]=new ItemStack('minecraft:enchanted_book');p.slots[9].enchantments=[{type:{id:id.includes('common_')?'sharpness':'protection'},level:id.includes('common_')?5:4}];return p;}
function runes(grade=1,level=10){const p=player('rune-fusion'),b=readRuneBag(p),a=addRuneRecord(b,'power',level,grade),m=addRuneRecord(b,'power',level,grade);writeRuneBag(p,b);equipRune(p,a.uid,0);return {p,a:rune(a.uid),m:rune(m.uid)};}
test('each weapon has independent promotions at every boundary, with main metadata preserved',()=>{
 for(const w of COMMON_WEAPONS)for(let grade=0;grade<6;grade++){
  const p=pair(w.id,grade),main=p.slots[3];main.nameTag='named by player';main.setDynamicProperty('test:custom','keep');main.setLore(['my lore']);
  const q=fusionQuote(p,inv(3),inv(4));assert.equal(q.chance,100);
  const before=getWallet(p),result=fuseEquipment(p,inv(3),inv(4),q.fingerprint,{random:()=>0});
  assert.equal(result.ok,true);assert.equal(result.success,true);assert.equal(p.slots[4],undefined);assert.equal(p.slots[3].getDynamicProperty(RARITY_KEY),grade+1);assert.equal(upgradeLevel(p.slots[3],'weapon'),0);assert.equal(p.slots[3].nameTag,'named by player');assert.equal(p.slots[3].getDynamicProperty('test:custom'),'keep');assert.ok(p.slots[3].getLore().includes('my lore'));assert.deepEqual(getWallet(p),before);
 }
});
test('failure consumes only material; main is byte-for-byte unchanged in state fingerprint',()=>{
 const p=pair(COMMON_WEAPONS[0].id,1,5),before=gearFingerprint(p.slots[3]),q=fusionQuote(p,inv(3),inv(4));const result=fuseEquipment(p,inv(3),inv(4),q.fingerprint,{random:()=>.85});assert.equal(result.success,false);assert.equal(gearFingerprint(p.slots[3]),before);assert.ok(p.slots[4]);
});
test('same slot, wrong kind, grade, level, armor part and mythical are rejected without loss',()=>{
 const cases=[p=>[inv(3),inv(3)],p=>{p.slots[4]=item(COMMON_WEAPONS[1].id);return [inv(3),inv(4)];},p=>{p.slots[4].setDynamicProperty(RARITY_KEY,0);return [inv(3),inv(4)];},p=>{p.slots[4].setDynamicProperty(WEAPON_LEVEL_KEY,4);return [inv(3),inv(4)];},p=>{p.slots[3]=item('rpg:adventurer_helmet');p.slots[4]=item('rpg:adventurer_boots');return [inv(3),inv(4)];},p=>{for(const i of [3,4])p.slots[i].setDynamicProperty(RARITY_KEY,6);return [inv(3),inv(4)];},p=>[inv(-1),inv(4)],p=>[{kind:'equipment',slot:EquipmentSlot.Mainhand},inv(4)]];
 for(const change of cases){const p=pair(),refs=change(p),before=p.slots.map(gearFingerprint);assert.equal(fuseEquipment(p,...refs,undefined,{random:()=>0}).ok,false);assert.deepEqual(p.slots.map(gearFingerprint),before);}
});
test('stale quote catches changes in name, unrelated dynamic data and amount',()=>{
 for(const change of [i=>i.nameTag='changed',i=>i.setDynamicProperty('rpg:rarity',2),i=>i.setDynamicProperty('custom:tag',1),i=>i.amount=2]){
  const p=pair(),q=fusionQuote(p,inv(3),inv(4));change(p.slots[3]);const before=p.slots.map(gearFingerprint);assert.equal(fuseEquipment(p,inv(3),inv(4),q.fingerprint,{random:()=>0}).ok,false);assert.deepEqual(p.slots.map(gearFingerprint),before);
 }
});
test('equipped armor promotion resets only enhancement and applies grade HP immediately',()=>{
 const p=pair('rpg:adventurer_helmet',2);p.equipment.set(EquipmentSlot.Head,p.slots[3]);p.slots[3]=undefined;
 assert.equal(getEquipmentBonuses(p).health,14);const result=fuseEquipment(p,{kind:'equipment',slot:EquipmentSlot.Head},inv(4),undefined,{random:()=>0});assert.equal(result.success,true);assert.equal(getEquipmentBonuses(p).health,7);assert.equal(upgradeLevel(p.equipment.get(EquipmentSlot.Head),'armor'),0);
});
test('failed physical save rolls back already-consumed material and equipped main',()=>{
 const p=pair('rpg:adventurer_helmet');p.equipment.set(EquipmentSlot.Head,p.slots[3]);p.slots[3]=undefined;const get=p.getComponent.bind(p),eq=get('minecraft:equippable');let fail=true;
 p.getComponent=n=>n==='minecraft:equippable'?{...eq,setEquipment:(s,i)=>{if(fail){fail=false;return false;}return eq.setEquipment(s,i);}}:get(n);
 const before=gearFingerprint(p.equipment.get(EquipmentSlot.Head)),material=gearFingerprint(p.slots[4]);assert.equal(fuseEquipment(p,{kind:'equipment',slot:EquipmentSlot.Head},inv(4),undefined,{random:()=>0}).ok,false);assert.equal(gearFingerprint(p.equipment.get(EquipmentSlot.Head)),before);assert.equal(gearFingerprint(p.slots[4]),material);
});
test('rune success retains main UID/equipped reference, consumes material, grade effect updates and cannot export upgraded rarity',()=>{
 const {p,a,m}=runes();const result=fuseEquipment(p,a,m,undefined,{random:()=>0});assert.equal(result.success,true);const bag=readRuneBag(p);assert.equal(bag.runes.length,1);assert.equal(bag.runes[0].grade,2);assert.equal(bag.runes[0].level,0);assert.equal(bag.equipped[0],a.slot);assert.ok(Math.abs(getEquipmentBonuses(p).physical-1.12)<1e-9);assert.equal(withdrawRune(p,a.slot).ok,false);
});
test('rune failure retains main state; bad RNG or missing material never consumes it',()=>{
 const {p,a,m}=runes(1,5),before=readRuneBag(p).runes[0];assert.equal(fuseEquipment(p,a,m,undefined,{random:()=>.99}).success,false);assert.deepEqual(readRuneBag(p).runes[0],before);const left=readRuneBag(p);left.runes=left.runes.filter(r=>r.uid!==m.slot);writeRuneBag(p,left);assert.equal(fuseEquipment(p,a,m,undefined,{random:()=>0}).ok,false);
 for(const value of [-1,1,NaN,Infinity]){const s=runes(1,5),old=s.p.getDynamicProperty('rpg:rune_bag_v1');assert.equal(fuseEquipment(s.p,s.a,s.m,undefined,{random:()=>value}).ok,false);assert.equal(s.p.getDynamicProperty('rpg:rune_bag_v1'),old);}
});
test('rune storage failure rolls back whole bag and material',()=>{
 const {p,a,m}=runes(),old=p.getDynamicProperty('rpg:rune_bag_v1'),write=p.setDynamicProperty.bind(p);let fail=true;p.setDynamicProperty=(k,v)=>{if(fail&&k==='rpg:rune_bag_v1'){fail=false;throw Error('test write');}write(k,v);};assert.equal(fuseEquipment(p,a,m,undefined,{random:()=>0}).ok,false);assert.equal(p.getDynamicProperty('rpg:rune_bag_v1'),old);
});
test('legacy +5 migration preserves effect, saves once and does not double again on rejoin',()=>{
 const p=player('migration');p.setDynamicProperty('rpg:rune_bag_v1',JSON.stringify({version:1,nextId:2,runes:[{uid:'r1',id:'absorption',level:5}],equipped:['r1',null,null]}));const migrated=readRuneBag(p);assert.equal(migrated.version,2);assert.equal(migrated.runes[0].level,10);assert.equal(migrated.runes[0].grade,0);writeRuneBag(p,migrated);assert.equal(readRuneBag(p).runes[0].level,10);assert.equal(getEquipmentBonuses(p).lifesteal,.12);
});
test('physical normal rune round trip retains count and bag grades',()=>{
 const p=player('tokens');p.slots[3]=new ItemStack('rpg:rune_power',3);assert.equal(depositRune(p,3).ok,true);assert.equal(p.slots[3].amount,2);const r=readRuneBag(p).runes[0];assert.equal(r.grade,0);assert.equal(withdrawRune(p,r.uid).ok,true);assert.equal(p.slots.filter(Boolean).reduce((n,i)=>n+i.amount,0),3);
});
test('common weapon +10 enhancement uses costs, caps, handles destruction and preserves grade',()=>{
 const p=player('weapon');p.equipment.set(EquipmentSlot.Mainhand,item(COMMON_WEAPONS[0].id,4,9));setWallet(p,{gold:10000,stone:100,dust:0});const q=enhancementQuote(p,'weapon',EquipmentSlot.Mainhand);assert.equal(q.level,9);const result=enhanceEquipped(p,'weapon',EquipmentSlot.Mainhand,q.fingerprint,{random:()=>0});assert.equal(result.level,10);assert.equal(p.equipment.get(EquipmentSlot.Mainhand).getDynamicProperty(RARITY_KEY),4);assert.equal(enhanceEquipped(p,'weapon',EquipmentSlot.Mainhand).ok,false);
 p.equipment.set(EquipmentSlot.Mainhand,item(COMMON_WEAPONS[0].id,4,9));assert.equal(enhanceEquipped(p,'weapon',EquipmentSlot.Mainhand,undefined,{random:()=>.99}).outcome,'destroy');assert.equal(p.equipment.get(EquipmentSlot.Mainhand),undefined);
});
test('fusion menu displays chance, cancel never consumes and confirm consumes exact selected material',async()=>{
 const p=pair();replies.push({selection:0},{selection:0},{selection:0},{canceled:true});await openFusionMenu(p);assert.ok(p.slots[4]);const f=forms.find(f=>f.heading==='등급 합성 확인');assert.match(f.text,/성공률 100%/);assert.match(f.text,/에픽.*\+0/);
 const old=Math.random;Math.random=()=>0;try{replies.push({selection:0},{selection:0},{selection:1},{canceled:true});await openFusionMenu(p);}finally{Math.random=old;}assert.equal(p.slots[4],undefined);assert.equal(p.slots[3].getDynamicProperty(RARITY_KEY),2);
});

test('promotion rejects missing, wrong-type and insufficient-level books before RNG or material loss',()=>{
 for(const enchants of [undefined,[{type:{id:'protection'},level:4}],[{type:{id:'sharpness'},level:4}]]){
  const p=pair();p.slots[9]=enchants?new ItemStack('minecraft:enchanted_book'):undefined;if(enchants)p.slots[9].enchantments=enchants;
  const before=p.slots.map(gearFingerprint);let rolled=false;
  assert.equal(fuseEquipment(p,inv(3),inv(4),undefined,{random:()=>{rolled=true;return 0;}}).ok,false);
  assert.equal(rolled,false);assert.deepEqual(p.slots.map(gearFingerprint),before);
 }
});
test('armor and weapon promotion each consume one correct book on success and failure',()=>{
 for(const id of ['rpg:adventurer_helmet',COMMON_WEAPONS[0].id])for(const roll of [0,.99]){
  const p=pair(id,1,5);p.slots[9].amount=2;const result=fuseEquipment(p,inv(3),inv(4),undefined,{random:()=>roll});
  assert.equal(result.ok,true);assert.equal(p.slots[9].amount,1);assert.equal(Boolean(p.slots[4]),roll!==0);
 }
});
test('a failed material write restores the already-debited promotion book',()=>{
 const p=pair(),get=p.getComponent.bind(p),invComponent=get('minecraft:inventory').container,set=invComponent.setItem;let fail=true;
 invComponent.setItem=(slot,item)=>{if(slot===4&&fail){fail=false;throw Error('material');}set(slot,item);};
 const before=p.slots.map(gearFingerprint);assert.equal(fuseEquipment(p,inv(3),inv(4),undefined,{random:()=>0}).ok,false);assert.deepEqual(p.slots.map(gearFingerprint),before);
});
