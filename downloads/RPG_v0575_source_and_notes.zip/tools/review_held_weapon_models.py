"""Offline geometry diagnostic, NOT a Bedrock screenshot or source texture edit.

Optional review renderer: Pillow + NumPy + matplotlib. Produces original-sprite
coordinate sheets, a fixed-camera projection, and an old/new hand-error report.
"""
from pathlib import Path
import json
import math
import numpy as np
from PIL import Image, ImageDraw
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
RP=ROOT/'RPG_RP_v0575'
OUT=ROOT/'review'
OUT.mkdir(exist_ok=True)
pose=json.loads((ROOT/'held_weapon_pose.json').read_text())
models=json.loads((RP/'models/entity/upright_weapons.geo.json').read_text())['minecraft:geometry']
anims=json.loads((RP/'animations/upright_weapons.animation.json').read_text())['animations']

def rot(native):
    x,y,z=np.radians([-native[0],-native[1],native[2]])
    rx=np.array([[1,0,0],[0,np.cos(x),-np.sin(x)],[0,np.sin(x),np.cos(x)]])
    ry=np.array([[np.cos(y),0,np.sin(y)],[0,1,0],[-np.sin(y),0,np.cos(y)]])
    rz=np.array([[np.cos(z),-np.sin(z),0],[np.sin(z),np.cos(z),0],[0,0,1]])
    return rz@ry@rx

def uv_point(m,xy,face='north'):
    b=m['bones'][1];c=b['cubes'][0];uv=c['uv'][face]
    x=(xy[0]-uv['uv'][0])/uv['uv_size'][0]
    y=(xy[1]-uv['uv'][1])/uv['uv_size'][1]
    lo=-c['origin'][0]-c['size'][0];hi=-c['origin'][0]
    p=np.array([hi+(lo-hi)*x if face=='north' else lo+(hi-lo)*x,c['origin'][1]+c['size'][1]*(1-y),0])
    pivot=np.array(b['pivot'])*[-1,1,1]
    return pivot+rot(b['rotation'])@(p-pivot)

for page in range(3):
    entries=pose['items'][page*15:(page+1)*15]
    fig,axes=plt.subplots(3,5,figsize=(18,11),facecolor='#c0c8d0')
    for ax,s in zip(axes.flat,entries):
        im=Image.open(RP/(s['texture']+'.png'))
        ax.set_facecolor('#293341');ax.imshow(im);ax.set_title(s['id'][4:]+' / '+s['kind'],fontsize=8)
        ax.scatter(*s['gripPixel'],c='lime',s=55,marker='+')
        ax.plot([s['gripPixel'][0],s['axisPixel'][0]],[s['gripPixel'][1],s['axisPixel'][1]],color='orange',alpha=.7,lw=1)
        ax.set_xticks([0,im.width//2,im.width]);ax.set_yticks([0,im.height//2,im.height]);ax.grid(alpha=.25)
    for ax in axes.flat[len(entries):]:ax.axis('off')
    fig.tight_layout();fig.savefig(OUT/('measured_grips_'+str(page+1)+'.png'),dpi=115);plt.close(fig)

# A software projection of the exported JSON/UVs, not of helper expectations.
# Common weapons plus the Sun axe match the user's reported problem.
selected=pose['items'][:7]+[s for s in pose['items'] if s['id']=='rpg:sun_heir_axe']
W,H=960,410
sheet=Image.new('RGB',(W,H*len(selected)),(31,40,53))
for row,s in enumerate(selected):
    m=next(m for m in models if m['description']['identifier']=='geometry.rpg.hand.'+s['id'][4:])
    image=Image.open(RP/(s['texture']+'.png')).convert('RGBA')
    for mode in ['third','first']:
        width=300 if mode=='third' else 660
        canvas=Image.new('RGBA',(width,H),(37,49,65,255))
        draw=ImageDraw.Draw(canvas)
        draw.text((10,8),s['id'][4:],fill='white')
        draw.text((10,24),mode+' / OFFLINE GEOMETRY GUIDE',fill='#b9c9df')
        anchor=np.array([0,24,0])
        matrix=rot(anims['animation.rpg.hand.'+mode]['bones']['hand_anchor']['rotation'])
        if mode=='first':
            guide=rot([95,-45,115]);shoulder=np.array([5,22,0])
            palm=guide@(np.array([6,15,-1])-shoulder)+shoulder+[-13.5,-10,12]
            matrix=guide@matrix
            focal=width/(2*math.tan(math.radians(35)))
            project=lambda p:np.array([width/2-p[0]/p[2]*focal,H/2-(p[1]-24)/p[2]*focal])
        else:
            palm=np.array([6,15,-1]);project=lambda p:np.array([width/2-p[0]*6.4,H*.79-p[1]*6.4])
            for (x1,y1,x2,y2),color in [((-4,12,4,24),'#64758a'),((-4,24,4,32),'#b29b85'),((4,12,8,24),'#8696aa'),((-8,12,-4,24),'#8696aa'),((-4,0,-.5,12),'#52667f'),((.5,0,4,12),'#52667f')]:
                a,b=project([x1,y2,0]),project([x2,y1,0]);draw.rectangle((min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1])),fill=color)
        src=np.array([[0,0],[image.width,0],[image.width,image.height],[0,image.height]],dtype=float)
        dst=np.array([project(palm+matrix@(uv_point(m,xy)-anchor)) for xy in src])
        # PIL expects the inverse homography: screen coordinates -> source UV.
        a=[];b=[]
        for (x,y),(u,v) in zip(dst,src):
            a.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);b.extend([u,v])
        coefficients=np.linalg.solve(np.array(a),np.array(b))
        sprite=image.transform((width,H),Image.Transform.PERSPECTIVE,coefficients,resample=Image.Resampling.NEAREST)
        canvas=Image.alpha_composite(canvas,sprite)
        d=ImageDraw.Draw(canvas);p=project(palm)
        d.ellipse((p[0]-3,p[1]-3,p[0]+3,p[1]+3),outline='#4cffa3',width=1)
        sheet.paste(canvas.convert('RGB'),(0 if mode=='third' else 300,row*H))
sheet.save(OUT/'held_models_projection.png')

oldpath=ROOT.parent/'rpg-v0572/RPG_RP_v0572/models/entity/upright_weapons.geo.json'
report={'meaning':'Euclidean model-space distance of measured grip from bound palm before camera rotation; units = 1/16 block','items':[]}
old=json.loads(oldpath.read_text())['minecraft:geometry'] if oldpath.exists() else []
for s,m in zip(pose['items'],models):
    xy=np.array(s['gripPixel'])+.5
    newerr=max(float(np.linalg.norm(uv_point(m,xy,f)-[0,24,0])) for f in ['north','south'])
    prev=next((g for g in old if g['description']['identifier'].endswith('.'+s['id'][4:])),None)
    olderr=float(np.linalg.norm(uv_point(prev,xy)-[0,24,0])) if prev else None
    report['items'].append({'id':s['id'],'old_v0572_error':olderr,'new_v0575_error':newerr})
report['max_new_error']=max(r['new_v0575_error'] for r in report['items'])
assert report['max_new_error']<1e-7
(OUT/'weapon_hand_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print('Reviewed',len(models),'models; max new grip error:',report['max_new_error'])
for r in report['items']:
    if r['id'] in ['rpg:common_flame_greatsword','rpg:sun_heir_axe']:print(r)
