"""Build held sprites around measured grips, without editing any source PNG.

Bedrock's bound-item frame subtracts 24 Y. Its model import also mirrors X;
per-face UVs must be included when placing a texture pixel at the hand pivot.
See v0575_무기_좌표_검증.md for the coordinate contract and references.
"""
from pathlib import Path
import hashlib
import json
import math
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
RP, BP = ROOT / 'RPG_RP_v0575', ROOT / 'RPG_BP_v0575'
HAND = [0, 24, 0]
FIRST_ARM_NATIVE = [95, -45, 115]
# Viewing-space (Blockbench) axes: blade vertical with a 10 degree inward lean, broad face toward camera.
FIRST_VIEW = [0, 0, -10]
THIRD_NATIVE = [0, 0, -10]
EXCLUDED = {'rpg:war_god_gauntlets', 'rpg:fighter_fist',
            'rpg:fist_bone_fist', 'rpg:apprentice_fist'}


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def rotation(angles):
    """Viewing-space Rz * Ry * Rx, as used by Blockbench's ZYX bones."""
    x, y, z = map(math.radians, angles)
    cx, sx, cy, sy, cz, sz = (math.cos(x), math.sin(x), math.cos(y),
                              math.sin(y), math.cos(z), math.sin(z))
    return [[cz*cy, cz*sy*sx-sz*cx, cz*sy*cx+sz*sx],
            [sz*cy, sz*sy*sx+cz*cx, sz*sy*cx-cz*sx],
            [-sy, cy*sx, cy*cx]]


def compose(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(3))
             for j in range(3)] for i in range(3)]


def first_person_rotation():
    # Native Bedrock X/Y rotations have the opposite sign in viewing space.
    g = rotation([-FIRST_ARM_NATIVE[0], -FIRST_ARM_NATIVE[1], FIRST_ARM_NATIVE[2]])
    inverse = [list(row) for row in zip(*g)]
    m = compose(inverse, rotation(FIRST_VIEW))
    x = math.atan2(m[2][1], m[2][2])
    y = math.asin(max(-1, min(1, -m[2][0])))
    z = math.atan2(m[1][0], m[0][0])
    return [round(-math.degrees(x), 9), round(-math.degrees(y), 9),
            round(math.degrees(z), 9)]


def main():
    atlas = json.loads((RP / 'textures/item_texture.json').read_text())['texture_data']
    raw = (BP / 'scripts/data/classWeapons.js').read_text()
    classes = json.loads(raw.split('Object.freeze(', 1)[1].split(');', 1)[0])
    raw = (BP / 'scripts/data/commonWeapons.js').read_text()
    common = json.loads(raw.split('=', 1)[1].strip().rstrip(';'))
    profiles = json.loads((ROOT / 'weapon_hand_profiles.json').read_text())['items']
    by_id = {p['id']: p for p in profiles}
    expected = {e['id'] for e in common + classes} - EXCLUDED
    assert set(by_id) == expected, 'Missing/extra manually reviewed weapon profile'
    specs, geometries = [], []
    for entry in common + classes:
        ident = entry['id']
        if ident in EXCLUDED:
            continue
        key, profile = ident[4:], by_id[ident]
        item = json.loads((BP / 'items' / (key + '.json')).read_text())['minecraft:item']
        texture = atlas[item['components']['minecraft:icon']]['textures']
        assert texture == profile['texture'], ident
        path = RP / (texture + '.png')
        assert hashlib.sha256(path.read_bytes()).hexdigest() == profile['sha256'], ident
        image = Image.open(path).convert('RGBA')
        assert list(image.size) == profile['imageSize'], ident
        gx, gy = profile['gripPixel']
        ax, ay = profile['axisPixel']
        assert 0 <= gx < image.width and 0 <= gy < image.height, ident
        assert image.getpixel((gx, gy))[3] >= 128, (ident, 'Grip must touch the item')
        assert gy > ay, (ident, 'Axis must point toward the upper limb/blade')
        turn = math.degrees(math.atan2(ax-gx, gy-ay))
        # Pixels refer to their centers. Negative north UV + mirrored model X
        # means origin X is (grip - width), not -grip.
        u, gx, gy = 32/image.width, gx+.5, gy+.5
        bones = [
            {'name': 'hand_anchor',
             'binding': 'q.item_slot_to_bone_name(c.item_slot)', 'pivot': HAND},
            {'name': 'sprite', 'parent': 'hand_anchor', 'pivot': HAND,
             'rotation': [0, 0, turn], 'cubes': [{
                 'origin': [(gx-image.width)*u, 24+(gy-image.height)*u, -.075],
                 'size': [32, image.height*u, .15],
                 'uv': {
                     'north': {'uv': [image.width, 0], 'uv_size': [-image.width, image.height]},
                     'south': {'uv': [0, 0], 'uv_size': [image.width, image.height]}
                 }
             }]}
        ]
        gid = 'geometry.rpg.hand.' + key
        geometries.append({
            'description': {'identifier': gid, 'texture_width': image.width,
                            'texture_height': image.height, 'visible_bounds_width': 6,
                            'visible_bounds_height': 6, 'visible_bounds_offset': [0, 1.5, 0]},
            'bones': bones
        })
        write(RP / 'attachables' / (key + '.json'), {
            'format_version': '1.10.0', 'minecraft:attachable': {'description': {
                'identifier': ident,
                'materials': {'default': 'entity_alphatest', 'enchanted': 'entity_alphatest_glint'},
                'textures': {'default': texture, 'enchanted': 'textures/misc/enchanted_item_glint'},
                'geometry': {'default': gid},
                'animations': {'first': 'animation.rpg.hand.first', 'third': 'animation.rpg.hand.third'},
                'scripts': {'animate': [{'first': 'context.is_first_person'},
                                        {'third': '!context.is_first_person'}]},
                'render_controllers': ['controller.render.item_default']
            }}
        })
        # BP values already have this setting; keep both definitions consistent.
        for base in [RP, BP]:
            f = base / 'items' / (key + '.json')
            if f.exists():
                d = json.loads(f.read_text())
                c = d['minecraft:item']['components']
                c.pop('minecraft:render_offsets', None)
                c['minecraft:hand_equipped'] = True
                write(f, d)
        specs.append({**profile, 'nativeSide': 16, 'heldSide': 32,
                      'gripUv': [gx, gy], 'normalizeZ': turn})
    write(RP / 'models/entity/upright_weapons.geo.json', {
        'format_version': '1.16.0', 'minecraft:geometry': geometries
    })
    animations = {}
    for name, angles in [('first', first_person_rotation()), ('third', THIRD_NATIVE)]:
        animations['animation.rpg.hand.' + name] = {
            'loop': True, 'bones': {'hand_anchor': {'rotation': angles}}
        }
    write(RP / 'animations/upright_weapons.animation.json', {
        'format_version': '1.10.0', 'animations': animations
    })
    write(ROOT / 'held_weapon_pose.json', {
        'frame': 'bound hand +24Y with mirrored-X per-face UV mapping',
        'handPivot': HAND, 'firstArmNative': FIRST_ARM_NATIVE,
        'firstViewRotation': FIRST_VIEW, 'items': specs
    })
    print('Built', len(specs), 'double-size models with measured grips and zero hand offset.')


if __name__ == '__main__':
    main()
