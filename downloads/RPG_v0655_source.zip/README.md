# RPG v0.6.55 · 투신 파티클

난식은 흰 테두리와 푸른 꼬리가 있는 기탄을 16방향으로 네 차례 발사합니다. 귀심 팔중은 양손을 번갈아 같은 기탄을 정면으로 쏩니다. 폭멸타·난참은 청백색 충격파가 전방으로 갈라지고, 폭열권·파황각은 발차기 궤적을 따라 빛줄기가 솟습니다. 명중 지점과 천멸격 준비 순간에는 짧은 섬광이 터집니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.55로 적용하고 월드를 다시 여세요. 회귀 검사는 모의 API와 팩 데이터를 사용합니다. 실제 엔진에서 보는 밝기와 잔상은 인게임 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0655
```
