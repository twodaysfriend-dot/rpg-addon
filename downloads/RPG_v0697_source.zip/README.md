# RPG v0.6.97 · 건축 태그와 소유지 상자 보호

- 관리자는 `/tag "플레이어 이름" add rpg_builder`로 건축 권한을 줄 수 있습니다. 태그 보유자는 마을과 던전의 건축 제한을 통과해 블록을 설치하거나 부술 수 있습니다. `/tag "플레이어 이름" remove rpg_builder`로 권한을 회수합니다.
- 소유지가 등록된 청크의 상자는 소유자와 같은 길드원만 열 수 있습니다. 파티만 같은 플레이어와 건축 태그 보유자도 상자를 열려면 소유자 또는 같은 길드원이어야 합니다.
- 일반·덫·구리 상자에 적용되며, 두 청크에 걸친 큰 상자는 양쪽 토지의 접근 권한을 확인합니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.97로 활성화하세요. 모의 테스트에서 건축 권한 지급·회수, 길드 탈퇴 후 접근 차단 및 청크 경계의 큰 상자 권한을 검증했습니다. 실제 Bedrock 월드에서의 건축 및 상자 조작은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
python3 tools/build_protected_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0697
```
