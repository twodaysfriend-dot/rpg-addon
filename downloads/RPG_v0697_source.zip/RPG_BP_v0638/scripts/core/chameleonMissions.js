import {world,system} from '@minecraft/server';
import {CHAMELEON_MISSIONS,CHAMELEON_MISSION_LEVEL,MISSION_HYDRA,MISSION_HYDRA_LEVEL,MISSION_HYDRA_TAG} from '../data/chameleonMissions.js';
import {getJobId} from './playerData.js';
import {getLevel} from './stats.js';
import {readChameleonProgress,saveChameleonProgress,deliverSkillBooks} from './chameleonProgress.js';
import {spawnRegion} from './spawnEffects.js';
import {applyMonsterLevel} from './monsterLevels.js';
import {isRaidMob} from './spawnPolicy.js';

const HUNT_OWNER='rpg:chameleon_hunt_owner';
const MISSION_IDS=Object.keys(CHAMELEON_MISSIONS);
const KILL_MISSIONS={'minecraft:wither':'wither','minecraft:elder_guardian':'guardian','rpg:elite_deathworm':'worm','minecraft:shulker':'shulker'};
const SURVIVAL_MODES=new Set(['survival','adventure']);
const RAID_MAX_AGE=30*60*1000;
const HUNT_RADIUS=16, HYDRA_LIMIT=36;
const dimName=id=>id?.replace(/^minecraft:/,'');
const inOverworld=source=>dimName(source.dimension?.id)==='overworld';
const horizontal=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const message=(p,text)=>{try{p.sendMessage(text);}catch{}};

export function missionEligible(p){
 return getJobId(p)==='chameleon'&&getLevel(p)>=CHAMELEON_MISSION_LEVEL;
}
export function missionSurvival(p){
 return p?.typeId==='minecraft:player'&&p.isValid&&SURVIVAL_MODES.has(String(p.getGameMode()).toLowerCase());
}
function rollMission(previous,random){
 const pool=MISSION_IDS.filter(id=>id!==previous?.id);
 const id=pool[Math.floor(random()*pool.length)];
 const mission={id,count:0,serial:(previous?.serial??0)+1,assignedAt:Date.now()};
 if(id==='hydra'){
  const town=spawnRegion();
  const insideTown=target=>town&&dimName(town.dimId)==='overworld'&&
   target.x>=town.x-24&&target.x<town.x+town.size+24&&target.z>=town.z-24&&target.z<town.z+town.size+24;
  const coordinate=()=>Math.floor(random()*1000)-500;
  let target={x:coordinate(),z:coordinate()};
  for(let i=0;i<8&&insideTown(target);i++)target={x:coordinate(),z:coordinate()};
  if(insideTown(target))target=[{x:-500,z:-500},{x:499,z:499}].find(point=>!insideTown(point));
  mission.target=target;
 }
 return mission;
}
function notice(p,mission){
 const details=mission.target?` · X ${mission.target.x}, Z ${mission.target.z}`:'';
 message(p,`§b[모방 수련] 새 미션 · ${CHAMELEON_MISSIONS[mission.id].name}${details} · /rpg:skillbook`);
}
export function activeChameleonMission(p){
 if(!missionEligible(p))return undefined;
 return readChameleonProgress(p).mission;
}
export function ensureChameleonMission(p,random=Math.random){
 if(!missionEligible(p))return undefined;
 const state=readChameleonProgress(p);
 if(state.mission)return state.mission;
 state.mission=rollMission(undefined,random);
 saveChameleonProgress(p,state);
 notice(p,state.mission);
 return state.mission;
}
export function chameleonMissionText(mission){
 const def=CHAMELEON_MISSIONS[mission.id];
 const target=mission.target?`\n§e목표 좌표 X ${mission.target.x}, Z ${mission.target.z} · 지상\n목표 16칸 안에 접근하면 히드라가 등장합니다.§r`:'';
 return `${def.name}\n\n${def.text}${target}\n\n진행 ${mission.count}/${def.goal} · 보상 카멜레온 랜덤 스킬북 1권\n완료하면 다음 미션이 자동 배정됩니다.`;
}
// Save payout and rotation together before attempting inventory delivery.
export function advanceChameleonMission(p,id,serial,amount=1,random=Math.random){
 if(!missionSurvival(p)||!missionEligible(p)||!Number.isSafeInteger(amount)||amount<=0)return false;
 const state=readChameleonProgress(p),mission=state.mission;
 if(mission?.id!==id||mission.serial!==serial)return false;
 const def=CHAMELEON_MISSIONS[id];
 mission.count=Math.min(def.goal,mission.count+amount);
 if(mission.count<def.goal){saveChameleonProgress(p,state);return true;}
 return completeMission(p,state,mission,random);
}
function completeMission(p,state,mission,random){
 state.pendingBooks++;
 state.mission=rollMission(mission,random);
 saveChameleonProgress(p,state);
 let delivered=0;
 try{delivered=deliverSkillBooks(p);}catch(error){console.warn('[RPG mission reward delivery] '+error);}
 message(p,`§a[모방 수련] ${CHAMELEON_MISSIONS[mission.id].name} 완료 · 랜덤 스킬북 1권 ${delivered?'지급':'보상함 저장'}`);
 notice(p,state.mission);
 return true;
}
export function creditChameleonDungeon(p,receipt){
 if(receipt.tier!==9||receipt.solo!==true||!Number.isFinite(receipt.startedAt)||!missionSurvival(p)||!missionEligible(p))return false;
 const state=readChameleonProgress(p),mission=state.mission;
 if(mission?.id!=='dungeon'||receipt.startedAt<mission.assignedAt||(state.missionDungeonRun??0)>=receipt.runId)return false;
 // The receipt ID, reward and rotation share the same player property write.
 state.missionDungeonRun=receipt.runId;
 return completeMission(p,state,mission,Math.random);
}

function nearEndCity(dead){
 const dim=dead.dimension,at=dead.location;
 if(dimName(dim?.id)!=='the_end'||Math.hypot(at.x,at.z)<768)return false;
 // End Cities generate shulkers on purpur and end stone brick structures.
 for(const y of [-4,-2,-1,0,1,2,4])for(const [x,z] of [[0,0],[2,0],[-2,0],[0,2],[0,-2]]){
  let type;
  try{type=dim.getBlock({x:Math.floor(at.x)+x,y:Math.floor(at.y)+y,z:Math.floor(at.z)+z})?.typeId;}catch{continue;}
  if(type?.startsWith('minecraft:purpur')||type==='minecraft:end_bricks'||type==='minecraft:end_stone_bricks')return true;
 }
 return false;
}
export function recordChameleonMissionKill(p,dead){
 if(!missionSurvival(p)||dead.hasTag?.('rpg_town_manual_spawn'))return;
 const mission=activeChameleonMission(p);
 if(!mission)return;
 if(mission.id==='raid'&&inOverworld(dead)&&isRaidMob(dead)&&horizontal(p.location,dead.location)<=96){
  const state=readChameleonProgress(p);
  state.mission.raidKill={x:dead.location.x,z:dead.location.z,at:Date.now()};
  saveChameleonProgress(p,state);
  return;
 }
 if(mission.id==='hydra'){
  if(dead.typeId===MISSION_HYDRA&&dead.hasTag?.(MISSION_HYDRA_TAG)&&dead.id===mission.bossId){
   advanceChameleonMission(p,'hydra',mission.serial);
  }
  return;
 }
 if(KILL_MISSIONS[dead.typeId]!==mission.id)return;
 if(mission.id==='shulker'&&!nearEndCity(dead))return;
 advanceChameleonMission(p,mission.id,mission.serial);
}
export function isRaidVictoryEffect(type){
 const id=dimName(type);
 return id==='village_hero'||id==='hero_of_the_village';
}
export function recordMissionRaidWin({entity:p,effect}){
 if(!isRaidVictoryEffect(effect?.typeId))return false;
 if(!missionSurvival(p)||!inOverworld(p))return false;
 const mission=activeChameleonMission(p),kill=mission?.raidKill;
 if(mission?.id!=='raid'||!kill||Date.now()-kill.at>RAID_MAX_AGE||horizontal(p.location,kill)>128)return false;
 return advanceChameleonMission(p,'raid',mission.serial);
}

function tickHydra(p,mission){
 if(!inOverworld(p)||!missionSurvival(p)||!(p.getComponent('minecraft:health')?.currentValue>0))return;
 const dim=p.dimension,target=mission.target;
 const boss=mission.bossId?world.getEntity(mission.bossId):undefined;
 if(boss?.isValid&&(boss.getComponent('minecraft:health')?.currentValue??0)>0){
  if(horizontal(boss.location,target)>HYDRA_LIMIT&&horizontal(p.location,target)<=HYDRA_LIMIT){
   const ground=dim.getTopmostBlock(target);
   if(ground)boss.teleport({x:target.x+.5,y:ground.location.y+1,z:target.z+.5},{dimension:dim});
  }
  return;
 }
 if(horizontal(p.location,target)>HUNT_RADIUS)return;
 const ground=dim.getTopmostBlock(target);
 if(!ground)return; // The target must be loaded before making a new encounter.
 const at={x:target.x+.5,y:ground.location.y+1,z:target.z+.5};
 if(Math.abs(p.location.y-at.y)>32||at.y>=dim.heightRange.max-2)return;
 const hunt=JSON.stringify([p.id,mission.serial]);
 const nearby=dim.getEntities({type:MISSION_HYDRA,location:at,maxDistance:HYDRA_LIMIT+8,tags:[MISSION_HYDRA_TAG]});
 const existing=nearby.find(entity=>entity.getDynamicProperty(HUNT_OWNER)===hunt&&entity.getComponent('minecraft:health')?.currentValue>0);
 if(existing){
  const state=readChameleonProgress(p);
  state.mission.bossId=existing.id;
  saveChameleonProgress(p,state);
  return;
 }
 const spawned=dim.spawnEntity(MISSION_HYDRA,at);
 try{
  spawned.addTag(MISSION_HYDRA_TAG);
  spawned.setDynamicProperty(HUNT_OWNER,hunt);
  if(!applyMonsterLevel(spawned,MISSION_HYDRA_LEVEL))throw Error('히드라 레벨 적용 실패');
  const state=readChameleonProgress(p);
  state.mission.bossId=spawned.id;
  saveChameleonProgress(p,state);
 }catch(error){try{spawned.remove();}catch{}throw error;}
 message(p,'§c[모방 수련] Lv.200 히드라가 나타났습니다!');
}
export function tickChameleonMissions(){
 for(const p of world.getAllPlayers())try{
  const mission=ensureChameleonMission(p);
  if(mission?.id==='hydra')tickHydra(p,mission);
 }catch(error){console.warn('[RPG chameleon mission tick] '+error);}
}
