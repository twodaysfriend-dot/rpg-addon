import { world } from '@minecraft/server';

export const SUPER_SANDBAG_ID = 'rpg:super_sandbag';
const DEFAULT_NAME = '§c슈퍼 샌드백 §f· HP ∞';
const damageKey = player => 'rpg:super_sandbag_damage_' + player.id;

function showDamage(dummy, player, damage) {
  const name = player.name.replace(/§./g, '');
  const amount = Number(damage.toFixed(2)).toLocaleString('en-US');
  dummy.nameTag = `${DEFAULT_NAME}\n§f${name} · 누적 피해 §e${amount}`;
}

export function recordSuperSandbagDamage(dummy, player, damage) {
  if (player?.typeId !== 'minecraft:player' || !Number.isFinite(damage) || damage <= 0) return;
  const key = damageKey(player);
  const total = (dummy.getDynamicProperty(key) ?? 0) + damage;
  dummy.setDynamicProperty(key, total);
  showDamage(dummy, player, total);
}

export function registerSuperSandbag() {
  const initialize = ({entity}) => {
    if (entity.typeId === SUPER_SANDBAG_ID && !entity.nameTag) entity.nameTag = DEFAULT_NAME;
  };
  world.afterEvents.entitySpawn.subscribe(initialize);
  world.afterEvents.entityLoad.subscribe(initialize);
  world.afterEvents.entityHurt.subscribe(({hurtEntity}) => {
    if (hurtEntity.typeId !== SUPER_SANDBAG_ID) return;
    try {
      const health = hurtEntity.getComponent('minecraft:health');
      if (health && health.currentValue < health.effectiveMax) health.resetToMaxValue();
    } catch {}
  });
  world.afterEvents.playerInteractWithEntity.subscribe(({player, target}) => {
    if (target.typeId !== SUPER_SANDBAG_ID || !player.isSneaking) return;
    target.setDynamicProperty(damageKey(player), undefined);
    showDamage(target, player, 0);
  });
}
