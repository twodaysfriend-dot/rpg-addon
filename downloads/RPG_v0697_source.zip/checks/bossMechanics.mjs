import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root=process.argv[2]??'.';
const read=path=>JSON.parse(fs.readFileSync(root+'/'+path));
const script=path=>fs.readFileSync(root+'/RPG_BP_v0638/scripts/core/'+path,'utf8');
const context=vm.createContext({console});
const dim={id:'overworld',getPlayers:()=>players.filter(p=>p.dimension===dim),getEntities:({type})=>type===boss?.typeId?[boss]:[]};
const empty={id:'nether',getPlayers:()=>[]};
const timers=[],animations=[],hits=[],particles=[];
const hooks={};
const world={getDimension:id=>id==='overworld'?dim:empty,afterEvents:new Proxy({},{
 get:(_obj,key)=>({subscribe:fn=>hooks[key]=fn}),
})};
const intervals=new Map();let nextId=0;
const system={currentTick:0,
 runInterval:fn=>{const id=++nextId;intervals.set(id,fn);return id;},
 clearRun:id=>intervals.delete(id),
 runTimeout:(fn,delay)=>timers.push({fn,delay,tick:system.currentTick+delay}),
};
let players=[],boss,wall=false,frozen=false;
const dist3=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
const norm3=v=>{const length=Math.hypot(v.x,v.y,v.z)||1;return {x:v.x/length,y:v.y/length,z:v.z/length};};
const bindings={world,system,isBloodedgePool:()=>false,EntityDamageCause:{fire:'fire',magic:'magic'},monsterAttackMultiplier:()=>1,dist3,norm3,
 healthAlive:e=>e.getComponent().currentValue>0,isTimeFrozen:e=>frozen&&e===boss,
 clearBlockPath:(_d,a,b)=>!wall || Math.max(a.z,b.z)<3 || Math.min(a.z,b.z)>3,
 particle:(dim,id,pos)=>particles.push({id,pos}),sound:()=>{},
 RESURRECTION_PENDING:'rpg:resurrection_pending',
 deferStoppedDamage:()=>false,scriptedHit:(_t,_b,callback)=>callback(),
 setCombatHealth:(_t,_b,hp,next)=>{hp.currentValue=next;},
 noteManualDamage:(_b,target,amount)=>hits.push({id:target.id,amount,manual:true}),
};
const motion=new vm.SourceTextModule(script('bossMotion.js'),{context});
const damage=new vm.SourceTextModule(script('bossDamage.js'),{context});
const mechanics=new vm.SourceTextModule(script('bossMechanics.js'),{context});
await mechanics.link(async specifier=>{
 if(specifier==='./bossMotion.js')return motion;
 if(specifier==='./bossDamage.js')return damage;
 return new vm.SyntheticModule(Object.keys(bindings),function(){
  for (const [name,value] of Object.entries(bindings)) this.setExport(name,value);
 },{context});
});
await mechanics.evaluate();
const {nearestBossPlayer,registerBossMechanics}=mechanics.namespace;
registerBossMechanics();
const update=()=>intervals.get(1)();
function advanceProjectiles(ticks){
 for(let i=0;i<ticks;i++){
  system.currentTick++;
  for(let j=timers.length-1;j>=0;j--)if(timers[j].tick<=system.currentTick)timers.splice(j,1)[0].fn();
  for(const [id,fn] of intervals)if(id!==1)fn();
 }
}
function player(id,x,z,mode='survival',dimension=dim){
 const hp={currentValue:100};
 return {id,dimension,location:{x,y:0,z},getGameMode:()=>mode,getComponent:()=>hp,
  applyDamage(amount,options){
   hp.currentValue-=amount;hits.push({id,amount,cause:options.cause});return true;
  },
  setOnFire:seconds=>hits.push({id,seconds}),addEffect:()=>{}};
}
function actor(type){
 return {id:type,typeId:'rpg:'+type,dimension:dim,location:{x:0,y:0,z:0},getComponent:()=>({currentValue:100}),setRotation:()=>{},playAnimation:name=>animations.push(name)};
}
const mapping={rock_golem_boss:['eruption',24,4.5],cyclops_boss:['eye_beam',22,1.5],hydra_boss:['fire_breath',18,0],tech_block_golem_boss:['arc_field',22,3.2],elite_deathworm:['sand_rupture',20,2]};
for(const [type,[attack,windup,widened]] of Object.entries(mapping)){
 boss=actor(type);
 const nearest=player('nearest',0,5);nearest.applyDamage=()=>false;
 const edge=player('edge',widened,5);
 players=[player('far',10,12),player('creative',0,1,'creative'),nearest,player('other',0,1,'survival',empty)];
 if(widened)players.push(edge);
 assert.equal(nearestBossPlayer(boss,players,38,1).id,'nearest');
 system.currentTick+=500;update();system.currentTick+=40;update();
 assert.equal(hits.length,0,'wind-up deals no damage');
 assert.equal(animations.at(-1),'animation.rpg.'+type+'.'+attack);
 assert.equal(timers[0].delay,windup);
 assert.equal(motion.namespace.playBossMotion(boss),false,'melee motion cannot interrupt windup');
 if(type==='hydra_boss'){
  assert.deepEqual(timers.map(timer=>timer.delay),[18,23,28]);
  advanceProjectiles(19);
  assert.equal(intervals.size,2,'first shot launched');
  nearest.location.x=6; // Move after launch, outside the straight initial trajectory.
  advanceProjectiles(60);
  assert.deepEqual(hits.filter(hit=>hit.id==='nearest'&&hit.manual).map(hit=>hit.amount),[6.5,6.5,6.5]);
  assert.equal(hits.filter(hit=>hit.id==='nearest'&&hit.seconds===3).length,3);
  assert.equal(nearest.getComponent().currentValue,80.5);
  assert.equal(intervals.size,1);
 }else{
  advanceProjectiles(windup);
  assert.ok(hits.some(hit=>hit.id==='nearest'&&hit.manual));
  assert.ok(hits.some(hit=>hit.id==='edge'&&hit.amount>0),'expanded area hits beyond its old boundary');
  assert.equal(hits.filter(hit=>hit.id==='edge').length,1,'native hit counts once even across overlapping fields');
 }
 assert.ok(hits.every(hit=>hit.id==='nearest'||hit.id==='edge'));
 hits.length=0;
}
boss=actor('hydra_boss');
players=[player('melee',0,4.99),player('tail-edge',-5.4,0)];
system.currentTick+=500;update();system.currentTick+=40;update();
assert.match(animations.at(-1),/tail_sweep$/);
advanceProjectiles(17);
assert.ok(hits.some(hit=>hit.id==='tail-edge'&&hit.amount===10),'tail sweep retains its damage and range');
hits.length=0;
players=[player('near',0,5)];
system.currentTick+=200;wall=true;update();
assert.equal(timers.length,0,'wall blocks initial target acquisition');
wall=false;update();assert.equal(timers.length,3);
advanceProjectiles(18);wall=true;
advanceProjectiles(60);assert.equal(hits.length,0,'fireballs stop at a wall encountered in flight');
system.currentTick+=200;wall=false;update();
advanceProjectiles(18);frozen=true;
advanceProjectiles(60);assert.equal(hits.length,0,'freeze cancels in-flight and pending shots');
frozen=false;
assert.ok(particles.some(p=>p.id==='rpg:ghast_fireball'));
const protection=player('warded',0,5);protection.applyDamage=()=>false;
protection.getEffect=id=>id==='fire_resistance'?{}:undefined;
assert.equal(damage.namespace.applyBossMechanicDamage(boss,protection,6.5,'fire'),false);
assert.equal(protection.getComponent().currentValue,100);
protection.getEffect=()=>({amplifier:4});
assert.equal(damage.namespace.applyBossMechanicDamage(boss,protection,16),false);
assert.equal(protection.getComponent().currentValue,100);
protection.getEffect=()=>undefined;
protection.applyDamage=()=>{throw Error('engine rejected');};
assert.equal(damage.namespace.applyBossMechanicDamage(boss,protection,16),true);
assert.equal(protection.getComponent().currentValue,84);
const animationsDoc=read('RPG_RP_v0638/animations/rpg_boss_motion.animation.json').animations;
for(const [type,patterns] of Object.entries({...mapping,hydra_boss:['fire_breath','tail_sweep']})){
 const names=type==='hydra_boss'?patterns:patterns.slice(0,1);
 const entity=read('RPG_RP_v0638/entity/'+type+'.entity.json')['minecraft:client_entity'].description;
 const model=type==='elite_deathworm'?'rpg_elite_deathworm_v98':type;
 const bones=new Set(read('RPG_RP_v0638/models/entity/'+model+'.geo.json')['minecraft:geometry'][0].bones.map(b=>b.name));
 for(const name of names){
  const animation=animationsDoc[entity.animations[name]];
  assert.ok(animation.animation_length>0);
  for(const bone of Object.keys(animation.bones))assert.ok(bones.has(bone),type+' missing '+bone);
 }
}
console.log('Five custom boss patterns, six animations, nearest target, wider hit areas, native damage rejection fallback, three homing fireballs, immunity, wall and freeze checks passed');
