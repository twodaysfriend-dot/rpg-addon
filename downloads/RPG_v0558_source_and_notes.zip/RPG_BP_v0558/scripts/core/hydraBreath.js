import {world,system,EntityDamageCause} from '@minecraft/server';
import {healthAlive,norm3,dist3,isSolidAt,particle,sound} from './util.js';
import {playBossMotion} from './bossMotion.js';
export const HYDRA_BREATH=Object.freeze({range:24,targetRange:28,chargeTicks:20,duration:60,pulseTicks:10,cooldown:200,damage:6,burnSeconds:2});
const states=new Map();let registered=false;
function alive(e){try{return e?.isValid!==false&&healthAlive(e);}catch{return false;}}
function targetValid(b,p){try{return p?.typeId==='minecraft:player'&&alive(p)&&p.dimension.id===b.dimension.id&&!['creative','spectator'].includes(p.getGameMode?.());}catch{return false;}}
function eligible(b){return world.getAllPlayers().filter(p=>targetValid(b,p)&&dist3(b.location,p.location)<=HYDRA_BREATH.targetRange);}
function mouths(b,face){const p=b.location,side={x:-face.z,z:face.x};return [-1,0,1].map(n=>({x:p.x+face.x*5.2+side.x*n*5.5,y:p.y+(n?12.5:15),z:p.z+face.z*5.2+side.z*n*5.5}));}
export function startHydraBreath(b){
 if(b?.typeId!=='rpg:hydra_boss'||!alive(b))return false;
 const now=system.currentTick,old=states.get(b.id);if(old&&(old.phase!=='cooldown'||now<old.next))return false;
 const target=eligible(b).sort((a,c)=>dist3(a.location,b.location)-dist3(c.location,b.location))[0];if(!target)return false;
 const face=norm3({x:target.location.x-b.location.x,y:0,z:target.location.z-b.location.z});
 states.set(b.id,{phase:'charge',target,dimension:b.dimension.id,face,ready:now+HYDRA_BREATH.chargeTicks,next:now+HYDRA_BREATH.cooldown});
 playBossMotion(b,'breath');sound(b.dimension,'mob.blaze.breathe',b.location,{volume:1,pitch:.65});return true;
}
function pulse(b,s){
 const hit=new Set(),players=world.getAllPlayers().filter(p=>targetValid(b,p));
 for(const [i,origin]of mouths(b,s.face).entries()){
  const dir=s.directions[i];
  for(let d=0;d<=HYDRA_BREATH.range;d+=1.2){
   const at={x:origin.x+dir.x*d,y:origin.y+dir.y*d,z:origin.z+dir.z*d};if(isSolidAt(b.dimension,at))break;
   particle(b.dimension,'minecraft:basic_flame_particle',at);
   if(d%2.4<.1)particle(b.dimension,'minecraft:basic_smoke_particle',at);
   for(const p of players){
    if(hit.has(p.id))continue;const loc={x:p.location.x,y:p.location.y+.9,z:p.location.z};
    if(dist3(loc,at)>.85+d*.025)continue;
    hit.add(p.id);try{p.applyDamage(HYDRA_BREATH.damage,{cause:EntityDamageCause.fire??'fire',damagingEntity:b});p.setOnFire?.(HYDRA_BREATH.burnSeconds,true);}catch{}
   }
  }
 }
}
export function tickHydraBreath(b){
 const s=states.get(b?.id);if(!s)return;
 if(!alive(b)||b.dimension.id!==s.dimension){states.delete(b.id);return;}
 const now=system.currentTick;
 if(s.phase==='cooldown'){if(now>=s.next)startHydraBreath(b);return;}
 if(s.phase==='charge'){
  if(!targetValid(b,s.target)||dist3(b.location,s.target.location)>HYDRA_BREATH.targetRange+4){s.phase='cooldown';return;}
  for(const at of mouths(b,s.face)){particle(b.dimension,'minecraft:basic_flame_particle',at);particle(b.dimension,'minecraft:lava_particle',at);}
  if(now<s.ready)return;
  const aim={x:s.target.location.x,y:s.target.location.y+.9,z:s.target.location.z};s.directions=mouths(b,s.face).map(at=>norm3({x:aim.x-at.x,y:aim.y-at.y,z:aim.z-at.z}));s.phase='breath';s.end=now+HYDRA_BREATH.duration;s.nextPulse=now;
  sound(b.dimension,'mob.ghast.fireball',b.location,{volume:1.2,pitch:.7});
 }
 if(s.phase==='breath'){
  if(now>=s.end){s.phase='cooldown';return;}
  if(now>=s.nextPulse){s.nextPulse=now+HYDRA_BREATH.pulseTicks;pulse(b,s);}
 }
}
export function registerHydraBreath(){
 if(registered)return;registered=true;
 system.runInterval(()=>{
  const seen=new Set();for(const name of ['overworld','nether','the_end']){
   let bosses;try{bosses=world.getDimension(name).getEntities({type:'rpg:hydra_boss'});}catch{continue;}
   for(const b of bosses){seen.add(b.id);if(!states.has(b.id))startHydraBreath(b);tickHydraBreath(b);}
  }
  for(const id of states.keys())if(!seen.has(id))states.delete(id);
 },5);
 world.afterEvents.entityDie.subscribe(ev=>states.delete(ev.deadEntity?.id));
}
