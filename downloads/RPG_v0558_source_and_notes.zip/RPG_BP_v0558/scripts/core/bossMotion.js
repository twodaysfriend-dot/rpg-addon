import {world,system} from '@minecraft/server';
const IDS=new Set(['rpg:rock_golem_boss','rpg:cyclops_boss','rpg:tech_block_golem_boss','rpg:hydra_boss']);
const locked=new Map();let registered=false;
export function playBossMotion(boss,motion='melee'){
 if(!IDS.has(boss?.typeId)||!['melee','slam','wave','breath'].includes(motion)||(boss.typeId==='rpg:hydra_boss'&&!['melee','breath'].includes(motion)))return false;
 if(motion==='breath'&&boss.typeId!=='rpg:hydra_boss')return false;
 try{
  if(boss.isValid===false||(boss.getComponent('minecraft:health')?.currentValue??0)<=0)return false;
  const until=locked.get(boss.id)??0;if((motion==='melee'||motion==='wave')&&until>system.currentTick)return false;
  boss.playAnimation('animation.rpg.'+boss.typeId.slice(4)+'.'+motion,{controller:'rpg_boss_action',blendOutTime:.15,stopExpression:'query.any_animation_finished'});
  locked.set(boss.id,system.currentTick+(motion==='breath'?80:motion==='slam'?24:motion==='wave'?20:16));return true;
 }catch{return false;}
}
export function registerBossMotion(){
 if(registered)return;registered=true;
 world.afterEvents.entityHurt.subscribe(ev=>{if(ev.damage>0&&ev.damageSource?.cause==='entityAttack')playBossMotion(ev.damageSource.damagingEntity);});
 world.afterEvents.entityDie.subscribe(ev=>locked.delete(ev.deadEntity?.id));
 system.runInterval(()=>{for(const [id,until]of locked)if(until<=system.currentTick)locked.delete(id);},100);
}
