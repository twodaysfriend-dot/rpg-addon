// Generated from recipes by tools/make_crafting_catalog.py.
export const CRAFTING_RECIPES = [
  {
    "id": "rpg:abyssal_boots",
    "category": "armor",
    "name": "심연 수호자 장화",
    "text": "작업대 제작 → 심연 수호자 장화 ×1\n\n재료:\n숲 수호자 장화 ×1\n네더라이트 주괴 ×1\n네더의 별 ×1\n다이아몬드 ×2\n자수정 조각 ×4\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:abyssal_chestplate",
    "category": "armor",
    "name": "심연 수호자 흉갑",
    "text": "작업대 제작 → 심연 수호자 흉갑 ×1\n\n재료:\n숲 수호자 흉갑 ×1\n네더라이트 주괴 ×1\n네더의 별 ×1\n다이아몬드 ×2\n자수정 조각 ×4\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:abyssal_helmet",
    "category": "armor",
    "name": "심연 수호자 투구",
    "text": "작업대 제작 → 심연 수호자 투구 ×1\n\n재료:\n숲 수호자 투구 ×1\n네더라이트 주괴 ×1\n네더의 별 ×1\n다이아몬드 ×2\n자수정 조각 ×4\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:abyssal_leggings",
    "category": "armor",
    "name": "심연 수호자 각반",
    "text": "작업대 제작 → 심연 수호자 각반 ×1\n\n재료:\n숲 수호자 각반 ×1\n네더라이트 주괴 ×1\n네더의 별 ×1\n다이아몬드 ×2\n자수정 조각 ×4\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:adventurer_boots",
    "category": "armor",
    "name": "모험가 장화",
    "text": "작업대 제작 → 모험가 장화 ×1\n\n재료:\n철 주괴 ×4\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 □ 철\n철 구 철\n□ □ □"
  },
  {
    "id": "rpg:adventurer_chestplate",
    "category": "armor",
    "name": "모험가 흉갑",
    "text": "작업대 제작 → 모험가 흉갑 ×1\n\n재료:\n철 주괴 ×7\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 □ 철\n철 구 철\n철 철 철"
  },
  {
    "id": "rpg:adventurer_helmet",
    "category": "armor",
    "name": "모험가 투구",
    "text": "작업대 제작 → 모험가 투구 ×1\n\n재료:\n철 주괴 ×4\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 구 철\n철 □ 철\n□ □ □"
  },
  {
    "id": "rpg:adventurer_leggings",
    "category": "armor",
    "name": "모험가 각반",
    "text": "작업대 제작 → 모험가 각반 ×1\n\n재료:\n철 주괴 ×6\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 구 철\n철 □ 철\n철 □ 철"
  },
  {
    "id": "rpg:astral_boots",
    "category": "armor",
    "name": "별빛 술사 장화",
    "text": "작업대 제작 → 별빛 술사 장화 ×1\n\n재료:\n모험가 장화 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:astral_chestplate",
    "category": "armor",
    "name": "별빛 술사 흉갑",
    "text": "작업대 제작 → 별빛 술사 흉갑 ×1\n\n재료:\n모험가 흉갑 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:astral_helmet",
    "category": "armor",
    "name": "별빛 술사 투구",
    "text": "작업대 제작 → 별빛 술사 투구 ×1\n\n재료:\n모험가 투구 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:astral_leggings",
    "category": "armor",
    "name": "별빛 술사 각반",
    "text": "작업대 제작 → 별빛 술사 각반 ×1\n\n재료:\n모험가 각반 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:common_battle_spear",
    "category": "weapon",
    "name": "별빛 전투창",
    "text": "작업대 제작 → 별빛 전투창 ×1\n\n재료:\n모험가 전투검 ×1\n다이아몬드 ×2\n자수정 조각 ×2\n철 주괴 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:common_battle_sword",
    "category": "weapon",
    "name": "모험가 전투검",
    "text": "작업대 제작 → 모험가 전투검 ×1\n\n재료:\n철 주괴 ×2\n구리 주괴 ×1\n막대기 ×1\n레드스톤 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:enhancement_catalyst",
    "category": "catalyst",
    "name": "강화 촉매",
    "text": "작업대 제작 → 강화 촉매 ×1\n\n재료:\n네더의 별 ×1\n자수정 조각 ×4\n다이아몬드 ×2\n엔더 진주 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:job_waiver",
    "category": "recovery",
    "name": "전직 포기각서",
    "text": "작업대 제작 → 전직 포기각서 ×1\n\n재료:\n종이 ×4\n먹물 주머니 ×2\n철 주괴 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_absorption",
    "category": "rune",
    "name": "흡수의 룬",
    "text": "작업대 제작 → 흡수의 룬 ×1\n\n재료:\n자수정 조각 ×3\n철 주괴 ×2\n프리즈머린 수정 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_arcane",
    "category": "rune",
    "name": "비전의 룬",
    "text": "작업대 제작 → 비전의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n엔더 진주 ×1\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_mana",
    "category": "rune",
    "name": "샘의 룬",
    "text": "작업대 제작 → 샘의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n청금석 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_power",
    "category": "rune",
    "name": "힘의 룬",
    "text": "작업대 제작 → 힘의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×2\n철 주괴 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_vitality",
    "category": "rune",
    "name": "생명의 룬",
    "text": "작업대 제작 → 생명의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n황금사과 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_ward",
    "category": "rune",
    "name": "수호의 룬",
    "text": "작업대 제작 → 수호의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n철 주괴 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:sandbag_spawner",
    "category": "training",
    "name": "훈련용 샌드백 소환",
    "text": "작업대 제작 → 훈련용 샌드백 소환 ×1\n\n재료:\n건초 더미 ×9\n\n배치도 (건=건초 더미):\n건 건 건\n건 건 건\n건 건 건"
  },
  {
    "id": "rpg:stat_reset_scroll",
    "category": "recovery",
    "name": "스탯 초기화 주문서",
    "text": "작업대 제작 → 스탯 초기화 주문서 ×1\n\n재료:\n종이 ×4\n청금석 ×3\n금 주괴 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:warden_boots",
    "category": "armor",
    "name": "숲 수호자 장화",
    "text": "작업대 제작 → 숲 수호자 장화 ×1\n\n재료:\n모험가 장화 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:warden_chestplate",
    "category": "armor",
    "name": "숲 수호자 흉갑",
    "text": "작업대 제작 → 숲 수호자 흉갑 ×1\n\n재료:\n모험가 흉갑 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:warden_helmet",
    "category": "armor",
    "name": "숲 수호자 투구",
    "text": "작업대 제작 → 숲 수호자 투구 ×1\n\n재료:\n모험가 투구 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:warden_leggings",
    "category": "armor",
    "name": "숲 수호자 각반",
    "text": "작업대 제작 → 숲 수호자 각반 ×1\n\n재료:\n모험가 각반 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  }
];
