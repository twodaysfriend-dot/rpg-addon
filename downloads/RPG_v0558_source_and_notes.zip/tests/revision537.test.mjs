import test from 'node:test';
import assert from 'node:assert/strict';
import {player,world,replies,forms,ItemStack,EquipmentSlot,intervals,system} from './minecraftMock.mjs';
import {openLotoDialogue} from '../RPG_BP_v0558/scripts/core/loto.js';
import {checkAdvance,requirementStatus} from '../RPG_BP_v0558/scripts/core/advance.js';
import {JOBS} from '../RPG_BP_v0558/scripts/data/jobs.js';
import {SKILLS} from '../RPG_BP_v0558/scripts/data/skills.js';
import {RUNNERS as DRAGON} from '../RPG_BP_v0558/scripts/skills/dragon.js';
import {RUNNERS as SPIN} from '../RPG_BP_v0558/scripts/skills/swordFlameSpin.js';
import {RUNNERS as ASSASSIN} from '../RPG_BP_v0558/scripts/skills/assassin.js';
import {RUNNERS as HARPOON} from '../RPG_BP_v0558/scripts/skills/harpoon.js';
import {RUNNERS as BERSERKER} from '../RPG_BP_v0558/scripts/skills/berserker.js';
import {armBlackFlash,BLACK_FLASH_KEY} from '../RPG_BP_v0558/scripts/skills/warGod.js';
import {cooldownLeft,startCooldown,clearPlayerRuntime} from '../RPG_BP_v0558/scripts/core/playerData.js';

function scene(id,job,y=-60){
 const p=player(id,1,{location:{x:0,y,z:0}});p.setDynamicProperty('rpg:job',job);
 p.equipment.set(EquipmentSlot.Mainhand,new ItemStack(JOBS[job].weapon));
 const dim={id:'minecraft:overworld',heightRange:{min:-64,max:320},getEntities:()=>[],getPlayers:()=>[p],
  getBlock:()=>({typeId:'minecraft:air',isSolid:false}),spawnParticle(){},playSound(){}};
 p.dimension=dim;p.getViewDirection=()=>({x:0,y:0,z:1});p.getRotation=()=>({x:0,y:0});
 p.getHeadLocation=()=>({...p.location,y:p.location.y+1.6});p.getTags=()=>[];
 p.teleport=(at)=>{p.location={...at};};
 return {p,dim};
}
function cast(runners,p,id){return runners[id](p,JOBS[p.getDynamicProperty('rpg:job')],SKILLS[id]);}
function tickFor(fn){const n=intervals.length;assert.equal(fn(),true);assert.equal(intervals.length,n+1);return intervals.at(-1);}

test('low-Y airborne flame spin dash no longer treats superflat as void',()=>{
 const {p}=scene('low-spin','swordsman');let pressed=false;p.inputInfo={getButtonState:()=>pressed?'Pressed':'Released'};
 const tick=tickFor(()=>cast(SPIN,p,'sword_flame_spin'));tick();pressed=true;tick();
 assert.ok(p.location.z>0);assert.equal(p.location.y,-60);
});
test('dragon sprint crosses unsupported terrain and lava below while keeping anchored Y',()=>{
 const {p,dim}=scene('low-dragon','dragon_knight');
 dim.getBlock=q=>({typeId:q.y<-60?'minecraft:lava':'minecraft:air',isSolid:false});
 const tick=tickFor(()=>cast(DRAGON,p,'dragon_sprint'));tick();tick();
 assert.ok(Math.abs(p.location.z-2.1)<1e-9);assert.equal(p.location.y,-60);
});
test('dragon charge can reach a target on a negative-Y superflat map',()=>{
 const {p,dim}=scene('low-charge','dragon_knight');const enemy=player('charge-target',1,{typeId:'minecraft:zombie',location:{x:0,y:-60,z:3}});
 enemy.dimension=dim;enemy.getTags=()=>[];dim.getEntities=()=>[enemy];
 assert.equal(cast(DRAGON,p,'dragon_charge'),true);assert.equal(p.location.z,3);assert.equal(p.location.y,-60);
});
test('assassin spin and soul separation accept open destinations without solid ground',()=>{
 for(const [job,id,runner,distance]of [['assassin','assassin_spin',ASSASSIN,3],['revenant','soul_separation',HARPOON,7]]){
  const {p}=scene('air-'+job,job);assert.equal(cast(runner,p,id),true);
  assert.equal(p.location.z,distance);assert.equal(p.location.y,-60);
 }
});
test('berserker triple slash moves in the air instead of requiring a solid floor',()=>{
 const {p}=scene('air-slash','mangnani');const tick=tickFor(()=>cast(BERSERKER,p,'berserker_triple_slash'));tick();
 assert.ok(p.location.z>.5);assert.equal(p.location.y,-60);
});
test('actual block collisions still stop dash and reject blocked teleport destinations',()=>{
 const {p,dim}=scene('wall-dragon','dragon_knight');dim.getBlock=()=>({typeId:'minecraft:stone',isSolid:true});
 tickFor(()=>cast(DRAGON,p,'dragon_sprint'))();assert.equal(p.location.z,0);
 for(const [job,id,runner]of [['assassin','assassin_spin',ASSASSIN],['revenant','soul_separation',HARPOON]]){
  const s=scene('wall-'+job,job);s.dim.getBlock=dim.getBlock;
  assert.equal(cast(runner,s.p,id),false);assert.equal(s.p.location.z,0);
 }
});
test('Loto opens quiz on conversation 23 and directly advances first correct player without level or kill requirements',async()=>{
 world.setDynamicProperty('rpg:loto_first_hacker',undefined);replies.length=0;const {p}=scene('first-hacker','apprentice');
 for(let n=1;n<=22;n++){await openLotoDialogue(p);assert.equal(p.getDynamicProperty('rpg:loto_talk_count'),n);assert.equal(p.getDynamicProperty('rpg:job'),'apprentice');}
 replies.push({canceled:false,formValues:['int *x;']},{canceled:false,selection:0});await openLotoDialogue(p);
 assert.equal(p.getDynamicProperty('rpg:loto_talk_count'),23);assert.equal(p.getDynamicProperty('rpg:job'),'hacker');
 assert.equal(world.getDynamicProperty('rpg:loto_first_hacker'),p.id);assert.equal(p.slots[0].typeId,'rpg:hacker_core');
 await openLotoDialogue(p);assert.equal(p.getDynamicProperty('rpg:loto_talk_count'),23);
});
test('later correct players get exactly one enchanted apple and cannot bypass through normal advancement',async()=>{
 world.setDynamicProperty('rpg:loto_first_hacker','first-hacker');replies.length=0;const {p}=scene('later-hacker','apprentice');
 p.setDynamicProperty('rpg:loto_talk_count',22);let apples=0;
 p.getComponent('minecraft:inventory').container.addItem=item=>{assert.equal(item.typeId,'minecraft:enchanted_golden_apple');apples+=item.amount;};
 replies.push({canceled:false,formValues:['int* x;']},{canceled:false,selection:0});await openLotoDialogue(p);await openLotoDialogue(p);
 assert.equal(apples,1);assert.equal(p.getDynamicProperty('rpg:job'),'apprentice');assert.equal(p.getDynamicProperty('rpg:loto_rewarded'),true);
 p.setDynamicProperty('rpg:rpg_level',100);p.setDynamicProperty('rpg:job','mage');p.setDynamicProperty('rpg:progress',JSON.stringify({job_elite:100,job_hacker_quiz:1}));
 assert.equal(checkAdvance(p,JOBS.hacker).ok,false);assert.match(requirementStatus(p,JOBS.hacker).label,/23/);
});
test('wrong quiz answer can be retried and does not claim the world winner',async()=>{
 world.setDynamicProperty('rpg:loto_first_hacker',undefined);replies.length=0;const {p}=scene('quiz-retry','apprentice');p.setDynamicProperty('rpg:loto_talk_count',22);
 replies.push({canceled:false,formValues:['int x;']},{canceled:false});await openLotoDialogue(p);
 assert.equal(world.getDynamicProperty('rpg:loto_first_hacker'),undefined);assert.equal(p.getDynamicProperty('rpg:loto_rewarded'),undefined);
 replies.push({canceled:false,formValues:['int * x ;']},{canceled:false});await openLotoDialogue(p);
 assert.equal(world.getDynamicProperty('rpg:loto_first_hacker'),p.id);assert.equal(p.getDynamicProperty('rpg:job'),'hacker');
});
test('Tenmyeol rename preserves saved skill IDs, ultimate charge and cooldown',()=>{
 assert.equal(SKILLS.war_god_black_flash.name,'천멸격 (궁극기)');assert.equal(BLACK_FLASH_KEY,'rpg:black_flash_ready');
 const {p}=scene('renamed-ult','war_god');p.setDynamicProperty(BLACK_FLASH_KEY,true);startCooldown(p,'war_god_black_flash',1800);clearPlayerRuntime(p.id);
 assert.ok(cooldownLeft(p,'war_god_black_flash')>0);assert.equal(armBlackFlash(p),false);assert.match(p.actionBars.at(-1),/천멸격/);
 assert.equal(p.getDynamicProperty(BLACK_FLASH_KEY),true);
});
