const signal = () => ({listeners:[], subscribe(fn) { this.listeners.push(fn); }});
export const events = Object.fromEntries(['entityDie','playerSpawn','playerLeave','entityHurt','entityHitEntity','entityHitBlock','projectileHitEntity','projectileHitBlock','entitySpawn','playerButtonInput','playerInteractWithEntity','playerDimensionChange','itemUse','itemCompleteUse','itemReleaseUse','playerSwingStart','worldLoad'].map(key=>[key,signal()]));
const props = new Map();
export const players = [];
export const timeouts = [];
export const intervals = [];
export const clearedRuns=new Set();
export const world = {
  afterEvents:events, beforeEvents:{}, getAllPlayers:() => players, getTimeOfDay:()=>6000,
  getDynamicProperty:key => props.get(key), setDynamicProperty:(key, value) => props.set(key, value),
};
export const system = {
  beforeEvents:{startup:signal()},afterEvents:{scriptEventReceive:signal()},
  currentTick:0, run:fn => fn(),
  clearRun:id=>clearedRuns.add(id),
  runTimeout:fn => {timeouts.push(fn); return timeouts.length;}, runInterval:fn => {intervals.push(fn);return intervals.length;},
};
export class ItemStack {
  constructor(typeId, amount=1) {this.typeId=typeId; this.amount=amount;this.props=new Map();this.lore=[];}
  clone() {const item=new ItemStack(this.typeId,this.amount);item.props=new Map(this.props);item.lore=[...this.lore];if(this.nameTag!==undefined)item.nameTag=this.nameTag;return item;}
  getDynamicProperty(key) {return this.props.get(key);}
  setDynamicProperty(key,value) {if(value===undefined)this.props.delete(key);else this.props.set(key,value);}
  getLore() {return [...this.lore];}
  setLore(lore) {this.lore=[...lore];}
}
export const ItemLockMode = {slot:'slot'};
export const InputButton = {Jump:'Jump',Sneak:'Sneak'};
export const ButtonState = {Pressed:'Pressed',Released:'Released'};
export const CommandPermissionLevel={Any:0,GameDirectors:1};
export const CustomCommandParamType={String:'String',Integer:'Integer'};
export const CustomCommandStatus={Success:0,Failure:1};
export const EquipmentSlot = {Mainhand:'Mainhand',Head:'Head',Chest:'Chest',Legs:'Legs',Feet:'Feet'};
export const EntityDamageCause = {entityAttack:'entityAttack', override:'override'};
export const HudElement = {Health:6,Armor:1,StatusEffects:11};
export const HudVisibility = {Hide:0,Reset:1};
export const replies = [];
export const forms = [];
export class ActionFormData {
  constructor() {this.buttons=[]; forms.push(this);}
  title(value) {this.heading=value; return this;}
  body(value) {this.text=value; return this;}
  button(value) {this.buttons.push(value); return this;}
  button1(value) {this.buttons[0]=value;return this;}
  button2(value) {this.buttons[1]=value;return this;}
  async show() {return replies.shift() ?? {canceled:true};}
}
export class ModalFormData extends ActionFormData {textField(){return this;}submitButton(){return this;}}
export class MessageFormData extends ActionFormData {}
export const FormCancelationReason = {UserBusy:'UserBusy'};

export function player(id, level=1, overrides={}) {
  const values = new Map([['rpg:job','apprentice'], ['rpg:rpg_level',level]]);
  const slots = new Array(36);
  const equipment=new Map(), effects=new Map();
  const actionBars=[],hudChanges=[];
  const eq={getEquipment:slot=>equipment.get(slot)?.clone(),setEquipment:(slot,item)=>{equipment.set(slot,item?.clone());return true;}};
  const inventory = {size:36, getItem:i=>slots[i], setItem:(i,item)=>{slots[i]=item;}};
  return {
    id, name:id, typeId:'minecraft:player', isValid:true, location:{x:0,y:64,z:0},
    dimension:{id:'minecraft:overworld'}, health:20, messages:[], slots, values, equipment, effects, actionBars, hudChanges,
    onScreenDisplay:{setActionBar:text=>actionBars.push(text),setHudVisibility:(visibility,elements)=>hudChanges.push({visibility,elements})},
    addEffect:(id,duration,options)=>effects.set(id,{duration,...options}),getEffect:id=>effects.get(id),removeEffect:id=>effects.delete(id),
    getGameMode:() => 'survival',
    getComponent(name) {
      if (name==='minecraft:health') {const p=this;return {get currentValue(){return p.health;},get effectiveMax(){return p.maxHealth??(20+(effects.has('health_boost')?4*(effects.get('health_boost').amplifier+1):0));},setCurrentValue(value){p.health=value;}};}
      if (name==='minecraft:inventory') return {container:inventory};
      if (name==='minecraft:equippable') return eq;
    },
    getDynamicProperty:key=>values.get(key),
    setDynamicProperty(key, value) {if (value===undefined) values.delete(key); else values.set(key,value);},
    sendMessage(message) {this.messages.push(message);},
    ...overrides,
  };
}
