import test from 'node:test';
import assert from 'node:assert/strict';
import {player,players,system,forms,replies} from './minecraftMock.mjs';
import {readRuneBag,writeRuneBag,addRuneRecord,equipRune,equippedRunes,RUNE_SLOTS} from '../RPG_BP_v0558/scripts/core/runeInventory.js';
import {getEquipmentBonuses} from '../RPG_BP_v0558/scripts/core/equipment.js';
import {runeLifestealRate,healLifesteal} from '../RPG_BP_v0558/scripts/core/lifesteal.js';
import {openRuneMenu} from '../RPG_BP_v0558/scripts/core/runeMenu.js';
import {HYDRA_BREATH,startHydraBreath,tickHydraBreath} from '../RPG_BP_v0558/scripts/core/hydraBreath.js';
let serial=0;const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
function equip(p,id,count=10,level=5){const bag=readRuneBag(p),r=[];for(let i=0;i<count;i++)r.push(addRuneRecord(bag,id,level));writeRuneBag(p,bag);r.forEach((r,i)=>assert.equal(equipRune(p,r.uid,i).ok,true));return r;}
test('old three-slot data migrates to ten while preserving inventory, UID, grades and equipped order',()=>{
 const p=player('legacy10');p.setDynamicProperty('rpg:rune_bag_v1',JSON.stringify({version:1,nextId:3,runes:[{uid:'r1',id:'power',level:5},{uid:'r2',id:'vitality',level:3}],equipped:['r1','r2',null]}));const b=readRuneBag(p);assert.equal(RUNE_SLOTS,10);assert.deepEqual(b.equipped,['r1','r2',...Array(8).fill(null)]);assert.equal(b.runes[1].level,3);writeRuneBag(p,b);assert.deepEqual(readRuneBag(p),b);
});
test('ten different instances of one rune can equip; the same UID moves instead of multiplying itself',()=>{
 const p=player('tenpower'),r=equip(p,'power');assert.equal(equippedRunes(p).length,10);close(getEquipmentBonuses(p).physical,4);assert.equal(equipRune(p,r[0].uid,10).ok,false);assert.equal(equipRune(p,r[0].uid,9).ok,true);assert.equal(readRuneBag(p).equipped[0],null);assert.equal(equippedRunes(p).length,9);
});
test('duplicate percent bonuses, HP, mana regen and lifesteal sum, resistance keeps strongest rank',()=>{
 for(const [id,field,expected]of [['arcane','magic',4],['vitality','health',240],['mana','manaRegenPercent',.3],['absorption','lifesteal',1.2],['ward','wardAmplifier',1]]){const p=player(id);equip(p,id);close(getEquipmentBonuses(p)[field],expected);if(id==='absorption'){close(runeLifestealRate(p),1.2);p.health=5;healLifesteal(p,player('enemy',1,{typeId:'minecraft:zombie'}),10);close(p.health,17);}}
});
test('rune menu exposes the tenth slot and actions still use the proper button indices',async()=>{
 const p=player('menuten'),bag=readRuneBag(p),r=addRuneRecord(bag,'power');writeRuneBag(p,bag);replies.push({canceled:false,selection:2},{canceled:false,selection:9},{canceled:true});await openRuneMenu(p);assert.equal(readRuneBag(p).equipped[9],r.uid);assert.ok(forms.some(f=>f.buttons?.includes('10번 칸 장착')));
});
function scene(){players.length=0;system.currentTick=0;const hits=[],fx=[],motion=[],b=player('hydra'+serial++,1,{typeId:'rpg:hydra_boss',maxHealth:1600,health:1600}),p=player('breath-target',1,{location:{x:0,y:64,z:14}});const dim={id:'minecraft:overworld',getBlock:()=>({isSolid:false}),spawnParticle:(id,at)=>fx.push({id,at}),playSound(){}};b.dimension=p.dimension=dim;b.playAnimation=id=>motion.push(id);p.applyDamage=(n,o)=>{hits.push({n,o});return true;};p.setOnFire=()=>{};players.push(p);return {b,p,dim,hits,fx,motion};}
test('Hydra telegraphs one second then sends six pulses, three heads hit only once per pulse',()=>{
 const {b,hits,motion}=scene();assert.equal(startHydraBreath(b),true);tickHydraBreath(b);assert.equal(hits.length,0);system.currentTick=19;tickHydraBreath(b);assert.equal(hits.length,0);
 for(let t=20;t<80;t+=5){system.currentTick=t;tickHydraBreath(b);}assert.equal(hits.length,6);assert.ok(hits.every(h=>h.n===6&&h.o.damagingEntity===b));assert.ok(motion[0].endsWith('.breath'));system.currentTick=80;tickHydraBreath(b);assert.equal(hits.length,6);assert.equal(startHydraBreath(b),false);system.currentTick=200;assert.equal(startHydraBreath(b),true);
});
test('breath is blocked by terrain and the locked direction can be dodged',()=>{
 const wall=scene();startHydraBreath(wall.b);wall.dim.getBlock=()=>({isSolid:true});system.currentTick=20;tickHydraBreath(wall.b);assert.equal(wall.hits.length,0);
 const dodge=scene();startHydraBreath(dodge.b);system.currentTick=20;tickHydraBreath(dodge.b);assert.equal(dodge.hits.length,1);dodge.p.location.x=15;system.currentTick=30;tickHydraBreath(dodge.b);assert.equal(dodge.hits.length,1);
});
test('dead/other-dimension targets cancel charge, dead casters stop and creative players are excluded',()=>{
 for(const change of [s=>s.p.health=0,s=>s.p.dimension={id:'minecraft:nether'},s=>s.b.health=0]){const s=scene();startHydraBreath(s.b);change(s);system.currentTick=20;tickHydraBreath(s.b);assert.equal(s.hits.length,0);}
 const s=scene();s.p.getGameMode=()=> 'creative';assert.equal(startHydraBreath(s.b),false);assert.equal(HYDRA_BREATH.range,24);
});
