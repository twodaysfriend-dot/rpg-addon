from pathlib import Path
from fractions import Fraction
import importlib.util
import hashlib
import json
import subprocess
import unittest

ROOT=Path(__file__).resolve().parents[1]
BP=ROOT/'RPG_BP_v0558'
BASELINE=json.loads((ROOT/'tests/rune_loot_baseline.json').read_text())

class LootAndCrafting(unittest.TestCase):
    def test_all_rune_chances_and_item_references(self):
        self.assertEqual(len(BASELINE),22)
        for name in BASELINE:
            entity=json.loads((BP/'entities'/f'{name}.json').read_text())['minecraft:entity']
            table=json.loads((BP/entity['components']['minecraft:loot']['table']).read_text())
            pool=table['pools'][-1]
            rune_entries=[e for e in pool['entries'] if e['type']=='item']
            total=sum(e.get('weight',1) for e in pool['entries'])
            percent=30 if name.endswith('_boss') else 3 if name.startswith('elite_') else 1
            self.assertEqual(Fraction(sum(e['weight'] for e in rune_entries),total),Fraction(percent,100),name)
            self.assertEqual(pool['rolls'],1)
            self.assertEqual(len(rune_entries),6)
            for entry in rune_entries:
                item=entry['name'].replace('rpg:','')
                self.assertTrue((BP/'items'/f'{item}.json').is_file())

    def test_previous_drops_and_catalyst_pools_are_preserved(self):
        for name,old_pools in BASELINE.items():
            table=json.loads((BP/'loot_tables/entities'/f'rpg_runes_{name}.json').read_text())
            self.assertEqual(table['pools'][:-1],old_pools,name)

    def test_regenerating_loot_is_idempotent(self):
        paths=list((BP/'loot_tables/entities').glob('rpg_runes_*.json'))+[BP/'entities'/f'{name}.json' for name in BASELINE]
        before={p:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
        subprocess.run(['python',str(ROOT/'tools/make_rune_loot.py')],check=True,capture_output=True)
        self.assertEqual(before,{p:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})

    def test_catalog_matches_real_recipes(self):
        spec=importlib.util.spec_from_file_location('catalog_builder',ROOT/'tools/make_crafting_catalog.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        source=(BP/'scripts/data/crafting.js').read_text()
        actual=json.loads(source.split('export const CRAFTING_RECIPES = ',1)[1].rstrip().removesuffix(';'))
        self.assertEqual(actual,module.generate_catalog())
        self.assertEqual(len(actual),28)
        for recipe in actual:
            self.assertTrue((BP/'items'/(recipe['id'].replace('rpg:','')+'.json')).is_file())

    def test_armor_patterns_are_unique_and_survival_craftable(self):
        seen=set()
        for path in (BP/'recipes').glob('adventurer_*.json'):
            data=json.loads(path.read_text())['minecraft:recipe_shaped']
            key=data['key'];pattern=data['pattern']
            grid=tuple(tuple(key[c]['item'] if c!=' ' else '' for c in row) for row in pattern)
            mirror=tuple(tuple(reversed(row)) for row in grid)
            self.assertNotIn(grid,seen);self.assertNotIn(mirror,seen);seen.add(grid)
            self.assertEqual(sum(c=='C' for row in pattern for c in row),1)
            self.assertTrue(all(v['item'].startswith('minecraft:') for v in key.values()))
        self.assertEqual(len(seen),4)

if __name__=='__main__':unittest.main(verbosity=2)
