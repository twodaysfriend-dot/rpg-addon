import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,EquipmentSlot,intervals,events,timeouts,system} from './minecraftMock.mjs';
import {RUNNERS as SWORD} from '../RPG_BP_v0558/scripts/skills/sword.js';
import {RUNNERS as FLAME} from '../RPG_BP_v0558/scripts/skills/swordFlameSpin.js';
import {registerTracking} from '../RPG_BP_v0558/scripts/core/tracking.js';
import {setSkills} from '../RPG_BP_v0558/scripts/core/playerData.js';
import {chameleonCastJob} from '../RPG_BP_v0558/scripts/core/chameleon.js';
import {JOBS} from '../RPG_BP_v0558/scripts/data/jobs.js';
import {SKILLS} from '../RPG_BP_v0558/scripts/data/skills.js';
registerTracking();let serial=0;
function scene(job,str){
 const p=player('damage-'+serial++,40),t=player('target-'+serial,1,{typeId:'minecraft:zombie',health:1000,maxHealth:1000,location:{x:0,y:64,z:2}}),hits=[],particles=[];
 p.setDynamicProperty('rpg:job',job);p.setDynamicProperty('rpg:stat_values',JSON.stringify({str,vit:5,int:5,mag:5}));
 setSkills(p,['sword_spin','sword_wave','sword_flame_spin','sword_rush']);p.equipment.set(EquipmentSlot.Mainhand,new ItemStack(JOBS[job].weapon));
 const dim={id:'minecraft:overworld',getEntities:()=>[t],getBlock:()=>({isSolid:false,typeId:'minecraft:air'}),spawnParticle:(id,at)=>particles.push({id,at}),playSound(){}};
 p.dimension=t.dimension=dim;p.getViewDirection=()=>({x:0,y:0,z:1});p.getRotation=()=>({x:0,y:0});p.teleport=at=>{p.location={...at};};t.setOnFire=()=>{};t.applyKnockback=()=>{};
 t.applyDamage=(amount)=>{hits.push(amount);t.health-=amount;return true;};return {p,t,hits,particles};
}
for(const [id,multiplier]of [['sword_flame_spin',1.5],['sword_wave',1.5],['sword_rush',1.5],['sword_spin',2]]){
 test(id+' boosts actual Sword Saint hits only and applies STR scaling once',()=>{
  for(const job of ['sword_saint','swordsman','fallen_sword_saint','chameleon']){
   if(job!=='chameleon'&&!JOBS[job].skills.includes(id))continue;
   for(const str of [5,15]){
    const {p,t,hits}=scene(job,str),def=SKILLS[id],runner=(id==='sword_flame_spin'?FLAME:SWORD)[id],before=intervals.length;
    if(id==='sword_rush')for(const fn of events.entityHurt.listeners)fn({hurtEntity:t,damage:1,damageSource:{damagingEntity:p}});
    runner(p,chameleonCastJob(id,JOBS[job]),def);
    if(id!=='sword_spin'){const tick=intervals[before];assert.equal(typeof tick,'function');for(let n=0;n<(id==='sword_rush'?def.hits*def.stepTicks:1);n++)tick();}
    assert.equal(hits.length,id==='sword_rush'?8:1,job);
    const expected=def.damage*(job==='sword_saint'?multiplier:1)*(1+.007*(str-5));
    for(const amount of hits)assert.ok(Math.abs(amount-expected)<1e-8,job+': '+amount+' vs '+expected);
   }
  }
 });
}

test('flame spin delivers three distinct pulses at ticks 1, 11 and 21 for every eligible class',()=>{
 for(const job of ['sword_saint','swordsman','fallen_sword_saint','chameleon']){
  const {p,hits}=scene(job,5),before=intervals.length;FLAME.sword_flame_spin(p,chameleonCastJob('sword_flame_spin',JOBS[job]),SKILLS.sword_flame_spin);const tick=intervals[before];
  for(let i=1;i<=28;i++){system.currentTick++;tick();assert.equal(hits.length,Math.min(3,Math.ceil(i/10)),job+' tick '+i);}
  assert.deepEqual(hits,Array(3).fill(job==='sword_saint'?18.9:12.6));
 }
});
test('finishing the seven-block dash preserves the remaining flame slashes',()=>{
 const {p,t,hits}=scene('sword_saint',5);let jump=false;p.inputInfo={getButtonState:()=>jump?'Pressed':'Released'};
 const before=intervals.length;FLAME.sword_flame_spin(p,JOBS.sword_saint,SKILLS.sword_flame_spin);const tick=intervals[before];
 for(let i=0;i<28;i++){if(i===1)jump=true;t.location={x:p.location.x,y:64,z:p.location.z+1};system.currentTick++;tick();}
 assert.equal(p.location.z,7);assert.deepEqual(hits,[18.9,18.9,18.9]);
});
test('flame follow-up stops on death, weapon removal or dimension change',()=>{
 for(const end of [p=>{p.health=0;},p=>p.equipment.clear(),p=>{p.dimension={id:'minecraft:nether'};}]){
  const {p,hits}=scene('sword_saint',5),before=intervals.length;FLAME.sword_flame_spin(p,JOBS.sword_saint,SKILLS.sword_flame_spin);const tick=intervals[before];tick();end(p);for(let i=0;i<28;i++)tick();assert.deepEqual(hits,[18.9]);
 }
});
test('Kenho layers large and small crescents while retaining three twelve-damage slashes',()=>{
 const {p,hits,particles}=scene('sword_saint',5),before=timeouts.length;
 SWORD.sword_kenho_rando(p,JOBS.sword_saint,SKILLS.sword_kenho_rando);for(const fn of timeouts.slice(before))fn();
 assert.deepEqual(hits,[12,12,12]);assert.equal(particles.filter(e=>e.id==='rpg:kenho_crescent').length,9);assert.equal(particles.filter(e=>e.id==='rpg:kenho_small_crescent').length,36);
});
test('Kenho does not deliver delayed damage or crescents after caster death',()=>{
 const {p,hits,particles}=scene('sword_saint',5),before=timeouts.length;SWORD.sword_kenho_rando(p,JOBS.sword_saint,SKILLS.sword_kenho_rando);const n=particles.length;p.health=0;for(const fn of timeouts.slice(before))fn();assert.deepEqual(hits,[12]);assert.equal(particles.length,n);
});
