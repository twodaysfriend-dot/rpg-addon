# RPG v0.6.80 테스트판 · 창셀혼과 블라디미르 전직 카드

창셀혼의 테스트 외형에는 마인크래프트 기본 스티브 텍스처를 사용합니다. 사용자 스킨 원본을 반영한 배포판은 더 높은 버전으로 제공할 수 있습니다.

- 창셀혼의 머리 위에는 **창셀혼**만 표시됩니다. 카드 없이 대화하면 “최고권력자 창셀혼입니다”라고 인사합니다.
- **블라디미르 전직 카드**를 주 손에 들고 창셀혼과 대화하면 전직을 선택할 수 있습니다. 직업과 레벨 제한은 없으며 전직 후 카드가 남습니다.
- 카드는 크리에이티브 보관함에서 꺼낼 수 있습니다. 창셀혼 소환알은 관리자 명령 `/rpg:hito 창셀혼`으로 받을 수 있습니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.80으로 활성화하고 월드를 다시 여세요. NPC 대화와 전직 처리는 모의 테스트로 확인했습니다. 실제 Bedrock 월드에서의 외형과 조작은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0680_preview
```
