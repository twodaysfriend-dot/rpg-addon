import {visiblePromotionJobs,isJobDiscovered} from './jobDiscovery.js';
import {jobStatText} from '../data/jobStats.js';
import { ActionFormData } from '@minecraft/server-ui';
import { JOBS } from '../data/jobs.js';
import { getJobId } from './playerData.js';
import { checkAdvance,requirementStatus,requestAdvance } from './advance.js';
import { openLotoDialogue } from './loto.js';
import { showForm } from './skillMenu.js';
import { JOB_TRIALS } from '../data/jobTrials.js';
import { offerItems,offerLight } from './offer.js';
const open=new Set();
export async function openJobMenu(p){
  if(getJobId(p)==='chameleon'){p.sendMessage('§7카멜레온은 다른 직업의 전직 조건을 조회할 수 없습니다.');return;}
  if(open.has(p.id))return;open.add(p.id);
  try{
    const jobs=visiblePromotionJobs(p);
    const form=new ActionFormData().title('전직 안내 · 발견 기록').body('현재: '+(JOBS[getJobId(p)]?.name??'견습')+'\n일반 직업과 발견한 히든 직업을 표시합니다. 히든 시련 조건을 2개 이상 완료해도 해당 전직 조건이 공개됩니다.\n처치 시련은 최근 30초 동안 공격·탱킹·유효 회복으로 기여한 파티원도 인정합니다. 같은 차원·처치 위치 32칸·생존 조건입니다.');
    for(const job of jobs)form.button(job.name+(job.hidden?' [히든]':' [일반]')+(getJobId(p)===job.id?' [현재]':checkAdvance(p,job).ok?' [가능]':''));form.button('닫기');
    const picked=await showForm(form,p);if(!picked||picked.canceled||picked.selection==null||picked.selection>=jobs.length)return;
    const job=jobs[picked.selection];if(!isJobDiscovered(p,job))return;
    const status=requirementStatus(p,job),parent=job.id==='bloodedge'?'제한 없음':JOB_TRIALS[job.id]?.allowedFrom?.map(id=>JOBS[id].name).join('·')??(job.parent?JOBS[job.parent]?.name:(JOB_TRIALS[job.id]?.fromApprentice?'견습 또는 아무 2차 이상 직업':'아무 2차 이상 직업'));
    const f=new ActionFormData().title(job.name).body(jobStatText(job)+'\n\n필요 직전 직업: '+parent+'\n'+(status?.label??'조건 없음'));
    const actions=[];
    if(job.id!=='bloodedge'){
      actions.push(()=>requestAdvance(p,job));
      f.button(job.id==='cleric'?'성직 전직관과 대화':job.id==='fallen_angel'?'성직 포기 후 전직':'전직 시도');
    }
    if(job.id==='hacker'){f.button('로토 퀴즈');actions.push(()=>openLotoDialogue(p));}
    if(['swordsman','mage','technomancer'].includes(job.id)){f.button('검과 책 바치기');actions.push(()=>offerItems(p));}
    if(job.id==='michael'){f.button('축복의 빛 바치기');actions.push(()=>offerLight(p));}
    f.button('닫기');
    const answer=await showForm(f,p);if(!answer||answer.canceled)return;
    if(actions[answer.selection])await actions[answer.selection]();
  }catch(error){try{p.sendMessage('§c'+String(error));}catch{}}finally{open.delete(p.id);}
}
