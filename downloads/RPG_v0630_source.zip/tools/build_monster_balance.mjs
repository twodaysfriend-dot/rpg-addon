import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {MONSTER_LEVELS,dungeonMonsterLevel,monsterCombatMultipliers} from '../RPG_BP_v0630/scripts/data/monsterLevels.js';
import {DUNGEON_TIERS} from '../RPG_BP_v0630/scripts/data/dungeons.js';
import {LEVELED_MONSTERS} from '../RPG_BP_v0630/scripts/data/leveledMonsters.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const check=process.argv.includes('--check'),round=(n,places=2)=>Number(n.toFixed(places));
let groups=0;
for(const id of LEVELED_MONSTERS){
 const file=path.join(root,'RPG_BP_v0630/entities',id.split(':')[1]+'.json'),original=fs.readFileSync(file,'utf8'),json=JSON.parse(original),entity=json['minecraft:entity'];
 const base=entity.components,hp=base['minecraft:health'].max,attack=base['minecraft:attack'].damage;
 const scaledKeys=Object.keys(entity.component_groups).filter(k=>/^rpg:(?:level_|dungeon_scaled_|dungeon_tier_)/.test(k));
 const setGroup=(key,m)=>{
  const value=round(hp*m.health);
  entity.component_groups[key]={...entity.component_groups[key],
   'minecraft:health':{value,max:value},
   'minecraft:damage_sensor':{triggers:[{cause:'all',damage_multiplier:round(m.defense,6)}]},
   'minecraft:attack':{damage:round(attack*m.attack)}
  };
  entity.events[key]={remove:{component_groups:scaledKeys},add:{component_groups:[key]}};
  groups++;
 };
 for(const level of MONSTER_LEVELS)setGroup('rpg:level_'+level,monsterCombatMultipliers(level));
 for(const tier of DUNGEON_TIERS){
  // The scaled event immediately follows this compatibility event at spawn.
  const key='rpg:dungeon_tier_'+tier.tier,g=entity.component_groups[key];
  if(g){g['minecraft:health']={value:round(hp*tier.hpMultiplier),max:round(hp*tier.hpMultiplier)};
  g['minecraft:attack']={damage:round(attack*tier.attackMultiplier)};}
  for(const kind of ['normal','elite','boss'])for(let index=0;index<(kind==='normal'?3:1);index++){
   const context={tier:tier.tier,kind,index},level=dungeonMonsterLevel(tier.tier,kind,index);
   setGroup(`rpg:dungeon_scaled_${tier.tier}_${kind}_${index}`,monsterCombatMultipliers(level,context));
  }
 }
 const output=JSON.stringify(json,null,2)+'\n';
 if(check){if(original!==output)throw Error('Stale generated balance: '+file);}else fs.writeFileSync(file,output);
}
console.log(`${check?'Verified':'Generated'} ${groups} wild/dungeon component groups across ${LEVELED_MONSTERS.length} entities`);
