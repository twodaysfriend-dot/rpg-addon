"""Build the three-pack Bedrock addon, source archive and download bundle."""
from pathlib import Path
import io,json,sys,zipfile,hashlib
root=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1] if len(sys.argv)>1 else '/tmp/rpg-release');out.mkdir(parents=True,exist_ok=True)
version='0630';stem='RPG_v'+version
packs=sorted(root.glob('RPG_*_v'+version))
assert len(packs)==3
with zipfile.ZipFile(out/(stem+'.mcaddon'),'w',zipfile.ZIP_DEFLATED) as addon:
 for pack in packs:
  manifest=json.loads((pack/'manifest.json').read_text());assert manifest['header']['version']==[0,6,30]
  buf=io.BytesIO()
  with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
   for p in sorted(pack.rglob('*')):
    if p.is_file():z.write(p,p.relative_to(pack))
  addon.writestr(pack.name+'.mcpack',buf.getvalue())
with zipfile.ZipFile(out/(stem+'_source.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(root))
notes=(root/'STATUS.md').read_bytes();(out/(stem+'_NOTES.md')).write_bytes(notes)
with zipfile.ZipFile(out/(stem+'_download.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for name in [stem+'.mcaddon',stem+'_NOTES.md']:z.write(out/name,name)
with zipfile.ZipFile(out/(stem+'.mcaddon')) as addon:
 assert addon.testzip() is None
 for name in addon.namelist():
  with zipfile.ZipFile(io.BytesIO(addon.read(name))) as z:
   assert z.testzip() is None;assert 'manifest.json' in z.namelist()
print(hashlib.sha256((out/(stem+'.mcaddon')).read_bytes()).hexdigest())
