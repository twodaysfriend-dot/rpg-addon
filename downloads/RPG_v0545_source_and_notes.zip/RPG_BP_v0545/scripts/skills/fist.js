import {teleportForSkill} from '../core/dungeonMovement.js';
import { hasBorrowedSkill } from "../core/skillAccess.js";
import { system, world, EntityDamageCause } from "@minecraft/server";
import { areAllies } from "../core/social.js";
import { strengthDamageBonus } from "../core/stats.js";
import { JOBS } from "../data/jobs.js";
import {
  getTargets, hurt, knockback, particle, sound, flatDir, isSolidAt, dist3, healthAlive, headPos,
} from "../core/util.js";
import { notify } from "../core/hud.js";
import { getLastHit } from "../core/tracking.js";
import { getJobId } from "../core/playerData.js";
import {
  giveDoubleBuff, doubleLeft, takeDouble, markSkillHit, consumeSkillMark, clearFistRuntime,
} from "../core/fistState.js";

// ---------------------------------------------------------------------------
// 무투가 / 권골 (line: "fist")
//  무투가 : 강펀치, 난타, 스매쉬
//  권골   : + 풍압, 안면강타, 강자의 자세, 대미장식(궁극기)
//  패시브 : 낙하 피해 없음 (무투가, 권골)
// 숫자는 data/skills.js 와 config.js 의 fist 항목에서 조정합니다.
// ---------------------------------------------------------------------------

const RED = "minecraft:redstone_ore_dust_particle";
const HIT = "minecraft:critical_hit_emitter";
const BOOM = "minecraft:large_explosion";
const HUGE = "minecraft:huge_explosion_emitter";
const SMOKE = "minecraft:basic_smoke_particle";

// ---- 작은 도우미들 ----
function fx(entity, id, ticks, amp = 0, show = false) {
  try {
    entity.addEffect(id, ticks, { amplifier: amp, showParticles: show });
  } catch {
    // 효과를 받을 수 없는 대상
  }
}

function unfx(entity, ids) {
  for (const id of ids) {
    try {
      entity.removeEffect(id);
    } catch {
      // 이미 사라진 효과/엔티티
    }
  }
}

// 움직이지도, 점프하지도, 제대로 때리지도 못하게 만듭니다.
const STUN_EFFECTS = ["slowness", "weakness", "mining_fatigue"];
function stun(entity, ticks) {
  clearLegacyJumpBoost(entity);
  fx(entity, "slowness", ticks, 255);
  fx(entity, "weakness", ticks, 255);
  fx(entity, "mining_fatigue", ticks, 255);
}

// 구버전의 점프 강화 200단계가 남은 플레이어/대상만 해제합니다.
// 일반 점프 강화 I~V는 그대로 둡니다.
function clearLegacyJumpBoost(entity) {
  try {
    const effect = entity.getEffect("jump_boost");
    if (effect && effect.amplifier >= 100) entity.removeEffect("jump_boost");
  } catch { /* 효과를 읽을 수 없거나 대상이 이미 사라짐 */ }
}

// (기본 피해 + 힘 버프 증가분) x 강펀치 배율
function power(player, base, mult) {
  return (base + strengthDamageBonus(player)) * mult;
}

function bodyCenter(e) {
  const l = e.location;
  return { x: l.x, y: l.y + 1, z: l.z };
}

// 일반 피해(방어력 적용). 강펀치가 '평타'로 착각하지 않도록 표시를 남깁니다.
function strike(target, player, amount) {
  if (areAllies(player, target)) return false;
  markSkillHit(target.id, player.id);
  return hurt(target, player, amount, "physical", {strengthIncluded:true});
}

// 방어력/무적 시간을 무시하는 고정 피해
function trueHit(target, player, amount) {
  if (areAllies(player, target)) return false;
  try {
    target.applyDamage(amount, { cause: EntityDamageCause.override, damagingEntity: player });
    return true;
  } catch {
    return strike(target, player, amount);
  }
}

function ring(dim, c, r, id, n = 16, dy = 0) {
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    particle(dim, id, { x: c.x + Math.cos(a) * r, y: c.y + dy, z: c.z + Math.sin(a) * r });
  }
}

function pathClear(dim, a, b) {
  const d = dist3(a, b);
  const n = Math.max(1, Math.floor(d));
  for (let i = 1; i < n; i++) {
    const p = {
      x: a.x + ((b.x - a.x) * i) / n,
      y: a.y + ((b.y - a.y) * i) / n,
      z: a.z + ((b.z - a.z) * i) / n,
    };
    if (isSolidAt(dim, p)) return false;
  }
  return true;
}

// 바라보는 방향(원뿔) 안에서 가장 가까운 대상. minDot 은 시선과의 cos 값(0.85 ≈ 32도).
function nearestInView(player, range, minDot) {
  const dim = player.dimension;
  const eye = headPos(player);
  const v = player.getViewDirection();
  let best;
  let bestD = Infinity;
  for (const t of getTargets(player, eye, range)) {
    const c = bodyCenter(t);
    const dx = c.x - eye.x;
    const dy = c.y - eye.y;
    const dz = c.z - eye.z;
    const d = Math.hypot(dx, dy, dz) || 0.001;
    if ((dx * v.x + dy * v.y + dz * v.z) / d < minDot) continue;
    if (!pathClear(dim, eye, c)) continue;
    if (d < bestD) {
      bestD = d;
      best = t;
    }
  }
  return best;
}

function validTarget(target, player, radius) {
  try {
    return (
      !!target &&
      healthAlive(target) && !areAllies(player, target) &&
      target.dimension.id === player.dimension.id &&
      dist3(target.location, player.location) <= radius
    );
  } catch {
    return false;
  }
}

function trail(dim, a, b) {
  const n = Math.min(24, Math.max(1, Math.floor(dist3(a, b) / 0.6)));
  for (let i = 0; i <= n; i++) {
    particle(dim, RED, {
      x: a.x + ((b.x - a.x) * i) / n,
      y: a.y + 1 + ((b.y - a.y) * i) / n,
      z: a.z + ((b.z - a.z) * i) / n,
    });
  }
}

// ---------------------------------------------------------------------------
// 스킬
// ---------------------------------------------------------------------------
export const RUNNERS = {
  // 강펀치: 사용 후 다음 N번의 공격(평타 1회 / 피해를 주는 스킬 1회)이 2배 피해.
  // 피해량은 힘 버프가 적용된 최종 피해를 기준으로 2배가 됩니다.
  fist_strong(player, job, def) {
    giveDoubleBuff(player, def.hits, def.duration);
    const dim = player.dimension;
    const l = player.location;
    ring(dim, { x: l.x, y: l.y, z: l.z }, 0.9, RED, 14, 0.2);
    ring(dim, { x: l.x, y: l.y, z: l.z }, 0.9, HIT, 8, 1.0);
    sound(dim, "random.anvil_land", l, { volume: 0.5, pitch: 1.6 });
    sound(dim, "mob.irongolem.throw", l, { volume: 0.8, pitch: 0.8 });
    notify(player, `§c강펀치! §7다음 ${def.hits}번 공격 피해 2배`);
  },

  // 난타: 대상에게 달라붙어 연속으로 때립니다. damage 는 전체 합계(체력 10칸 = 20).
  fist_flurry(player, job, def) {
    const dim = player.dimension;
    const origin = { ...player.location };
    const rot = player.getRotation();

    let target = getLastHit(player);
    if (!validTarget(target, player, def.radius)) target = nearestInView(player, def.range, 0.7);
    if (!target) {
      notify(player, "§7난타할 대상이 없습니다. 먼저 공격하거나 대상을 바라보세요.");
      return false;
    }

    const mult = takeDouble(player);
    const perHit = power(player, def.damage, mult) / def.hits;
    if (mult > 1) notify(player, `§c강펀치 적용! §7남은 횟수 ${doubleLeft(player)}`);

    fx(player, "resistance", def.hits * def.stepTicks + 20, 1);

    let hitCount = 0;
    let tick = 0;
    let last = origin;

    const finish = () => {
      system.clearRun(id);
      try {
        if (def.returnToOrigin) {
          trail(dim, last, origin);
          teleportForSkill(player,origin, { rotation: rot });
        }
      } catch {
        // 플레이어가 사라진 경우
      }
    };

    const id = system.runInterval(() => {
      try {
        if (hitCount >= def.hits || !healthAlive(target)) {
          finish();
          return;
        }
        if (tick % def.stepTicks === 0) {
          const tl = target.location;
          // 대상 둘레를 돌며 매번 다른 각도에서 때린다
          const ang = hitCount * 2.4;
          let stand = { x: tl.x + Math.cos(ang) * 1.3, y: tl.y, z: tl.z + Math.sin(ang) * 1.3 };
          if (isSolidAt(dim, stand) || isSolidAt(dim, { x: stand.x, y: stand.y + 1, z: stand.z })) {
            stand = { x: tl.x, y: tl.y, z: tl.z };
          }
          teleportForSkill(player,stand, { facingLocation: { x: tl.x, y: tl.y + 1, z: tl.z } });
          trueHit(target, player, perHit);
          const finisher = hitCount === def.hits - 1;
          knockback(target, tl.x - stand.x, tl.z - stand.z, finisher ? 1.0 : 0.1, finisher ? 0.4 : 0.05);
          particle(dim, HIT, { x: tl.x, y: tl.y + 1, z: tl.z });
          particle(dim, finisher ? BOOM : RED, { x: tl.x, y: tl.y + 1, z: tl.z });
          sound(dim, finisher ? "random.explode" : "mob.irongolem.hit", tl, {
            volume: finisher ? 0.7 : 0.5,
            pitch: 1.2 + hitCount * 0.04,
          });
          last = stand;
          hitCount++;
        }
        tick++;
      } catch {
        finish();
      }
    }, 1);
  },

  // 스매쉬: 1초 모았다가 바라보는 방향의 가장 가까운 대상에게 날아가 주먹을 날림 (최대 32블럭)
  fist_smash(player, job, def) {
    const dim = player.dimension;
    const target = nearestInView(player, def.range, def.coneDot);
    if (!target) {
      notify(player, "§7바라보는 방향에 대상이 없습니다.");
      return false;
    }

    const mult = takeDouble(player);
    const damage = power(player, def.damage, mult);
    if (mult > 1) notify(player, `§c강펀치 적용! §7남은 횟수 ${doubleLeft(player)}`);

    // 모으는 동안은 제자리에 서 있고, 날아가는 동안에는 받는 피해가 크게 줄어듭니다.
    clearLegacyJumpBoost(player);
    fx(player, "slowness", def.charge + 2, 255);
    fx(player, "resistance", def.charge + 60, 1);
    sound(dim, "mob.irongolem.repair", player.location, { volume: 1.0, pitch: 0.6 });

    const punch = () => {
      try {
        if (!healthAlive(target)) return;
        const horizontalGap=Math.hypot(target.location.x-player.location.x,target.location.z-player.location.z);
        if(horizontalGap>3.2)return;
        const tl = target.location;
        const pl = player.location;
        strike(target, player, damage);
        knockback(target, tl.x - pl.x, tl.z - pl.z, def.knockback, 0.45);
        const c = bodyCenter(target);
        particle(dim, BOOM, c);
        particle(dim, HIT, c);
        ring(dim, c, 1.2, RED, 14);
        sound(dim, "random.explode", tl, { volume: 0.9, pitch: 1.1 });
        sound(dim, "mob.irongolem.hit", tl, { volume: 1.0, pitch: 0.7 });
      } catch {
        // 대상이 사라짐
      }
    };

    const dash = () => {
      try {
        if (!healthAlive(target) || target.dimension.id !== dim.id) return;
        let last = { ...player.location };
        const dashY = player.location.y;
        const maxSteps = Math.ceil((def.range + 10) / def.dashSpeed) + 4;
        let steps = 0;
        const did = system.runInterval(() => {
          try {
            if (!healthAlive(target)) {
              system.clearRun(did);
              return;
            }
            const p = player.location;
            const tl = target.location;
            const dx = tl.x - p.x;
            const dz = tl.z - p.z;
            const d = Math.hypot(dx, dz) || 0.001;
            if (d <= 1.9 || ++steps > maxSteps) {
              system.clearRun(did);
              punch();
              return;
            }
            const mv = Math.min(def.dashSpeed, d - 1.6);
            const next = { x: p.x + (dx / d) * mv, y: dashY, z: p.z + (dz / d) * mv };
            trail(dim, last, next);
            teleportForSkill(player,next, { facingLocation: bodyCenter(target) });
            particle(dim, SMOKE, { x: next.x, y: next.y + 1, z: next.z });
            sound(dim, "item.trident.riptide_1", next, { volume: 0.4, pitch: 1.5 });
            last = next;
          } catch {
            system.clearRun(did);
          }
        }, 1);
      } catch {
        // 플레이어 상태를 읽을 수 없음
      }
    };

    let t = 0;
    const cid = system.runInterval(() => {
      try {
        const l = player.location;
        // 주먹으로 기운이 빨려 들어가는 연출
        const r = 2.6 * (1 - t / def.charge) + 0.3;
        for (let k = 0; k < 8; k++) {
          const a = (k / 8) * Math.PI * 2 + t * 0.4;
          particle(dim, RED, { x: l.x + Math.cos(a) * r, y: l.y + 0.6 + (k % 3) * 0.4, z: l.z + Math.sin(a) * r });
        }
        if (t % 5 === 0) sound(dim, "note.bass", l, { volume: 0.6, pitch: 0.6 + t * 0.06 });
        if (++t >= def.charge) {
          system.clearRun(cid);
          unfx(player, ["slowness"]);
          dash();
        }
      } catch {
        system.clearRun(cid);
      }
    }, 1);
  },

  // 풍압: 엔더드래곤 몸통박치기처럼 앞쪽 넓은 범위의 적을 멀리 날려 보냄
  fist_wind(player, job, def) {
    const dim = player.dimension;
    const l = player.location;
    const dir = flatDir(player);
    const damage = def.damage; // 풍압은 마력 판정이며 강펀치 횟수를 소비하지 않습니다.

    sound(dim, "mob.enderdragon.flap", l, { volume: 1.5, pitch: 0.7 });
    sound(dim, "mob.warden.sonic_boom", l, { volume: 0.6, pitch: 1.4 });

    for (const t of getTargets(player, { x: l.x, y: l.y + 1, z: l.z }, def.range)) {
      const tl = t.location;
      const dx = tl.x - l.x;
      const dz = tl.z - l.z;
      const len = Math.hypot(dx, dz) || 0.001;
      if ((dx * dir.x + dz * dir.z) / len < def.coneDot) continue;
      markSkillHit(t.id,player.id);
      hurt(t,player,damage,def.damageType);
      knockback(t, dx, dz, def.knockback, def.vertical);
      const c = bodyCenter(t);
      particle(dim, BOOM, c);
      particle(dim, HIT, c);
    }

    // 앞으로 퍼져 나가는 충격파
    const side = { x: -dir.z, z: dir.x };
    let dist = 1;
    const id = system.runInterval(() => {
      try {
        const o = player.location;
        const spread = dist * 0.9;
        for (let w = -spread; w <= spread; w += 0.8) {
          const p = {
            x: o.x + dir.x * dist + side.x * w,
            y: o.y + 1,
            z: o.z + dir.z * dist + side.z * w,
          };
          particle(dim, SMOKE, p);
          if (Math.abs(w) > spread * 0.7) particle(dim, HIT, p);
        }
        dist += 1.6;
        if (dist > def.range) system.clearRun(id);
      } catch {
        system.clearRun(id);
      }
    }, 1);
  },

  // 안면강타: 주변 6블럭 안의 모든 적을 영혼작살처럼 매 틱 시전자 정면으로 끌어당김.
  // 이전의 안전 지점 탐색 + 마지막 틱 순간이동은 실패하면 적이 움직이지 않는 문제가 있었음.
  // Y값을 변경하지 않고, 발/머리 공간이 막혀 있거나 바닥이 끊긴 지점은 넘지 않음.
  fist_face(player, job, def) {
    const dim = player.dimension;
    const origin = { ...player.location };
    const list = getTargets(player, origin, def.radius);
    sound(dim, "mob.ravager.roar", origin, { volume: 1.0, pitch: 0.92 });
    ring(dim, origin, def.radius, RED, 36, 0.3);
    ring(dim, origin, def.radius * 0.6, HIT, 20, 0.9);
    if (list.length === 0) return;

    const pullTicks = 10;
    const face = flatDir(player);
    const side = { x: -face.z, z: face.x };
    let tick = 0;
    // 한 타이머에서 모든 대상을 처리해 몬스터가 많아도 중복 간격 타이머가 생성되지 않도록 함.
    const victims = list.map((entity, index) => ({ entity, index }));
    for (const { entity } of victims) stun(entity, pullTicks + def.stun);

    const timer = system.runInterval(() => {
      try {
        if (!player.isValid || player.dimension.id !== dim.id || ++tick > pullTicks) {
          system.clearRun(timer);
          return;
        }
        const here = player.location;
        for (const { entity: target, index } of victims) {
          try {
            if (!healthAlive(target) || target.dimension.id !== dim.id || areAllies(player, target)) continue;
            const pos = target.location;
            if (dist3(pos, here) > def.radius + 5) continue;

            // 여러 대상이 한 블럭에 겹치지 않도록 약간씩 좌우로 모음.
            const lane = index === 0 ? 0 : (index % 2 ? 1 : -1) * Math.ceil(index / 2) * 0.40;
            const goal = {
              x: here.x + face.x * 1.65 + side.x * lane,
              z: here.z + face.z * 1.65 + side.z * lane,
            };
            const dx = goal.x - pos.x;
            const dz = goal.z - pos.z;
            const distance = Math.hypot(dx, dz);
            if (distance > 0.30) {
              const travel = Math.min(1.05, distance * 0.38);
              const next = {
                x: pos.x + dx / distance * travel,
                y: pos.y, // 이전 버전의 Y 급상승/공허 낙하 문제가 재발하지 않도록 높이를 고정
                z: pos.z + dz / distance * travel,
              };
              const free = !isSolidAt(dim, { x: next.x, y: next.y + 0.15, z: next.z }) &&
                !isSolidAt(dim, { x: next.x, y: next.y + 1.45, z: next.z });
              // 처음에 땅을 딛고 있던 대상은 바닥 없는 곳으로 끌어당기지 않음.
              const grounded = isSolidAt(dim, { x: pos.x, y: pos.y - 0.45, z: pos.z });
              const hasFloor = isSolidAt(dim, { x: next.x, y: next.y - 0.45, z: next.z });
              if (free && (!grounded || hasFloor)) {
                target.teleport(next, { dimension: dim, keepVelocity: false });
              }
            }
            const at = target.location;
            particle(dim, RED, { x: at.x, y: at.y + 1, z: at.z });
            if (tick % 2 === 0) particle(dim, SMOKE, { x: at.x, y: at.y + 0.75, z: at.z });
            if (tick === pullTicks) {
              particle(dim, HIT, bodyCenter(target));
              if (def.damage > 0) strike(target, player, power(player, def.damage, 1));
            }
          } catch { /* 사라진 몬스터나 텔레포트 불가 대상은 건너뜀 */ }
        }
        if (tick >= pullTicks) {
          system.clearRun(timer);
          sound(dim, "random.anvil_land", here, { volume: 0.9, pitch: 0.75 });
        }
      } catch {
        system.clearRun(timer);
      }
    }, 1);
  },

  // 강자의 자세: 1초간 자기 둔화, 15초간 힘/저항 버프
  fist_stance(player, job, def) {
    clearLegacyJumpBoost(player);
    const dim = player.dimension;
    const l = player.location;
    fx(player, "slowness", def.freeze, 255);
    fx(player, "strength", def.buffTicks, def.strengthAmp, true);
    fx(player, "resistance", def.buffTicks, def.resistanceAmp, true);
    sound(dim, "mob.irongolem.repair", l, { volume: 1.0, pitch: 0.5 });
    sound(dim, "beacon.activate", l, { volume: 0.8, pitch: 1.2 });
    notify(player, `§6강자의 자세! §7${def.freeze / 20}초간 움직일 수 없습니다.`);

    let t = 0;
    const id = system.runInterval(() => {
      try {
        const p = player.location;
        const r = 1.4 - (t % 20) * 0.04;
        ring(dim, p, Math.max(0.4, r), RED, 12, (t % 10) * 0.2);
        if (t % 10 === 0) particle(dim, HIT, { x: p.x, y: p.y + 1, z: p.z });
        t += 2;
        if (t >= def.freeze) system.clearRun(id);
      } catch {
        system.clearRun(id);
      }
    }, 2);
  },

  // 대미장식 (궁극기): 높이 15블럭의 상승/하강을 파티클로 시각화합니다.
  // 기존의 플레이어+대상 순간이동 방식은 평지맵의 공허 낙하, 처치/퇴장 시
  // 안전 위치 복구 실패 위험이 있어서 제거합니다. 대상은 원래 지면에 머뭅니다.
  fist_finale(player, job, def) {
    const dim = player.dimension;
    const target = getLastHit(player);
    if (!validTarget(target, player, def.radius)) {
      notify(player, "§7최근에 타격한 대상이 주변에 없습니다. 먼저 공격하세요.");
      return false;
    }

    clearLegacyJumpBoost(player);
    clearLegacyJumpBoost(target);
    const rise = Math.max(0, Math.min(15, Number(def.rise) || 15));
    const riseTicks = Math.max(1, Math.trunc(def.riseTicks || 20));
    const hoverTicks = Math.max(1, Math.trunc(def.hoverTicks || 10));
    const fallTicks = Math.max(3, Math.ceil(rise / Math.max(0.5, def.slamSpeed || 3)));
    const totalTicks = riseTicks + hoverTicks + fallTicks + 4;
    const origin = { ...target.location };
    fx(player, "resistance", totalTicks, 4);
    stun(target, totalTicks);
    sound(dim, "mob.ravager.roar", origin, { volume: 1.2, pitch: 0.7 });

    let tick = 0;
    let ended = false;
    let id;
    function finish() {
      if (ended) return;
      ended = true;
      if (id !== undefined) system.clearRun(id);
      try { unfx(target, STUN_EFFECTS); } catch {}
      try { unfx(player, ["resistance"]); } catch {}
      // 절대 target/player를 다른 Y좌표로 순간이동시키지 않습니다.
    }

    id = system.runInterval(() => {
      try {
        if (!healthAlive(target) || !healthAlive(player) ||
            target.dimension.id !== dim.id || player.dimension.id !== dim.id ||
            areAllies(player, target)) {
          finish();
          return;
        }
        const foot = target.location;
        let height;
        if (tick < riseTicks) {
          height = rise * (tick + 1) / riseTicks;
        } else if (tick < riseTicks + hoverTicks) {
          height = rise;
        } else {
          const elapsed = tick - riseTicks - hoverTicks + 1;
          height = rise * Math.max(0, 1 - elapsed / fallTicks);
        }
        const phantom = { x: foot.x, y: foot.y + height + 0.7, z: foot.z };
        // 시각 효과만 상승/하강: 실제 플레이어/적의 위치와 수직속도는 수정하지 않습니다.
        ring(dim, phantom, 1.25, RED, 12);
        particle(dim, SMOKE, { x: phantom.x, y: phantom.y - 0.25, z: phantom.z });
        if (tick % 3 === 0) particle(dim, HIT, phantom);
        if (tick++ < riseTicks + hoverTicks + fallTicks - 1) return;

        // 대상이 발을 딛고 있는 실제 위치에서 피해를 입힙니다.
        // 공중으로 순간이동하지 않으므로 평지맵이나 비정상 좌표에서도 공허로 떨어지지 않습니다.
        if (!areAllies(player, target)) {
          trueHit(target, player, def.damage);
          const at = target.location;
          const c = { x: at.x, y: at.y + 0.3, z: at.z };
          particle(dim, BOOM, c);
          ring(dim, c, 2.5, SMOKE, 24, 0.2);
          ring(dim, c, 4.5, RED, 36, 0.3);
          ring(dim, c, 6.5, HIT, 36, 0.3);
          sound(dim, "random.explode", c, { volume: 1.4, pitch: 0.6 });
          sound(dim, "mob.irongolem.hit", c, { volume: 1.2, pitch: 0.5 });
          sound(dim, "random.anvil_land", c, { volume: 1.2, pitch: 0.5 });
        }
        finish();
      } catch {
        finish();
      }
    }, 1);
  },
};


// v0.4.76: 복구 - 이전 수정 중 빠진 등록 함수 때문에 main.js 모듈이 로드되지 못했습니다.
// 무투가/권골의 기본 공격 강화, 낙하 보호 및 플레이어 종료 시 상태 정리를 복원합니다.
function isFistLine(player) {
  return JOBS[getJobId(player)]?.line === "fist" || hasBorrowedSkill(player,"fist_strong");
}
function noFall(player) {
  const job = JOBS[getJobId(player)];
  return job?.line === "fist" && job.tier >= 2;
}

export function registerFist() {
  world.afterEvents.playerLeave.subscribe((ev) => clearFistRuntime(ev.playerId));
  world.afterEvents.entityHurt.subscribe((ev) => {
    const victim = ev.hurtEntity;
    const cause = ev.damageSource?.cause;
    if (victim?.typeId === "minecraft:player" && cause === EntityDamageCause.fall && noFall(victim)) {
      try {
        const hp = victim.getComponent("minecraft:health");
        if (hp && hp.currentValue > 0) hp.setCurrentValue(Math.min(hp.effectiveMax, hp.currentValue + ev.damage));
      } catch { /* entity no longer active */ }
      return;
    }
    const attacker = ev.damageSource?.damagingEntity;
    if (attacker?.typeId !== "minecraft:player" || cause !== EntityDamageCause.entityAttack ||
        !victim || victim.id === attacker.id || !isFistLine(attacker) ||
        areAllies(attacker, victim)) return;
    if (consumeSkillMark(victim.id, attacker.id) || doubleLeft(attacker) <= 0) return;
    takeDouble(attacker);
    trueHit(victim, attacker, ev.damage);
    const pos = bodyCenter(victim);
    particle(victim.dimension, HIT, pos);
    particle(victim.dimension, RED, pos);
    sound(victim.dimension, "random.anvil_land", victim.location, { volume: 0.4, pitch: 1.5 });
    notify(attacker, doubleLeft(attacker) > 0
      ? `§c강펀치! §7남은 횟수 ${doubleLeft(attacker)}`
      : "§c강펀치 효과가 끝났습니다.");
  });
  // 낙하 직전 천천히 내려오도록 해 즉사 피해를 먼저 방지합니다.
  system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
      try {
        if (!noFall(player) || player.isOnGround || player.getVelocity().y > -0.6) continue;
        const at = player.location;
        for (let step = 1; step <= 6; step++) {
          if (isSolidAt(player.dimension, { x: at.x, y: at.y - step, z: at.z })) {
            fx(player, "slow_falling", 10, 0);
            break;
          }
        }
      } catch { /* ignore unloaded players */ }
    }
  }, 1);
}
