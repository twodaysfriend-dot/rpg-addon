import {system} from '@minecraft/server';
import {ActionFormData,ModalFormData} from '@minecraft/server-ui';
import {showForm} from './skillMenu.js';
import {lookupRpgQuestion,formatKnowledge,selectKnowledgeEntries,QUESTION_LIMIT,UNKNOWN_ANSWER} from './rpgKnowledge.js';
import {rankKnowledge} from './assistantTransport.js';
const busy=new Set(),nextAsk=new Map();
export async function answerRpgQuestion(question){
 const found=lookupRpgQuestion(question);
 if(found.status==='too_long')return {text:`질문은 ${QUESTION_LIMIT}자 이내로 입력해 주세요.`,mode:'local'};
 if(found.status!=='answer')return {text:UNKNOWN_ANSWER,mode:'local'};
 let selected=found.entries.slice(0,1),mode='local';
 try{
  const ranked=await rankKnowledge(String(question).trim(),found.entries);
  if(ranked!==undefined){const valid=selectKnowledgeEntries(found.entries,ranked);if(valid!==undefined){selected=valid;mode='api';}}
 }catch{/* Connection errors keep the canonical local answer available. */}
 return {text:formatKnowledge(selected),mode};
}
export async function askRpg(p,question=''){
 if(busy.has(p.id))return;
 if((nextAsk.get(p.id)??0)>system.currentTick){p.sendMessage('§7질문은 2초 간격으로 할 수 있습니다.');return;}
 for(const [id,until]of nextAsk)if(until<=system.currentTick)nextAsk.delete(id);
 nextAsk.set(p.id,system.currentTick+40);busy.add(p.id);
 try{
  let q=String(question??'').trim(),formMode=!q;
  if(formMode){
   const form=new ModalFormData().title('RPG 정보 질문').textField('이 애드온의 직업·스킬·제작·던전 질문','예: 해커 전직 조건');
   const reply=await showForm(form,p);if(!reply||reply.canceled)return;
   q=String(reply.formValues?.[0]??'').trim();if(!q)return;
  }
  const result=await answerRpgQuestion(q);if(!p.isValid)return;
  if(formMode)await showForm(new ActionFormData().title('RPG 정보 안내').body(result.text).button('닫기'),p);
  else p.sendMessage('§b[RPG 안내]§r '+result.text);
 }catch{try{p.sendMessage('§7정보 창을 열지 못했습니다. /rpg:skillguide 또는 /rpg:craft를 이용하세요.');}catch{}}
 finally{busy.delete(p.id);}
}
