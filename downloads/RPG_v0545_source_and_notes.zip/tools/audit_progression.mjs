// Reproducible code/API-mock audit; these are not measured Bedrock clear times.
import fs from 'node:fs';
import {player,events} from '../tests/minecraftMock.mjs';
import {xpForNext,getXp,getLevel,registerRpgStats} from '../RPG_BP_v0545/scripts/core/stats.js';
import {getProgress} from '../RPG_BP_v0545/scripts/core/playerData.js';
import {getWallet} from '../RPG_BP_v0545/scripts/core/wallet.js';
import {DUNGEON_TIERS,HUNT_REWARDS,clearRewardForTier} from '../RPG_BP_v0545/scripts/data/dungeons.js';
registerRpgStats();const emit=events.entityDie.listeners.at(-1);
const killExamples={};
for(const typeId of ['minecraft:zombie','minecraft:chicken','rpg:green_goblin','rpg:elite_green_goblin','rpg:rock_golem_boss']){
 const p=player(typeId),random=Math.random;
 try{Math.random=()=>.5;emit({deadEntity:{typeId},damageSource:{damagingEntity:p}});}finally{Math.random=random;}
 const earnedXp=getXp(p)+Array.from({length:getLevel(p)-1},(_,n)=>xpForNext(n+1)).reduce((a,b)=>a+b,0);
 killExamples[typeId]={earnedXp,wallet:getWallet(p),trialKills:getProgress(p).job_kills??0};
}
const levels=[10,20,25,40,100].map(level=>{
 const xp=Array.from({length:level-1},(_,n)=>xpForNext(n+1)).reduce((a,b)=>a+b,0);
 return {level,xp,normalKillsAt20Xp:Math.ceil(xp/20)};
});
const gold=tier=>50*HUNT_REWARDS.normal.gold+5*HUNT_REWARDS.elite.gold+HUNT_REWARDS.boss.gold+clearRewardForTier(tier).gold;
const output={basis:'v0.5.45 source + mocked entity death events; no client gameplay timing',levels,killExamples,
 firstTenWithManualQuestKills:Math.ceil((levels[0].xp-100)/20),
 firstClassMaterials:{swordsman:{diamondSwords:5,diamondsToCraft:10},mage:{enchantedBooks:10},fighter:{bags:2,hayBlocks:18,wheatToCraft:162},fistBoneAdditional:{bags:10,hayBlocks:90,wheatToCraft:810}},
 michaelSoloPrayer:{light:192,angelLightPerDay:2,prayers:96,naturalWorldHoursWithoutSleep:32},
 dungeons:{tier1GoldIncludingAllKillPayouts:gold(1),tier10GoldIncludingAllKillPayouts:gold(10),tier10GoldIncreasePercent:100*(gold(10)/gold(1)-1),tier10HpMultiplier:DUNGEON_TIERS[9].hpMultiplier},
};
fs.writeFileSync(new URL('../v0545_진행점검_수치.json',import.meta.url),JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output,null,2));
