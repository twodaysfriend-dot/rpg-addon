"""Integrate generated art: split sprites and pack material swatches into armor UVs.

No illustration is drawn here. Nearest-neighbor resizing preserves hard pixels;
the armor atlas uses the built-in Bedrock humanoid armor geometry UV layout.
"""
from pathlib import Path
from PIL import Image
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
BP = ROOT / 'RPG_BP_v0545'
RP = ROOT / 'RPG_RP_v0545'
SOURCE = ROOT / 'art' / 'transparent_sheet.png'
sheet = Image.open(SOURCE).convert('RGBA')
parts = ['helmet','chestplate','leggings','boots']
part_names = ['투구','흉갑','각반','장화']
sets = {
    'adventurer': ('모험가', [2,5,4,2], [220,320,300,220]),
    'warden': ('숲 수호자', [3,6,5,2], [300,450,420,300]),
    'astral': ('별빛 술사', [2,5,4,2], [260,400,375,260]),
}
runes = {'power':'힘의 룬', 'ward':'수호의 룬', 'mana':'샘의 룬', 'arcane':'비전의 룬', 'vitality':'생명의 룬'}

def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

def tile(col,row):
    w,h=sheet.size
    return sheet.crop((col*w//6,row*h//4,(col+1)*w//6,(row+1)*h//4)).resize((128,128),Image.Resampling.NEAREST)

texture_path = RP / 'textures/item_texture.json'
texture_data = json.loads(texture_path.read_text())
icons = [f'{s}_{p}' for s in sets for p in parts] + [f'rune_{r}' for r in runes]
icon_dir = RP / 'textures/items/rpg_equipment'
icon_dir.mkdir(parents=True,exist_ok=True)
for index,name in enumerate(icons):
    icon=tile(index%6,index//6)
    # Alpha-test material export: eliminate hidden RGB halos and soft alpha.
    icon.putdata([(r,g,b,255) if a>=128 else (0,0,0,0) for r,g,b,a in icon.get_flattened_data()])
    icon.save(icon_dir/(name+'.png'))
    texture_data['texture_data']['rpg_'+name]={'textures':'textures/items/rpg_equipment/'+name}
write(texture_path,texture_data)

# Vanilla armor 64x32 UV coordinates, packed into an actual 128x128 PNG.
# Texture coordinates are normalized by the built-in geometry dimensions.
uvs = [
    (0,0,8,8,8),    # head
    (16,16,8,12,4), # body
    (40,16,4,12,4), # arms (mirrored by vanilla armor geometry)
    (0,16,4,12,4),  # legs / boots
]
armor_dir=RP/'textures/models/armor/rpg';armor_dir.mkdir(parents=True,exist_ok=True)
for si,(set_name,(label,protection,durability)) in enumerate(sets.items()):
    plate=tile(si*2,3); cloth=tile(si*2+1,3)
    for layer in [1,2]:
        atlas=Image.new('RGBA',(128,128),(0,0,0,0))
        for u,v,w,h,d in uvs:
            # Six faces in Bedrock cube box-UV order.
            faces=[(u+d,v,w,d),(u+d+w,v,w,d),(u,v+d,d,h),
                   (u+d,v+d,w,h),(u+d+w,v+d,d,h),(u+2*d+w,v+d,w,h)]
            for x,y,fw,fh in faces:
                material=cloth if layer==2 else plate
                atlas.paste(material.resize((fw*2,fh*4),Image.Resampling.NEAREST),(x*2,y*4))
        if layer==1:
            # Open visor/face, leaving a pixel brow, nose guard and temples.
            for box in [(9,11,11,16),(12,11,15,16)]:
                x1,y1,x2,y2=box
                atlas.paste((0,0,0,0),(x1*2,y1*4,x2*2,y2*4))
        atlas.putdata([(r,g,b,255) if a>=128 else (0,0,0,0) for r,g,b,a in atlas.get_flattened_data()])
        atlas.save(armor_dir/f'{set_name}_{layer}.png')

    for index,part in enumerate(parts):
        identifier=f'rpg:{set_name}_{part}'
        repair={'adventurer':'minecraft:iron_ingot','warden':'minecraft:emerald','astral':'minecraft:amethyst_shard'}[set_name]
        item={
            'format_version':'1.21.90',
            'minecraft:item':{
                'description':{'identifier':identifier,'menu_category':{'category':'equipment'}},
                'components':{
                    'minecraft:display_name':{'value':f'{label} {part_names[index]}'},
                    'minecraft:icon':'rpg_'+set_name+'_'+part,
                    'minecraft:max_stack_size':1,
                    'minecraft:wearable':{'slot':['slot.armor.head','slot.armor.chest','slot.armor.legs','slot.armor.feet'][index],'protection':protection[index]},
                    'minecraft:durability':{'max_durability':durability[index]},
                    'minecraft:enchantable':{'slot':['armor_head','armor_torso','armor_legs','armor_feet'][index],'value':12},
                    'minecraft:repairable':{'repair_items':[{'items':[repair],'repair_amount':60}]},
                },
            },
        }
        write(BP/'items'/f'{set_name}_{part}.json',item)
        layer=2 if part=='leggings' else 1
        visible={'helmet':'helmet','chestplate':'chest','leggings':'leg','boots':'boot'}[part]
        attachable={'format_version':'1.8.0','minecraft:attachable':{'description':{
            'identifier':identifier,
            'materials':{'default':'armor','enchanted':'armor_enchanted'},
            'textures':{'default':f'textures/models/armor/rpg/{set_name}_{layer}','enchanted':'textures/misc/enchanted_actor_glint'},
            'geometry':{'default':'geometry.humanoid.armor.'+part},
            'scripts':{'parent_setup':f'variable.{visible}_layer_visible = 0.0;'},
            'render_controllers':['controller.render.armor'],
        }}}
        write(RP/'attachables'/f'{set_name}_{part}.json',attachable)
        if set_name=='adventurer':
            # Copper accent makes all four patterns distinct from vanilla armor.
            patterns=[['ICI','I I'],['I I','ICI','III'],['ICI','I I','I I'],['I I','ICI']]
            recipe={'format_version':'1.20.10','minecraft:recipe_shaped':{
                'description':{'identifier':identifier},'tags':['crafting_table'],
                'pattern':patterns[index],'key':{'I':{'item':'minecraft:iron_ingot'},'C':{'item':'minecraft:copper_ingot'}},
                'result':{'item':identifier,'count':1},
            }}
        else:
            material='minecraft:emerald' if set_name=='warden' else 'minecraft:amethyst_shard'
            extra='minecraft:oak_planks' if set_name=='warden' else 'minecraft:lapis_lazuli'
            recipe={'format_version':'1.20.10','minecraft:recipe_shapeless':{
                'description':{'identifier':identifier},'tags':['crafting_table'],
                'ingredients':[{'item':f'rpg:adventurer_{part}'}, {'item':material},{'item':material},{'item':extra}],
                'result':{'item':identifier,'count':1},
            }}
        write(BP/'recipes'/f'{set_name}_{part}.json',recipe)

cores={
    'power':['minecraft:redstone','minecraft:iron_ingot'],
    'ward':['minecraft:iron_ingot','minecraft:iron_ingot'],
    'mana':['minecraft:lapis_lazuli','minecraft:lapis_lazuli'],
    'arcane':['minecraft:ender_pearl','minecraft:lapis_lazuli'],
    'vitality':['minecraft:golden_apple'],
    'haste':['minecraft:sugar','minecraft:sugar'],
}
for rune,label in runes.items():
    identifier='rpg:rune_'+rune
    write(BP/'items'/f'rune_{rune}.json',{
        'format_version':'1.21.90','minecraft:item':{
            'description':{'identifier':identifier,'menu_category':{'category':'items'}},
            'components':{'minecraft:display_name':{'value':label},'minecraft:icon':'rpg_rune_'+rune,'minecraft:max_stack_size':64},
        },
    })
    ingredients=['minecraft:amethyst_shard']*3+['minecraft:redstone']+cores[rune]
    write(BP/'recipes'/f'rune_{rune}.json',{
        'format_version':'1.20.10','minecraft:recipe_shapeless':{
            'description':{'identifier':identifier},'tags':['crafting_table'],
            'ingredients':[{'item':i} for i in ingredients],'result':{'item':identifier,'count':1},
        },
    })

print('Wrote 18 item icons and 6 armor atlases, all 128x128; 18 items/recipes, 12 attachables.')
