"""Build Unit-01 geometry, pose tracks and pixel art. Pillow is used only to rebuild artwork."""
from pathlib import Path
import json
import math
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
RP = ROOT / 'RPG_RP_v0638'
GEOMETRY = 'geometry.rpg.eva_unit_01'
ANIMATION = 'animation.rpg.eva_unit_01.'
CONTROLLER = 'controller.animation.rpg.eva_unit_01'
RENDER = 'controller.render.rpg.eva_unit_01'
ACTIVE = "query.property('rpg:eva_action')"
BERSERK = "query.property('rpg:eva_berserk')"
FACES = ('north', 'south', 'east', 'west', 'up', 'down')


def write_json(path, contents):
    path.write_text(json.dumps(contents, ensure_ascii=False, indent=2) + '\n')


# Each material has its own directional pixel-art tile, with model-space panel lines.
materials = {
    'purple': ('#44216c', '#7337a6', '#9a5ec9', '#211539'),
    'violet': ('#5b287f', '#8645ba', '#b87ee4', '#32194c'),
    'darkviolet': ('#291c47', '#483168', '#664990', '#161324'),
    'black': ('#151a27', '#292d40', '#454758', '#0d1119'),
    'rib': ('#212737', '#3b3f50', '#626675', '#15161f'),
    'green': ('#345f13', '#629b28', '#a6d34a', '#28400c'),
    'lime': ('#6fa22a', '#a8de40', '#d8f779', '#3a6317'),
    'steel': ('#394357', '#55647c', '#8093a6', '#252d3f'),
    'gold': ('#986028', '#d59a42', '#f9cc65', '#63401f'),
    'eye': ('#9acb55', '#ecffab', '#ffffe0', '#677a28'),
    'red': ('#68153d', '#a62758', '#e54c74', '#3e1230'),
    'blade': ('#487478', '#86c6c9', '#e3ffff', '#2d4f5b'),
    'lens': ('#324366', '#3d87b2', '#88effa', '#19284c'),
    'serial': ('#251638', '#633187', '#b088b7', '#110d20'),
}
index = {name: i for i, name in enumerate(materials)}
face_shade = [-.01, -.16, -.10, -.18, .13, -.27]


def shade(hex_color, delta):
    return tuple(min(255, max(0, round(int(hex_color[i:i+2], 16) * (1 + delta)))) for i in (1, 3, 5))


def atlas(berserk=False):
    image = Image.new('RGBA', (128, 256))
    for name, colors in materials.items():
        if berserk and name in ('eye', 'lime', 'lens'):
            colors = ('#a12137', '#ef5240', '#ffcf94', '#6d173b') if name != 'lens' else ('#74364f', '#cb356e', '#ff94a8', '#40244a')
        for face, value in enumerate(face_shade):
            x, y = face*16, index[name]*16
            base, high, edge, low = [shade(color, value) for color in colors]
            d = ImageDraw.Draw(image)
            d.rectangle((x, y, x+15, y+15), fill=base)
            d.polygon([(x+1,y+1),(x+14,y+1),(x+14,y+9),(x+10,y+14),(x+1,y+14)], fill=high)
            d.line((x+1,y+1,x+13,y+1), fill=edge)
            d.line((x+1,y+2,x+1,y+11), fill=edge)
            d.line((x+2,y+14,x+10,y+14,x+14,y+10), fill=low)
            d.line((x,y+15,x+15,y+15,x+15,y), fill=low)
            if name in ('purple','violet','steel','darkviolet'):
                d.line((x+4,y+3,x+11,y+3), fill=shade(colors[2], value-.26))
                d.point((x+12,y+10), fill=edge)
                d.line((x+3,y+11,x+6,y+11), fill=shade(colors[0],value+.10))
                d.point((x+9,y+6), fill=shade(colors[1],value+.1))
            if name in ('rib','black'):
                for v in (5,8,11):
                    d.line((x+2,y+v,x+13,y+v), fill=low)
            if name in ('eye','lime','lens','blade'):
                d.line((x+3,y+4,x+12,y+4), fill=edge, width=2)
            if name == 'serial' and face == 0:
                d.line((x+3,y+5,x+3,y+11,x+6,y+11,x+6,y+5,x+3,y+5), fill=edge)
                d.line((x+10,y+6,x+12,y+5,x+12,y+11), fill=edge)
    return image


bones = []


def bone(name, pivot, parent=None):
    entry = {'name':'eva_'+name, 'pivot':pivot, 'cubes':[]}
    if parent:
        entry['parent'] = 'eva_'+parent
    bones.append(entry)
    return entry['cubes']


def cube(origin, size, material, rotation=None, pivot=None, front=None):
    uv = {face:{'uv':[i*16,index[front if i == 0 and front else material]*16], 'uv_size':[16,16]} for i,face in enumerate(FACES)}
    result = {'origin':origin, 'size':size, 'uv':uv}
    if rotation:
        result.update(rotation=rotation, pivot=pivot or [p+s/2 for p,s in zip(origin,size)])
    return result


def box(cubes, origin, size, material, rotation=None, pivot=None, front=None):
    cubes.append(cube(origin,size,material,rotation,pivot,front))


def sided(cubes, side, x, y, z, w, h, depth, material, tilt=None, turn=0, front=None):
    origin = [x if side>0 else -x-w, y, z]
    return box(cubes,origin,[w,h,depth],material,[turn,0,(tilt or 0)*side] if tilt or turn else None,front=front)


bone('root',[0,0,0])
pelvis=bone('pelvis',[0,39,0],'root')
box(pelvis,[-6,34,-3.2],[12,8,7.7],'black')
box(pelvis,[-5.5,34.5,-4.2],[11,5.4,5],'darkviolet')
box(pelvis,[-2,33.7,-5.2],[4,5,3.2],'purple',[12,0,0])
box(pelvis,[-1.1,35.1,-5.7],[2.2,2.8,.8],'gold',[14,0,0])
box(pelvis,[-5,36.2,2.9],[10,4.8,2.8],'violet')
spine=bone('spine',[0,40,0],'pelvis')
for i in range(4):
    box(spine,[-4.1+i*.2,40+i*2,-3.5+i*.3],[8.2-i*.4,1.7,7.3],'green' if i%2==0 else 'rib')
    box(spine,[-1.7,40+i*2,-4.1+i*.13],[3.4,1.15,1.6],'lime' if i==2 else 'black')
chest=bone('chest',[0,48,0],'spine')
box(chest,[-7.5,48,-4],[15,11,9],'black')
box(chest,[-6.7,48.5,2.8],[13.4,9,3.5],'purple')
box(chest,[-4.1,49.7,5.4],[8.2,8.4,2.9],'darkviolet')
box(chest,[-1.9,50,-5.6],[3.8,9.1,3.5],'darkviolet',[9,0,0])
box(chest,[-1,49,-5.22],[2,4.8,1.6],'red')
box(chest,[-2.2,57,6.5],[4.4,2.4,2.1],'steel')
box(chest,[-.65,57.4,8.4],[1.3,1.35,.5],'lens')
for side in (-1,1):
    sided(chest,side,.85,53.5,-6.34,7.2,4.35,5.9,'violet',-13,14)
    sided(chest,side,1.9,51.1,-5.65,5.9,3.4,3.6,'purple',-22,17)
    sided(chest,side,4.5,55.9,-6.95,3.9,1.6,1.4,'lime',-10)
    sided(chest,side,4.2,48.4,-.6,3.75,4.8,5.5,'darkviolet',-14)
    sided(chest,side,4.45,50,5.6,1.7,6.4,1.1,'rib',9)
    sided(chest,side,3.9,55.5,6.1,1.9,1.2,1.8,'green',14)
neck=bone('neck',[0,59,0],'chest')
box(neck,[-2.85,57,-2.7],[5.7,6,5.7],'rib',[-12,0,0])
box(neck,[-2.8,61,1.4],[5.6,2.6,2.7],'violet')
head=bone('head',[0,63,-.6],'neck')
box(head,[-3.45,63,-3.9],[6.9,8.1,7.1],'purple')
box(head,[-2.65,70,-3.0],[5.3,2.3,5.4],'violet',[-10,0,0])
box(head,[-2.4,65.1,-5],[4.8,4.6,2.9],'black',[11,0,0])
box(head,[-.75,68.2,-5.8],[1.5,3,1.8],'darkviolet',[13,0,0])
box(head,[-.92,70.4,-5.85],[1.84,4.1,2.2],'violet',[21,0,0])
box(head,[-.62,73.2,-6.78],[1.24,4.8,1.35],'lime',[26,0,0])
box(head,[-.32,77.3,-7.29],[.64,3.2,.78],'purple',[28,0,0])
for side in (-1,1):
    sided(head,side,1.95,66.7,-5.25,2.1,3.6,4.1,'green',12,13)
    sided(head,side,.48,67.45,-5.59,2.48,.78,1.1,'eye',-13)
    sided(head,side,2.98,65.55,-2.6,1.25,4.1,3.2,'violet',-10)
    sided(head,side,3.6,67.5,-.62,.85,1.9,2,'lime',8)
    sided(head,side,1.9,61.95,-3.5,1.55,3.9,4.1,'purple',13)
jaw=bone('jaw',[0,64.4,-1.1],'head')
box(jaw,[-2.6,61.6,-5.6],[5.2,2.65,4.7],'darkviolet',[-11,0,0])
box(jaw,[-2.05,63.25,-5.79],[4.1,.66,2.4],'steel',[-10,0,0])
box(jaw,[-1.58,62.1,-6.05],[3.16,1.0,2.4],'gold',[10,0,0])
box(jaw,[-1.3,61.55,-4.9],[2.6,.85,2.6],'green')
for x in (-1.7,-.58,.54,1.66):
    box(head,[x,64.1,-4.7],[.44,1.14,.74],'blade',[8,0,0])
    box(jaw,[x,63.32,-4.85],[.43,.7,.7],'steel',[-6,0,0])

for side, suffix in ((-1,'r'),(1,'l')):
    shoulder=bone('shoulder_'+suffix,[side*7.6,55,0],'chest')
    sided(shoulder,side,6.4,51.3,-3,5.4,6.9,6.4,'violet',-14)
    sided(shoulder,side,8.8,52.8,-3.3,3.3,3.9,6.8,'purple',-15,front='serial')
    pylon=bone('pylon_'+suffix,[side*9.7,55.4,1.0],'shoulder_'+suffix)
    sided(pylon,side,9,55.7,-1.9,3.55,11.6,6,'darkviolet',7,-7)
    sided(pylon,side,9.34,63.5,-1.3,2.85,6.2,4.6,'purple',6,-9)
    sided(pylon,side,9.7,68.1,-.6,2.12,6.2,3.1,'violet',5,-14)
    sided(pylon,side,10.2,72.8,-.1,1.45,2.9,2.0,'darkviolet',4,-14)
    sided(pylon,side,11.25,57.4,-2.06,1.35,8.6,1.2,'lime',6,-7)
    sided(pylon,side,10.8,58.0,3.1,1.8,5.1,1.0,'green',7)
    arm=bone('upper_arm_'+suffix,[side*9.7,53.8,.1],'shoulder_'+suffix)
    sided(arm,side,8.1,43.2,-2.35,4,11.2,4.9,'black',6)
    sided(arm,side,7.65,48,-3,4.8,5.8,4.9,'purple',9)
    sided(arm,side,8.2,45.6,-2.9,4.5,2.8,5.5,'green',6)
    forearm=bone('forearm_'+suffix,[side*10.65,43.8,-.15],'upper_arm_'+suffix)
    sided(forearm,side,8.7,34.6,-2.27,4.6,9.5,4.9,'black',4)
    sided(forearm,side,9.35,36.3,-3.05,4.7,7.7,3.2,'violet',6)
    sided(forearm,side,10.3,38.6,-3.48,3.0,4.7,1.0,'green',3)
    sided(forearm,side,10,34.2,-2.55,3.3,2.2,5.05,'darkviolet',4)
    hand=bone('hand_'+suffix,[side*11.65,35.7,.02],'forearm_'+suffix)
    sided(hand,side,9.8,32,-2,3.65,4.1,4.1,'steel',5)
    sided(hand,side,9.27,31.35,-2.92,1.2,3.4,1.78,'gold',-17)
    for i in range(3):
        sided(hand,side,10.1+i*1.13,30.1,-2.05,1.02,2.9,2.1,'rib',3)
        sided(hand,side,10.1+i*1.13,30.1,-2.25,1.02,1,1.9,'gold',3)

    thigh=bone('thigh_'+suffix,[side*4.35,37.15,.5],'pelvis')
    sided(thigh,side,1.4,21.5,-2.7,6.1,16,6.2,'black',6)
    sided(thigh,side,1.7,23.6,-4.5,6.8,12.1,5.6,'purple',7,8)
    sided(thigh,side,4.7,23,-3.4,4.3,11.95,6.3,'darkviolet',7,9)
    sided(thigh,side,1.75,31.9,-5.1,4.2,4.9,2.5,'violet',8,8)
    sided(thigh,side,3.1,22.2,-4.6,3.3,3.2,2.3,'gold',5)
    shin=bone('shin_'+suffix,[side*5.35,22.55,-.05],'thigh_'+suffix)
    sided(shin,side,2.8,5.2,-2.6,5,17.8,5.75,'black',3)
    sided(shin,side,2.5,15.0,-4.05,6.55,7.7,6.45,'violet',5)
    sided(shin,side,2.9,8.1,-3.75,6.35,8.1,5.0,'purple',6)
    sided(shin,side,4.9,11.4,1.8,4.27,8.5,3.14,'darkviolet',6)
    for i in range(3):
        sided(shin,side,3.6,13.05+i*2.15,-4.6-i*.07,4.7,.8,1.1,'darkviolet',4)
    sided(shin,side,7.0,16.15,-4.85,1.4,3.2,1.9,'lime',6)
    sided(shin,side,4,5.0,-3.9,4.6,4.6,5.1,'green',5)
    foot=bone('foot_'+suffix,[side*5.75,5.7,.4],'shin_'+suffix)
    sided(foot,side,2.75,.5,-6.4,7.3,2.0,10.6,'gold')
    sided(foot,side,2.65,2.12,-6.45,7.6,2.3,10.1,'purple')
    sided(foot,side,3.15,2.95,-3.9,6.6,3.38,7.35,'darkviolet',0,10)
    sided(foot,side,3.42,3.8,-3.55,4.9,2.15,2.75,'lime',0,10)
    sided(foot,side,7.4,2.8,-6.9,2.7,2.1,4.0,'violet')

knife=bone('knife',[-11.9,32.7,-1],'hand_r')
box(knife,[-13.1,31.8,-2.6],[1.9,2.0,5.5],'steel')
box(knife,[-13.9,31.43,-3.06],[3.6,2.7,1.2],'lime')
box(knife,[-13.6,31.7,-10.8],[2.9,2.05,8.1],'blade')
box(knife,[-13.39,32,-13.45],[1.96,1.55,3.75],'blade',[0,-16,0])
box(knife,[-12.85,32,-14.46],[1.1,1.2,2.4],'blade',[0,-17,0])
box(knife,[-13.75,32.2,-10.12],[.48,.6,7.04],'eye')
rifle=bone('rifle',[-11.65,34,-1],'hand_r')
box(rifle,[-13.08,32.8,-5.95],[2.86,3.65,8.6],'black')
box(rifle,[-13.55,33.55,-5.35],[3.75,2.7,5.97],'steel')
box(rifle,[-12.8,33.5,-13.2],[2.48,2.4,7.8],'darkviolet')
box(rifle,[-13.22,33.12,-13.66],[3.25,3.2,2.68],'rib')
box(rifle,[-12.7,33.7,-13.83],[2.16,2.04,.24],'gold')
box(rifle,[-12.68,32.0,-4.15],[2.1,2.55,2.1],'green',[21,0,0])
box(rifle,[-12.1,36.6,-4.8],[1.12,1.15,3.1],'lens')

# Keep geometry dimensions and animation in authored units (16 units per block).
write_json(RP/'models/entity/eva_unit_01.geo.json', {'format_version':'1.12.0','minecraft:geometry':[{ 'description':{
    'identifier':GEOMETRY,'texture_width':128,'texture_height':256,'visible_bounds_width':7,'visible_bounds_height':7,'visible_bounds_offset':[0,2.5,0]},'bones':bones}]})
atlas().save(RP/'textures/entity/eva_unit_01.png')
atlas(True).save(RP/'textures/entity/eva_unit_01_berserk.png')

# Standalone item sprite with the faceted white/purple entry capsule and a lime latch.
icon = Image.new('RGBA',(32,32))
draw=ImageDraw.Draw(icon)
draw.polygon([(5,27),(6,20),(20,5),(25,3),(29,6),(27,12),(12,27),(7,29)], fill='#191728')
draw.polygon([(7,25),(8,21),(21,6),(25,5),(27,7),(25,12),(11,26)], fill='#a4b7c8')
draw.polygon([(10,23),(12,19),(23,8),(26,7),(24,12),(12,25)], fill='#56617d')
draw.polygon([(8,22),(13,17),(15,19),(10,25),(7,26)], fill='#8255b1')
draw.polygon([(14,16),(16,14),(19,16),(16,19)], fill='#32394d')
draw.polygon([(15,16),(16,15),(18,16),(16,18)], fill='#bdf153')
draw.line((9,20,21,7,24,6), fill='#f4f9ff')
draw.line((12,26,26,12), fill='#4c2d68')
icon.save(RP/'textures/items/eva_entry_plug.png')


def expression_track(**values):
    return {'eva_'+bone_name:{channel:value} for bone_name,(channel,value) in values.items()}


def channel(name, **tracks):
    return {'eva_'+bone_name:{name:{str(t):{'post':v,'lerp_mode':'catmullrom'} for t,v in values}} for bone_name,values in tracks.items()}


def pose(length, rotations, positions=None):
    tracks=channel('rotation',**rotations)
    for bone_name,data in channel('position',**(positions or {})).items():
        tracks.setdefault(bone_name,{}).update(data)
    return {'loop':'hold_on_last_frame','animation_length':length,'bones':tracks}


def rest(berserk=False):
    pace='query.anim_time * '+('235' if berserk else '128')
    return {'loop':True,'bones':expression_track(
        root=('position',[0,f'math.sin({pace}) * .43',0]),
        spine=('rotation',[f'{9 if berserk else 2} + math.sin({pace}) * 2',0,0]),
        chest=('rotation',[f'math.sin({pace}) * 1.7',0,f'math.sin({pace} * .52) * .9']),
        head=('rotation',[f'{-8 if berserk else -3} + math.sin({pace} + 28) * 2.3',f'math.sin({pace} * .49) * 4',0]),
        jaw=('rotation',[f'{20 if berserk else 1} + math.sin({pace}) * {8 if berserk else 1.4}',0,0]),
        shoulder_r=('rotation',[0,0,9 if berserk else 3]),shoulder_l=('rotation',[0,0,-9 if berserk else -3]),
        forearm_r=('rotation',[f'{-32 if berserk else -12} + math.sin({pace}) * 3',0,7]),
        forearm_l=('rotation',[f'{-34 if berserk else -13} + math.sin({pace}+55) * 3',0,-7]),
        thigh_r=('rotation',[-4,-3,-9]),thigh_l=('rotation',[-4,3,9]),
        shin_r=('rotation',[7,0,6]),shin_l=('rotation',[7,0,-6]),
        foot_r=('rotation',[-3,-8,3]),foot_l=('rotation',[-3,8,-3]),
        pylon_r=('rotation',[f'math.sin({pace}-31) * 2',0,2]),pylon_l=('rotation',[f'math.sin({pace}-31) * 2',0,-2]))}


def walk():
    gait='query.modified_distance_moved * 42'
    speed='math.clamp(query.modified_move_speed * 3.4, .42, 1.08)'
    wave=lambda degrees: f'math.sin({gait}+{degrees})'
    out=expression_track(root=('position',[0,f'-1.2 + math.abs({wave(0)}) * 2.1',0]),
        pelvis=('rotation',[5,f'{wave(0)} * 7',f'{wave(90)} * 2.6']),
        spine=('rotation',[10,0,0]),chest=('rotation',[4,f'{wave(0)} * -15',f'{wave(90)} * -3.5']),
        head=('rotation',[-16,f'{wave(0)} * 3',0]))
    for side,phase in (('r',0),('l',180)):
        out['eva_thigh_'+side]={'rotation':[f'{wave(phase)} * 39 * {speed}',0,0]}
        out['eva_shin_'+side]={'rotation':[f'3 + math.max(0,{wave(phase+60)}) * 58 * {speed}',0,0]}
        out['eva_foot_'+side]={'rotation':[f'-{wave(phase+35)} * 22 * {speed}',0,0]}
        out['eva_upper_arm_'+side]={'rotation':[f'{wave(phase+180)} * 28 * {speed}',0,0]}
        out['eva_forearm_'+side]={'rotation':[f'-22 - math.max(0,{wave(phase+182)}) * 25',0,0]}
        out['eva_pylon_'+side]={'rotation':[f'{wave(phase-25)} * 4',0,0]}
    return {'loop':True,'bones':out}


boot=pose(1.10,{
    'pelvis':[(0,[18,0,0]),(.28,[24,0,-3]),(.64,[-8,0,0]),(1.09,[0,0,0])],
    'spine':[(0,[29,0,0]),(.3,[35,0,1]),(.68,[-7,0,-2]),(1.09,[2,0,0])],
    'head':[(0,[25,0,-5]),(.43,[31,0,-2]),(.78,[-15,0,0]),(1.09,[-3,0,0])],
    'pylon_r':[(0,[26,0,15]),(.27,[33,0,24]),(.76,[-3,0,-4]),(1.08,[0,0,2])],
    'pylon_l':[(0,[26,0,-15]),(.27,[33,0,-24]),(.76,[-3,0,4]),(1.08,[0,0,-2])],
    'thigh_r':[(0,[-27,0,8]),(.31,[-32,0,11]),(.88,[0,0,0])],
    'thigh_l':[(0,[-24,0,-5]),(.31,[-29,0,-10]),(.91,[0,0,0])],
    'shin_r':[(0,[58,0,0]),(.31,[65,0,0]),(.83,[0,0,0])],
    'shin_l':[(0,[55,0,0]),(.31,[62,0,0]),(.87,[0,0,0])],
    'upper_arm_r':[(0,[12,0,12]),(.46,[5,8,23]),(.78,[-18,-12,5]),(1.09,[0,0,0])],
    'upper_arm_l':[(0,[15,0,-10]),(.46,[2,-8,-21]),(.78,[-20,11,-5]),(1.09,[0,0,0])],
    'forearm_r':[(0,[-24,0,7]),(.62,[-48,0,-2]),(1.09,[-10,0,6])],
    'forearm_l':[(0,[-20,0,-7]),(.62,[-41,0,2]),(1.09,[-10,0,-6])]}, {'root':[(0,[0,-14,1]),(.29,[0,-16,1]),(.67,[0,1,0]),(1.09,[0,0,0])]})
knife_pose=pose(1.20,{
    'pelvis':[(0,[0,0,0]),(.14,[8,22,-7]),(.28,[14,-33,6]),(.45,[8,-24,3]),(.58,[11,25,-6]),(.79,[-8,30,3]),(.93,[14,-43,6]),(1.18,[0,0,0])],
    'chest':[(0,[0,0,0]),(.14,[0,38,-10]),(.27,[5,-47,10]),(.45,[0,-36,12]),(.56,[1,40,-13]),(.78,[-13,44,-5]),(.92,[16,-45,15]),(1.18,[0,0,0])],
    'head':[(0,[0,0,0]),(.16,[-5,-33,5]),(.31,[-9,36,-6]),(.56,[-8,-38,4]),(.91,[-14,38,-7]),(1.18,[-2,0,0])],
    'upper_arm_r':[(0,[-10,0,8]),(.14,[-49,-31,51]),(.25,[-63,61,-27]),(.45,[-56,65,-36]),(.56,[-58,-55,43]),(.77,[-138,-9,12]),(.91,[-42,46,-27]),(1.18,[-3,0,5])],
    'forearm_r':[(0,[-10,0,0]),(.14,[-68,-14,-23]),(.25,[-17,30,13]),(.43,[-53,8,14]),(.56,[-14,-26,-3]),(.78,[-54,-14,-11]),(.92,[-11,21,18]),(1.18,[-12,0,3])],
    'hand_r':[(0,[0,0,0]),(.14,[-12,-12,34]),(.28,[14,16,-15]),(.56,[8,-27,22]),(.91,[-19,24,-16]),(1.18,[0,0,0])],
    'upper_arm_l':[(0,[0,0,-3]),(.14,[-42,-19,-27]),(.28,[4,-36,-35]),(.55,[-64,0,-11]),(.92,[13,-18,-41]),(1.18,[0,0,0])],
    'thigh_r':[(0,[0,0,0]),(.23,[-31,0,4]),(.57,[-14,0,6]),(.9,[-28,0,9]),(1.18,[0,0,0])],
    'shin_r':[(0,[0,0,0]),(.23,[29,0,0]),(.57,[18,0,0]),(.9,[39,0,0]),(1.18,[0,0,0])]},
    {'root':[(0,[0,0,0]),(.25,[0,-2,-3]),(.56,[0,-1,-2]),(.9,[0,-3,-4]),(1.18,[0,0,0])]})

# Five shoulder and slide kickbacks at the exact projectile frames, with small recovery beats.
recoil_frames = (5,9,13,17,21)
rifle_root=[(0,[0,0,0]),(.15,[0,-2,0])]
rifle_chest=[(0,[0,0,0]),(.15,[12,6,-3])]
rifle_arm=[(0,[0,0,0]),(.15,[-79,18,9])]
rifle_hand=[(0,[0,0,0]),(.15,[-7,0,0])]
rifle_aim=[(0,[0,0,0]),(.15,[100,-21,1])]
for frame in recoil_frames:
    t=frame/20
    rifle_root.extend([(t,[0,-2,1.35]),(t+.12,[0,-2,0])])
    rifle_chest.extend([(t,[2,9,-3]),(t+.12,[11,6,-3])])
    rifle_arm.extend([(t,[-92,21,9]),(t+.12,[-79,18,9])])
    rifle_hand.extend([(t,[-13,0,0]),(t+.12,[-5,0,0])])
    rifle_aim.extend([(t,[125,-25,2]),(t+.12,[100,-21,1])])
for track in (rifle_root,rifle_chest,rifle_arm,rifle_hand,rifle_aim):
    track.append((1.24,[0,0,0]))
rifle_pose=pose(1.25,{
    'chest':rifle_chest,'upper_arm_r':rifle_arm,'hand_r':rifle_hand,'rifle':rifle_aim,
    'upper_arm_l':[(0,[0,0,0]),(.16,[-96,-42,-2]),(1.1,[-96,-42,-2]),(1.24,[0,0,0])],
    'forearm_l':[(0,[-13,0,0]),(.16,[2,-17,0]),(1.1,[2,-17,0]),(1.24,[-13,0,0])],
    'forearm_r':[(0,[-13,0,0]),(.16,[-29,0,4]),(1.1,[-29,0,4]),(1.24,[-13,0,0])],
    'head':[(0,[-3,0,0]),(.16,[-10,-7,4]),(1.1,[-10,-7,4]),(1.24,[-3,0,0])],
    'thigh_r':[(0,[0,0,0]),(.16,[-17,0,8]),(1.1,[-17,0,8]),(1.24,[0,0,0])],
    'thigh_l':[(0,[0,0,0]),(.16,[16,0,-8]),(1.1,[16,0,-8]),(1.24,[0,0,0])]}, {'root':rifle_root})

field=pose(.7,{
    'chest':[(0,[0,0,0]),(.17,[7,0,0]),(.3,[-12,0,0]),(.67,[0,0,0])],
    'upper_arm_r':[(0,[0,0,0]),(.16,[-64,-26,26]),(.32,[-97,-3,22]),(.55,[-79,-8,19]),(.69,[0,0,0])],
    'upper_arm_l':[(0,[0,0,0]),(.16,[-64,26,-26]),(.32,[-97,3,-22]),(.55,[-79,8,-19]),(.69,[0,0,0])],
    'forearm_r':[(0,[-10,0,0]),(.16,[-61,22,-21]),(.32,[-12,8,4]),(.69,[-10,0,0])],
    'forearm_l':[(0,[-10,0,0]),(.16,[-61,-22,21]),(.32,[-12,-8,-4]),(.69,[-10,0,0])],
    'pylon_r':[(0,[0,0,0]),(.3,[-10,-6,12]),(.69,[0,0,0])],
    'pylon_l':[(0,[0,0,0]),(.3,[-10,6,-12]),(.69,[0,0,0])]})
ramiel=pose(1.5,{
    'spine':[(0,[0,0,0]),(.4,[19,0,0]),(.87,[12,0,0]),(1.02,[-22,0,2]),(1.12,[-14,0,0]),(1.49,[0,0,0])],
    'head':[(0,[0,0,0]),(.28,[17,0,0]),(.81,[25,0,-2]),(1.04,[-19,0,1]),(1.49,[-3,0,0])],
    'upper_arm_r':[(0,[0,0,0]),(.24,[-40,-25,41]),(.8,[-61,-16,38]),(1.05,[-104,-7,29]),(1.47,[0,0,0])],
    'upper_arm_l':[(0,[0,0,0]),(.24,[-40,25,-41]),(.8,[-61,16,-38]),(1.05,[-104,7,-29]),(1.47,[0,0,0])],
    'forearm_r':[(0,[-10,0,0]),(.26,[-66,17,-16]),(.84,[-83,15,-22]),(1.03,[-20,7,-8]),(1.46,[-12,0,0])],
    'forearm_l':[(0,[-10,0,0]),(.26,[-66,-17,16]),(.84,[-83,-15,22]),(1.03,[-20,-7,8]),(1.46,[-12,0,0])],
    'pylon_r':[(0,[0,0,0]),(.79,[14,-6,23]),(1.02,[-26,-13,30]),(1.46,[0,0,0])],
    'pylon_l':[(0,[0,0,0]),(.79,[14,6,-23]),(1.02,[-26,13,-30]),(1.46,[0,0,0])]},
    {'root':[(0,[0,0,0]),(.4,[0,-3,0]),(.91,[0,-4,0]),(1.03,[0,-1,3]),(1.49,[0,0,0])]})
zeruel=pose(1.25,{
    'chest':[(0,[0,0,0]),(.21,[5,32,-12]),(.4,[10,-43,10]),(.62,[4,-34,13]),(.75,[8,42,-12]),(1.24,[0,0,0])],
    'head':[(0,[0,0,0]),(.22,[-8,-31,11]),(.41,[-11,39,-8]),(.76,[-9,-38,7]),(1.24,[0,0,0])],
    'upper_arm_r':[(0,[0,0,0]),(.25,[-39,-42,66]),(.41,[-76,51,-18]),(.64,[-64,48,-21]),(.8,[4,0,39]),(1.24,[0,0,0])],
    'upper_arm_l':[(0,[0,0,0]),(.25,[-19,-11,-22]),(.63,[-53,45,-63]),(.75,[-82,-56,23]),(.94,[-63,-43,17]),(1.24,[0,0,0])],
    'forearm_r':[(0,[-10,0,0]),(.28,[-41,0,-14]),(.41,[-5,0,15]),(1.24,[-10,0,0])],
    'forearm_l':[(0,[-10,0,0]),(.64,[-44,0,13]),(.76,[-6,0,-19]),(1.24,[-10,0,0])]},
    {'root':[(0,[0,0,0]),(.39,[0,-1,-3]),(.75,[0,-2,-4]),(1.24,[0,0,0])]})
sachiel=pose(1.35,{
    'spine':[(0,[0,0,0]),(.39,[-18,0,0]),(.58,[-26,0,0]),(.76,[38,0,0]),(.97,[28,0,0]),(1.34,[2,0,0])],
    'head':[(0,[0,0,0]),(.42,[-19,0,0]),(.75,[-13,0,0]),(.93,[-21,0,0]),(1.34,[-3,0,0])],
    'upper_arm_r':[(0,[0,0,0]),(.37,[-137,7,28]),(.57,[-157,4,20]),(.75,[-39,15,10]),(.98,[-31,12,6]),(1.34,[0,0,0])],
    'upper_arm_l':[(0,[0,0,0]),(.37,[-137,-7,-28]),(.57,[-157,-4,-20]),(.75,[-39,-15,-10]),(.98,[-31,-12,-6]),(1.34,[0,0,0])],
    'forearm_r':[(0,[-10,0,0]),(.5,[-63,5,8]),(.76,[-13,1,8]),(1.34,[-10,0,0])],
    'forearm_l':[(0,[-10,0,0]),(.5,[-63,-5,-8]),(.76,[-13,-1,-8]),(1.34,[-10,0,0])],
    'thigh_r':[(0,[0,0,0]),(.5,[-15,0,7]),(.75,[-43,0,11]),(1.34,[0,0,0])],
    'thigh_l':[(0,[0,0,0]),(.5,[-15,0,-7]),(.75,[-43,0,-11]),(1.34,[0,0,0])],
    'shin_r':[(0,[0,0,0]),(.75,[60,0,0]),(1.34,[0,0,0])],
    'shin_l':[(0,[0,0,0]),(.75,[60,0,0]),(1.34,[0,0,0])]},
    {'root':[(0,[0,0,0]),(.46,[0,3,1]),(.6,[0,5,0]),(.75,[0,-11,-4]),(.95,[0,-9,-3]),(1.34,[0,0,0])]})
berserk=pose(1.5,{
    'pelvis':[(0,[0,0,0]),(.34,[21,-6,5]),(.7,[28,3,-6]),(.91,[-12,0,0]),(1.49,[0,0,0])],
    'spine':[(0,[0,0,0]),(.36,[30,8,-9]),(.66,[38,-8,8]),(.92,[-25,0,0]),(1.49,[9,0,0])],
    'head':[(0,[0,0,0]),(.43,[19,12,5]),(.71,[29,-13,-6]),(.93,[-39,0,3]),(1.49,[-8,0,0])],
    'jaw':[(0,[0,0,0]),(.58,[6,0,0]),(.9,[44,0,0]),(1.25,[36,0,0]),(1.49,[24,0,0])],
    'upper_arm_r':[(0,[0,0,0]),(.4,[-42,-6,-23]),(.67,[-31,-9,-28]),(.95,[-30,-37,68]),(1.49,[0,0,8])],
    'upper_arm_l':[(0,[0,0,0]),(.4,[-42,6,23]),(.67,[-31,9,28]),(.95,[-30,37,-68]),(1.49,[0,0,-8])],
    'forearm_r':[(0,[-10,0,0]),(.42,[-76,0,-18]),(.96,[-14,-8,5]),(1.49,[-32,0,7])],
    'forearm_l':[(0,[-10,0,0]),(.42,[-76,0,18]),(.96,[-14,8,-5]),(1.49,[-34,0,-7])],
    'pylon_r':[(0,[0,0,0]),(.62,[38,0,12]),(.96,[-26,-14,22]),(1.49,[4,0,6])],
    'pylon_l':[(0,[0,0,0]),(.62,[38,0,-12]),(.96,[-26,14,-22]),(1.49,[4,0,-6])],
    'thigh_r':[(0,[0,0,0]),(.57,[-39,0,9]),(.94,[-10,0,9]),(1.49,[-6,0,5])],
    'thigh_l':[(0,[0,0,0]),(.57,[-34,0,-8]),(.94,[-10,0,-9]),(1.49,[-6,0,-5])],
    'shin_r':[(0,[0,0,0]),(.56,[60,0,0]),(.95,[25,0,0]),(1.49,[9,0,0])],
    'shin_l':[(0,[0,0,0]),(.56,[55,0,0]),(.95,[25,0,0]),(1.49,[9,0,0])]},
    {'root':[(0,[0,0,0]),(.51,[0,-10,0]),(.69,[0,-12,-2]),(.94,[0,2,2]),(1.49,[0,-1,0])]})
air=pose(.32,{
    'thigh_r':[(0,[-17,0,5]),(.25,[-37,0,6])],'thigh_l':[(0,[-13,0,-5]),(.25,[17,0,-8])],
    'shin_r':[(0,[20,0,0]),(.25,[38,0,0])],'shin_l':[(0,[25,0,0]),(.25,[48,0,0])],
    'spine':[(0,[2,0,0]),(.25,[13,0,-3])],
    'upper_arm_r':[(0,[-8,0,3]),(.25,[-28,0,21])],'upper_arm_l':[(0,[10,0,-3]),(.25,[14,0,-27])]})
land=pose(.26,{
    'spine':[(0,[14,0,0]),(.065,[21,0,0]),(.25,[2,0,0])],
    'thigh_r':[(0,[-20,0,3]),(.065,[-28,0,4]),(.25,[0,0,0])],
    'thigh_l':[(0,[-20,0,-3]),(.065,[-28,0,-4]),(.25,[0,0,0])],
    'shin_r':[(0,[29,0,0]),(.065,[45,0,0]),(.25,[0,0,0])],
    'shin_l':[(0,[29,0,0]),(.065,[45,0,0]),(.25,[0,0,0])]},
    {'root':[(0,[0,-2,0]),(.065,[0,-5,0]),(.25,[0,0,0])]})
shutdown=pose(.7,{
    'chest':[(0,[0,0,0]),(.30,[12,0,0]),(.68,[28,0,0])],
    'head':[(0,[-3,0,0]),(.30,[13,0,0]),(.68,[30,0,0])],
    'pylon_r':[(0,[0,0,0]),(.34,[20,0,10]),(.68,[33,0,23])],
    'pylon_l':[(0,[0,0,0]),(.34,[20,0,-10]),(.68,[33,0,-23])],
    'thigh_r':[(0,[0,0,0]),(.31,[-20,0,3]),(.68,[-33,0,5])],
    'thigh_l':[(0,[0,0,0]),(.31,[-21,0,-3]),(.68,[-34,0,-5])],
    'shin_r':[(0,[0,0,0]),(.31,[32,0,0]),(.68,[66,0,0])],
    'shin_l':[(0,[0,0,0]),(.31,[32,0,0]),(.68,[66,0,0])],
    'forearm_r':[(0,[-12,0,0]),(.3,[-26,-7,9]),(.68,[-40,0,14])],
    'forearm_l':[(0,[-12,0,0]),(.3,[-26,7,-9]),(.68,[-40,0,-14])]},
    {'root':[(0,[0,0,0]),(.32,[0,-4,1]),(.68,[0,-11,1])]})
animations={'idle':rest(),'fury':rest(True),'run':walk(),'air':air,'land':land,
            'boot':boot,'knife':knife_pose,'rifle':rifle_pose,'ward':field,'ramiel':ramiel,
            'zeruel':zeruel,'sachiel':sachiel,'berserk':berserk,'shutdown':shutdown}
write_json(RP/'animations/eva_unit_01.animation.json',{'format_version':'1.8.0','animations':{ANIMATION+k:v for k,v in animations.items()}})
actions={2:'boot',3:'knife',4:'rifle',5:'ward',6:'ramiel',7:'zeruel',8:'sachiel',9:'berserk',10:'shutdown'}
active_transitions=[{name:f'{ACTIVE} == {value}'} for value,name in actions.items()]
states={'off':{'transitions':[*active_transitions,{'idle':f'{ACTIVE} == 1'}]}}
state_conditions={
  'idle':[{'run':'query.modified_move_speed > 0.035'},{'fury':BERSERK}],
  'run':[{'fury':f'query.modified_move_speed <= 0.025 && {BERSERK}'},{'idle':'query.modified_move_speed <= 0.025'}],
  'fury':[{'run':'query.modified_move_speed > 0.035'},{'idle':f'!{BERSERK}'}],
}
for name in ('idle','run','fury'):
    states[name]={'animations':['eva_'+name],'blend_transition':.12,
                  'transitions':[*active_transitions,{'off':f'{ACTIVE} == 0'},{'air':'!query.is_on_ground'},*state_conditions[name]]}
states['air']={'animations':['eva_air'],'blend_transition':.10,
               'transitions':[*active_transitions,{'off':f'{ACTIVE} == 0'},{'land':'query.is_on_ground'}]}
states['land']={'animations':['eva_land'],'blend_transition':.1,
                'transitions':[*active_transitions,{'off':f'{ACTIVE} == 0'},{'air':'!query.is_on_ground'},
                               {'run':'query.any_animation_finished && query.modified_move_speed > 0.035'},
                               {'fury':f'query.any_animation_finished && {BERSERK}'},{'idle':'query.any_animation_finished'}]}
for name in actions.values():
    states[name]={'animations':['eva_'+name],'blend_transition':.08 if name!='boot' else .13,
                  'transitions':[*[t for t in active_transitions if name not in t],{'off':f'{ACTIVE} == 0'},{'idle':f'{ACTIVE} == 1'}]}
write_json(RP/'animation_controllers/eva_unit_01.animation_controllers.json',{'format_version':'1.10.0','animation_controllers':{CONTROLLER:{'initial_state':'off','states':states}}})
write_json(RP/'render_controllers/eva_unit_01.render_controllers.json',{'format_version':'1.8.0','render_controllers':{RENDER:{
    'arrays':{'textures':{'Array.eva_paint':['Texture.eva_normal','Texture.eva_berserk']}},
    'geometry':'Geometry.eva_unit','materials':[{'*':'Material.eva_body'}],
    'textures':[f'Array.eva_paint[{BERSERK} ? 1 : 0]'],
    'part_visibility':[{'eva_knife':f'{ACTIVE} == 3'},{'eva_rifle':f'{ACTIVE} == 4'}],
}}})

# Alpha-masked particles use per-cast color and scale supplied by the game script.
fx=Image.new('RGBA',(48,16))
for tile in range(3):
    for y in range(16):
        for x in range(16):
            dx,dy = x-7.5,y-7.5
            radius=math.hypot(dx,dy)
            if tile==0:
                alpha=max(0, 1-radius/8)**1.25
            elif tile==1:
                alpha=max(0,1-min(abs(dx)+abs(dy)*.32,abs(dy)+abs(dx)*.32)/3.3)*max(0,1-radius/8)**.6
            else:
                alpha=max(0,1-abs(radius-4.65)/2.05)*.88 + max(0,1-radius/3.25)*.4
            fx.putpixel((tile*16+x,y),(255,255,255,round(min(1,alpha)*255)))
fx.save(RP/'textures/particles/eva_effects.png')
for tile,kind in enumerate(('energy','spark','arc')):
    durations=(.26,.18,.29)
    lifetime=durations[tile]
    effect={'description':{'identifier':'rpg:eva_'+kind,'basic_render_parameters':{'material':'particles_add','texture':'textures/particles/eva_effects'}},
            'components':{
                'minecraft:emitter_rate_instant':{'num_particles':1},
                'minecraft:emitter_lifetime_once':{'active_time':.05},
                'minecraft:emitter_shape_point':{},
                'minecraft:particle_lifetime_expression':{'max_lifetime':lifetime},
                'minecraft:particle_initial_speed':0,
                'minecraft:particle_appearance_billboard':{
                    'size':['variable.effect_size * (0.86 + variable.particle_age / variable.particle_lifetime * 0.37)']*2,
                    'facing_camera_mode':'lookat_xyz','uv':{'texture_width':48,'texture_height':16,'uv':[tile*16,0],'uv_size':[16,16]}},
                'minecraft:particle_appearance_tinting':{'color':['variable.tint.r','variable.tint.g','variable.tint.b','(1 - variable.particle_age / variable.particle_lifetime) * variable.tint.a']},
            }}
    write_json(RP/f'particles/eva_{kind}.particle.json',{'format_version':'1.10.0','particle_effect':effect})

# Reused player controllers keep vanilla first-person input, the skin preview and map faces.
path=RP/'entity/player.entity.json'
player=json.loads(path.read_text())
client=player['minecraft:client_entity']['description']
client['materials']['eva_body']='entity_alphatest'
client['textures'].update(eva_normal='textures/entity/eva_unit_01',eva_berserk='textures/entity/eva_unit_01_berserk')
client['geometry']['eva_unit']=GEOMETRY
client['animations'].update({'eva_motion':CONTROLLER,**{'eva_'+k:ANIMATION+k for k in animations}})
if 'eva_motion' not in client['scripts']['animate']:
    client['scripts']['animate'].append('eva_motion')
normal=next(c for c in client['render_controllers'] if 'controller.render.player.third_person' in c)
normal['controller.render.player.third_person']=f'!variable.is_first_person && !variable.map_face_icon && !query.is_spectator && (variable.is_paperdoll || {ACTIVE} == 0)'
if not any(RENDER in c for c in client['render_controllers']):
    client['render_controllers'].append({RENDER:f'!variable.is_first_person && !variable.is_paperdoll && !variable.map_face_icon && !query.is_spectator && {ACTIVE} > 0'})
write_json(path,player)
