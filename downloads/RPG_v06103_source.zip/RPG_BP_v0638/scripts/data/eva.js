export const EVA_JOB = 'shinji';
export const EVA_WEAPON = 'rpg:eva_entry_plug';
export const EVA_ACTION = 'rpg:eva_action';
export const EVA_BERSERK = 'rpg:eva_berserk';

export const EVA_SKILLS = {
  eva_sync: {id:'eva_sync',name:'초호기 기동',line:'eva',mana:0,cooldown:0,action:2,windup:22},
  eva_knife: {id:'eva_knife',name:'프로그레시브 나이프',line:'eva',mana:70,cooldown:100,action:3,windup:24,damage:26,range:6,damageType:'physical'},
  eva_rifle: {id:'eva_rifle',name:'팔레트 라이플',line:'eva',mana:100,cooldown:150,action:4,windup:25,damage:12,range:32,damageType:'physical'},
  eva_field: {id:'eva_field',name:'A.T. 필드',line:'eva',mana:120,cooldown:400,action:5,windup:14,duration:100},
  eva_ramiel: {id:'eva_ramiel',name:'라미엘 · 가속 입자포',line:'eva',mana:190,cooldown:480,action:6,windup:30,damage:155,range:36,damageType:'magic'},
  eva_zeruel: {id:'eva_zeruel',name:'제르엘 · 절단 띠',line:'eva',mana:135,cooldown:260,action:7,windup:25,damage:55,range:14,damageType:'magic'},
  eva_sachiel: {id:'eva_sachiel',name:'사키엘 · 십자충격',line:'eva',mana:130,cooldown:320,action:8,windup:27,damage:95,radius:8,damageType:'magic'},
  eva_berserk: {id:'eva_berserk',name:'초호기 폭주 (궁극기)',line:'eva',mana:410,cooldown:1500,action:9,windup:30,duration:240,damage:160,radius:10,damageType:'physical',ultimate:true},
};

export const EVA_NOTES = {
  eva_sync:'엔트리 플러그로 약 1초간 초호기를 기동합니다. 장갑과 조종석이 잠긴 뒤 전투 기술을 사용할 수 있습니다. 같은 기술을 다시 쓰면 탑승을 해제합니다.',
  eva_knife:'시선 방향 6칸 부채꼴을 세 번 벱니다. 기본 물리 피해는 26씩입니다. 공격마다 현재 위치와 방향이 반영됩니다.',
  eva_rifle:'직선 32칸 사거리로 기본 물리 피해 12의 탄을 5발 연사합니다. 각 탄은 벽이나 처음 맞힌 적에서 멈춥니다.',
  eva_field:'5초간 저항 II를 얻습니다. 전방에 육각 장벽이 형성되어 현재 바라보는 방향을 따라갑니다.',
  eva_ramiel:'약 1초간 충전 후 36칸까지 푸른 입자포를 발사합니다. 벽에 도달할 때까지 광선에 닿은 적마다 기본 마법 피해 155를 입힙니다.',
  eva_zeruel:'전방 14칸에 좌우 절단 띠를 차례로 펼칩니다. 각 띠의 기본 마법 피해는 55이며 중심부의 적은 두 번 맞을 수 있습니다.',
  eva_sachiel:'두 주먹으로 지면을 내려쳐 반경 8칸에 십자 파동을 일으킵니다. 기본 마법 피해 95와 밀치기를 주며 지형은 보존됩니다.',
  eva_berserk:'반경 10칸에 기본 물리 피해 160과 밀치기를 주고 12초간 폭주합니다. 폭주 중 다른 초호기 공격 스킬의 피해가 25% 증가합니다.',
};
