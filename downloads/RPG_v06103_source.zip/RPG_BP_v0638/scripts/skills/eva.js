import {MolangVariableMap,system,world} from '@minecraft/server';
import {EVA_ACTION,EVA_BERSERK,EVA_JOB} from '../data/eva.js';
import {getJobId} from '../core/playerData.js';
import {isJailed} from '../core/prison.js';
import {isTimeFrozen} from '../core/timeStopDamage.js';
import {notify} from '../core/hud.js';
import {clearBlockPath,dist3,flatDir,getTargets,headPos,healthAlive,hurt,knockback,norm3,particle,sound} from '../core/util.js';

const pilots=new Map();
const SHUTDOWN_TICKS=14;
const GREEN=[.65,1,.19], VIOLET=[.76,.36,1], BLUE=[.24,.85,1], IVORY=[.88,1,.92], GOLD=[1,.61,.2], RED=[1,.19,.32];
const offset=(p,v,n)=>({x:p.x+v.x*n,y:p.y+v.y*n,z:p.z+v.z*n});
const vector=(from,to)=>({x:to.x-from.x,y:to.y-from.y,z:to.z-from.z});
const dot=(a,b)=>a.x*b.x+a.y*b.y+a.z*b.z;
const torso=e=>({...e.location,y:e.location.y+.85});
const center=(p,height)=>({...p.location,y:p.location.y+height});

function effect(p,pos,color,size,kind='energy'){
 const variables=new MolangVariableMap();
 variables.setColorRGBA('variable.tint',{red:color[0],green:color[1],blue:color[2],alpha:1});
 variables.setFloat('variable.effect_size',size);
 particle(p.dimension,'rpg:eva_'+kind,pos,variables);
}
function stroke(p,from,to,color,size,step=1,kind='energy'){
 const d=vector(from,to),count=Math.max(1,Math.ceil(dist3(from,to)/step));
 for(let i=0;i<=count;i++)effect(p,offset(from,d,i/count),color,size,kind);
}
function ripple(p,origin,radius,color,points=24){
 for(let i=0;i<points;i++){
  const angle=i*Math.PI*2/points;
  effect(p,{x:origin.x+Math.cos(angle)*radius,y:origin.y,z:origin.z+Math.sin(angle)*radius},color,.44,'arc');
 }
}
function rotate(v,angle){
 return {x:v.x*Math.cos(angle)-v.z*Math.sin(angle),y:0,z:v.z*Math.cos(angle)+v.x*Math.sin(angle)};
}
function front(p,range,direction,halfAngle){
 const origin=headPos(p),minDot=Math.cos(halfAngle*Math.PI/180);
 return getTargets(p,p.location,range+1).filter(e=>{
  const delta=vector(p.location,e.location),horizontal=Math.hypot(delta.x,delta.z);
  return dist3(p.location,e.location)<=range&&(!horizontal||(direction.x*delta.x+direction.z*delta.z)/horizontal>=minDot)&&
   clearBlockPath(p.dimension,origin,torso(e));
 });
}
function waveHit(p,state,def,target){
 const power=system.currentTick<state.berserkUntil&&def.id!=='eva_berserk'?1.25:1;
 return hurt(target,p,def.damage*power,def.damageType,{ignoreInvulnerability:true});
}
function lineHit(p,def,width){
 const from=headPos(p),dir=norm3(p.getViewDirection());
 let distance=0;
 for(let step=.4;step<=def.range+.01;step+=.4){
  if(!clearBlockPath(p.dimension,offset(from,dir,distance),offset(from,dir,step)))break;
  distance=step;
 }
 const hits=[];
 for(const target of getTargets(p,p.location,distance+2)){
  const point=torso(target),delta=vector(from,point),depth=dot(delta,dir);
  if(depth<0||depth>distance||dist3(point,offset(from,dir,depth))>width||!clearBlockPath(p.dimension,from,point))continue;
  hits.push({target,depth});
 }
 hits.sort((a,b)=>a.depth-b.depth);
 return {from,dir,distance,hits};
}
function knife(p,state,def,side){
 const facing=flatDir(p),at=center(p,1.45),steps=12;
 for(let i=0;i<=steps;i++){
  const a=(i/steps-.5)*Math.PI*.93*side;
  const pt=offset(at,rotate(facing,a),2.25+Math.sin(i*Math.PI/steps)*1.7);
  pt.y+=(i/steps-.5)*.9*side;
  if(clearBlockPath(p.dimension,at,pt))effect(p,pt,i%3===0?IVORY:GREEN,.38,'arc');
 }
 for(const e of front(p,def.range,facing,52))waveHit(p,state,def,e);
 sound(p.dimension,'mob.player.attack.strong',p.location,{volume:.85,pitch:1.05+side*.16});
}
function rifle(p,state,def){
 const {from,dir,distance,hits}=lineHit(p,def,.95),hit=hits[0];
 const end=offset(from,dir,hit?.depth??distance);
 effect(p,offset(from,dir,.65),IVORY,.65,'spark');
 stroke(p,offset(from,dir,Math.min(.55,distance)),end,GOLD,.17,1.15,'spark');
 effect(p,end,GOLD,.4,'arc');
 if(hit)waveHit(p,state,def,hit.target);
 sound(p.dimension,'random.explode',p.location,{volume:.35,pitch:1.7});
}
function ward(p){
 const dir=flatDir(p),right={x:dir.z,y:0,z:-dir.x},origin=offset(center(p,1.65),{...dir,y:0},1.75);
 for(const radius of [1.16,1.72]){
  const corners=Array.from({length:6},(_,i)=>{
   const angle=(i+.5)*Math.PI/3;
   const at=offset(origin,right,Math.cos(angle)*radius);
   at.y+=Math.sin(angle)*radius;
   return at;
  });
  for(let i=0;i<6;i++)stroke(p,corners[i],corners[(i+1)%6],radius>1.5?GOLD:VIOLET,.29,.46,'arc');
 }
}
function chargeRamiel(p,t){
 const origin=offset(headPos(p),p.getViewDirection(),1.18),r=.26+t*.035;
 for(let i=0;i<4;i++){
  const angle=i*Math.PI/2+t*.15;
  effect(p,{x:origin.x+Math.cos(angle)*r,y:origin.y+(i%2===0?r:-r)*.5,z:origin.z+Math.sin(angle)*r},BLUE,.23,'arc');
 }
 effect(p,origin,IVORY,.38+t*.017);
}
function ramiel(p,state,def){
 const {from,dir,distance,hits}=lineHit(p,def,1.45),end=offset(from,dir,distance);
 stroke(p,from,end,BLUE,.6,.66);
 stroke(p,offset(from,dir,Math.min(.45,distance)),end,IVORY,.26,.8,'spark');
 for(const {target} of hits)waveHit(p,state,def,target);
 effect(p,end,BLUE,1.3,'arc');
 sound(p.dimension,'random.explode',p.location,{volume:.85,pitch:1.3});
}
function zeruel(p,state,def,side){
 const facing=flatDir(p),dir=rotate(facing,.28*side),origin=center(p,1.42);
 for(let i=0;i<=20;i++){
  const angle=side*.52-(i/20)*side*1.04;
  const distance=2.1+(def.range-2.1)*Math.sin(i*Math.PI/20);
  const point=offset(origin,{...rotate(dir,angle),y:0},distance);
  point.y+=Math.sin(i/20*Math.PI*2)*.75;
  if(clearBlockPath(p.dimension,origin,point)){
   effect(p,point,IVORY,.43,'arc');
   if(i%2===0)effect(p,{...point,y:point.y-.2},VIOLET,.38,'spark');
  }
 }
 for(const e of front(p,def.range,dir,32))waveHit(p,state,def,e);
 sound(p.dimension,'mob.player.attack.strong',p.location,{volume:.85,pitch:.7});
}
function impact(p,state,def,berserk){
 const at=center(p,.36),origin=headPos(p),radius=def.radius;
 ripple(p,at,radius*.72,berserk?RED:VIOLET);
 ripple(p,{...at,y:at.y+.27},radius*.43,berserk?GOLD:IVORY,16);
 if(!berserk){
  const facing={...flatDir(p),y:0},right=rotate(facing,Math.PI/2);
  for(const direction of [facing,right])stroke(p,offset(at,direction,-radius),offset(at,direction,radius),VIOLET,.5,.75,'arc');
 }
 for(const e of getTargets(p,p.location,radius)){
  if(dist3(p.location,e.location)>radius||!clearBlockPath(p.dimension,origin,torso(e)))continue;
  if(waveHit(p,state,def,e))knockback(e,e.location.x-at.x,e.location.z-at.z,berserk?1.9:1.35,.32);
 }
 sound(p.dimension,'random.explode',p.location,{volume:1,pitch:berserk?.58:.8});
}

function stop(id){
 const state=pilots.get(id);
 if(!state)return;
 pilots.delete(id);
 resetVisual(state.player);
}
function resetVisual(p){
 try{p.setProperty(EVA_ACTION,0);p.setProperty(EVA_BERSERK,false);}catch{}
}
function sync(p,_job,def){
 if(getJobId(p)!==EVA_JOB||isJailed(p))return false;
 const now=system.currentTick,state=pilots.get(p.id);
 if(state){
  if(state.shutdownAt)return false;
  p.setProperty(EVA_ACTION,10);
  p.setProperty(EVA_BERSERK,false);
  state.action=undefined;state.guardUntil=0;state.berserkUntil=0;
  state.actionUntil=state.shutdownAt=now+SHUTDOWN_TICKS;
  sound(p.dimension,'random.click',p.location,{volume:.8,pitch:.65});
  return true;
 }
 try{p.setProperty(EVA_ACTION,def.action);}catch{notify(p,'§c행동 팩의 초호기 모델 데이터를 확인하세요.');return false;}
 pilots.set(p.id,{player:p,dim:p.dimension.id,readyAt:now+def.windup,actionUntil:now+def.windup,action:undefined,guardUntil:0,berserkUntil:0});
 sound(p.dimension,'beacon.activate',p.location,{volume:.9,pitch:.68});
 return true;
}
function start(p,_job,def){
 const state=pilots.get(p.id),now=system.currentTick;
 if(getJobId(p)!==EVA_JOB||!state||state.dim!==p.dimension.id){notify(p,'§7먼저 초호기 기동을 사용하세요.');return false;}
 if(now<state.actionUntil){notify(p,'§7초호기 동작이 끝나면 사용할 수 있습니다.');return false;}
 p.setProperty(EVA_ACTION,def.action);
 state.action={def,start:now};
 state.actionUntil=now+def.windup;
 return true;
}
const frames={
 eva_knife:{5:(p,s,d)=>knife(p,s,d,1),11:(p,s,d)=>knife(p,s,d,-1),18:(p,s,d)=>knife(p,s,d,1)},
 eva_rifle:Object.fromEntries([5,9,13,17,21].map(tick=>[tick,rifle])),
 eva_field:{4:(p,s,d)=>{
  s.guardUntil=system.currentTick+d.duration;
  const existing=p.getEffect('resistance');
  if(!existing||existing.amplifier<1||existing.amplifier===1&&existing.duration<d.duration)
   p.addEffect('resistance',d.duration,{amplifier:1,showParticles:false});
  ward(p);sound(p.dimension,'beacon.power',p.location,{volume:.8,pitch:1.6});
 }},
 eva_ramiel:{20:ramiel},
 eva_zeruel:{8:(p,s,d)=>zeruel(p,s,d,1),15:(p,s,d)=>zeruel(p,s,d,-1)},
 eva_sachiel:{15:(p,s,d)=>impact(p,s,d,false)},
 eva_berserk:{18:(p,s,d)=>{
  s.berserkUntil=system.currentTick+d.duration;p.setProperty(EVA_BERSERK,true);impact(p,s,d,true);
 }},
};

export const RUNNERS={eva_sync:sync,...Object.fromEntries(Object.keys(frames).map(id=>[id,start]))};
export function evaStatus(p){
 const state=pilots.get(p.id),now=system.currentTick;
 if(!state)return '§7대기';
 if(state.shutdownAt)return '§7탑승 해제 중';
 if(now<state.readyAt)return '§e기동 중';
 return now<state.berserkUntil?'§c폭주 '+Math.ceil((state.berserkUntil-now)/20)+'초':'§a동기화';
}
export function tickEva(){
 const now=system.currentTick;
 for(const [id,state] of pilots){
  const {player:p}=state;
  try{
   if(p.isValid===false||!healthAlive(p)||getJobId(p)!==EVA_JOB||state.dim!==p.dimension.id||isJailed(p)||String(p.getGameMode()).toLowerCase()==='spectator'){stop(id);continue;}
   if(state.shutdownAt){
    if(now>=state.shutdownAt)stop(id);
    else if(now===state.shutdownAt-5)ripple(p,center(p,.25),1.7,VIOLET,18);
    continue;
   }
   if(state.berserkUntil&&now>=state.berserkUntil){state.berserkUntil=0;p.setProperty(EVA_BERSERK,false);}
   if(now<state.readyAt&&now%5===0)ripple(p,center(p,.2),1.05+(state.readyAt-now)*.075,GREEN,14);
   if(state.actionUntil&&now>=state.actionUntil){p.setProperty(EVA_ACTION,1);state.action=undefined;state.actionUntil=0;}
   if(isTimeFrozen(p)){
    if(state.action){p.setProperty(EVA_ACTION,1);state.action=undefined;state.actionUntil=0;}
    continue;
   }
   if(now<state.guardUntil&&now%6===0)ward(p);
   if(now<state.berserkUntil&&now%8===0){effect(p,center(p,.6),RED,.65,'arc');effect(p,center(p,2.8),VIOLET,.48,'spark');}
   if(!state.action)continue;
   const {def,start:began}=state.action,t=now-began;
   if(def.id==='eva_ramiel'&&t>0&&t<20&&t%3===0)chargeRamiel(p,t);
   frames[def.id][t]?.(p,state,def);
  }catch(error){console.warn('[RPG Eva] '+String(error));stop(id);}
 }
}
export function registerEva(){
 world.afterEvents.playerLeave.subscribe(({playerId})=>stop(playerId));
 world.afterEvents.playerSpawn.subscribe(({player})=>{stop(player.id);resetVisual(player);});
 system.run(()=>{for(const p of world.getAllPlayers())if(!pilots.has(p.id))resetVisual(p);});
 system.runInterval(tickEva,1);
}
