# RPG v0.6.103 · 신지와 에반게리온 초호기

- `/rpg:job 신지` 또는 전직 안내에서 신지를 선택하고 확인하면 단축바 1번 칸에 **초호기 엔트리 플러그**를 받습니다. 이미 전직한 직업은 30분 뒤 기존 직업 복귀 기능으로 돌아갈 수 있습니다.
- 엔트리 플러그를 들고 **초호기 기동**을 우클릭하면 약 1초 뒤 동기화됩니다. 기동을 한 번 더 쓰면 탑승이 해제됩니다. 웅크리면 스킬을 넘기고 우클릭으로 사용합니다. 3인칭에서 조종 캐릭터가 약 5블록 높이의 초호기 외형으로 바뀌며 기본 이동과 피격 판정은 플레이어와 같습니다.
- **프로그레시브 나이프**는 전방 6칸 3연격입니다. **팔레트 라이플**은 현재 시선 방향 32칸에 5발을 쏘며 한 발마다 첫 적 또는 벽에서 멈춥니다. **A.T. 필드**는 전방에 육각 장벽을 표시하고 5초간 저항 II를 줍니다.
- **라미엘 · 가속 입자포**는 1초간 충전하고 36칸 관통 광선을 쏩니다. **제르엘 · 절단 띠**는 좌우에서 두 번 휘감고, **사키엘 · 십자충격**은 반경 8칸에 지면 충격파를 일으킵니다.
- **초호기 폭주**는 반경 10칸을 밀쳐내고 12초 동안 다른 초호기 공격 기술의 피해를 25% 높입니다. 폭주 중 눈과 장갑 빛깔이 바뀌고 턱이 열립니다. 초호기의 기술은 신지 전용입니다.
- 보라색 다층 장갑, 초록색 패널, 어깨의 긴 장갑과 뿔을 새로 모델링했습니다. 기동, 탑승 해제, 달리기, 점프, 착지, 각 기술에 별도 관절 모션을 추가했습니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.103으로 활성화하세요. 자동 검사에서 전직·핫바 스킬 입력, 이동 중 공격, 벽과 아군 판정, 폭주·탑승 해제, 모델과 애니메이션 참조를 확인했습니다. Blender에서 모델을 확인했으며 실제 Bedrock의 렌더링과 멀티플레이는 미검증입니다.

## 개발·검증·패키징

기본 검사와 패키징은 Node.js 24·Python 3.12를 사용합니다. 초호기 모델과 텍스처를 다시 생성할 때만 Pillow와 `python3 tools/build_eva_unit.py`가 필요합니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
python3 tools/build_protected_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v06103
```
