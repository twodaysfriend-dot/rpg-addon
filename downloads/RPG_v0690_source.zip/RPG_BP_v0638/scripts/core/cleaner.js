import * as mc from '@minecraft/server';
import { isRpgAdmin } from './adminPermissions.js';
import { registeredDungeonAreas } from './dungeons.js';
import { inFootprint } from './dungeonCleanup.js';

const {world,system}=mc;
const enabledKey='rpg:cleaner_enabled_v1';
const ticksPerSecond=20;
const period=3*60*ticksPerSecond;
const dimensions=['overworld','nether','the_end'];
const protectedTypes=new Set([
  'minecraft:player','minecraft:armor_stand','minecraft:xp_orb','minecraft:ender_crystal',
  'minecraft:villager','minecraft:villager_v2','minecraft:wandering_trader','minecraft:npc','minecraft:agent',
  'minecraft:zombie','minecraft:husk','minecraft:drowned','minecraft:zombie_villager','minecraft:zombie_villager_v2',
  'minecraft:snow_golem','minecraft:iron_golem','minecraft:allay',
  'minecraft:cow','minecraft:mooshroom','minecraft:pig','minecraft:sheep','minecraft:chicken','minecraft:rabbit',
  'minecraft:goat','minecraft:horse','minecraft:donkey','minecraft:mule','minecraft:llama','minecraft:trader_llama',
  'minecraft:camel','minecraft:camel_husk','minecraft:skeleton_horse','minecraft:zombie_horse',
  'rpg:gpt_guide','rpg:sandbag_entity','rpg:super_sandbag','rpg:dungeon_loot_cache',
]);

let nextSweep, lastWarning, registered=false;

function removableMob(entity,areas){
  const type=entity.typeId;
  if(protectedTypes.has(type)||type.startsWith('rpg:hito_')||
     /^minecraft:(?:.*_)?(?:minecart|boat|raft)$/.test(type))return false;
  if(!(entity.getComponent('minecraft:health')?.currentValue>0))return false;
  if(entity.hasTag('rpg_dungeon_mob')||areas.some(area=>inFootprint(entity,area)))return false;
  if(entity.getComponent('minecraft:tameable')?.isTamed||entity.hasTag('rpg_player_owned')||
     entity.getDynamicProperty('rpg:necro_owner'))return false;
  const family=entity.getComponent('minecraft:type_family');
  return !family?.hasTypeFamily('inanimate')&&!family?.hasTypeFamily('zombie')&&
    !family?.hasTypeFamily('villager')&&!family?.hasTypeFamily('farm_animal');
}

function sweep(){
  const areas=registeredDungeonAreas();
  let mobs=0,items=0,bottles=0;
  for(const name of dimensions){
    let dim,entities;
    try{dim=world.getDimension(name);entities=dim.getEntities();}catch{continue;}
    const localAreas=areas.filter(area=>area.dimId===dim.id);
    for(const entity of entities){
      try{
        if(!entity.isValid)continue;
        const type=entity.typeId;
        if(type==='minecraft:item'){entity.remove();items++;}
        else if(type==='minecraft:xp_bottle'){entity.remove();bottles++;}
        // Despawn skips entityDie, so neither native drops nor scripted kill rewards run.
        else if(removableMob(entity,localAreas)){entity.remove();mobs++;}
      }catch(error){
        if(entity.isValid)console.warn('[RPG cleaner entity] '+String(error));
      }
    }
  }
  return {mobs,items,bottles};
}

function schedule(){
  nextSweep=system.currentTick+period;
  lastWarning=undefined;
}

function tickCleaner(){
  if(nextSweep===undefined)return;
  const remaining=nextSweep-system.currentTick;
  if(remaining>0){
    const seconds=Math.ceil(remaining/ticksPerSecond);
    if(seconds<=5&&seconds!==lastWarning){
      lastWarning=seconds;
      world.sendMessage(`§e청소기가 작동되기까지 ${seconds}초 남았습니다.`);
    }
    return;
  }
  schedule();
  try{
    const {mobs,items,bottles}=sweep();
    world.sendMessage(`§a청소기 작동 완료 · 몹 ${mobs}마리, 드롭 아이템 ${items}묶음, 날아가는 경험치 병 ${bottles}개를 제거했습니다.`);
  }catch(error){
    console.warn('[RPG cleaner] '+String(error));
    world.sendMessage('§c청소기 실행에 실패했습니다.');
  }
}

export function registerCleaner(){
  if(registered)return;
  if(world.getDynamicProperty(enabledKey)===true)schedule();
  system.runInterval(tickCleaner,1);
  registered=true;
}

export function runCleanerCommand(player,arg=''){
  if(!isRpgAdmin(player)){
    player.sendMessage('§c이 명령어는 운영자만 사용할 수 있습니다.');
    return;
  }
  const mode=String(arg).trim().toLowerCase();
  if(!['','on','off'].includes(mode)){
    player.sendMessage('§e사용법 /rpg:cleaner 또는 /rpg:cleaner off');
    return;
  }
  registerCleaner();
  if(mode==='off'){
    world.setDynamicProperty(enabledKey,undefined);
    nextSweep=undefined;
    player.sendMessage('§7자동 청소기를 껐습니다.');
    return;
  }
  if(nextSweep!==undefined){
    const seconds=Math.max(0,Math.ceil((nextSweep-system.currentTick)/ticksPerSecond));
    player.sendMessage(`§e자동 청소기가 실행 중입니다. 다음 청소까지 ${seconds}초 남았습니다.`);
    return;
  }
  world.setDynamicProperty(enabledKey,true);
  schedule();
  player.sendMessage('§a자동 청소기를 켰습니다. 3분마다 작동합니다.');
}

export function registerCleanerCommand(){
  system.beforeEvents.startup.subscribe(({customCommandRegistry})=>{
    const permissionLevel=mc.CommandPermissionLevel?.GameDirectors??mc.CustomCommandPermissionLevel?.GameDirectors;
    const type=mc.CustomCommandParamType?.String;
    const status=mc.CustomCommandStatus;
    if(!customCommandRegistry||permissionLevel===undefined||type===undefined||!status)return;
    try{
      customCommandRegistry.registerCommand({
        name:'rpg:cleaner',description:'운영자 전용 · 3분마다 자동 청소',
        permissionLevel,cheatsRequired:false,optionalParameters:[{name:'mode',type}],
      },(origin,...args)=>{
        const player=origin.sourceEntity??origin.initiator;
        if(player?.typeId!=='minecraft:player')return {status:status.Failure,message:'플레이어만 사용할 수 있습니다.'};
        const mode=Array.isArray(args[0])?args[0][0]:args[0];
        system.run(()=>{
          try{runCleanerCommand(player,mode);}
          catch(error){console.warn('[RPG cleaner command] '+String(error));player.sendMessage('§c청소기 설정을 저장하지 못했습니다.');}
        });
        return {status:status.Success};
      });
    }catch(error){console.warn('[RPG] /rpg:cleaner 등록 실패: '+String(error));}
  });
}
