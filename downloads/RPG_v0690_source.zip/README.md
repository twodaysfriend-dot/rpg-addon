# RPG v0.6.90 · 던전 보스 교체와 샌드웜 강화

| 던전 | 보스 | 체력 | 공격력 |
| --- | --- | ---: | ---: |
| 7단계 | 마공학 골렘 | 33,000 | 145 |
| 8단계 | 마공학 골렘 | 52,000 | 225 |
| 9단계 | 히드라 | 33,000 | 92 |
| 10단계 | 히드라 | 36,000 | 115 |

마공학 골렘은 기존 9·10단계의 체력, 공격력, 레벨, 피해 감소 수치를 순서대로 가져옵니다. 히드라는 기존 7·8단계의 체력을 각각 1.2배로 올려 옮겼습니다.

샌드웜(데스웜)과 엘리트 샌드웜은 필드와 던전 모두 체력 4배, 공격력 2배입니다. 레벨 보정 전 기준으로 일반 샌드웜은 체력 250·공격력 24, 엘리트는 체력 1,300·공격력 28입니다. 엘리트 샌드웜의 모래 분출에도 공격 배율이 적용됩니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.90으로 활성화하세요. 데이터와 모의 테스트에서 보스 스폰과 수치, 샌드웜의 필드·던전 배율, 저장된 샌드웜의 체력 비율 이전을 확인했습니다. 실제 Bedrock 월드에서는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0690
```
