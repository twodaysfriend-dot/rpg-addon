# RPG v0.6.100 · 올포원 초월에 각성 조건 추가

- 올포원도 `/rpg:skillbook`에서 각성한 공격·직접 회복 스킬만 초월하거나 초월강화할 수 있습니다. 각성과 초월 한도는 각각 5개입니다.
- v0.6.99에서 각성 없이 올린 초월·초월강화 단계는 보존됩니다. 그 스킬을 각성하면 저장된 단계의 효과가 적용됩니다. 사용 횟수 제한이 원래 없던 스킬도 구버전 초월 기록이 있으면 올포원이 각성할 수 있습니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.100으로 활성화하세요. 자동 검사에서 각성 전 구매·효과 차단, 각성 후 구매와 기존 초월 단계의 재적용을 확인했습니다. 실제 Bedrock 월드에서는 확인하지 못했습니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
python3 tools/build_protected_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v06100
```
