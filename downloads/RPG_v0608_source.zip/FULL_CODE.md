# RPG v0.6.8 변경 파일 전체 코드

## RPG_BP_v0603/entities/player.json

```json
{
  "format_version": "1.21.0",
  "minecraft:entity": {
    "description": {
      "identifier": "minecraft:player",
      "spawn_category": "creature",
      "is_spawnable": false,
      "is_summonable": false
    },
    "component_groups": {
      "minecraft:add_raid_omen": {
        "minecraft:spell_effects": {
          "add_effects": [
            {
              "effect": "raid_omen",
              "duration": 30,
              "display_on_screen_animation": true
            }
          ],
          "remove_effects": "bad_omen"
        },
        "minecraft:timer": {
          "time": [
            0.0,
            0.0
          ],
          "looping": false,
          "time_down_event": {
            "event": "minecraft:clear_add_raid_omen",
            "target": "self"
          }
        }
      },
      "minecraft:clear_raid_omen_spell_effect": {
        "minecraft:spell_effects": {}
      },
      "minecraft:raid_trigger": {
        "minecraft:raid_trigger": {
          "triggered_event": {
            "event": "minecraft:remove_raid_trigger",
            "target": "self"
          }
        }
      },
      "rpg:duel_safe": {},
      "rpg:duel_normal": {
        "minecraft:health": {
          "value": 20,
          "max": 20,
          "min": 0
        }
      },
      "rpg:ward_defense_0": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 1.0
            }
          ]
        }
      },
      "rpg:ward_defense_40": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.986
            }
          ]
        }
      },
      "rpg:ward_defense_44": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9846
            }
          ]
        }
      },
      "rpg:ward_defense_48": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9832
            }
          ]
        }
      },
      "rpg:ward_defense_54": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9811
            }
          ]
        }
      },
      "rpg:ward_defense_60": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.979
            }
          ]
        }
      },
      "rpg:ward_defense_66": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9769
            }
          ]
        }
      },
      "rpg:ward_defense_70": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9755
            }
          ]
        }
      },
      "rpg:ward_defense_72": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9748
            }
          ]
        }
      },
      "rpg:ward_defense_80": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.972
            }
          ]
        }
      },
      "rpg:ward_defense_81": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.97165
            }
          ]
        }
      },
      "rpg:ward_defense_88": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9692
            }
          ]
        }
      },
      "rpg:ward_defense_90": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9685
            }
          ]
        }
      },
      "rpg:ward_defense_96": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9664
            }
          ]
        }
      },
      "rpg:ward_defense_100": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.965
            }
          ]
        }
      },
      "rpg:ward_defense_105": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.96325
            }
          ]
        }
      },
      "rpg:ward_defense_108": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9622
            }
          ]
        }
      },
      "rpg:ward_defense_110": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9615
            }
          ]
        }
      },
      "rpg:ward_defense_120": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.958
            }
          ]
        }
      },
      "rpg:ward_defense_132": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9538
            }
          ]
        }
      },
      "rpg:ward_defense_135": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.95275
            }
          ]
        }
      },
      "rpg:ward_defense_140": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.951
            }
          ]
        }
      },
      "rpg:ward_defense_144": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9496
            }
          ]
        }
      },
      "rpg:ward_defense_150": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9475
            }
          ]
        }
      },
      "rpg:ward_defense_154": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9461
            }
          ]
        }
      },
      "rpg:ward_defense_160": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.944
            }
          ]
        }
      },
      "rpg:ward_defense_162": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9433
            }
          ]
        }
      },
      "rpg:ward_defense_168": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9412
            }
          ]
        }
      },
      "rpg:ward_defense_175": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.93875
            }
          ]
        }
      },
      "rpg:ward_defense_176": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9384
            }
          ]
        }
      },
      "rpg:ward_defense_180": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.937
            }
          ]
        }
      },
      "rpg:ward_defense_189": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.93385
            }
          ]
        }
      },
      "rpg:ward_defense_192": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9328
            }
          ]
        }
      },
      "rpg:ward_defense_198": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9307
            }
          ]
        }
      },
      "rpg:ward_defense_200": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.93
            }
          ]
        }
      },
      "rpg:ward_defense_210": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9265
            }
          ]
        }
      },
      "rpg:ward_defense_216": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9244
            }
          ]
        }
      },
      "rpg:ward_defense_220": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.923
            }
          ]
        }
      },
      "rpg:ward_defense_240": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.916
            }
          ]
        }
      },
      "rpg:ward_defense_242": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9153
            }
          ]
        }
      },
      "rpg:ward_defense_243": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.91495
            }
          ]
        }
      },
      "rpg:ward_defense_245": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.91425
            }
          ]
        }
      },
      "rpg:ward_defense_264": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9076
            }
          ]
        }
      },
      "rpg:ward_defense_270": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.9055
            }
          ]
        }
      },
      "rpg:ward_defense_280": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.902
            }
          ]
        }
      },
      "rpg:ward_defense_288": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.8992
            }
          ]
        }
      },
      "rpg:ward_defense_297": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.89605
            }
          ]
        }
      },
      "rpg:ward_defense_300": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.895
            }
          ]
        }
      },
      "rpg:ward_defense_315": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.88975
            }
          ]
        }
      },
      "rpg:ward_defense_320": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.888
            }
          ]
        }
      },
      "rpg:ward_defense_324": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.8866
            }
          ]
        }
      },
      "rpg:ward_defense_330": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.8845
            }
          ]
        }
      },
      "rpg:ward_defense_350": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.8775
            }
          ]
        }
      },
      "rpg:ward_defense_360": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.874
            }
          ]
        }
      },
      "rpg:ward_defense_385": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.86525
            }
          ]
        }
      },
      "rpg:ward_defense_400": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.86
            }
          ]
        }
      },
      "rpg:ward_defense_420": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.853
            }
          ]
        }
      },
      "rpg:ward_defense_440": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.846
            }
          ]
        }
      },
      "rpg:ward_defense_480": {
        "minecraft:damage_sensor": {
          "triggers": [
            {
              "cause": "all",
              "deals_damage": true,
              "damage_multiplier": 0.832
            }
          ]
        }
      }
    },
    "components": {
      "minecraft:experience_reward": {
        "on_death": "Math.Min(query.player_level * 7, 100)"
      },
      "minecraft:type_family": {
        "family": [
          "player"
        ]
      },
      "minecraft:is_hidden_when_invisible": {},
      "minecraft:loot": {
        "table": "loot_tables/empty.json"
      },
      "minecraft:collision_box": {
        "width": 0.6,
        "height": 1.8
      },
      "minecraft:can_climb": {},
      "minecraft:movement": {
        "value": 0.1
      },
      "minecraft:hurt_on_condition": {
        "damage_conditions": [
          {
            "filters": {
              "test": "in_lava",
              "subject": "self",
              "operator": "==",
              "value": true
            },
            "cause": "lava",
            "damage_per_tick": 4
          }
        ]
      },
      "minecraft:attack": {
        "damage": 1
      },
      "minecraft:exhaustion_values": {
        "heal": 6,
        "jump": 0.05,
        "sprint_jump": 0.2,
        "mine": 0.005,
        "attack": 0.1,
        "damage": 0.1,
        "walk": 0.0,
        "sprint": 0.1,
        "swim": 0.01
      },
      "minecraft:player.saturation": {
        "value": 5,
        "max": 20
      },
      "minecraft:player.exhaustion": {
        "value": 0,
        "max": 20
      },
      "minecraft:player.level": {
        "value": 0,
        "max": 24791
      },
      "minecraft:player.experience": {
        "value": 0,
        "max": 1
      },
      "minecraft:breathable": {
        "total_supply": 15,
        "suffocate_time": -1,
        "inhale_time": 3.75,
        "generates_bubbles": false
      },
      "minecraft:nameable": {
        "always_show": true,
        "allow_name_tag_renaming": false
      },
      "minecraft:physics": {
        "push_towards_closest_space": true
      },
      "minecraft:pushable": {
        "is_pushable": false,
        "is_pushable_by_piston": true
      },
      "minecraft:insomnia": {
        "days_until_insomnia": 3
      },
      "minecraft:rideable": {
        "seat_count": 2,
        "family_types": [
          "parrot_tame"
        ],
        "pull_in_entities": true,
        "seats": [
          {
            "position": [
              0.4,
              -0.2,
              -0.1
            ],
            "min_rider_count": 0,
            "max_rider_count": 0,
            "lock_rider_rotation": 0
          },
          {
            "position": [
              -0.4,
              -0.2,
              -0.1
            ],
            "min_rider_count": 1,
            "max_rider_count": 2,
            "lock_rider_rotation": 0
          }
        ]
      },
      "minecraft:conditional_bandwidth_optimization": {},
      "minecraft:block_climber": {},
      "minecraft:environment_sensor": {
        "triggers": {
          "filters": {
            "all_of": [
              {
                "test": "has_mob_effect",
                "subject": "self",
                "value": "bad_omen"
              },
              {
                "test": "is_in_village",
                "subject": "self",
                "value": true
              }
            ]
          },
          "event": "minecraft:gain_raid_omen"
        }
      },
      "minecraft:health": {
        "value": 20,
        "max": 20,
        "min": 0
      }
    },
    "events": {
      "minecraft:gain_raid_omen": {
        "add": {
          "component_groups": [
            "minecraft:add_raid_omen"
          ]
        }
      },
      "minecraft:clear_add_raid_omen": {
        "remove": {
          "component_groups": [
            "minecraft:add_raid_omen"
          ]
        },
        "add": {
          "component_groups": [
            "minecraft:clear_raid_omen_spell_effect"
          ]
        }
      },
      "minecraft:trigger_raid": {
        "add": {
          "component_groups": [
            "minecraft:raid_trigger"
          ]
        }
      },
      "minecraft:remove_raid_trigger": {
        "remove": {
          "component_groups": [
            "minecraft:raid_trigger"
          ]
        }
      },
      "rpg:duel_enter": {
        "remove": {
          "component_groups": [
            "rpg:duel_safe",
            "rpg:duel_normal"
          ]
        }
      },
      "rpg:duel_exit": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:duel_safe",
                "rpg:duel_normal"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:duel_normal"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_0": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_0"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_40": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_40"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_44": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_44"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_48": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_48"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_54": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_54"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_60": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_60"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_66": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_66"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_70": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_70"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_72": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_72"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_80": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_80"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_81": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_81"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_88": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_88"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_90": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_90"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_96": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_96"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_100": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_100"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_105": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_105"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_108": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_108"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_110": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_110"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_120": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_120"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_132": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_132"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_135": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_135"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_140": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_140"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_144": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_144"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_150": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_150"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_154": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_154"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_160": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_160"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_162": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_162"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_168": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_168"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_175": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_175"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_176": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_176"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_180": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_180"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_189": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_189"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_192": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_192"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_198": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_198"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_200": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_200"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_210": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_210"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_216": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_216"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_220": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_220"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_240": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_240"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_242": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_242"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_243": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_243"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_245": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_245"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_264": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_264"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_270": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_270"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_280": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_280"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_288": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_288"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_297": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_297"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_300": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_300"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_315": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_315"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_320": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_320"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_324": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_324"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_330": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_330"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_350": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_350"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_360": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_360"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_385": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_385"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_400": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_400"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_420": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_420"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_440": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_440"
              ]
            }
          }
        ]
      },
      "rpg:ward_defense_480": {
        "sequence": [
          {
            "remove": {
              "component_groups": [
                "rpg:ward_defense_0",
                "rpg:ward_defense_40",
                "rpg:ward_defense_44",
                "rpg:ward_defense_48",
                "rpg:ward_defense_54",
                "rpg:ward_defense_60",
                "rpg:ward_defense_66",
                "rpg:ward_defense_70",
                "rpg:ward_defense_72",
                "rpg:ward_defense_80",
                "rpg:ward_defense_81",
                "rpg:ward_defense_88",
                "rpg:ward_defense_90",
                "rpg:ward_defense_96",
                "rpg:ward_defense_100",
                "rpg:ward_defense_105",
                "rpg:ward_defense_108",
                "rpg:ward_defense_110",
                "rpg:ward_defense_120",
                "rpg:ward_defense_132",
                "rpg:ward_defense_135",
                "rpg:ward_defense_140",
                "rpg:ward_defense_144",
                "rpg:ward_defense_150",
                "rpg:ward_defense_154",
                "rpg:ward_defense_160",
                "rpg:ward_defense_162",
                "rpg:ward_defense_168",
                "rpg:ward_defense_175",
                "rpg:ward_defense_176",
                "rpg:ward_defense_180",
                "rpg:ward_defense_189",
                "rpg:ward_defense_192",
                "rpg:ward_defense_198",
                "rpg:ward_defense_200",
                "rpg:ward_defense_210",
                "rpg:ward_defense_216",
                "rpg:ward_defense_220",
                "rpg:ward_defense_240",
                "rpg:ward_defense_242",
                "rpg:ward_defense_243",
                "rpg:ward_defense_245",
                "rpg:ward_defense_264",
                "rpg:ward_defense_270",
                "rpg:ward_defense_280",
                "rpg:ward_defense_288",
                "rpg:ward_defense_297",
                "rpg:ward_defense_300",
                "rpg:ward_defense_315",
                "rpg:ward_defense_320",
                "rpg:ward_defense_324",
                "rpg:ward_defense_330",
                "rpg:ward_defense_350",
                "rpg:ward_defense_360",
                "rpg:ward_defense_385",
                "rpg:ward_defense_400",
                "rpg:ward_defense_420",
                "rpg:ward_defense_440",
                "rpg:ward_defense_480"
              ]
            }
          },
          {
            "add": {
              "component_groups": [
                "rpg:ward_defense_480"
              ]
            }
          }
        ]
      }
    }
  }
}

```

## RPG_BP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon BP v0.6.8",
    "description": "RPG v0.6.8 · PvP 무적·비살상 보호 제거 · 기존 보호 상태 정리",
    "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
    "version": [
      0,
      6,
      8
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "data",
      "uuid": "cc5d6e3c-5285-4787-8a59-a8e2856f2aec",
      "version": [
        0,
        6,
        8
      ]
    },
    {
      "type": "script",
      "language": "javascript",
      "uuid": "c41fa3d6-d82c-4a54-9783-68f92fe633a1",
      "entry": "scripts/gameplayEntry.js",
      "version": [
        0,
        6,
        8
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
      "version": [
        0,
        6,
        8
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    },
    {
      "module_name": "@minecraft/server-ui",
      "version": "2.0.0"
    }
  ]
}

```

## RPG_BP_v0603/scripts/core/combatContext.js

```js
import {isTimeFrozen} from './timeStopDamage.js';
import {system} from '@minecraft/server';
import {notePvpAttack} from './pvp.js';
export function setCombatHealth(target,source,hp,next){if(isTimeFrozen(source))return;const amount=Math.max(0,hp.currentValue-next);notePvpAttack(source,target,amount);if(next<=0&&source)rememberScriptKiller(source,target);hp.setCurrentValue(next);}
export const BLACK_FLASH_KEY='rpg:black_flash_ready';
const hits=[],pending=[],credits=new Map();let onManual=()=>{},basicHandler=()=>{},manualObserver=()=>{},manualMultiplier=()=>1;
export function setManualDamageMultiplier(fn){manualMultiplier=fn;}
export function setManualDamageObserver(fn){manualObserver=fn;}
export function setUnreportedDamageHandler(fn){onManual=fn;}
export function setBasicHitHandler(fn){basicHandler=fn;}
export function handleBasicHit(ev,scripted){basicHandler(ev,scripted);}
const same=(h,s,t)=>h.source?.id===s?.id&&h.target?.id===t?.id;
export function currentScriptHit(source,target){return [...hits].reverse().find(h=>same(h,source,target));}
function prune(){for(let i=pending.length-1;i>=0;i--)if(pending[i].until<system.currentTick)pending.splice(i,1);}
export function markDamageReported(source,target){
 prune();const h=currentScriptHit(source,target)??pending.find(h=>same(h,source,target));if(h){h.reported=true;const i=pending.indexOf(h);if(i>=0)pending.splice(i,1);}return h;
}
export function noteManualDamage(source,target,damage,{incomingScaled=false}={}){
 if(!incomingScaled&&damage>0){try{const hp=target.getComponent('minecraft:health'),extra=Math.min(hp?.currentValue??0,damage*Math.max(0,manualMultiplier(target)-1));if(extra>0){if(extra>=hp.currentValue&&source)rememberScriptKiller(source,target);setCombatHealth(target,source,hp,Math.max(0,hp.currentValue-extra));damage+=extra;}}catch{}}
 const h=currentScriptHit(source,target);if(h)h.manualDamage=(h.manualDamage??0)+damage;try{manualObserver(source,target,damage);}catch{}
}

export function rememberScriptKiller(source,target){for(const [id,c]of credits)if(c.until<system.currentTick)credits.delete(id);credits.set(target.id,{source,until:system.currentTick+4});}
export function scriptKiller(target){const c=credits.get(target?.id);credits.delete(target?.id);return c&&c.until>=system.currentTick?c.source:undefined;}
export function scriptedHit(target,source,fn){
 if(isTimeFrozen(source))return false;
 let before;try{before=target.getComponent('minecraft:health')?.currentValue;}catch{}
 prune();const h={source,target,before,reported:false,until:system.currentTick+2};hits.push(h);pending.push(h);let result;
 try{result=fn();return result;}finally{
  hits.pop();if(h.manualDamage>0){try{onManual(source,target,h.manualDamage);}catch{}h.reported=true;}
  if(h.reported||result===false){const i=pending.indexOf(h);if(i>=0)pending.splice(i,1);}
 }
}

```

## RPG_BP_v0603/scripts/core/friendlyFire.js

```js
import {CONFIG} from '../config.js';
import { world, system, EntityDamageCause } from "@minecraft/server";
import { areAllies } from "./social.js";

let registered = false;

// 최종 피해 판정에서 같은 길드/파티/팀의 플레이어를 보호합니다.
// minecraft:projectile 컴포넌트의 owner도 추적하여 일반 화살을 포함합니다.
export function registerFriendlyFire(onAllyMeleeHit) {
  if (registered) return;
  registered = true;
  try {
    world.beforeEvents.entityHurt?.subscribe(event => {
      try {
        const victim = event.hurtEntity;
        if (victim?.typeId !== "minecraft:player") return;
        const src = event.damageSource;
        let attacker = src?.damagingEntity;
        if (!attacker || attacker.typeId !== "minecraft:player") {
          const projectile = src?.damagingProjectile;
          attacker = projectile?.getComponent("minecraft:projectile")?.owner ?? attacker;
        }
        if (attacker?.typeId === "minecraft:player" && (!CONFIG.pvp || areAllies(attacker, victim))) {
          event.cancel = true;
          // Canceling damage can also suppress afterEvents.entityHitEntity on some
          // Bedrock versions. Still allow *support* skills to target guild/party allies.
          if (typeof onAllyMeleeHit === "function" &&
              src?.cause === EntityDamageCause.entityAttack &&
              src?.damagingEntity?.id === attacker.id) {
            system.run(() => {
              try { if (attacker.isValid && victim.isValid) onAllyMeleeHit(attacker, victim); }
              catch {}
            });
          }
        }
      } catch { /* 접근할 수 없는 엔티티는 무시 */ }
    });
  } catch(error) {
    console.warn(`[RPG] 아군 피해 취소 이벤트를 연결하지 못했습니다: ${error}`);
  }
}

```

## RPG_BP_v0603/scripts/core/pvp.js

```js
import {arenaReady,enterDuelArena,releaseDuelArena,restoreArenaPlayer,insidePvpArena} from './pvpArena.js';
import {world,system} from '@minecraft/server';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {getWallet,setWallet,BALANCE_MAX} from './wallet.js';
import {dungeonRuns} from './dungeonState.js';
import {showForm} from './skillMenu.js';
const STORE='rpg:pk_registry_v1',RECOVER='rpg:duel_recover',PK_GRACE='rpg:post_duel_pk_until';
const pkExempt=new Map(),repairing=new Set();
export function hasPostDuelPkGrace(p){return Math.max(pkExempt.get(p?.id)??0,Number(p?.getDynamicProperty?.(PK_GRACE)??0))>Date.now();}
const duels=new Map(),offers=new Map(),lastHits=new Map(),deaths=new Map();let registered=false;
const online=id=>world.getAllPlayers().find(p=>p.id===id);
const hp=p=>p?.getComponent('minecraft:health');
const tell=(p,s)=>{try{p?.sendMessage(s);}catch{}};
const active=p=>p?.isValid&&p.typeId==='minecraft:player'&&hp(p)?.currentValue>0&&!['creative','spectator'].includes(String(p.getGameMode()).toLowerCase());
const distance=(a,b)=>a.dimension.id===b.dimension.id?Math.hypot(a.location.x-b.location.x,a.location.y-b.location.y,a.location.z-b.location.z):Infinity;
const inDungeon=p=>[...dungeonRuns.values()].some(r=>r.members.some(m=>m.id===p.id));
export function pvpOwner(source){if(!source||source.typeId==='minecraft:player')return source;try{const owner=source.getComponent('minecraft:projectile')?.owner;if(owner?.typeId==='minecraft:player')return owner;const id=source.getComponent('minecraft:tameable')?.tamedToPlayerId??source.getDynamicProperty('rpg:necro_owner');return online(id)??source;}catch{return source;}}
export function notePvpAttack(source,target,damage){source=pvpOwner(source);if(damage>0&&source?.typeId==='minecraft:player'&&target?.typeId==='minecraft:player'&&source.id!==target.id&&!duelOf(target))lastHits.set(target.id,{id:source.id,name:source.name,until:Date.now()+10000});}
function registry(){return JSON.parse(world.getDynamicProperty(STORE)??'{"version":1,"pk":{}}');}
function save(s){const raw=JSON.stringify(s);if(raw.length>29000)throw Error('PK 저장 공간 부족');world.setDynamicProperty(STORE,raw);}
export function isPk(p){return Boolean(registry().pk[p?.id]);}
function refreshPk(p){if(!p)return;const marked=isPk(p);try{if(marked)p.addTag('rpg_pk');else p.removeTag('rpg_pk');}catch{}try{if(marked){if(p.getDynamicProperty('rpg:pk_name')===undefined)p.setDynamicProperty('rpg:pk_name',p.nameTag??p.name);p.nameTag='§c[PK] §r'+p.name;}else{const old=p.getDynamicProperty('rpg:pk_name');if(old!==undefined){p.nameTag=old;p.setDynamicProperty('rpg:pk_name',undefined);}}}catch{}}
export function markPk(p){if(hasPostDuelPkGrace(p))return;const s=registry(),old=s.pk[p.id];s.pk[p.id]={name:p.name,kills:(old?.kills??0)+1,since:old?.since??Date.now()};save(s);refreshPk(p);tell(p,'§c[PK] 합의된 결투 밖에서 플레이어를 살해했습니다. PK 표식·현상금 패널티가 적용됩니다.');}
export function transferBounty(killer,victim){const a=getWallet(killer),b=getWallet(victim),amount=Math.min(50000,b.gold,BALANCE_MAX-a.gold);try{setWallet(victim,{...b,gold:b.gold-amount});setWallet(killer,{...a,gold:a.gold+amount});}catch(error){try{setWallet(victim,b);setWallet(killer,a);}catch{}throw error;}return amount;}
export function duelOf(p){return duels.get(typeof p==='string'?p:p?.id);}
export function duelOpponents(a,b){const d=duelOf(a);return Boolean(d&&d===duelOf(b)&&a.id!==b.id);}
function fullHealth(p){const h=hp(p);if(h&&h.currentValue>0)h.setCurrentValue(h.effectiveMax??20);}
// Migration only: new duels never enable native health floors or damage immunity.
// Legacy recovery explicitly restores ordinary min-HP=0; new duels never add min-HP=1.
// A delayed native health reset must never heal the player during migration.
export function clearLegacyDuelProtection(p){
 const h=hp(p);
 if(!p?.isValid||!h||h.currentValue<=0||repairing.has(p.id))return false;
 if(!p.getDynamicProperty(RECOVER)&&!(h.effectiveMin>0))return false;
 const previousHealth=h.currentValue;
 p.setDynamicProperty(RECOVER,true);
 try{p.triggerEvent('rpg:duel_exit');}catch(error){console.warn('[RPG PvP legacy repair] '+error);return false;}
 repairing.add(p.id);
 system.runTimeout(()=>{
  repairing.delete(p.id);
  try{
   if(!p.isValid)return;const health=hp(p);if(!health||health.currentValue<=0)return;
   if(health.currentValue>previousHealth)health.setCurrentValue(Math.min(previousHealth,health.effectiveMax));
   if(health.effectiveMin===0){p.setDynamicProperty(RECOVER,undefined);}
  }catch(error){console.warn('[RPG PvP legacy repair] '+error);}
 },2);
 return true;
}
export function finishDuel(d,winner,reason='결투 종료'){
 if(!d||d.finished)return;d.finished=true;for(const id of d.ids)duels.delete(id);
 for(const id of d.ids){lastHits.delete(id);pkExempt.set(id,Date.now()+10000);}
 for(const id of d.ids){const p=online(id);if(p){try{p.setDynamicProperty(PK_GRACE,Date.now()+10000);}catch{}try{clearLegacyDuelProtection(p);}catch{}}tell(p,`§e[결투] ${reason}${winner?' · 승자 '+winner.name:''}. 결투 PK·현상금은 없습니다.`);}
 system.runTimeout(()=>releaseDuelArena(d.ids),2);
}
export function requestDuel(p,target){
 if(!active(p)||!active(target)||p.id===target.id)throw Error('생존한 다른 서바이벌 플레이어를 선택하세요.');
 if(!arenaReady())throw Error('관리자가 /pvpcreate 또는 /rpg:pvpcreate로 PvP장을 먼저 생성해야 합니다.');
 if(duelOf(p)||duelOf(target)||inDungeon(p)||inDungeon(target))throw Error('던전·결투 진행 중에는 신청할 수 없습니다.');
 const existing=offers.get(target.id);if(existing&&existing.until>Date.now()&&existing.from!==p.id)throw Error('상대가 다른 결투 신청에 응답 중입니다.');offers.set(target.id,{from:p.id,until:Date.now()+30000});tell(p,'§e[결투] '+target.name+'에게 신청했습니다.');tell(target,'§e[결투] '+p.name+'의 신청입니다. /rpg:pvp에서 30초 안에 수락하세요.');return true;
}
export function acceptDuel(p,expectedFrom){
 const offer=offers.get(p.id),other=online(offer?.from);if(!offer||offer.until<Date.now())throw Error('유효한 결투 신청이 없습니다.');if(expectedFrom&&offer.from!==expectedFrom)throw Error('신청자가 바뀌었습니다. 결투 메뉴를 다시 여세요.');
 if(!active(p)||!active(other)||duelOf(p)||duelOf(other)||inDungeon(p)||inDungeon(other))throw Error('결투 참가 상태·거리·던전 상태를 확인하세요.');
 // Ordinary combat is lethal: no native min-HP component, damage refund or shield.
 enterDuelArena(p,other);
 const d={ids:[p.id,other.id],phase:'countdown',until:Date.now()+303000,finished:false};duels.set(p.id,d);duels.set(other.id,d);offers.delete(p.id);offers.delete(other.id);for(const [id,o]of offers)if(o.from===p.id||o.from===other.id)offers.delete(id);
 try{for(const a of [p,other]){fullHealth(a);clearLegacyDuelProtection(a);tell(a,'§e[결투] 3초 후 시작합니다. 대기 중에도 피해를 받습니다.');}}
 catch(error){finishDuel(d,undefined,'결투 준비 실패');throw error;}
 system.runTimeout(()=>{if(d.finished)return;const a=online(d.ids[0]),b=online(d.ids[1]);if(!active(a)||!active(b)||!insidePvpArena(a)||!insidePvpArena(b)||distance(a,b)>48){finishDuel(d,undefined,'시작 조건 불충족');return;}d.phase='active';d.until=Date.now()+300000;for(const p of [a,b])tell(p,'§c[결투] 시작! 사망하면 패배합니다.');},60);return d;
}
export function observePvpHurt(ev){
 const target=ev.hurtEntity;if(target?.typeId!=='minecraft:player')return;
 const source=pvpOwner(ev.damageSource?.damagingEntity??ev.damageSource?.damagingProjectile?.getComponent('minecraft:projectile')?.owner);
 notePvpAttack(source,target,ev.damage);
}

export function recordPvpDeath(killer,victim){
 if(victim?.typeId!=='minecraft:player')return;
 const d=duelOf(victim);if(d){const opponent=online(d.ids.find(id=>id!==victim.id));finishDuel(d,active(opponent)?opponent:undefined,'결투 참가자 사망');return;}
 if(deaths.get(victim.id)===system.currentTick)return;deaths.set(victim.id,system.currentTick);
 if(killer?.typeId!=='minecraft:player'){const last=lastHits.get(victim.id);killer=last?.until>Date.now()?(online(last.id)??{id:last.id,name:last.name,typeId:'minecraft:player',isValid:false}):undefined;}
 lastHits.delete(victim.id);if(!killer||killer.id===victim.id)return;
 if(hasPostDuelPkGrace(killer)||hasPostDuelPkGrace(victim))return;
 if(isPk(victim)){
  let amount;const s=registry();if(killer.isValid===false){const before=getWallet(victim);s.credits??={};const owed=s.credits[killer.id]??0;amount=Math.min(50000,before.gold,BALANCE_MAX-owed);try{setWallet(victim,{...before,gold:before.gold-amount});s.credits[killer.id]=owed+amount;delete s.pk[victim.id];save(s);}catch(error){setWallet(victim,before);throw error;}}else{const ka=getWallet(killer),va=getWallet(victim);try{amount=transferBounty(killer,victim);delete s.pk[victim.id];save(s);}catch(error){setWallet(killer,ka);setWallet(victim,va);throw error;}}refreshPk(victim);tell(killer,'§6[현상금] PK 플레이어 지갑에서 '+amount.toLocaleString()+'골드를 받았습니다. 추가 PK 패널티는 없습니다.');tell(victim,'§c[PK] '+amount.toLocaleString()+'골드가 현상금으로 지급되었고 PK 표식이 해제됐습니다.');
 }else markPk(killer);
}
export function recoverPvpPlayer(p){if(!duelOf(p))try{restoreArenaPlayer(p);}catch(error){console.warn('[RPG arena recovery] '+error);}const state=registry(),owed=state.credits?.[p.id]??0;if(owed){const before=getWallet(p),amount=Math.min(owed,BALANCE_MAX-before.gold);try{setWallet(p,{...before,gold:before.gold+amount});state.credits[p.id]=owed-amount;save(state);}catch(error){setWallet(p,before);throw error;}}clearLegacyDuelProtection(p);refreshPk(p);}
export async function openPvp(p,arg=''){
 try{
  const text=String(arg).trim();if(text){if(['수락','accept'].includes(text))return acceptDuel(p);if(['거절','reject'].includes(text)){offers.delete(p.id);return;}if(['항복','surrender'].includes(text)){const d=duelOf(p);if(d)finishDuel(d,online(d.ids.find(id=>id!==p.id)),'항복');return;}const target=world.getAllPlayers().find(a=>a.name.toLowerCase()===text.toLowerCase());if(!target)throw Error('접속 중인 플레이어를 찾지 못했습니다.');return requestDuel(p,target);}
  const d=duelOf(p);if(d){const r=await showForm(new MessageFormData().title('진행 중인 결투').body('결투를 포기할까요?').button1('계속').button2('항복'),p);if(r&&!r.canceled&&r.selection===1)finishDuel(d,online(d.ids.find(id=>id!==p.id)),'항복');return;}
  const pending=offers.get(p.id);if(pending&&pending.until>Date.now()){const from=online(pending.from);const r=await showForm(new MessageFormData().title('결투 신청').body((from?.name??'상대')+'의 결투를 수락할까요? 두 사람 체력을 채운 뒤 시작합니다.').button1('거절').button2('수락'),p);if(r&&!r.canceled&&r.selection===1)return acceptDuel(p,pending.from);if(r&&!r.canceled&&offers.get(p.id)===pending)offers.delete(p.id);return;}
  const list=world.getAllPlayers().filter(a=>a.id!==p.id&&active(a)&&!duelOf(a)&&!inDungeon(a)).sort((a,b)=>a.name.localeCompare(b.name));
  const f=new ActionFormData().title('PvP · 상대 플레이어 선택').body((list.length?'결투할 플레이어를 선택하세요. 수락 시 두 사람이 PvP장으로 이동합니다.':'현재 신청 가능한 다른 플레이어가 없습니다. 상대가 서바이벌 상태로 접속했는지 확인하세요.')+'\n상대가 수락하면 체력을 회복하고 3초 후 시작합니다.\n내 PK 상태: '+(isPk(p)?'PK':'없음'));
  for(const a of list){const dist=distance(p,a);f.button(a.name+'\n'+(Number.isFinite(dist)?Math.ceil(dist)+'칸 거리':'다른 차원'));}
  f.button('닫기');const r=await showForm(f,p);
  if(!r||r.canceled||!Number.isInteger(r.selection)||r.selection<0||r.selection>=list.length)return;
  const target=list[r.selection];
  const confirm=await showForm(new MessageFormData().title('결투 신청 확인').body(target.name+'님에게 결투를 신청할까요? 상대가 수락해야 시작됩니다.').button1('취소').button2('신청'),p);
  if(confirm&&!confirm.canceled&&confirm.selection===1)requestDuel(p,target);
 }catch(error){tell(p,'§c[PvP] '+String(error.message??error));}
}
export function registerPvp(){
 if(registered)return;registered=true;
 world.afterEvents.entityHurt.subscribe(ev=>{try{observePvpHurt(ev);}catch(error){console.warn('[RPG PvP hurt] '+error);}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{try{recoverPvpPlayer(ev.player);}catch{}},20));
 world.afterEvents.playerLeave.subscribe(ev=>{const d=duelOf(ev.playerId);if(d)finishDuel(d,online(d.ids.find(id=>id!==ev.playerId)),'접속 종료로 패배');offers.delete(ev.playerId);});
 system.run(()=>{for(const p of world.getAllPlayers())try{recoverPvpPlayer(p);}catch{}});
 system.runInterval(()=>{for(const p of world.getAllPlayers()){try{clearLegacyDuelProtection(p);}catch{}}for(const [id,o]of offers)if(o.until<Date.now())offers.delete(id);for(const [id,h]of lastHits)if(h.until<Date.now())lastHits.delete(id);for(const d of new Set(duels.values())){const a=online(d.ids[0]),b=online(d.ids[1]);if(!active(a)||!active(b)||!insidePvpArena(a)||!insidePvpArena(b)||distance(a,b)>48||Date.now()>d.until)finishDuel(d,undefined,'시간 초과·범위 이탈·참가 상태 변경');}},20);
}

let reflectingPk=false;
export function reflectPkDamage(source,target,damage){
 source=pvpOwner(source);
 if(reflectingPk||source?.typeId!=='minecraft:player'||target?.typeId!=='minecraft:player'||source.id===target.id||!Number.isFinite(damage)||damage<=0||!isPk(source))return 0;
 const amount=damage*.7;reflectingPk=true;
 try{
  const h=hp(source);if(!h||h.currentValue<=0)return 0;const before=h.currentValue;
  source.applyDamage(amount,{cause:'override'});return Math.min(before,amount);
 }finally{reflectingPk=false;}
}

export function clearPkPenalty(admin,arg=''){
 const permitted=admin?.playerPermissionLevel===2||admin?.commandPermissionLevel>=1||admin?.isOp?.()===true;
 if(!permitted){tell(admin,'§c관리자만 PK 패널티를 해제할 수 있습니다.');return false;}
 const name=String(arg).trim().replace(/^"|"$/g,''),s=registry();
 const target=name?world.getAllPlayers().find(p=>p.name.toLowerCase()===name.toLowerCase()):admin;
 const id=target?.id??Object.keys(s.pk).find(id=>s.pk[id].name?.toLowerCase()===name.toLowerCase());
 if(!id){tell(admin,'§e해당 플레이어의 PK 기록을 찾지 못했습니다.');return false;}
 delete s.pk[id];save(s);lastHits.delete(id);if(target)refreshPk(target);
 tell(admin,'§a'+(target?.name??name)+' PK 패널티를 해제했습니다.');return true;
}

```

## RPG_BP_v0603/scripts/core/pvpArena.js

```js
import {world,system} from '@minecraft/server';
import {registerStructureProtection} from './structureProtection.js';
export const ARENA={x:1000,y:250,z:1000,radius:16,dimension:'minecraft:overworld'};
const KEY='rpg:pvp_arena_v1',RETURN='rpg:pvp_arena_return_v1';let building=false,occupants=new Set(),registered=false;
const wait=ticks=>new Promise(resolve=>system.runTimeout(resolve,ticks));
export function arenaReady(){try{return world.getDynamicProperty(KEY)===true;}catch{return false;}}
export function insidePvpArena(p){return p?.dimension?.id===ARENA.dimension&&Math.abs(p.location.x-1000)<16&&Math.abs(p.location.z-1000)<16&&p.location.y>=251&&p.location.y<259;}
export async function createPvpArena(p){
 const admin=p?.playerPermissionLevel===2||p?.commandPermissionLevel>=1||p?.isOp?.()===true;
 if(!admin){p.sendMessage('§cPvP장 생성은 관리자만 가능합니다.');return false;}
 if(building){p.sendMessage('§ePvP장을 생성 중입니다.');return false;}
 if(arenaReady()){p.sendMessage('§bPvP장이 이미 있습니다: 오버월드 1000 250 1000');return true;}
 building=true;let modified=false;
 try{
  p.sendMessage('§bPvP장 생성 준비 중 · 오버월드 1000 250 1000');const dim=world.getDimension('overworld');
  try{dim.runCommand('tickingarea add circle 1000 250 1000 2 rpg_pvp_arena true');}catch{}
  let loaded=false;
  for(let attempt=0;attempt<10;attempt++){try{loaded=Boolean(dim.getBlock({x:1000,y:250,z:1000}));}catch{}if(loaded)break;await wait(20);}
  if(!loaded)throw Error('생성 위치 청크를 불러오지 못했습니다. tickingarea 여유를 확인하거나 해당 위치를 불러온 뒤 다시 실행하세요.');
  // Inspect the full volume before replacing blocks. A failed scan leaves existing builds intact.
  let scanned=0;
  for(let y=250;y<=259;y++)for(let x=984;x<=1016;x++)for(let z=984;z<=1016;z++){
   const block=dim.getBlock({x,y,z});if(!block)throw Error('검사 도중 청크가 해제되었습니다. 다시 실행하세요.');
   const air=block.isAir??['minecraft:air','minecraft:cave_air','minecraft:void_air'].includes(block.typeId);
   if(!air)throw Error('PvP장 범위에 기존 블록이 있습니다. 984~1016 / 높이 250~259 구역을 비운 뒤 다시 실행하세요.');
   if(++scanned%1024===0)await wait(1);
  }
  modified=true;
  dim.runCommand('fill 984 250 984 1016 250 1016 minecraft:obsidian');
  dim.runCommand('fill 984 251 984 1016 255 984 minecraft:quartz_block');
  dim.runCommand('fill 984 251 1016 1016 255 1016 minecraft:quartz_block');
  dim.runCommand('fill 984 251 985 984 255 1015 minecraft:quartz_block');
  dim.runCommand('fill 1016 251 985 1016 255 1015 minecraft:quartz_block');
  dim.runCommand('fill 984 259 984 1016 259 1016 minecraft:glass');
  for(const x of [988,1012])for(const z of [988,1012])dim.runCommand(`setblock ${x} 250 ${z} minecraft:sea_lantern`);
  dim.runCommand('fill 998 250 998 1002 250 1002 minecraft:red_concrete');
  world.setDynamicProperty(KEY,true);p.sendMessage('§aPvP장 생성 완료! 결투 수락 시 자동 이동합니다.');return true;
 }catch(error){p.sendMessage('§c[PvP장] '+String(error.message??error)+(modified?' · 일부 블록이 생성되었을 수 있습니다.':''));return false;}
 finally{building=false;}
}
export function restoreArenaPlayer(p){
 const raw=p.getDynamicProperty(RETURN);if(raw===undefined)return false;
 // Dead players return after respawn; keep the saved destination until then.
 if((p.getComponent('minecraft:health')?.currentValue??0)<=0)return false;
 const saved=JSON.parse(raw);p.teleport(saved.location,{dimension:world.getDimension(saved.dimension),keepVelocity:false,...(saved.rotation?{rotation:saved.rotation}:{})});
 p.setDynamicProperty(RETURN,undefined);return true;
}
export function enterDuelArena(a,b){
 if(!arenaReady())throw Error('관리자가 /pvpcreate 또는 /rpg:pvpcreate로 PvP장을 먼저 생성해야 합니다.');
 if(occupants.size)throw Error('PvP장에서 다른 결투가 진행 중입니다. 잠시 후 다시 신청하세요.');
 for(const p of [a,b])if(p.getDynamicProperty(RETURN)!==undefined)throw Error(p.name+'님의 이전 PvP장 귀환이 대기 중입니다. 재접속 후 다시 신청하세요.');
 const players=[a,b],dim=world.getDimension('overworld');
 try{
  for(const p of players){p.setDynamicProperty(RETURN,JSON.stringify({dimension:p.dimension.id,location:p.location,rotation:p.getRotation?.()}));occupants.add(p.id);}
  for(let i=0;i<2;i++)players[i].teleport({x:1000.5,y:251,z:i?1008.5:992.5},{dimension:dim,keepVelocity:false,facingLocation:{x:1000.5,y:252,z:i?992.5:1008.5}});
 }catch(error){for(const p of players)try{restoreArenaPlayer(p);}catch{}occupants.clear();throw error;}
}
export function releaseDuelArena(ids){for(const id of ids){occupants.delete(id);const p=world.getAllPlayers().find(p=>p.id===id);if(p)try{restoreArenaPlayer(p);}catch(error){console.warn('[RPG PvP arena return] '+error);}}}
export function registerPvpArena(){
 if(registered)return;registered=true;
 registerStructureProtection('pvp_arena',block=>arenaReady()&&block.dimension.id===ARENA.dimension&&block.location.x>=984&&block.location.x<=1016&&block.location.z>=984&&block.location.z<=1016&&block.location.y>=250&&block.location.y<=259);
 system.run(()=>{if(arenaReady())try{world.getDimension('overworld').runCommand('tickingarea add circle 1000 250 1000 2 rpg_pvp_arena true');}catch{}});
}

```

## RPG_BP_v0603/scripts/core/rpgKnowledge.js

```js
import {dungeonMonsterLevel} from '../data/monsterLevels.js';
import {PROMOTION_RATES,GRADE_MULTIPLIERS,ARMOR_GRADE_HP} from '../data/grades.js';
import {RARITIES,itemRarity,runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {skillScalingInfo} from '../data/skillScaling.js';
import {isBalanceQuestion,isHiddenPromotionQuestion} from './assistantPolicy.js';
import {JOBS,APPRENTICE_SKILLS} from '../data/jobs.js';
import {SKILLS} from '../data/skills.js';
import {LINE_NOTES,SKILL_NOTES} from '../data/skillGuide.js';
import {JOB_TRIALS} from '../data/jobTrials.js';
import {CRAFTING_RECIPES} from '../data/crafting.js';
import {RUNES,ARMOR_SETS} from '../data/equipment.js';
import {upgradedRune,RUNE_MAX,ARMOR_MAX,MAX_CATALYSTS,upgradeCost,enhancementRates} from '../data/upgrades.js';
import {DUNGEON,DUNGEON_TIERS,clearRewardForTier,netheriteChanceForTier} from '../data/dungeons.js';
import {CONFIG} from '../config.js';
import {defaultDamageTypeFor} from './stats.js';
export const QUESTION_LIMIT=200;
export const UNKNOWN_ANSWER='이 애드온의 직업·스킬·룬·갑옷·제작·강화·던전·성장 정보만 안내합니다. 도감에 없는 내용은 확인할 수 없습니다. 예: 월룡륜미 범위 / 검사 전직 / 생명의 룬 / 샌드백 제작';
export const normalizeQuestion=s=>String(s??'').normalize('NFKC').toLowerCase().replace(/§./g,'').replace(/[^a-z0-9가-힣]/g,'');
const clean=s=>String(s??'').replace(/§./g,'').replace(/[\u0000-\u0008\u000b-\u001f]/g,'');
const bossName=id=>({rock_golem_boss:'바위 골렘',cyclops_boss:'외눈 거인',hydra_boss:'히드라',tech_block_golem_boss:'마공학 골렘'}[id]??'던전 보스');
const percent=n=>Number((n*100).toFixed(3))+'%';
function runeEffects(r){
 const a=[];if(r.physical)a.push('물리 피해 +'+percent(r.physical-1));if(r.magic)a.push('마법 피해 +'+percent(r.magic-1));
 if(r.defense)a.push('RPG 방어력 +'+Number(r.defense.toFixed(1))+' (피해 감소 '+percent(r.defense*.0035)+')');if(r.health)a.push('최대 HP +'+r.health);if(r.manaRegenPercent)a.push('초당 최대 MP의 '+percent(r.manaRegenPercent)+' 추가 회복');
 if(r.lifesteal)a.push('준 피해의 '+percent(r.lifesteal)+' HP 회복');if(r.ward)a.push('저항 '+(r.wardAmplifier+1)+'단계 유지');return a.join(', ');
}
const EFFECT_GROUPS=[
 {id:'damagebuff',title:'피해 증가·공격 강화 기술',match:q=>/딜뻥|공증|뎀증|힘버프|공격력버프|((데미지|대미지|피해|공격력|딜).*(버프|증가|강화|올려|높여))/.test(q),groups:[
 ['힘 효과를 주는 기술',['holy_sword','fist_stance','beast_berserk','blood_awaken','fire_armor','fire_emperor','sun_descent']],
 ['평타·후속 타격을 강화하는 기술',['war_god_black_flash','sun_slash','fist_strong','berserker_execute','assassin_stealth','dragon_triple_strike']],
 ['적이 받는 피해를 늘리는 기술',['assassin_mark','fallen_orb','berserker_charge']],
 ['적에게 힘을 주는 예외: 자가 공격 강화용 지원기가 아님',['demon_contract']]]},
 {id:'healing',title:'회복·흡혈 기술',match:q=>/회복|힐|치유|흡혈/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|있는|주는/.test(q),groups:[['회복·재생·흡혈 효과',['holy_heal','holy_orb','angel_bless','angel_zone','demon_vampirism','fallen_sword_frenzy','beast_berserk','moon_moonlight','sun_descent']]]},
 {id:'defense',title:'보호·방어 강화 기술',match:q=>/보호막|방어버프|저항버프|피해흡수/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['보호·저항·피해 흡수',['holy_shield','holy_orb','angel_bless','angel_zone','fallen_shield','fist_stance','fire_armor','sun_blessing','sun_descent','demon_contract']]]},
 {id:'control',title:'적 제어 기술',match:q=>/기절|동결|빙결|속박|둔화|cc/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['제어 효과를 갖는 기술 예시',['fist_face','frost_grasp','frost_absolute','blood_bind','tech_prison','sage_zero','moon_fullwave','sun_slash']]]}
];
function effectKnowledge(q){
 const g=EFFECT_GROUPS.find(g=>g.match(q));if(!g)return undefined;
 
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder&&j.id!=='chameleon');
 const groups=g.groups.map(([title,ids])=>title+'\n'+ids.filter(id=>SKILLS[id]&&SKILL_NOTES[id]).map(id=>{
 const skill=SKILLS[id],owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name).join('·');
 return '• '+skill.name+' ('+owners+'): '+SKILL_NOTES[id].split(/\.\s+(?=[가-힣A-Z])/)[0]+'.';
 }).join('\n')).join('\n\n');
 return Object.freeze({id:'effect:'+g.id,title:g.title,aliases:[],body:groups+'\n\n효과별 안내이며 강함·티어 순위가 아닙니다. 개별 기술명으로 상세 수치·조건을 확인하세요.',source:'data/skills.js · data/skillGuide.js · data/jobs.js'});
}
const PUBLIC_JOBS=new Set(['swordsman','mage','archer','fighter','cleric']);
let catalog;
export function knowledgeEntries(){
 if(catalog)return catalog;
 const entries=[];
 const add=(id,title,aliases,body,source)=>entries.push(Object.freeze({id,title,aliases:Object.freeze([...new Set([title,...aliases].map(normalizeQuestion).filter(x=>x.length>=2))]),body:clean(body),source}));
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder),active=new Set([...jobs.flatMap(j=>j.skills),...Object.values(APPRENTICE_SKILLS).flat()]);
 for(const id of active){
  const s=SKILLS[id];if(!s||!SKILL_NOTES[id])continue;
  const owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name);
  add('skill:'+id,s.name,[id,s.name.replace(/\s*\([^)]*\)/g,''),s.name.replace(/\s*제작$/,'')],`피해 보정: ${skillScalingInfo(id)}\n기본 MP ${s.mana} / 쿨 ${s.cooldown/20}초\n${SKILL_NOTES[id]}\n사용 직업: ${owners.join('·')}\n피해 수치는 스탯·힘 버프·장비 보정 전입니다.`, 'data/skills.js · data/skillGuide.js');
 }
 for(const j of jobs){
  const publicPromotion=PUBLIC_JOBS.has(j.id);
  const trial=publicPromotion?JOB_TRIALS[j.id]:undefined,condition=trial?`레벨 ${trial.level}\n`+['all','any'].filter(k=>trial[k]).map(k=>trial[k].map(c=>`${c.label} ${c.need}`).join(k==='all'?' + ':' 또는 ')).join('\n'):'견습 시작 직업';
  const from=trial?.allowedFrom?.map(id=>JOBS[id].name).join('·')??(j.hidden&&j.parent===null?'아무 2차 이상 직업':JOBS[j.parent]?.name??'없음');
  const type=defaultDamageTypeFor({getDynamicProperty:()=>j.id});
  const special=!publicPromotion?'전직 방법·조건은 공개하지 않습니다.':j.id==='hacker'?'전직: 로토와 23회 대화 후 퀴즈 정답. 월드 최초 정답자 1명만 전직 가능. 직업·레벨 제한 없음.':`직전 직업: ${from}\n전직 조건: ${condition}`;
  const shrine=trial?.shrine?`\n전직 장소: 천체 신전의 ${trial.shrine==='sun'?'해 제단·낮':'달 제단·밤'} 4칸 안. /rpg:temple에서 위치 확인.`:'';
  const extra='';
  add('job:'+j.id,j.name,[j.id],`${special}${extra}${shrine}\n기본 피해 계열: ${type==='magic'?'마력(마법)':'근력(물리)'}. 개별 기술에 다른 피해 판정이 있으면 해당 판정을 따릅니다.\n보유 기술: ${j.skills.map(id=>SKILLS[id]?.name??id).join('·')||'시작 장비에 따라 사용'}\n${j.id==='chameleon'?LINE_NOTES.chameleon:''}`,'data/jobs.js · data/jobTrials.js · data/skillGuide.js');
 }
 for(const [id,r]of Object.entries(RUNES)){
  const recipe=CRAFTING_RECIPES.find(c=>c.id==='rpg:rune_'+id);
  add('rune:'+id,r.name,[r.name.replace('의 ',''),'rune_'+id],`등급: 일반~신화, 강화와 별개인 합성 승급. 힘·비전 룬은 +1부터 공용·직업 무기 근접 평타에도 추가 피해를 줍니다. 두 룬의 평타 추가 피해율은 합산합니다. 아래는 일반 등급 기준\n기본: ${runeEffects(upgradedRune(r,0))}\n최대 +${RUNE_MAX}: ${runeEffects(upgradedRune(r,RUNE_MAX))}\n/rpg:runes 보관함에서 장착해야 효과를 받습니다.\n${recipe?.text??'룬 드롭으로 획득'}`,'data/equipment.js · data/upgrades.js · data/crafting.js');
 }
 for(const [id,a]of Object.entries(ARMOR_SETS))add('armor:'+id,a.name+' 갑옷',[a.name,id,...(id==='abyssal'?['심연갑옷','상위갑옷','네더라이트이상']:[])],`${a.description}\n등급: 일반~신화. 부위당 등급 추가 HP ${ARMOR_GRADE_HP.join(' / ')}\n부위별 방어력: ${a.protection.join(' / ')}\n최대 강화 +${ARMOR_MAX}. 부위별 제작법은 /rpg:craft에서 확인하세요.`,'data/equipment.js · data/upgrades.js');
 for(const r of CRAFTING_RECIPES)add('craft:'+r.id,r.name+' 제작법',[r.name,r.id,r.name.replace('훈련용 ','').replace(' 소환',''),...(r.id==='rpg:stat_reset_scroll'?['스탯초기화']:[])],r.text,'data/crafting.js (실제 조합법에서 생성)');
 add('rule:offer','검과 책 바치기',['공물','바치기','검바치기','책바치기'], '/rpg:offer: 검과 책을 바칩니다. 인벤토리에서 현재 직업과 진행도에 맞게 소비합니다. 바친 아이템은 사라집니다. 효과부여 책은 시련과 마나 공물 중 현재 필요한 용도로 사용됩니다.','core/offer.js');
 add('rule:huntingzones','사냥 구역과 자연 출현',['사냥구역','초반사냥','중반사냥','후반사냥','몹스폰','몬스터출현'], '오버월드 X·Z 중 절댓값이 큰 좌표를 기준으로 초반 ±1500, 초반 밖 중반 ±4000, 중반 밖 후반 ±10000입니다. 경계는 안쪽 구역에 포함하고 10000 밖도 후반을 유지합니다. 밤에는 구역에 맞는 RPG 몬스터가 출현합니다. 바닐라 적대 몹 자연 출현은 동굴로 제한합니다. 사막 몬스터는 사막에서 밤낮·좌표 제한 없이 출현합니다.','data/huntingZones.js · spawn_rules');
 add('rule:rarity','아이템 등급·합성',['등급','아이템등급','무기등급','갑옷등급','룬등급','희귀도','합성','승급'],RARITIES.join(' → ')+'\n룬·RPG 갑옷·공용 무기 7종은 모두 일반~신화가 존재합니다. 같은 종류·같은 등급의 +5 이상 두 개를 /rpg:fuse에서 합성합니다. 성공하면 다음 등급 +0, 실패하면 두 장비를 보존하며 50% 확률로 주장비만 -1강. 둘 다 +10이면 성공률 100%. 신화는 최종 등급. 갑옷은 보호 IV 책 1권, 공용 무기는 날카로움 V 책 1권이 추가로 필요하고 성공·실패 모두 소모합니다. 룬은 책이 필요 없습니다.\n다음 등급 성공률: '+PROMOTION_RATES.join(' / ')+'%. 무기 기본 피해·룬 수치 효과 배율: '+GRADE_MULTIPLIERS.join(' / ')+'. 갑옷 부위당 추가 HP: '+ARMOR_GRADE_HP.join(' / ')+'. 직업 기본 무기는 등급·승급 없이 +10 강화만 가능하며, 강화 단계당 근접 피해 +1·물리/마법 스킬 피해 +2%. 고정 피해·회복량은 제외. 바닐라 장비는 제외.','data/grades.js · core/fusion.js');
 add('rule:armor','갑옷 종류·제작',['갑옷','방어구'],Object.values(ARMOR_SETS).map(a=>a.name+': '+a.description).join('\n')+'\n4부위를 같은 세트로 입어야 세트 효과를 받습니다. /rpg:craft에서 부위별 제작법, /rpg:upgrade에서 강화를 확인하세요.','data/equipment.js · data/crafting.js');
 add('rule:scalingjobs','근력·마력 직업 안내',['근력직업','마력직업','근력캐','마력캐','힘캐','마법직업'],['근력(물리) 기본 계열: '+jobs.filter(j=>j.id!=='apprentice'&&defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='physical').map(j=>j.name).join('·'),'마력(마법) 기본 계열: '+jobs.filter(j=>defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='magic').map(j=>j.name).join('·'),'직업 기본 계열과 개별 기술은 다를 수 있습니다. 풍압·용의 브레스는 마력, 달 계열 공격은 근력, 메테오드라이브/혈인은 혼합, 대미장식은 고정 피해입니다. 스킬명과 함께 물어보세요.'].join('\n'),'core/stats.js · data/skillScaling.js');
 add('rule:damage','피해 계산·힘 버프',['힘버프','힘효과','힘스킬','마법딜','고정피해','마법피해','피해계산'],`힘 효과는 물리·마법 스킬 피해를 단계당 ${CONFIG.skillDamage.strengthPerLevel*100}% 증가시킵니다. 힘 I +5%·II +10%·III +15%. 단타와 연타 총합에 같은 비율로 적용합니다. 이후 물리는 근력, 마법은 마력과 장비·룬 보정을 받습니다. 고정 피해는 유지합니다.\n무투가 기존 힘 계산 및 평타 배수에는 중복 적용하지 않습니다. 기본 평타의 힘 효과는 마인크래프트 엔진 규칙입니다.`,'core/stats.js · skills/fist.js');
 add('rule:transfer','갑옷 강화 이전',['강화이전','이전서','강화추출'],`/rpg:transfer에서 제작 전에 강화를 이전서로 추출하세요. 단계당 골드 500, 원래 갑옷은 +0. 새 RPG 갑옷을 만든 뒤 같은 부위에 100% 적용하며 이전서는 소모됩니다. 기존 단계보다 높은 이전서만 적용하며 합산하지 않습니다. 인챈트·내구도는 대상 장비 것을 유지합니다.`,'core/armorTransfer.js');
 add('rule:bosscc','보스 CC 저항',['보스cc','보스기절','보스빙결','보스둔화'],`커스텀 보스 4종·드래곤·위더·워든에게 기절·빙결·둔화·속박 1회 지속시간은 50%, 넉백·끌어당김 강도는 50%입니다. 일반 몬스터와 플레이어는 그대로입니다. 장판에서 CC를 다시 적용하는 동작은 유지하며, 피해·화상·독은 CC 감소 대상이 아닙니다.`,'core/crowdControl.js');
 add('rule:farm','좀벌레 보상',['좀벌레','좀벌레팜','공장'],`좀벌레는 XP 5, 골드 2, 강화석·룬 가루 0, 룬 확률 0.1%입니다. 일반 적과 다른 전용 보상을 적용합니다.`,'core/economy.js · core/runeDrops.js');
 add('rule:commonweapons','공용 전투 무기',['공용무기','무기제작','평타무기'],COMMON_WEAPONS.map(w=>w.name+': 추가 근접 피해 설정 '+w.damage+'·내구도 '+w.durability).join('\n')+'\n누구나 제작하는 평타용 무기입니다. 직업 스킬은 기존 전용 아이템으로 사용합니다. /rpg:craft에서 재료를 확인하세요.','data/commonWeapons.js · data/crafting.js');
 for(const w of COMMON_WEAPONS)add('weapon:'+w.key,w.name,[w.key,w.id],`공용 RPG 평타 무기. 일반~신화 합성 승급 가능, 최대 +10 강화(단계당 추가 근접 피해 +1) · 추가 근접 피해 설정 ${w.damage}·내구도 ${w.durability}. 직업 제한 없음. /rpg:craft에서 제작법을 확인하세요. 직업 스킬은 전용 아이템을 사용합니다.`,'data/commonWeapons.js');
 add('rule:stats','레벨·스탯',['스탯','근력','마력','지능','체력스탯','레벨업'],`자연 성장 최대 레벨 100, 레벨마다 SP 3. 근력·체력·마력 투자 상한 없음. 지능 최대 50이며 마나 소모 감소는 최대 40%.\n근력은 물리 피해, 마력은 마법 피해·회복량, 체력은 최대 HP입니다. /rpg:stats에서 분배합니다.`,'core/stats.js');
 add('rule:pvp','PvP·결투·PK',['pvp','피케이','결투','현상금','pk패널티'], '일반 PvP 허용. /rpg:pvp 또는 지원되는 환경의 /pvp로 신청하고 서로 수락하면 PvP장으로 이동하여 최대 HP로 회복 후 3초 뒤 결투 시작, 사망 시 패배합니다. 결투 전용 무적·체력 하한·피해 복구는 없으며 대기 중에도 피해를 받습니다. 결투 밖 플레이어 살인은 PK 표식. PK 플레이어를 죽이면 그 지갑에서 최대 50,000골드를 지급하고 새 PK가 되지 않습니다. 잔액만 지급하며 부족분은 생성하지 않습니다. PK는 플레이어에게 처치돼야 해제됩니다. 던전에서는 결투 불가.','core/pvp.js');
 add('rule:party','파티 경험치',['파티','경험치','쩔','xp'],`최대 4명. 같은 차원·처치자 ${CONFIG.partyXp.radius}칸 안·생존한 파티원은 각자 원래 XP의 ${percent(CONFIG.partyXp.multiplier)} 획득. 90 XP 몹이면 각자 ${90*CONFIG.partyXp.multiplier} XP.\n일반 마크 생물 10, 대부분 적대 몹 30, 좀벌레·좀비화 피글린 5 XP. 커스텀 몹/보스는 별도 값.\n전직 처치는 최근 30초 공격·탱킹·유효 회복에 기여한 같은 차원·시체 32칸 안 생존 파티원도 인정합니다.`,'config.js · data/mobXp.js · core/combatContribution.js');
 add('rule:runes','룬 획득·장착',['룬','룬획득','룬드랍','룬드롭','룬장착'],`일반 몬스터 1%·RPG 엘리트 3%·보스 30% 확률로 룬 드롭(좀벌레만 0.1%). 현재 룬 ${Object.values(RUNES).map(r=>r.name).join('·')}.\n/rpg:runes 전용 보관함 30칸, 장착 기본 3개·슬롯 강화로 최대 5개. 같은 종류는 하나만 장착. 원하는 룬은 /rpg:craft 제작법을 확인하세요.`,'core/runeDrops.js · loot_tables/rpg · core/runeInventory.js');
 const ar=enhancementRates('armor',ARMOR_MAX-1),rr=enhancementRates('rune',RUNE_MAX-1),ac=upgradeCost('armor',ARMOR_MAX-1),rc=upgradeCost('rune',RUNE_MAX-1);
 add('rule:classweapon','직업 기본 무기 강화',['직업무기강화','기본무기강화','직업무기등급'], '직업·견습 기본 무기 36종은 /rpg:upgrade에서 +10까지 강화합니다. 등급·승급은 없습니다. 강화당 근접 피해 +1, 그 무기를 들고 사용하는 물리·마법 스킬 피해 +2%(+10은 +20%). 고정 피해와 회복량은 증가하지 않습니다. 공용 무기와 같은 비용·실패·강등·파괴·촉매 규칙입니다. 카멜레온 무기 전환과 직업 무기 재지급·전직 시 강화 단계를 유지합니다.','data/classWeapons.js · core/upgrades.js');
 add('rule:upgrade','강화·촉매·재화',['강화','촉매','골드','강화석','룬가루'],`/rpg:upgrade에서 갑옷·공용·직업 무기 최대 +${ARMOR_MAX}, 룬 최대 +${RUNE_MAX}. 실패·강등·파괴에도 비용 소모.\n갑옷 마지막 단계: 골드 ${ac.gold}·강화석 ${ac.stone}, 성공 ${ar.success}% / 유지 ${ar.fail}% / 강등 ${ar.downgrade}% / 파괴 ${ar.destroy}%.\n룬 마지막 단계: 골드 ${rc.gold}·룬 가루 ${rc.dust}, 성공 ${rr.success}% / 유지 ${rr.fail}% / 강등 ${rr.downgrade}% / 파괴 ${rr.destroy}%.\n촉매는 갑옷·무기 +5·룬 +2부터 1회 최대 ${MAX_CATALYSTS}개, 1개당 성공 +9%p·파괴 -3%p(파괴 0% 하한). 최종 확률은 확인창에 표시.`,'data/upgrades.js');
 add('rule:monsterlevels','몬스터 레벨',['몬스터레벨','몹레벨','필드레벨','던전난이도'], 'RPG 몬스터 22종은 레벨에 따라 체력·공격·방어가 증가합니다. 초반 필드 Lv.1/5/10/15, 중반 Lv.20/30/40/55, 후반 Lv.70/90/115/145. 같은 종도 여러 레벨로 등장합니다. 10단계는 일반 Lv.145~220, 엘리트 Lv.220, 보스 Lv.260입니다. 무기·RPG 갑옷·장착 룬 전설 +10 수준의 4인 파티 권장선이며 장비 입장 제한은 없습니다. 고정 피해는 레벨 방어를 상쇄합니다.','data/monsterLevels.js');
 add('rule:dungeon','던전 입장·진행',['던전','던젼','보스제한시간','솔플','솔로보상','혼자던전'],`난이도 ${DUNGEON_TIERS.length}개. /rpg:dungeon에서 참가, /rpg:dungeonstart로 최대 ${DUNGEON.maxParty}명 출발. 혼자는 /rpg:dungeonsolo 1. 처음부터 혼자 출발하면 클리어 골드·강화석·룬 가루·촉매 1.5배(올림). 룬·보급품·처치 보상은 그대로입니다.\n파티는 일반 ${DUNGEON.normalCount}·엘리트 ${DUNGEON.eliteCount}마리를 ${DUNGEON.mobLimitMs/60000}분 안에 처치한 뒤 보스 1마리를 ${DUNGEON.bossLimitMs/60000}분 안에 잡습니다. 혼자 출발하면 전반 7분 30초·보스 4분 30초입니다. 몹이 없으면 후속 몹이 일찍 나옵니다. 전투 중 임의 퇴장 불가, 사망·완료·제한시간 종료로 귀환.\n종료 시 남은 아이템과 몹의 마크 XP를 피해+유효 회복 기여도에 따라 분배합니다. RPG 처치 XP는 기존 방식이며 가방 부족 전리품은 /rpg:dungeonloot로 받습니다.\n관리자 생성: /rpg:dungeoncreate 1 또는 all.`,'data/dungeons.js · core/dungeons.js');
 for(const d of DUNGEON_TIERS){const r=clearRewardForTier(d.tier),solo=clearRewardForTier(d.tier,true);add('dungeon:'+d.tier,`던전 ${d.tier} ${d.name}`,[d.name,'던전'+d.tier,d.tier+'번던전',d.tier+'단계던전',d.tier+'티어던전'],`난이도 ${d.tier}. 일반 Lv.${dungeonMonsterLevel(d.tier,'normal',0)}~${dungeonMonsterLevel(d.tier,'normal',2)}, 엘리트 Lv.${dungeonMonsterLevel(d.tier,'elite')}, 보스 Lv.${dungeonMonsterLevel(d.tier,'boss')}. 10단계는 전설 +10 세트 권장, 입장 제한 없음. 보스: ${bossName(d.boss)}.\n클리어 보상: 골드 ${r.gold}·강화석 ${r.stone}·룬 가루 ${r.dust}·촉매 ${r.catalysts}·룬 ${r.runes}개. 보급품 ${r.supplyMultiplier}배. 솔로 클리어는 골드 ${solo.gold}·강화석 ${solo.stone}·룬 가루 ${solo.dust}·촉매 ${solo.catalysts}입니다. 던전 엘리트는 다이아 1개 40%·3개 10%·없음 50%로 공동 전리품을 남깁니다. 클리어 시 네더라이트 주괴 1개 확률 ${Math.round(netheriteChanceForTier(d.tier)*100)}%(6~10단계 한정, 각자 추첨). 개별 몬스터 처치 재화는 별도.`,'data/dungeons.js');}
 add('rule:temple','해·달의 신전',['신전','해의신전','달의신전','천체신전'],'낮에는 해의 제단, 밤에는 달의 제단이 활성화되는 구조물입니다. 히든 직업의 전직 방법·조건은 안내하지 않습니다.','data/temple.js');
 add('rule:melee','추가 근접 피해 없는 기본 아이템',['근접피해없는직업','근접데미지없는직업','기본아이템피해'],`기본 아이템에 추가 근접 피해 설정이 없는 직업은 마법사·현자·궁수·천궁·성직자·천사·미카엘·타락천사입니다. 공격이 완전히 0인 뜻은 아니며 맨손 수준 기본 피해·힘·인챈트와 화살/스킬 피해는 별도입니다. 공용 전투검/전투창으로 근접 사냥을 보완할 수 있습니다.`,'items/*.json · data/jobs.js');
 add('rule:start','처음 시작',['초보','시작','처음','막혔','막힘'],`/rpg:guide의 견습 5계열 체험에서 시작 계열과 관계없이 검·마법·활·격투·회복 견습 장비를 바꿔 사용할 수 있습니다. 빵과 화살은 처음 한 번만 지급합니다. 첫 전직은 레벨 10과 각 직업 시련이 필요합니다. /rpg:jobs에서 현재 전직 조건, /rpg:craft에서 재료, /rpg:skillguide에서 기술을 확인하세요.`,'core/beginner.js · core/jobMenu.js');
 catalog=Object.freeze(entries);return catalog;
}
export function lookupRpgQuestion(question){
 const raw=String(question??'').trim();if(!raw)return {status:'empty',entries:[]};
 if(raw.length>QUESTION_LIMIT)return {status:'too_long',entries:[]};
 if(isBalanceQuestion(raw))return {status:'balance',entries:[]};
 if(isHiddenPromotionQuestion(raw))return {status:'hidden',entries:[]};
 const q=normalizeQuestion(raw);if(!q)return {status:'unknown',entries:[]};
 if(/전직(방법|조건|하는법|하려면|알려)|직업.*조건/.test(q)&&!Object.values(JOBS).some(j=>j.id!=='apprentice'&&q.includes(normalizeQuestion(j.name)))){return {status:'answer',entries:[{id:'rule:publicpromotions',title:'공개 전직 안내: 기본 직업 5종',body:knowledgeEntries().filter(e=>['job:swordsman','job:mage','job:archer','job:fighter','job:cleric'].includes(e.id)).map(e=>e.title+'\n'+e.body).join('\n\n'),source:'data/jobTrials.js'}],effect:true};}
 const named=knowledgeEntries().some(e=>e.id.startsWith('skill:')&&e.aliases.some(a=>q.includes(a)));
 const effect=!named&&effectKnowledge(q);if(effect)return {status:'answer',entries:[effect],effect:true};
 const ranked=knowledgeEntries().map(e=>({entry:e,score:Math.max(0,...e.aliases.filter(a=>q.includes(a)&&(!/[0-9]$/.test(a)||new RegExp(a+'(?![0-9])').test(q))).map(a=>a.length*10+(/등급|희귀도/.test(q)&&/^(weapon|armor|rune):/.test(e.id)?100:0)+(named&&/근력|마력|물리|마법|피해계열/.test(q)&&e.id.startsWith('skill:')?100:0)+(e.id.startsWith('skill:')?2:e.id.startsWith('rune:')?3:0)+(e.id.startsWith('craft:')&&/제작|만드|만들|조합|재료/.test(q)?5:0)))})).filter(e=>e.score>0).sort((a,b)=>b.score-a.score||a.entry.id.localeCompare(b.entry.id));
 return {status:ranked.length?'answer':'unknown',entries:ranked.slice(0,6).map(r=>r.entry)};
}
// Only canonical records may be rendered; remote services cannot inject answer text.
export function selectKnowledgeEntries(candidates,ids){
 if(!Array.isArray(ids)||ids.length>3||ids.some(id=>typeof id!=='string'))return undefined;
 const unique=[...new Set(ids)],selected=unique.map(id=>candidates.find(e=>e.id===id));
 return selected.some(e=>!e)?undefined:selected;
}
export function formatKnowledge(entries){
 if(!entries?.length)return UNKNOWN_ANSWER;
 return entries.slice(0,3).map(e=>`${e.title}\n${e.body}`).join('\n\n')+'\n\n자료: 이 애드온의 게임 도감 v0.5.78';
}

```

## RPG_BP_v0603/scripts/core/rulebook.js

```js
import {layoutRulebook} from '../data/rulebookLayout.js';
// 명령어 책 페이지는 v0.4.82의 실제 등록 명령어 목록을 기반으로 작성.
// ItemBookComponent는 @minecraft/server 2.2.0부터 지원.
import { ItemStack } from "@minecraft/server";

export const RULEBOOK_SECTIONS = [
  "§l§61. RPG 서버 종합 룰북§r\n\n일반 PvP가 허용됩니다. 결투는 /rpg:pvp 메뉴에서 신청하고 상대가 수락해야 합니다. 두 사람의 체력을 채운 뒤 3초 후 시작하며 사망 시 패배합니다. 결투 전용 무적·체력 하한·피해 복구는 없으며 대기 중에도 피해를 받습니다.\n\n결투 밖 살인은 PK 표식·현상금 패널티. 건축물 훼손·약탈은 하지 마세요. 던전·신전 보호는 유지합니다.",
  "§l§62. 목차§r\n\n기초 지식·사냥 구역\n시작 안내·전투 조작·공물\n전직·스탯·파티·길드\n재화·룬·갑옷·무기\n강화·촉매·등급·합성\n던전·신전·초기화 아이템\n정보 질문·서바이벌 명령어\n\n주제 번호순으로 정리했습니다.",
  "§l§63. 기초 지식§r\n\nRPG 경험치와 바닐라 초록 경험치바는 별개입니다.\n/rpg:stats에서 RPG 레벨·SP를 확인하세요.\n\nRPG 레벨이 오를 때 SP 3개를 받습니다. 자연 성장은 레벨 100까지입니다.\nHP 2는 하트 1칸입니다.",
  "§l§64. 사냥 구역 기준§r\n\n오버월드 X·Z 중 절댓값이 큰 좌표로 구분합니다. 높이 Y는 무관합니다.\n\n초반: -1,500~+1,500\n중반: 초반 밖, -4,000~+4,000\n후반: 중반 밖, -10,000~+10,000\n\n경계는 안쪽 구역. 1만 밖도 후반 몬스터가 계속 나옵니다.",
  "§l§65. 밤의 사냥§r\n\n밤에는 현재 사냥 구역에 맞는 RPG 몬스터가 나옵니다. 바깥 구역일수록 강한 적을 만나게 됩니다.\n\n초반: 버섯·초록 고블린\n중반: 빨강·황금 고블린·대장\n후반: 엘리트 버섯·고블린\n\n밤이 되어도 조명·공간·몹 수에 따라 출현량은 달라집니다.",
  "§l§66. 동굴과 사막§r\n\n바닐라 적대 몹은 오버월드 동굴에서 자연 출현합니다.\n\n사막에서는 밤낮과 사냥 구역 좌표에 상관없이 사막 몬스터가 나옵니다.\n전갈·사마귀·데스웜과 엘리트가 있으니 초반에도 주의하세요.\n\n동물은 먹거리와 목장 운영에 활용하세요.",
  "§l§67. 처음 시작하기§r\n\n/rpg:guide\n원할 때 시작 장비와 안내를 받습니다. 첫 접속에 계열 선택창은 자동으로 뜨지 않습니다.\n\n/rpg:guide의 견습 5계열 체험에서 시작 계열과 관계없이 장비를 바꿔 써보세요. 빵과 화살은 처음 한 번만 지급합니다. 첫 사냥 5마리를 완료하면 같은 안내창에서 보상을 받으세요.",
  "§l§68. 전투 조작§r\n\n직업 전용 아이템을 손에 들고 사용하세요. 웅크리면 다음 기술로 전환합니다.\n\n대부분 우클릭/아이템 사용으로 시전합니다. 활과 대상 지정 회복 등은 조작이 다릅니다.\n/rpg:skills에서 기술을 켜거나 끕니다.\n/rpg:skillguide에서 효과·MP·쿨타임을 확인하세요.",
  "§l§69. 검과 책을 바칩니다§r\n\n/rpg:offer\n\n인벤토리의 검과 효과부여 책을 현재 직업·진행도에 맞게 바칩니다. 바친 아이템은 소비됩니다.\n\n검사 기본 시련에는 다이아몬드 검을 사용합니다. 마법사 기본 시련에는 효과부여 책을 사용합니다.\n검은 시련 수량까지만 소비합니다. 책은 직업에 따라 마나 공물로도 사용됩니다.",
  "§l§610. 기본 직업과 정보§r\n\n검사·마법사·궁수·무투가·성직자가 기본 직업입니다. 첫 전직은 레벨 10과 직업별 시련이 필요합니다.\n\n/rpg:job <직업>\n전직을 요청합니다.\n/rpg:jobs\n직업 정보를 확인합니다.\n\n이 책에는 히든 직업의 전직 방법을 적지 않습니다.",
  "§l§611. 스탯과 마나§r\n\n근력: 물리 스킬 피해\n마력: 마법 스킬 피해·직접 회복\n체력: 최대 HP\n지능: 기술 MP 소모 감소\n\n지능 할인은 최대 40%입니다. 근력·마력·체력은 투자 상한이 없습니다.\n마법·성직 고마나 직업은 책 공물로 최대 마나를 늘릴 수 있습니다.",
  "§l§612. 파티 사냥§r\n\n/rpg:party · /rpg:invites\n파티를 만들고 초대를 수락하세요. 최대 4명입니다.\n\n같은 차원·처치자 32칸 안·생존 중인 파티원은 각자 원래 XP의 75%를 받습니다.\n예: 90 XP 몹 → 각자 67.5 XP.\n레벨 차이로 나눠 갖는 방식은 아닙니다.",
  "§l§613. 길드와 전직 기여§r\n\n/rpg:guild\n길드 생성·초대·관리를 합니다. 길드만 같다고 XP를 공유하지는 않습니다.\n\n전직용 처치는 최근 30초간 공격·탱킹·유효 회복에 기여한 파티원도 인정됩니다. 같은 차원·처치 위치 32칸·생존 조건을 충족해야 합니다.",
  "§l§614. 재화와 제작§r\n\n/rpg:wallet\n골드·강화석·룬 가루를 확인합니다.\n골드: 공통 강화 비용\n강화석: 갑옷·공용 무기 강화\n룬 가루: 룬 강화\n\n/rpg:craft\n실제 조합법과 획득법을 봅니다. 제작은 작업대에서 합니다.",
  "§l§615. 룬 획득§r\n\n일반 몬스터: 1%\n엘리트 몬스터: 3%\n보스 몬스터: 30%\n좀벌레: 0.1%\n\n드롭 룬은 바닥에 1개이며 파티원별로 복제되지 않습니다.\n원하는 룬은 /rpg:craft에서 재료를 확인해 제작할 수도 있습니다.",
  "§l§616. 룬 보관·장착§r\n\n/rpg:runes\n일반 가방의 룬을 전용 보관함에 넣고 장착하세요. 들고만 있어서는 효과를 받지 않습니다.\n\n보관 30칸·장착 기본 3개·슬롯 강화로 최대 5개. 같은 종류는 1개만 장착합니다.\n갑옷과 독립적입니다. 강화·승급 룬은 전용 보관함에서 관리합니다.",
  "§l§617. 힘·비전의 룬§r\n\n일반 등급 기준\n\n힘의 룬: 물리 스킬 피해 +10% → +10 강화 시 +30%.\n\n비전의 룬: 마법 스킬 피해 +10% → +10 강화 시 +30%.\n\n고정 피해에는 일반 피해 증가 보정이 적용되지 않습니다.",
  "§l§618. 샘·생명의 룬§r\n\n일반 등급 기준\n\n샘의 룬: 초당 최대 마나의 1% 추가 회복 → +10 강화 시 3%.\n\n생명의 룬: 최대 HP +4 → +10 강화 시 +24.\n실제 최대 HP는 기존 엔진 효과에 따라 4 HP 단위로 근사됩니다.",
  "§l§619. 수호·흡수의 룬§r\n\n일반 등급 기준\n\n수호의 룬: RPG 방어력 +4, 강화마다 +2. 일반 +10은 방어력 +24(룬 피해 감소 8.4%)와 기존 HP 보너스. 저항 효과는 부여하지 않습니다.\n\n흡수의 룬: 적에게 준 실제 피해의 5%를 HP로 회복 → +10에서 12%.\n받는 피해를 줄이는 룬이 아닙니다.",
  "§l§620. RPG 갑옷§r\n\n같은 종류의 갑옷 4부위를 착용해야 세트 효과를 받습니다.\n\n모험가: 물리 스킬 +8%\n숲 수호자: 최대 HP +8\n별빛 술사: 마법 스킬 +8%, 초당 MP +3\n심연 수호자: 최대 HP +16, 물리·마법 +8%, 저항 I\n\n/rpg:equipment에서 관리하세요.",
  "§l§621. 공용 무기 7종§r\n\n적월선\n마공학 검\n마공학 대검\n정예기사의 대검\n빙설의 대검\n화염의 대검\n마수의 도끼\n\n직업 제한 없이 제작하는 평타 무기입니다. 직업 기술은 기존 전용 아이템을 사용하세요. 제작법은 /rpg:craft.",
  "§l§622. 강화와 위험§r\n\n/rpg:upgrade\n착용 RPG 갑옷·손에 든 공용·직업 무기·보관함 룬을 최대 +10까지 강화합니다.\n\n성공·유지 실패·1단계 강등·파괴가 있습니다. 높은 단계일수록 위험합니다. 모든 완료된 시도에서 비용이 소비됩니다. 확인창을 읽고 진행하세요.",
  "§l§623. 촉매와 이전§r\n\n촉매는 한 번에 최대 5개. 개당 성공률 +9%p·파괴 확률 -3%p입니다. 강등·파괴를 제외한 확률 상한을 적용합니다.\n갑옷·무기 +5, 룬 +2부터 사용합니다.\n\n/rpg:transfer\n갑옷 강화는 제작 전에 이전서로 추출하세요. 같은 부위에 강화 단계만 이전하며 등급·인챈트는 옮기지 않습니다.",
  "§l§624. 장비 등급§r\n\n일반 → 레어 → 에픽 → 고대 → 영웅 → 전설 → 신화\n\n룬·RPG 갑옷·공용 무기에 각각 등급이 있습니다. 직업 전용 아이템은 등급·승급 없이 +10 강화만 가능합니다. 단계당 근접 피해 +1·물리/마법 스킬 +2%입니다.\n\n등급은 무기 기본 피해·룬 수치형 효과·갑옷 추가 HP에 영향을 줍니다. 일반 강화만으로 등급이 오르지는 않습니다.",
  "§l§625. 장비 합성§r\n\n/rpg:fuse\n같은 종류·같은 등급의 +5 이상 장비 두 개를 합성합니다. 갑옷은 세트·부위도 같아야 합니다.\n\n성공: 다음 등급 +0\n실패: 두 장비 보존, 50%로 주장비 -1강. 둘 다 +10이면 확정 승급\n\n갑옷은 보호 IV 책, 공용 무기는 날카로움 V 책 1권 추가. 성공·실패 모두 소모하며 룬은 제외합니다.\n\n승급 확률은 순서대로 90/85/80/75/70/60%. 신화가 최종 등급입니다.",
  "§l§626. 던전 입장§r\n\n/rpg:dungeon\n난이도 1~10 중 본인이 원하는 대기실에 참가합니다. 몬스터 레벨은 후반일수록 높습니다. 10단계는 무기·갑옷·장착 룬 전설 +10 세트 권장, 입장 제한 없음.\n/rpg:dungeonstart\n대기실 첫 참가자가 1~4명으로 출발합니다.\n/rpg:dungeonsolo <1~10>\n혼자 바로 출발합니다. 파티원을 자동으로 이동시키지 않습니다.",
  "§l§627. 던전 진행·실패§r\n\n일반 몬스터 50마리·엘리트 5마리를 5분 안에 잡으세요. 모두 잡으면 보스 1마리가 나옵니다. 보스는 등장 후 3분 제한입니다. 혼자 출발하면 일반·엘리트 7분 30초, 보스 4분 30초입니다.\n\n시간 초과·전원 사망이면 실패하며 내부 몹을 보상 없이 정리합니다. 전직관·GPT NPC는 보존됩니다.",
  "§l§628. 던전 귀환·보상§r\n\n종료 시 남은 아이템·몹의 마크 XP를 피해+유효 회복 기여도로 나눕니다. RPG 처치 XP는 기존 방식입니다.\n\n전투 중 임의로 나갈 수 없습니다. 경계 밖으로 이탈하면 복귀됩니다.\n/rpg:dungeonleave\n대기를 취소하거나 사망 후 귀환합니다.\n/rpg:dungeonloot\n가방 부족으로 보관된 보급품과 분배 전리품을 받습니다.\n\n처음부터 혼자 출발하면 주요 클리어 재화가 1.5배입니다.\n\n던전 엘리트 다이아: 1개 40%·3개 10%·없음 50%(공동 전리품).\n6~10단계 클리어: 각자 네더라이트 주괴 1개를 10/15/20/25/30% 확률로 받습니다.",
  "§l§629. 신전·구조물 보호§r\n\n낮에는 해의 제단, 밤에는 달의 제단이 활성화됩니다.\n/rpg:temple\n신전의 위치와 현재 상태를 확인합니다.\n\n등록된 던전·신전은 채굴·폭발·블록 변형으로부터 보호됩니다. 제단과 전직관을 사용하는 것은 가능합니다.",
  "§l§630. 성장 초기화 아이템§r\n\n스탯 초기화 주문서: 배분한 스탯 SP를 되돌립니다.\n전직 포기각서: 현재 직업을 포기하고 견습으로 돌아갑니다.\n\n제작법은 /rpg:craft. 사용 확인창을 읽으세요. 전직 포기는 기술 구성을 바꾸지만 레벨·재화·장비를 삭제하지 않습니다.",
  "§l§631. 정보 질문과 도감§r\n\n/rpg:ask <질문>\n또는 GPT NPC와 대화하세요.\n기술 효과·물리/마법 판정·제작·룬·던전 정보를 안내합니다.\n\n밸런스 순위·사기 직업 평가는 하지 않습니다. 전직 방법 안내는 기본 5직업만 제공합니다.\n/rpg:skillguide: 기술 상세 도감",
  "§l§632. 서바이벌 명령어 1§r\n\n/rpg:guide 시작 안내\n/rpg:status 내 상태\n/rpg:stats 스탯 배분\n/rpg:skills 기술 켜기/끄기\n/rpg:offer 검과 책을 바칩니다\n/rpg:craft 제작·획득 도감\n/rpg:wallet 지갑\n/rpg:equipment 장비 메뉴\n/rpg:runes 룬 보관·장착",
  "§l§633. 서바이벌 명령어 2§r\n\n/rpg:upgrade 강화\n/rpg:fuse 등급 합성\n/rpg:transfer 갑옷 강화 이전\n/rpg:party 파티\n/rpg:guild 길드\n/rpg:invites 초대 확인\n/rpg:dungeon 던전\n/rpg:temple 신전 정보\n/rpg:rulebook 이 책 다시 받기",
  "§l§634. 직업 전용 기능§r\n\n/rpg:skillbook: 카멜레온 학습·분해·횟수 충전\n/rpg:learn <스킬ID>: 학습\n/rpg:swap: 카멜레온 무기 전환\n/rpg:wings: 날개 전환\n/rpg:wingcheck: 날개 상태\n/rpg:wingrefresh: 날개 재장착\n/rpg:fistcheck: 격투 상태\n\n해당 직업·기능을 보유해야 사용할 수 있습니다.",
  "§l§635. 안내를 다시 볼 때§r\n\nRPG v0.5.78 PvP·PK 서버용\n\n/rpg:rulebook으로 최신 종합 룰북을 다시 받으세요. 업데이트 전의 책은 옛 내용이 남아 있습니다.\n\n기술 사용이 막히면 직업 아이템·켜 둔 기술·MP·쿨타임을 먼저 확인하세요. 막힌 내용은 /rpg:ask로 질문할 수 있습니다.",
  "§l§636. 결투·PK 상세§r\n\n/rpg:pvp 신청·수락·항복\n서로 동의한 결투는 사망·아이템·XP 손실 없이 끝납니다. 던전 진행 중에는 결투 불가.\n\nPK 상태 플레이어를 죽이면 상대 지갑에서 최대 50,000골드를 받으며 추가 PK가 되지 않습니다. 잔액이 부족하면 있는 만큼만 지급합니다. PK는 플레이어에게 처치되면 해제되며 환경 사망·재접속으로 지워지지 않습니다."
];

export const RULEBOOK_PAGES=layoutRulebook(RULEBOOK_SECTIONS);

export function giveRulebook(player) {
  try {
    const book = new ItemStack("minecraft:writable_book", 1);
    const pages = book.getComponent("minecraft:book");
    if (!pages || typeof pages.setContents !== "function") {
      player.sendMessage("§c[RPG] 책 페이지 API가 없는 버전입니다. @minecraft/server 2.2.0 이상을 사용하세요.");
      return false;
    }
    pages.setContents(RULEBOOK_PAGES);
    if(typeof pages.signBook==="function")pages.signBook("RPG 서버 종합 룰북","RPG 서버");
    book.nameTag = "§6RPG 서버 종합 룰북";
    book.setLore(["§7서바이벌·성장·룬·던전 · " + RULEBOOK_PAGES.length + "쪽", "§7/rulebook 또는 /rpg:rulebook"]);
    const inventory = player.getComponent("minecraft:inventory")?.container;
    if (!inventory) {
      player.sendMessage("§c[RPG] 인벤토리를 찾지 못했습니다.");
      return false;
    }
    const leftover = inventory.addItem(book);
    if (leftover) {
      // 가방이 꽉 차도 책이 사라지지 않게 플레이어 발밑에 드롭합니다.
      const loc = player.location;
      player.dimension.spawnItem(leftover, { x: loc.x, y: loc.y + 0.5, z: loc.z });
      player.sendMessage("§e[RPG] 인벤토리가 가득 차서 명령어 책이 발밑에 떨어졌습니다.");
    } else {
      player.sendMessage("§a[RPG] 'RPG 서버 종합 룰북'을 받았습니다! (" + RULEBOOK_PAGES.length + "쪽)");
    }
    return true;
  } catch (error) {
    player.sendMessage("§c[RPG] 안내서 지급 실패: " + String(error));
    return false;
  }
}

```

## RPG_BP_v0603/scripts/core/social.js

```js
import { world, system } from "@minecraft/server";
import {duelOpponents} from './pvp.js';
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";

// RPG 길드·파티: 길드/파티는 월드 동적 속성에 보관하여 재접속 후에도 유지.
// 초대장은 최대 2분 동안만 유효하며, 받는 사람의 수락이 있어야 가입됩니다.
const STORE = "rpg:social_v1";
const GROUP_TYPES = ["guild", "party"];
const PREFIX = { guild: "rpg_guild_", party: "rpg_party_" };
const LIMIT = { guild: 30, party: 4 };
const EXPIRES = 2400;
const invites = new Map();
const menus = new Set();
let db;

async function showForm(form, player) {
  for (let i=0; i<16; i++) {
    const res = await form.show(player);
    if (!res.canceled || String(res.cancelationReason) !== "UserBusy") return res;
    await new Promise(resolve => system.runTimeout(resolve, 10));
  }
  return undefined;
}
const nameKey = (s) => String(s ?? "").toLowerCase();
const online = () => world.getAllPlayers();
const byName = (name) => online().find(p => nameKey(p.name) === nameKey(name));
const caption = (type) => type === "guild" ? "길드" : "파티";

function state() {
  if (db) return db;
  let saved;
  try { saved = world.getDynamicProperty(STORE); } catch {}
  try {
    const parsed = typeof saved === "string" ? JSON.parse(saved) : null;
    if (parsed && Array.isArray(parsed.guilds) && Array.isArray(parsed.parties) && Number.isFinite(parsed.nextId)) {
      db = parsed;
    }
  } catch {}
  if (!db) db = { version: 1, nextId: 1, guilds: [], parties: [] };
  return db;
}
function groups(data, type) { return type === "guild" ? data.guilds : data.parties; }
function memberOf(data, type, name) {
  return groups(data, type).find(g => g.members.some(n => nameKey(n) === nameKey(name)));
}
function mutate(fn, player) {
  try {
    const next = JSON.parse(JSON.stringify(state()));
    const outcome = fn(next);
    if (outcome !== true) {
      if (typeof outcome === "string" && player) player.sendMessage(`§c${outcome}`);
      return false;
    }
    const encoded = JSON.stringify(next);
    if (encoded.length > 30000) {
      player?.sendMessage("§c길드·파티 저장 용량이 가득 찼습니다.");
      return false;
    }
    world.setDynamicProperty(STORE, encoded);
    db = next;
    syncAllTags();
    return true;
  } catch (error) {
    console.warn(`[RPG social] 저장 실패: ${error}`);
    player?.sendMessage("§c길드·파티 정보 저장에 실패했습니다.");
    return false;
  }
}
function notifyMembers(type, id, message) {
  const g = groups(state(), type).find(item => item.id === id);
  if (!g) return;
  for (const name of g.members) {
    const p = byName(name);
    try { p?.sendMessage(message); } catch {}
  }
}

function syncPlayerTags(player) {
  try {
    const data = state();
    for (const type of GROUP_TYPES) {
      const g = memberOf(data, type, player.name);
      const wanted = g ? `${PREFIX[type]}${g.id}` : null;
      for (const tag of player.getTags()) {
        if (tag.startsWith(PREFIX[type]) && tag !== wanted) player.removeTag(tag);
      }
      if (wanted && !player.hasTag(wanted)) player.addTag(wanted);
    }
  } catch {}
}
function syncAllTags() { for (const p of online()) syncPlayerTags(p); }

// 수동으로 설정된 rpg_team_* 태그도 기존처럼 아군으로 간주합니다.
export function areAllies(source, other) {
  if (!source || !other) return false;
  if (source.id === other.id) return true;
  if (source.typeId !== "minecraft:player" || other.typeId !== "minecraft:player") return false;
  if(duelOpponents(source,other))return false;
  try {
    return source.getTags().some(tag =>
      (tag.startsWith("rpg_guild_") || tag.startsWith("rpg_party_") || tag.startsWith("rpg_team_")) && other.hasTag(tag));
  } catch { return false; }
}

// Resolve actual party membership from saved data, not guild/team tags.
// A guild alone never shares kill XP. Offline members are not recipients.
export function partyMembership(player) {
  const party = memberOf(state(), 'party', player.name);
  if (!party) return {inParty:false, members:[player]};
  // Older saves may have 5–8 members. Keep their roster intact, but only the
  // leader and the first three other members share XP until the roster shrinks.
  const activeNames = [party.leader, ...party.members.filter(n => nameKey(n) !== nameKey(party.leader))].slice(0, LIMIT.party);
  if (!activeNames.some(n => nameKey(n) === nameKey(player.name))) return {inParty:true, members:[]};
  const names = new Set(activeNames.map(nameKey));
  return {inParty:true, members:online().filter(p => names.has(nameKey(p.name)))};
}

export function enforcePartyLimit() {
  if (!state().parties.some(p => p.members.length > LIMIT.party)) return true;
  const removed = [];
  const ok = mutate(data => {
    for (const party of data.parties) {
      if (party.members.length <= LIMIT.party) continue;
      const keep = [party.leader, ...party.members.filter(n => nameKey(n) !== nameKey(party.leader))].slice(0, LIMIT.party);
      removed.push(...party.members.filter(n => !keep.some(k => nameKey(k) === nameKey(n))));
      party.members = keep;
    }
    return true;
  });
  if (ok) for (const name of removed) try { byName(name)?.sendMessage('§e[RPG] 파티 정원이 4명으로 변경되어 기존 파티에서 탈퇴 처리되었습니다. 새 파티에 가입할 수 있습니다.'); } catch {}
  return ok;
}

function incoming(player) {
  const key = nameKey(player.name);
  const now = system.currentTick;
  const list = (invites.get(key) ?? []).filter(x => x.expires > now);
  if (list.length) invites.set(key, list); else invites.delete(key);
  return list;
}
function removeInvitation(player, invite) {
  const key = nameKey(player.name);
  const next = incoming(player).filter(i => i !== invite);
  if (next.length) invites.set(key, next); else invites.delete(key);
}
function clearGroupInvites(type, id) {
  for (const [key, list] of invites) {
    const rest = list.filter(i => i.type !== type || i.id !== id);
    if (rest.length) invites.set(key, rest); else invites.delete(key);
  }
}
function sendInvite(sender, target, type) {
  const g = memberOf(state(), type, sender.name);
  if (!g || nameKey(g.leader) !== nameKey(sender.name)) {
    sender.sendMessage(`§c${caption(type)}장만 초대할 수 있습니다.`); return;
  }
  if (memberOf(state(), type, target.name)) {
    sender.sendMessage(`§c${target.name}님은 이미 ${caption(type)}에 소속되어 있습니다.`); return;
  }
  if (nameKey(sender.name) === nameKey(target.name)) return;
  const key = nameKey(target.name);
  const curr = incoming(target).filter(i => i.type !== type);
  curr.push({ type, id: g.id, inviter: sender.name, expires: system.currentTick + EXPIRES });
  invites.set(key, curr);
  sender.sendMessage(`§a${target.name}님에게 ${caption(type)} 초대를 보냈습니다. (2분 유효)`);
  target.sendMessage(`§e${sender.name}님의 ${caption(type)} 초대가 왔습니다! §f/rpg:invites §7또는 /rpg:${type}에서 수락할 수 있습니다.`);
  system.runTimeout(() => { if (target.isValid && !menus.has(target.id)) showInviteNotice(target); }, 15);
}
async function showInviteNotice(target) {
  try {
    const list = incoming(target);
    if (!list.length) return;
    const form = new MessageFormData().title("RPG 그룹 초대")
      .body(`${list[0].inviter}님에게서 ${caption(list[0].type)} 초대가 왔습니다.\n받은 초대함에서 수락하거나 거절할 수 있습니다.`)
      .button1("나중에")
      .button2("초대 확인");
    // 다른 게임 메뉴를 가리지 않도록 자동 팝업은 한 번만 시도합니다.
    const result = await form.show(target);
    if (!result.canceled && result.selection === 1) openInvites(target);
  } catch {}
}
function approve(player, invite, accept) {
  removeInvitation(player, invite);
  if (!accept) {
    player.sendMessage("§7초대를 거절했습니다."); return;
  }
  let joinedId = null;
  if (!mutate(data => {
    const g = groups(data, invite.type).find(v => v.id === invite.id);
    if (!g) return "초대한 그룹이 사라졌습니다.";
    if (memberOf(data, invite.type, player.name)) return `이미 다른 ${caption(invite.type)}에 소속되어 있습니다.`;
    if (g.members.length >= LIMIT[invite.type]) return "그룹 정원이 가득 찼습니다.";
    g.members.push(player.name);
    joinedId = g.id;
    return true;
  }, player)) return;
  player.sendMessage(`§a${caption(invite.type)} 가입에 성공했습니다.`);
  notifyMembers(invite.type, joinedId, `§b[${caption(invite.type)}] §f${player.name}님이 가입했습니다.`);
}

async function openInvitesView(player) {
  const list = incoming(player);
  const form = new ActionFormData().title("받은 초대");
  if (!list.length) {
    form.body("현재 받은 초대가 없습니다.").button("돌아가기");
    await showForm(form, player); return;
  }
  form.body("초대를 선택하여 수락하거나 거절하세요. (2분 후 자동 만료)");
  for (const item of list) form.button(`${caption(item.type)} · ${item.inviter}`);
  form.button("뒤로");
  const r = await showForm(form, player);
  if (!r || r.canceled || r.selection >= list.length) return;
  const item = list[r.selection];
  if (!incoming(player).includes(item)) { player.sendMessage("§7초대가 만료되었습니다."); return; }
  const g = groups(state(), item.type).find(v => v.id === item.id);
  if (!g) { removeInvitation(player, item); player.sendMessage("§7초대한 그룹이 존재하지 않습니다."); return; }
  const choice = await showForm(new MessageFormData().title("초대 응답")
    .body(`${item.inviter}님의 ${caption(item.type)} 초대에 응하시겠습니까?\n${item.type === "guild" ? g.name : g.leader + "님의 파티"}`)
    .button1("거절")
    .button2("수락"), player);
  if (!choice || choice.canceled) return;
  if (!incoming(player).includes(item)) { player.sendMessage("§7초대가 만료되었습니다."); return; }
  approve(player, item, choice.selection === 1);
}
export function openInvites(player) { return openMenu(player, "invites"); }

async function makeGuild(player) {
  if (memberOf(state(), "guild", player.name)) return;
  const form = new ModalFormData().title("길드 창설")
    .textField("길드 이름 (2~16자)", "예: 달빛기사단")
    .submitButton("길드 생성");
  const r = await showForm(form, player);
  if (!r || r.canceled) return;
  const name = String(r.formValues?.[0] ?? "").trim();
  if (name.length < 2 || name.length > 16 || /[§\r\n\t]/.test(name)) {
    player.sendMessage("§c길드 이름은 2~16자이며 줄바꿈·색상 코드는 사용할 수 없습니다."); return;
  }
  if (mutate(data => {
    if (memberOf(data, "guild", player.name)) return "이미 길드에 가입했습니다.";
    if (data.guilds.some(g => nameKey(g.name) === nameKey(name))) return "이미 사용 중인 길드 이름입니다.";
    data.guilds.push({ id: data.nextId++, name, leader: player.name, members: [player.name] });
    return true;
  }, player)) player.sendMessage(`§a길드 [${name}] 생성 완료!`);
}
function makeParty(player) {
  if (mutate(data => {
    if (memberOf(data, "party", player.name)) return "이미 파티에 가입했습니다.";
    data.parties.push({ id: data.nextId++, leader: player.name, members: [player.name] });
    return true;
  }, player)) player.sendMessage("§a파티를 만들었습니다. 파티 메뉴에서 다른 플레이어를 초대하세요.");
}

async function choosePlayer(player, type, action) {
  const group = memberOf(state(), type, player.name);
  if (!group || nameKey(group.leader) !== nameKey(player.name)) return;
  let candidates;
  if (action === "invite") candidates = online().filter(p => nameKey(p.name) !== nameKey(player.name) && !memberOf(state(), type, p.name));
  else candidates = group.members.filter(n => nameKey(n) !== nameKey(player.name));
  if (!candidates.length) { player.sendMessage(action === "invite" ? "§7초대할 수 있는 접속 중인 플레이어가 없습니다." : "§7다른 멤버가 없습니다."); return; }
  const names = candidates.map(p => typeof p === "string" ? p : p.name);
  const title = action === "invite" ? `${caption(type)}에 초대` : action === "kick" ? "멤버 추방" : "그룹장 위임";
  const form = new ActionFormData().title(title).body("대상 플레이어를 선택하세요.");
  names.forEach(n => form.button(n)); form.button("취소");
  const res = await showForm(form, player);
  if (!res || res.canceled || res.selection >= names.length) return;
  const name = names[res.selection];
  const current = memberOf(state(), type, player.name);
  if (!current || nameKey(current.leader) !== nameKey(player.name)) return;
  if (action === "invite") {
    const target = byName(name);
    if (!target) { player.sendMessage("§c플레이어가 접속을 종료했습니다."); return; }
    sendInvite(player, target, type);
    return;
  }
  const success = mutate(data => {
    const g = memberOf(data, type, player.name);
    if (!g || nameKey(g.leader) !== nameKey(player.name)) return "권한이 없습니다.";
    if (!g.members.some(n => nameKey(n) === nameKey(name))) return "더 이상 그룹원이 아닙니다.";
    if (action === "kick") g.members = g.members.filter(n => nameKey(n) !== nameKey(name));
    else if (action === "transfer") g.leader = g.members.find(n => nameKey(n) === nameKey(name));
    return true;
  }, player);
  if (success) {
    player.sendMessage(action === "kick" ? `§e${name}님을 추방했습니다.` : `§a그룹장을 ${name}님에게 위임했습니다.`);
    if (action === "kick") byName(name)?.sendMessage(`§c${caption(type)}에서 추방되었습니다.`);
    const g = memberOf(state(), type, player.name);
    if (g) notifyMembers(type, g.id, `§b[${caption(type)}] §f${name}님 ${action === "kick" ? "추방" : "그룹장 위임"}`);
  }
}
function leaveGroup(player, type, disband) {
  const group = memberOf(state(), type, player.name);
  if (!group) return;
  const id = group.id;
  const memberNames = [...group.members];
  const success = mutate(data => {
    const list = groups(data, type);
    const index = list.findIndex(g => g.id === id);
    if (index < 0) return "그룹을 찾을 수 없습니다.";
    const g = list[index];
    const isLeader = nameKey(g.leader) === nameKey(player.name);
    if (disband) {
      if (!isLeader) return "그룹장만 해산할 수 있습니다.";
      list.splice(index, 1);
    } else {
      if (isLeader && type === "guild" && g.members.length > 1) return "길드장을 다른 멤버에게 위임한 후 탈퇴할 수 있습니다.";
      g.members = g.members.filter(n => nameKey(n) !== nameKey(player.name));
      if (!g.members.length) list.splice(index, 1);
      else if (isLeader) g.leader = g.members[0];
    }
    return true;
  }, player);
  if (!success) return;
  if (disband) {
    clearGroupInvites(type, id);
    for (const n of memberNames) byName(n)?.sendMessage(`§e${caption(type)}가 해산되었습니다.`);
  } else {
    player.sendMessage(`§7${caption(type)}에서 탈퇴했습니다.`);
    notifyMembers(type, id, `§b[${caption(type)}] §f${player.name}님이 탈퇴했습니다.`);
  }
}
async function confirmLeave(player, type, disband) {
  const res = await showForm(new MessageFormData().title(`${caption(type)} ${disband ? "해산" : "탈퇴"}`)
    .body(disband ? "그룹이 해산되고 모든 멤버가 제거됩니다. 계속하시겠습니까?" : `${caption(type)}에서 탈퇴하시겠습니까?`)
    .button1("취소").button2("확인"), player);
  if (res && !res.canceled && res.selection === 1) leaveGroup(player, type, disband);
}
async function showMembers(player, type) {
  const g = memberOf(state(), type, player.name);
  if (!g) return;
  const text = g.members.map(n => `${nameKey(n) === nameKey(g.leader) ? "§6[장]§r " : ""}${n} ${byName(n) ? "§a접속" : "§7오프라인"}`).join("\n");
  await showForm(new ActionFormData().title(`${caption(type)} 멤버`).body(text).button("뒤로"), player);
}
async function groupPage(player, type) {
  const g = memberOf(state(), type, player.name);
  const heading = caption(type);
  const form = new ActionFormData().title(`RPG ${heading}`);
  const actions = [];
  const add = (label, fn) => { form.button(label); actions.push(fn); };
  if (!g) {
    form.body(`${heading}에 소속되어 있지 않습니다.`);
    add(type === "guild" ? "길드 만들기" : "파티 만들기", () => type === "guild" ? makeGuild(player) : makeParty(player));
  } else {
    form.body(`${type === "guild" ? `§b${g.name}` : `${g.leader}님의 파티`} §7(${g.members.length}/${LIMIT[type]})\n그룹장: ${g.leader}`);
    if (type === 'party' && g.members.length > LIMIT.party) form.body(`${g.leader}님의 파티 (${g.members.length}/4)\n§e구버전 파티입니다. 리더와 명단 앞 3명만 경험치를 공유합니다.\n리더가 멤버를 정리해 4명 이하로 맞춰 주세요.`);
    add("멤버 보기", () => showMembers(player, type));
    if (nameKey(g.leader) === nameKey(player.name)) {
      add("플레이어 초대", () => choosePlayer(player, type, "invite"));
      add("멤버 추방", () => choosePlayer(player, type, "kick"));
      add("그룹장 위임", () => choosePlayer(player, type, "transfer"));
      add(`${heading} 해산`, () => confirmLeave(player, type, true));
    }
    add(`${heading} 탈퇴`, () => confirmLeave(player, type, false));
  }
  add("받은 초대", () => openInvitesView(player));
  add("닫기", () => "close");
  const r = await showForm(form, player);
  if (!r || r.canceled || r.selection >= actions.length) return "close";
  return actions[r.selection]();
}
async function openMenu(player, initialType) {
  if (menus.has(player.id)) { player.sendMessage("§7이미 길드·파티 창이 열려 있습니다."); return; }
  menus.add(player.id);
  try {
    if (initialType === "invites") { await openInvitesView(player); return; }
    for (let i=0; i<20 && player.isValid; i++) {
      const result = await groupPage(player, initialType);
      if (result === "close") break;
    }
  } catch (e) { console.warn(`[RPG social] UI 오류: ${e}`); }
  finally { menus.delete(player.id); }
}
export function openGuildMenu(player) { return openMenu(player, "guild"); }
export function openPartyMenu(player) { return openMenu(player, "party"); }

export function registerSocial() {
  // 최초 로드와 재접속 때 길드/파티 태그 재부착
  system.run(() => { state(); enforcePartyLimit(); syncAllTags(); });
  world.afterEvents.playerSpawn.subscribe(event => system.runTimeout(() => {
    if (event.player.isValid) syncPlayerTags(event.player);
  }, 30));
  system.runInterval(() => {
    try { syncAllTags(); for (const p of online()) incoming(p); }
    catch {}
  }, 200);
}

export function partyLeaderName(player){return memberOf(state(),"party",player.name)?.leader??player.name;}

```

## RPG_BP_v0603/scripts/core/util.js

```js
import {deferStoppedDamage} from './timeStopDamage.js';
import {setCombatHealth} from './combatContext.js';
import {applyStatus,ccScale} from './crowdControl.js';
import {monsterDefenseMultiplier} from '../data/monsterLevels.js';
import {scriptedHit,noteManualDamage,rememberScriptKiller} from './combatContext.js';
import { EntityDamageCause, EquipmentSlot } from "@minecraft/server";
import { hasPiercing } from "./piercing.js";
import { CONFIG } from "../config.js";
import { areAllies } from "./social.js";
import { skillDamageFor, defaultDamageTypeFor } from "./stats.js";

// 아이템/경험치 구슬 같은 것은 대상에서 제외합니다.
const EXCLUDE_TYPES = ["rpg:dungeon_loot_cache", "rpg:gpt_guide","minecraft:item", "minecraft:xp_orb", "minecraft:armor_stand", "rpg:moon_chakram_projectile", "rpg:moon_weapon_chakram", "rpg:tech_prison_dome"];

export function healthAlive(entity) {
  try {
    const hp = entity.getComponent("minecraft:health");
    return !!hp && hp.currentValue > 0;
  } catch {
    return false;
  }
}

// center 주변 radius 블록 안의 공격 가능한 엔티티 목록.
// 엔티티 위치는 발밑 기준이라, 눈높이로 날아가는 투사체처럼 center 가 몸 높이일 때는
// bodyOffset(보통 0.9)을 줘서 몸 중심 기준으로 거리를 잽니다.
export function getTargets(source, center, radius, bodyOffset = 0) {
  const out = [];
  let list = [];
  try {
    list = source.dimension.getEntities({
      location: { x: center.x, y: center.y - bodyOffset, z: center.z },
      maxDistance: radius,
      excludeTypes: EXCLUDE_TYPES,
    });
  } catch {
    return out;
  }
  for (const e of list) {
    try {
      if (e.typeId === "rpg:gpt_guide" || e.id === source.id || areAllies(source, e)) continue;
      if (!CONFIG.pvp && e.typeId === "minecraft:player") continue;
      if (!healthAlive(e)) continue;
      out.push(e);
    } catch {
      // 사라진 엔티티는 무시
    }
  }
  return out;
}

export function hurt(target,source,amount,type="auto",options){return scriptedHit(target,source,()=>hurtCore(target,source,amount,type,options));}
function hurtCore(target, source, amount, type = "auto", options) {
  if (target?.typeId==="rpg:gpt_guide"||areAllies(source, target)) return false;
  if (!CONFIG.pvp && target?.typeId === "minecraft:player") return false;
  const finalDamage=skillDamageFor(source, amount, type === "auto" ? defaultDamageTypeFor(source) : type, options);
  if(deferStoppedDamage(target,source,finalDamage))return true;
  const defense=monsterDefenseMultiplier(target),engineDamage=type==='fixed'?finalDamage/defense:finalDamage;
  const directDamage=type==='fixed'?finalDamage:finalDamage*defense;
  if(hasPiercing(source)||options?.ignoreInvulnerability){
    // override is used for 3 seconds only. Fallback handles damage immunity
    // when an engine still rejects repeated hits via applyDamage.
    try{
      if(target.applyDamage(engineDamage,{cause:EntityDamageCause.override,damagingEntity:source})) return true;
    }catch{}
    try{
      const hp=target.getComponent("minecraft:health");
      if(hp && hp.currentValue>0){
        const before=hp.currentValue;if(directDamage>=before)rememberScriptKiller(source,target);setCombatHealth(target,source,hp,Math.max(0,before-directDamage));noteManualDamage(source,target,Math.min(before,directDamage));
        return true;
      }
    }catch{}
    return false;
  }
  try {
    return target.applyDamage(engineDamage,{
      cause: EntityDamageCause.entityAttack,
      damagingEntity: source,
    }) !== false;
  } catch {
    return false;
  }
}

// 버전에 따라 applyKnockback 인자 형태가 달라서 두 가지를 모두 시도합니다.
export function knockback(entity, dirX, dirZ, strength, vertical = 0.35) {
  strength*=ccScale(entity);vertical*=ccScale(entity);
  const len = Math.hypot(dirX, dirZ) || 1;
  const x = dirX / len;
  const z = dirZ / len;
  try {
    entity.applyKnockback({ x: x * strength, z: z * strength }, vertical);
    return;
  } catch {
    // 구버전 형태로 재시도
  }
  try {
    entity.applyKnockback(x, z, strength, vertical);
  } catch {
    // 밀 수 없는 대상
  }
}

// 엔티티에 불 붙이기. 블록/바닥에는 불이 붙지 않습니다.
export function burn(entity, seconds) {
  if (!CONFIG.igniteEntities) return;
  try {
    entity.setOnFire(seconds, true);
  } catch {
    // 불 붙일 수 없는 대상
  }
}

export function slow(entity, amplifier, ticks) {
  try {
    applyStatus(entity,"slowness", ticks, { amplifier, showParticles: true });
  } catch {
    // 효과를 받을 수 없는 대상
  }
}

export function push(entity, x, y, z) {
  const scale=ccScale(entity);x*=scale;y*=scale;z*=scale;
  try {
    entity.applyImpulse({ x, y, z });
  } catch {
    // 플레이어 등 impulse 불가 대상
  }
}

export function particle(dimension, id, pos) {
  try {
    dimension.spawnParticle(id, pos);
  } catch {
    // 없는 파티클 id 등은 무시
  }
}

export function sound(dimension, id, pos, options = { volume: 1, pitch: 1 }) {
  try {
    dimension.playSound(id, pos, options);
  } catch {
    // 없는 사운드 id 등은 무시
  }
}

// 시선의 수평 방향 (위/아래를 봐도 앞쪽으로 나가도록)
export function flatDir(player) {
  const v = player.getViewDirection();
  const len = Math.hypot(v.x, v.z);
  if (len < 0.001) {
    const yaw = (player.getRotation().y * Math.PI) / 180;
    return { x: -Math.sin(yaw), z: Math.cos(yaw) };
  }
  return { x: v.x / len, z: v.z / len };
}

export function isSolidAt(dimension, pos) {
  try {
    const b = dimension.getBlock(pos);
    if (!b) return true;
    const solid = typeof b.isSolid === "function" ? b.isSolid() : b.isSolid;
    return !!solid;
  } catch {
    return true;
  }
}

export function dist3(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
}

export function norm3(v) {
  const l = Math.hypot(v.x, v.y, v.z) || 1;
  return { x: v.x / l, y: v.y / l, z: v.z / l };
}

export function headPos(player) {
  try {
    return player.getHeadLocation();
  } catch {
    const l = player.location;
    return { x: l.x, y: l.y + 1.6, z: l.z };
  }
}

// 시선 끝 지점 (벽/바닥에 닿으면 그 직전). hit 는 무언가에 닿았는지.
export function aimPoint(player, maxDist, step = 0.5) {
  const dim = player.dimension;
  const d = player.getViewDirection();
  const h = headPos(player);
  let last = { ...h };
  for (let t = step; t <= maxDist; t += step) {
    const p = { x: h.x + d.x * t, y: h.y + d.y * t, z: h.z + d.z * t };
    if (isSolidAt(dim, p)) return { point: last, hit: true };
    last = p;
  }
  return { point: last, hit: false };
}

// 시선 앞에서 가장 먼저 만나는 대상
export function firstTargetInView(player, maxDist) {
  const dim = player.dimension;
  const d = player.getViewDirection();
  const h = headPos(player);
  for (let t = 1; t <= maxDist; t += 1) {
    const p = { x: h.x + d.x * t, y: h.y + d.y * t, z: h.z + d.z * t };
    if (isSolidAt(dim, p)) return undefined;
    const list = getTargets(player, p, 2.2, 0.9);
    if (list.length > 0) {
      list.sort((a, b) => dist3(a.location, h) - dist3(b.location, h));
      return list[0];
    }
  }
  return undefined;
}

// 현재 주 손에 든 아이템의 typeId
export function heldItemId(player) {
  try {
    const eq = player.getComponent("minecraft:equippable");
    const item = eq?.getEquipment(EquipmentSlot.Mainhand ?? "Mainhand");
    return item?.typeId;
  } catch {
    return undefined;
  }
}

```

## RPG_BP_v0603/scripts/gameplayEntry.js

```js
// RPG gameplay module - independent from slash-command registration pack.
import * as mc from "@minecraft/server";
import { initializeGameplay } from "./main.js";
let started = false;
function safeStart() {
  if (started) return;
  started = true;
  try { initializeGameplay(); }
  catch (e) { console.error("[RPG v0.6.8 gameplay] initialization failed: " + String(e?.stack ?? e)); }
}
try { mc.system.run(safeStart); }
catch (e) { console.error("[RPG v0.6.8 gameplay] schedule failed: " + String(e)); }
try {
  mc.world.afterEvents.worldLoad.subscribe(() => {
    if (!started) mc.system.run(safeStart);
  });
} catch (e) { console.warn("[RPG v0.6.8 gameplay] worldLoad recovery unavailable: " + String(e)); }

// Hydra: guard against any existing burning visual effects after pack upgrade.
// Fire immunity is configured in entities/hydra_boss.json.
try {
  mc.system.runInterval(() => {
    for (const id of ["overworld", "nether", "the_end"]) {
      try {
        const dim = mc.world.getDimension(id);
        for (const hydra of dim.getEntities({ type: "rpg:hydra_boss" })) {
          try {
            if (hydra.getComponent("minecraft:onfire")) hydra.extinguishFire(false);
          } catch (_) { /* invalid or unloaded entity */ }
        }
      } catch (_) { /* unloaded or inaccessible dimension */ }
    }
  }, 10);
} catch (e) { console.warn("[RPG] hydra fire cleanup unavailable: " + String(e)); }

```

## RPG_BP_v0603/scripts/skills/harpoon.js

```js
import {rememberScriptKiller} from '../core/combatContext.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import {teleportForSkill} from '../core/dungeonMovement.js';
import { skillDamageFor } from "../core/stats.js";
import { areAllies } from "../core/social.js";
import { system, world, EntityDamageCause } from '@minecraft/server';
import { CONFIG } from '../config.js';
import { getTargets, headPos, flatDir, norm3, dist3, isSolidAt, particle, sound, hurt, healthAlive } from '../core/util.js';
import { notify } from '../core/hud.js';
import { getLastHit } from '../core/tracking.js';

// 작살꾼 → 복수귀 (v0.4.45). 1틱=1/20초, 모든 연출은 작은 파티클로 제한.
const TRAIL = 'rpg:harpoon_trail';
const CHAIN = 'rpg:soul_chain';
const GHOST = 'rpg:soul_trace';
const pins = new Map();
const bleeding = new Map();
const TEAM_PREFIX = 'rpg_team_';
let installed = false;

function alive(e) { try { return !!e?.isValid && healthAlive(e); } catch { return false; } }
function friendly(p,e) {
  if (areAllies(p,e)) return true;
  if (e.id === p.id) return true;
  if (e.typeId !== 'minecraft:player') return false;
  const tag=p.getTags().find(t=>t.startsWith(TEAM_PREFIX));
  return !!tag && e.hasTag(tag);
}
function enemy(p,e) {
  return alive(e) && !friendly(p,e) && (e.typeId!=='minecraft:player' || CONFIG.pvp);
}
function effect(entity,id,duration,amp=0) {
  try { applyStatus(entity,id,duration,{amplifier:amp,showParticles:false}); } catch {}
}
function point(e,height=0.95) { const p=e.location;return {x:p.x,y:p.y+height,z:p.z}; }
function line(dim,from,to,fx,spacing=0.5) {
  const distance=dist3(from,to);const n=Math.min(65,Math.max(1,Math.ceil(distance/spacing)));
  for(let i=0;i<=n;i++) {const t=i/n;particle(dim,fx,{x:from.x+(to.x-from.x)*t,y:from.y+(to.y-from.y)*t,z:from.z+(to.z-from.z)*t});}
}
function safeSpot(dim,p,ground=true) {
  return !isSolidAt(dim,{x:p.x,y:p.y+0.15,z:p.z}) &&
    !isSolidAt(dim,{x:p.x,y:p.y+1.45,z:p.z}) &&
    (!ground || isSolidAt(dim,{x:p.x,y:p.y-0.8,z:p.z}));
}
function hitFx(dim,p) {
  for(let i=0;i<7;i++) {
    const a=i*2*Math.PI/7;
    particle(dim,TRAIL,{x:p.x+Math.cos(a)*.25,y:p.y+.07*(i%3),z:p.z+Math.sin(a)*.25});
  }
}

// 실제 작살 투사체: 1틱마다 2분할 충돌 판정, 0.2블록짜리 픽셀 궤적.
function shoot(p,def,onHit) {
  const d=norm3(p.getViewDirection()),dim=p.dimension,eye=headPos(p);
  const origin={x:eye.x+d.x*.65,y:eye.y+d.y*.65,z:eye.z+d.z*.65};
  let travel=0;
  const handler=system.runInterval(()=>{
    try {
      if(!p.isValid || travel>=def.range){system.clearRun(handler);return;}
      for(let i=0;i<3;i++) {
        travel+=def.speed/3;
        const at={x:origin.x+d.x*travel,y:origin.y+d.y*travel,z:origin.z+d.z*travel};
        if(isSolidAt(dim,at)) {hitFx(dim,at);system.clearRun(handler);return;}
        particle(dim,TRAIL,at);
        if(i===0 && (Math.floor(travel*4)%3===0))particle(dim,CHAIN,at);
        const victim=getTargets(p,at,1.1,.9).find(e=>enemy(p,e));
        if(victim) {
          hurt(victim,p,def.damage);hitFx(dim,at);onHit?.(victim,at);
          system.clearRun(handler);return;
        }
      }
    }catch {system.clearRun(handler);}
  },1);
  sound(dim,'mob.guardian.attack',p.location,{volume:.6,pitch:1.25});
  return true;
}
function throwHarpoon(p,job,def){return shoot(p,def);}

function frontTargets(p,def){
 const origin=p.location,dir=flatDir(p);
 return getTargets(p,{x:origin.x,y:origin.y+.9,z:origin.z},def.range+1,.9).filter(e=>{
  if(!enemy(p,e))return false;
  const at=e.location,dx=at.x-origin.x,dz=at.z-origin.z,front=dx*dir.x+dz*dir.z,side=Math.abs(dx*dir.z-dz*dir.x);
  if(front<0||front>def.range||side>def.halfWidth||Math.abs(at.y-origin.y)>2.5)return false;
  const distance=Math.hypot(dx,dz)||1;
  for(let d=.4;d<distance;d+=.4)if(isSolidAt(p.dimension,{x:origin.x+dx*d/distance,y:origin.y+.9+(at.y-origin.y)*d/distance,z:origin.z+dz*d/distance}))return false;
  return true;
 });
}
function deepPierce(p,job,def){
 const dir=flatDir(p),from=point(p),to={x:from.x+dir.x*def.range,y:from.y,z:from.z+dir.z*def.range};
 line(p.dimension,from,to,TRAIL,.35);sound(p.dimension,'item.trident.throw',p.location,{volume:.65,pitch:1.4});
 for(const target of frontTargets(p,def)){hurt(target,p,def.damage,'physical');hitFx(p.dimension,point(target));}
 return true;
}
function rend(p,job,def){
 const dim=p.dimension,dir=flatDir(p),from=point(p);
 for(let i=0;i<9;i++){const angle=Math.atan2(dir.z,dir.x)-Math.PI*.4+i*Math.PI*.1;particle(dim,GHOST,{x:from.x+Math.cos(angle)*2,y:from.y,z:from.z+Math.sin(angle)*2});}
 sound(dim,'mob.player.attack.sweep',p.location,{volume:.75,pitch:.8});
 for(const target of frontTargets(p,def)){
  if(!hurt(target,p,def.damage,'physical'))continue;hitFx(dim,point(target));
  const key=p.id+':'+target.id,state={ticks:0};bleeding.set(key,state);
  const timer=system.runInterval(()=>{
   try{
    if(bleeding.get(key)!==state||!p.isValid||!healthAlive(p)||!enemy(p,target)||p.dimension.id!==target.dimension.id){system.clearRun(timer);if(bleeding.get(key)===state)bleeding.delete(key);return;}
    hurt(target,p,def.bleedDamage,'physical');particle(dim,GHOST,point(target));
    if(++state.ticks>=def.bleedHits){bleeding.delete(key);system.clearRun(timer);}
   }catch{if(bleeding.get(key)===state)bleeding.delete(key);system.clearRun(timer);}
  },def.bleedInterval);
 }
 return true;
}

// 복수귀 영혼작살: 사슬에 맞은 대상은 시전자 앞 1.8칸까지 10틱 동안 당겨집니다.
function soulHarpoon(p,job,def) {
  return shoot(p,def,(target)=>{
    const dim=p.dimension;
    effect(target,'slowness',25,6);
    let ticks=0;
    const timer=system.runInterval(()=>{
      try {
        if(!p.isValid||!enemy(p,target)||p.dimension.id!==target.dimension.id) {system.clearRun(timer);return;}
        const me=p.location, t=target.location, dir=flatDir(p);
        const dest={x:me.x+dir.x*1.8,y:me.y,z:me.z+dir.z*1.8};
        line(dim,point(target),point(p),CHAIN,0.8);
        const length=dist3(t,dest);
        if(length>0.45) {
          const ratio=Math.min(.34,Math.max(0.03,1.8/length));
          const next={x:t.x+(dest.x-t.x)*ratio,y:t.y+(dest.y-t.y)*ratio,z:t.z+(dest.z-t.z)*ratio};
          if(safeSpot(dim,next,false))target.teleport(next,{dimension:dim,keepVelocity:false});
        }
        ticks++;
        if(ticks>=ccTicks(target,10) || length<.45){system.clearRun(timer);hitFx(dim,point(target));}
      } catch {system.clearRun(timer);}
    },1);
    sound(dim,'mob.endermen.portal',target.location,{volume:.55,pitch:1.3});
  });
}

function dive(p,job,def) {
  const upgraded=job.id==='revenant';
  const duration=upgraded?200:100;
  effect(p,'invisibility',duration,0);
  effect(p,'speed',duration,upgraded?3:2);
  if(upgraded)effect(p,'regeneration',duration,1);
  sound(p.dimension,'mob.guardian.flop',p.location,{volume:.6,pitch:1.1});
  notify(p,upgraded?'§b잠수: §f10초간 투명화·신속 IV·재생 II':'§b잠수: §f5초간 투명화·신속 III');
  return true;
}

// 전방 다섯 블럭의 적에게 무조건 적중하는 돌진. 지면·벽 검사 없이 Y 고정.
function charge(p,job,def){
  const dim=p.dimension,origin={...p.location},dir=flatDir(p),side={x:-dir.z,z:dir.x};
  const targets=getTargets(p,origin,def.length+2).filter(e=>{
    if(!enemy(p,e))return false;
    const at=e.location,dx=at.x-origin.x,dz=at.z-origin.z;
    const front=dx*dir.x+dz*dir.z,sideDist=Math.abs(dx*side.x+dz*side.z);
    return front>=0 && front<=def.length && sideDist<=def.width/2;
  });
  const dest={x:origin.x+dir.x*def.length,y:origin.y,z:origin.z+dir.z*def.length};
  // 판정은 돌진 당시 전방 5칸에 대한 고정 범위. 적이 있으면 무조건 공격.
  for(const victim of targets){
    hurt(victim,p,def.damage);hitFx(dim,point(victim));
  }
  line(dim,point(p),{x:dest.x,y:dest.y+1,z:dest.z},TRAIL,0.4);
  try{teleportForSkill(p,dest,{dimension:dim,keepVelocity:false});}catch{}
  sound(dim,'mob.irongolem.throw',origin,{volume:.8,pitch:.85});
  if(!targets.length) notify(p,'§7돌진했지만 전방 5블럭 안에 적이 없습니다.');
  else notify(p,`§b돌진: §f${targets.length}명에게 타격`);
  return true;
}

// 진짜 기절: 구속 및 무력화 + 위치 고정 (3초).
function pin(target,duration){
  effect(target,'slowness',duration,255);
  effect(target,'weakness',duration,255);
  effect(target,'mining_fatigue',duration,255);
  const existing=pins.get(target.id);
  pins.set(target.id,{entity:target,anchor:existing?.anchor??{...target.location},until:Math.max(system.currentTick+ccTicks(target,duration),existing?.until??0),dimension:target.dimension.id});
}
function distanceToSegment(p,a,b){
  const vx=b.x-a.x,vy=b.y-a.y,vz=b.z-a.z,wx=p.x-a.x,wy=p.y-a.y,wz=p.z-a.z;
  const dot=vx*vx+vy*vy+vz*vz||1;
  const t=Math.max(0,Math.min(1,(wx*vx+wy*vy+wz*vz)/dot));
  return Math.hypot(p.x-a.x-vx*t,p.y-a.y-vy*t,p.z-a.z-vz*t);
}
function soulSeparation(p,job,def) {
  const dim=p.dimension,origin={...p.location},dir=flatDir(p),dest={x:origin.x+dir.x*def.range,y:origin.y,z:origin.z+dir.z*def.range};
  if(!safeSpot(dim,dest,false)) {notify(p,'§7영혼분리: 도착 위치가 블록으로 막혀 있습니다.');return false;}
  for(let s=.5;s<def.range;s+=.5){
    const at={x:origin.x+dir.x*s,y:origin.y,z:origin.z+dir.z*s};
    if(!safeSpot(dim,at,false)){notify(p,'§7영혼분리: 앞에 장애물이 있습니다.');return false;}
  }
  try{teleportForSkill(p,dest,{dimension:dim,keepVelocity:false});}catch{return false;}
  line(dim,{...origin,y:origin.y+1},{...dest,y:dest.y+1},GHOST,.7);
  sound(dim,'mob.endermen.portal',dest,{volume:.85,pitch:1.3});
  // 1초 뒤 원래 위치에서 영혼이 시전자에게 돌아오며, 그 경로 주위 3블럭 기절.
  system.runTimeout(()=>{
    if(!p.isValid||p.dimension.id!==dim.id)return;
    const end={...p.location};
    const start={x:origin.x,y:origin.y+1,z:origin.z};
    const finish={x:end.x,y:end.y+1,z:end.z};
    line(dim,start,finish,GHOST,.35);
    line(dim,start,finish,CHAIN,.75);
    const travel=dist3(start,finish),center={x:(start.x+finish.x)/2,y:(start.y+finish.y)/2,z:(start.z+finish.z)/2};
    let hits=0;
    for(const e of getTargets(p,center,travel/2+def.radius+1,0.9)){
      if(!enemy(p,e))continue;
      if(distanceToSegment(point(e),start,finish)<=def.radius){pin(e,def.stun);hitFx(dim,point(e));hits++;}
    }
    sound(dim,'mob.endermen.portal',end,{volume:.6,pitch:.6});
    notify(p,`§b영혼분리: §f영혼 귀환 · ${hits}명 3초 기절`);
  },def.delay);
  return true;
}

// 성공: 시전자 반경 4칸의 25% 이하 적 처형, 5초 쿨타임 + 재생 III 5초.
// 실패: 같은 반경 안의 최근 공격/조준 대상 50피해, 60초 쿨타임.
function execution(p,job,def) {
  const dim=p.dimension;
  const nearby=getTargets(p,p.location,def.radius).filter(e=>enemy(p,e)&&dist3(e.location,p.location)<=def.radius);
  for(let i=0;i<32;i++){const angle=i*Math.PI*2/32;particle(dim,GHOST,{x:p.location.x+Math.cos(angle)*def.radius,y:p.location.y+.1,z:p.location.z+Math.sin(angle)*def.radius});}
  let victims=[];
  try {
    for(const e of nearby){
      if(!enemy(p,e))continue;
      const hp=e.getComponent('minecraft:health');
      if(!hp)continue;
      if(hp.currentValue>0 && hp.currentValue<=hp.effectiveMax*def.healthThreshold)victims.push(e);
    }
  }catch{}
  if(victims.length){
    let killed=0;
    for(const e of victims){
      try {
        const at=point(e);
        rememberScriptKiller(p,e);e.kill();killed++;
        hitFx(dim,at);
        particle(dim,GHOST,at);
      }catch{}
    }
    if(killed>0){
      effect(p,'regeneration',100,2);
      sound(dim,'random.anvil_land',p.location,{volume:.9,pitch:.55});
      notify(p,`§5처형 성공! §f${killed}명 · 쿨타임 5초 · 재생 III 5초`);
      return {cooldown:def.successCooldown};
    }
  }
  let target=getLastHit(p);
  if(!enemy(p,target)||target.dimension.id!==dim.id||dist3(target.location,p.location)>def.radius){
    let closest=Infinity;target=null;
    const eye=headPos(p),look=norm3(p.getViewDirection());
    for(const e of nearby){
      if(!enemy(p,e))continue;
      const v=point(e),delta={x:v.x-eye.x,y:v.y-eye.y,z:v.z-eye.z};
      const distance=Math.hypot(delta.x,delta.y,delta.z)||1;
      if((delta.x*look.x+delta.y*look.y+delta.z*look.z)/distance<.78)continue;
      if(distance<closest){closest=distance;target=e;}
    }
  }
  if(target){
    try{target.applyDamage(skillDamageFor(p,def.failDamage,"physical"),{cause:EntityDamageCause.override,damagingEntity:p});}
    catch{hurt(target,p,def.failDamage);}
    hitFx(dim,point(target));
  }
  sound(dim,'mob.endermen.portal',p.location,{volume:.7,pitch:.55});
  notify(p,target?'§c처형 실패: §f대상에게 50 피해 · 쿨타임 60초':'§c처형 실패: §f적이 없음 · 쿨타임 60초');
  return {cooldown:def.cooldown};
}

export const RUNNERS={
  revenant_deep_pierce:deepPierce,revenant_rend:rend,
  harpoon_throw:throwHarpoon,harpoon_dive:dive,harpoon_charge:charge,
  soul_harpoon:soulHarpoon,soul_separation:soulSeparation,revenant_execution:execution,
};
export function registerHarpoon(){
  if(installed)return;installed=true;
  system.runInterval(()=>{
    for(const [id,pinState] of pins){
      const {entity,anchor,until,dimension}=pinState;
      try {
        if(!alive(entity)||system.currentTick>=until||entity.dimension.id!==dimension){pins.delete(id);continue;}
        if(dist3(entity.location,anchor)>.3)entity.teleport(anchor,{dimension:entity.dimension,keepVelocity:false});
        if(system.currentTick%10===0)particle(entity.dimension,CHAIN,point(entity));
      }catch{pins.delete(id);}
    }
  },5);
  world.afterEvents.entityDie.subscribe(ev=>pins.delete(ev.deadEntity?.id));
}

```

## RPG_Commands_BP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Commands BP v0.6.8",
    "description": "RPG v0.6.8 · PvP 무적·비살상 보호 제거 · 기존 보호 상태 정리",
    "uuid": "533cff27-4591-48cb-85fb-540c8bcbcc72",
    "version": [
      0,
      6,
      8
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "script",
      "language": "javascript",
      "uuid": "9518dff9-cc69-4ea4-adb6-2762b6291c45",
      "entry": "scripts/commands.js",
      "version": [
        0,
        6,
        8
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
      "version": [
        0,
        6,
        8
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    }
  ]
}

```

## RPG_Commands_BP_v0603/scripts/commands.js

```js
// RPG command registry, isolated in a separate behavior pack.
// Even if complex RPG combat/skill imports fail, /rpg:ping can still register.
import * as mc from "@minecraft/server";
const VERSION = "0.6.8";
const commands = [
  ['tpa','플레이어 이동 요청 · 이동 성공 시 1000골드'],
  ['tpaaccept','받은 플레이어 이동 요청 수락·거절'],
  ['pvpcreate','관리자: 1000 250 1000에 PvP장 생성',null,true],
  ['pkclear','관리자: 플레이어 PK 패널티 해제','player',true],
  ['peace','관리자: 현재 위치 반경 200 평화구역 설정·해제','mode',true],
  ['pvp','결투 신청·수락·항복·PK 상태','player'],
  ['gptnpc','관리자: GPT RPG 질문 NPC 생성',null,true],
  ['temple','천체 신전 위치·활성 제단·후예 전직'],
  ['templecreate','관리자: 앞쪽 빈 지역에 천체 신전 생성',null,true],
  ['templeremove','관리자: 신전 등록 해제·건물 보존',null,true],
  ['fuse','RPG 장비 등급 합성'],
  ['transfer','RPG 갑옷 강화 추출·이전'],
  ['ask','이 애드온의 직업·스킬·제작·던전 정보 질문','question'],
  ['dungeoncreate','관리자: 난이도 1~10 또는 all 동굴 생성·누락 복구','difficulty',true],
  ['dungeonremove','관리자: 던전 등록 해제 (건축물 보존)','name',true],
  ['dungeon','난이도 목록·파티장 입장 시 파티원 자동 등록','difficulty'],
  ['dungeonstart','대기실 인원 1~4명 출발'],
  ['dungeonsolo','해당 난이도 혼자 바로 시작','difficulty'],
  ['dungeonleave','대기 취소·사망 후 귀환 (전투 중 불가)'],
  ['dungeonloot','보관된 던전 보급품 받기'],
  ['skillguide','모든 직업·스킬 상세 도감'],
  ['runes','룬 전용 보관함·장착'],
  ['jobs','직업별 전직 조건·시련'],
  ['craft', '갑옷·룬 제작법과 획득 도감'],
  ['upgrade', '갑옷·룬·공용 무기 강화'],
  ['wallet', '골드·강화석·룬 가루 지갑'],
  ['equipment', 'RPG 갑옷·룬 보관·장착'],
  ['guide', '모험 시작·견습 5계열 자유 체험'],
  ["rulebook", "RPG 서버 종합 룰북"],
  ["ping", "명령어 등록 진단"],
  ["diag", "명령어 및 스크립트 진단"],
  ["menu", "카멜레온 스킬 메뉴"],
  ["job", "전직", "job"],
  ["help", "명령어 도움말"],
  ["status", "캐릭터 상태"],
  ["stats", "레벨·스탯 분배"],
  ["admin", "운영자 설정 도구", null, true],
  ["setlevel", "관리자: 레벨 설정", "level", true],
  ["setmana", "관리자: 최대 마나 설정", "amount", true],
  ["skills", "스킬 켜기·끄기"],
  ["skillbook", "스킬 도감"],
  ["learn", "스킬 습득", "skill"],
  ["swap", "카멜레온 무기 전환"],
  ["offer", "검과 책을 바칩니다"],
  ["bless", "미카엘 전직: 축복의 빛 192개 공물"],
  ["holywater", "성수 제작"],
  ["force", "관리자: 강제 전직", "job", true],
  ["reset", "관리자: 초기화", null, true],
  ["starter", "관리자: 견습 장비", "line", true],
  ["charge", "관리자: 마나·쿨타임 회복", null, true],
  ["items", "관리자: 전용 아이템", null, true],
  ["egg", "관리자: 몬스터 스폰알", null, true],
  ["hito", "관리자: 전직관 소환알 지급", "line", true],
  ["wings", "날개 켜기·끄기"],
  ["wingcheck", "날개 상태"],
  ["wingrefresh", "날개 새로고침"],
  ["guild", "길드 메뉴"],
  ["party", "파티 메뉴"],
  ["invites", "초대 확인"],
  ["boss", "관리자: 바위 골렘", null, true],
  ["cyclops", "관리자: 외눈 거인", null, true],
  ["hydra", "관리자: 히드라", null, true],
  ["techgolem", "관리자: 마공학 골렘", null, true],
  ["fistcheck", "주먹 강화 상태"]
];
const registered = new Set();
let startupDone = false;
let failures = [];
function isPlayer(p) { return !!p && p.typeId === "minecraft:player"; }
function tell(p, msg) { try { p.sendMessage(msg); } catch (e) { console.warn("[RPG commands] message: " + e); } }
function handle(action, p, arg="") {
  if (!isPlayer(p)) return;
  if (action === "ping") {
    tell(p, "§a[RPG v"+VERSION+"] 명령어 스크립트 실행 정상. 등록 "+registered.size+"/"+commands.length);
    return;
  }
  if (action === "diag") {
    tell(p,"§e[RPG v"+VERSION+"] 명령어 팩 실행 정상 ("+registered.size+"/"+commands.length+"). RPG 본체 확인: /rpg:status");
    if(failures.length) failures.slice(0,4).forEach(x=>tell(p,"§c"+x));
    tell(p,"§7게임플레이 오류는 설정 → 제작자 → 콘텐츠 로그에서 확인 가능. /function rpg_hydra 로 히드라 소환 검사 가능");
    return;
  }
  // The RPG gameplay BP independently handles this script event. It is run as
  // the player so event.sourceEntity is the correct player object.
  const message = String(arg??"").replace(/[\r\n]/g," ").trim();
  try {
    p.runCommand("scriptevent rpg:"+action+(message?" "+message:""));
  } catch (e) {
    tell(p,"§c[RPG] 명령어 전달 실패: "+String(e));
  }
}
mc.system.beforeEvents.startup.subscribe(ev => {
  startupDone = true;
  const registry = ev.customCommandRegistry;
  if(!registry){ console.error("[RPG commands] customCommandRegistry unavailable"); return; }
  const levels = mc.CommandPermissionLevel ?? mc.CustomCommandPermissionLevel;
  const params = mc.CustomCommandParamType;
  const statuses = mc.CustomCommandStatus;
  if(!levels || !params || !statuses){ console.error("[RPG commands] Script API command enums unavailable"); return; }
  for(const [name, description, arg, admin] of commands){
    try{
      const def={name:"rpg:"+name,description,permissionLevel: admin?levels.GameDirectors:levels.Any,cheatsRequired:false};
      if(arg){
        const t = name === "setlevel" ? params.Integer : params.String;
        if(name === "hito" || name === "dungeon" || name === "ask" || name === "pvp" || name === "peace" || name === "pkclear") def.optionalParameters=[{name:arg,type:t}];
        else def.mandatoryParameters=[{name:arg,type:t}];
      }
      registry.registerCommand(def,(origin,...args)=>{
        const p=origin.sourceEntity??origin.initiator;
        if(!isPlayer(p)) return {status:statuses.Failure,message:"플레이어 전용 명령어"};
        const raw=Array.isArray(args[0])?args[0][0]:args[0];
        mc.system.run(()=>handle(name,p,raw==null?"":String(raw)));
        return {status:statuses.Success};
      });
      registered.add(name);
    }catch(e){
      const msg="/rpg:"+name+" 등록 실패: "+String(e);
      failures.push(msg);console.error("[RPG commands] "+msg);
    }
  }
  try{registry.registerCommand({name:'pvp',description:'결투 신청',permissionLevel:levels.Any,cheatsRequired:false,optionalParameters:[{name:'player',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvp',p,arg??''));return {status:statuses.Success};});}catch{ /* Namespace-free aliases are unsupported on some Bedrock versions. */ }
  try{registry.registerCommand({name:'peace',description:'관리자: 반경 200 평화구역',permissionLevel:levels.GameDirectors,cheatsRequired:false,optionalParameters:[{name:'mode',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('peace',p,arg??''));return {status:statuses.Success};});}catch{console.warn('[RPG] /peace 별칭 미지원: /rpg:peace 사용');}
  try{registry.registerCommand({name:'pvpcreate',description:'관리자: PvP장 생성',permissionLevel:levels.GameDirectors,cheatsRequired:false},origin=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvpcreate',p,''));return {status:statuses.Success};});}catch{console.warn('[RPG] /pvpcreate 별칭 미지원: /rpg:pvpcreate 사용');}
  console.warn("[RPG v"+VERSION+"] registered "+registered.size+"/"+commands.length+" commands");
});
// Allow commands even if a particular client doesn't display slash commands.
try {
  const chat=mc.world.beforeEvents?.chatSend;
  if(chat?.subscribe) chat.subscribe(ev=>{
    const msg=String(ev.message??"").trim();
    if(!/^!(?:rpg|rulebook|hito|pvp)(?:\s|$)/i.test(msg))return;
    ev.cancel=true;
    let action="help",arg="";
    if(/^!pvp(?:\s|$)/i.test(msg)){action='pvp';arg=msg.replace(/^!pvp\s*/i,'');}
    else if(/^!rulebook$/i.test(msg))action="rulebook";
    else if(/^!hito(?:\s|$)/i.test(msg)){action="hito";arg=msg.replace(/^!hito\s*/i,"");}
    else {const parts=msg.replace(/^!rpg\s*/i,"").trim().split(/\s+/);action=(parts.shift()||"help").toLowerCase();arg=parts.join(" ");}
    const p=ev.sender;
    mc.system.run(()=>handle(action,p,arg));
  });
}catch(e){console.warn("[RPG commands] chat fallback disabled: "+e);}
// Direct /scriptevent rpg:ping and rpg:diag allow diagnosing even if custom
// command registration is unsupported on the current Bedrock version.
try {
  mc.system.afterEvents.scriptEventReceive.subscribe(ev=>{
    if(ev.id!=="rpg:ping"&&ev.id!=="rpg:diag") return;
    if(isPlayer(ev.sourceEntity))mc.system.run(()=>handle(ev.id.slice(4),ev.sourceEntity));
  });
}catch(e){console.warn("[RPG commands] event diagnostic fallback disabled: "+e);}

```

## RPG_RP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon RP v0.6.8",
    "description": "RPG v0.6.8 · PvP 무적·비살상 보호 제거 · 기존 보호 상태 정리",
    "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
    "version": [
      0,
      6,
      8
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "resources",
      "uuid": "7ede5e36-9a5f-44d1-9aa0-9dc38822fa99",
      "version": [
        0,
        6,
        8
      ]
    }
  ]
}

```

