import { CONFIG } from '../config.js';
import { isBeginnerTarget } from './beginnerData.js';
import { partyMembership } from './social.js';
import { isActiveNearbyPlayer } from './xpDistribution.js';
import { creditWallet, WALLET_KEY } from './wallet.js';

const BOSSES = new Set(['rpg:rock_golem_boss','rpg:cyclops_boss','rpg:hydra_boss','rpg:tech_block_golem_boss',
  'minecraft:wither','minecraft:ender_dragon','minecraft:warden']);

export function currencyReward(typeId, random=Math.random) {
  if (BOSSES.has(typeId)) return {gold:250,stone:12,dust:6};
  if (!isBeginnerTarget(typeId)) return undefined;
  if (typeId.startsWith('rpg:elite_')) return {gold:25,stone:3,dust:1};
  return {gold:8,stone:1,dust:random() < 0.15 ? 1 : 0};
}

export function grantKillCurrencies(killer, entity, random=Math.random) {
  // A creative/spectator killer cannot mint money for survival party members.
  if (!isActiveNearbyPlayer(killer,killer.location,killer.dimension.id,CONFIG.partyXp.radius)) return [];
  const reward = currencyReward(entity?.typeId,random);
  if (!reward) return [];
  const recipients = partyMembership(killer).members.filter(p=>
    isActiveNearbyPlayer(p,killer.location,killer.dimension.id,CONFIG.partyXp.radius));
  const paid = [];
  for (const player of recipients) {
    try {
      const first = player.getDynamicProperty(WALLET_KEY)===undefined;
      creditWallet(player,reward);paid.push(player.id);
      if (first || reward.gold>=25) try {player.sendMessage(`§6[RPG 재화] 골드 +${reward.gold}, 강화석 +${reward.stone}, 룬 가루 +${reward.dust} §7(/rpg:wallet · /rpg:upgrade)`);} catch {}
    }
    catch (error) {console.warn('[RPG economy] reward failed: '+String(error));}
  }
  return paid;
}
