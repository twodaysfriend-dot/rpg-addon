from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import zipfile
from PIL import Image

ROOT = Path(__file__).resolve().parent
DIST = ROOT / 'dist'
PACKS = ['RPG_BP_v0532', 'RPG_Commands_BP_v0532', 'RPG_RP_v0532']

def main():
    subprocess.run(['python',str(ROOT/'tools/make_crafting_catalog.py')],cwd=ROOT,check=True)
    subprocess.run(['python',str(ROOT/'tools/make_skill_guide.py')],cwd=ROOT,check=True)
    DIST.mkdir(exist_ok=True)
    counts = {'json': 0, 'js': 0, 'active_imports': 0}
    headers = {}
    for name in PACKS:
        base = ROOT / name
        manifest = json.loads((base / 'manifest.json').read_text())
        assert manifest['header']['version'] == [0, 5, 32]
        headers[manifest['header']['uuid']] = manifest['header']['version']
        for module in manifest['modules']:
            assert module['version'] == [0, 5, 32]
            if module['type'] == 'script':
                assert (base / module['entry']).is_file(), module['entry']
        for file in base.rglob('*.json'):
            json.loads(file.read_text(encoding='utf-8-sig'))
            counts['json'] += 1
        for file in base.rglob('*.js'):
            result = subprocess.run(['node', '--input-type=module', '--check'],
                                    input=file.read_bytes(), capture_output=True)
            if result.returncode:
                raise RuntimeError(f'{file}: {result.stderr.decode()}')
            counts['js'] += 1
            # The RP contains unused historical script copies; it has no script module.
            if name != 'RPG_RP_v0532':
                for relative in re.findall(r'''(?:from\s*|import\s*)["'](\.[^"']+)["']''', file.read_text()):
                    assert (file.parent / relative).is_file(), (file, relative)
                    counts['active_imports'] += 1
    for name in PACKS:
        manifest = json.loads((ROOT / name / 'manifest.json').read_text())
        for dependency in manifest.get('dependencies', []):
            if 'uuid' in dependency:
                assert headers[dependency['uuid']] == dependency['version']
    rp = ROOT / 'RPG_RP_v0532'
    bp = ROOT / 'RPG_BP_v0532'
    atlas = json.loads((rp/'textures/item_texture.json').read_text())['texture_data']
    new_items = [p for p in (bp/'items').glob('*.json') if p.stem!='rune_haste' and p.stem.startswith(('adventurer_','warden_','astral_','rune_'))]
    assert len(new_items) == 17
    new_textures = list((rp/'textures/items/rpg_equipment').glob('*.png')) + list((rp/'textures/models/armor/rpg').glob('*.png'))
    assert len(new_textures) == 25
    for texture in new_textures:
        image = Image.open(texture)
        assert image.size == (128,128), texture
        assert image.mode == 'RGBA'
        assert set(image.getchannel('A').get_flattened_data()) <= {0,255}, texture
    for file in new_items:
        item = json.loads(file.read_text())['minecraft:item']
        texture = atlas[item['components']['minecraft:icon']]['textures']
        assert (rp/(texture+'.png')).is_file()
        assert (bp/'recipes'/file.name).is_file()
        if not file.stem.startswith('rune_'):
            attach = json.loads((rp/'attachables'/file.name).read_text())['minecraft:attachable']['description']
            assert attach['identifier'] == item['description']['identifier']
            assert (rp/(attach['textures']['default']+'.png')).is_file()
    counts['new_128px_textures'] = len(new_textures)
    catalyst=json.loads((bp/'items/enhancement_catalyst.json').read_text())['minecraft:item']
    assert catalyst['description']['identifier']=='rpg:enhancement_catalyst'
    assert catalyst['components']['minecraft:icon']=='rpg_enhancement_catalyst'
    assert atlas['rpg_enhancement_catalyst']['textures']=='textures/items/rpg_equipment/enhancement_catalyst'
    crystal=Image.open(rp/'textures/items/rpg_equipment/enhancement_catalyst.png')
    assert len(crystal.getcolors())<=16
    for y in range(0,128,4):
        for x in range(0,128,4):
            assert len(crystal.crop((x,y,x+4,y+4)).getcolors())==1
    assert (bp/'recipes/enhancement_catalyst.json').is_file()
    book=json.loads((bp/'items/random_skillbook.json').read_text())['minecraft:item']
    assert book['description']['identifier']=='rpg:random_skillbook'
    assert 'rpg:random_skillbook' in book['components']
    assert book['components']['minecraft:icon']=='rpg_random_skillbook'
    book_image=rp/(atlas['rpg_random_skillbook']['textures']+'.png')
    assert book_image.is_file()
    mana_entity=json.loads((bp/'entities/mana_arrow.json').read_text())['minecraft:entity']
    assert mana_entity['description']['identifier']=='rpg:mana_arrow'
    assert 'minecraft:inventory' not in mana_entity['components']
    mana_visual=json.loads((rp/'entity/mana_arrow.entity.json').read_text())['minecraft:client_entity']['description']
    assert mana_visual['identifier']=='rpg:mana_arrow'
    assert (rp/(mana_visual['textures']['default']+'.png')).is_file()
    mana_geometry=json.loads((rp/'models/entity/mana_arrow.geo.json').read_text())['minecraft:geometry'][0]['description']['identifier']
    assert mana_visual['geometry']['default']==mana_geometry
    for y in range(0,128,4):
        for x in range(0,128,4):
            assert len(Image.open(book_image).crop((x,y,x+4,y+4)).getcolors())==1
    for name in ['rock_golem_boss','cyclops_boss','hydra_boss','tech_block_golem_boss']:
        entity=json.loads((bp/'entities'/f'{name}.json').read_text())['minecraft:entity']
        assert (bp/entity['components']['minecraft:loot']['table']).is_file()
    print('Validation:', json.dumps(counts))

    addon = DIST / 'RPG_v0532.mcaddon'
    with zipfile.ZipFile(addon, 'w', zipfile.ZIP_DEFLATED) as outer:
        for name in PACKS:
            base = ROOT / name
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as pack:
                for file in sorted(base.rglob('*')):
                    if file.is_file():
                        pack.write(file, file.relative_to(base).as_posix())
            outer.writestr(name + '.mcpack', buffer.getvalue())
    with zipfile.ZipFile(addon) as outer:
        assert outer.testzip() is None
        for name in outer.namelist():
            with zipfile.ZipFile(io.BytesIO(outer.read(name))) as pack:
                assert pack.testzip() is None
                assert 'manifest.json' in pack.namelist()

    source = DIST / 'RPG_v0532_source_and_notes.zip'
    with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED) as archive:
        for file in sorted(ROOT.rglob('*')):
            if file.is_file() and not file.is_relative_to(DIST) and '__pycache__' not in file.parts and file.suffix != '.pyc':
                archive.write(file, file.relative_to(ROOT).as_posix())
    textures = DIST / 'RPG_equipment_128px.zip'
    with zipfile.ZipFile(textures, 'w', zipfile.ZIP_DEFLATED) as archive:
        for file in new_textures:
            archive.write(file,file.relative_to(rp).as_posix())
        for file in new_items:
            if not file.stem.startswith('rune_'):
                attach = rp/'attachables'/file.name
                archive.write(attach,attach.relative_to(rp).as_posix())
        archive.write(ROOT/'사용법_및_제작법.md','사용법_및_제작법.md')
        archive.write(ROOT/'강화_및_재화_안내.md','강화_및_재화_안내.md')
        archive.write(ROOT/'위험강화_체력_변경사항.md','위험강화_체력_변경사항.md')
        archive.write(ROOT/'촉매_룬획득_갑옷제작.md','촉매_룬획득_갑옷제작.md')
        archive.write(ROOT/'v0532_개편_전체안내.md','v0532_개편_전체안내.md')
        archive.write(ROOT/'v0532_밸런스_변경과_추천조합.md','v0532_밸런스_변경과_추천조합.md')
        archive.write(ROOT/'직업계열별_129개_스킬_상세도감.md','직업계열별_129개_스킬_상세도감.md')
        archive.write(ROOT/'v0532_최신_수정사항.md','v0532_최신_수정사항.md')
        archive.write(ROOT/'v0532_풀강_비용과_시간.md','v0532_풀강_비용과_시간.md')
    icon = DIST / 'enhancement_catalyst_128.png'
    icon.write_bytes((rp/'textures/items/rpg_equipment/enhancement_catalyst.png').read_bytes())
    skill_icon=DIST/'random_skillbook_128.png'
    skill_icon.write_bytes(book_image.read_bytes())
    for file in [addon, source, textures, icon, skill_icon]:
        digest = hashlib.sha256(file.read_bytes()).hexdigest()
        print(file.name, file.stat().st_size, 'bytes', 'sha256=' + digest)

if __name__ == '__main__':
    main()
