import test, {after} from 'node:test';
// This regression suite explicitly exercises successful upgrade paths.
const originalRandom=Math.random;Math.random=()=>0;after(()=>{Math.random=originalRandom;});
import assert from 'node:assert/strict';
import {player,ItemStack,EquipmentSlot,world,players,replies,forms,events} from './minecraftMock.mjs';
import {WALLET_KEY,CURRENCIES,BALANCE_MAX,getWallet,setWallet,creditWallet} from '../RPG_BP_v0532/scripts/core/wallet.js';
import {currencyReward,grantKillCurrencies} from '../RPG_BP_v0532/scripts/core/economy.js';
import {enhancementQuote,enhanceEquipped,openUpgradeMenu} from '../RPG_BP_v0532/scripts/core/upgrades.js';
import {ARMOR_LEVEL_KEY,RUNE_LEVEL_KEY,upgradeLevel,upgradeCost,upgradedRune} from '../RPG_BP_v0532/scripts/data/upgrades.js';
import {RUNES,RUNE_KEY} from '../RPG_BP_v0532/scripts/data/equipment.js';
import {getEquipmentBonuses} from '../RPG_BP_v0532/scripts/core/equipment.js';
import {registerRpgStats,getXp} from '../RPG_BP_v0532/scripts/core/stats.js';

function ready(name='smith') {
  const p=player(name);p.equipment.set(EquipmentSlot.Chest,new ItemStack('rpg:adventurer_chestplate'));
  setWallet(p,{gold:100000,stone:10000,dust:10000});return p;
}
test('exactly 3 currencies, default zero and persistent wallet',()=>{
  assert.deepEqual(Object.keys(CURRENCIES),['gold','stone','dust']);
  const p=player('wallet');assert.deepEqual(getWallet(p),{gold:0,stone:0,dust:0});
  creditWallet(p,{gold:250,stone:12,dust:6});
  const reload=player('wallet');reload.setDynamicProperty(WALLET_KEY,p.getDynamicProperty(WALLET_KEY));
  assert.deepEqual(getWallet(reload),{gold:250,stone:12,dust:6});
});
test('wallet rejects negative, fractional and corrupt balances without resetting saved money',()=>{
  const p=ready();const old=p.getDynamicProperty(WALLET_KEY);
  for(const gold of [-1,1.5,NaN,Infinity])assert.throws(()=>setWallet(p,{gold,stone:1,dust:1}));
  assert.equal(p.getDynamicProperty(WALLET_KEY),old);
  assert.throws(()=>creditWallet(p,{gold:-1}));
  p.setDynamicProperty(WALLET_KEY,'{invalid');assert.throws(()=>getWallet(p));
  assert.equal(p.getDynamicProperty(WALLET_KEY),'{invalid');
});
test('wallet cap and monster tier rewards, including deterministic dust rolls',()=>{
  const p=player('cap');setWallet(p,{gold:BALANCE_MAX-1,stone:0,dust:0});
  creditWallet(p,{gold:10});assert.equal(getWallet(p).gold,BALANCE_MAX);
  assert.deepEqual(currencyReward('minecraft:zombie',()=>0),{gold:8,stone:1,dust:1});
  assert.deepEqual(currencyReward('minecraft:zombie',()=>0.15),{gold:8,stone:1,dust:0});
  assert.deepEqual(currencyReward('rpg:elite_green_goblin'),{gold:25,stone:3,dust:1});
  assert.deepEqual(currencyReward('rpg:hydra_boss'),{gold:250,stone:12,dust:6});
  for(const id of ['minecraft:chicken','minecraft:villager','minecraft:player','rpg:bone_minion','rpg:sandbag_entity','rpg:hito_sword'])assert.equal(currencyReward(id),undefined);
});

const killer=player('killer'),low=player('low'),far=player('far',1,{location:{x:100,y:64,z:0}}),dead=player('dead',1,{health:0}),guild=player('guild');
world.setDynamicProperty('rpg:social_v1',JSON.stringify({version:1,nextId:3,
  parties:[{id:1,leader:'killer',members:['killer','low','far','dead']}],
  guilds:[{id:2,name:'guild',leader:'killer',members:['killer','guild']}]}));
players.push(killer,low,far,dead,guild);
test('nearby party members receive currency without a last-hit/level requirement; exclusions work',()=>{
  killer.setDynamicProperty('rpg:rpg_level',100);low.setDynamicProperty('rpg:rpg_level',1);
  assert.deepEqual(grantKillCurrencies(killer,{typeId:'rpg:hydra_boss'}),['killer','low']);
  assert.deepEqual(getWallet(low),{gold:250,stone:12,dust:6});
  for(const p of [far,dead,guild])assert.deepEqual(getWallet(p),{gold:0,stone:0,dust:0});
  killer.getGameMode=()=> 'creative';
  assert.deepEqual(grantKillCurrencies(killer,{typeId:'rpg:hydra_boss'}),[]);
  assert.equal(getWallet(low).gold,250);killer.getGameMode=()=> 'survival';
});
test('armor +10 cap, increasing cost and unchanged currency on capped retry',()=>{
  const p=ready();let totalGold=0,totalStone=0;
  for(let level=0;level<10;level++) {
    const cost=upgradeCost('armor',level);totalGold+=cost.gold;totalStone+=cost.stone;
    assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest).ok,true);
  }
  assert.equal(upgradeLevel(p.equipment.get(EquipmentSlot.Chest),'armor'),10);
  assert.deepEqual(getWallet(p),{gold:100000-totalGold,stone:10000-totalStone,dust:10000});
  const saved=p.getDynamicProperty(WALLET_KEY);assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest).ok,false);
  assert.equal(p.getDynamicProperty(WALLET_KEY),saved);
});
test('insufficient money/materials, invalid equipment and stale quotes never spend funds',()=>{
  const p=ready();setWallet(p,{gold:0,stone:100,dust:100});
  assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest).ok,false);
  assert.deepEqual(getWallet(p),{gold:0,stone:100,dust:100});
  assert.equal(enhanceEquipped(p,'rune',EquipmentSlot.Chest).ok,false);
  creditWallet(p,{gold:1000});const q=enhancementQuote(p,'armor',EquipmentSlot.Chest);
  p.equipment.get(EquipmentSlot.Chest).setDynamicProperty(ARMOR_LEVEL_KEY,1);
  const saved=p.getDynamicProperty(WALLET_KEY);assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest,q.fingerprint).ok,false);
  assert.equal(p.getDynamicProperty(WALLET_KEY),saved);
  p.equipment.set(EquipmentSlot.Chest,new ItemStack('minecraft:iron_chestplate'));
  assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest).ok,false);
});
test('equipment write failure refunds wallet and leaves original enhancement unchanged',()=>{
  const p=ready(),saved=p.getDynamicProperty(WALLET_KEY),get=p.getComponent.bind(p),eq=get('minecraft:equippable');let first=true;
  p.getComponent=name=>name==='minecraft:equippable'?{...eq,setEquipment:(slot,item)=>{if(first){first=false;return false;}return eq.setEquipment(slot,item);}}:get(name);
  assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest).ok,false);
  assert.equal(p.getDynamicProperty(WALLET_KEY),saved);assert.equal(upgradeLevel(p.equipment.get(EquipmentSlot.Chest),'armor'),0);
});
test('wallet write failure does not change the equipped item',()=>{
  const p=ready(),saved=p.getDynamicProperty(WALLET_KEY),write=p.setDynamicProperty.bind(p);let first=true;
  p.setDynamicProperty=(key,value)=>{if(key===WALLET_KEY&&first){first=false;throw Error('test save failure');}write(key,value);};
  assert.equal(enhanceEquipped(p,'armor',EquipmentSlot.Chest).ok,false);
  assert.equal(p.getDynamicProperty(WALLET_KEY),saved);assert.equal(upgradeLevel(p.equipment.get(EquipmentSlot.Chest),'armor'),0);
});
test('upgrade menu confirms spending, and cancel never charges',async()=>{
  const p=ready();replies.push({canceled:false,selection:0},{canceled:false,selection:0},{canceled:true});
  await openUpgradeMenu(p);assert.equal(getWallet(p).gold,100000);
  replies.push({canceled:false,selection:0},{canceled:false,selection:1},{canceled:true});
  await openUpgradeMenu(p);assert.equal(getWallet(p).gold,99960);
  assert.ok(forms.some(f=>f.heading==='위험 강화 확인'));
});
test('actual entityDie handler grants wallet rewards alongside existing RPG XP',()=>{
  const p=player('event');registerRpgStats();
  events.entityDie.listeners.at(-1)({deadEntity:{typeId:'rpg:cyclops_boss'},damageSource:{damagingEntity:p}});
  assert.deepEqual(getWallet(p),{gold:250,stone:12,dust:6});assert.ok(p.getDynamicProperty('rpg:rpg_level')>1);
});
