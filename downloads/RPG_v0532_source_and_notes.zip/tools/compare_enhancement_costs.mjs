// Exact finite-state expectations. Destruction returns to +0 with a replacement
// provided; replacement crafting/loot costs are deliberately reported separately.
import {enhancementRates,upgradeCost,catalystAllowed,ARMOR_MAX,RUNE_MAX} from '../RPG_BP_v0532/scripts/data/upgrades.js';
import {currencyReward} from '../RPG_BP_v0532/scripts/core/economy.js';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
function solve(matrix,vector){
 const a=matrix.map((row,i)=>[...row,vector[i]]),n=vector.length;
 for(let col=0;col<n;col++){
  let pivot=col;for(let row=col+1;row<n;row++)if(Math.abs(a[row][col])>Math.abs(a[pivot][col]))pivot=row;
  [a[col],a[pivot]]=[a[pivot],a[col]];if(Math.abs(a[col][col])<1e-12)throw Error('Non-absorbing enhancement configuration');
  const divisor=a[col][col];for(let k=col;k<=n;k++)a[col][k]/=divisor;
  for(let row=0;row<n;row++)if(row!==col){const factor=a[row][col];for(let k=col;k<=n;k++)a[row][k]-=factor*a[col][k];}
 }
 return a.map(row=>row[n]);
}
export function expectedEnhancement(kind,catalysts=0){
 const n=kind==='armor'?ARMOR_MAX:RUNE_MAX,metrics=['attempts','gold','stone','dust','catalysts','destroyed'];
 const matrix=[],rewards=Object.fromEntries(metrics.map(k=>[k,[]]));
 for(let level=0;level<n;level++){
  const count=catalystAllowed(kind,level)?catalysts:0,rates=enhancementRates(kind,level,count),cost=upgradeCost(kind,level);
  if(!rates)throw Error('Invalid enhancement configuration');
  const row=Array(n).fill(0);row[level]=1;
  for(const [next,chance]of [[level+1,rates.success],[level,rates.fail],[Math.max(0,level-1),rates.downgrade],[0,rates.destroy]])if(next<n)row[next]-=chance/100;
  matrix.push(row);const reward={attempts:1,...cost,catalysts:count,destroyed:rates.destroy/100};for(const k of metrics)rewards[k].push(reward[k]);
 }
 return Object.fromEntries(metrics.map(k=>[k,solve(matrix,rewards[k])[0]]));
}
export function sumEnhancements(armor,rune,armorCount=4,runeCount=3){return Object.fromEntries(Object.keys(armor).map(k=>[k,armor[k]*armorCount+rune[k]*runeCount]));}
export function calculate(){
 return [0,5].map(catalysts=>{const armor=expectedEnhancement('armor',catalysts),rune=expectedEnhancement('rune',catalysts);return {catalystsPerEligibleAttempt:catalysts,armor,rune,equippedSet:sumEnhancements(armor,rune),allFiveRunes:sumEnhancements(armor,rune,4,5)};});
}
const f=(n,d=0)=>n.toLocaleString('ko-KR',{minimumFractionDigits:d,maximumFractionDigits:d});
function table(rows){return '| 대상 | 촉매 | 평균 시도 | 골드 | 강화석 | 룬 가루 | 촉매 소비 | 파괴 후 교체 |\n|---|---:|---:|---:|---:|---:|---:|---:|\n'+rows.map(([name,c,r])=>`| ${name} | ${c} | ${f(r.attempts,1)} | ${f(r.gold)} | ${f(r.stone,1)} | ${f(r.dust,1)} | ${f(r.catalysts,1)} | ${f(r.destroyed,2)} |`).join('\n')+'\n';}
export function report(data){
 const [none,max]=data;
 const normal=currencyReward('minecraft:zombie',()=>0.5);normal.dust=.15;
 const boss=currencyReward('rpg:hydra_boss');
 const supply=(req,reward)=>Math.max(...['gold','stone','dust'].map(k=>req[k]/reward[k]));
 const noNormal=supply(none.equippedSet,normal),yesNormal=supply(max.equippedSet,normal);
 const noBoss=supply(none.equippedSet,boss),yesBoss=Math.max(supply(max.equippedSet,boss),max.equippedSet.catalysts/.25);
 return `# RPG v0.5.32 풀강 비용·시간 비교\n\n기준은 캐릭터 1명의 갑옷 4부위 +10, 서로 다른 장착 룬 3개 +5입니다. 룬 종류와 갑옷 세트에 따라 강화 요금은 달라지지 않습니다. 보관함의 룬 5종을 모두 강화하는 경우도 아래에 따로 표시했습니다.\n\n실제 확률표·요금으로 상태전이 연립방정식 E = 비용 + P·E를 풀었습니다. 실패는 같은 단계, 강등은 한 단계 아래, 파괴는 새 +0 장비로 재시작합니다. 단순히 성공률의 역수만 합산하지 않았습니다. 강화 확률·요금은 이번 버전에서 변경하지 않았습니다.\n\n촉매 5개 방식은 갑옷 현재 +5 이상, 룬 현재 +2 이상인 모든 시도에 5개를 사용하는 고정 전략입니다. 그 아래는 무촉매입니다. 최적 전략을 탐색한 결과는 아닙니다.\n\n`+
 table(data.flatMap(x=>[['갑옷 1부위 +10',x.catalystsPerEligibleAttempt,x.armor],['룬 1개 +5',x.catalystsPerEligibleAttempt,x.rune],['갑옷 4부위',x.catalystsPerEligibleAttempt,sumEnhancements(x.armor,x.rune,4,0)],['장착 룬 3개',x.catalystsPerEligibleAttempt,sumEnhancements(x.armor,x.rune,0,3)],['갑옷 4 + 장착 룬 3',x.catalystsPerEligibleAttempt,x.equippedSet],['갑옷 4 + 룬 5종 전체',x.catalystsPerEligibleAttempt,x.allFiveRunes]]))+
 `\n촉매 5개는 장착 세트의 평균 골드 비용을 약 ${f((1-max.equippedSet.gold/none.equippedSet.gold)*100,1)}% 줄입니다. 그래도 최종 구간(갑옷 +9→10, 룬 +4→5)은 성공률 40%·파괴율 3%가 남습니다. 촉매가 파괴를 완전히 막아주지는 않습니다. 갑옷만 보면 4부위 평균 교체는 무촉매 ${f(none.armor.destroyed*4,2)}개, 촉매 5개 전략 ${f(max.armor.destroyed*4,2)}개입니다.\n\n## 시간 환산 — 실측이 아닌 가정\n\n현재 일반 몹 1마리당 골드 8·강화석 1·15% 확률 룬 가루 1, RPG 보스 1마리당 골드 250·강화석 12·룬 가루 6입니다. RPG 보스의 촉매 드롭은 25%이며 바닥 드롭 1개라 파티 인원수만큼 복제되지 않습니다. 보상 대상 파티원도 개인 지갑 재화를 얻지만, 아래는 재화를 합치는 가정을 하지 않았습니다.\n\n| 수급 가정 | 무촉매 | 고위 강화마다 촉매 5개 |\n|---|---:|---:|\n| 일반 몹만, 촉매는 미리 확보 | 약 ${f(noNormal)}마리 | 약 ${f(yesNormal)}마리 |\n| 위 일반 몹을 이동 포함 5초당 1마리 | 약 ${f(noNormal*5/3600,1)}시간 | 약 ${f(yesNormal*5/3600,1)}시간 + 촉매 사전 수급 |\n| RPG 보스만, 촉매도 25% 드롭으로 조달 | 약 ${f(noBoss)}마리 | 약 ${f(yesBoss)}마리 |\n| 위 보스 처치·재소환 포함 5분당 1마리 | 약 ${f(noBoss*5/60,1)}시간 | 약 ${f(yesBoss*5/60,1)}시간 |\n\n갑옷 4부위만 일반 몹 5초당 1마리로 환산하면 무촉매 약 ${f(supply(sumEnhancements(none.armor,none.rune,4,0),normal)*5/3600,1)}시간, 촉매 사전 확보 시 약 ${f(supply(sumEnhancements(max.armor,max.rune,4,0),normal)*5/3600,1)}시간입니다. 룬 3개만 보면 각각 약 ${f(supply(sumEnhancements(none.armor,none.rune,0,3),normal)*5/3600,1)}시간 / ${f(supply(sumEnhancements(max.armor,max.rune,0,3),normal)*5/3600,1)}시간입니다. 함께 파밍하면 갑옷용 재화와 룬용 재화를 동시에 받습니다.

드롭과 강화의 변동 때문에 실제 종료 시각의 정확한 기대값은 아닙니다. 각 평균 요구량을 평균 수급량으로 나눈 뒤 가장 오래 걸리는 자원을 기준으로 한 계획용 근사치입니다. 일반 몹 10초당 1마리면 표의 일반 사냥 시간은 2배, 보스 10분당 1마리면 표의 보스 시간도 2배입니다. 부활 대기·탐색·실패한 전투·장비 교체 제작 재료·초기 장비 및 룬 획득·UI 클릭 시간은 포함하지 않았습니다. 파괴 후 새 +0 장비를 바로 공급할 수 있다는 가정입니다.\n\n촉매를 제작한다면 1개당 네더의 별 1·자수정 조각 4·다이아몬드 2·엔더 진주 2가 추가로 필요합니다. 장착 세트의 평균 ${f(max.equippedSet.catalysts,1)}개 촉매를 전부 제작하려면 대략 네더의 별 ${f(max.equippedSet.catalysts)}개·자수정 ${f(max.equippedSet.catalysts*4)}개·다이아 ${f(max.equippedSet.catalysts*2)}개·진주 ${f(max.equippedSet.catalysts*2)}개입니다. 이 재료 수급 시간은 일반 몹 사냥 시간에 포함되지 않습니다.\n\n## 밸런스 해석\n\n현재는 골드 요금과 파괴 후 갑옷 재제작이 병목입니다. 촉매를 쓰면 강화 실패 부담은 크게 줄지만, 촉매 자체의 수급이 새로운 병목이 됩니다. 무촉매 갑옷 풀강이 룬보다 훨씬 오래 걸립니다. 이 수치는 현행 비용을 그대로 분석한 것이며, 요금 인하·파괴 복구·천장 추가는 적용하지 않았습니다. 실제 사냥 속도를 측정한 뒤 목표 플레이 시간에 맞춰 조정하는 것이 좋습니다.\n\n재현: \`node --experimental-loader ./tests/loader.mjs tools/compare_enhancement_costs.mjs\`\n`;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){const data=calculate();fs.writeFileSync('강화비용_계산결과.json',JSON.stringify(data,null,2)+'\n');fs.writeFileSync('v0532_풀강_비용과_시간.md',report(data));console.log(JSON.stringify(data,null,2));}
