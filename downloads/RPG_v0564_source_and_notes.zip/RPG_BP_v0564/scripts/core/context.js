import { syncChameleonLoadout } from './chameleonProgress.js';
import { JOBS, STARTER_ITEMS, APPRENTICE_SKILLS } from "../data/jobs.js";
import { SKILLS } from "../data/skills.js";
import { getJobId, getSkills, setSkills, getDisabled, setDisabled, setJobId, setIndex } from "./playerData.js";
import { heldItemId } from "./util.js";

// 지금 들고 있는 아이템으로 정해지는 "스킬 사용 상태".
//  - 견습: 계열별 시작 아이템(검/마법책)을 들면 그 계열의 스킬 목록
//  - 2차 이상: 직업 무기를 들었을 때만 직업 스킬 목록
// 해당 없으면 undefined.
export function getContext(player) {
  const currentJobId = getJobId(player);
  let job = JOBS[currentJobId];
  if (!job) {
    if (currentJobId === "necromancer" || currentJobId === "deathlord") {
      setJobId(player, "apprentice");
      setSkills(player, []);
      setDisabled(player, []);
      job = JOBS.apprentice;
    } else {
      return undefined;
    }
  }

  // 기존 저장 데이터도 새 스킬을 습득하도록 호환 마이그레이션합니다.
  const isSwordSaint = job.id === "sword_saint" || job.id === "fallen_sword_saint";
  const autoLearn = job.id === "swordsman"
    ? ["sword_spin", "sword_wave", "sword_flame_spin"]
    : job.id === "fallen_sword_saint"
      ? ["sword_spin", "sword_wave", "sword_flame_spin", "sword_kenho_rando", "sword_moon_dragon", "sword_rush", "fallen_sword_frenzy"]
      : job.id === "sword_saint"
        ? ["sword_spin", "sword_wave", "sword_flame_spin", "sword_kenho_rando", "sword_moon_dragon", "sword_rush", "sword_annihilation"]
        : [];
  // v0.4.83: 이미 카멜레온으로 전직한 월드에도 신규 검 스킬 지급.
  if (job.id === "chameleon") {
    syncChameleonLoadout(player);
    const learned = getSkills(player);
    const wanted = [...learned];
    if (!wanted.includes("chameleon_crimson_dash")) wanted.push("chameleon_crimson_dash");
    if (!wanted.includes("chameleon_ground_slam")) wanted.push("chameleon_ground_slam");
    if (wanted.length !== learned.length) setSkills(player, wanted);
  }
  // 기존 망나니·야수 저장 스킬을 새 기술 구성으로 이전.
  if (job.id === "mangnani" || job.id === "beast") {
    const learned = getSkills(player);
    const revised = [...job.skills];
    if (JSON.stringify(learned) !== JSON.stringify(revised)) setSkills(player, revised);
    const off = getDisabled(player);
    const cleaned = off.filter(id => revised.includes(id));
    if (cleaned.length !== off.length) setDisabled(player, cleaned);
  }
  // Existing Revenants gain the new attacks and use the same attack/buff/ultimate order.
  if(job.id==='revenant'){
    const wanted=[...job.skills];
    if(JSON.stringify(getSkills(player))!==JSON.stringify(wanted)){setSkills(player,wanted);setIndex(player,0);}
    const off=getDisabled(player),clean=off.filter(id=>wanted.includes(id));
    if(clean.length!==off.length)setDisabled(player,clean);
  }
  // v0.4.36~37의 빈 직업 스킬 데이터도 신버전에 자동 등록합니다.
  if (job.id === "blood_mage" || job.id === "hacker" || job.id === "assassin" || job.id === "shadow_assassin" || job.id === "frost_controller" || job.id === "fire_controller" || job.id === "dragon_knight" || job.id === "technomancer" || job.id === "demon" || job.id === "sun_heir" || job.id === "moon_heir") {
    const learned = getSkills(player);
    const wanted = [...job.skills];
    if (JSON.stringify(learned) !== JSON.stringify(wanted)) setSkills(player, wanted);
    const disabled = getDisabled(player);
    const cleaned = disabled.filter(id => wanted.includes(id));
    if (cleaned.length !== disabled.length) setDisabled(player, cleaned);
  }
  // v0.4.16에서 이미 전직한 궁수에게 새 스킬을 자동 지급합니다.
  const isArcher = job.line === "archer" && job.id !== "apprentice";
  if (isArcher) {
    const learned = getSkills(player);
    const allowed = new Set(job.skills);
    const revised = learned.filter(id => id !== "archer_triple" && id !== "archer_rain" && (job.id !== "heavenly_archer" || id !== "archer_fire"));
    for (const id of allowed) if (!revised.includes(id)) revised.push(id);
    if (JSON.stringify(revised) !== JSON.stringify(learned)) setSkills(player, revised);
    const disabled = getDisabled(player);
    const cleanDisabled = disabled.filter(id => id !== "archer_rain" && (job.id !== "heavenly_archer" || id !== "archer_fire"));
    if (cleanDisabled.length !== disabled.length) setDisabled(player, cleanDisabled);
  }
  if (job.id === "apprentice") {
    const item=heldItemId(player);
    if (item === "rpg:apprentice_bow") {
      const learned=getSkills(player);
      const revised=[...learned];
      for(const id of APPRENTICE_SKILLS.archer) if(!revised.includes(id)) revised.push(id);
      if(revised.length!==learned.length)setSkills(player,revised);
    }
  }
  if (autoLearn.length > 0 || isSwordSaint) {
    let learnedNow = getSkills(player);
    let changed = false;
    // 기존 저장 데이터에 남아 있을 수 있는 '발도'를 제거합니다.
    if (isSwordSaint && learnedNow.includes("sword_draw")) {
      learnedNow = learnedNow.filter((id) => id !== "sword_draw");
      changed = true;
    }
    // 섬멸은 검성 전용. 이전 저장 데이터에서 타락검성에게 남은 섬멸을 정리합니다.
    if (job.id === "fallen_sword_saint" && learnedNow.includes("sword_annihilation")) {
      learnedNow = learnedNow.filter((id) => id !== "sword_annihilation");
      changed = true;
    }
    for (const id of autoLearn) {
      if (!learnedNow.includes(id)) {
        learnedNow.push(id);
        changed = true;
      }
    }
    if (changed) setSkills(player, learnedNow);
    if (isSwordSaint) {
      const off = getDisabled(player);
      const remove = job.id === "fallen_sword_saint" ? new Set(["sword_draw", "sword_annihilation"]) : new Set(["sword_draw"]);
      if (off.some((id) => remove.has(id))) setDisabled(player, off.filter((id) => !remove.has(id)));
    }
  }

  const held = heldItemId(player);
  if (!held) return undefined;

  let line;
  let ids;
  if (job.id === "apprentice") {
    line = STARTER_ITEMS[held];
    if (!line) return undefined;
    ids = APPRENTICE_SKILLS[line] ?? [];
  } else {
    // 카멜레온은 두 무기 어느 쪽에서도 배운 스킬만 사용한다.
    if (job.id === "chameleon") {
      if (held !== job.weapon && held !== job.altWeapon) return undefined;
    } else
    // 달의 차크람은 던지는 무기, 달빛 인장은 스킬 전용 입력 도구이다.
    if (job.id === "moon_heir") {
      if (held !== "rpg:moon_heir_focus") return undefined;
    } else if (!job.weapon || held !== job.weapon) return undefined;
    line = job.line;
    ids = job.id === "chameleon"
      ? getSkills(player).filter(id => typeof id === "string" && !!SKILLS[id] &&
          ((id !== "chameleon_crimson_dash" || held === "rpg:chameleon_flame_blade") && (id !== "chameleon_ground_slam" || held === "rpg:chameleon_moon_scythe")))
      : job.skills;
  }

  const learned = getSkills(player);
  const off = getDisabled(player);
  // all : 배운 스킬 전체(설정창에 표시), skills : 그중 켜 둔 스킬(전환/발동 대상)
  const all = ids.filter((id) => learned.includes(id));
  return { job, line, held, all, skills: all.filter((id) => !off.includes(id)) };
}
