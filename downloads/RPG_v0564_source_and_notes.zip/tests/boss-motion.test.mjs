import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,players,world,events,intervals,timeouts,system} from './minecraftMock.mjs';
import {playBossMotion,registerBossMotion} from '../RPG_BP_v0564/scripts/core/bossMotion.js';
import {registerGolemBoss} from '../RPG_BP_v0564/scripts/core/golemBoss.js';
import {registerCyclopsBoss} from '../RPG_BP_v0564/scripts/core/cyclopsBoss.js';
const read=p=>JSON.parse(fs.readFileSync(new URL('../'+p,import.meta.url)));
const names=['rock_golem_boss','cyclops_boss','tech_block_golem_boss','hydra_boss'];
const animations=read('RPG_RP_v0564/animations/rpg_boss_motion.animation.json').animations;
function boss(name){const p=player(name+Math.random(),1,{typeId:'rpg:'+name,health:1000,maxHealth:1000}),calls=[];p.playAnimation=(...a)=>calls.push(a);return {p,calls};}
test('all boss motions resolve to actual geometry bones, walk is speed gated and time uses moving distance',()=>{
 for(const name of names){const desc=read('RPG_RP_v0564/entity/'+name+'.entity.json')['minecraft:client_entity'].description,g=read('RPG_RP_v0564/models/entity/'+name+'.geo.json')['minecraft:geometry'][0],bones=new Set(g.bones.map(b=>b.name));
 assert.deepEqual(desc.scripts.animate,['idle',{walk:'query.modified_move_speed > 0.01'}]);for(const id of Object.values(desc.animations)){assert.ok(animations[id],id);for(const bone of Object.keys(animations[id].bones))assert.ok(bones.has(bone),name+':'+bone);}
 assert.ok(JSON.stringify(animations[desc.animations.walk]).includes('query.modified_distance_moved'));assert.equal(animations[desc.animations.idle].loop,true);assert.ok(animations[desc.animations.melee].animation_length>0);
 }
});
test('tech golem is 1.5x with grounded feet, scaled collision, valid UVs and original combat values',()=>{
 const e=read('RPG_BP_v0564/entities/tech_block_golem_boss.json')['minecraft:entity'],g=read('RPG_RP_v0564/models/entity/tech_block_golem_boss.geo.json')['minecraft:geometry'][0],cs=g.bones.flatMap(b=>b.cubes??[]);assert.deepEqual(e.components['minecraft:collision_box'],{width:5.1,height:7.5});assert.equal(Math.min(...cs.map(c=>c.origin[1])),0);assert.equal(Math.max(...cs.map(c=>c.origin[1]+c.size[1])),114);assert.equal(cs[0].size[0],24);
 for(const c of cs)for(const face of Object.values(c.uv)){assert.ok(Array.isArray(face.uv));assert.equal(face.uv.length,2);assert.ok(face.uv[0]+face.uv_size[0]<=128);}
 assert.equal(e.components['minecraft:health'].value,1400);assert.equal(e.components['minecraft:attack'].damage,17);assert.equal(e.components['minecraft:experience_reward'].on_death,850);
});
test('hydra articulation retains its full cube mesh and all parent references are valid',()=>{
 const g=read('RPG_RP_v0564/models/entity/hydra_boss.geo.json')['minecraft:geometry'][0],bones=new Set(g.bones.map(b=>b.name));assert.equal(g.bones.flatMap(b=>b.cubes??[]).length,6399);for(const b of g.bones)if(b.parent)assert.ok(bones.has(b.parent));for(const id of ['head_left','head_center','head_right','tail'])assert.ok(g.bones.some(b=>b.parent===id&&b.cubes?.length));
});
test('native effective hits play once; players, dead bosses and unsupported APIs are harmless',()=>{
 registerBossMotion();for(const name of names){const {p,calls}=boss(name);const ev={hurtEntity:player('victim'),damage:5,damageSource:{cause:'entityAttack',damagingEntity:p}};for(const fn of events.entityHurt.listeners)fn(ev);assert.equal(calls.length,1);for(const fn of events.entityHurt.listeners)fn(ev);assert.equal(calls.length,1);assert.equal(calls[0][0],'animation.rpg.'+name+'.melee');}
 const dead=boss('rock_golem_boss');dead.p.health=0;assert.equal(playBossMotion(dead.p),false);assert.equal(playBossMotion(player('normal')),false);const noapi=boss('cyclops_boss');noapi.p.playAnimation=()=>{throw Error('no rendering API');};assert.equal(playBossMotion(noapi.p),false);
});
test('special windups override melee and protect slam from wave/melee restarts until recovery',()=>{
 const {p,calls}=boss('rock_golem_boss');assert.equal(playBossMotion(p,'slam'),true);assert.equal(playBossMotion(p,'melee'),false);assert.equal(playBossMotion(p,'wave'),false);system.currentTick+=25;assert.equal(playBossMotion(p,'wave'),true);assert.equal(calls.length,2);assert.equal(playBossMotion(boss('hydra_boss').p,'slam'),false);
});
test('rock slam and cyclops stomp animate before their unchanged delayed damage',()=>{
 players.length=0;system.currentTick=0;const rock=boss('rock_golem_boss'),cyclops=boss('cyclops_boss'),victim=player('boss-target',1,{health:100,maxHealth:100,location:{x:0,y:64,z:1.5}});victim.damage=[];victim.applyDamage=n=>{victim.damage.push(n);return true;};
 const dim={id:'minecraft:overworld',getEntities:q=>q.type===rock.p.typeId?[rock.p]:q.type===cyclops.p.typeId?[cyclops.p]:[],spawnParticle(){},playSound(){}};for(const p of [victim,rock.p,cyclops.p])p.dimension=dim;players.push(victim);world.getDimension=name=>{if(name==='overworld')return dim;throw Error('unloaded');};cyclops.p.getViewDirection=()=>({x:0,y:0,z:1});
 const n=intervals.length;registerGolemBoss();registerCyclopsBoss();const timers=intervals.slice(n);for(const fn of timers)fn();system.currentTick=100;const t=timeouts.length;for(const fn of timers)fn();assert.ok(rock.calls[0][0].endsWith('.slam'));assert.ok(cyclops.calls[0][0].endsWith('.slam'));assert.deepEqual(victim.damage,[]);for(const fn of timeouts.slice(t))fn();assert.deepEqual(victim.damage,[11.25,18]);
 const slab=animations['animation.rpg.rock_golem_boss.slam'].bones.left_arm.rotation,stomp=animations['animation.rpg.cyclops_boss.slam'].bones.left_arm.rotation;assert.deepEqual(slab['0.7'],[35,0,0]);assert.deepEqual(stomp['0.8'],[35,0,0]);
});
