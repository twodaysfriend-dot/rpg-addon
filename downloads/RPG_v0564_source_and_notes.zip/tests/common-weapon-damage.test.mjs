import test from 'node:test';
import assert from 'node:assert/strict';
import {ItemStack,player,EquipmentSlot,events,system} from './minecraftMock.mjs';
import {applyCommonWeaponBonus,commonWeaponFactor} from '../RPG_BP_v0564/scripts/core/commonWeaponDamage.js';
import {RARITY_KEY} from '../RPG_BP_v0564/scripts/data/grades.js';
import {WEAPON_LEVEL_KEY} from '../RPG_BP_v0564/scripts/data/upgrades.js';
import {registerLifesteal} from '../RPG_BP_v0564/scripts/core/lifesteal.js';
import {registerWarGod,BLACK_FLASH_KEY} from '../RPG_BP_v0564/scripts/skills/warGod.js';
import {scriptedHit,scriptKiller} from '../RPG_BP_v0564/scripts/core/combatContext.js';
import {readRuneBag,writeRuneBag,addRuneRecord,equipRune} from '../RPG_BP_v0564/scripts/core/runeInventory.js';
registerLifesteal();registerWarGod();let serial=0;
const emit=ev=>{for(const fn of events.entityHurt.listeners)fn(ev);};
function scene(){const id='common'+serial++,p=player(id,1,{health:10,maxHealth:1000}),t=player(id+'mob',1,{typeId:'minecraft:zombie',health:988,maxHealth:1000}),i=new ItemStack('rpg:common_redmoon_blade');i.setDynamicProperty(RARITY_KEY,6);i.setDynamicProperty(WEAPON_LEVEL_KEY,10);p.equipment.set(EquipmentSlot.Mainhand,i);return {p,t,ev:{damage:12,hurtEntity:t,damageSource:{cause:'entityAttack',damagingEntity:p}}};}
test('mythic +10 base melee has the proposed base-grade plus additive-upgrade amount',()=>{
 const {p,t,ev}=scene();assert.equal(commonWeaponFactor(p.equipment.get(EquipmentSlot.Mainhand)),33/12);assert.equal(applyCommonWeaponBonus(ev),33);assert.equal(t.health,967);
});
test('armor/resistance effective hit scaling is retained instead of applying unmitigated flat bonus',()=>{
 const {t,ev}=scene();ev.damage=6;t.health=994;assert.equal(applyCommonWeaponBonus(ev),16.5);assert.equal(t.health,983.5);
});
test('normal unenhanced weapons, spells, fixed/scripted damage and protected targets receive no bonus',()=>{
 for(const mode of ['normal','scripted','spell','friend','npc','player']){const {p,t,ev}=scene();if(mode==='normal')p.equipment.set(EquipmentSlot.Mainhand,new ItemStack('rpg:common_redmoon_blade'));if(mode==='spell')ev.damageSource.cause='magic';if(mode==='friend'){t.typeId='minecraft:player';p.getTags=()=>['rpg_team_test'];t.hasTag=()=>true;}if(mode==='npc')t.typeId='rpg:gpt_guide';if(mode==='player'){t.typeId='minecraft:player';t.getGameMode=()=> 'creative';}const before=t.health;assert.equal(applyCommonWeaponBonus(ev,mode==='scripted'),12);assert.equal(t.health,before);}
 const {p,t,ev}=scene();scriptedHit(t,p,()=>{applyCommonWeaponBonus(ev);return true;});assert.equal(t.health,988);
});
test('lifesteal receives actual bonus once and Black Flash multiplies the enhanced effective hit by ten',()=>{
 const {p,t,ev}=scene(),b=readRuneBag(p),r=addRuneRecord(b,'absorption',10,6);writeRuneBag(p,b);equipRune(p,r.uid,0);emit(ev);assert.equal(t.health,967);assert.ok(Math.abs(p.health-(10+33*.24))<1e-8);
 const s=scene();s.p.setDynamicProperty(BLACK_FLASH_KEY,true);emit(s.ev);assert.equal(s.t.health,670);assert.equal(s.p.getDynamicProperty(BLACK_FLASH_KEY),undefined);
});
test('lethal bonus caps actual lifesteal and attributes manual kill to the attacker',()=>{
 const {p,t,ev}=scene();t.health=5;const b=readRuneBag(p),r=addRuneRecord(b,'absorption',10);writeRuneBag(p,b);equipRune(p,r.uid,0);emit(ev);assert.equal(t.health,0);assert.equal(scriptKiller(t),p);assert.ok(Math.abs(p.health-(10+17*.12))<1e-8);
});
