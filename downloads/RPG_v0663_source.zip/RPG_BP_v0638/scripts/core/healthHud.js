import { HudElement, HudVisibility } from '@minecraft/server';

// Seven three-row tiers, twenty health points in a vanilla row.
const TIER_KEYS = 'roygcbp';
const HEART_SLOTS = 30;
const HP_PER_LAYER = 2 * HEART_SLOTS;
const HIDDEN_FRAME = '_'.repeat(HEART_SLOTS);
const visibility = new Map();

export function heartFrame(player) {
  const mode = String(player.getGameMode?.()).toLowerCase();
  const hp = player.getComponent('minecraft:health');
  if (mode === 'creative' || mode === 'spectator' || !hp ||
      !Number.isFinite(hp.currentValue) || !Number.isFinite(hp.effectiveMax) || hp.effectiveMax <= 0) {
    return HIDDEN_FRAME;
  }
  const capacity = Math.min(HEART_SLOTS, Math.ceil(hp.effectiveMax / 2));
  const current = Math.ceil(Math.max(0, Math.min(hp.currentValue, hp.effectiveMax, HP_PER_LAYER * TIER_KEYS.length)));
  const layer = Math.max(0, Math.ceil(current / HP_PER_LAYER) - 1);
  const remaining = current - layer * HP_PER_LAYER;
  const full = Math.floor(remaining / 2);
  const half = remaining % 2 ? String(layer + 1) : '';
  const filled = TIER_KEYS[layer].repeat(full) + half;
  const visible = layer === 0 ? filled.padEnd(capacity, '0') : filled;
  return visible.padEnd(HEART_SLOTS, '_');
}

// Each cell maps to a precolored sprite in font/glyph_E8.png.
const GLYPH_KEYS = '0roygcbp1234567';
export function heartRows(frame) {
  const rows = [];
  for (let start = 0; start < HEART_SLOTS; start += 10) {
    const cells = frame.slice(start, start + 10).replace(/_/g, '');
    if (cells) rows.unshift(Array.from(cells, key => String.fromCharCode(0xe800 + GLYPH_KEYS.indexOf(key))).join(''));
  }
  return rows;
}

export function syncHudVisibility(player, frame, gearLabel) {
  const previous = visibility.get(player.id);
  const customHealth = Boolean(frame) && frame !== HIDDEN_FRAME;
  const customItem = Boolean(gearLabel);
  const display = player.onScreenDisplay;
  if (!previous) display.setHudVisibility(HudVisibility.Hide, [HudElement.Armor,HudElement.StatusEffects]);
  if (previous?.customHealth !== customHealth) {
    display.setHudVisibility(customHealth ? HudVisibility.Hide : HudVisibility.Reset, [HudElement.Health]);
  }
  if (previous?.customItem !== customItem) {
    display.setHudVisibility(customItem ? HudVisibility.Hide : HudVisibility.Reset, [HudElement.ItemText,HudElement.ToolTips]);
  }
  visibility.set(player.id, {customHealth,customItem});
}

export function clearHealthHud(id) { visibility.delete(id); }
