# RPG v0.6.63 · 체력과 선택 기술 표시

1번 칸 무기를 들면 장비 등급과 이름 아래에 선택 기술과 재사용 대기시간이 표시됩니다. 기술을 바꾸면 이름이 즉시 갱신됩니다. 장비의 마법 부여와 잠금 정보는 인벤토리에서 확인할 수 있습니다.

하트와 현재·최대 HP를 기본 액션바에 함께 표시합니다. 하트는 한 줄에 10칸, 한 색상에 최대 세 줄입니다. 62 HP에서는 주황 한 칸, 122 HP에서는 노란 한 칸이 보입니다.

Bedrock 1.21.100 이상에서 행동 팩 두 개와 리소스 팩을 모두 v0.6.63으로 활성화하세요. 자동 테스트에서는 1번 칸에 연결한 고대 마공학 대검을 들고 미카엘 기술을 전환하는 경우와 하트 색상 경계를 확인했습니다. 모바일 기기에서의 렌더링은 별도 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0663
```
