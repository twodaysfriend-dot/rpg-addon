import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0638';
const base=root+'/RPG_BP_v0638/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}


let gear=0;
const stats=await load('scripts/core/stats.js',{getEquipmentBonuses:()=>({health:gear})});
const check=vit=>{
 const applied=[];let removed=0;
 const p={getDynamicProperty:k=>k==='rpg:stat_values'?JSON.stringify({str:5,mag:5,int:5,vit}):undefined,addEffect:(id,ticks,options)=>applied.push({id,ticks,...options}),getEffect:()=>({}),removeEffect:()=>removed++};
 stats.applyVitality(p);return {hp:20+(applied.length?4*(applied[0].amplifier+1):0),applied,removed};
};
assert.equal(check(5).hp,20);assert.equal(check(5).removed,1);
assert.equal(check(50).hp,120);assert.equal(check(50).applied[0].showParticles,false);
assert.equal(stats.VITALITY_HP_PER_POINT*45,100);
let previous=20;for(let vit=5;vit<=100;vit++){const n=check(vit).hp;assert.ok(n>=previous);previous=n;}
gear=20;assert.equal(check(50).hp,140);gear=0;assert.equal(check(50).hp,120);
console.log('Vitality: 5=20 HP, 50=120 HP without gear; monotonic growth, gear added separately, removing gear recomputes without stacking; passive health particles hidden');

const healthHud=await load('scripts/core/healthHud.js',{
 HudElement:{Health:'health',Armor:'armor',StatusEffects:'effects',ItemText:'item',ToolTips:'tips'},
 HudVisibility:{Hide:'hide',Reset:'reset'},
});
const hp={effectiveMax:148,currentValue:148};
const changes=[];
const player={id:'hud',getGameMode:()=> 'survival',getComponent:()=>hp,
 onScreenDisplay:{setHudVisibility:(...args)=>changes.push(args)}};
const read=(current,max)=>{
 hp.effectiveMax=max;
 hp.currentValue=current;
 return healthHud.heartFrame(player);
};
assert.equal(read(148,148),'y'.repeat(14)+'_'.repeat(16));
assert.equal(read(9,20),'rrrr1'+'0'.repeat(5)+'_'.repeat(20));
assert.equal(read(21,21),'r'.repeat(10)+'1'+'_'.repeat(19));
assert.equal(read(40,40),'r'.repeat(20)+'_'.repeat(10));
assert.equal(read(0,420),'0'.repeat(30));
const colors='roygcbp';
for(let layer=0;layer<colors.length;layer++){
 const end=(layer+1)*60,base=colors[layer];
 assert.equal(read(end,420),base.repeat(30));
 if(layer===6)break;
 const next=colors[layer+1],half=String(layer+2);
 assert.equal(read(end+.25,420),half+'_'.repeat(29));
 assert.equal(read(end+2,420),next+'_'.repeat(29));
 assert.equal(read(end+20,420),next.repeat(10)+'_'.repeat(20));
 assert.equal(read(end+40,420),next.repeat(20)+'_'.repeat(10));
 assert.equal(read(end+1,420),half+'_'.repeat(29));
 assert.equal(read(end,420),base.repeat(30));
}
assert.equal(read(62,62),'o'.padEnd(30,'_'));
assert.equal(read(122,148),'y'.padEnd(30,'_'));
assert.equal(read(121,148),'3'.padEnd(30,'_'));
assert.equal(read(120,148),'o'.repeat(30));
assert.equal(read(500,500),'p'.repeat(30));
player.getGameMode=()=> 'creative';
const hidden='_'.repeat(30);
assert.equal(healthHud.heartFrame(player),hidden);
healthHud.syncHudVisibility(player,'r'.repeat(30),'equipment');
const before=changes.length;
healthHud.syncHudVisibility(player,'r'.repeat(30),'equipment');
assert.equal(changes.length,before);
healthHud.syncHudVisibility(player,hidden,'');
assert.deepEqual(changes.slice(-2).map(([mode,e])=>[mode,...e]),[['reset','health'],['reset','item','tips']]);
const rp=root+'/RPG_RP_v0638/';
const ui=JSON.parse(fs.readFileSync(rp+'ui/hud_screen.json'));
player.getGameMode=()=> 'survival';
assert.ok(!ui.hud_actionbar_text.visible);
assert.ok(!ui.root_panel);
const atlas=fs.readFileSync(rp+'font/glyph_E8.png');
assert.equal(atlas.readUInt32BE(16),256);
assert.equal(atlas.readUInt32BE(20),256);
assert.equal(healthHud.heartRows(read(62,148)).join(''),'\ue802');
assert.equal(healthHud.heartRows(read(122,148)).join(''),'\ue803');
assert.deepEqual(Array.from(healthHud.heartRows(read(148,148))),['\ue803'.repeat(4),'\ue803'.repeat(10)]);
console.log('Native actionbar heart glyphs, three-row cap, top row order, seven tiers and half-hearts passed');
