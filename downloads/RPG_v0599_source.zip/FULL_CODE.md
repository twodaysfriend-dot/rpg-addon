# 변경/신규 파일 전체 코드

## RPG_BP_v0597/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon BP v0.5.99",
    "description": "RPG v0.5.99 · 밤 RPG 스폰 감소·룬 강화 및 평타 피해·강화 비용 조정",
    "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
    "version": [
      0,
      5,
      99
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "data",
      "uuid": "cc5d6e3c-5285-4787-8a59-a8e2856f2aec",
      "version": [
        0,
        5,
        99
      ]
    },
    {
      "type": "script",
      "language": "javascript",
      "uuid": "c41fa3d6-d82c-4a54-9783-68f92fe633a1",
      "entry": "scripts/gameplayEntry.js",
      "version": [
        0,
        5,
        99
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
      "version": [
        0,
        5,
        99
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    },
    {
      "module_name": "@minecraft/server-ui",
      "version": "2.0.0"
    }
  ]
}
```

## RPG_BP_v0597/scripts/core/commonWeaponDamage.js

```javascript
import {runeMeleeBonus} from './runeMelee.js';
import {setCombatHealth} from './combatContext.js';
import {EquipmentSlot,EntityDamageCause} from '@minecraft/server';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {classWeapon} from '../data/classWeapons.js';
import {GRADE_MULTIPLIERS,itemGrade} from '../data/grades.js';
import {upgradeLevel} from '../data/upgrades.js';
import {currentScriptHit,scriptedHit,rememberScriptKiller,noteManualDamage} from './combatContext.js';
import {areAllies} from './social.js';
import {CONFIG} from '../config.js';
export function commonWeaponFactor(item){
 const c=classWeapon(item?.typeId),w=COMMON_WEAPONS.find(w=>w.id===item?.typeId)??c;if(!w)return 1;
 // minecraft:damage adds to the player's one point native unarmed damage.
 return (1+w.damage*(c?1:GRADE_MULTIPLIERS[itemGrade(item)])+upgradeLevel(item,'weapon'))/(1+w.damage);
}
export function applyCommonWeaponBonus(ev,scripted=false){
 const p=ev.damageSource?.damagingEntity,t=ev.hurtEntity;
 if(scripted||p?.typeId!=='minecraft:player'||!t||p.id===t.id||ev.damageSource?.cause!==EntityDamageCause.entityAttack||currentScriptHit(p,t)||!(ev.damage>0)||areAllies(p,t))return ev.damage;
 if(['rpg:gpt_guide','minecraft:armor_stand','minecraft:item','minecraft:xp_orb'].includes(t.typeId)||t.typeId.startsWith('rpg:hito_'))return ev.damage;
 if(t.typeId==='minecraft:player'&&(!CONFIG.pvp||['creative','spectator'].includes(String(t.getGameMode?.()).toLowerCase())))return ev.damage;
 const item=p.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand);
 if(!classWeapon(item?.typeId)&&!COMMON_WEAPONS.some(w=>w.id===item?.typeId))return ev.damage;
 const factor=commonWeaponFactor(item)*(1+runeMeleeBonus(p));
 if(factor<=1)return ev.damage;
 const hp=t.getComponent('minecraft:health');if(!(hp?.currentValue>0))return ev.damage;
 // Add the same-hit proportional bonus AFTER native mitigation, without a second
 // armor pass or a second hit lost to invulnerability. Enchants/critical/Strength
 // inherit that hit's effective scaling. This is only a basic melee hit hook.
 const bonus=ev.damage*(factor-1),before=hp.currentValue,actual=Math.min(before,bonus);
 if(actual>=before)rememberScriptKiller(p,t);
 scriptedHit(t,p,()=>{setCombatHealth(t,p,hp,Math.max(0,before-actual));noteManualDamage(p,t,actual,{incomingScaled:true});return true;});
 return ev.damage+bonus;
}
```

## RPG_BP_v0597/scripts/core/nightMobs.js

```javascript
import {world,system,EntityInitializationCause} from '@minecraft/server';
import {ZONED_MOBS} from '../data/huntingZones.js';

// 밤 몬스터 정리: 밤에 자연 스폰되는 바닐라 적대 몬스터의 절반만 남기고,
// 남은 몬스터는 표식을 달았다가 아침이 되면 전부 제거해 렉을 줄입니다.
// 사냥터의 밤 RPG 몬스터는 기존보다 절반인 유지율 25%를 적용합니다.
// 던전 몬스터·보스·알로 직접 소환한 몬스터·이름표가 붙은 몬스터는 건드리지 않습니다.
const TAG='rpg_night_spawn',ROLLED='rpg_night_rolled';
const SPAWN_KEEP_RATE=0.5; // 바닐라 유지
const RPG_SPAWN_KEEP_RATE=0.25; // 기존 RPG 유지율 0.5의 절반
const NIGHT_START=13000,NIGHT_END=23000;
const HOSTILE=new Set(['minecraft:zombie','minecraft:zombie_villager','minecraft:husk','minecraft:drowned','minecraft:skeleton','minecraft:stray','minecraft:bogged','minecraft:creeper','minecraft:spider','minecraft:witch','minecraft:phantom','minecraft:slime']);
let registered=false,wasNight=null;

const isNight=()=>{const t=world.getTimeOfDay();return t>=NIGHT_START&&t<NIGHT_END;};
const valid=e=>{try{return Boolean(e?.isValid);}catch{return false;}};
function naturalSpawn(cause){
  if(EntityInitializationCause&&EntityInitializationCause.Spawned!==undefined)return cause===EntityInitializationCause.Spawned;
  return String(cause)==='Spawned';
}
function purge(){
  for(const id of ['overworld']){
    try{for(const e of world.getDimension(id).getEntities({tags:[TAG]}))try{e.remove();}catch{}}catch{}
  }
}
export function registerNightMobs(){
  if(registered)return;registered=true;
  world.afterEvents.entitySpawn.subscribe(ev=>{
    try{
      const e=ev.entity;
      if(valid(e)&&ZONED_MOBS.has(e.typeId)&&e.dimension.id==='minecraft:overworld'&&isNight()){
        // 사냥터 판정 및 교체 소환 뒤 1회 추첨. 알/던전은 PROCESSED 태그가 없어 제외.
        system.runTimeout(()=>{try{
          if(!valid(e)||e.hasTag(ROLLED)||e.hasTag('rpg_dungeon_mob')||!e.hasTag('rpg_hunt_zoned')||e.nameTag)return;
          e.addTag(ROLLED);
          if(!isNight()||Math.random()>=RPG_SPAWN_KEEP_RATE)e.remove();else e.addTag(TAG);
        }catch{}},3);
        return;
      }
      if(!valid(e)||!HOSTILE.has(e.typeId)||!naturalSpawn(ev.cause))return;
      if(e.dimension.id!=='minecraft:overworld'||!isNight())return;
      if(e.nameTag)return;
      if(Math.random()>=SPAWN_KEEP_RATE){system.run(()=>{try{if(valid(e))e.remove();}catch{}});return;}
      e.addTag(TAG);
    }catch{}
  });
  // 아침이 되는 순간 표식이 붙은 몬스터를 모두 제거
  system.runInterval(()=>{
    try{
      const night=isNight();
      if(wasNight===true&&!night)purge();
      wasNight=night;
    }catch{}
  },20);
  // 로드되지 않았다가 아침에 불려온 몬스터와 남은 표식 몬스터 정리
  world.afterEvents.entityLoad.subscribe(ev=>{try{if(!isNight()&&valid(ev.entity)&&ev.entity.hasTag(TAG))ev.entity.remove();}catch{}});
  system.runInterval(()=>{try{if(!isNight())purge();}catch{}},200);
}
```

## RPG_BP_v0597/scripts/core/rpgKnowledge.js

```javascript
import {dungeonMonsterLevel} from '../data/monsterLevels.js';
import {PROMOTION_RATES,GRADE_MULTIPLIERS,ARMOR_GRADE_HP} from '../data/grades.js';
import {RARITIES,itemRarity,runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {skillScalingInfo} from '../data/skillScaling.js';
import {isBalanceQuestion,isHiddenPromotionQuestion} from './assistantPolicy.js';
import {JOBS,APPRENTICE_SKILLS} from '../data/jobs.js';
import {SKILLS} from '../data/skills.js';
import {LINE_NOTES,SKILL_NOTES} from '../data/skillGuide.js';
import {JOB_TRIALS} from '../data/jobTrials.js';
import {CRAFTING_RECIPES} from '../data/crafting.js';
import {RUNES,ARMOR_SETS} from '../data/equipment.js';
import {upgradedRune,RUNE_MAX,ARMOR_MAX,MAX_CATALYSTS,upgradeCost,enhancementRates} from '../data/upgrades.js';
import {DUNGEON,DUNGEON_TIERS,clearRewardForTier,netheriteChanceForTier} from '../data/dungeons.js';
import {CONFIG} from '../config.js';
import {defaultDamageTypeFor} from './stats.js';
export const QUESTION_LIMIT=200;
export const UNKNOWN_ANSWER='이 애드온의 직업·스킬·룬·갑옷·제작·강화·던전·성장 정보만 안내합니다. 도감에 없는 내용은 확인할 수 없습니다. 예: 월룡륜미 범위 / 검사 전직 / 생명의 룬 / 샌드백 제작';
export const normalizeQuestion=s=>String(s??'').normalize('NFKC').toLowerCase().replace(/§./g,'').replace(/[^a-z0-9가-힣]/g,'');
const clean=s=>String(s??'').replace(/§./g,'').replace(/[\u0000-\u0008\u000b-\u001f]/g,'');
const bossName=id=>({rock_golem_boss:'바위 골렘',cyclops_boss:'외눈 거인',hydra_boss:'히드라',tech_block_golem_boss:'마공학 골렘'}[id]??'던전 보스');
const percent=n=>Number((n*100).toFixed(3))+'%';
function runeEffects(r){
 const a=[];if(r.physical)a.push('물리 피해 +'+percent(r.physical-1));if(r.magic)a.push('마법 피해 +'+percent(r.magic-1));
 if(r.health)a.push('최대 HP +'+r.health);if(r.manaRegenPercent)a.push('초당 최대 MP의 '+percent(r.manaRegenPercent)+' 추가 회복');
 if(r.lifesteal)a.push('준 피해의 '+percent(r.lifesteal)+' HP 회복');if(r.ward)a.push('저항 '+(r.wardAmplifier+1)+'단계 유지');return a.join(', ');
}
const EFFECT_GROUPS=[
 {id:'damagebuff',title:'피해 증가·공격 강화 기술',match:q=>/딜뻥|공증|뎀증|힘버프|공격력버프|((데미지|대미지|피해|공격력|딜).*(버프|증가|강화|올려|높여))/.test(q),groups:[
 ['힘 효과를 주는 기술',['holy_sword','fist_stance','beast_berserk','blood_awaken','fire_armor','fire_emperor','sun_descent']],
 ['평타·후속 타격을 강화하는 기술',['war_god_black_flash','sun_slash','fist_strong','berserker_execute','assassin_stealth','dragon_triple_strike']],
 ['적이 받는 피해를 늘리는 기술',['assassin_mark','fallen_orb','berserker_charge']],
 ['적에게 힘을 주는 예외: 자가 공격 강화용 지원기가 아님',['demon_contract']]]},
 {id:'healing',title:'회복·흡혈 기술',match:q=>/회복|힐|치유|흡혈/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|있는|주는/.test(q),groups:[['회복·재생·흡혈 효과',['holy_heal','holy_orb','angel_bless','angel_zone','demon_vampirism','fallen_sword_frenzy','beast_berserk','moon_moonlight','sun_descent']]]},
 {id:'defense',title:'보호·방어 강화 기술',match:q=>/보호막|방어버프|저항버프|피해흡수/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['보호·저항·피해 흡수',['holy_shield','holy_orb','angel_bless','angel_zone','fallen_shield','fist_stance','fire_armor','sun_blessing','sun_descent','demon_contract']]]},
 {id:'control',title:'적 제어 기술',match:q=>/기절|동결|빙결|속박|둔화|cc/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['제어 효과를 갖는 기술 예시',['fist_face','frost_grasp','frost_absolute','blood_bind','tech_prison','sage_zero','moon_fullwave','sun_slash']]]}
];
function effectKnowledge(q){
 const g=EFFECT_GROUPS.find(g=>g.match(q));if(!g)return undefined;
 
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder&&j.id!=='chameleon');
 const groups=g.groups.map(([title,ids])=>title+'\n'+ids.filter(id=>SKILLS[id]&&SKILL_NOTES[id]).map(id=>{
 const skill=SKILLS[id],owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name).join('·');
 return '• '+skill.name+' ('+owners+'): '+SKILL_NOTES[id].split(/\.\s+(?=[가-힣A-Z])/)[0]+'.';
 }).join('\n')).join('\n\n');
 return Object.freeze({id:'effect:'+g.id,title:g.title,aliases:[],body:groups+'\n\n효과별 안내이며 강함·티어 순위가 아닙니다. 개별 기술명으로 상세 수치·조건을 확인하세요.',source:'data/skills.js · data/skillGuide.js · data/jobs.js'});
}
const PUBLIC_JOBS=new Set(['swordsman','mage','archer','fighter','cleric']);
let catalog;
export function knowledgeEntries(){
 if(catalog)return catalog;
 const entries=[];
 const add=(id,title,aliases,body,source)=>entries.push(Object.freeze({id,title,aliases:Object.freeze([...new Set([title,...aliases].map(normalizeQuestion).filter(x=>x.length>=2))]),body:clean(body),source}));
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder),active=new Set([...jobs.flatMap(j=>j.skills),...Object.values(APPRENTICE_SKILLS).flat()]);
 for(const id of active){
  const s=SKILLS[id];if(!s||!SKILL_NOTES[id])continue;
  const owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name);
  add('skill:'+id,s.name,[id,s.name.replace(/\s*\([^)]*\)/g,''),s.name.replace(/\s*제작$/,'')],`피해 보정: ${skillScalingInfo(id)}\n기본 MP ${s.mana} / 쿨 ${s.cooldown/20}초\n${SKILL_NOTES[id]}\n사용 직업: ${owners.join('·')}\n피해 수치는 스탯·힘 버프·장비 보정 전입니다.`, 'data/skills.js · data/skillGuide.js');
 }
 for(const j of jobs){
  const publicPromotion=PUBLIC_JOBS.has(j.id);
  const trial=publicPromotion?JOB_TRIALS[j.id]:undefined,condition=trial?`레벨 ${trial.level}\n`+['all','any'].filter(k=>trial[k]).map(k=>trial[k].map(c=>`${c.label} ${c.need}`).join(k==='all'?' + ':' 또는 ')).join('\n'):'견습 시작 직업';
  const from=trial?.allowedFrom?.map(id=>JOBS[id].name).join('·')??(j.hidden&&j.parent===null?'아무 2차 이상 직업':JOBS[j.parent]?.name??'없음');
  const type=defaultDamageTypeFor({getDynamicProperty:()=>j.id});
  const special=!publicPromotion?'전직 방법·조건은 공개하지 않습니다.':j.id==='hacker'?'전직: 로토와 23회 대화 후 퀴즈 정답. 월드 최초 정답자 1명만 전직 가능. 직업·레벨 제한 없음.':`직전 직업: ${from}\n전직 조건: ${condition}`;
  const shrine=trial?.shrine?`\n전직 장소: 천체 신전의 ${trial.shrine==='sun'?'해 제단·낮':'달 제단·밤'} 4칸 안. /rpg:temple에서 위치 확인.`:'';
  const extra='';
  add('job:'+j.id,j.name,[j.id],`${special}${extra}${shrine}\n기본 피해 계열: ${type==='magic'?'마력(마법)':'근력(물리)'}. 개별 기술에 다른 피해 판정이 있으면 해당 판정을 따릅니다.\n보유 기술: ${j.skills.map(id=>SKILLS[id]?.name??id).join('·')||'시작 장비에 따라 사용'}\n${j.id==='chameleon'?LINE_NOTES.chameleon:''}`,'data/jobs.js · data/jobTrials.js · data/skillGuide.js');
 }
 for(const [id,r]of Object.entries(RUNES)){
  const recipe=CRAFTING_RECIPES.find(c=>c.id==='rpg:rune_'+id);
  add('rune:'+id,r.name,[r.name.replace('의 ',''),'rune_'+id],`등급: 일반~신화, 강화와 별개인 합성 승급. 힘·비전 룬은 +1부터 공용·직업 무기 근접 평타에도 추가 피해를 줍니다. 두 룬의 평타 추가 피해율은 합산합니다. 아래는 일반 등급 기준\n기본: ${runeEffects(upgradedRune(r,0))}\n최대 +${RUNE_MAX}: ${runeEffects(upgradedRune(r,RUNE_MAX))}\n/rpg:runes 보관함에서 장착해야 효과를 받습니다.\n${recipe?.text??'룬 드롭으로 획득'}`,'data/equipment.js · data/upgrades.js · data/crafting.js');
 }
 for(const [id,a]of Object.entries(ARMOR_SETS))add('armor:'+id,a.name+' 갑옷',[a.name,id,...(id==='abyssal'?['심연갑옷','상위갑옷','네더라이트이상']:[])],`${a.description}\n등급: 일반~신화. 부위당 등급 추가 HP ${ARMOR_GRADE_HP.join(' / ')}\n부위별 방어력: ${a.protection.join(' / ')}\n최대 강화 +${ARMOR_MAX}. 부위별 제작법은 /rpg:craft에서 확인하세요.`,'data/equipment.js · data/upgrades.js');
 for(const r of CRAFTING_RECIPES)add('craft:'+r.id,r.name+' 제작법',[r.name,r.id,r.name.replace('훈련용 ','').replace(' 소환',''),...(r.id==='rpg:stat_reset_scroll'?['스탯초기화']:[])],r.text,'data/crafting.js (실제 조합법에서 생성)');
 add('rule:offer','검과 책 바치기',['공물','바치기','검바치기','책바치기'], '/rpg:offer: 검과 책을 바칩니다. 인벤토리에서 현재 직업과 진행도에 맞게 소비합니다. 바친 아이템은 사라집니다. 효과부여 책은 시련과 마나 공물 중 현재 필요한 용도로 사용됩니다.','core/offer.js');
 add('rule:huntingzones','사냥 구역과 자연 출현',['사냥구역','초반사냥','중반사냥','후반사냥','몹스폰','몬스터출현'], '오버월드 X·Z 중 절댓값이 큰 좌표를 기준으로 초반 ±1500, 초반 밖 중반 ±4000, 중반 밖 후반 ±10000입니다. 경계는 안쪽 구역에 포함하고 10000 밖도 후반을 유지합니다. 밤에는 구역에 맞는 RPG 몬스터가 출현합니다. 바닐라 적대 몹 자연 출현은 동굴로 제한합니다. 사막 몬스터는 사막에서 밤낮·좌표 제한 없이 출현합니다.','data/huntingZones.js · spawn_rules');
 add('rule:rarity','아이템 등급·합성',['등급','아이템등급','무기등급','갑옷등급','룬등급','희귀도','합성','승급'],RARITIES.join(' → ')+'\n룬·RPG 갑옷·공용 무기 7종은 모두 일반~신화가 존재합니다. 같은 종류·같은 등급의 +5 이상 두 개를 /rpg:fuse에서 합성합니다. 성공하면 다음 등급 +0, 실패하면 두 장비를 보존하며 50% 확률로 주장비만 -1강. 둘 다 +10이면 성공률 100%. 신화는 최종 등급. 갑옷은 보호 IV 책 1권, 공용 무기는 날카로움 V 책 1권이 추가로 필요하고 성공·실패 모두 소모합니다. 룬은 책이 필요 없습니다.\n다음 등급 성공률: '+PROMOTION_RATES.join(' / ')+'%. 무기 기본 피해·룬 수치 효과 배율: '+GRADE_MULTIPLIERS.join(' / ')+'. 갑옷 부위당 추가 HP: '+ARMOR_GRADE_HP.join(' / ')+'. 직업 기본 무기는 등급·승급 없이 +10 강화만 가능하며, 강화 단계당 근접 피해 +1·물리/마법 스킬 피해 +2%. 고정 피해·회복량은 제외. 바닐라 장비는 제외.','data/grades.js · core/fusion.js');
 add('rule:armor','갑옷 종류·제작',['갑옷','방어구'],Object.values(ARMOR_SETS).map(a=>a.name+': '+a.description).join('\n')+'\n4부위를 같은 세트로 입어야 세트 효과를 받습니다. /rpg:craft에서 부위별 제작법, /rpg:upgrade에서 강화를 확인하세요.','data/equipment.js · data/crafting.js');
 add('rule:scalingjobs','근력·마력 직업 안내',['근력직업','마력직업','근력캐','마력캐','힘캐','마법직업'],['근력(물리) 기본 계열: '+jobs.filter(j=>j.id!=='apprentice'&&defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='physical').map(j=>j.name).join('·'),'마력(마법) 기본 계열: '+jobs.filter(j=>defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='magic').map(j=>j.name).join('·'),'직업 기본 계열과 개별 기술은 다를 수 있습니다. 풍압·용의 브레스는 마력, 달 계열 공격은 근력, 메테오드라이브/혈인은 혼합, 대미장식은 고정 피해입니다. 스킬명과 함께 물어보세요.'].join('\n'),'core/stats.js · data/skillScaling.js');
 add('rule:damage','피해 계산·힘 버프',['힘버프','힘효과','힘스킬','마법딜','고정피해','마법피해','피해계산'],`힘 효과는 물리·마법 스킬 피해를 단계당 ${CONFIG.skillDamage.strengthPerLevel*100}% 증가시킵니다. 힘 I +5%·II +10%·III +15%. 단타와 연타 총합에 같은 비율로 적용합니다. 이후 물리는 근력, 마법은 마력과 장비·룬 보정을 받습니다. 고정 피해는 유지합니다.\n무투가 기존 힘 계산 및 평타 배수에는 중복 적용하지 않습니다. 기본 평타의 힘 효과는 마인크래프트 엔진 규칙입니다.`,'core/stats.js · skills/fist.js');
 add('rule:transfer','갑옷 강화 이전',['강화이전','이전서','강화추출'],`/rpg:transfer에서 제작 전에 강화를 이전서로 추출하세요. 단계당 골드 500, 원래 갑옷은 +0. 새 RPG 갑옷을 만든 뒤 같은 부위에 100% 적용하며 이전서는 소모됩니다. 기존 단계보다 높은 이전서만 적용하며 합산하지 않습니다. 인챈트·내구도는 대상 장비 것을 유지합니다.`,'core/armorTransfer.js');
 add('rule:bosscc','보스 CC 저항',['보스cc','보스기절','보스빙결','보스둔화'],`커스텀 보스 4종·드래곤·위더·워든에게 기절·빙결·둔화·속박 1회 지속시간은 50%, 넉백·끌어당김 강도는 50%입니다. 일반 몬스터와 플레이어는 그대로입니다. 장판에서 CC를 다시 적용하는 동작은 유지하며, 피해·화상·독은 CC 감소 대상이 아닙니다.`,'core/crowdControl.js');
 add('rule:farm','좀벌레 보상',['좀벌레','좀벌레팜','공장'],`좀벌레는 XP 5, 골드 2, 강화석·룬 가루 0, 룬 확률 0.1%입니다. 일반 적과 다른 전용 보상을 적용합니다.`,'core/economy.js · core/runeDrops.js');
 add('rule:commonweapons','공용 전투 무기',['공용무기','무기제작','평타무기'],COMMON_WEAPONS.map(w=>w.name+': 추가 근접 피해 설정 '+w.damage+'·내구도 '+w.durability).join('\n')+'\n누구나 제작하는 평타용 무기입니다. 직업 스킬은 기존 전용 아이템으로 사용합니다. /rpg:craft에서 재료를 확인하세요.','data/commonWeapons.js · data/crafting.js');
 for(const w of COMMON_WEAPONS)add('weapon:'+w.key,w.name,[w.key,w.id],`공용 RPG 평타 무기. 일반~신화 합성 승급 가능, 최대 +10 강화(단계당 추가 근접 피해 +1) · 추가 근접 피해 설정 ${w.damage}·내구도 ${w.durability}. 직업 제한 없음. /rpg:craft에서 제작법을 확인하세요. 직업 스킬은 전용 아이템을 사용합니다.`,'data/commonWeapons.js');
 add('rule:stats','레벨·스탯',['스탯','근력','마력','지능','체력스탯','레벨업'],`자연 성장 최대 레벨 100, 레벨마다 SP 3. 근력·체력·마력 투자 상한 없음. 지능 최대 50이며 마나 소모 감소는 최대 40%.\n근력은 물리 피해, 마력은 마법 피해·회복량, 체력은 최대 HP입니다. /rpg:stats에서 분배합니다.`,'core/stats.js');
 add('rule:pvp','PvP·결투·PK',['pvp','피케이','결투','현상금','pk패널티'], '일반 PvP 허용. /rpg:pvp 또는 지원되는 환경의 /pvp로 신청하고 서로 수락하면 PvP장으로 이동하여 최대 HP로 회복 후 3초 뒤 결투 시작, 패배 직전 비살상 종료합니다. 결투 밖 플레이어 살인은 PK 표식. PK 플레이어를 죽이면 그 지갑에서 최대 50,000골드를 지급하고 새 PK가 되지 않습니다. 잔액만 지급하며 부족분은 생성하지 않습니다. PK는 플레이어에게 처치돼야 해제됩니다. 던전에서는 결투 불가.','core/pvp.js');
 add('rule:party','파티 경험치',['파티','경험치','쩔','xp'],`최대 4명. 같은 차원·처치자 ${CONFIG.partyXp.radius}칸 안·생존한 파티원은 각자 원래 XP의 ${percent(CONFIG.partyXp.multiplier)} 획득. 90 XP 몹이면 각자 ${90*CONFIG.partyXp.multiplier} XP.\n일반 마크 생물 10, 대부분 적대 몹 30, 좀벌레·좀비화 피글린 5 XP. 커스텀 몹/보스는 별도 값.\n전직 처치는 최근 30초 공격·탱킹·유효 회복에 기여한 같은 차원·시체 32칸 안 생존 파티원도 인정합니다.`,'config.js · data/mobXp.js · core/combatContribution.js');
 add('rule:runes','룬 획득·장착',['룬','룬획득','룬드랍','룬드롭','룬장착'],`일반 몬스터 1%·RPG 엘리트 3%·보스 30% 확률로 룬 드롭(좀벌레만 0.1%). 현재 룬 ${Object.values(RUNES).map(r=>r.name).join('·')}.\n/rpg:runes 전용 보관함 30칸, 장착 3개. 같은 종류는 하나만 장착. 원하는 룬은 /rpg:craft 제작법을 확인하세요.`,'core/runeDrops.js · loot_tables/rpg · core/runeInventory.js');
 const ar=enhancementRates('armor',ARMOR_MAX-1),rr=enhancementRates('rune',RUNE_MAX-1),ac=upgradeCost('armor',ARMOR_MAX-1),rc=upgradeCost('rune',RUNE_MAX-1);
 add('rule:classweapon','직업 기본 무기 강화',['직업무기강화','기본무기강화','직업무기등급'], '직업·견습 기본 무기 36종은 /rpg:upgrade에서 +10까지 강화합니다. 등급·승급은 없습니다. 강화당 근접 피해 +1, 그 무기를 들고 사용하는 물리·마법 스킬 피해 +2%(+10은 +20%). 고정 피해와 회복량은 증가하지 않습니다. 공용 무기와 같은 비용·실패·강등·파괴·촉매 규칙입니다. 카멜레온 무기 전환과 직업 무기 재지급·전직 시 강화 단계를 유지합니다.','data/classWeapons.js · core/upgrades.js');
 add('rule:upgrade','강화·촉매·재화',['강화','촉매','골드','강화석','룬가루'],`/rpg:upgrade에서 갑옷·공용·직업 무기 최대 +${ARMOR_MAX}, 룬 최대 +${RUNE_MAX}. 실패·강등·파괴에도 비용 소모.\n갑옷 마지막 단계: 골드 ${ac.gold}·강화석 ${ac.stone}, 성공 ${ar.success}% / 유지 ${ar.fail}% / 강등 ${ar.downgrade}% / 파괴 ${ar.destroy}%.\n룬 마지막 단계: 골드 ${rc.gold}·룬 가루 ${rc.dust}, 성공 ${rr.success}% / 유지 ${rr.fail}% / 강등 ${rr.downgrade}% / 파괴 ${rr.destroy}%.\n촉매는 갑옷·무기 +5·룬 +2부터 1회 최대 ${MAX_CATALYSTS}개, 1개당 성공 +9%p·파괴 -3%p(파괴 0% 하한). 최종 확률은 확인창에 표시.`,'data/upgrades.js');
 add('rule:monsterlevels','몬스터 레벨',['몬스터레벨','몹레벨','필드레벨','던전난이도'], 'RPG 몬스터 22종은 레벨에 따라 체력·공격·방어가 증가합니다. 초반 필드 Lv.1/5/10/15, 중반 Lv.20/30/40/55, 후반 Lv.70/90/115/145. 같은 종도 여러 레벨로 등장합니다. 10단계는 일반 Lv.145~220, 엘리트 Lv.220, 보스 Lv.260입니다. 무기·RPG 갑옷·장착 룬 전설 +10 수준의 4인 파티 권장선이며 장비 입장 제한은 없습니다. 고정 피해는 레벨 방어를 상쇄합니다.','data/monsterLevels.js');
 add('rule:dungeon','던전 입장·진행',['던전','던젼','보스제한시간','솔플','솔로보상','혼자던전'],`난이도 ${DUNGEON_TIERS.length}개. /rpg:dungeon에서 참가, /rpg:dungeonstart로 최대 ${DUNGEON.maxParty}명 출발. 혼자는 /rpg:dungeonsolo 1. 처음부터 혼자 출발하면 클리어 골드·강화석·룬 가루·촉매 1.5배(올림). 룬·보급품·처치 보상은 그대로입니다.\n파티는 일반 ${DUNGEON.normalCount}·엘리트 ${DUNGEON.eliteCount}마리를 ${DUNGEON.mobLimitMs/60000}분 안에 처치한 뒤 보스 1마리를 ${DUNGEON.bossLimitMs/60000}분 안에 잡습니다. 혼자 출발하면 전반 7분 30초·보스 4분 30초입니다. 몹이 없으면 후속 몹이 일찍 나옵니다. 전투 중 임의 퇴장 불가, 사망·완료·제한시간 종료로 귀환.\n종료 시 남은 아이템과 몹의 마크 XP를 피해+유효 회복 기여도에 따라 분배합니다. RPG 처치 XP는 기존 방식이며 가방 부족 전리품은 /rpg:dungeonloot로 받습니다.\n관리자 생성: /rpg:dungeoncreate 1 또는 all.`,'data/dungeons.js · core/dungeons.js');
 for(const d of DUNGEON_TIERS){const r=clearRewardForTier(d.tier),solo=clearRewardForTier(d.tier,true);add('dungeon:'+d.tier,`던전 ${d.tier} ${d.name}`,[d.name,'던전'+d.tier,d.tier+'번던전',d.tier+'단계던전',d.tier+'티어던전'],`난이도 ${d.tier}. 일반 Lv.${dungeonMonsterLevel(d.tier,'normal',0)}~${dungeonMonsterLevel(d.tier,'normal',2)}, 엘리트 Lv.${dungeonMonsterLevel(d.tier,'elite')}, 보스 Lv.${dungeonMonsterLevel(d.tier,'boss')}. 10단계는 전설 +10 세트 권장, 입장 제한 없음. 보스: ${bossName(d.boss)}.\n클리어 보상: 골드 ${r.gold}·강화석 ${r.stone}·룬 가루 ${r.dust}·촉매 ${r.catalysts}·룬 ${r.runes}개. 보급품 ${r.supplyMultiplier}배. 솔로 클리어는 골드 ${solo.gold}·강화석 ${solo.stone}·룬 가루 ${solo.dust}·촉매 ${solo.catalysts}입니다. 던전 엘리트는 다이아 1개 40%·3개 10%·없음 50%로 공동 전리품을 남깁니다. 클리어 시 네더라이트 주괴 1개 확률 ${Math.round(netheriteChanceForTier(d.tier)*100)}%(6~10단계 한정, 각자 추첨). 개별 몬스터 처치 재화는 별도.`,'data/dungeons.js');}
 add('rule:temple','해·달의 신전',['신전','해의신전','달의신전','천체신전'],'낮에는 해의 제단, 밤에는 달의 제단이 활성화되는 구조물입니다. 히든 직업의 전직 방법·조건은 안내하지 않습니다.','data/temple.js');
 add('rule:melee','추가 근접 피해 없는 기본 아이템',['근접피해없는직업','근접데미지없는직업','기본아이템피해'],`기본 아이템에 추가 근접 피해 설정이 없는 직업은 마법사·현자·궁수·천궁·성직자·천사·미카엘·타락천사입니다. 공격이 완전히 0인 뜻은 아니며 맨손 수준 기본 피해·힘·인챈트와 화살/스킬 피해는 별도입니다. 공용 전투검/전투창으로 근접 사냥을 보완할 수 있습니다.`,'items/*.json · data/jobs.js');
 add('rule:start','처음 시작',['초보','시작','처음','막혔','막힘'],`/rpg:guide의 견습 5계열 체험에서 시작 계열과 관계없이 검·마법·활·격투·회복 견습 장비를 바꿔 사용할 수 있습니다. 빵과 화살은 처음 한 번만 지급합니다. 첫 전직은 레벨 10과 각 직업 시련이 필요합니다. /rpg:jobs에서 현재 전직 조건, /rpg:craft에서 재료, /rpg:skillguide에서 기술을 확인하세요.`,'core/beginner.js · core/jobMenu.js');
 catalog=Object.freeze(entries);return catalog;
}
export function lookupRpgQuestion(question){
 const raw=String(question??'').trim();if(!raw)return {status:'empty',entries:[]};
 if(raw.length>QUESTION_LIMIT)return {status:'too_long',entries:[]};
 if(isBalanceQuestion(raw))return {status:'balance',entries:[]};
 if(isHiddenPromotionQuestion(raw))return {status:'hidden',entries:[]};
 const q=normalizeQuestion(raw);if(!q)return {status:'unknown',entries:[]};
 if(/전직(방법|조건|하는법|하려면|알려)|직업.*조건/.test(q)&&!Object.values(JOBS).some(j=>j.id!=='apprentice'&&q.includes(normalizeQuestion(j.name)))){return {status:'answer',entries:[{id:'rule:publicpromotions',title:'공개 전직 안내: 기본 직업 5종',body:knowledgeEntries().filter(e=>['job:swordsman','job:mage','job:archer','job:fighter','job:cleric'].includes(e.id)).map(e=>e.title+'\n'+e.body).join('\n\n'),source:'data/jobTrials.js'}],effect:true};}
 const named=knowledgeEntries().some(e=>e.id.startsWith('skill:')&&e.aliases.some(a=>q.includes(a)));
 const effect=!named&&effectKnowledge(q);if(effect)return {status:'answer',entries:[effect],effect:true};
 const ranked=knowledgeEntries().map(e=>({entry:e,score:Math.max(0,...e.aliases.filter(a=>q.includes(a)&&(!/[0-9]$/.test(a)||new RegExp(a+'(?![0-9])').test(q))).map(a=>a.length*10+(/등급|희귀도/.test(q)&&/^(weapon|armor|rune):/.test(e.id)?100:0)+(named&&/근력|마력|물리|마법|피해계열/.test(q)&&e.id.startsWith('skill:')?100:0)+(e.id.startsWith('skill:')?2:e.id.startsWith('rune:')?3:0)+(e.id.startsWith('craft:')&&/제작|만드|만들|조합|재료/.test(q)?5:0)))})).filter(e=>e.score>0).sort((a,b)=>b.score-a.score||a.entry.id.localeCompare(b.entry.id));
 return {status:ranked.length?'answer':'unknown',entries:ranked.slice(0,6).map(r=>r.entry)};
}
// Only canonical records may be rendered; remote services cannot inject answer text.
export function selectKnowledgeEntries(candidates,ids){
 if(!Array.isArray(ids)||ids.length>3||ids.some(id=>typeof id!=='string'))return undefined;
 const unique=[...new Set(ids)],selected=unique.map(id=>candidates.find(e=>e.id===id));
 return selected.some(e=>!e)?undefined:selected;
}
export function formatKnowledge(entries){
 if(!entries?.length)return UNKNOWN_ANSWER;
 return entries.slice(0,3).map(e=>`${e.title}\n${e.body}`).join('\n\n')+'\n\n자료: 이 애드온의 게임 도감 v0.5.78';
}
```

## RPG_BP_v0597/scripts/core/runeMelee.js

```javascript
import {equippedRunes} from './runeInventory.js';
import {RUNES} from '../data/equipment.js';
import {upgradedRune} from '../data/upgrades.js';
// Upgraded power and arcane rune bonuses add together for basic weapon hits.
export function runeMeleeModifiers(player){
 let bonus=0,physical=1,magicBonus=0;
 for(const stored of equippedRunes(player)){
  if(!['power','arcane'].includes(stored.id))continue;
  const rune=upgradedRune(RUNES[stored.id],stored.level,stored.grade);
  if(stored.id==='power')physical*=rune.physical??1;
  if(stored.level>0){const extra=Math.max(0,(rune.physical??rune.magic??1)-1);bonus+=extra;if(stored.id==='arcane')magicBonus+=extra;}
 }
 return {bonus,physical,magicBonus};
}
export function runeMeleeBonus(player){return runeMeleeModifiers(player).bonus;}
// The World's basic punch already goes through skillDamageFor('physical').
// Preserve that existing physical factor and add the arcane melee bonus once.
export function scriptedMeleeRuneFactor(player){const {physical,magicBonus}=runeMeleeModifiers(player);return (physical+magicBonus)/physical;}
```

## RPG_BP_v0597/scripts/core/upgrades.js

```javascript
import {itemGrade} from '../data/grades.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {classWeapon} from '../data/classWeapons.js';
import {gearFingerprint,setGearLevel} from './gearState.js';
import {openFusionMenu} from './fusion.js';
import {runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {decorateRarity} from './rarityLabels.js';
import {openArmorTransfer} from './armorTransfer.js';
import { EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { armorInfo, RUNES, RUNE_KEY } from '../data/equipment.js';
import { ARMOR_LEVEL_KEY, RUNE_LEVEL_KEY, upgradeLevel, upgradeCost, upgradedRune, enhancementRates, rollEnhancement, catalystAllowed, CATALYST_ID, MAX_CATALYSTS } from '../data/upgrades.js';
import { getWallet, setWallet, canAfford, walletText } from './wallet.js';
import { showForm } from './skillMenu.js';
import { readRuneBag, writeRuneBag, migrateChestRune } from './runeInventory.js';

const SLOTS = () => [
  {slot:EquipmentSlot.Head, part:'helmet', name:'투구'},
  {slot:EquipmentSlot.Chest, part:'chestplate', name:'흉갑'},
  {slot:EquipmentSlot.Legs, part:'leggings', name:'각반'},
  {slot:EquipmentSlot.Feet, part:'boots', name:'장화'},
];
export function describeRune(id, rank, grade=0) {
  const r = upgradedRune(RUNES[id],rank,grade);
  if (!r) return '없음';
  const values = [];
  if (r.physical && r.physical>1) values.push(`물리 스킬 +${Number(((r.physical-1)*100).toFixed(1))}%`);
  if (r.magic && r.magic>1) values.push(`마법 스킬 +${Number(((r.magic-1)*100).toFixed(1))}%`);
  if(rank>0&&['power','arcane'].includes(id))values.push('공용·직업 무기 근접 평타 +'+Number((((r.physical??r.magic)-1)*100).toFixed(1))+'%');
  if (r.health) values.push(`최대 HP +${r.health}`);
  if (r.manaRegenPercent) values.push(`초당 최대 마나의 +${Number((r.manaRegenPercent*100).toFixed(1))}% 회복`);
  if (r.lifesteal) values.push('준 피해의 '+Number((r.lifesteal*100).toFixed(1))+'% 흡혈');
  if (r.ward) values.push('저항 '+(r.wardAmplifier+1));
  if (r.speed) values.push('신속 '+(r.speedAmplifier+1));
  return rarityBadge(runeRarity(grade))+' · '+values.join(', ');
}

function fingerprint(item) {return gearFingerprint(item);}
export function enhancementQuote(player,kind,slot) {
  if(kind==='rune') {
    const rune=readRuneBag(player).runes.find(r=>r.uid===slot);if(!rune)return undefined;
    return {kind,slot,level:rune.level,runeId:rune.id,fingerprint:JSON.stringify(rune),cost:upgradeCost(kind,rune.level),name:RUNES[rune.id].name,
      effect:describeRune(rune.id,rune.level,rune.grade)+'\n→ '+describeRune(rune.id,rune.level+1,rune.grade)};
  }
  if(kind==='weapon'){
    if(slot!==EquipmentSlot.Mainhand)return undefined;
    const item=player.getComponent('minecraft:equippable')?.getEquipment(slot),jobWeapon=classWeapon(item?.typeId),w=COMMON_WEAPONS.find(w=>w.id===item?.typeId)??jobWeapon;
    if(!w||item.amount!==1)return undefined;const level=upgradeLevel(item,kind);
    return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:w.name,effect:jobWeapon?`직업 무기 · 등급·승급 없음\n근접 피해 +${level} → +${level+1}\n물리·마법 스킬 피해 +${level*2}% → +${(level+1)*2}%`:`${rarityBadge(itemGrade(item))} 등급 유지 · 강화 근접 피해 +${level} → +${level+1}`};
  }
  if(kind!=='armor')return undefined;
  const definition=SLOTS().find(s=>s.slot===slot),item=player.getComponent('minecraft:equippable')?.getEquipment(slot);
  const info=armorInfo(item?.typeId);if(!definition||info?.part!==definition.part)return undefined;
  const level=upgradeLevel(item,'armor');return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:info.name+' '+definition.name,effect:`${rarityBadge(itemGrade(item))} 등급 유지\n부위 강화 HP +${level} → +${level+1}`};
}

export function enhanceEquipped(player,kind,slot,expectedFingerprint,options={}) {
  try {
    const quote=enhancementQuote(player,kind,slot);
    if (!quote) return {ok:false,reason:'강화할 RPG 갑옷·공용·직업 무기·보관 룬이 없습니다.'};
    if (!quote.cost) return {ok:false,reason:'이미 최대 강화 단계입니다.'};
    if (expectedFingerprint!==undefined&&quote.fingerprint!==expectedFingerprint) return {ok:false,reason:'장비 또는 강화 단계가 변경됐습니다. 다시 선택하세요.'};
    const catalystCount=options.catalystCount??0;
    const rates=enhancementRates(kind,quote.level,catalystCount);
    if (!rates) return {ok:false,reason:'촉매 수량은 0~5개이며, 갑옷·무기 +5·룬 +2부터 사용할 수 있습니다.'};
    const wallet=getWallet(player);
    if (!canAfford(wallet,quote.cost)) return {ok:false,reason:'강화에 필요한 재화가 부족합니다.'};
    const eq=player.getComponent('minecraft:equippable');
    const inventory=player.getComponent('minecraft:inventory')?.container;
    const catalysts=[];
    let needed=catalystCount;
    if(needed>0&&inventory)for(let i=0;i<inventory.size&&needed>0;i++) {
      const token=inventory.getItem(i);
      if(token?.typeId!==CATALYST_ID||token.amount<1)continue;
      const take=Math.min(needed,token.amount);
      catalysts.push({slot:i,original:token.clone(),take});needed-=take;
    }
    if(needed>0)return {ok:false,reason:`강화 촉매 ${catalystCount}개가 필요합니다.`};
    const original=kind!=='rune'?eq.getEquipment(slot).clone():readRuneBag(player);
    const outcome=rollEnhancement(rates,options.random??Math.random);
    let level=quote.level,target;
    if(outcome==='success')level++;
    if(outcome==='downgrade')level=Math.max(0,level-1);
    if(kind!=='rune') {
      target=original.clone();
      if(outcome==='destroy'){target=undefined;level=0;}
      else target=setGearLevel(target,kind,level);
    }else{
      target=JSON.parse(JSON.stringify(original));
      if(outcome==='destroy'){level=0;target.runes=target.runes.filter(r=>r.uid!==slot);target.equipped=target.equipped.map(uid=>uid===slot?null:uid);}
      else target.runes.find(r=>r.uid===slot).level=level;
    }
    const next=Object.fromEntries(Object.entries(wallet).map(([k,v])=>[k,v-quote.cost[k]]));
    let debited=false,catalystTouched=false;
    try {
      setWallet(player,next);debited=true;
      if(catalysts.length) {
        catalystTouched=true;
        for(const entry of catalysts) {
          if(entry.original.amount===entry.take)inventory.setItem(entry.slot,undefined);
          else {const remaining=entry.original.clone();remaining.amount-=entry.take;inventory.setItem(entry.slot,remaining);}
        }
      }
      if(kind!=='rune'){if(!eq.setEquipment(slot,target))throw Error('장비 저장 실패');}else writeRuneBag(player,target);
    } catch(error) {
      let recovered=true;
      try {if(kind!=='rune'){if(!eq.setEquipment(slot,original))recovered=false;}else writeRuneBag(player,original);}catch{recovered=false;}
      if(catalystTouched)for(const entry of catalysts)try{inventory.setItem(entry.slot,entry.original);}catch{recovered=false;}
      if(debited)try{setWallet(player,wallet);}catch{recovered=false;}
      if(!recovered)console.error('[RPG upgrade] rollback incomplete: '+String(error));
      return {ok:false,reason:recovered?'강화를 저장하지 못해 취소하고 재화를 복구했습니다.':'강화 복구에 실패했습니다. 관리자에게 콘텐츠 로그 확인을 요청하세요.'};
    }
    return {ok:true,outcome,level,cost:quote.cost,rates,catalystCount};
  }catch(error){return {ok:false,reason:'강화 오류: '+String(error)};}
}

const menus = new Set();
export async function openUpgradeMenu(player) {
  if (menus.has(player.id)) return;
  menus.add(player.id);
  try {
    const migration=migrateChestRune(player);if(!migration.ok)player.sendMessage('§e'+migration.reason);
    for (let count=0;count<40&&player.isValid;count++) {
      const options = SLOTS().map(s=>enhancementQuote(player,'armor',s.slot)).filter(Boolean);
      const weapon=enhancementQuote(player,'weapon',EquipmentSlot.Mainhand);if(weapon)options.push(weapon);
      for(const rune of readRuneBag(player).runes)options.push(enhancementQuote(player,'rune',rune.uid));
      const form = new ActionFormData().title('RPG 장비 강화 · 합성').body(walletText(getWallet(player))+
        '\n\n단계가 높아질수록 실패·강등·파괴 위험 증가\n갑옷 최대 +10: 부위당 단계별 최대 HP +1\n룬·공용 무기도 최대 +10. 무기: 강화당 근접 피해 +1'+
        '\nHP는 게임 효과 특성상 총합을 4 HP 단위로 근사합니다.\n착용 중인 장비를 선택하세요. 룬은 전용 보관함에 넣은 뒤 강화합니다.\n촉매: 갑옷·무기 +5 / 룬 +2부터 최대 5개. 1개당 성공률 +9%p, 파괴확률 -3%p.');
      for (const q of options) form.button(`${q.kind==='armor'?'갑옷':q.kind==='weapon'?'무기':'룬'}: ${q.name} +${q.level}\n`+(q.cost?`다음 단계: 골드 ${q.cost.gold} / ${q.cost.stone?'강화석 '+q.cost.stone:'룬 가루 '+q.cost.dust}`:'최대 단계'));
      form.button('갑옷 강화 이전');form.button('장비 등급 합성');form.button('닫기');
      const result = await showForm(form,player);
      if (!result || result.canceled || result.selection==null || result.selection>options.length+1) return;
      if(result.selection===options.length){await openArmorTransfer(player);continue;}
      if(result.selection===options.length+1){await openFusionMenu(player);continue;}
      const quote = options[result.selection];
      if (!quote.cost) {player.sendMessage('§e[RPG] 이미 최대 강화 단계입니다.');continue;}
      let catalystCount=0;
      if(catalystAllowed(quote.kind,quote.level)) {
        const inventory=player.getComponent('minecraft:inventory')?.container;
        let owned=0;
        if(inventory)for(let i=0;i<inventory.size;i++){const token=inventory.getItem(i);if(token?.typeId===CATALYST_ID)owned+=token.amount;}
        const maximum=Math.min(MAX_CATALYSTS,owned);
        const form=new ActionFormData().title('강화 촉매 수량')
          .body(`보유 촉매 ${owned}개. 한 번에 최대 5개 사용.\n1개당 성공률 +9%p, 파괴확률 -3%p (최소 0%).\n완료된 모든 결과에서 선택 수량을 소비합니다.`);
        for(let count=0;count<=maximum;count++) {
          const preview=enhancementRates(quote.kind,quote.level,count);
          form.button(`${count===0?'촉매 사용 안 함':count+'개 사용'}\n성공 ${preview.success}% / 파괴 ${preview.destroy}%`);
        }
        form.button('취소');
        const choice=await showForm(form,player);
        if(!choice||choice.canceled||choice.selection==null||choice.selection>maximum)continue;
        catalystCount=choice.selection;
      }
      const rates=enhancementRates(quote.kind,quote.level,catalystCount);
      const percentages=`성공 ${rates.success}% / 유지 실패 ${rates.fail}%\n1단계 강등 ${rates.downgrade}% / 파괴 ${rates.destroy}%`;
      const destruction=quote.kind!=='rune'?'장비 파괴 시 해당 장비만 소멸하고 전용 보관함 룬은 유지됩니다.':'룬 파괴 시 해당 보관 룬만 소멸하며 장착도 해제됩니다.';
      const confirm=await showForm(new MessageFormData().title('위험 강화 확인')
        .body(`${quote.name} +${quote.level} → +${quote.level+1}\n${quote.effect}\n\n${percentages}\n${destruction}\n\n비용: 골드 ${quote.cost.gold}, 강화석 ${quote.cost.stone}, 룬 가루 ${quote.cost.dust}\n${catalystCount?'강화 촉매 '+catalystCount+'개 사용\n':''}모든 결과에서 비용이 소비됩니다.`)
        .button1('취소').button2('강화'),player);
      if(!confirm||confirm.canceled||confirm.selection!==1)continue;
      const attempt=enhanceEquipped(player,quote.kind,quote.slot,quote.fingerprint,{catalystCount});
      if(!attempt.ok)player.sendMessage('§c[RPG] '+attempt.reason);
      else {
        const messages={success:`§a강화 성공! +${attempt.level}`,fail:'§e강화 실패: 단계 유지',downgrade:`§6강등: +${attempt.level}`,destroy:quote.kind!=='rune'?'§c장비 파괴: 해당 장비 소멸':'§c룬 파괴: 해당 보관 룬 소멸'};
        player.sendMessage('[RPG] '+quote.name+' · '+messages[attempt.outcome]);
      }
    }
  } catch(error) {try {player.sendMessage('§c[RPG] 강화 메뉴 오류: '+String(error));} catch {}}
  finally {menus.delete(player.id);}
}
```

## RPG_BP_v0597/scripts/data/equipment.js

```javascript
import {COMMON_WEAPONS} from './commonWeapons.js';
export const ARMOR_SETS = {
  abyssal:{name:'심연 수호자',protection:[3,8,6,3],durability:[550,800,750,650],health:16,physical:1.08,magic:1.08,ward:true,description:'4세트: 최대 HP +16, 물리·마법 스킬 +8%, 저항 I 유지. 기본 방어 합계 20·내구도 네더라이트 이상'},
  adventurer: {name:'모험가', protection:[2,5,4,2], durability:[220,320,300,220], physical:1.08, description:'4세트: 물리 스킬 피해 +8%'},
  warden: {name:'숲 수호자', protection:[3,6,5,2], durability:[300,450,420,300], health:8, description:'4세트: 최대 HP +8'},
  astral: {name:'별빛 술사', protection:[2,5,4,2], durability:[260,400,375,260], magic:1.08, manaRegen:3, description:'4세트: 마법 스킬 피해 +8%, 초당 마나 +3'},
};
export const ARMOR_PARTS = ['helmet','chestplate','leggings','boots'];
export const PART_NAMES = ['투구','흉갑','각반','장화'];
export const RUNES = {
  power:{name:'힘의 룬', description:'물리 스킬 피해 +17%, 강화마다 +3.4%p. +1부터 공용·직업 무기 근접 평타에도 추가 피해', physical:1.17},
  ward:{name:'수호의 룬', description:'저항 II 유지, +10에서 저항 IV (기존 방어 효과 2배, 더 강한 저항 우선)', ward:true},
  mana:{name:'샘의 룬', description:'초당 최대 마나의 1% 추가 회복', manaRegenPercent:0.01},
  arcane:{name:'비전의 룬', description:'마법 스킬 피해 +17%, 강화마다 +3.4%p. +1부터 공용·직업 무기 근접 평타에도 추가 피해', magic:1.17},
  vitality:{name:'생명의 룬', description:'최대 HP +4, 강화마다 +2 (일반 +10: +24)', health:4},
  absorption:{name:'흡수의 룬',description:'적에게 준 피해의 5%를 HP로 회복, 최대 강화 12%',lifesteal:.05},
};
export const RUNE_KEY = 'rpg:chest_rune';
export const ALL_EQUIPMENT_IDS = [
  'rpg:armor_transfer_seal',...COMMON_WEAPONS.map(w=>w.id), 'rpg:enhancement_catalyst', 'rpg:random_skillbook', 'rpg:stat_reset_scroll', 'rpg:job_waiver',
  ...Object.keys(ARMOR_SETS).flatMap(set=>ARMOR_PARTS.map(part=>`rpg:${set}_${part}`)),
  ...Object.keys(RUNES).map(rune=>`rpg:rune_${rune}`),
];
export function armorInfo(typeId) {
  for (const [set, data] of Object.entries(ARMOR_SETS)) {
    for (let i=0;i<ARMOR_PARTS.length;i++) if (typeId === `rpg:${set}_${ARMOR_PARTS[i]}`) return {set, part:ARMOR_PARTS[i], ...data};
  }
  return undefined;
}
```

## RPG_BP_v0597/scripts/data/upgrades.js

```javascript
import {GRADE_MULTIPLIERS,gradeRank} from './grades.js';
export const ARMOR_LEVEL_KEY = 'rpg:armor_upgrade';
export const RUNE_LEVEL_KEY = 'rpg:rune_upgrade';
export const ARMOR_MAX = 10;
export const RUNE_MAX = 10;
export const WEAPON_MAX = 10;
export const WEAPON_LEVEL_KEY = 'rpg:weapon_upgrade';

export function upgradeLevel(item, kind) {
  const key = kind === 'armor' ? ARMOR_LEVEL_KEY : kind === 'weapon' ? WEAPON_LEVEL_KEY : RUNE_LEVEL_KEY;
  const max = kind === 'armor' ? ARMOR_MAX : RUNE_MAX;
  const value = item?.getDynamicProperty(key);
  return Number.isInteger(value) ? Math.max(0, Math.min(max, value)) : 0;
}

export const RUNE_DUST_COSTS=Object.freeze([1,1,2,3,5,5,5,6,6,7]);
// Costs refer to the NEXT level, and are consumed for all completed attempts.
export function upgradeCost(kind, current) {
  const max = ['armor','weapon','rune'].includes(kind) ? 10 : 0;
  if (!Number.isInteger(current) || current < 0 || current >= max) return undefined;
  const next = current + 1;
  return kind !== 'rune'
    ? {gold:200*next*next, stone:2*next, dust:0}
    : {gold:Math.round(2.5*next*next)*5, stone:0, dust:RUNE_DUST_COSTS[current]};
}

export const CATALYST_ID = 'rpg:enhancement_catalyst';
export const MAX_CATALYSTS = 5;
// Rows are success / unchanged failure / downgrade / destruction, in percent.
const ARMOR_RATES = [
  [95,5,0,0], [90,10,0,0], [80,18,2,0], [70,23,7,0], [60,28,10,2],
  [50,30,16,4], [40,32,22,6], [30,34,27,9], [22,35,30,13], [15,35,32,18],
];
// +10 rune curve follows the armor curve; catalysts remain available from +2.
const RUNE_RATES = [[95,5,0,0],[90,10,0,0],[70,28,2,0],[65,28,7,0],...ARMOR_RATES.slice(4)];
export function catalystAllowed(kind,current) {return kind==='armor'||kind==='weapon'?current>=5:kind==='rune'&&current>=2;}
export function enhancementRates(kind,current,catalystCount=0) {
  if (!Number.isInteger(catalystCount)||catalystCount<0||catalystCount>MAX_CATALYSTS) return undefined;
  const row = (kind==='armor'||kind==='weapon'?ARMOR_RATES:kind==='rune'?RUNE_RATES:[])[current];
  if (!row) return undefined;
  let [success,fail,downgrade,destroy] = row;
  if (catalystCount>0) {
    if (!catalystAllowed(kind,current)) return undefined;
    destroy = Math.max(0,destroy-3*catalystCount);
    success = Math.min(success+9*catalystCount,100-downgrade-destroy);
    fail = 100-success-downgrade-destroy;
  }
  return {success,fail,downgrade,destroy};
}
export function rollEnhancement(rates,random=Math.random) {
  const value=random();
  if (!Number.isFinite(value)||value<0||value>=1) throw Error('강화 난수 범위 오류');
  const roll=value*100;
  if (roll<rates.success) return 'success';
  if (roll<rates.success+rates.fail) return 'fail';
  if (roll<rates.success+rates.fail+rates.downgrade) return 'downgrade';
  return 'destroy';
}

export function upgradedRune(rune, level, grade=0) {
  if (!rune) return undefined;
  const rank = Math.max(0, Math.min(RUNE_MAX, Number.isInteger(level) ? level : 0));
  const result = {...rune, wardAmplifier:0, speedAmplifier:0};
  if (rune.physical) result.physical += rank*0.034;
  if (rune.magic) result.magic += rank*0.034;
  if (rune.manaRegenPercent) result.manaRegenPercent = (10+rank*2)/1000;
  if (rune.health) result.health = rune.health+rank*2;
  if (rune.lifesteal) result.lifesteal=(50+rank*7)/1000;
  if (rune.ward) {
    result.health = rank;
    result.wardAmplifier = rank === RUNE_MAX ? 3 : 1;
  }
  const multiplier=GRADE_MULTIPLIERS[gradeRank(grade)];
  for(const key of ['physical','magic'])if(result[key])result[key]=1+(result[key]-1)*multiplier;
  for(const key of ['health','manaRegen','manaRegenPercent','lifesteal'])if(result[key])result[key]*=multiplier;
  return result;
}
```

## RPG_BP_v0597/scripts/gameplayEntry.js

```javascript
// RPG gameplay module - independent from slash-command registration pack.
import * as mc from "@minecraft/server";
import { initializeGameplay } from "./main.js";
let started = false;
function safeStart() {
  if (started) return;
  started = true;
  try { initializeGameplay(); }
  catch (e) { console.error("[RPG v0.5.99 gameplay] initialization failed: " + String(e?.stack ?? e)); }
}
try { mc.system.run(safeStart); }
catch (e) { console.error("[RPG v0.5.99 gameplay] schedule failed: " + String(e)); }
try {
  mc.world.afterEvents.worldLoad.subscribe(() => {
    if (!started) mc.system.run(safeStart);
  });
} catch (e) { console.warn("[RPG v0.5.99 gameplay] worldLoad recovery unavailable: " + String(e)); }

// Hydra: guard against any existing burning visual effects after pack upgrade.
// Fire immunity is configured in entities/hydra_boss.json.
try {
  mc.system.runInterval(() => {
    for (const id of ["overworld", "nether", "the_end"]) {
      try {
        const dim = mc.world.getDimension(id);
        for (const hydra of dim.getEntities({ type: "rpg:hydra_boss" })) {
          try {
            if (hydra.getComponent("minecraft:onfire")) hydra.extinguishFire(false);
          } catch (_) { /* invalid or unloaded entity */ }
        }
      } catch (_) { /* unloaded or inaccessible dimension */ }
    }
  }, 10);
} catch (e) { console.warn("[RPG] hydra fire cleanup unavailable: " + String(e)); }
```

## RPG_BP_v0597/scripts/skills/theWorld.js

```javascript
import {scriptedMeleeRuneFactor} from '../core/runeMelee.js';
import {duelOf} from '../core/pvp.js';
import {world,system,InputPermissionCategory,EntityDamageCause} from '@minecraft/server';
import {attack as martialAttack} from './warGod.js';
import {SKILLS} from '../data/skills.js';
import {getJobId} from '../core/playerData.js';
import {getTargets,flatDir,isSolidAt,knockback,heldItemId,hurt} from '../core/util.js';
import {areAllies} from '../core/social.js';
import {isBoss} from '../core/crowdControl.js';
import {scriptedHit,setCombatHealth,noteManualDamage} from '../core/combatContext.js';
import {registerStoppedTarget,takeStoppedDamage,isTimeFrozen} from '../core/timeStopDamage.js';
export {isTimeFrozen};
const MARK='rpg:the_world_freeze_v1',TAG='rpg_the_world_frozen',WEAK='rpg:the_world_native_guard',HIGH='rpg:the_world_high_until',BLOOD='rpg:the_world_blood_until';
const sessions=new Map(),frames=new Map(),basics=new Map();let registered=false;
const valid=e=>{try{return Boolean(e?.isValid);}catch{return false;}};
const living=e=>valid(e)&&(e.getComponent('minecraft:health')?.currentValue??0)>0;
const effectData=(e,name)=>{const f=e.getEffect(name);return f?{duration:f.duration,amplifier:f.amplifier}:null;};
function enemy(p,e){return valid(e)&&p.id!==e.id&&e.typeId!=='rpg:the_world_stand'&&!areAllies(p,e)&&!e.typeId.startsWith('rpg:hito_')&&e.typeId!=='rpg:gpt_guide'&&(e.typeId!=='minecraft:player'||!['creative','spectator'].includes(String(e.getGameMode?.()).toLowerCase()));}
export function restoreFrozenEntity(e){
 const raw=e.getDynamicProperty(MARK);if(raw===undefined){try{e.removeTag(TAG);}catch{}return true;}
 let saved;try{saved=JSON.parse(raw);}catch{console.warn('[The World] corrupt recovery marker');return false;}
 let okay=true;const elapsed=Math.max(0,Math.floor((Date.now()-saved.at)/50));
 for(const name of ['slowness','weakness'])try{e.removeEffect(name);const old=saved.effects[name];if(old&&old.duration>elapsed)e.addEffect(name,old.duration-elapsed,{amplifier:old.amplifier,showParticles:false});}catch{okay=false;}
 if(e.typeId==='minecraft:player')for(const [category,enabled]of saved.permissions??[])try{e.inputPermissions.setPermissionCategory(category,enabled);}catch{okay=false;}
 try{e.clearVelocity();const projectile=e.getComponent('minecraft:projectile');if(projectile)projectile.shoot(saved.velocity);else e.applyImpulse(saved.velocity);}catch{okay=false;}
 if(okay){e.setDynamicProperty(MARK,undefined);e.removeTag(TAG);}return okay;
}
function sharedGuild(a,b){try{return a?.typeId==='minecraft:player'&&b?.typeId==='minecraft:player'&&a.getTags().some(t=>t.startsWith('rpg_guild_')&&b.hasTag(t));}catch{return false;}}
function freeze(p,e,session){
 const base=session.duration??SKILLS.world_stop.duration;
 if(frames.has(e.id)||!enemy(p,e)||sharedGuild(p,e))return false;
 const projectile=e.getComponent('minecraft:projectile');
 if(projectile?.owner&&(projectile.owner.id===p.id||areAllies(p,projectile.owner)||sharedGuild(p,projectile.owner)))return false;
 if(!projectile&&!living(e))return false;
 if(e.getDynamicProperty(MARK)!==undefined&&!restoreFrozenEntity(e))return false;
 const saved={at:Date.now(),effects:{slowness:effectData(e,'slowness'),weakness:effectData(e,'weakness')},velocity:e.getVelocity(),permissions:[]};
 if(e.typeId==='minecraft:player')try{for(const category of [...new Set([InputPermissionCategory.Movement,InputPermissionCategory.Camera,...Object.values(InputPermissionCategory).filter(v=>typeof v==='number')])])saved.permissions.push([category,e.inputPermissions.isPermissionCategoryEnabled(category)]);}catch{saved.permissions=[];}
 e.setDynamicProperty(MARK,JSON.stringify(saved));e.addTag(TAG);e.clearVelocity();
 let mode='position';
 if(saved.permissions.length>=2)try{for(const category of [InputPermissionCategory.Movement,InputPermissionCategory.Camera])e.inputPermissions.setPermissionCategory(category,false);mode='inputPermissions';}catch{mode='position';}
 const duration=Math.ceil(base*(isBoss(e)?.5:1));
 if(!projectile){e.addEffect('slowness',duration,{amplifier:255,showParticles:false});e.addEffect('weakness',duration,{amplifier:255,showParticles:false});}
 frames.set(e.id,{entity:e,owner:p,location:{...e.location},rotation:e.getRotation(),dimension:e.dimension.id,until:system.currentTick+duration,duel:duelOf(p),mode});session.ids.add(e.id);registerStoppedTarget(e,p);return true;
}
function releaseFrame(id,applyDamage=true){
 const f=frames.get(id);frames.delete(id);const deferred=takeStoppedDamage(id);if(!f)return;
 try{if(valid(f.entity))restoreFrozenEntity(f.entity);}catch(error){console.warn('[The World restore] '+error);}
 if(!applyDamage||!deferred?.damage||!living(f.entity)||!living(f.owner)||areAllies(f.owner,f.entity)||(f.duel&&(f.duel.finished||duelOf(f.owner)!==f.duel||duelOf(f.entity)!==f.duel)))return;
 const target=f.entity,source=f.owner,amount=deferred.damage;
 scriptedHit(target,source,()=>{try{if(target.applyDamage(amount,{cause:EntityDamageCause.override,damagingEntity:source})!==false)return true;}catch{}
  const hp=target.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return false;const before=hp.currentValue;setCombatHealth(target,source,hp,Math.max(0,before-amount));noteManualDamage(source,target,Math.min(before,amount));return true;});
}
function restoreWorldGuard(id,session){
 try{const pl=world.getAllPlayers().find(x=>x.id===id);if(!pl||!valid(pl)||!session.guard)return;
  pl.removeEffect('resistance');const prev=session.guard.prev;
  if(prev){const left=prev.endTick-system.currentTick;if(left>0)pl.addEffect('resistance',left,{amplifier:prev.amplifier,showParticles:false});}
 }catch{}
}
export function stopTheWorld(p,applyDamage=true){const session=sessions.get(p.id);if(!session)return false;sessions.delete(p.id);restoreWorldGuard(p.id,session);for(const id of session.ids)releaseFrame(id,applyDamage);return true;}
export function startTheWorld(p){
 if(sessions.has(p.id))return false;
 let duration=SKILLS.world_stop.duration,extended=false;
 try{if(Number(p.getDynamicProperty(BLOOD)??0)>Date.now()){duration=SKILLS.world_stop.bloodDuration;extended=true;}p.setDynamicProperty(BLOOD,undefined);}catch{}
 const session={ids:new Set(),dimension:p.dimension.id,duration,until:system.currentTick+duration};sessions.set(p.id,session);
 // 시간 정지 중 시전자는 어떤 적의 공격도 받지 않음(저항 V = 피해 100% 감소). 기존 저항 효과는 종료 후 복원.
 try{const old=p.getEffect('resistance');session.guard={prev:old?{amplifier:old.amplifier,endTick:system.currentTick+old.duration}:null};p.addEffect('resistance',duration+10,{amplifier:4,showParticles:false});}catch(error){console.warn('[The World guard] '+error);}
 try{for(const e of p.dimension.getEntities({location:p.location,maxDistance:SKILLS.world_stop.radius})){if(session.ids.size>=60)break;try{freeze(p,e,session);}catch(error){try{restoreFrozenEntity(e);}catch{}console.warn('[The World freeze] '+error);}}}
 catch(error){stopTheWorld(p,false);throw error;}
 p.sendMessage(extended?'§6더 월드! §c흡혈의 힘으로 §e9초§7간 시간이 멈춥니다.':'§6더 월드! §7시간이 멈췄습니다.');return true;
}
export function tickTheWorld(){
 for(const [id,s]of sessions){const p=world.getAllPlayers().find(p=>p.id===id);if(!living(p)||p.dimension.id!==s.dimension||system.currentTick>=s.until||getJobId(p)!=='the_world'){stopTheWorld(p??{id},living(p)&&p.dimension.id===s.dimension&&getJobId(p)==='the_world');continue;}}
 for(const [id,f]of frames){
  if(!valid(f.entity)||!living(f.owner)||f.entity.dimension.id!==f.dimension||system.currentTick>=f.until||areAllies(f.owner,f.entity)){releaseFrame(id);continue;}
  try{f.entity.teleport(f.location,{dimension:f.entity.dimension,rotation:f.rotation,keepVelocity:false});f.entity.clearVelocity();}catch{releaseFrame(id);}
 }
}
export function recoverStoppedEntities(){
 for(const name of ['overworld','nether','the_end'])try{for(const e of world.getDimension(name).getEntities({tags:[TAG]}))if(!frames.has(e.id))try{restoreFrozenEntity(e);}catch(error){console.warn('[The World recovery] '+error);}}catch{}
 for(const p of world.getAllPlayers())if(!frames.has(p.id)&&p.getDynamicProperty(MARK)!==undefined)try{restoreFrozenEntity(p);}catch{}
}
function saveNativeGuard(p){if(p.getDynamicProperty(WEAK)===undefined)p.setDynamicProperty(WEAK,JSON.stringify({at:Date.now(),effect:effectData(p,'weakness')}));p.addEffect('weakness',40,{amplifier:255,showParticles:false});}
function restoreNativeGuard(p){const raw=p.getDynamicProperty(WEAK);if(raw===undefined)return;const saved=JSON.parse(raw);p.removeEffect('weakness');const ticks=(Date.now()-saved.at)/50;if(saved.effect?.duration>ticks)p.addEffect('weakness',Math.ceil(saved.effect.duration-ticks),{amplifier:saved.effect.amplifier,showParticles:false});p.setDynamicProperty(WEAK,undefined);}
export function tickWorldGuards(){for(const p of world.getAllPlayers())try{if(isTimeFrozen(p))continue;if(getJobId(p)==='the_world'&&(heldItemId(p)==='rpg:the_world_arrow'||sessions.has(p.id))&&!isTimeFrozen(p))saveNativeGuard(p);else restoreNativeGuard(p);}catch(error){console.warn('[The World melee guard] '+error);}}
export function isWorldHighActive(p){return Number(p.getDynamicProperty(HIGH)??0)>Date.now();}
function punch(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,hits:d.hits*2}:d);}
function finisher(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,damagePerHit:d.damagePerHit*2}:d);}
function roller(p,job,d){const dir=flatDir(p),origin=p.location;let at=origin;for(let n=.5;n<=3;n+=.5){const q={x:origin.x+dir.x*n,y:origin.y,z:origin.z+dir.z*n};if(isSolidAt(p.dimension,q)||isSolidAt(p.dimension,{...q,y:q.y+1}))break;at=q;}p.teleport(at,{dimension:p.dimension,keepVelocity:false});return martialAttack(p,job,d);}
function high(p){p.setDynamicProperty(HIGH,Date.now()+8000);p.addEffect('speed',160,{amplifier:1,showParticles:false});const strength=p.getEffect('strength');if(!strength||strength.amplifier<1||(strength.amplifier===1&&strength.duration<160))p.addEffect('strength',160,{amplifier:1,showParticles:false});return true;}
// 흡혈: 전방 근접 대상을 물어 체력을 회복하고 재생 II 10초·저항 II 30초.
// 보스·데스웜(샌드웜)·대장 고블린(대왕 고블린)을 흡혈하면 60초 안에 쓰는 다음 더 월드가 9초로 증가.
const BLOOD_BIG=new Set(['rpg:deathworm','rpg:elite_deathworm','rpg:goblin_captain','rpg:elite_goblin_captain']);
function bloodTarget(p){
 const dir=p.getViewDirection(),origin={x:p.location.x,y:p.location.y+1,z:p.location.z};let best,bestD=Infinity;
 for(const e of getTargets(p,origin,5.5,0)){
  if(!enemy(p,e)||!living(e))continue;
  const dx=e.location.x-origin.x,dy=e.location.y+(e.getComponent('minecraft:health')?1:0)*.8-origin.y,dz=e.location.z-origin.z,d=Math.hypot(dx,dy,dz)||.01;
  if((dx*dir.x+dy*dir.y+dz*dir.z)/d<.35)continue;
  if(d<bestD){best=e;bestD=d;}
 }
 return best;
}
function blood(p){
 const target=bloodTarget(p);
 p.addEffect('regeneration',200,{amplifier:1,showParticles:true});
 p.addEffect('resistance',600,{amplifier:1,showParticles:true});
 if(!target){p.sendMessage('§c흡혈! §7(대상 없음 · 재생 II 10초 / 저항 II 30초)');return true;}
 hurt(target,p,12,'physical',{ignoreInvulnerability:true});
 try{const hp=p.getComponent('minecraft:health');if(hp)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+8));}catch{}
 try{p.dimension.spawnParticle('minecraft:redstone_ore_dust_particle',{x:target.location.x,y:target.location.y+1,z:target.location.z});}catch{}
 if(isBoss(target)||BLOOD_BIG.has(target.typeId)){
  p.setDynamicProperty(BLOOD,Date.now()+60000);
  p.sendMessage('§4흡혈! §7강대한 피를 마셨습니다. §e60초 안의 더 월드가 9초로 증가합니다.');
 }else p.sendMessage('§c흡혈! §7재생 II 10초 / 저항 II 30초');
 return true;
}
export const RUNNERS={world_blood:blood,world_muda:punch,world_finish:finisher,world_roller:roller,world_high:high,world_stop:startTheWorld};
export function registerTheWorld(){
 if(registered)return;registered=true;
 world.beforeEvents.itemUse.subscribe(e=>{if(isTimeFrozen(e.source)||(sessions.has(e.source.id)&&e.itemStack?.typeId!=='rpg:the_world_arrow'))e.cancel=true;});
 system.runInterval(tickTheWorld,1);system.runInterval(tickWorldGuards,1);system.runInterval(recoverStoppedEntities,100);system.run(recoverStoppedEntities);
 world.afterEvents.entitySpawn.subscribe(ev=>system.run(()=>{try{const owner=ev.entity.getComponent('minecraft:projectile')?.owner;if(owner&&isTimeFrozen(owner))ev.entity.remove();}catch{}}));
 // Stable 2.2.0 has no before-hurt cancellation. Weakness/projectile suppression
 // prevent normal attacks; refund any surviving native damage that still reports.
 world.afterEvents.entityHurt.subscribe(ev=>{
  const src=ev.damageSource,projectile=src?.damagingProjectile;
  let attacker=src?.damagingEntity;
  try{attacker=attacker??projectile?.getComponent('minecraft:projectile')?.owner;}catch{}
  try{const victim=ev.hurtEntity;if(victim?.typeId==='minecraft:player'&&sessions.has(victim.id)&&ev.damage>0&&attacker?.id!==victim.id){const h=victim.getComponent('minecraft:health');if(h&&h.currentValue>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));}}catch{}
  if(!isTimeFrozen(attacker)&&!isTimeFrozen(projectile))return;
  try{const h=ev.hurtEntity.getComponent('minecraft:health');if(h?.currentValue>0&&ev.damage>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));}catch{}
 });
 world.afterEvents.entityLoad.subscribe(ev=>{if(!frames.has(ev.entity.id))try{restoreFrozenEntity(ev.entity);}catch{}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.run(()=>{try{if(!frames.has(ev.player.id))restoreFrozenEntity(ev.player);restoreNativeGuard(ev.player);}catch{}}));
 world.afterEvents.playerDimensionChange.subscribe(ev=>stopTheWorld(ev.player,false));
 world.afterEvents.playerLeave.subscribe(ev=>{stopTheWorld({id:ev.playerId},false);basics.delete(ev.playerId);});
 world.afterEvents.entityDie.subscribe(ev=>{stopTheWorld(ev.deadEntity,false);if(frames.has(ev.deadEntity.id))releaseFrame(ev.deadEntity.id,false);});
 world.afterEvents.entityHitEntity.subscribe(ev=>{const p=ev.damagingEntity,t=ev.hitEntity;if(p?.typeId!=='minecraft:player'||getJobId(p)!=='the_world'||heldItemId(p)!=='rpg:the_world_arrow'||isTimeFrozen(p)||!enemy(p,t))return;
  const gap=isWorldHighActive(p)?5:10;if((basics.get(p.id)??-100)>system.currentTick-gap)return;basics.set(p.id,system.currentTick);hurt(t,p,8*scriptedMeleeRuneFactor(p),'physical',{ignoreInvulnerability:true});});
}
```

## RPG_Commands_BP_v0597/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Commands BP v0.5.99",
    "description": "RPG v0.5.99 · 밤 RPG 스폰 감소·룬 강화 및 평타 피해·강화 비용 조정",
    "uuid": "533cff27-4591-48cb-85fb-540c8bcbcc72",
    "version": [
      0,
      5,
      99
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "script",
      "language": "javascript",
      "uuid": "9518dff9-cc69-4ea4-adb6-2762b6291c45",
      "entry": "scripts/commands.js",
      "version": [
        0,
        5,
        99
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
      "version": [
        0,
        5,
        99
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    }
  ]
}
```

## RPG_Commands_BP_v0597/scripts/commands.js

```javascript
// RPG command registry, isolated in a separate behavior pack.
// Even if complex RPG combat/skill imports fail, /rpg:ping can still register.
import * as mc from "@minecraft/server";
const VERSION = "0.5.99";
const commands = [
  ['tpa','플레이어 이동 요청 · 이동 성공 시 1000골드'],
  ['tpaaccept','받은 플레이어 이동 요청 수락·거절'],
  ['pvpcreate','관리자: 1000 250 1000에 PvP장 생성',null,true],
  ['pkclear','관리자: 플레이어 PK 패널티 해제','player',true],
  ['peace','관리자: 현재 위치 반경 200 평화구역 설정·해제','mode',true],
  ['pvp','결투 신청·수락·항복·PK 상태','player'],
  ['gptnpc','관리자: GPT RPG 질문 NPC 생성',null,true],
  ['temple','천체 신전 위치·활성 제단·후예 전직'],
  ['templecreate','관리자: 앞쪽 빈 지역에 천체 신전 생성',null,true],
  ['templeremove','관리자: 신전 등록 해제·건물 보존',null,true],
  ['fuse','RPG 장비 등급 합성'],
  ['transfer','RPG 갑옷 강화 추출·이전'],
  ['ask','이 애드온의 직업·스킬·제작·던전 정보 질문','question'],
  ['dungeoncreate','관리자: 난이도 1~10 또는 all 동굴 생성·누락 복구','difficulty',true],
  ['dungeonremove','관리자: 던전 등록 해제 (건축물 보존)','name',true],
  ['dungeon','난이도 목록·파티장 입장 시 파티원 자동 등록','difficulty'],
  ['dungeonstart','대기실 인원 1~4명 출발'],
  ['dungeonsolo','해당 난이도 혼자 바로 시작','difficulty'],
  ['dungeonleave','대기 취소·사망 후 귀환 (전투 중 불가)'],
  ['dungeonloot','보관된 던전 보급품 받기'],
  ['skillguide','모든 직업·스킬 상세 도감'],
  ['runes','룬 전용 보관함·장착'],
  ['jobs','직업별 전직 조건·시련'],
  ['craft', '갑옷·룬 제작법과 획득 도감'],
  ['upgrade', '갑옷·룬·공용 무기 강화'],
  ['wallet', '골드·강화석·룬 가루 지갑'],
  ['equipment', 'RPG 갑옷·룬 보관·장착'],
  ['guide', '모험 시작·견습 5계열 자유 체험'],
  ["rulebook", "RPG 서버 종합 룰북"],
  ["ping", "명령어 등록 진단"],
  ["diag", "명령어 및 스크립트 진단"],
  ["menu", "카멜레온 스킬 메뉴"],
  ["job", "전직", "job"],
  ["help", "명령어 도움말"],
  ["status", "캐릭터 상태"],
  ["stats", "레벨·스탯 분배"],
  ["admin", "운영자 설정 도구", null, true],
  ["setlevel", "관리자: 레벨 설정", "level", true],
  ["setmana", "관리자: 최대 마나 설정", "amount", true],
  ["skills", "스킬 켜기·끄기"],
  ["skillbook", "스킬 도감"],
  ["learn", "스킬 습득", "skill"],
  ["swap", "카멜레온 무기 전환"],
  ["offer", "검과 책을 바칩니다"],
  ["bless", "미카엘 전직: 축복의 빛 192개 공물"],
  ["holywater", "성수 제작"],
  ["force", "관리자: 강제 전직", "job", true],
  ["reset", "관리자: 초기화", null, true],
  ["starter", "관리자: 견습 장비", "line", true],
  ["charge", "관리자: 마나·쿨타임 회복", null, true],
  ["items", "관리자: 전용 아이템", null, true],
  ["egg", "관리자: 몬스터 스폰알", null, true],
  ["hito", "관리자: 전직관 소환알 지급", "line", true],
  ["wings", "날개 켜기·끄기"],
  ["wingcheck", "날개 상태"],
  ["wingrefresh", "날개 새로고침"],
  ["guild", "길드 메뉴"],
  ["party", "파티 메뉴"],
  ["invites", "초대 확인"],
  ["boss", "관리자: 바위 골렘", null, true],
  ["cyclops", "관리자: 외눈 거인", null, true],
  ["hydra", "관리자: 히드라", null, true],
  ["techgolem", "관리자: 마공학 골렘", null, true],
  ["fistcheck", "주먹 강화 상태"]
];
const registered = new Set();
let startupDone = false;
let failures = [];
function isPlayer(p) { return !!p && p.typeId === "minecraft:player"; }
function tell(p, msg) { try { p.sendMessage(msg); } catch (e) { console.warn("[RPG commands] message: " + e); } }
function handle(action, p, arg="") {
  if (!isPlayer(p)) return;
  if (action === "ping") {
    tell(p, "§a[RPG v"+VERSION+"] 명령어 스크립트 실행 정상. 등록 "+registered.size+"/"+commands.length);
    return;
  }
  if (action === "diag") {
    tell(p,"§e[RPG v"+VERSION+"] 명령어 팩 실행 정상 ("+registered.size+"/"+commands.length+"). RPG 본체 확인: /rpg:status");
    if(failures.length) failures.slice(0,4).forEach(x=>tell(p,"§c"+x));
    tell(p,"§7게임플레이 오류는 설정 → 제작자 → 콘텐츠 로그에서 확인 가능. /function rpg_hydra 로 히드라 소환 검사 가능");
    return;
  }
  // The RPG gameplay BP independently handles this script event. It is run as
  // the player so event.sourceEntity is the correct player object.
  const message = String(arg??"").replace(/[\r\n]/g," ").trim();
  try {
    p.runCommand("scriptevent rpg:"+action+(message?" "+message:""));
  } catch (e) {
    tell(p,"§c[RPG] 명령어 전달 실패: "+String(e));
  }
}
mc.system.beforeEvents.startup.subscribe(ev => {
  startupDone = true;
  const registry = ev.customCommandRegistry;
  if(!registry){ console.error("[RPG commands] customCommandRegistry unavailable"); return; }
  const levels = mc.CommandPermissionLevel ?? mc.CustomCommandPermissionLevel;
  const params = mc.CustomCommandParamType;
  const statuses = mc.CustomCommandStatus;
  if(!levels || !params || !statuses){ console.error("[RPG commands] Script API command enums unavailable"); return; }
  for(const [name, description, arg, admin] of commands){
    try{
      const def={name:"rpg:"+name,description,permissionLevel: admin?levels.GameDirectors:levels.Any,cheatsRequired:false};
      if(arg){
        const t = name === "setlevel" ? params.Integer : params.String;
        if(name === "hito" || name === "dungeon" || name === "ask" || name === "pvp" || name === "peace" || name === "pkclear") def.optionalParameters=[{name:arg,type:t}];
        else def.mandatoryParameters=[{name:arg,type:t}];
      }
      registry.registerCommand(def,(origin,...args)=>{
        const p=origin.sourceEntity??origin.initiator;
        if(!isPlayer(p)) return {status:statuses.Failure,message:"플레이어 전용 명령어"};
        const raw=Array.isArray(args[0])?args[0][0]:args[0];
        mc.system.run(()=>handle(name,p,raw==null?"":String(raw)));
        return {status:statuses.Success};
      });
      registered.add(name);
    }catch(e){
      const msg="/rpg:"+name+" 등록 실패: "+String(e);
      failures.push(msg);console.error("[RPG commands] "+msg);
    }
  }
  try{registry.registerCommand({name:'pvp',description:'결투 신청',permissionLevel:levels.Any,cheatsRequired:false,optionalParameters:[{name:'player',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvp',p,arg??''));return {status:statuses.Success};});}catch{ /* Namespace-free aliases are unsupported on some Bedrock versions. */ }
  try{registry.registerCommand({name:'peace',description:'관리자: 반경 200 평화구역',permissionLevel:levels.GameDirectors,cheatsRequired:false,optionalParameters:[{name:'mode',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('peace',p,arg??''));return {status:statuses.Success};});}catch{console.warn('[RPG] /peace 별칭 미지원: /rpg:peace 사용');}
  try{registry.registerCommand({name:'pvpcreate',description:'관리자: PvP장 생성',permissionLevel:levels.GameDirectors,cheatsRequired:false},origin=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvpcreate',p,''));return {status:statuses.Success};});}catch{console.warn('[RPG] /pvpcreate 별칭 미지원: /rpg:pvpcreate 사용');}
  console.warn("[RPG v"+VERSION+"] registered "+registered.size+"/"+commands.length+" commands");
});
// Allow commands even if a particular client doesn't display slash commands.
try {
  const chat=mc.world.beforeEvents?.chatSend;
  if(chat?.subscribe) chat.subscribe(ev=>{
    const msg=String(ev.message??"").trim();
    if(!/^!(?:rpg|rulebook|hito|pvp)(?:\s|$)/i.test(msg))return;
    ev.cancel=true;
    let action="help",arg="";
    if(/^!pvp(?:\s|$)/i.test(msg)){action='pvp';arg=msg.replace(/^!pvp\s*/i,'');}
    else if(/^!rulebook$/i.test(msg))action="rulebook";
    else if(/^!hito(?:\s|$)/i.test(msg)){action="hito";arg=msg.replace(/^!hito\s*/i,"");}
    else {const parts=msg.replace(/^!rpg\s*/i,"").trim().split(/\s+/);action=(parts.shift()||"help").toLowerCase();arg=parts.join(" ");}
    const p=ev.sender;
    mc.system.run(()=>handle(action,p,arg));
  });
}catch(e){console.warn("[RPG commands] chat fallback disabled: "+e);}
// Direct /scriptevent rpg:ping and rpg:diag allow diagnosing even if custom
// command registration is unsupported on the current Bedrock version.
try {
  mc.system.afterEvents.scriptEventReceive.subscribe(ev=>{
    if(ev.id!=="rpg:ping"&&ev.id!=="rpg:diag") return;
    if(isPlayer(ev.sourceEntity))mc.system.run(()=>handle(ev.id.slice(4),ev.sourceEntity));
  });
}catch(e){console.warn("[RPG commands] event diagnostic fallback disabled: "+e);}
```

## RPG_RP_v0597/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon RP v0.5.99",
    "description": "RPG v0.5.99 · 밤 RPG 스폰 감소·룬 강화 및 평타 피해·강화 비용 조정",
    "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
    "version": [
      0,
      5,
      99
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "resources",
      "uuid": "7ede5e36-9a5f-44d1-9aa0-9dc38822fa99",
      "version": [
        0,
        5,
        99
      ]
    }
  ]
}
```

