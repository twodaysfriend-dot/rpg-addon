import { HudElement, HudVisibility } from '@minecraft/server';

// Seven three-row tiers, twenty health points in a vanilla row.
const TIER_KEYS = 'roygcbp';
const HEART_SLOTS = 30;
const HP_PER_LAYER = 2 * HEART_SLOTS;
const HIDDEN_FRAME = '_'.repeat(HEART_SLOTS);
const visibility = new Map();

export function heartFrame(player) {
  const mode = String(player.getGameMode?.()).toLowerCase();
  const hp = player.getComponent('minecraft:health');
  if (mode === 'creative' || mode === 'spectator' || !hp ||
      !Number.isFinite(hp.currentValue) || !Number.isFinite(hp.effectiveMax) || hp.effectiveMax <= 0) {
    return HIDDEN_FRAME;
  }
  const capacity = Math.min(HEART_SLOTS, Math.ceil(hp.effectiveMax / 2));
  const current = Math.ceil(Math.max(0, Math.min(hp.currentValue, hp.effectiveMax, HP_PER_LAYER * TIER_KEYS.length)));
  const layer = Math.max(0, Math.ceil(current / HP_PER_LAYER) - 1);
  const remaining = current - layer * HP_PER_LAYER;
  const full = Math.floor(remaining / 2);
  // A new layer paints over the preceding one. Mixed sprites keep the older half visible.
  const half = remaining % 2 ? '1hijklm'[layer] : '';
  const underlay = layer > 0 ? TIER_KEYS[layer - 1] : '0';
  return (TIER_KEYS[layer].repeat(full) + half).padEnd(capacity, underlay).padEnd(HEART_SLOTS, '_');
}

export function syncHudVisibility(player, frame, gearLabel) {
  const previous = visibility.get(player.id);
  const customHealth = frame !== HIDDEN_FRAME;
  const customItem = Boolean(gearLabel);
  const display = player.onScreenDisplay;
  if (!previous) display.setHudVisibility(HudVisibility.Hide, [HudElement.Armor,HudElement.StatusEffects]);
  if (previous?.customHealth !== customHealth) {
    display.setHudVisibility(customHealth ? HudVisibility.Hide : HudVisibility.Reset, [HudElement.Health]);
  }
  if (previous?.customItem !== customItem) {
    display.setHudVisibility(customItem ? HudVisibility.Hide : HudVisibility.Reset, [HudElement.ItemText]);
  }
  visibility.set(player.id, {customHealth,customItem});
}

export function clearHealthHud(id) { visibility.delete(id); }
