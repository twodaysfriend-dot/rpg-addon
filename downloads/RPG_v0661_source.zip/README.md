# RPG v0.6.61 · 세 줄 하트 HUD

핫바 왼쪽 위에 한 줄당 하트 10개를 아래에서부터 최대 세 줄까지 표시합니다. 하트 하나는 2 HP입니다. 처음 60 HP는 빨강이며, 이후에는 같은 자리에 새 색이 반 칸씩 채워집니다. 62 HP에서는 주황 하트 1개와 빨강 하트 29개, 148 HP에서는 노란 하트 14개와 주황 하트 16개가 보입니다. 피해를 받으면 반대 순서로 이전 색이 드러납니다.

색상은 세 줄마다 빨강, 주황, 노랑, 초록, 하늘, 파랑, 분홍 순으로 바뀝니다. 21줄에 해당하는 420 HP에서 모든 칸이 분홍색이 됩니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.61로 활성화하세요. 모의 Script API에서 색상 경계, 반 칸, 피해·회복 및 장비 이름 표시를 검증했습니다. 실제 모바일 렌더링은 별도 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0661
```
