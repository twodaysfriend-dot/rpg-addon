import * as mc from "@minecraft/server";
import { getCommandHandler, getGameplayStatus, setGameplayStatus } from "./core/commandBridge.js";
import { initializeGameplay } from "./main.js";
import { giveRulebook } from "./core/rulebook.js";

const names = [
  ['setgrade','관리자: 장비 등급 직접 지정','grade',true],
  ['citycreate','관리자: 250×250 판타지 성곽 도시 생성','height',true],
  ['citystop','관리자: 성곽 도시 생성 일시 중지',null,true],
  ['cityresume','관리자: 성곽 마을 수동 재개',null,true],
  ['citystatus','관리자: 성곽 도시 생성 진행도',null,true],
  ['cityreset','관리자: 건축 전 도시 검사 취소',null,true],
  ['weapon','공통 무기를 직업 아이템 대신 1번 칸에 고정'],
  ['spawncreate','관리자: 남쪽 빈 공간에 17×17 스폰 광장 생성',null,true],
  ['pvp','결투 신청·수락·항복','player'],
  ["rulebook", "RPG 서버 종합 룰북 지급"],
  ["ping", "RPG 독립 명령어 진단"],
  ["diag", "RPG 게임플레이 오류 확인"],
  ["menu", "카멜레온 스킬 메뉴"],
  ["job", "전직", "job"],
  ["help", "명령어 도움말"],
  ["status", "캐릭터 상태"],
  ["stats", "레벨 및 스탯 분배"],
  ["admin", "관리자: 우클릭 설정 도구 지급", undefined, true],
  ["setlevel", "관리자: RPG 레벨 설정 (1~100000)", "level", true],
  ["setmana", "관리자: 최대 마나 설정", "amount", true],
  ["skills", "보유 스킬 관리"],
  ["skillbook", "카멜레온 스킬 도감"],
  ["learn", "카멜레온 스킬 배우기", "skill", false],
  ["swap", "카멜레온 무기 전환"],
  ["offer", "검과 책을 바칩니다"],
  ["bless", "축복의 빛 공물"],
  ["holywater", "성수 제작"],
  ["force", "관리자: 강제 전직", "job", true],
  ["reset", "관리자: 견습 초기화", undefined, true],
  ["starter", "관리자: 견습 장비 지급", "line", true],
  ["charge", "관리자: 마나·쿨타임 초기화", undefined, true],
  ["items", "관리자: 아이템 지급", undefined, true],
  ["egg", "관리자: RPG 몬스터 소환 알 메뉴", undefined, true],
  ["hito", "관리자: 전직관 소환알 지급", "line", true],
  ["wfly", "더 월드 비행 켜기·끄기 (off)", "mode"],
  ["wings", "날개 전환·속도 1/2/3", "speed"],
  ["wingcheck", "날개 상태 확인"],
  ["wingrefresh", "날개 표시 새로고침"],
  ["guild", "길드 관리"],
  ["party", "파티 관리"],
  ["invites", "길드·파티 초대 확인"],
  ["boss", "관리자: 바위 골렘 소환", undefined, true],
  ["cyclops", "관리자: 외눈박이 거인 소환", undefined, true],
  ["hydra", "관리자: 지옥의 히드라 소환", undefined, true],
  ["techgolem", "관리자: 마공학 블럭 골렘 소환", undefined, true],
  ["fistcheck", "권골 주먹 상태 확인"],
];
const adminActions = new Set(names.filter(spec => spec[3]).map(spec => spec[0]));
function isAdmin(p) {
  // Permission getters can be unavailable or throw independently on some Bedrock builds.
  try { if (p.playerPermissionLevel === 2) return true; } catch {}
  try { if (typeof p.commandPermissionLevel === "number" && p.commandPermissionLevel >= 1) return true; } catch {}
  try { if (typeof p.isOp === "function" && p.isOp()) return true; } catch {}
  return false;
}
function invoke(action, player, arg = "") {
  try {
    if (!player || player.typeId !== "minecraft:player") return;
    // 명령어가 작동했지만 최초 시작 틱이 누락된 경우 한 번 더 게임플레이 초기화.
    if (getGameplayStatus().state === "loading") initializeGameplaySafely();
    if (adminActions.has(action) && !isAdmin(player)) {
      player.sendMessage("§c[RPG] 관리자 권한이 필요합니다.");
      return;
    }
    if (action === "rulebook") { giveRulebook(player); return; }
    if (action === "ping" || action === "diag") {
      const info = getGameplayStatus();
      const loaded = !!getCommandHandler();
      player.sendMessage("§e[RPG] v0.5.19 | 명령어: 정상 | 게임플레이: " +
        (loaded ? (info.state === "partial" ? "§6일부 오류" : "§a연결됨") : "§c연결 안 됨") +
        " §7(" + info.state + ")");
      if (action === "diag") {
        if (info.errors.length) {
          info.errors.slice(0, 4).forEach((e, i) => player.sendMessage("§c[" + (i+1) + "] " + String(e).slice(0, 250)));
          if (info.errors.length > 4) player.sendMessage("§e추가 오류 " + (info.errors.length - 4) + "개는 콘텐츠 로그에서 확인");
        } else if (!loaded) player.sendMessage("§7게임플레이 초기화 대기 또는 실패. 세계를 다시 불러오고 /rpg:diag 재시도");
        else player.sendMessage("§aRPG 기능 초기화 중 발견된 오류 없음");
      }
      return;
    }
    const handler = getCommandHandler();
    if (!handler) {
      player.sendMessage("§c[RPG] 명령어는 로드됐으나 RPG 게임플레이 스크립트 로드에 실패했습니다. 콘텐츠 로그를 확인하세요.");
      return;
    }
    if ((action === "setlevel" || action === "setmana") && String(arg ?? "").trim() === "") {
      player.sendMessage("§e[RPG] 사용법: " + (action === "setlevel" ? "/rpg:setlevel 100" : "/rpg:setmana 100000 또는 /rpg:setmana reset"));
      return;
    }
    handler(action, player, arg);
  } catch (e) {
    try { player.sendMessage("§c[RPG] 명령어 실행 오류: " + String(e)); } catch {}
    console.warn("[rpg/commands] action " + action + ": " + String(e));
  }
}

// The registry has to run during system.beforeEvents.startup. This module is a
// SEPARATE script entry, so bugs in unrelated RPG skill modules can't block it.
mc.system.beforeEvents.startup.subscribe(event => {
  const registry = event.customCommandRegistry;
  if (!registry) {
    console.warn("[rpg/commands] CustomCommandRegistry unavailable. Use /function rulebook or !rulebook.");
    return;
  }
  const permission = [mc.CommandPermissionLevel, mc.CustomCommandPermissionLevel]
    .find(p => p && p.Any !== undefined && p.GameDirectors !== undefined);
  const type = mc.CustomCommandParamType;
  const status = mc.CustomCommandStatus;
  if (!permission || !status || !type) {
    console.warn("[rpg/commands] Missing API enum: CommandPermissionLevel/CustomCommandParamType/CustomCommandStatus");
    return;
  }
  let success = 0;
  for (const [action, description, param, admin] of names) {
    try {
      const def = {
        name: "rpg:" + action,
        description,
        permissionLevel: admin ? permission.GameDirectors : permission.Any,
        cheatsRequired: false,
      };
      if (param) {
        if (!type) throw Error("CustomCommandParamType not found");
        // Numbers need the integer parser; 'setmana reset' still needs a string.
        if (action === "hito" || action === "pvp" || action === "wings" || action === "wfly" || action === "citycreate") {
          def.optionalParameters = [{ name: param, type: type.String }];
        } else {
          def.mandatoryParameters = [{ name: param, type: action === "setlevel" ? type.Integer : type.String }];
        }
      }
      if(action==='setgrade')def.optionalParameters=[{name:'target',type:type.String}];
      registry.registerCommand(def, (origin, ...args) => {
        const source = origin.sourceEntity ?? origin.initiator;
        if (!source || source.typeId !== "minecraft:player") {
          return { status: status.Failure, message: "플레이어만 사용할 수 있습니다." };
        }
        // Some versions use positional callback parameters; older bridges handed an array.
        const first = args[0];
        const raw = action==='setgrade'?(Array.isArray(first)?first.slice(0,2):args.slice(0,2)).filter(v=>v!==undefined).join(' '):(Array.isArray(first) ? first[0] : first);
        const value = raw == null ? "" : String(raw).trim();
        mc.system.run(() => invoke(action, source, value));
        return { status: status.Success };
      });
      success++;
    } catch (error) {
      console.warn("[rpg/commands] /rpg:" + action + " registration error: " + error);
    }
  }
  console.warn("[rpg/commands] v0.5.19 registered " + success + "/" + names.length + " commands");
  if (success === 0) console.error("[rpg/commands] zero registered: check Script API and content logs");
});

// 채팅 이벤트는 프리릴리스 API일 수 있습니다. 이벤트가 없어도 부팅을 멈추면 안 됩니다.
try {
  const chatSend = mc.world?.beforeEvents?.chatSend;
  if (chatSend && typeof chatSend.subscribe === "function") {
    chatSend.subscribe(event => {
      const message = String(event.message ?? "").trim();
      if (/^!rulebook$/i.test(message)) {
        event.cancel = true;
        const p = event.sender;
        mc.system.run(() => invoke("rulebook", p));
        return;
      }
      if (/^!hito(?:\s|$)/i.test(message)) {
        event.cancel = true;
        const p=event.sender;
        const arg=message.replace(/^!hito\s*/i, "").trim();
        mc.system.run(() => invoke("hito",p,arg));
        return;
      }
      if (!/^!rpg(?:\s|$)/i.test(message)) return;
      event.cancel = true;
      const player = event.sender;
      const tokens = message.replace(/^!rpg\s*/i, "").trim().split(/\s+/);
      const action = (tokens.shift() || "help").toLowerCase();
      const arg = tokens.join(" ");
      mc.system.run(() => invoke(action, player, arg));
    });
  } else {
    console.warn("[rpg/commands] chatSend before-event is unavailable; optional !rpg aliases disabled. /rpg: and /scriptevent remain available.");
  }
} catch (error) {
  console.warn("[rpg/commands] Optional chat aliases unavailable: " + String(error));
}

// A missing optional event must never stop RPG gameplay initialization.
try {
  const eventReceive = mc.system?.afterEvents?.scriptEventReceive;
  if (eventReceive?.subscribe) eventReceive.subscribe(event => {
    if (!["rpg:rulebook", "rpg:ping", "rpg:diag"].includes(event.id)) return;
    const p = event.sourceEntity;
    if (!p || p.typeId !== "minecraft:player") {
      console.warn("[rpg/commands] use /execute as <player> at @s run scriptevent rpg:rulebook");
      return;
    }
    mc.system.run(() => invoke(event.id.slice(4), p));
  });
} catch (error) {
  console.warn("[rpg/commands] scriptEvent handler failed: " + String(error));
}

// RPG 안내서는 자동 지급하지 않습니다. 필요할 때 /rpg:rulebook 으로 받을 수 있습니다.

// Static imports are already resolved above. Never let optional events prevent this step.
function initializeGameplaySafely() {
  if (getGameplayStatus().state !== "loading") return;
  try { initializeGameplay(); }
  catch (error) {
    const detail = String(error?.stack ?? error);
    console.warn("[rpg/gameplay] startup failed: " + detail);
    setGameplayStatus("failed", [detail]);
  }
}

// Preferred tick-deferred initialization, plus worldLoad recovery for unusual startup timing.
try {
  mc.system.run(initializeGameplaySafely);
} catch (error) {
  console.warn("[rpg/gameplay] failed scheduling startup: " + String(error));
}
try {
  const worldLoad = mc.world?.afterEvents?.worldLoad;
  if (worldLoad?.subscribe) worldLoad.subscribe(() => {
    try { mc.system.run(initializeGameplaySafely); }
    catch (error) { console.warn("[rpg/gameplay] worldLoad scheduler: " + String(error)); }
  });
} catch (error) {
  console.warn("[rpg/gameplay] optional worldLoad fallback: " + String(error));
}
