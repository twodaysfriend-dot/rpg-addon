import {world,system} from '@minecraft/server';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {showForm} from './skillMenu.js';
import {getWallet,setWallet} from './wallet.js';
import {duelOf} from './pvp.js';
import {dungeonRuns,dungeonLobbies} from './dungeonState.js';
import {isTimeFrozen} from './timeStopDamage.js';
export const TPA_PRICE=1000;const requests=new Map(),menus=new Set();let registered=false;
const online=id=>world.getAllPlayers().find(p=>p.id===id);
export function travelUnavailable(p){return !p?.isValid||(p.getComponent('minecraft:health')?.currentValue??0)<=0||duelOf(p)||isTimeFrozen(p)||[...dungeonRuns.values(),...dungeonLobbies.values()].some(r=>r.members.some(m=>m.id===p.id))||p.getDynamicProperty('rpg:pvp_arena_return_v1')!==undefined||p.getDynamicProperty('rpg:dungeon_return_v1')!==undefined;}
export function requestTpa(p,target){
 if(p.id===target.id||travelUnavailable(p)||travelUnavailable(target))throw Error('던전·결투·시간 정지·사망 중에는 이동 요청을 할 수 없습니다.');
 if(getWallet(p).gold<TPA_PRICE)throw Error('이동 시 사용할 1,000골드가 필요합니다.');
 requests.set(p.id,{from:p.id,to:target.id,until:Date.now()+30000});p.sendMessage('§b'+target.name+'님에게 이동을 요청했습니다. 수락·이동 성공 시 1,000골드를 사용합니다.');target.sendMessage('§e'+p.name+'님의 이동 요청입니다. 상태창의 받은 이동 요청 또는 /rpg:tpaaccept에서 30초 안에 수락하세요.');
}
export function tpaDestination(target){return {...target.location};}
export function acceptTpa(target,fromId){
 const request=requests.get(fromId),p=online(fromId);
 if(!request||request.to!==target.id||request.until<Date.now())throw Error('유효한 이동 요청이 없습니다.');
 if(travelUnavailable(p)||travelUnavailable(target))throw Error('참가자의 던전·결투·시간 정지·생존 상태를 확인하세요.');
 const before=getWallet(p);if(before.gold<TPA_PRICE)throw Error('요청자의 골드가 부족합니다.');
 const at=tpaDestination(target),origin={dimension:p.dimension,location:{...p.location},rotation:p.getRotation()};requests.delete(fromId);let moved=false;
 try{p.teleport(at,{dimension:target.dimension,keepVelocity:false});moved=true;setWallet(p,{...before,gold:before.gold-TPA_PRICE});}
 catch(error){try{setWallet(p,before);}catch{}if(moved)try{p.teleport(origin.location,{dimension:origin.dimension,rotation:origin.rotation,keepVelocity:false});}catch(rollback){console.error('[RPG TPA return] '+rollback);}throw error;}
 p.sendMessage('§a이동 완료 · 1,000골드를 사용했습니다.');target.sendMessage('§a'+p.name+'님이 이동했습니다.');return true;
}
export async function openTpa(p){
 if(menus.has(p.id))return;menus.add(p.id);
 try{const targets=world.getAllPlayers().filter(t=>t.id!==p.id);const f=new ActionFormData().title('플레이어 이동 요청 · TPA').body('상대가 수락하면 상대의 현재 위치로 이동합니다. 안전한 착지 공간 검사는 하지 않습니다.\n이동 성공 시 요청자의 RPG 골드 1,000을 사용합니다.\n요청·거절·만료에는 비용이 들지 않습니다.');for(const t of targets)f.button(t.name);f.button('닫기');const r=await showForm(f,p);if(r&&!r.canceled&&Number.isInteger(r.selection)&&r.selection>=0&&r.selection<targets.length)requestTpa(p,targets[r.selection]);}
 catch(error){p.sendMessage('§e[TPA] '+String(error.message??error));}finally{menus.delete(p.id);}
}
export async function openTpaInbox(p){
 if(menus.has(p.id))return;menus.add(p.id);
 try{const pending=[...requests.values()].filter(r=>r.to===p.id&&r.until>Date.now()&&online(r.from));const f=new ActionFormData().title('받은 이동 요청').body(pending.length?'요청자를 선택해 수락하거나 거절하세요.':'받은 이동 요청이 없습니다.');for(const r of pending)f.button(online(r.from).name);f.button('닫기');const pick=await showForm(f,p);if(!pick||pick.canceled||!Number.isInteger(pick.selection)||pick.selection<0||pick.selection>=pending.length)return;const req=pending[pick.selection];const reply=await showForm(new MessageFormData().title('이동 요청 수락').body(online(req.from).name+'님을 내 주변으로 이동시킬까요? 상대방이 1,000골드를 사용합니다.').button1('거절').button2('수락'),p);if(reply&&!reply.canceled){if(reply.selection===1)acceptTpa(p,req.from);else requests.delete(req.from);}}
 catch(error){p.sendMessage('§e[TPA] '+String(error.message??error));}finally{menus.delete(p.id);}
}
export function registerTpa(){if(registered)return;registered=true;world.afterEvents.playerLeave.subscribe(e=>{menus.delete(e.playerId);requests.delete(e.playerId);for(const [id,r]of requests)if(r.to===e.playerId)requests.delete(id);});system.runInterval(()=>{for(const [id,r]of requests)if(r.until<Date.now())requests.delete(id);},100);}
