import {world} from '@minecraft/server';
import {travelUnavailable} from './tpa.js';
export function menuTeleport(p,location,dimension){
 if(travelUnavailable(p))throw Error('던전·결투·시간 정지·사망 중에는 이동할 수 없습니다.');
 if(!location||!['x','y','z'].every(k=>Number.isFinite(location[k])))throw Error('이동 좌표가 올바르지 않습니다.');
 p.teleport(location,{dimension,keepVelocity:false,checkForBlocks:true});
}
export function returnToSpawn(p){
 try{menuTeleport(p,world.getDefaultSpawnLocation(),world.getDimension('overworld'));p.sendMessage('§a월드 스폰으로 이동했습니다.');}
 catch(error){p.sendMessage('§e[이동] '+String(error.message??error));}
}
