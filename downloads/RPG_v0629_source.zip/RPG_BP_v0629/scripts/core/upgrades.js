import {openRuneBatch} from './runeBatch.js';
import {maintainWeaponBinding,weaponBinding} from './weaponBinding.js';
import {openRuneSlotUpgradeMenu} from './runeSlotUpgrade.js';
import {itemGrade} from '../data/grades.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {classWeapon} from '../data/classWeapons.js';
import {gearFingerprint,setGearLevel} from './gearState.js';
import {openFusionMenu} from './fusion.js';
import {runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {decorateRarity} from './rarityLabels.js';
import {openArmorTransfer} from './armorTransfer.js';
import { EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { armorInfo, RUNES, RUNE_KEY } from '../data/equipment.js';
import { ARMOR_LEVEL_KEY, RUNE_LEVEL_KEY, upgradeLevel, upgradeCost, upgradedRune, enhancementRates, rollEnhancement, catalystAllowed, CATALYST_ID, MAX_CATALYSTS } from '../data/upgrades.js';
import { getWallet, setWallet, canAfford, walletText } from './wallet.js';
import { showForm } from './skillMenu.js';
import { readRuneBag, writeRuneBag, migrateChestRune } from './runeInventory.js';

const SLOTS = () => [
  {slot:EquipmentSlot.Head, part:'helmet', name:'투구'},
  {slot:EquipmentSlot.Chest, part:'chestplate', name:'흉갑'},
  {slot:EquipmentSlot.Legs, part:'leggings', name:'각반'},
  {slot:EquipmentSlot.Feet, part:'boots', name:'장화'},
];
export function describeRune(id, rank, grade=0) {
  const r = upgradedRune(RUNES[id],rank,grade);
  if (!r) return '없음';
  const values = [];
  if (r.physical && r.physical>1) values.push(`물리 스킬 +${Number(((r.physical-1)*100).toFixed(1))}%`);
  if (r.magic && r.magic>1) values.push(`마법 스킬 +${Number(((r.magic-1)*100).toFixed(1))}%`);
  if(rank>0&&['power','arcane'].includes(id))values.push('공용·직업 무기 근접 평타 +'+Number((((r.physical??r.magic)-1)*100).toFixed(1))+'%');
  if (r.defense) values.push('RPG 방어력 +'+Number(r.defense.toFixed(1))+' (피해 감소 '+Number((r.defense*.35).toFixed(2))+'%)');
  if (r.health) values.push(`최대 HP +${Number(r.health.toFixed(2))}`);
  if (r.manaRegenPercent) values.push(`초당 최대 마나의 +${Number((r.manaRegenPercent*100).toFixed(1))}% 회복`);
  if (r.lifesteal) values.push('준 피해의 '+Number((r.lifesteal*100).toFixed(1))+'% 흡혈');
  if (r.ward) values.push('저항 '+(r.wardAmplifier+1));
  if (r.speed) values.push('신속 '+(r.speedAmplifier+1));
  for (const t of r.extraText??[]) values.push(t);
  return rarityBadge(runeRarity(grade))+' · '+values.join(', ');
}

function weaponAt(player,slot){
 if(Number.isInteger(slot)){const inv=player.getComponent('minecraft:inventory')?.container;return slot>=0&&slot<(inv?.size??0)?inv.getItem(slot):undefined;}
 return slot===EquipmentSlot.Mainhand?player.getComponent('minecraft:equippable')?.getEquipment(slot):undefined;
}
export function inventoryWeaponQuotes(player){
 const inv=player.getComponent('minecraft:inventory')?.container,quotes=[];
 for(let slot=0;slot<(inv?.size??0);slot++)if(COMMON_WEAPONS.some(w=>w.id===inv.getItem(slot)?.typeId)){
  const quote=enhancementQuote(player,'weapon',slot);if(quote)quotes.push(quote);
 }
 return quotes;
}
function fingerprint(item) {return gearFingerprint(item);}
export function enhancementQuote(player,kind,slot) {
  if(kind==='rune') {
    const rune=readRuneBag(player).runes.find(r=>r.uid===slot);if(!rune)return undefined;
    return {kind,slot,level:rune.level,runeId:rune.id,fingerprint:JSON.stringify(rune),cost:upgradeCost(kind,rune.level),name:RUNES[rune.id].name,
      effect:describeRune(rune.id,rune.level,rune.grade)+'\n→ '+describeRune(rune.id,rune.level+1,rune.grade)};
  }
  if(kind==='weapon'){
    if(slot!==EquipmentSlot.Mainhand&&!Number.isInteger(slot))return undefined;
    const item=weaponAt(player,slot),jobWeapon=classWeapon(item?.typeId),w=COMMON_WEAPONS.find(w=>w.id===item?.typeId)??jobWeapon;
    if(!w||item.amount!==1||(Number.isInteger(slot)&&!COMMON_WEAPONS.some(w=>w.id===item.typeId)))return undefined;const level=upgradeLevel(item,kind);
    return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:w.name,effect:jobWeapon?`직업 무기 · 등급·승급 없음\n근접 피해 +${level} → +${level+1}\n물리·마법 스킬 피해 +${level*2}% → +${(level+1)*2}%`:`${rarityBadge(itemGrade(item))} 등급 유지 · 강화 근접 피해 +${level} → +${level+1}`};
  }
  if(kind!=='armor')return undefined;
  const definition=SLOTS().find(s=>s.slot===slot),item=player.getComponent('minecraft:equippable')?.getEquipment(slot);
  const info=armorInfo(item?.typeId);if(!definition||info?.part!==definition.part)return undefined;
  const level=upgradeLevel(item,'armor');return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:info.name+' '+definition.name,effect:`${rarityBadge(itemGrade(item))} 등급 유지\n부위 강화 HP +${level} → +${level+1}`};
}

export function enhanceEquipped(player,kind,slot,expectedFingerprint,options={}) {
  try {
    const quote=enhancementQuote(player,kind,slot);
    if (!quote) return {ok:false,reason:'강화할 RPG 갑옷·공용·직업 무기·보관 룬이 없습니다.'};
    if (!quote.cost) return {ok:false,reason:'이미 최대 강화 단계입니다.'};
    if (expectedFingerprint!==undefined&&quote.fingerprint!==expectedFingerprint) return {ok:false,reason:'장비 또는 강화 단계가 변경됐습니다. 다시 선택하세요.'};
    const catalystCount=options.catalystCount??0;
    const rates=enhancementRates(kind,quote.level,catalystCount);
    if (!rates) return {ok:false,reason:'촉매 수량은 0~5개이며, 갑옷·무기 +5·룬 +2부터 사용할 수 있습니다.'};
    const wallet=getWallet(player);
    if (!canAfford(wallet,quote.cost)) return {ok:false,reason:'강화에 필요한 재화가 부족합니다.'};
    const eq=player.getComponent('minecraft:equippable');
    const inventory=player.getComponent('minecraft:inventory')?.container;
    const catalysts=[];
    let needed=catalystCount;
    if(needed>0&&inventory)for(let i=0;i<inventory.size&&needed>0;i++) {
      const token=inventory.getItem(i);
      if(token?.typeId!==CATALYST_ID||token.amount<1)continue;
      const take=Math.min(needed,token.amount);
      catalysts.push({slot:i,original:token.clone(),take});needed-=take;
    }
    if(needed>0)return {ok:false,reason:`강화 촉매 ${catalystCount}개가 필요합니다.`};
    const original=kind!=='rune'?(kind==='weapon'?weaponAt(player,slot):eq.getEquipment(slot)).clone():readRuneBag(player);
    const outcome=rollEnhancement(rates,options.random??Math.random);
    let level=quote.level,target;
    if(outcome==='success')level++;
    if(outcome==='downgrade')level=Math.max(0,level-1);
    if(kind!=='rune') {
      target=original.clone();
      if(outcome==='destroy'){target=undefined;level=0;}
      else target=setGearLevel(target,kind,level);
    }else{
      target=JSON.parse(JSON.stringify(original));
      if(outcome==='destroy'){level=0;target.runes=target.runes.filter(r=>r.uid!==slot);target.equipped=target.equipped.map(uid=>uid===slot?null:uid);}
      else target.runes.find(r=>r.uid===slot).level=level;
    }
    const next=Object.fromEntries(Object.entries(wallet).map(([k,v])=>[k,v-quote.cost[k]]));
    let debited=false,catalystTouched=false;
    try {
      setWallet(player,next);debited=true;
      if(catalysts.length) {
        catalystTouched=true;
        for(const entry of catalysts) {
          if(entry.original.amount===entry.take)inventory.setItem(entry.slot,undefined);
          else {const remaining=entry.original.clone();remaining.amount-=entry.take;inventory.setItem(entry.slot,remaining);}
        }
      }
      if(kind!=='rune'){if(kind==='weapon'&&Number.isInteger(slot))inventory.setItem(slot,target);else if(!eq.setEquipment(slot,target))throw Error('장비 저장 실패');}else writeRuneBag(player,target);
    } catch(error) {
      let recovered=true;
      try {if(kind!=='rune'){if(kind==='weapon'&&Number.isInteger(slot))inventory.setItem(slot,original);else if(!eq.setEquipment(slot,original))recovered=false;}else writeRuneBag(player,original);}catch{recovered=false;}
      if(catalystTouched)for(const entry of catalysts)try{inventory.setItem(entry.slot,entry.original);}catch{recovered=false;}
      if(debited)try{setWallet(player,wallet);}catch{recovered=false;}
      if(!recovered)console.error('[RPG upgrade] rollback incomplete: '+String(error));
      return {ok:false,reason:recovered?'강화를 저장하지 못해 취소하고 재화를 복구했습니다.':'강화 복구에 실패했습니다. 관리자에게 콘텐츠 로그 확인을 요청하세요.'};
    }
    if(kind==='weapon'&&weaponBinding(player))maintainWeaponBinding(player);
    return {ok:true,outcome,level,cost:quote.cost,rates,catalystCount};
  }catch(error){return {ok:false,reason:'강화 오류: '+String(error)};}
}

const menus = new Set();
const KIND_NAMES = {rune:'룬',armor:'갑옷',weapon:'무기'};
function costText(cost) {
  if(!cost)return '§a최대 강화 +10';
  return `골드 ${cost.gold.toLocaleString()}`+(cost.stone?` · 강화석 ${cost.stone}`:'')+(cost.dust?` · 룬 가루 ${cost.dust}`:'');
}
function quoteButton(quote) {
  return `${quote.name} +${quote.level}\n${costText(quote.cost)}`;
}
async function attemptUpgrade(player,quote) {
  if (!quote.cost) {player.sendMessage('§e[RPG] 이미 최대 강화 단계입니다.');return;}
  let catalystCount=0;
  if(catalystAllowed(quote.kind,quote.level)) {
    const inventory=player.getComponent('minecraft:inventory')?.container;
    let owned=0;
    if(inventory)for(let i=0;i<inventory.size;i++){const token=inventory.getItem(i);if(token?.typeId===CATALYST_ID)owned+=token.amount;}
    const maximum=Math.min(MAX_CATALYSTS,owned);
    const form=new ActionFormData().title('강화 촉매 수량')
      .body(`보유 촉매 ${owned}개. 한 번에 최대 5개 사용.\n1개당 성공률 +9%p, 파괴확률 -3%p (최소 0%).\n완료된 모든 결과에서 선택 수량을 소비합니다.`);
    for(let count=0;count<=maximum;count++) {
      const preview=enhancementRates(quote.kind,quote.level,count);
      form.button(`${count===0?'촉매 사용 안 함':count+'개 사용'}\n성공 ${preview.success}% / 파괴 ${preview.destroy}%`);
    }
    form.button('취소');
    const choice=await showForm(form,player);
    if(!choice||choice.canceled||choice.selection==null||choice.selection>maximum)return;
    catalystCount=choice.selection;
  }
  const rates=enhancementRates(quote.kind,quote.level,catalystCount);
  const percentages=`성공 ${rates.success}% / 유지 실패 ${rates.fail}%\n1단계 강등 ${rates.downgrade}% / 파괴 ${rates.destroy}%`;
  const destruction=quote.kind!=='rune'?'장비 파괴 시 해당 장비만 소멸하고 전용 보관함 룬은 유지됩니다.':'룬 파괴 시 해당 보관 룬만 소멸하며 장착도 해제됩니다.';
  const confirm=await showForm(new MessageFormData().title('위험 강화 확인')
    .body(`${quote.name} +${quote.level} → +${quote.level+1}\n${quote.effect}\n\n${percentages}\n${destruction}\n\n비용: ${costText(quote.cost)}\n${catalystCount?'강화 촉매 '+catalystCount+'개 사용\n':''}모든 결과에서 비용이 소비됩니다.`)
    .button1('취소').button2('강화'),player);
  if(!confirm||confirm.canceled||confirm.selection!==1)return;
  const attempt=enhanceEquipped(player,quote.kind,quote.slot,quote.fingerprint,{catalystCount});
  if(!attempt.ok)player.sendMessage('§c[RPG] '+attempt.reason);
  else {
    const messages={success:`§a강화 성공! +${attempt.level}`,fail:'§e강화 실패: 단계 유지',downgrade:`§6강등: +${attempt.level}`,destroy:quote.kind!=='rune'?'§c장비 파괴: 해당 장비 소멸':'§c룬 파괴: 해당 보관 룬 소멸'};
    player.sendMessage('[RPG] '+quote.name+' · '+messages[attempt.outcome]);
  }
}

export async function openUpgradeMenu(player) {await upgradeSession(player,'root');}
export async function openRuneUpgradeMenu(player) {await upgradeSession(player,'runeTypes');}
export async function openArmorUpgradeMenu(player) {await upgradeSession(player,'armor');}
export async function openWeaponUpgradeMenu(player) {await upgradeSession(player,'weapon');}

async function upgradeSession(player,initialPage) {
  if(menus.has(player.id))return;
  menus.add(player.id);
  try {
    const migration=migrateChestRune(player);if(!migration.ok)player.sendMessage('§e'+migration.reason);
    let page=initialPage,runeId;
    for(let count=0;count<160&&player.isValid;count++) {
      const form=new ActionFormData();
      let options=[];
      const wallet=walletText(getWallet(player));
      if(page==='root') {
        form.title('RPG 강화 메뉴').body(wallet+'\n\n강화할 종류를 선택하세요.\n룬·갑옷·무기는 각각의 화면에서 관리합니다.');
        form.button('§d룬 강화\n종류 선택 · 보관 룬 강화')
          .button('§b갑옷 강화\n착용 부위별 강화 · 강화 이전')
          .button('§6무기 강화\n가방 공통 무기 · 손에 든 직업 무기')
          .button('장비 등급 합성').button('닫기');
      } else if(page==='runeTypes') {
        const bag=readRuneBag(player);
        options=Object.entries(RUNES);
        form.title('룬 강화 · 종류 선택').body(wallet+'\n\n강화할 룬 종류를 고르세요.\n장착하지 않은 보관 룬도 강화할 수 있습니다.\n일반 가방의 룬은 룬 보관함에 넣어 주세요.');
        for(const [id,definition] of options) {
          const runes=bag.runes.filter(r=>r.id===id);
          form.button(`${definition.name}\n보유 ${runes.length}개 · 강화 가능 ${runes.filter(r=>r.level<10).length}개`);
        }
        form.button('같은 종류·등급 룬 일괄 강화').button('장착 슬롯 강화 · 해금').button('강화 메뉴로');
      } else if(page==='runes') {
        const bag=readRuneBag(player);
        options=bag.runes.filter(r=>r.id===runeId).map(r=>({rune:r,quote:enhancementQuote(player,'rune',r.uid)}));
        form.title('룬 강화 · '+RUNES[runeId].name).body(wallet+'\n\n강화할 룬 1개를 선택하세요.\n같은 종류도 등급·강화 단계·보관 번호로 구분합니다.\n촉매는 현재 +2부터 최대 5개 사용할 수 있습니다.'+(options.length?'':'\n\n이 종류의 룬이 보관함에 없습니다.'));
        for(const {rune,quote} of options) {
          const slot=bag.equipped.indexOf(rune.uid);
          form.button(`${slot>=0?'§a['+(slot+1)+'번 장착] ':''}${rarityBadge(runeRarity(rune.grade))} +${rune.level} · 보관 #${rune.uid}\n${costText(quote.cost)}`);
        }
        form.button('룬 종류 선택으로');
      } else {
        const kind=page;
        form.title(KIND_NAMES[kind]+' 강화').body(wallet+(kind==='armor'?
          '\n\n착용 중인 RPG 갑옷 부위를 선택하세요.\n최대 +10 · 부위 강화당 최대 HP +1\n총 HP는 게임 효과에 따라 4 HP 단위로 근사합니다.':
          '\n\n가방의 공통 무기는 손에 들지 않고 선택할 수 있습니다. 직업 전용 무기는 주 손에 들어 주세요.\n최대 +10 · 강화당 근접 피해 +1\n직업 무기는 단계당 물리·마법 스킬 피해 +2%')+
          '\n촉매는 현재 +5부터 최대 5개 사용할 수 있습니다.');
        options=kind==='armor'?SLOTS().map(s=>({name:s.name,quote:enhancementQuote(player,kind,s.slot)})):
          [...(classWeapon(weaponAt(player,EquipmentSlot.Mainhand)?.typeId)?[{name:'주 손 직업 무기',quote:enhancementQuote(player,kind,EquipmentSlot.Mainhand)}]:[]),...inventoryWeaponQuotes(player).map(quote=>({name:'가방 '+(quote.slot+1)+'번',quote:{...quote,name:quote.name+' [가방 '+(quote.slot+1)+'번]'}}))];
        for(const {name,quote} of options)form.button(quote?quoteButton(quote):name+'\n강화할 RPG 장비 없음');
        if(kind==='armor')form.button('갑옷 강화 이전');
        form.button('강화 메뉴로');
      }
      const choice=await showForm(form,player);
      if(!choice||choice.canceled||choice.selection==null)return;
      const selected=choice.selection;
      if(page==='root') {
        if(selected===0)page='runeTypes';
        else if(selected===1)page='armor';
        else if(selected===2)page='weapon';
        else if(selected===3)await openFusionMenu(player);
        else return;
      } else if(page==='runeTypes') {
        if(selected===options.length){await openRuneBatch(player);continue;}
        if(selected===options.length+1){await openRuneSlotUpgradeMenu(player);continue;}
        if(selected===options.length+2){page='root';continue;}
        if(!options[selected])return;
        runeId=options[selected][0];page='runes';
      } else if(page==='runes') {
        if(selected===options.length){page='runeTypes';continue;}
        if(!options[selected])return;
        await attemptUpgrade(player,options[selected].quote);
      } else {
        if(selected<options.length) {
          const entry=options[selected];if(!entry)return;
          if(entry.quote)await attemptUpgrade(player,entry.quote);
          else player.sendMessage('§e[RPG] '+entry.name+'에 강화할 RPG 장비가 없습니다.');
        } else if(page==='armor'&&selected===options.length)await openArmorTransfer(player);
        else page='root';
      }
    }
  } catch(error) {try{player.sendMessage('§c[RPG] 강화 메뉴 오류: '+String(error));}catch{}}
  finally {menus.delete(player.id);}
}
