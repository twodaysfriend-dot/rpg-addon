import {STONE_MASK_USED_KEY} from './worldUnlock.js';
import {world,system} from '@minecraft/server';
export const STONE_MASK='rpg:stone_mask';
const OVERRIDE='rpg:mask_job',SUN='rpg_vampire_sun';
export function jobRace(job){return ['the_world','blood_mage'].includes(job)?'vampire':job==='revenant'?'undead':'human';}
export function raceOf(p){const job=p.getDynamicProperty('rpg:job')??'apprentice';return p.getDynamicProperty(OVERRIDE)===job?'vampire':jobRace(job);}
export function raceName(p){return {human:'인간',vampire:'흡혈귀',undead:'언데드'}[raceOf(p)];}
export function exposedToSun(p){
 if(raceOf(p)!=='vampire'||!['overworld','minecraft:overworld'].includes(p.dimension?.id))return false;
 const time=world.getTimeOfDay();if(time>=12000)return false;
 const weather=p.dimension.getWeather?.()??world.getWeather?.();if(weather&&String(weather).toLowerCase()!=='clear')return false;
 const head=p.getHeadLocation();
 // An unloaded column is not positive evidence of exposure.
 try{const top=p.dimension.getTopmostBlock({x:Math.floor(head.x),z:Math.floor(head.z)});return !!top&&top.location.y<head.y;}catch{return false;}
}
export function syncRace(p){if(typeof p.getDynamicProperty(OVERRIDE)==='string'&&p.getDynamicProperty(STONE_MASK_USED_KEY)!==true)p.setDynamicProperty(STONE_MASK_USED_KEY,true);const sun=exposedToSun(p);if(sun){if(!p.hasTag(SUN))p.addTag(SUN);}else if(p.hasTag(SUN))p.removeTag(SUN);return sun;}
export function sunDamageMultiplier(p){return p?.typeId==='minecraft:player'&&exposedToSun(p)?1.5:1;}
export function useStoneMask(p){
 if(!p?.isValid||!['survival','adventure'].includes(String(p.getGameMode?.()).toLowerCase()))return {ok:false,reason:'생존 또는 모험 모드에서 사용하세요.'};
 if(!(p.getComponent('minecraft:health')?.currentValue>0))return {ok:false,reason:'사망 중에는 사용할 수 없습니다.'};
 if(raceOf(p)==='vampire')return {ok:false,reason:'이미 흡혈귀입니다. 돌가면은 소비하지 않습니다.'};
 const inv=p.getComponent('minecraft:inventory')?.container,slot=p.selectedSlotIndex,item=inv?.getItem(slot);
 if(item?.typeId!==STONE_MASK)return {ok:false,reason:'돌가면을 손에 들고 사용하세요.'};
 const old=p.getDynamicProperty(OVERRIDE),oldUsed=p.getDynamicProperty(STONE_MASK_USED_KEY),before=item.clone();
 try{
  p.setDynamicProperty(OVERRIDE,p.getDynamicProperty('rpg:job')??'apprentice');
  if(item.amount===1)inv.setItem(slot,undefined);else{const next=item.clone();next.amount--;inv.setItem(slot,next);}
  p.setDynamicProperty(STONE_MASK_USED_KEY,true);
  syncRace(p);return {ok:true};
 }catch(error){p.setDynamicProperty(OVERRIDE,old);p.setDynamicProperty(STONE_MASK_USED_KEY,oldUsed);inv.setItem(slot,before);return {ok:false,reason:'변환 실패로 아이템을 복구했습니다.'};}
}
const useTicks=new Map();
export function handleStoneMask(p){if((useTicks.get(p.id)??-100)>system.currentTick-3)return;useTicks.set(p.id,system.currentTick);const r=useStoneMask(p);p.sendMessage(r.ok?'§4흡혈귀로 변했습니다. §7햇빛 노출 시 받는 피해 ×1.5 · 준 피해의 10% 흡혈. 전직 시 새 직업의 종족으로 변경됩니다.':'§e'+r.reason);}
let registered=false;
export function registerRaces(){
 if(registered)return;registered=true;
 system.runInterval(()=>{for(const p of world.getAllPlayers())try{syncRace(p);}catch{}},1);
 world.afterEvents.itemUse.subscribe(ev=>{if(ev.itemStack?.typeId===STONE_MASK)system.run(()=>handleStoneMask(ev.source));});
 world.afterEvents.playerSpawn.subscribe(ev=>system.run(()=>{try{syncRace(ev.player);}catch{}}));
 world.afterEvents.playerLeave.subscribe(ev=>useTicks.delete(ev.playerId));
}
