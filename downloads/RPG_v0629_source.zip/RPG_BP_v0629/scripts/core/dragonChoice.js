import {EquipmentSlot} from '@minecraft/server';
import {getJobId} from './playerData.js';
export const DRAGON_CHOICE='rpg:dragon_choice';
export function hasDragonChoice(p){try{return p.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand)?.typeId===DRAGON_CHOICE;}catch{return false;}}
export function dragonChoiceRequirement(p){const met=hasDragonChoice(p)&&getJobId(p)!=='dragon_knight'&&(p.getComponent('minecraft:health')?.currentValue??0)>0;return {met,have:met?1:0,need:1,label:getJobId(p)==='dragon_knight'?'이미 용기사입니다.':'용의 선택을 손에 들고 사용 (전직 확정 시 1개 소비)'};}
