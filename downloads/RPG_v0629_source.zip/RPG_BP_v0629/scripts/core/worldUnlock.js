export const STONE_MASK_USED_KEY='rpg:stone_mask_used_v1';
export const STAND_ARROW='rpg:stand_manifestation_arrow';
export function hasUsedStoneMask(p){return p.getDynamicProperty(STONE_MASK_USED_KEY)===true||typeof p.getDynamicProperty('rpg:mask_job')==='string';}
export function ownsStandArrow(p){try{const inv=p.getComponent('minecraft:inventory')?.container;for(let i=0;i<(inv?.size??0);i++)if(inv.getItem(i)?.typeId===STAND_ARROW)return true;}catch{}return false;}
