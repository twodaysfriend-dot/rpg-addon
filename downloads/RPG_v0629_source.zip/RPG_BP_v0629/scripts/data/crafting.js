// Generated from recipes by tools/make_crafting_catalog.py.
export const CRAFTING_RECIPES = [
{"id": "rpg:stand_manifestation_arrow", "category": "promotion", "name": "스탠드 구현의 화살", "text": "작업대 3×3 (왼쪽 위부터 1~9번)\n금블록 금블록 금블록\n금블록 화살 금블록\n다이아블록 네더라이트주괴 다이아블록\n금 블록 5개·화살 1개·다이아몬드 블록 2개·네더라이트 주괴 1개 → 스탠드 구현의 화살 1개.\n더 월드: RPG 레벨 60 이상·돌가면 사용 이력·이 화살 소지·기존 보스 3/밤 적 60 처치·2차 이상 직업. 사용하거나 전직관에서 전직을 요청하세요. 화살은 소모되지 않습니다."},
{"id": "rpg:dragon_choice", "category": "promotion", "name": "용의 선택", "text": "작업대: 드래곤 알 1개 → 용의 선택 1개. 배치 순서 자유. 손에 들고 사용 후 확정하면 1개를 소비해 용기사로 전직합니다. 기존 엔더맨·보스 처치 시련과 레벨/직업 제한은 적용하지 않습니다."},
{"id": "rpg:stone_mask_fragment", "category": "race", "name": "돌가면 파편", "text": "돌 8개 + 중앙 금 블록 1개 → 돌가면 파편 1개\n돌 돌 돌\n돌 금 돌\n돌 돌 돌"},
{"id": "rpg:stone_mask", "category": "race", "name": "돌가면", "text": "돌가면 파편 8개 + 중앙 네더라이트 주괴 1개 → 돌가면 1개\n파 파 파\n파 네 파\n파 파 파\n사용 시 흡혈귀로 변환. 다음 전직 시 새 직업의 종족으로 변경."},
{"id": "minecraft:nether_star", "category": "recovery", "name": "네더의 별", "text": "작업대 제작 → 네더의 별 ×1\n다이아몬드 ×4 + 네더라이트 주괴 ×1\n\n□ 다 □\n다 네 다\n□ 다 □\n\n다=다이아몬드, 네=네더라이트 주괴"},
{"id": "rpg:status_tablet", "category": "recovery", "name": "상태창", "text": "작업대 제작 → 상태창 ×1\n나침반 ×1 + 종이 ×1 + 자수정 조각 ×1\n배치 순서는 자유입니다. 사용해도 소모되지 않습니다. 접속 시 최초 1개 지급됩니다."},
  {
    "id": "rpg:abyssal_boots",
    "category": "armor",
    "name": "심연 수호자 장화",
    "text": "작업대 제작 → 심연 수호자 장화 ×1\n\n재료:\n숲 수호자 장화 ×1\n네더라이트 주괴 ×1\n네더의 별 ×1\n다이아몬드 ×2\n자수정 조각 ×4\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:abyssal_chestplate",
    "category": "armor",
    "name": "심연 수호자 흉갑",
    "text": "작업대 제작 → 심연 수호자 흉갑 ×1\n\n재료:\n숲 수호자 흉갑 ×1\n네더라이트 주괴 ×1\n네더의 별 ×1\n다이아몬드 ×2\n자수정 조각 ×4\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:abyssal_helmet",
    "category": "armor",
    "name": "심연 수호자 투구",
    "text": "작업대 제작 → 심연 수호자 투구 ×1\n\n재료:\n숲 수호자 투구 ×1\n네더라이트 주괴 ×1\n네더의 별 ×1\n다이아몬드 ×2\n자수정 조각 ×4\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:abyssal_leggings",
    "category": "armor",
    "name": "심연 수호자 각반",
    "text": "작업대 제작 → 심연 수호자 각반 ×1\n\n재료:\n숲 수호자 각반 ×1\n네더라이트 주괴 ×1\n네더의 별 ×1\n다이아몬드 ×2\n자수정 조각 ×4\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:adventurer_boots",
    "category": "armor",
    "name": "모험가 장화",
    "text": "작업대 제작 → 모험가 장화 ×1\n\n재료:\n철 주괴 ×4\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 □ 철\n철 구 철\n□ □ □"
  },
  {
    "id": "rpg:adventurer_chestplate",
    "category": "armor",
    "name": "모험가 흉갑",
    "text": "작업대 제작 → 모험가 흉갑 ×1\n\n재료:\n철 주괴 ×7\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 □ 철\n철 구 철\n철 철 철"
  },
  {
    "id": "rpg:adventurer_helmet",
    "category": "armor",
    "name": "모험가 투구",
    "text": "작업대 제작 → 모험가 투구 ×1\n\n재료:\n철 주괴 ×4\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 구 철\n철 □ 철\n□ □ □"
  },
  {
    "id": "rpg:adventurer_leggings",
    "category": "armor",
    "name": "모험가 각반",
    "text": "작업대 제작 → 모험가 각반 ×1\n\n재료:\n철 주괴 ×6\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 구 철\n철 □ 철\n철 □ 철"
  },
  {
    "id": "rpg:astral_boots",
    "category": "armor",
    "name": "별빛 술사 장화",
    "text": "작업대 제작 → 별빛 술사 장화 ×1\n\n재료:\n모험가 장화 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:astral_chestplate",
    "category": "armor",
    "name": "별빛 술사 흉갑",
    "text": "작업대 제작 → 별빛 술사 흉갑 ×1\n\n재료:\n모험가 흉갑 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:astral_helmet",
    "category": "armor",
    "name": "별빛 술사 투구",
    "text": "작업대 제작 → 별빛 술사 투구 ×1\n\n재료:\n모험가 투구 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:astral_leggings",
    "category": "armor",
    "name": "별빛 술사 각반",
    "text": "작업대 제작 → 별빛 술사 각반 ×1\n\n재료:\n모험가 각반 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:common_battle_spear",
    "category": "weapon",
    "name": "정예기사의 대검",
    "text": "작업대 제작 → 정예기사의 대검 ×1\n\n재료:\n철 주괴 ×4\n다이아몬드 ×2\n네더라이트 주괴 ×1\n막대기 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:common_battle_sword",
    "category": "weapon",
    "name": "마공학 검",
    "text": "작업대 제작 → 마공학 검 ×1\n\n재료:\n철 주괴 ×3\n구리 주괴 ×2\n레드스톤 ×1\n자수정 조각 ×1\n막대기 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:common_beast_axe",
    "category": "weapon",
    "name": "마수의 도끼",
    "text": "작업대 제작 → 마수의 도끼 ×1\n\n재료:\n다이아몬드 도끼 ×1\n금 주괴 ×2\n네더라이트 주괴 ×1\n뼈 ×2\n에메랄드 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:common_flame_greatsword",
    "category": "weapon",
    "name": "화염의 대검",
    "text": "작업대 제작 → 화염의 대검 ×1\n\n재료:\n다이아몬드 검 ×1\n블레이즈 가루 ×3\n마그마 크림 ×2\n다이아몬드 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:common_frost_greatsword",
    "category": "weapon",
    "name": "빙설의 대검",
    "text": "작업대 제작 → 빙설의 대검 ×1\n\n재료:\n다이아몬드 검 ×1\n꽁꽁 언 얼음 ×3\n다이아몬드 ×2\n자수정 조각 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:common_magitech_greatsword",
    "category": "weapon",
    "name": "마공학 대검",
    "text": "작업대 제작 → 마공학 대검 ×1\n\n재료:\n철 주괴 ×4\n구리 주괴 ×2\n레드스톤 ×1\n다이아몬드 ×1\n막대기 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:common_redmoon_blade",
    "category": "weapon",
    "name": "적월선",
    "text": "작업대 제작 → 적월선 ×1\n\n재료:\n철 주괴 ×2\n금 주괴 ×2\n레드스톤 ×2\n자수정 조각 ×1\n다이아몬드 ×1\n막대기 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:enhancement_catalyst",
    "category": "catalyst",
    "name": "강화 촉매",
    "text": "작업대 제작 → 강화 촉매 ×1\n\n재료:\n네더의 별 ×1\n자수정 조각 ×4\n다이아몬드 ×2\n엔더 진주 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:job_waiver",
    "category": "recovery",
    "name": "전직 포기각서",
    "text": "작업대 제작 → 전직 포기각서 ×1\n\n재료:\n종이 ×4\n먹물 주머니 ×2\n철 주괴 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_absorption",
    "category": "rune",
    "name": "흡수의 룬",
    "text": "작업대 제작 → 흡수의 룬 ×1\n\n재료:\n자수정 조각 ×3\n철 주괴 ×2\n프리즈머린 수정 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_arcane",
    "category": "rune",
    "name": "비전의 룬",
    "text": "작업대 제작 → 비전의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n엔더 진주 ×1\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_mana",
    "category": "rune",
    "name": "샘의 룬",
    "text": "작업대 제작 → 샘의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n청금석 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_power",
    "category": "rune",
    "name": "힘의 룬",
    "text": "작업대 제작 → 힘의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×2\n철 주괴 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_vitality",
    "category": "rune",
    "name": "생명의 룬",
    "text": "작업대 제작 → 생명의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n황금사과 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_ward",
    "category": "rune",
    "name": "수호의 룬",
    "text": "작업대 제작 → 수호의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n철 주괴 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:sandbag_spawner",
    "category": "training",
    "name": "훈련용 샌드백 소환",
    "text": "작업대 제작 → 훈련용 샌드백 소환 ×1\n\n재료:\n건초 더미 ×9\n\n배치도 (건=건초 더미):\n건 건 건\n건 건 건\n건 건 건"
  },
  {
    "id": "rpg:stat_reset_scroll",
    "category": "recovery",
    "name": "스탯 초기화 주문서",
    "text": "작업대 제작 → 스탯 초기화 주문서 ×1\n\n재료:\n종이 ×4\n청금석 ×3\n금 주괴 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:warden_boots",
    "category": "armor",
    "name": "숲 수호자 장화",
    "text": "작업대 제작 → 숲 수호자 장화 ×1\n\n재료:\n모험가 장화 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:warden_chestplate",
    "category": "armor",
    "name": "숲 수호자 흉갑",
    "text": "작업대 제작 → 숲 수호자 흉갑 ×1\n\n재료:\n모험가 흉갑 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:warden_helmet",
    "category": "armor",
    "name": "숲 수호자 투구",
    "text": "작업대 제작 → 숲 수호자 투구 ×1\n\n재료:\n모험가 투구 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  },
  {
    "id": "rpg:warden_leggings",
    "category": "armor",
    "name": "숲 수호자 각반",
    "text": "작업대 제작 → 숲 수호자 각반 ×1\n\n재료:\n모험가 각반 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n재료 갑옷은 소비됩니다. 강화된 갑옷은 /rpg:transfer에서 강화 이전서로 먼저 추출하고 제작한 뒤 적용하세요. 인챈트는 승계되지 않으며 룬 보관함은 유지됩니다."
  }
];
