import vm from 'node:vm';import fs from 'node:fs';import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0629';
const intervals=[],events=new Map(),players=[];
const event=key=>{if(!events.has(key))events.set(key,[]);return {subscribe:fn=>events.get(key).push(fn)};};
const world={getAllPlayers:()=>players,afterEvents:new Proxy({},{get:(_,k)=>event(k)}),beforeEvents:new Proxy({},{get:(_,k)=>event(k)})};
const system={runInterval:fn=>intervals.push(fn)};
const values={world,system,ItemStack:class{},EquipmentSlot:{Offhand:'off',Chest:'chest'},EntityDamageCause:{magic:'magic'},InputButton:{Jump:'jump'},ButtonState:{Pressed:'pressed'},getJobId:p=>p.job,isFrenzyActive:()=>false};
const context=vm.createContext({console}),m=new vm.SourceTextModule(fs.readFileSync(root+'/RPG_BP_v0629/scripts/core/wings.js','utf8'),{context});
await m.link(spec=>{const names=spec==='@minecraft/server'?['world','system','ItemStack','EquipmentSlot','EntityDamageCause','InputButton','ButtonState']:spec==='@minecraft/server-ui'?['ActionFormData']:spec.includes('skillMenu')?['showForm']:spec.includes('playerData')?['getJobId']:['isFrenzyActive'];return new vm.SyntheticModule(names,function(){for(const n of names)this.setExport(n,values[n]);},{context});});await m.evaluate();const api=m.namespace;api.registerWings();
for(const job of ['angel','michael']){
 const props=new Map(),impulses=[];const p={id:job,job,isOnGround:true,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),sendMessage:()=>{},getComponent:()=>({getEquipment:slot=>slot==='off'?{typeId:job==='angel'?'rpg:angel_wing_toggle':'rpg:michael_wing_toggle'}:undefined}),getVelocity:()=>({x:0,y:0,z:0}),getViewDirection:()=>({x:0,y:0,z:1}),applyImpulse:v=>impulses.push(v),dimension:{},location:{x:0,y:0,z:0}};
 players.splice(0,players.length,p);assert.equal(api.wingSpeedMultiplier(p),1);
 const fire=()=>events.get('playerButtonInput').forEach(fn=>fn({player:p,button:'jump',newButtonState:'pressed'}));
 fire();p.isOnGround=false;intervals[0]();intervals[0]();fire();
 const speeds=[];for(const mode of [1,2,3]){assert.equal(api.setWingSpeed(p,String(mode)),true);intervals[0]();speeds.push(impulses.at(-1).z);}
 assert.ok(Math.abs(speeds[1]/speeds[0]-2)<1e-9);assert.ok(Math.abs(speeds[2]/speeds[0]-5)<1e-9);
 for(const mode of ['0','4','2x',''])assert.equal(api.setWingSpeed(p,mode),false);
 assert.equal(api.wingSpeedMultiplier(p),5);p.job='fallen_angel';assert.equal(api.setWingSpeed(p,'3'),false);assert.equal(api.wingSpeedMultiplier(p),1);
}
console.log('Angel and Michael: double jump engages real glide tick; speed modes produce 1x/2x/5x forward steering, invalid modes rejected, other classes unchanged');
