"""Keep the protected armor's native components and compatible recipes in sync."""
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
bp = root / 'RPG_BP_v0638'
attachables = root / 'RPG_RP_v0638' / 'attachables'
sets = ('adventurer', 'warden', 'astral', 'abyssal')
parts = ('helmet', 'chestplate', 'leggings', 'boots')
names = [f'{armor_set}_{part}' for armor_set in sets for part in parts]
protected = {f'rpg:{name}': f'rpg:{name}_unbreakable' for name in names}
check = '--check' in sys.argv


def write(path, data):
    encoded = json.dumps(data, ensure_ascii=False, indent=2) + '\n'
    if check:
        assert path.read_text() == encoded, f'Stale generated file: {path}'
    else:
        path.write_text(encoded)


for name in names:
    path = bp / 'items' / f'{name}.json'
    data = json.loads(path.read_text())
    item = data['minecraft:item']
    item['description']['identifier'] = protected[item['description']['identifier']]
    item['description']['menu_category'] = {'category': 'none'}
    item['components']['minecraft:durability']['damage_chance'] = {'min': 0, 'max': 0}
    write(path.with_stem(name + '_unbreakable'), data)
    path = attachables / f'{name}.json'
    data = json.loads(path.read_text())
    desc = data['minecraft:attachable']['description']
    desc['identifier'] = protected[desc['identifier']]
    write(path.with_stem(name + '_unbreakable'), data)

for result_set in ('warden', 'astral', 'abyssal'):
    for part in parts:
        name = f'{result_set}_{part}'
        path = bp / 'recipes' / f'{name}.json'
        data = json.loads(path.read_text())
        recipe = data['minecraft:recipe_shapeless']
        for ingredient in recipe['ingredients']:
            if ingredient.get('item') in protected:
                ingredient['item'] = protected[ingredient['item']]
        recipe['description']['identifier'] += '_from_unbreakable'
        write(path.with_stem(name + '_from_unbreakable'), data)

print('Verified' if check else 'Generated', '16 protected armor items, 16 attachables and 12 compatible recipes')
