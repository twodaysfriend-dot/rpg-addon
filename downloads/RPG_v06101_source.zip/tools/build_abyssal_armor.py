"""Compose abyssal armor with existing native race, ward and resurrection sensors.

Keep native armor and Protection enchantments. Above Bedrock's 20 armor cap,
each overflow point reduces remaining damage by 4%; toughness adds 1% per point.
Damage sensor triggers are mutually exclusive; resurrection triggers stay intact.
"""
import copy
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
path = root / 'RPG_BP_v0638/entities/player.json'
original = path.read_text()
data = json.loads(original)
entity = data['minecraft:entity']
profiles = [(0, 0)] + [(n, overflow) for n in (1, 2, 3) for overflow in range(n * 2 + 1)] + [(4, 8)]
prefix = 'rpg_abyssal_'

# Each active Bloodedge shield has a slot; only entities marked in front of that
# specific player match. Slots let two players face the same attacker independently.
guard = {'any_of': [
    {'all_of': [
        {'test': 'has_tag', 'subject': 'self', 'value': f'rpg_be_guard_{slot}'},
        {'any_of': [{'test': 'has_tag', 'subject': subject, 'value': f'rpg_be_front_{slot}'}
                    for subject in ('other', 'damager')]},
    ]}
    for slot in range(16)
]}
guard_event = 'rpg:bloodedge_block_front'
# Stable Script API measures the promoted shield's nonfatal hits in the hurt event.
# Keep lethal hits blocked in the native sensor even during that measurement.
measure = {'test': 'has_tag', 'subject': 'self', 'value': 'rpg_be_measure'}
pvp_source = {'any_of': [
    condition
    for subject in ('other', 'damager')
    for condition in (
        {'test': 'is_family', 'subject': subject, 'value': 'player'},
        {'test': 'has_tag', 'subject': subject, 'value': 'rpg_player_owned'},
    )
]}
non_pvp_source = {'none_of': [pvp_source]}
pvp_multiplier = .08

def without_resurrection_filter(filters):
    # The native resurrection predicate already excludes every PvP source.
    if 'none_of' in filters and 'rpg:resurrection_armed' in json.dumps(filters['none_of']):
        return None
    if 'all_of' not in filters:
        return filters
    return {'all_of': [
        kept for child in filters['all_of']
        if (kept := without_resurrection_filter(child)) is not None
    ]}

protected_guard = {'all_of': [guard, {'any_of': [{'none_of': [measure]}, {'test': 'has_damage', 'value': 'fatal'}]}]}
siwang_tag = {'test': 'has_tag', 'subject': 'self', 'value': 'rpg_siwang_fall'}
siwang_fall = {'all_of': [siwang_tag, {'test': 'has_damage', 'value': 'fall'}]}
siwang_sensor = {'cause': 'fall', 'deals_damage': False, 'on_damage': {'filters': siwang_tag}}
entity['description']['properties']['rpg:siwang_phase'] = {
    'type': 'int', 'range': [0, 2], 'default': 0, 'client_sync': True,
}

for container in [entity['components'], *entity['component_groups'].values()]:
    sensor = container.get('minecraft:damage_sensor')
    if not sensor:
        continue
    templates = []
    for trigger in sensor['triggers']:
        trigger = copy.deepcopy(trigger)
        on_damage = trigger.get('on_damage', {})
        if on_damage.get('event') == guard_event or trigger == siwang_sensor:
            continue
        f = on_damage.get('filters', {})
        first = f.get('all_of', [{}])[0]
        if first == pvp_source:
            continue
        if first == non_pvp_source:
            f = f['all_of'][1]
            on_damage['filters'] = f
        tail = f.get('all_of', [{}])[-1]
        if (tail in ({'none_of': [guard]}, {'none_of': [protected_guard]})
                or siwang_fall in tail.get('none_of', [])):
            f = f['all_of'][0]
            on_damage['filters'] = f
        tail = f.get('all_of', [{}])[-1]
        if tail.get('test') == 'has_tag' and str(tail.get('value', '')).startswith(prefix):
            continue
        if 'none_of' in tail and any(str(x.get('value', '')).startswith(prefix) for x in tail['none_of']):
            trigger['on_damage']['filters'] = f['all_of'][0]
        templates.append(trigger)
    result = []
    pvp_triggers = []
    for template in templates:
        if 'damage_multiplier' not in template:
            result.append(template)
            continue
        for count, overflow in profiles:
            trigger = copy.deepcopy(template)
            condition = ({'none_of': [{'test': 'has_tag', 'subject': 'self', 'value': 'rpg_abyssal_active'}]}
                         if not count else {'test': 'has_tag', 'subject': 'self', 'value': prefix + str(count * 9 + overflow)})
            trigger['on_damage']['filters'] = {'all_of': [template['on_damage']['filters'], condition]}
            multiplier = template['damage_multiplier'] * (1 - overflow * .04) * (1 - count * .04)
            trigger['damage_multiplier'] = round(multiplier, 10)
            result.append(trigger)
            pvp_trigger = copy.deepcopy(trigger)
            pvp_trigger['on_damage']['filters'] = {'all_of': [
                pvp_source, without_resurrection_filter(template['on_damage']['filters']),
                condition, {'none_of': [siwang_fall]},
            ]}
            pvp_trigger['damage_multiplier'] = round(multiplier * pvp_multiplier, 10)
            pvp_triggers.append(pvp_trigger)
    # An intentional dive must not trigger normal fall damage or consume a resurrection.
    for trigger in result:
        gate = trigger.get('on_damage', {})
        excluded = [protected_guard] if gate.get('event') == 'rpg:resurrection_save' else []
        if trigger['cause'] in ('all', 'fall'):
            excluded.append(siwang_fall)
        if excluded:
            gate['filters'] = {'all_of': [gate['filters'], {'none_of': excluded}]}
        if 'damage_multiplier' in trigger:
            gate['filters'] = {'all_of': [non_pvp_source, gate['filters']]}
    sensor['triggers'] = [{
        'cause': 'all', 'deals_damage': False,
        'on_damage': {'event': guard_event, 'target': 'self', 'filters': protected_guard},
    }, siwang_sensor, *pvp_triggers, *result]

groups = [f'rpg:abyssal_knockback_{n}' for n in range(5)]
for count, key in enumerate(groups):
    entity['component_groups'][key] = {'minecraft:knockback_resistance': {'value': round(count * .2, 2)}}
    entity['events'][key] = {'sequence': [{'remove': {'component_groups': groups}}, {'add': {'component_groups': [key]}}]}
entity['events'][guard_event] = {}
pool_group = 'rpg:bloodedge_untargetable'
entity['component_groups'][pool_group] = {
    'minecraft:cannot_be_attacked': {}, 'minecraft:is_hidden_when_invisible': {},
}
entity['events']['rpg:bloodedge_pool_on'] = {'add': {'component_groups': [pool_group]}}
entity['events']['rpg:bloodedge_pool_off'] = {'remove': {'component_groups': [pool_group]}}
# Native profile combinations repeat filters; compact JSON keeps the pack small.
output = json.dumps(data, ensure_ascii=False, separators=(',', ':')) + '\n'
if '--check' in sys.argv:
    assert output == original, 'Stale generated abyssal armor sensors'
else:
    path.write_text(output)
print('Verified' if '--check' in sys.argv else 'Generated', '17 armor profiles across native race/ward sensors; knockback 0/20/40/60/80%')
