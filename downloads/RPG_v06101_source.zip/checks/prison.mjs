import vm from 'node:vm';import fs from 'node:fs';import assert from 'node:assert/strict';
const root=process.argv[2]??'.',base=root+'/RPG_BP_v0638/';
async function load(file,bindings={}){const source=fs.readFileSync(base+file,'utf8'),ctx=vm.createContext({console}),m=new vm.SourceTextModule(source,{context:ctx});await m.link(async spec=>{const names=new Set();for(const h of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(h[2]===spec)for(const n of h[1].split(','))names.add(n.trim().split(/\s+as\s+/)[0]);return new vm.SyntheticModule([...names],function(){for(const n of names)this.setExport(n,bindings[n]??(()=>{}));},{context:ctx});});await m.evaluate();return m.namespace;}
async function setup(store=new Map()){
 const blocks=new Map(),players=[],hooks={},providers=new Map(),system={currentTick:0,run:fn=>fn(),runInterval:()=>1,runTimeout:fn=>fn()};let writes=0,failAt=0;
 const dim={id:'minecraft:overworld',runCommand:()=>({successCount:1}),getBlock:at=>{const key=`${at.x},${at.y},${at.z}`;return {get typeId(){return blocks.get(key)??'minecraft:air';},get isAir(){return !blocks.has(key)||blocks.get(key)==='minecraft:air';},get permutation(){return {type:blocks.get(key)??'minecraft:air'};},setPermutation(p){writes++;if(writes===failAt)throw Error('write failure');if(p.type==='minecraft:air')blocks.delete(key);else blocks.set(key,p.type);}};}};
 const events=new Proxy({},{get:(_,k)=>({subscribe:fn=>(hooks[k]??=[]).push(fn)})});
 const world={getAllPlayers:()=>players,getDimension:()=>dim,getDynamicProperty:k=>store.get(k),setDynamicProperty:(k,v)=>store.set(k,v),afterEvents:events};
 function player(name,admin=false){const tags=new Set(),props=new Map(),p={id:'id-'+name,name,typeId:'minecraft:player',isValid:true,commandPermissionLevel:admin?1:0,hp:100,location:{x:0,y:65,z:0},dimension:dim,messages:[],getComponent:k=>k==='minecraft:health'?{currentValue:p.hp,effectiveMax:100,effectiveMin:0,setCurrentValue:n=>p.hp=n}:undefined,getGameMode:()=> 'survival',getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),setProperty:()=>{},addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),sendMessage:t=>p.messages.push(t),getRotation:()=>({x:0,y:0}),teleport(at,options){p.location={...at};p.dimension=options.dimension;}};players.push(p);return p;}
 const bindings={world,system,BlockPermutation:{resolve:type=>({type})},registerStructureProtection:(name,fn)=>providers.set(name,fn)};
 const api=await load('scripts/core/prison.js',bindings);
 const step=n=>{for(let i=0;i<n;i++){system.currentTick++;api.tickPrison();}};
 return {store,blocks,players,system,world,dim,hooks,providers,bindings,api,player,step,get writes(){return writes;},set failAt(n){failAt=n;}};
}
const arrest=(h,p)=>{for(let i=0;i<3;i++)h.api.recordPrisonPk(p);};
{
 const h=await setup(),admin=h.player('admin',true),p=h.player('offender');
 assert.throws(()=>h.api.createPrison(p),/관리자/);assert.equal(h.api.createPrison(admin),true);const saved=JSON.parse(h.store.get(h.api.PRISON_KEY));assert.equal(saved.config.cells.length,10);assert.equal(new Set(saved.config.cells.map(c=>`${c.x},${c.z}`)).size,10);
 h.api.recordPrisonPk(p);h.api.recordPrisonPk(p);assert.equal(h.api.getPrisonRecord(p).stacks,2);assert.equal(h.api.isJailed(p),false);
 h.api.recordPrisonPk(p);assert.equal(h.api.getPrisonRecord(p).stacks,0);assert.equal(h.api.getPrisonRecord(p).remaining,'6000');assert.ok(h.api.prisonContains(p));
 h.step(2);assert.equal(h.api.getPrisonRecord(p).remaining,'5999');const before=h.api.getPrisonRecord(p).remaining;
 p.location={...p.location,x:p.location.x+1};h.step(1);assert.equal(h.api.getPrisonRecord(p).remaining,before);assert.ok(h.api.prisonContains(p));h.step(1);assert.equal(h.api.getPrisonRecord(p).remaining,before);h.step(1);assert.equal(BigInt(h.api.getPrisonRecord(p).remaining),BigInt(before)-1n);
 const deathTime=h.api.getPrisonRecord(p).remaining;p.hp=0;h.step(5);assert.equal(h.api.getPrisonRecord(p).remaining,deathTime);p.hp=100;h.step(1);assert.equal(h.api.getPrisonRecord(p).remaining,deathTime);
 const same=h.api.getPrisonRecord(p).remaining;p.dimension={id:'minecraft:nether'};h.step(1);assert.equal(h.api.getPrisonRecord(p).remaining,same);assert.equal(p.dimension.id,'minecraft:overworld');
 assert.throws(()=>h.api.releasePrisoner(p,'offender'),/관리자/);assert.throws(()=>h.api.resetPrisonHistory(p,'offender'),/관리자/);
 h.api.releasePrisoner(admin,'offender');assert.equal(h.api.isJailed(p),false);assert.equal(h.api.getPrisonRecord(p).visits,1);
 arrest(h,p);assert.equal(h.api.getPrisonRecord(p).remaining,'12000');h.api.releasePrisoner(admin,'offender');arrest(h,p);assert.equal(h.api.getPrisonRecord(p).remaining,'24000');
 h.api.resetPrisonHistory(admin,'offender');assert.equal(h.api.getPrisonRecord(p).remaining,'6000');assert.equal(h.api.getPrisonRecord(p).visits,0);h.api.releasePrisoner(admin,'offender');arrest(h,p);assert.equal(h.api.getPrisonRecord(p).remaining,'6000');
 h.step(6002);assert.equal(h.api.isJailed(p),false);assert.equal(h.api.getPrisonRecord(p).remaining,'0');
 h.api.registerPrison();const protect=h.providers.get('pk_prison'),at=saved.config.cells[0],block={dimension:h.dim,location:{x:Math.floor(at.x),y:at.y,z:Math.floor(at.z)}};assert.equal(protect(block,p),true);assert.equal(protect(block,admin),false);assert.equal(protect(block),true);
}
{
 const h=await setup(),a=h.player('admin',true);h.api.createPrison(a);const criminals=Array.from({length:11},(_,i)=>h.player('p'+i));for(const p of criminals)arrest(h,p);
 assert.equal(criminals.filter(p=>h.api.getPrisonRecord(p).cell!=null).length,10);const pending=criminals.find(p=>h.api.getPrisonRecord(p).cell==null);const remaining=h.api.getPrisonRecord(pending).remaining;h.step(10);assert.equal(h.api.getPrisonRecord(pending).remaining,remaining);
 h.api.releasePrisoner(a,'p0');h.step(1);assert.notEqual(h.api.getPrisonRecord(pending).cell,null);
 h.api.registerPrison();const target=criminals[1],value=h.api.getPrisonRecord(target).remaining;h.players.splice(h.players.indexOf(target),1);for(const fn of h.hooks.playerLeave)fn({playerId:target.id});h.step(100);assert.equal(h.api.getPrisonRecord(target).remaining,value);
 const restored=await setup(h.store),admin=restored.player('admin',true),back=restored.player('p1');restored.step(1);assert.equal(restored.api.getPrisonRecord(back).remaining,value);assert.ok(restored.api.prisonContains(back));restored.step(2);assert.ok(BigInt(restored.api.getPrisonRecord(back).remaining)<BigInt(value));
 restored.players.splice(restored.players.indexOf(back),1);restored.api.releasePrisoner(admin,'p1');restored.players.push(back);restored.step(1);assert.equal(restored.api.isJailed(back),false);assert.equal(back.location.x,JSON.parse(restored.store.get(restored.api.PRISON_KEY)).config.exit.x,'Offline release must move the returning player out of the physical cell');
}
{
 const h=await setup(),admin=h.player('admin',true);h.blocks.set('6,66,10','minecraft:chest');const original=new Map(h.blocks);assert.throws(()=>h.api.createPrison(admin),/기존 블록/);assert.deepEqual(h.blocks,original);assert.equal(JSON.parse(h.store.get(h.api.PRISON_KEY)??'{"config":null}').config,null);
 const k=await setup(),a=k.player('admin',true);k.failAt=5;assert.throws(()=>k.api.createPrison(a),/write failure/);assert.equal(k.blocks.size,0);assert.equal(k.store.has(k.api.PRISON_KEY),false);
 const p=k.player('pending');arrest(k,p);assert.equal(k.api.isJailed(p),true);k.step(100);assert.equal(k.api.getPrisonRecord(p).remaining,'6000');assert.equal(k.api.getPrisonRecord(p).cell,null);
}
{
 const h=await setup(),a=h.player('admin',true),p=h.player('criminal'),v=h.player('victim');h.api.createPrison(a);
 const wallet=new Map();const getWallet=p=>wallet.get(p.id)??{gold:10000},setWallet=(p,n)=>wallet.set(p.id,n);
 const pvp=await load('scripts/core/pvp.js',{...h.bindings,arenaReady:()=>true,enterDuelArena:()=>{},insidePvpArena:()=>true,releaseDuelArena:()=>{},recordPrisonPk:h.api.recordPrisonPk,isJailed:h.api.isJailed,dungeonRuns:new Map(),getWallet,setWallet,BALANCE_MAX:1e12});
 for(let i=0;i<3;i++){h.system.currentTick++;pvp.recordPvpDeath(p,v);pvp.recordPvpDeath(p,v);}assert.equal(h.api.getPrisonRecord(p).visits,1);assert.equal(h.api.getPrisonRecord(p).stacks,0);assert.equal(h.api.isJailed(p),true);
 assert.throws(()=>pvp.requestDuel(p,v),/수감/);
 const d1=h.player('duelist1'),d2=h.player('duelist2');pvp.requestDuel(d1,d2);pvp.acceptDuel(d2);pvp.recordPvpDeath(d1,d2);assert.equal(h.api.getPrisonRecord(d1),undefined,'Consensual duels must not create prison stacks');
 const hunter=h.player('hunter'),wanted=h.player('wanted');pvp.markPk(wanted);h.system.currentTick++;pvp.recordPvpDeath(hunter,wanted);assert.equal(h.api.getPrisonRecord(hunter),undefined,'Bounty kills must not create prison stacks');
 const indirect=h.player('indirect'),later=h.player('later');pvp.notePvpAttack(indirect,later,5);h.players.splice(h.players.indexOf(indirect),1);h.system.currentTick++;pvp.recordPvpDeath(undefined,later);assert.equal(h.api.getPrisonRecord(indirect).stacks,1,'Offline indirect killer retains PK stack');
 const tpa=await load('scripts/core/tpa.js',{...h.bindings,isJailed:h.api.isJailed,duelOf:()=>undefined,isTimeFrozen:()=>false,dungeonRuns:new Map(),dungeonLobbies:new Map(),getWallet,setWallet});
 assert.throws(()=>tpa.requestTpa(p,v),/감옥/);assert.throws(()=>tpa.requestTpa(v,p),/감옥/);assert.equal(getWallet(p).gold,10000);
 const sender=h.player('sender'),acceptor=h.player('acceptor');tpa.requestTpa(sender,acceptor);arrest(h,sender);assert.throws(()=>tpa.acceptTpa(acceptor,sender.id),/감옥/);assert.equal(getWallet(sender).gold,10000,'An accepted request cannot bypass a later arrest or debit gold');
 const runs=new Map(),lobbies=new Map(),r={members:[{id:p.id},{id:v.id}],anchors:new Map(),finishing:false};runs.set('run',r);
 p.setDynamicProperty('rpg:dungeon_return_v1','old');
 const dungeon=await load('scripts/core/dungeons.js',{...h.bindings,isJailed:h.api.isJailed,dungeonRuns:runs,dungeonLobbies:lobbies,activeDungeonRun:()=>r});
 assert.equal(dungeon.enforceDungeonBounds(p,r),false);assert.ok(r.members.every(m=>m.id!==p.id));assert.equal(p.getDynamicProperty('rpg:dungeon_return_v1'),undefined);
 assert.throws(()=>dungeon.enterDungeon(p,1),/수감/);assert.throws(()=>dungeon.startDungeon(p),/수감/);assert.throws(()=>dungeon.soloDungeon(p,1),/수감/);
 p.setDynamicProperty('rpg:pvp_arena_return_v1','old');const arena=await load('scripts/core/pvpArena.js',{...h.bindings,isJailed:h.api.isJailed});assert.equal(arena.restoreArenaPlayer(p),false);assert.equal(p.getDynamicProperty('rpg:pvp_arena_return_v1'),undefined);
 const move=await load('scripts/core/dungeonMovement.js',{...h.bindings,isJailed:h.api.isJailed,dungeonRuns:new Map()});assert.throws(()=>move.teleportForSkill(p,{x:100,y:65,z:100}),/Prison/);
}
{
 const h=await setup(),p=h.player('long-history');h.api.recordPrisonPk(p);
 const saved=JSON.parse(h.store.get(h.api.PRISON_KEY));saved.players[p.id].visits=55;saved.players[p.id].stacks=2;h.store.set(h.api.PRISON_KEY,JSON.stringify(saved));
 const restored=await setup(h.store),a=restored.player('long-history');restored.api.recordPrisonPk(a);assert.equal(restored.api.getPrisonRecord(a).remaining,(6000n<<55n).toString());
}
console.log('Prison: ten 1x1 cells, third-PK stack reset, 5/10/20-minute escalation and admin release/reset, inside-only countdown, escape/dimension/death/offline/restart persistence, capacity queue, protected structures, safe build rollback, deduplicated PvP deaths and TPA/skill movement guards passed');
