import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0638'),base=root+'/RPG_BP_v0638/scripts/';
const source=fs.readFileSync(base+'data/fantasyCity.js','utf8'),context=vm.createContext({console});const data=new vm.SourceTextModule(source,{context});await data.link(()=>{});await data.evaluate();
const planner=data.namespace,{operations,houses}=planner.makeFantasyCityPlan();let area=0,clipped=0,volume=0;const sum=o=>(o.x2-o.x+1)*(o.y2-o.y+1)*(o.z2-o.z+1);
for(const o of operations){assert.ok(o.x>=0&&o.z>=0&&o.x2<250&&o.z2<250&&o.y>=-1&&o.y2<=30,JSON.stringify(o));volume+=sum(o);}
for(let i=0;i<16;i++){const t=planner.cityTile(i);area+=(t.x2-t.x+1)*(t.z2-t.z+1);for(const op of planner.tileOperations(operations,t))clipped+=sum(op);}
assert.equal(area,62500);assert.equal(clipped,volume);assert.ok(houses>=20);
const material=(x,y,z)=>operations.find(o=>x>=o.x&&x<=o.x2&&y>=o.y&&y<=o.y2&&z>=o.z&&z<=o.z2)?.type;
assert.equal(material(249,-1,249),'minecraft:stone_bricks');assert.equal(material(125,1,0),undefined);assert.equal(material(0,1,50),'minecraft:stone_bricks');assert.equal(material(38,1,30),undefined);assert.equal(material(33,3,30),'minecraft:glass');assert.equal(material(125,0,125),'minecraft:gold_block');assert.equal(material(125,1,125),undefined);
for(const [id,x,z]of planner.CITY_TRAINERS){assert.ok(material(x,0,z));assert.equal(material(x,1,z),undefined);}
console.log(`Compact city: 250x250, ${houses} buildings, ${volume} placement visits, 16 tiles, usable gates/windows/NPCs and center spawn passed`);
async function runtime(store=new Map(),options={}){
 const messages=[],commands=[],npcs=[],writes=[],timers=[];let count=0,queries=0,now=100000;
 const p={id:'admin',location:{x:1000.8,y:65.9,z:-700.2},dimension:{id:'minecraft:overworld'},sendMessage:s=>messages.push(s)};
 const dim={runCommand:s=>{commands.push(s);return {successCount:options.loadFailure?0:1};},getTopmostBlock:()=>{queries++;return {location:{y:options.top??63}};},getBlock:location=>{const key=[location.x,location.y,location.z].join(',');return {get isAir(){return options.blocks?!options.blocks.has(key):!options.existing;},get typeId(){return options.blocks?options.blocks.get(key)??'minecraft:air':options.existing?'minecraft:chest':'minecraft:air';},getComponent:()=>options.containers?.get(key),setPermutation:permutation=>{count++;if(options.blocks){if(permutation.type==='minecraft:air')options.blocks.delete(key);else options.blocks.set(key,permutation.type);}if(writes.length<512)writes.push({location,permutation});}};},getEntities:q=>npcs.filter(n=>n.type===q.type&&Math.hypot(n.location.x-q.location.x,n.location.z-q.location.z)<=q.maxDistance),spawnEntity:(type,location)=>npcs.push({type,location})};
 const world={getDimension:()=>dim,getAllPlayers:()=>options.offline?[]:[p,...(options.players??[])],getDefaultSpawnLocation:()=>({x:9999,y:200,z:9999}),setDefaultSpawnLocation:pos=>options.newSpawn=pos,getDynamicProperty:k=>store.get(k),setDynamicProperty:(k,v)=>v===undefined?store.delete(k):store.set(k,v)};
 const system={currentTick:0,run:fn=>timers.push(fn),runInterval:()=>1},ctx=vm.createContext({console,Date:class extends Date{static now(){return now;}}});
 const m=new vm.SourceTextModule(fs.readFileSync(base+'core/fantasyCity.js','utf8'),{context:ctx}),plan=new vm.SourceTextModule(source,{context:ctx});await plan.link(()=>{});
 const ext=new vm.SyntheticModule(['world','system','BlockPermutation'],function(){this.setExport('world',world);this.setExport('system',system);this.setExport('BlockPermutation',{resolve:(type,states)=>({type,states})});},{context:ctx});
 const region=new vm.SyntheticModule(['setSpawnRegion'],function(){this.setExport('setSpawnRegion',s=>store.set('region',JSON.stringify(s)));},{context:ctx});
 await m.link(s=>s.includes('spawnEffects')?region:s.startsWith('.')?plan:ext);await m.evaluate();const api=m.namespace;
 return {api,p,store,options,messages,commands,npcs,writes,timers,get count(){return count;},get queries(){return queries;},tick(){now+=50;system.currentTick++;api.tickFantasyCity();},saved(){return JSON.parse(store.get(api.CITY_KEY));}};
}
{
 const t=await runtime();assert.equal(t.api.createFantasyCity(t.p,''),true);assert.equal(t.saved().x,875);assert.equal(t.saved().z,-826);assert.equal(t.saved().y,64);let n=0;
 while(t.saved().phase!=='done'&&n++<10000)t.tick();assert.equal(t.saved().phase,'done');assert.equal(t.queries,62500);assert.equal(t.npcs.length,8);assert.equal(t.options.newSpawn.x,1000);assert.equal(t.options.newSpawn.z,-701);assert.equal(t.options.newSpawn.y,65);assert.ok(t.commands.every(s=>s.includes('rpg_city_build_v1')));assert.ok(t.writes.every(w=>w.location.x>=875&&w.location.x<1125&&w.location.z>=-826&&w.location.z< -576));
 console.log(`Compact full simulated build completed in ${n} ticks at caller's X/Z, 8 NPCs, and no resume request`);
}
{
 const t=await runtime(new Map(),{top:210});t.api.createFantasyCity(t.p,'');let n=0;while(t.saved().phase==='survey'&&n++<10000)t.tick();assert.equal(t.saved().phase,'build');assert.equal(t.saved().y,211);assert.equal(t.count,0);
 while(t.count===0&&n++<11000)t.tick();assert.ok(t.count>0);t.api.stopFantasyCity(t.p);const count=t.count;t.tick();assert.equal(t.count,count);assert.equal(t.saved().manualPause,true);t.api.resumeFantasyCity(t.p);assert.equal(t.saved().manualPause,false);
 const copy=JSON.parse(t.store.get(t.api.CITY_KEY));copy.manualPause=false;t.store.set(t.api.CITY_KEY,JSON.stringify(copy));const restored=await runtime(t.store);restored.api.registerFantasyCity();restored.timers[0]();assert.equal(restored.saved().manualPause,false);for(let i=0;i<25;i++)restored.tick();assert.ok(restored.count>0);
 console.log('Automatic height adjustment and world-restart continuation passed; explicit manual stop still respected');
}
{
 const opts={loadFailure:true},t=await runtime(new Map(),opts);t.api.createFantasyCity(t.p,'');t.tick();assert.ok(t.saved().error);assert.equal(t.count,0);opts.loadFailure=false;for(let i=0;i<150;i++)t.tick();assert.ok(t.queries>0);assert.equal(t.saved().manualPause,false);
 const off={offline:true},u=await runtime(new Map(),off);u.api.createFantasyCity(u.p,'');for(let i=0;i<25;i++)u.tick();assert.equal(u.queries,0);off.offline=false;for(let i=0;i<25;i++)u.tick();assert.ok(u.queries>0);
 console.log('Chunk-load failure and offline idle automatically continue without /cityresume');
}
{
 const old=JSON.stringify({version:1,phase:'done',x:0,z:0,y:200});
 const store=new Map([['rpg:fantasy_city_v1',old]]),t=await runtime(store);t.api.registerFantasyCity();t.timers[0]();for(let i=0;i<20;i++)t.tick();
 assert.equal(t.count,0);assert.equal(store.get(t.api.CITY_KEY),old);assert.equal(store.has('rpg:fantasy_city_1000_archive'),false);
 assert.equal(t.api.createFantasyCity(t.p,''),true);assert.equal(t.saved().size,250);assert.equal(t.saved().designRevision,2);
 const options={existing:true},v=await runtime(new Map(),options);v.api.createFantasyCity(v.p,'');let n=0;while(v.saved().phase==='survey'&&n++<10000)v.tick();for(let i=0;i<25;i++)v.tick();assert.equal(v.count,0);
 console.log('Retired 1000-city metadata remains untouched, no old build/trim resumes, fresh compact plan usable; occupied blocks preserved');
}
{
 for(const phase of ['done','trim','decorate']){
  const s={version:2,size:250,x:875,y:64,z:-826,owner:'admin',phase,tile:16,op:0,offset:0,manualPause:false,retries:0};
  const archive=JSON.stringify({version:1,phase:'done',x:0,y:50,z:0});
  const store=new Map([['rpg:fantasy_city_v1',JSON.stringify(s)],['rpg:fantasy_city_1000_archive',archive]]),t=await runtime(store,{existing:true});
  t.api.registerFantasyCity();t.timers[0]();for(let i=0;i<30;i++)t.tick();assert.equal(t.saved().phase,'done');assert.equal(t.count,0);assert.equal(store.get('rpg:fantasy_city_1000_archive'),archive);
 }
 const s={version:2,designRevision:1,size:250,x:875,y:64,z:-826,owner:'admin',phase:'build',tile:1,op:3,offset:5,manualPause:false,retries:0};
 const t=await runtime(new Map([['rpg:fantasy_city_v1',JSON.stringify(s)]]));t.api.registerFantasyCity();t.timers[0]();for(let i=0;i<30;i++)t.tick();assert.equal(t.saved().phase,'paused_legacy');assert.equal(t.count,0);
 t.api.resumeFantasyCity(t.p);t.tick();assert.equal(t.saved().manualPause,true);assert.equal(t.count,0);t.p.location.x=3000;assert.equal(t.api.createFantasyCity(t.p,''),true);assert.equal(t.saved().designRevision,2);
 console.log('Old decoration/trim work stops without touching buildings or archived save data; obsolete partial plans cannot resume using new operation indexes');
}
{
 const roofs=operations.filter(o=>o.y>=6&&o.type.endsWith('_stairs')),floor=operations.filter(o=>o.y===0&&o.y2===0),floors=new Set(floor.map(o=>o.type));
 assert.ok(roofs.length>200);assert.ok(roofs.some(o=>o.states.weirdo_direction===0&&!o.states.upside_down_bit));assert.ok(roofs.some(o=>o.states.weirdo_direction===1&&!o.states.upside_down_bit));assert.ok(roofs.some(o=>o.states.upside_down_bit));
 for(const type of ['minecraft:mossy_cobblestone','minecraft:mossy_stone_bricks','minecraft:moss_block','minecraft:andesite','minecraft:chiseled_stone_bricks','minecraft:polished_blackstone_bricks'])assert.ok(floors.has(type),type);
 assert.ok(floor.some(o=>o.type.endsWith('_stairs')&&o.states.upside_down_bit));assert.equal(material(30,7,35),'minecraft:dark_oak_planks');
 console.log(`Village decoration geometry: ${roofs.length} oriented roof/eave stair operations, flat-topped stair pavement, ${floors.size} floor materials, closed eaves and clear routes`);
}
{
 const schema=JSON.parse(fs.readFileSync(new URL('./city_blocks.json',import.meta.url),'utf8')).blocks;
 for(const op of operations){assert.ok(schema[op.type],op.type);for(const [key,value]of Object.entries(op.states??{}))assert.ok(schema[op.type][key]?.includes(value),op.type+' '+key+' '+value);}
 assert.equal(operations.filter(o=>o.type==='minecraft:oak_leaves'&&o.states?.persistent_bit).length,30);assert.equal(operations.filter(o=>o.type==='minecraft:flowering_azalea').length,24);
 console.log('All planned vanilla block IDs and explicit states match bundled Mojang metadata; planted yards, benches and two market canopies verified');
}
