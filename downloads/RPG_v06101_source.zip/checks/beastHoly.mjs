import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-dev/v0638',base=root+'/RPG_BP_v0638/';
async function load(file,bindings={}){
 const source=fs.readFileSync(base+file,'utf8'),context=vm.createContext({console});
 const m=new vm.SourceTextModule(source,{context});
 await m.link(async spec=>{
  const names=new Set();
  for(const hit of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(hit[2]===spec)for(const n of hit[1].split(','))names.add(n.trim().split(/\s+as\s+/)[0]);
  return new vm.SyntheticModule([...names],function(){for(const n of names)this.setExport(n,bindings[n]??(n==='projectileMotion'?(_p,speed,steps=1)=>({speed,steps,step:speed/steps}):()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}
const defs=(await load('scripts/data/skills.js')).SKILLS,jobs=(await load('scripts/data/jobs.js')).JOBS;
const mobs=await load('scripts/data/mobXp.js'),leveled=await load('scripts/data/leveledMonsters.js');
function setup(before=true){
 let next=0;const callbacks=new Map(),hooks={},targets=[],effects=[],damage=[],impulses=[];
 const system={currentTick:0,runInterval(fn,period){callbacks.set(++next,{fn,period,due:this.currentTick+period});return next;},runTimeout(fn,delay){callbacks.set(++next,{fn,period:0,due:this.currentTick+Math.max(1,delay)});return next;},clearRun:id=>callbacks.delete(id)};
 function events(prefix){return new Proxy({},{get:(_,key)=>({subscribe:fn=>{(hooks[prefix+key]??=[]).push(fn);}})});}
 const world={beforeEvents:before?events('before:'):{},afterEvents:events('after:'),getAllPlayers:()=>[],getDay:()=>2};
 const dim={id:'minecraft:overworld',blocked:false};
 function entity(id,type='minecraft:zombie'){
  const e={id,typeId:type,isValid:true,isOnGround:false,job:type==='minecraft:player'?'beast':undefined,location:{x:0,y:0,z:3},dimension:dim,hp:10000,effects:[],props:new Map(),isAllied:false,
   getComponent(k){if(k==='minecraft:health')return {currentValue:e.hp,effectiveMax:10000,setCurrentValue:n=>e.hp=n};if(k==='minecraft:type_family')return {hasTypeFamily:f=>f==='monster'&&e.typeId!=='minecraft:player'};if(k==='minecraft:tameable')return {isTamed:e.tamed??false};},
   getDynamicProperty:k=>e.props.get(k),setDynamicProperty:(k,v)=>e.props.set(k,v),
   applyDamage(n){damage.push({id:e.id,n});e.hp-=n;return true;},addEffect(id,ticks,options){e.effects.push({id,ticks,...options});effects.push({entity:e,id,ticks,...options});},
   teleport(at){e.location={...at};},applyImpulse(v){impulses.push({id:e.id,...v});},setOnFire:()=>{},getViewDirection:()=>({x:0,y:0,z:1}),getHeadLocation:()=>({...e.location,y:e.location.y+1.6}),
   onScreenDisplay:{setActionBar:s=>e.message=s},getEffects:()=>[{typeId:'weakness'},{typeId:'poison'}],removeEffect:id=>(e.removed??=[]).push(id),
  };return e;
 }
 const p=entity('caster','minecraft:player');p.location={x:0,y:0,z:0};p.hp=100;
 const bindings={world,system,CONFIG:{pvp:false},VANILLA_HOSTILES:mobs.VANILLA_HOSTILES,LEVELED_MONSTERS:leveled.LEVELED_MONSTERS,
  healthAlive:e=>!!e&&e.isValid!==false&&e.hp>0,getJobId:e=>e?.job,getSkills:e=>e?.skills??[],canUseSkill:(p,id,allowed)=>!!p&&(allowed.includes(p.job)||(p.job==='chameleon'&&p.skills?.includes(id))),
  areAllies:(p,e)=>e.isAllied,getTargets:()=>targets,skillDamageFor:(p,n)=>n,applyStatus:(e,id,ticks,options)=>e.addEffect(id,ticks,options),ccScale:e=>e.boss?.5:1,ccTicks:(e,n)=>e.boss?Math.ceil(n/2):n,
  dist3:(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z),isSolidAt:dim=>dim.blocked,flatDir:()=>({x:0,z:1}),
  EntityDamageCause:{magic:'magic',entityAttack:'entityAttack'},heldItemId:p=>p.job==='beast'?'rpg:beast_axe':'rpg:mangnani_axe',skillItemId:p=>p.job==='beast'?'rpg:beast_axe':'rpg:mangnani_axe',currentScriptHit:()=>false,
  setCombatHealth:(victim,src,h,n)=>h.setCurrentValue(n),scriptedHit:(t,p,fn)=>fn(),ItemStack:class{constructor(id,amount){this.typeId=id;this.amount=amount;}}
 };
 function step(n){for(let i=0;i<n;i++){system.currentTick++;for(const [id,c]of [...callbacks])if(callbacks.has(id)&&c.due<=system.currentTick){if(c.period)c.due+=c.period;else callbacks.delete(id);c.fn();}}}
 function fire(key,ev){for(const fn of hooks[key]??[])fn(ev);}
 return {p,dim,entity,system,world,bindings,targets,effects,damage,impulses,step,fire,callbacks};
}
async function beast(before=true){const h=setup(before);h.api=await load('scripts/skills/berserker.js',h.bindings);h.api.registerBerserker();return h;}
{
 const h=await beast();
 for(let i=0;i<80;i++){const e=h.entity('m'+i);e.location={x:30,y:0,z:40};h.targets.push(e);}
 const boss=h.entity('boss','rpg:hydra_boss');boss.boss=true;h.targets.push(boss);
 for(const [id,configure]of [['far',e=>e.location={x:0,y:0,z:50.01}],['ally',e=>e.isAllied=true],['pet',e=>e.tamed=true],['player',e=>e.typeId='minecraft:player'],['other-dimension',e=>e.dimension={id:'minecraft:nether'}],['summon',e=>e.props.set('rpg:necro_owner','owner')]]){const e=h.entity(id);configure(e);h.targets.push(e);}
 assert.equal(h.api.RUNNERS.beast_taunt(h.p,jobs.beast,defs.beast_taunt),true);
 assert.equal(h.effects.length,81);assert.ok(h.effects.every(e=>e.id==='weakness'&&e.ticks===600&&e.amplifier===1));
 h.step(4);assert.equal(h.impulses.length,81);assert.ok(h.impulses.every(v=>v.y===0));assert.ok(h.impulses.find(v=>v.id==='m0').x<0);
 h.p.location.x=100;h.step(4);assert.ok(h.impulses.findLast(v=>v.id==='m0').x>0);
 h.dim.blocked=true;const count=h.impulses.length;h.step(4);assert.equal(h.impulses.length,count);h.dim.blocked=false;
 h.step(587);const at599=h.impulses.length;h.step(5);assert.equal(h.impulses.length,at599);
 assert.equal(h.api.RUNNERS.beast_taunt({...h.p,job:'mangnani'},jobs.mangnani,defs.beast_taunt),false);
 console.log('Taunt: all 81 loaded monsters including exact 50-block boundary/boss get Weakness II for 600 ticks and follow moving caster; no cap, allies/pets/players/summons/other dimensions/out-of-range excluded, wall checks and expiry passed');
}
for(const reason of ['leave','death','dimension','job']){
 const h=await beast(),e=h.entity('victim');h.targets.push(e);h.api.RUNNERS.beast_taunt(h.p,jobs.beast,defs.beast_taunt);h.step(4);const n=h.impulses.length;
 if(reason==='leave')h.fire('after:playerLeave',{playerId:h.p.id});if(reason==='death')h.p.hp=0;if(reason==='dimension')h.p.dimension={id:'minecraft:nether'};if(reason==='job')h.p.job='mage';
 h.step(8);assert.equal(h.impulses.length,n,reason);
}
for(const job of ['beast','mangnani']){
 const h=await beast();h.p.job=job;const e=h.entity('victim');h.targets.push(e);h.api.RUNNERS.berserker_slam(h.p,jobs[job],defs.berserker_slam);
 assert.equal(h.damage[0].n,job==='beast'?30:18);h.step(12);assert.equal(e.location.y,10);
 e.isOnGround=true;h.step(1);assert.equal(h.damage.length,1,'peak is not a landing');
 e.location.y=0;h.step(1);assert.deepEqual(h.damage.map(v=>v.n),job==='beast'?[30,10]:[18]);h.step(20);assert.equal(h.damage.length,job==='beast'?2:1);
 h.api.RUNNERS.berserker_execute(h.p,jobs[job],defs.berserker_execute);
 const hit={hurtEntity:e,damage:10,damageSource:{cause:'entityAttack',damagingEntity:h.p}};h.fire('before:entityHurt',hit);assert.equal(hit.damage,job==='beast'?60:40);
 const next={...hit,damage:10};h.fire('before:entityHurt',next);assert.equal(next.damage,10,'buff consumed once');
 h.api.RUNNERS.berserker_execute(h.p,jobs[job],defs.berserker_execute);e.hp=1499;const lethal={...hit,damage:10};h.fire('before:entityHurt',lethal);assert.equal(lethal.damage,1499,'below 15% execution retained');
}
{
 const h=await beast(),e=h.entity('ceiling-victim');h.targets.push(e);h.dim.blocked=true;h.api.RUNNERS.berserker_slam(h.p,jobs.beast,defs.berserker_slam);h.step(20);e.isOnGround=true;h.step(3);assert.deepEqual(h.damage.map(v=>v.n),[30]);
}
{
 const h=await beast(),e=h.entity('moved-victim');h.targets.push(e);h.api.RUNNERS.berserker_slam(h.p,jobs.beast,defs.berserker_slam);h.step(12);e.dimension={id:'minecraft:nether'};e.location.y=0;e.isOnGround=true;h.step(5);assert.equal(h.damage.length,1);
}
console.log('Beast slam: real runner deals 30 then one 10 on landing, ceiling/stale-ground/dimension exclusions; Mangnani remains 18 and no landing hit. Execute: Beast x6/Mangnani x4, single use and <15% execution retained');
{
 const h=await beast(),e=h.entity('flame-target');h.targets.push(e);h.api.RUNNERS.beast_flame_burst(h.p,jobs.beast,defs.beast_flame_burst);h.step(40);assert.deepEqual(h.damage.map(v=>v.n),[25,25,25,25,25]);
 h.damage.length=0;h.api.RUNNERS.beast_grand_explosion(h.p,jobs.beast,defs.beast_grand_explosion);h.step(19);assert.equal(h.damage.length,0);h.step(1);assert.equal(h.damage[0].n,90);
}
for(const [job,amount]of [['cleric',2],['angel',4],['michael',6]]){
 const h=setup(),items=[];h.p.job=job;h.p.getComponent=key=>key==='minecraft:inventory'?{container:{addItem:i=>{items.push(i);}}}:undefined;
 const holy=await load('scripts/skills/holy.js',h.bindings);holy.RUNNERS.holy_pray(h.p,jobs[job],defs.holy_pray);h.step(199);assert.equal(items.length,0);h.step(1);assert.equal(items[0].typeId,'rpg:blessing_light');assert.equal(items[0].amount,amount);
 assert.equal(holy.RUNNERS.holy_pray(h.p,jobs[job],defs.holy_pray),false);h.step(200);assert.equal(items.length,1,'same-day repeat denied');
}
{
 const h=setup(),holy=await load('scripts/skills/holy.js',h.bindings);holy.registerHoly();
 h.fire('after:itemCompleteUse',{source:h.p,itemStack:{typeId:'rpg:holy_water'}});
 assert.ok(h.p.effects.some(e=>e.id==='strength'&&e.amplifier===2&&e.ticks===2400));assert.ok(h.p.effects.some(e=>e.id==='resistance'&&e.amplifier===1&&e.ticks===2400));assert.ok(h.p.effects.some(e=>e.id==='regeneration'&&e.amplifier===1&&e.ticks===200));assert.deepEqual(h.p.removed,['weakness','poison']);
 const before=h.effects.length;h.fire('after:itemCompleteUse',{source:h.p,itemStack:{typeId:'minecraft:potion'}});assert.equal(h.effects.length,before);
}
console.log('Flame burst: five actual projectile hits at 25 each; explosion 90 after 20 ticks. Prayer completes with 2/4/6 lights and same-day denial; consumed holy water grants Strength III/Resistance II for 2400 ticks, retains cleansing/Regeneration II');

for(const job of ['beast','mangnani']){
 const h=await beast(false);h.p.job=job;const e=h.entity('fallback-target');e.hp=9990;
 h.api.RUNNERS.berserker_execute(h.p,jobs[job],defs.berserker_execute);
 h.fire('after:entityHurt',{hurtEntity:e,damage:10,damageSource:{cause:'entityAttack',damagingEntity:h.p}});
 assert.equal(e.hp,10000-(job==='beast'?60:40),'stable API post-hurt path');
 const after=e.hp;h.fire('after:entityHurt',{hurtEntity:e,damage:10,damageSource:{cause:'entityAttack',damagingEntity:h.p}});assert.equal(e.hp,after,'no second extra hit');
}
console.log('Stable API fallback without before-hurt: Beast x6 and Mangnani x4 execute multipliers applied once through actual post-hurt handler');
