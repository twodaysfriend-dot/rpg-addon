import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const root=process.argv[2]??'.';const slots={Mainhand:'Mainhand',Offhand:'Offhand',Head:'Head',Chest:'Chest',Legs:'Legs',Feet:'Feet'};
let interval;const hooks={},world={getAllPlayers:()=>[p],afterEvents:new Proxy({},{get:(_,key)=>({subscribe:fn=>hooks[key]=fn})})};
const system={runInterval:fn=>interval=fn};const context=vm.createContext({console,Date,Math});
const m=new vm.SourceTextModule(fs.readFileSync(root+'/RPG_BP_v0638/scripts/core/mendingBoost.js','utf8'),{context});
const equipment=new vm.SourceTextModule(fs.readFileSync(root+'/RPG_BP_v0638/scripts/data/equipment.js','utf8'),{context});
await m.link(specifier=>{
 if(specifier==='../data/equipment.js')return equipment;
 if(specifier==='./commonWeapons.js')return new vm.SyntheticModule(['COMMON_WEAPONS'],function(){this.setExport('COMMON_WEAPONS',[]);},{context});
 return new vm.SyntheticModule(['world','system','EquipmentSlot'],function(){this.setExport('world',world);this.setExport('system',system);this.setExport('EquipmentSlot',slots);},{context});
});
await m.evaluate();const api=m.namespace;
class Item{
 constructor(id='rpg:abyssal_chestplate',damage=100,mending=true){this.typeId=id;this.props=new Map([['rpg:rarity',6],['rpg:armor_upgrade',10]]);this.durability={damage,maxDurability:3200};this.enchants=mending?[{type:{id:'minecraft:mending'},level:1},{type:{id:'minecraft:protection'},level:4}]:[];this.nameTag='My armor';this.lore=['keep this'];}
 getComponent(id){return id==='minecraft:durability'?this.durability:id==='minecraft:enchantable'?{getEnchantments:()=>this.enchants}:undefined;}
 getDynamicProperty(key){return this.props.get(key);}setDynamicProperty(key,value){this.props.set(key,value);}
 clone(){const copy=new Item(this.typeId);copy.props=new Map(this.props);copy.durability={...this.durability};copy.enchants=this.enchants.map(e=>({type:{...e.type},level:e.level}));copy.nameTag=this.nameTag;copy.lore=[...this.lore];return copy;}
}
const worn=new Map(),eq={getEquipment:slot=>worn.get(slot)?.clone(),setEquipment:(slot,item)=>worn.set(slot,item.clone())};const p={id:'p',getComponent:()=>eq};
worn.set('Chest',new Item());assert.equal(api.boostMending(p),0);worn.get('Chest').durability.damage=90;
assert.equal(api.boostMending(p),30);assert.equal(worn.get('Chest').durability.damage,60);assert.equal(api.boostMending(p),0);assert.equal(worn.get('Chest').durability.damage,60);
assert.equal(worn.get('Chest').nameTag,'My armor');assert.deepEqual(worn.get('Chest').lore,['keep this']);assert.equal(worn.get('Chest').props.get('rpg:rarity'),6);assert.equal(worn.get('Chest').props.get('rpg:armor_upgrade'),10);assert.equal(worn.get('Chest').enchants[1].level,4);
worn.get('Chest').durability.damage=50;assert.equal(api.boostMending(p),30);assert.equal(worn.get('Chest').durability.damage,20);
// Identical gear swapped into the same slot must not count as native repair.
worn.set('Chest',new Item(undefined,5));assert.equal(api.boostMending(p),0);assert.equal(worn.get('Chest').durability.damage,5);worn.get('Chest').durability.damage=1;assert.equal(api.boostMending(p),1);assert.equal(worn.get('Chest').durability.damage,0);
const removed=worn.get('Chest');worn.delete('Chest');api.boostMending(p);removed.durability.damage=0;worn.set('Chest',removed);assert.equal(api.boostMending(p),0);
// Vanilla held tools, armor and offhand: only repaired Mending items gain a bonus.
worn.set('Mainhand',new Item('minecraft:diamond_pickaxe',50));worn.set('Offhand',new Item('minecraft:shield',50));worn.set('Head',new Item('rpg:abyssal_helmet',50,false));api.boostMending(p);
for(const slot of ['Mainhand','Offhand','Head'])worn.get(slot).durability.damage=40;
assert.equal(api.boostMending(p),20);assert.equal(worn.get('Mainhand').durability.damage,30);assert.equal(worn.get('Offhand').durability.damage,30);assert.equal(worn.get('Head').durability.damage,40);
worn.get('Mainhand').durability.damage=35;assert.equal(api.boostMending(p),0);assert.equal(worn.get('Mainhand').durability.damage,35,'Damage must not become repair');
api.registerMendingBoost();api.registerMendingBoost();hooks.playerLeave({playerId:'p'});worn.get('Mainhand').durability.damage=20;interval();assert.equal(worn.get('Mainhand').durability.damage,20);
hooks.playerSpawn({player:p});worn.get('Mainhand').durability.damage=10;interval();assert.equal(worn.get('Mainhand').durability.damage,10);
const expectedMax={adventurer:[880,1280,1200,880],warden:[1200,1800,1680,1200],astral:[1040,1600,1500,1040],abyssal:[2200,3200,3000,2600]};
for(const [set,values] of Object.entries(expectedMax)){
 const {ARMOR_PARTS,ARMOR_SETS}=equipment.namespace;
 assert.deepEqual(Array.from(ARMOR_SETS[set].durability),values);
 ARMOR_PARTS.forEach((part,i)=>{
  const file=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0638/items/'+set+'_'+part+'.json','utf8'));
  assert.equal(file['minecraft:item'].components['minecraft:durability'].max_durability,values[i]);
 });
}
console.log('Mending: native repair quadrupled for RPG armor and doubled for other gear, cap, repeated repairs, identical swaps/unequip resets, vanilla tools/offhand, missing enchant, damage, lifecycle reset, rarity/enchant/name/lore preservation passed');
