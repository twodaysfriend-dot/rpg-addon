import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0638';
const base=root+'/RPG_BP_v0638/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(n==='projectileMotion'?(_p,speed,steps=1)=>({speed,steps,step:speed/steps}):()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}


const defs=(await load('scripts/data/skills.js')).SKILLS;
async function setup(job){
 const callbacks=new Map(),particles=[],effects=[],regen=[],removed=[],stops=[],direct=[],notices=[],hooks=new Map();
 let next=0;
 const system={
  currentTick:0,
  runInterval(fn,period){callbacks.set(++next,{fn,period,due:system.currentTick+period});return next;},
  clearRun:id=>callbacks.delete(id),
 };
 const dimension={id:'minecraft:overworld'},otherDimension={id:'minecraft:nether'};
 const players=[];
 function entity(id,hp,max,x,dim=dimension){
  const messages=[],status=new Map(),health={currentValue:hp,effectiveMax:max};
  const t={id,typeId:'minecraft:player',isValid:true,location:{x,y:0,z:0},dimension:dim,messages,status,health,
   getComponent:id=>id==='minecraft:health'?health:undefined,
   getHeadLocation:()=>({...t.location,y:1.7}),
   sendMessage:text=>messages.push(text),
   getEffect(id){
    const e=status.get(id);
    if(!e||e.end<=system.currentTick)return undefined;
    return {amplifier:e.amplifier,duration:e.end-system.currentTick};
   },
   removeEffect(id){removed.push([t.id,id]);status.delete(id);},
  };
  players.push(t);return t;
 }
 const p=entity('caster',20,100,0);
 p.job=job;
 const a=entity('first',22,28,20),b=entity('second',31,100,25);
 const far=entity('far',10,100,50),cross=entity('cross',12,100,1,otherDimension);
 const full=entity('full',8,8,2),outsider=entity('guild-only',2,100,3),dead=entity('dead',0,100,3);
 const party=[p,a,b,far,cross,full,dead];
 const world={getAllPlayers:()=>players,afterEvents:new Proxy({},{get:(_,id)=>({subscribe:fn=>hooks.set(id,fn)})})};
 const holy=await load('scripts/skills/holy.js',{
  system,world,CONFIG:{pvp:false},partyMembership:()=>({inParty:true,members:party}),areAllies:()=>true,
  isHealingAlly:()=>true,healthAlive:e=>e?.isValid&&e.health.currentValue>0,rpgMaxHealth:(e,hp)=>e.rpgMax??hp.effectiveMax,
  getJobId:e=>e.job,hasBorrowedSkill:()=>job==='chameleon',dist3:(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z),
  headPos:e=>e.getHeadLocation(),notify:(_p,msg)=>notices.push(msg),
  applyStatus(entity,id,ticks,options){effects.push({entity,id,ticks,...options});entity.status.set(id,{end:system.currentTick+ticks,...options});},
  applyHolyRegeneration:(caster,target,ticks,amp,source)=>regen.push({caster,target,ticks,amp,source}),
  stopHolyRegeneration:(target,source)=>stops.push([target.id,source]),
  healHolyAlly(caster,target,amount){direct.push({caster,target,amount});target.health.currentValue=Math.min(target.health.effectiveMax,target.health.currentValue+amount);},
  particle:(dim,id,at)=>particles.push({dim,id,at}),
 });
 function step(count){
  for(let i=0;i<count;i++){
   system.currentTick++;
   for(const [id,timer] of [...callbacks])if(callbacks.has(id)&&timer.due<=system.currentTick){
    timer.due+=timer.period;timer.fn();
   }
  }
 }
 return {p,a,b,far,cross,full,outsider,dead,party,holy,step,callbacks,particles,effects,regen,removed,stops,direct,notices,hooks};
}
for(const job of ['cleric','angel','michael','chameleon']){
 const h=await setup(job);
 const def=defs.holy_orb;
 h.holy.RUNNERS.holy_orb(h.p,{id:job},def);
 assert.equal(h.holy.RUNNERS.holy_orb(h.p,{id:job},def),false);
 h.step(100);
 assert.equal(h.particles.length,50);
 assert.ok(h.particles.every(v=>v.id==='rpg:holy_blessing_orb'&&v.at.x===20&&Math.abs(v.at.y-2.6)<1e-8));
 assert.equal(h.regen.length,10);
 assert.ok(h.regen.every(r=>r.target===h.a&&r.ticks===40&&r.amp===(def.regenByJob[job]??2)-1));
 assert.equal(h.effects.filter(e=>e.id==='absorption').length,1);
 assert.equal(h.effects.filter(e=>e.id==='speed').length,10);
 assert.equal(h.effects.filter(e=>e.id==='hunger').length,10);
 assert.ok(h.effects.every(e=>e.showParticles===false));
 h.a.location.x=21;h.step(2);
 assert.equal(h.particles.at(-1).at.x,21);
}
{
 const h=await setup('cleric');
 h.a.status.set('absorption',{amplifier:3,end:1200});
 h.holy.RUNNERS.holy_orb(h.p,{id:'cleric'},defs.holy_orb);
 h.step(10);
 h.a.rpgMax=27;h.a.health.currentValue=27;
 h.a.status.set('speed',{amplifier:7,end:300});
 h.step(2);
 assert.equal(h.regen.at(-1).target,h.b);
 assert.equal(h.particles.at(-1).at.x,25);
 assert.deepEqual(h.stops,[['first','orb:caster']]);
 assert.equal(h.a.getEffect('speed').amplifier,7);
 assert.equal(h.a.getEffect('absorption').amplifier,3);
 h.b.health.currentValue=100;h.a.health.currentValue=10;
 h.step(10);
 assert.equal(h.regen.at(-1).target,h.a);
 assert.equal(h.effects.filter(e=>e.id==='absorption'&&e.entity===h.a&&e.amplifier===7).length,1);
 h.a.health.currentValue=27;
 h.step(10);
 assert.equal(h.callbacks.size,0);
 assert.equal(h.p.getEffect('hunger'),undefined);
 assert.match(h.notices.at(-1),/사라졌습니다/);
 assert.equal(h.holy.RUNNERS.holy_orb(h.p,{id:'cleric'},defs.holy_orb),false);
}
{
 const h=await setup('angel');
 h.holy.RUNNERS.holy_orb(h.p,{id:'angel'},defs.holy_orb);
 h.step(2);
 h.a.location.x=31;
 h.step(10);
 assert.equal(h.regen.at(-1).target,h.b);
 h.party.splice(h.party.indexOf(h.b),1);
 h.step(10);
 assert.equal(h.callbacks.size,0);
}
{
 const h=await setup('michael');
 h.holy.registerHoly();
 const job={id:'michael'};
 h.holy.RUNNERS.holy_sword(h.p,job,defs.holy_sword);
 h.holy.RUNNERS.holy_shield(h.p,job,defs.holy_shield);
 for(const ally of [h.p,h.a,h.b,h.far,h.cross,h.full]){
  assert.equal(ally.getEffect('strength').amplifier,2);
  assert.equal(ally.getEffect('absorption').amplifier,4);
  assert.equal(ally.getEffect('resistance').amplifier,2);
  assert.deepEqual(ally.messages.map(text=>text.replace(/§./g,'')),['불굴의 검 효과를 받았습니다.','불굴의 방패 효과를 받았습니다.']);
 }
 for(const excluded of [h.dead,h.outsider])assert.deepEqual(excluded.messages,[]);
 h.holy.RUNNERS.holy_heal(h.p,job,defs.holy_heal);
 assert.equal(h.direct.at(-1).target,h.far);
 assert.equal(h.direct.at(-1).amount,16);
 h.holy.RUNNERS.holy_heal(h.p,job,defs.holy_heal,h.a);
 assert.equal(h.direct.at(-1).target,h.a);
 h.a.status.delete('strength');
 h.step(2);
 assert.match(h.a.messages.at(-1),/불굴의 검 효과가 사라졌습니다/);
 h.step(98);
 h.holy.RUNNERS.holy_sword(h.p,job,defs.holy_sword);
 h.step(5900);
 assert.match(h.b.messages.at(-1),/불굴의 방패 효과가 사라졌습니다/);
 assert.ok(!h.b.messages.some(text=>/불굴의 검 효과가 사라졌습니다/.test(text)));
 h.step(100);
 assert.match(h.b.messages.at(-1),/불굴의 검 효과가 사라졌습니다/);
 h.step(100);
 assert.equal(h.b.messages.filter(text=>/사라졌습니다/.test(text)).length,2);
}
const particle=JSON.parse(fs.readFileSync(root+'/RPG_RP_v0638/particles/rpg_holy_blessing_orb.json','utf8')).particle_effect;
assert.equal(particle.description.identifier,'rpg:holy_blessing_orb');assert.equal(particle.components['minecraft:emitter_rate_instant'].num_particles,1);assert.equal(particle.components['minecraft:particle_lifetime_expression'].max_lifetime,.1);assert.equal(particle.components['minecraft:particle_initial_speed'],0);assert.ok(fs.existsSync(root+'/RPG_RP_v0638/'+particle.description.basic_render_parameters.texture+'.png'));
console.log('Holy party support: distant party-wide buffs and receipt/expiry chat, lowest-HP heal, orb cadence, full-health/range/party handoff, non-stacking absorption and effect ownership passed');
