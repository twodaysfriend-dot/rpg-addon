import fs from 'node:fs';
import assert from 'node:assert/strict';
import {DUNGEON_TIERS} from '../RPG_BP_v0638/scripts/data/dungeons.js';
import {DUNGEON_HEALTH_PRESSURE,MONSTER_LEVELS,dungeonMonsterLevel,monsterCombatMultipliers,monsterDefenseFor} from '../RPG_BP_v0638/scripts/data/monsterLevels.js';
import {MONSTER_BASE_STATS,MONSTER_STAT_MULTIPLIERS,DUNGEON_BALANCE} from '../RPG_BP_v0638/scripts/data/dungeonBalance.js';
import {LEVELED_MONSTERS} from '../RPG_BP_v0638/scripts/data/leveledMonsters.js';
import {DUNGEON_NATIVE_XP} from '../RPG_BP_v0638/scripts/data/dungeonNativeXp.js';
const root=process.argv[2]??'.';
const close=(a,b,e=1e-6)=>assert.ok(Math.abs(a-b)<e,`${a} != ${b}`);
const expectedBossLevels=[20,40,55,70,90,115,220,260,145,180];
const sourceBossTiers=[1,2,3,4,5,6,9,10,7,8];
const scaleFor=id=>MONSTER_STAT_MULTIPLIERS[id]??{health:1,attack:1};
assert.deepEqual(MONSTER_STAT_MULTIPLIERS,{
 'rpg:deathworm':{health:4,attack:2},
 'rpg:elite_deathworm':{health:4,attack:2},
});
let cases=0;
for(const id of LEVELED_MONSTERS){
 const e=JSON.parse(fs.readFileSync(`${root}/RPG_BP_v0638/entities/${id.split(':')[1]}.json`))['minecraft:entity'];
 const base=e.components;
 const profile=MONSTER_BASE_STATS[id.split(':')[1]];
 const buff=scaleFor(id);
 assert.equal(profile.health*buff.health,base['minecraft:health'].max);
 assert.equal(profile.attack*buff.attack,base['minecraft:attack'].damage);
 for(const level of MONSTER_LEVELS){
  const g=e.component_groups['rpg:level_'+level];
  close(g['minecraft:health'].max,Number((base['minecraft:health'].max*((1+(level-1)*.035)*.9)).toFixed(2)));
  close(g['minecraft:damage_sensor'].triggers[0].damage_multiplier,1);
  assert.equal(monsterDefenseFor(level),1);
 }
 for(const t of DUNGEON_TIERS)for(const kind of ['normal','elite','boss'])for(let index=0;index<(kind==='normal'?3:1);index++){
  const level=dungeonMonsterLevel(t.tier,kind,index),ctx={tier:t.tier,kind,index};
  const pressureTier=kind==='boss'?sourceBossTiers[t.tier-1]:t.tier;
  const oldReduction=1-1/((1+(level-1)*.004)*(pressureTier>=2?1+(pressureTier-2)*.04:1));
  const g=e.component_groups[`rpg:dungeon_scaled_${t.tier}_${kind}_${index}`];
  close(1-g['minecraft:damage_sensor'].triggers[0].damage_multiplier,oldReduction*.64);
  const m=monsterCombatMultipliers(level,ctx,id);
  close(g['minecraft:health'].max,Number((base['minecraft:health'].max*m.health).toFixed(2)),.011);
  close(g['minecraft:attack'].damage,Number((base['minecraft:attack'].damage*m.attack).toFixed(2)),.011);
  cases++;
 }
}
const expectedBossHealth=[1000,5000,7500,10000,12500,15000,33000,52000,66000,72000];
const expectedBossAttack=[14,20,28,40,55,72,145,225,138,172.5];
let previous={normal:0,elite:0};
for(const t of DUNGEON_TIERS){
 const file=id=>JSON.parse(fs.readFileSync(`${root}/RPG_BP_v0638/entities/${id}.json`))['minecraft:entity'];
 const boss=file(t.boss).component_groups[`rpg:dungeon_scaled_${t.tier}_boss_0`];
 assert.equal(dungeonMonsterLevel(t.tier,'boss'),expectedBossLevels[t.tier-1]);
 assert.equal(boss['minecraft:health'].max,expectedBossHealth[t.tier-1]);
 assert.equal(boss['minecraft:attack'].damage,expectedBossAttack[t.tier-1]);
 // Scripted boss moves use the same multiplier as native melee damage.
 close(monsterCombatMultipliers(dungeonMonsterLevel(t.tier,'boss'),{tier:t.tier,kind:'boss'}).attack*file(t.boss).components['minecraft:attack'].damage,expectedBossAttack[t.tier-1]);
 for(const kind of ['normal','elite']){
  let max=0;
  for(const id of new Set(t[kind])){
   const e=file(id);
   const buff=scaleFor('rpg:'+id);
   const persist='rpg:dungeon_persistent';
   assert.ok(e.events[`rpg:dungeon_tier_${t.tier}`].add.component_groups.includes(persist),id);
   assert.ok('minecraft:persistent' in e.component_groups[persist],id);
   assert.equal(e.component_groups[persist]['minecraft:experience_reward'].on_death,0,id);
   assert.equal(DUNGEON_NATIVE_XP['rpg:'+id],e.components['minecraft:experience_reward'].on_death,id);
   for(let i=0;i<(kind==='normal'?3:1);i++){
    const g=e.component_groups[`rpg:dungeon_scaled_${t.tier}_${kind}_${i}`];
    const unbuffedHealth=g['minecraft:health'].max/buff.health;
    assert.ok(unbuffedHealth<=DUNGEON_BALANCE[t.tier-1][kind+'Health']+.01);
    assert.ok(g['minecraft:attack'].damage/buff.attack<=DUNGEON_BALANCE[t.tier-1][kind+'Attack']+.01);
    // Check the shared cap before the worm-only buffs.
    const level=dungeonMonsterLevel(t.tier,kind,i),kindHp=kind==='elite'&&t.tier>=2?1.35:1;
    const oldHp=MONSTER_BASE_STATS[id].health*(1+(level-1)*.035)*t.hpMultiplier*kindHp*DUNGEON_HEALTH_PRESSURE[t.tier-1];
    assert.ok(unbuffedHealth<=oldHp+.011);
    max=Math.max(max,unbuffedHealth);
   }
  }
  assert.ok(max>previous[kind],`${kind} peak health progression at tier ${t.tier}`);previous[kind]=max;
 }
}
close(monsterDefenseFor(260,{tier:8,kind:'boss'}),.5981377626957195);
console.log(`${cases} dungeon groups: tier 9–10 Hydra HP ×2 and attack ×1.5; unchanged boss levels, defense and normal/elite ceilings`);
