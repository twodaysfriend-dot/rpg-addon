# RPG v0.6.101 · 전인자 해방과 슈퍼 샌드백 Mk.2

- 올포원은 `/rpg:skillbook` → **전인자 해방 · 기준 스킬**에서 첫 번째로 발사할 기술을 저장할 수 있습니다. 스킬을 선택하고 적을 바라본 채 직업 무기를 우클릭하면 발동합니다.
- **전인자 해방**은 고정 MP 2,000, 재사용 대기시간 5분입니다. 보유한 공격 스킬의 피해를 기준 스킬부터 유도탄으로 발사합니다. 원거리 연사와 기본 공격 강화, 돌진 피해도 반영합니다. 개별 스킬의 마나, 사용 횟수, 쿨타임은 궁극기 발동으로 소비되지 않습니다. 투사체는 벽에 막힙니다.
- 전직관, 훈련 샌드백, 슈퍼 샌드백, Mk.2는 배치 위치에 고정됩니다. 넉백과 블랙홀에 밀리거나 끌려가지 않습니다.
- **슈퍼 샌드백 Mk.2**는 PvP와 같은 8% 피해 배율을 적용합니다. 무한 체력과 플레이어별 누적 피해 표시를 사용하며, 웅크린 채 우클릭하면 자신의 누적 피해를 초기화합니다. `/rpg:egg` → **기타**에서 소환 알을 받을 수 있습니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.101로 활성화하세요. 자동 검사에서 궁극기 설정·발동·추적과 마나·쿨타임, Mk.2 피해 집계와 고정을 확인했습니다. 실제 Bedrock 월드에서는 확인하지 못했습니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
python3 tools/build_protected_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v06101
```
