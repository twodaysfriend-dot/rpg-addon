scriptevent rpg:skillbook
