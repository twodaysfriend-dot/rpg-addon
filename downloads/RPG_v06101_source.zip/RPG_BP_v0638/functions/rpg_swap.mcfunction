scriptevent rpg:swap
