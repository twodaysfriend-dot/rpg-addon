Vanilla villager definitions adapted from Mojang/bedrock-samples.
Source tag: v1.21.100.6
Commit: c32ab2ac8ebdd8b418c03990b30597d6b56bc8c9
https://github.com/Mojang/bedrock-samples/tree/c32ab2ac8ebdd8b418c03990b30597d6b56bc8c9/behavior_pack/entities
Files: villager.json and villager_v2.json. JSONC comments/trailing commas removed. Added native damage-sensor filters gated by rpg_town_villager_protected; town lightning cannot convert to witches. v0.6.38 also raises max_cured_discount to five times cured_discount for all 13 economy trade tables, retaining the current per-cure amounts. This restores repeated-cure accumulation up to five cures using the same native fields as Mojang bedrock-samples v1.20.10.1 (https://github.com/Mojang/bedrock-samples/blob/v1.20.10.1/behavior_pack/entities/villager_v2.json). All remaining components, events and zombie conversion retained. See accompanying license.
