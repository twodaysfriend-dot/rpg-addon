import {world,system,EntityInitializationCause} from '@minecraft/server';
import {spawnRegion,insideSpawn} from './spawnEffects.js';
export const ZOMBIE_NATURAL='rpg_town_zombie_natural',ZOMBIE_KEPT='rpg_town_zombie_kept';
export const TOWN_ZOMBIE_TYPES=Object.freeze(['minecraft:zombie','minecraft:zombie_villager','minecraft:zombie_villager_v2']);
export const isTownZombieType=id=>TOWN_ZOMBIE_TYPES.includes(id);
const zombieKind=id=>id==='minecraft:zombie'?id:'minecraft:zombie_villager';
const eggs=[];let registered=false;
const inside=e=>insideSpawn(e,spawnRegion());
function noteEgg(ev){try{
 const egg=ev.itemStack?.typeId;if(!egg?.endsWith('_spawn_egg')||!isTownZombieType(egg.slice(0,-10)))return;
 const type=egg.slice(0,-10);
 const p=ev.source??ev.player;if(!p)return;
 const at=ev.block?.location??p.location;
 if(eggs.some(r=>r.player===p.id&&r.type===type&&r.tick===system.currentTick))return;
 eggs.push({player:p.id,type,at:{...at},dim:p.dimension.id,tick:system.currentTick});while(eggs.length>32)eggs.shift();
}catch{}}
function eggMatches(e){
 const index=eggs.findIndex(r=>zombieKind(r.type)===zombieKind(e.typeId)&&r.dim===e.dimension.id&&system.currentTick-r.tick>=0&&system.currentTick-r.tick<=8&&Math.hypot(e.location.x-r.at.x,e.location.y-r.at.y,e.location.z-r.at.z)<=10);
 if(index<0)return false;eggs.splice(index,1);return true;
}
export function keepTownZombie(e){
 if(!isTownZombieType(e?.typeId))return false;
 if(e.hasTag?.(ZOMBIE_KEPT))return true;
 if(!inside(e))return false;
 if((e.hasTag?.('rpg_town_manual_spawn')&&!e.hasTag?.('rpg_hunt_zoned'))||eggMatches(e)){e.removeTag?.(ZOMBIE_NATURAL);e.addTag(ZOMBIE_KEPT);return true;}
 if(e.hasTag?.(ZOMBIE_NATURAL))return false;
 // Unmarked existing/load/transported zombies are retained, never guessed natural.
 e.addTag(ZOMBIE_KEPT);e.removeTag?.('rpg_night_spawn');return true;
}
export function noteTownZombieSpawn(e,cause){
 if(!isTownZombieType(e?.typeId)||!inside(e))return;
 if(cause===(EntityInitializationCause?.Spawned??'Spawned')){
  e.addTag(ZOMBIE_NATURAL);
  if(eggMatches(e)){e.removeTag?.(ZOMBIE_NATURAL);e.addTag(ZOMBIE_KEPT);}
 }else if(!e.hasTag?.(ZOMBIE_NATURAL)){e.addTag(ZOMBIE_KEPT);}
}
export function registerTownZombies(){
 if(registered)return;registered=true;
 world.beforeEvents?.itemUse?.subscribe(noteEgg);world.beforeEvents?.playerInteractWithBlock?.subscribe(noteEgg);world.afterEvents.itemUse.subscribe(noteEgg);
 world.afterEvents.entitySpawn.subscribe(ev=>{try{noteTownZombieSpawn(ev.entity,ev.cause);if(isTownZombieType(ev.entity?.typeId)&&ev.entity.hasTag?.(ZOMBIE_NATURAL))system.runTimeout(()=>{try{if(!keepTownZombie(ev.entity))ev.entity.remove();}catch{}},4);}catch(error){console.warn('[RPG town zombie] '+error);}});
}
