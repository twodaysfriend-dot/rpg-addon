import {world,system} from '@minecraft/server';
import {landOwner,landSelection} from './realEstate.js';
import {sharesLandGuild} from './social.js';

const CHESTS=new Set(['minecraft:chest','minecraft:trapped_chest']);
const COPPER_CHEST=/^minecraft:(?:waxed_)?(?:(?:exposed|weathered|oxidized)_)?copper_chest$/;
const isChest=type=>CHESTS.has(type)||COPPER_CHEST.test(type??'');
const DOUBLE_CAPACITY=54;
const MAX_PAIR_SCAN=64;
const cardinal=['down','up','north','south','west','east'];
let registered=false;

function privateChest(block,player){
 const owner=landOwner(landSelection(block,null));
 return !!owner&&owner.id!==player.id&&!sharesLandGuild(player,owner);
}
function facing(block){
 const states=block.permutation?.getAllStates?.()??{};
 return states['minecraft:cardinal_direction']??cardinal[states.facing_direction];
}
function capacity(block){return block.getComponent?.('minecraft:inventory')?.container?.size;}

function pairedChests(block,axis,direction){
 const adjacent=offset=>{
  const at={...block.location,[axis]:block.location[axis]+offset};
  const neighbor=block.dimension.getBlock(at);
  if(!neighbor)throw Error('큰 상자 주변 청크를 읽을 수 없습니다.');
  if(neighbor.typeId!==block.typeId||direction&&facing(neighbor)!==direction)return undefined;
  return capacity(neighbor)===DOUBLE_CAPACITY?neighbor:undefined;
 };
 const left=adjacent(-1),right=adjacent(1);
 if(!left||!right)return [left??right].filter(Boolean);
 // In a row of double chests each endpoint pairs with its only neighbor.
 // Count from an endpoint to distinguish adjacent doubles with the same facing.
 for(let distance=2;distance<=MAX_PAIR_SCAN;distance++){
  if(!adjacent(-distance))return [distance%2===0?left:right];
 }
 return [left,right];
}

export function landChestProtected(block,player){
 if(!isChest(block?.typeId)||!player)return false;
 try{
  if(privateChest(block,player))return true;
  if(capacity(block)!==DOUBLE_CAPACITY)return false;
  const direction=facing(block);
  const axes=direction==='north'||direction==='south'?['x']:
   direction==='east'||direction==='west'?['z']:['x','z'];
  return axes.some(axis=>pairedChests(block,axis,direction).some(half=>privateChest(half,player)));
 }catch{
  // A failed land lookup must not expose an owner's inventory.
  return true;
 }
}

export function registerLandChestProtection(){
 if(registered)return;
 registered=true;
 world.beforeEvents.playerInteractWithBlock.subscribe(event=>{
  if(event.cancel||!landChestProtected(event.block,event.player))return;
  event.cancel=true;
  if(event.isFirstEvent!==false){
   const player=event.player;
   system.run(()=>{if(player.isValid)player.sendMessage('§c[부동산] 소유자와 같은 길드원만 이 상자를 열 수 있습니다.');});
  }
 });
}
