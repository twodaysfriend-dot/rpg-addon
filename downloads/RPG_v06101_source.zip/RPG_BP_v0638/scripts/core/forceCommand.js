import * as mc from '@minecraft/server';
import { runRpgAction } from './rpgActions.js';

let subscribed = false;
export function registerForceCommand() {
  if (subscribed) return;
  subscribed = true;
  mc.system.beforeEvents.startup.subscribe(({customCommandRegistry}) => {
    const permissionLevel = mc.CommandPermissionLevel?.GameDirectors ?? mc.CustomCommandPermissionLevel?.GameDirectors;
    const type = mc.CustomCommandParamType?.String;
    const status = mc.CustomCommandStatus;
    if (!customCommandRegistry || permissionLevel === undefined || type === undefined || !status) return;

    try {
      customCommandRegistry.registerCommand({
        name: 'rpg:force',
        description: '관리자: 강제 전직 · 직업명 또는 ID',
        permissionLevel,
        cheatsRequired: false,
        mandatoryParameters: [{name:'job',type}],
        optionalParameters: [{name:'jobPart2',type},{name:'jobPart3',type}],
      }, (origin, ...args) => {
        const player = origin.sourceEntity ?? origin.initiator;
        if (player?.typeId !== 'minecraft:player')
          return {status:status.Failure, message:'플레이어만 사용할 수 있습니다.'};
        const parts = Array.isArray(args[0]) ? args[0] : args;
        const job = parts.filter(part => part != null).join(' ');
        mc.system.run(async () => {
          try { await runRpgAction('force', player, job); }
          catch (error) {
            console.warn('[RPG force] ' + String(error));
            try { player.sendMessage('§c[RPG] 강제 전직을 완료하지 못했습니다.'); } catch {}
          }
        });
        return {status:status.Success};
      });
    } catch (error) {
      console.warn('[RPG] /rpg:force 등록 실패: ' + String(error));
    }
  });
}
