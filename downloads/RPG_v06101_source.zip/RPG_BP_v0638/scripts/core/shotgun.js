// Pick one randomized ray in each azimuth sector of the aiming cone.
export function shotgunDirections(aim, flat, shots, spread) {
  const right={x:flat.z,y:0,z:-flat.x};
  const up={x:aim.y*right.z,y:aim.z*right.x-aim.x*right.z,z:-aim.y*right.x};
  const half=spread*Math.PI/360,coneCos=Math.cos(half);
  return Array.from({length:shots},(_,i)=>{
    const yaw=((i+Math.random())*2/shots-1)*half;
    const pitchLimit=Math.min(.33,Math.acos(Math.min(1,coneCos/Math.cos(yaw))));
    const pitch=(Math.random()*2-1)*pitchLimit;
    const forward=Math.cos(yaw)*Math.cos(pitch),side=Math.sin(yaw)*Math.cos(pitch),height=Math.sin(pitch);
    return {x:aim.x*forward+right.x*side+up.x*height,y:aim.y*forward+up.y*height,z:aim.z*forward+right.z*side+up.z*height};
  });
}
