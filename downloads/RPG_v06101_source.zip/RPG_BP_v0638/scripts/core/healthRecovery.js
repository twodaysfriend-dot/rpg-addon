import {rpgMaxHealth} from './healthLimits.js';
export function restoreFullHealth(p){
 const hp=p.getComponent('minecraft:health');
 if(hp&&hp.currentValue>0)hp.setCurrentValue(rpgMaxHealth(p,hp));
}
