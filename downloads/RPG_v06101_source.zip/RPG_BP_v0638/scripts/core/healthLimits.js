const limits=new Map();

export function setHealthLimit(id,max){
  if(max===undefined)limits.delete(id);
  else limits.set(id,max);
}

export function rpgMaxHealth(entity,health){
  const nativeMax=health?.effectiveMax??health?.defaultValue??20;
  const limit=limits.get(entity?.id);
  return limit===undefined?nativeMax:Math.min(nativeMax,limit);
}

export function clampHealthLimit(entity){
  const limit=limits.get(entity?.id);
  if(limit===undefined)return;
  const health=entity.getComponent('minecraft:health');
  if(health&&health.currentValue>limit)health.setCurrentValue(limit);
}

export function isHealthLimitAdjustment(entity,oldValue,newValue){
  const limit=limits.get(entity?.id);
  return limit!==undefined && oldValue>limit && newValue===limit;
}
