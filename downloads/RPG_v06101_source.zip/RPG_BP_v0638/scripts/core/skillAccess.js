import {isChameleonJob} from '../data/jobs.js';
import { getJobId,getSkills } from './playerData.js';
export function hasBorrowedSkill(p,id){return p?.typeId==='minecraft:player'&&isChameleonJob(getJobId(p))&&getSkills(p).includes(id);}
export function canUseSkill(p,id,jobs){return p?.typeId==='minecraft:player'&&(jobs.includes(getJobId(p))||hasBorrowedSkill(p,id));}
export function isChameleonWeapon(id){return ['rpg:chameleon_flame_blade','rpg:chameleon_moon_scythe'].includes(id);}
