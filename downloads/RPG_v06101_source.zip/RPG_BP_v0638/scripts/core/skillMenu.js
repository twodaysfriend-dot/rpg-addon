import {jobStatText} from '../data/jobStats.js';
import { system } from "@minecraft/server";
import * as UI from "@minecraft/server-ui";
import { SKILLS } from "../data/skills.js";
import { getDisabled, setDisabled, setIndex } from "./playerData.js";
import { getContext } from "./context.js";
import { refreshHud } from "./hud.js";
import { sound } from "./util.js";
import {
  canBoostSkillMana, manaDamageMultiplier, MAX_SKILL_MANA_MULTIPLIER,
  setSkillManaSetting, skillManaCost, skillManaMultiplier, skillManaSetting,
} from "./skillMana.js";

// 스킬 설정창: 지금 든 책/지팡이(직업 무기)의 스킬을 눌러서 켜고 끕니다.
// 꺼 둔 스킬은 웅크리기 전환 목록과 발동 대상에서 빠지고, 월드를 다시 열어도 유지됩니다.

const open = new Set(); // 설정창이 이미 열려 있는 플레이어

// 채팅창 등이 열려 있으면 창이 바로 닫히므로(UserBusy) 잠시 기다렸다가 다시 띄웁니다.
export async function showForm(form, player) {
  const busy = UI.FormCancelationReason?.UserBusy ?? "UserBusy";
  for (let i = 0; i < 30; i++) {
    const res = await form.show(player);
    if (!res.canceled || res.cancelationReason !== busy) return res;
    await new Promise((resolve) => system.runTimeout(resolve, 10));
  }
  return undefined;
}

async function openManaSettings(player, expectedJob) {
  while (true) {
    const ctx = getContext(player);
    if (ctx?.job.id !== expectedJob) return;
    const skills = ctx.all.map(id => SKILLS[id]).filter(canBoostSkillMana);
    if (!skills.length) return;
    const defaultMana = skillManaSetting(player, undefined, expectedJob);
    const form = new UI.ActionFormData().title("마나 배율 설정")
      .body("공통 배율은 해당 직업의 피해 스킬에 적용됩니다. 개별 설정이 있으면 그 값을 먼저 사용합니다.")
      .button("직업 공통 · ×" + defaultMana);
    for (const def of skills) {
      const override = skillManaSetting(player, def.id, expectedJob);
      const factor = override || defaultMana;
      form.button(`${def.name} · ×${factor}${override ? "" : " (공통)"}\nMP ${skillManaCost(player, def, factor)}`);
    }
    form.button("뒤로");
    const answer = await showForm(form, player);
    if (answer?.canceled || !Number.isInteger(answer?.selection) || answer.selection < 0 || answer.selection > skills.length) return;

    const def = skills[answer.selection - 1];
    const factors = Array.from({ length: MAX_SKILL_MANA_MULTIPLIER }, (_, i) => i + 1);
    if (def) factors.unshift(0);
    const choice = new UI.ActionFormData().title(def?.name ?? "직업 공통 배율")
      .body("마나 2배부터 1단계마다 피해가 10%p 증가합니다." +
        (def?.id === 'holy_heal' ? "\n힐의 배율은 적에게 피해를 줄 때 적용됩니다." : ""));
    for (const factor of factors) {
      if (factor === 0) choice.button("직업 공통 배율 사용 · ×" + defaultMana);
      else choice.button(`마나 ×${factor} · 피해 ×${manaDamageMultiplier(factor).toFixed(1)}` +
        (def ? `\nMP ${skillManaCost(player, def, factor)}` : ""));
    }
    choice.button("뒤로");
    const pick = await showForm(choice, player);
    const factor = !pick?.canceled ? factors[pick?.selection] : undefined;
    if (factor === undefined) continue;
    const current = getContext(player);
    if (current?.job.id !== expectedJob || def && !current.all.includes(def.id)) return;
    if (setSkillManaSetting(player, def?.id, factor, expectedJob))
      sound(player.dimension, "random.click", player.location, { volume: 0.6, pitch: 1.1 });
  }
}

export async function openSkillMenu(player) {
  if (open.has(player.id)) return;
  const first = getContext(player);
  if (!first || first.all.length === 0) {
    player.sendMessage("§7책이나 지팡이 같은 직업 무기를 든 상태에서 설정할 수 있습니다.");
    return;
  }
  const ids = first.all;
  const showMana = ids.some(id => canBoostSkillMana(SKILLS[id]));

  open.add(player.id);
  try {
    while (true) {
      const off = getDisabled(player);
      const form = new UI.ActionFormData()
        .title("스킬 설정")
        .body(jobStatText(first.job,first.line)+"\n\n누르면 켜고 끕니다.\n§a켜짐§r 스킬만 웅크리기로 전환하고 쓸 수 있습니다.");
      for (const id of ids) {
        const def = SKILLS[id];
        const factor = skillManaMultiplier(player, def, first.job.id);
        const label = `${off.includes(id) ? "§c✘ 꺼짐" : "§a✔ 켜짐"}§r  ${def?.name ?? id}${factor > 1 ? " §b마나 ×" + factor : ""}`;
        if (id === "chameleon_crimson_dash") form.button(label, "textures/ui/rpg_chameleon_crimson_dash");
        else if (id === "chameleon_ground_slam") form.button(label, "textures/ui/rpg_chameleon_ground_slam");
        else form.button(label);
      }
      if (showMana) form.button("마나 배율 설정");
      form.button("닫기");

      const res = await showForm(form, player);
      if (res?.canceled || !Number.isInteger(res?.selection) || res.selection < 0) break;
      if (showMana && res.selection === ids.length) {
        await openManaSettings(player, first.job.id);
        continue;
      }
      if (res.selection >= ids.length) break;

      const id = ids[res.selection];
      const now = getDisabled(player);
      setDisabled(player, now.includes(id) ? now.filter((x) => x !== id) : [...now, id]);
      sound(player.dimension, "random.click", player.location, { volume: 0.6, pitch: 1.1 });
    }
  } catch {
    // 플레이어가 나갔거나 창을 띄울 수 없는 경우
  } finally {
    open.delete(player.id);
    try {
      setIndex(player, 0);
      refreshHud(player, true);
    } catch {
      // 이미 나간 플레이어
    }
  }
}
