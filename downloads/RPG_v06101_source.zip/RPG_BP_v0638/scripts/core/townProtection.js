import {CITY_HOUSE_PLOTS} from '../data/fantasyCity.js';
import {landOwner,landSelection,hasLandAccess} from './realEstate.js';
import {spawnRegion} from './spawnEffects.js';
import {hasBuilderTag,registerStructureProtection} from './structureProtection.js';
const dimensionId=id=>id?.replace('minecraft:','');
export function townProtected(block,region=spawnRegion(),player,operation){
 if(!block?.location||!block.dimension?.id)return false;
 const {x,y,z}=block.location;
 const inTown=region&&dimensionId(block.dimension.id)===dimensionId(region.dimId)&&
  x>=region.x&&x<region.x+region.size&&z>=region.z&&z<region.z+region.size;
 if(inTown&&hasBuilderTag(player))return false;
 try{
  const owner=landOwner(landSelection(block,region));
  if(!inTown)return !!owner&&!hasLandAccess(player,owner);
  // Public remodeling remains available in unclaimed houses above the permanent floor.
  const house=CITY_HOUSE_PLOTS.some(p=>x-region.x>=p.x&&x-region.x<p.x+p.w&&z-region.z>=p.z&&z-region.z<p.z+p.d);
  const publicHouseHeight=(y>region.y&&y<=region.y+16)||(operation==='support'&&Math.floor(y)===region.y);
  if(player&&house&&publicHouseHeight&&!owner)return false;
  if(!hasLandAccess(player,owner))return true;
 }catch{return true;}
 // A purchased chunk allows building on top of the permanent village floor.
 if(operation==='support'&&Math.floor(y)===region.y)return false;
 return Math.floor(y)<=region.y;
}
let registered=false;
export function registerTownProtection(){if(registered)return;registered=true;registerStructureProtection('town',(block,player,operation)=>townProtected(block,spawnRegion(),player,operation));}
