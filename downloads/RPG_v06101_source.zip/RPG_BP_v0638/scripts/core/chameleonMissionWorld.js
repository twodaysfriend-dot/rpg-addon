import {world,system} from '@minecraft/server';
import {activeChameleonMission,advanceChameleonMission,missionSurvival,isRaidVictoryEffect,recordMissionRaidWin,tickChameleonMissions} from './chameleonMissions.js';

const DRAGON_WAIT='rpg:chameleon_dragon_wait';
const DRAGON_CREDIT='rpg:chameleon_dragon_credit_';
const DRAGON_TIMEOUT=150000;
const DIAMOND_ORES=['minecraft:diamond_ore','minecraft:deepslate_diamond_ore'];
const DEBRIS='minecraft:ancient_debris';
const MINING_MISSIONS=new Map([...DIAMOND_ORES.map(id=>[id,'diamond']),[DEBRIS,'debris']]);
const DEBRIS_TOOLS=['minecraft:diamond_pickaxe','minecraft:netherite_pickaxe'];
const DIAMOND_TOOLS=['minecraft:iron_pickaxe',...DEBRIS_TOOLS];
const DIAMOND_DROPS=[];
const DIAMOND_BREAKS=[];
let miningTimer,registered=false;

function observe(action){
 return event=>{try{action(event);}catch(error){console.warn('[RPG mission event] '+error);}};
}
const isEnd=dim=>dim?.id==='minecraft:the_end'||dim?.id==='the_end';
const horizontal=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const dragonCreditKey=p=>DRAGON_CREDIT+encodeURIComponent(p.id);
const savedDragon=()=>{
 const raw=world.getDynamicProperty(DRAGON_WAIT);
 return typeof raw==='string'?JSON.parse(raw):undefined;
};
function fountainSide(x,z){
 const cardinal=distance=>Math.abs(distance)>=2&&Math.abs(distance)<=4;
 if(x===0&&cardinal(z))return z<0?'north':'south';
 if(z===0&&cardinal(x))return x<0?'west':'east';
}
function crystalCount(dim,at){
 // Four crystals sit on the cardinal blocks of the exit fountain.
 const crystals=dim.getEntities({type:'minecraft:ender_crystal',location:{x:.5,y:at.y+1,z:.5},maxDistance:6});
 const positions=new Set();
 for(const entity of crystals){
  const {x,y,z}=entity.location;
  if(Math.abs(y-at.y-1)>1)continue;
  const side=fountainSide(Math.floor(x),Math.floor(z));
  if(side)positions.add(side);
 }
 return positions.size;
}
export function observeDragonCrystal({player:p,beforeItemStack,itemStack,block}){
 if(beforeItemStack?.typeId!=='minecraft:end_crystal'||block?.typeId!=='minecraft:bedrock'||!isEnd(block.dimension))return false;
 const at=block.location,dim=block.dimension;
 if(!fountainSide(at.x,at.z))return false;
 if(itemStack?.typeId===beforeItemStack.typeId&&itemStack.amount>=beforeItemStack.amount)return false;
 if(!missionSurvival(p))return false;
 const mission=activeChameleonMission(p);
 if(mission?.id!=='dragon')return false;
 const check=()=>{
  if(savedDragon()?.until>Date.now()||dim.getEntities({type:'minecraft:ender_dragon'}).length||crystalCount(dim,at)!==4)return false;
  world.setDynamicProperty(DRAGON_WAIT,JSON.stringify({playerId:p.id,serial:mission.serial,until:Date.now()+DRAGON_TIMEOUT}));
  return true;
 };
 // Allow the engine to publish the last crystal before inspecting the fountain.
 if(check())return true;
 system.run(observe(check));
 return false;
}
export function observeDragonSpawn(entity){
 if(entity.typeId!=='minecraft:ender_dragon'||!isEnd(entity.dimension)||horizontal(entity.location,{x:0,z:0})>128)return false;
 const claim=savedDragon();
 if(!claim)return false;
 if(claim.until>=Date.now())world.setDynamicProperty(dragonCreditKey({id:claim.playerId}),claim.serial);
 world.setDynamicProperty(DRAGON_WAIT,undefined);
 return true;
}
function deliverDragonCredit(p){
 const key=dragonCreditKey(p),serial=world.getDynamicProperty(key);
 if(!Number.isSafeInteger(serial))return;
 const mission=activeChameleonMission(p);
 if(!mission)return;
 if(mission.id!=='dragon'||mission.serial!==serial||advanceChameleonMission(p,'dragon',serial))world.setDynamicProperty(key,undefined);
}

function oreChunk(block){
 const {x,y,z}=block.location;
 return 'rpg:placed_mission_ore_'+encodeURIComponent(block.dimension.id)+'_'+[x,y,z].map(v=>Math.floor(v/16)).join('_');
}
function rememberPlacedOre(block,placed){
 const key=oreChunk(block),{x,y,z}=block.location;
 const local=v=>v&15;
 const point=local(y)*256+local(z)*16+local(x);
 const raw=world.getDynamicProperty(key),stored=typeof raw==='string'?JSON.parse(raw):[];
 const positions=new Set(stored),existed=positions.has(point);
 if(existed===placed)return existed;
 if(placed)positions.add(point);else positions.delete(point);
 world.setDynamicProperty(key,positions.size?JSON.stringify([...positions]):undefined);
 return existed;
}
export function observeOrePlacement({block}){
 if(MINING_MISSIONS.has(block.typeId))rememberPlacedOre(block,true);
}
function enchantmentLevel(item,id){
 try{return item?.getComponent('minecraft:enchantable')?.getEnchantment(id)?.level??0;}catch{return 0;}
}
function queueMiningFlush(){
 if(miningTimer!==undefined)return;
 miningTimer=system.runTimeout(observe(flushMissionDiamonds),2);
}
export function observeOreBreak({block,brokenBlockPermutation,itemStackBeforeBreak,player:p}){
 const id=MINING_MISSIONS.get(brokenBlockPermutation?.type?.id);
 if(!id||rememberPlacedOre(block,false)||!missionSurvival(p))return false;
 const mission=activeChameleonMission(p);
 const item=itemStackBeforeBreak;
 if(mission?.id!==id)return false;
 if(id==='debris'){
  if(!DEBRIS_TOOLS.includes(item?.typeId))return false;
  return advanceChameleonMission(p,id,mission.serial);
 }
 if(!DIAMOND_TOOLS.includes(item?.typeId)||enchantmentLevel(item,'silk_touch')>0)return false;
 const at=block.location;
 DIAMOND_BREAKS.push({p,serial:mission.serial,dim:block.dimension.id,tick:system.currentTick,
  at:{x:at.x+.5,y:at.y+.5,z:at.z+.5},cap:1+Math.min(3,enchantmentLevel(item,'fortune'))});
 queueMiningFlush();
 return true;
}
export function observeDiamondDrop(entity){
 if(entity.typeId!=='minecraft:item')return false;
 const item=entity.getComponent('minecraft:item')?.itemStack;
 if(item?.typeId!=='minecraft:diamond'||item.amount<1||item.amount>4)return false;
 DIAMOND_DROPS.push({dim:entity.dimension.id,at:{...entity.location},tick:system.currentTick,amount:item.amount});
 queueMiningFlush();
 return true;
}
export function flushMissionDiamonds(){
 miningTimer=undefined;
 const breaks=DIAMOND_BREAKS.splice(0),drops=DIAMOND_DROPS.splice(0);
 const matches=[];
 for(const block of breaks)for(const drop of drops){
  if(block.dim!==drop.dim||Math.abs(block.tick-drop.tick)>1||drop.amount>block.cap)continue;
  const delta=Math.hypot(drop.at.x-block.at.x,drop.at.y-block.at.y,drop.at.z-block.at.z);
  if(delta<=1.25)matches.push({block,drop,delta});
 }
 matches.sort((a,b)=>a.delta-b.delta);
 for(const {block,drop} of matches){
  if(drop.amount===0||block.cap<drop.amount)continue;
  const amount=drop.amount;
  drop.amount=0;
  block.cap-=amount;
  advanceChameleonMission(block.p,'diamond',block.serial,amount);
 }
 // A break or drop from the current tick may still get its partner next tick.
 const recent=system.currentTick-1;
 DIAMOND_BREAKS.push(...breaks.filter(block=>block.cap>0&&block.tick>=recent));
 DIAMOND_DROPS.push(...drops.filter(drop=>drop.amount>0&&drop.tick>=recent));
 if(DIAMOND_BREAKS.length||DIAMOND_DROPS.length)queueMiningFlush();
}
export function tickMissionWorld(){
 tickChameleonMissions();
 for(const p of world.getAllPlayers())observe(deliverDragonCredit)(p);
}
export function registerChameleonMissions(){
 if(registered)return;
 registered=true;
 world.afterEvents.playerPlaceBlock.subscribe(observe(observeOrePlacement));
 world.afterEvents.playerBreakBlock.subscribe(observe(observeOreBreak));
 world.afterEvents.playerInteractWithBlock.subscribe(observe(observeDragonCrystal));
 world.afterEvents.effectAdd.subscribe(observe(({entity,effect})=>{
  const typeId=effect?.typeId;
  if(!isRaidVictoryEffect(typeId)||activeChameleonMission(entity)?.id!=='raid')return;
  const event={entity,effect:{typeId}};
  // The engine can publish the hero effect before the final raider's death callback.
  if(!recordMissionRaidWin(event))system.run(observe(()=>recordMissionRaidWin(event)));
 }));
 world.afterEvents.entitySpawn.subscribe(observe(({entity})=>{
  if(entity.typeId==='minecraft:ender_dragon')observeDragonSpawn(entity);
  else if(entity.typeId==='minecraft:item')observeDiamondDrop(entity);
 }));
 system.runInterval(tickMissionWorld,20);
}
