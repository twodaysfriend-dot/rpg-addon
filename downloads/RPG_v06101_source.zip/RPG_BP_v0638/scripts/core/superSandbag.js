import { world } from '@minecraft/server';
import { isSuperSandbag, SUPER_SANDBAG_MK2_ID } from './positionLock.js';

export { SUPER_SANDBAG_ID } from './positionLock.js';
const DEFAULT_NAME = '§c슈퍼 샌드백 §f· HP ∞';
const MK2_NAME = '§b슈퍼 샌드백 Mk.2 §f· HP ∞ · PvP 8%';
const displayName = entity => entity.typeId === SUPER_SANDBAG_MK2_ID ? MK2_NAME : DEFAULT_NAME;
const damageKey = player => 'rpg:super_sandbag_damage_' + player.id;

function showDamage(dummy, player, damage) {
  const name = player.name.replace(/§./g, '');
  const amount = Number(damage.toFixed(2)).toLocaleString('en-US');
  dummy.nameTag = `${displayName(dummy)}\n§f${name} · 누적 피해 §e${amount}`;
}

export function recordSuperSandbagDamage(dummy, player, damage) {
  if (player?.typeId !== 'minecraft:player' || !Number.isFinite(damage) || damage <= 0) return;
  const key = damageKey(player);
  const total = (dummy.getDynamicProperty(key) ?? 0) + damage;
  dummy.setDynamicProperty(key, total);
  showDamage(dummy, player, total);
}

export function registerSuperSandbag() {
  const initialize = ({entity}) => {
    if (isSuperSandbag(entity.typeId) && !entity.nameTag) entity.nameTag = displayName(entity);
  };
  world.afterEvents.entitySpawn.subscribe(initialize);
  world.afterEvents.entityLoad.subscribe(initialize);
  world.afterEvents.entityHurt.subscribe(({hurtEntity}) => {
    if (!isSuperSandbag(hurtEntity.typeId)) return;
    try {
      const health = hurtEntity.getComponent('minecraft:health');
      if (health && health.currentValue < health.effectiveMax) health.resetToMaxValue();
    } catch {}
  });
  world.afterEvents.playerInteractWithEntity.subscribe(({player, target}) => {
    if (!isSuperSandbag(target.typeId) || !player.isSneaking) return;
    target.setDynamicProperty(damageKey(player), undefined);
    showDamage(target, player, 0);
  });
}
