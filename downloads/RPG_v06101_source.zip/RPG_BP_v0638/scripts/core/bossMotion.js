import {world,system} from '@minecraft/server';
const IDS=new Set(['rpg:rock_golem_boss','rpg:cyclops_boss','rpg:tech_block_golem_boss','rpg:hydra_boss']);
const MECHANICS={
 'rpg:rock_golem_boss':{eruption:34},
 'rpg:cyclops_boss':{eye_beam:32},
 'rpg:hydra_boss':{fire_breath:30,tail_sweep:26},
 'rpg:tech_block_golem_boss':{arc_field:32},
 'rpg:elite_deathworm':{sand_rupture:31},
};
const mechanicUntil=new Map();
export function bossMechanicActive(boss){return (mechanicUntil.get(boss.id)??0)>system.currentTick;}
const locked=new Map();let registered=false;
export function playBossMotion(boss,motion='melee'){
 const duration=MECHANICS[boss?.typeId]?.[motion];
 if(!duration&&(!IDS.has(boss?.typeId)||!['melee','slam','wave'].includes(motion)||(boss.typeId==='rpg:hydra_boss'&&motion!=='melee')||bossMechanicActive(boss)))return false;
 try{
  if(boss.isValid===false||(boss.getComponent('minecraft:health')?.currentValue??0)<=0)return false;
  const until=locked.get(boss.id)??0;if((motion==='melee'||motion==='wave')&&until>system.currentTick)return false;
  if(duration)mechanicUntil.set(boss.id,system.currentTick+duration);
  boss.playAnimation('animation.rpg.'+boss.typeId.slice(4)+'.'+motion,{controller:'rpg_boss_action',blendOutTime:.15,stopExpression:'query.any_animation_finished'});
  locked.set(boss.id,system.currentTick+(duration??(motion==='slam'?24:motion==='wave'?20:16)));return true;
 }catch{return false;}
}
export function registerBossMotion(){
 if(registered)return;registered=true;
 world.afterEvents.entityHurt.subscribe(ev=>{if(ev.damage>0&&ev.damageSource?.cause==='entityAttack')playBossMotion(ev.damageSource.damagingEntity);});
 world.afterEvents.entityDie.subscribe(ev=>{locked.delete(ev.deadEntity?.id);mechanicUntil.delete(ev.deadEntity?.id);});
 system.runInterval(()=>{for(const [id,until]of locked)if(until<=system.currentTick)locked.delete(id);for(const [id,until]of mechanicUntil)if(until<=system.currentTick)mechanicUntil.delete(id);},100);
}
