import {world,system,EquipmentSlot} from '@minecraft/server';
import {armorInfo} from '../data/equipment.js';

const KEY='rpg:mending_identity_v1';
const SLOTS=[EquipmentSlot.Mainhand,EquipmentSlot.Offhand,EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet];
const snapshots=new Map();let serial=0,registered=false;
const session=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
function signature(item){
 const durability=item?.getComponent('minecraft:durability');
 const enchants=item?.getComponent('minecraft:enchantable')?.getEnchantments()??[];
 if(!durability||!enchants.some(e=>e.type.id.replace('minecraft:','')==='mending'))return;
 return {durability,key:item.typeId+':'+durability.maxDurability+':'+JSON.stringify(enchants.map(e=>[e.type.id,e.level]).sort())};
}
// Native Mending has no stable Script API event. Observe its repair on continuously
// equipped/held items; an anvil/grindstone requires removing the item and resets
// this baseline. Track identity, not just type, so swapping identical gear is safe.
export function boostMending(player){
 const eq=player.getComponent('minecraft:equippable');
 if(!eq){snapshots.delete(player.id);return 0;}
 const previous=snapshots.get(player.id)??new Map(),next=new Map();let restored=0;
 for(const slot of SLOTS){
  const item=eq.getEquipment(slot),s=signature(item);if(!s)continue;
  let identity=item.getDynamicProperty(KEY),changed=false;
  if(!identity){identity=session+':'+(++serial);item.setDynamicProperty(KEY,identity);changed=true;}
  const key=identity+':'+s.key,old=previous.get(slot),damage=s.durability.damage;
  if(old?.key===key&&damage<old.damage){
   const nativeRepair=old.damage-damage;
   const bonusMultiplier=armorInfo(item.typeId)?3:1;
   const extra=Math.min(damage,nativeRepair*bonusMultiplier);
   if(extra>0){s.durability.damage=damage-extra;restored+=extra;changed=true;}
  }
  if(changed)eq.setEquipment(slot,item);
  // Record the post-bonus value to prevent compounding our own repair next tick.
  next.set(slot,{key,damage:s.durability.damage});
 }
 snapshots.set(player.id,next);return restored;
}
export function forgetMending(playerId){snapshots.delete(playerId);}
export function registerMendingBoost(){
 if(registered)return;registered=true;
 world.afterEvents.playerLeave.subscribe(({playerId})=>forgetMending(playerId));
 world.afterEvents.playerSpawn.subscribe(({player})=>forgetMending(player.id));
 system.runInterval(()=>{for(const p of world.getAllPlayers())try{boostMending(p);}catch(error){forgetMending(p.id);console.warn('[RPG mending] '+error);}},1);
}
