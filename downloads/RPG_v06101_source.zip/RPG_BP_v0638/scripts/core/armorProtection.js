import {EquipmentSlot,ItemStack,system,world} from '@minecraft/server';
import {armorInfo} from '../data/equipment.js';
import {ARMOR_PROTECTION_LEVEL,upgradeLevel} from '../data/upgrades.js';

const SLOTS=[EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet];

function targetArmorType(item,level){
 const info=armorInfo(item?.typeId);
 if(!info)return undefined;
 const type=level>=ARMOR_PROTECTION_LEVEL?info.protectedTypeId:info.baseTypeId;
 return type===item.typeId?undefined:type;
}

// The stable Script API exposes an item's damage value but not its wear chance.
// Both native types have the same wearable, enchantable, repairable and icon data.
export function withArmorProtection(item,level=upgradeLevel(item,'armor')){
 const type=targetArmorType(item,level);
 if(!type)return undefined;
 const next=new ItemStack(type,item.amount);
 next.nameTag=item.nameTag;
 next.keepOnDeath=item.keepOnDeath;
 next.lockMode=item.lockMode;
 next.setLore(item.getRawLore?.()??item.getLore());
 const destroy=item.getCanDestroy?.(),place=item.getCanPlaceOn?.();
 if(destroy?.length)next.setCanDestroy(destroy);
 if(place?.length)next.setCanPlaceOn(place);
 for(const key of item.getDynamicPropertyIds())next.setDynamicProperty(key,item.getDynamicProperty(key));
 const enchantments=item.getComponent('minecraft:enchantable')?.getEnchantments();
 if(enchantments?.length)next.getComponent('minecraft:enchantable').addEnchantments(enchantments);
 const oldDurability=item.getComponent('minecraft:durability');
 if(oldDurability){
  const durability=next.getComponent('minecraft:durability');
  durability.damage=Math.min(durability.maxDurability-1,oldDurability.damage);
 }
 return next;
}

function migrateSlot(item,save){
 if(!item||!armorInfo(item.typeId))return false;
 try{
  const next=withArmorProtection(item);
  if(!next)return false;
  save(next);
  return true;
 }catch(error){
  console.warn('[RPG armor protection] '+error);
  return false;
 }
}
function syncWornArmor(player){
 const equipment=player.getComponent('minecraft:equippable');
 if(!equipment)return;
 for(const slot of SLOTS){
  migrateSlot(equipment.getEquipment(slot),next=>{
   if(!equipment.setEquipment(slot,next))throw Error('착용 갑옷 저장 실패');
  });
 }
}
function syncStoredArmor(player){
 const inventory=player.getComponent('minecraft:inventory')?.container;
 if(!inventory)return;
 for(let slot=0;slot<inventory.size;slot++)migrateSlot(inventory.getItem(slot),next=>inventory.setItem(slot,next));
}
export function syncProtectedArmor(player){
 syncWornArmor(player);
 syncStoredArmor(player);
}
export function registerArmorProtection(){
 for(const player of world.getAllPlayers())syncProtectedArmor(player);
 world.afterEvents.playerSpawn.subscribe(({player})=>syncProtectedArmor(player));
 world.afterEvents.playerInventoryItemChange.subscribe(({player,itemStack})=>{
  if(armorInfo(itemStack?.typeId)&&targetArmorType(itemStack,upgradeLevel(itemStack,'armor')))syncStoredArmor(player);
 });
 // Wearing armor via a dispenser does not necessarily touch the player inventory.
 system.runInterval(()=>{for(const player of world.getAllPlayers())syncWornArmor(player);},1);
}
