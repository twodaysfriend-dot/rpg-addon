import {world,system,BlockPermutation} from '@minecraft/server';
import {registerStructureProtection} from './structureProtection.js';
export const PRISON_KEY='rpg:prison_v1';
export const PRISON_BASE_TICKS=6000n;
const AREA='rpg_pk_jail_v1',last=new Map();let cached,registered=false,dirty=false;
const tell=(p,s)=>{try{p?.sendMessage(s);}catch{}};
export function prisonAdmin(p){try{if(p?.playerPermissionLevel===2)return true;}catch{}try{if(p?.commandPermissionLevel>=1)return true;}catch{}try{return p?.isOp?.()===true;}catch{return false;}}
function requireAdmin(p){if(!prisonAdmin(p))throw Error('감옥 관리는 관리자만 사용할 수 있습니다.');}
function state(){if(!cached){const raw=world.getDynamicProperty(PRISON_KEY);cached=raw?JSON.parse(raw):{version:1,players:{},config:null};if(cached.version!==1||!cached.players)throw Error('감옥 저장 데이터를 확인하세요.');}return cached;}
function write(s){const raw=JSON.stringify(s);if(raw.length>30000)throw Error('감옥 기록 저장 공간이 부족합니다. 관리자 확인이 필요합니다.');world.setDynamicProperty(PRISON_KEY,raw);cached=s;dirty=false;}
function change(fn){const s=JSON.parse(JSON.stringify(state())),result=fn(s);write(s);return result;}
const online=id=>world.getAllPlayers().find(p=>p.id===id);
export function getPrisonRecord(p){return state().players[typeof p==='string'?p:p?.id];}
export function isJailed(p){const r=getPrisonRecord(p);return r?.active===true||r?.releasePending===true;}
function inside(p,at,dimId){return p?.dimension?.id===dimId&&Math.floor(p.location.x)===Math.floor(at.x)&&Math.floor(p.location.z)===Math.floor(at.z)&&p.location.y>=at.y-.05&&p.location.y<at.y+2.05;}
export function prisonContains(p){const s=state(),r=getPrisonRecord(p);return !!(s.config&&r?.active&&r.cell!==null&&r.cell!==undefined&&inside(p,s.config.cells[r.cell],s.config.dimId));}
function displayTicks(raw){const seconds=(BigInt(raw)+19n)/20n;return seconds>=60n?`${seconds/60n}분 ${seconds%60n}초`:`${seconds}초`;}
export function recordPrisonPk(p){
 if(!p?.id)return;
 let sentenced=false;
 change(s=>{const r=s.players[p.id]??={name:p.name,stacks:0,visits:0,active:false};r.name=p.name??r.name;if(r.active)return;r.stacks++;
  if(r.stacks>=3){r.stacks=0;r.visits++;r.active=true;r.releasePending=false;r.cell=null;r.remaining=(PRISON_BASE_TICKS<<(BigInt(r.visits)-1n)).toString();sentenced=true;}
 });
 const r=getPrisonRecord(p);tell(p,sentenced?`§c[감옥] PK 3회로 ${displayTicks(r.remaining)} 수감됩니다. PK 스택은 0으로 초기화됐습니다.`:`§c[감옥] PK 스택 ${r.stacks}/3`);
 if(sentenced&&p.isValid!==false)tickPrison();
}
function clearActive(s,id){const r=s.players[id];if(!r)return;r.active=false;r.cell=null;r.remaining='0';r.stacks=0;r.releasePending=!!s.config;}
function tryExit(p,c){if(!p||!c)return false;try{p.teleport(c.exit,{dimension:world.getDimension(c.dimId),keepVelocity:false,checkForBlocks:true});}catch(error){if(system.currentTick%100===0)tell(p,'§e석방됐지만 출구 이동에 실패했습니다. 관리자에게 이동을 요청하세요.');return false;}try{p.removeTag('rpg_jailed');}catch{}last.delete(p.id);return true;}
function moveOut(p){if(tryExit(p,state().config)){const r=getPrisonRecord(p);if(r){r.releasePending=false;dirty=true;}}}
function resolveName(arg){const name=String(arg??'').trim().replace(/^"|"$/g,'').toLowerCase();if(!name)throw Error('플레이어 이름을 입력하세요.');const p=world.getAllPlayers().find(p=>p.name.toLowerCase()===name);const id=p?.id??Object.keys(state().players).find(id=>state().players[id].name?.toLowerCase()===name);if(!id||!state().players[id])throw Error('해당 플레이어의 감옥 기록이 없습니다.');return {id,p,name:state().players[id].name};}
export function releasePrisoner(admin,arg){requireAdmin(admin);const t=resolveName(arg);if(!getPrisonRecord(t.id).active&&!getPrisonRecord(t.id).releasePending){tell(admin,'§e이미 석방된 플레이어입니다.');return;}change(s=>clearActive(s,t.id));moveOut(t.p);tell(admin,`§a${t.name}을 석방했습니다. 누적 수감 횟수는 유지합니다.`);tell(t.p,'§a[감옥] 관리자가 석방했습니다.');}
export function resetPrisonHistory(admin,arg=''){
 requireAdmin(admin);
 const name=String(arg??'').trim();
 const target=!name||name==='@s'?{id:admin.id,name:admin.name}:resolveName(name);
 if(!getPrisonRecord(target.id)){tell(admin,'§e[감옥] 초기화할 PK·수감 기록이 없습니다.');return false;}
 change(s=>{const r=s.players[target.id];r.visits=0;r.stacks=0;if(r.active)r.remaining=PRISON_BASE_TICKS.toString();});
 last.delete(target.id);
 tell(admin,`§a${target.name}의 PK 스택·수감 배율을 초기화했습니다. 현재 수감 중이면 남은 5분, 다음 수감도 5분입니다.`);
 return true;
}
export function showPrisonStatus(p,arg='',overview=false){
 if(overview)requireAdmin(p);
 const name=String(arg).trim();if(name&&!prisonAdmin(p))throw Error('다른 플레이어의 기록은 관리자만 확인할 수 있습니다.');
 if(!name&&overview){const s=state(),all=Object.values(s.players).filter(r=>r.active);tell(p,`§e감옥 ${s.config?'설치됨 · '+s.config.dimId+' '+s.config.x+' '+s.config.y+' '+s.config.z:'미설치'} · 수감/대기 ${all.length}명\n${all.map(r=>`${r.name}: ${r.cell==null?'대기':(r.cell+1)+'번'} · ${displayTicks(r.remaining)}`).join('\n')}`);return;}
 const r=name?state().players[resolveName(name).id]:getPrisonRecord(p);
 tell(p,r?`§e[감옥] ${r.name} · PK ${r.stacks}/3 · 누적 ${r.visits}회 · ${r.active?displayTicks(r.remaining)+(r.cell==null?' (수감 대기)':' 남음'):(r.releasePending?'석방·출구 이동 대기':'수감 아님')}`:'§e[감옥] PK 0/3 · 수감 기록 없음');
}
export function tickPrison(){
 const s=JSON.parse(JSON.stringify(state())),toRelease=[],c=s.config,players=world.getAllPlayers(),byId=new Map(players.map(p=>[p.id,p])),now=system.currentTick;
 const occupied=new Set();
 for(const [id,r]of Object.entries(s.players)){
  if(!r.active)continue;
  if(!byId.has(id)){if(r.cell!=null){r.cell=null;dirty=true;}last.delete(id);continue;}
  if(r.cell!=null&&r.cell>=0&&r.cell<10&&!occupied.has(r.cell))occupied.add(r.cell);else if(r.cell!=null){r.cell=null;dirty=true;last.delete(id);}
 }
 for(const p of players){
  const r=s.players[p.id];if(!r?.active){if(r?.releasePending&&tryExit(p,c)){r.releasePending=false;dirty=true;}try{if(p.hasTag?.('rpg_jailed'))p.removeTag('rpg_jailed');}catch{}last.delete(p.id);continue;}
  try{if(!p.hasTag?.('rpg_jailed'))p.addTag('rpg_jailed');}catch{}
  if(!c){last.delete(p.id);if(now%200===0)tell(p,'§c감옥 설치 대기 중입니다. 관리자가 /rpg:jailcreate를 실행해야 합니다.');continue;}
  if(r.cell==null){const slot=Array.from({length:10},(_,i)=>i).find(i=>!occupied.has(i));if(slot!==undefined){r.cell=slot;occupied.add(slot);dirty=true;last.delete(p.id);} }
  const target=r.cell==null?c.wait:c.cells[r.cell],was=last.get(p.id),alive=(p.getComponent('minecraft:health')?.currentValue??0)>0,valid=alive&&r.cell!=null&&inside(p,target,c.dimId);
  if(valid&&was?.inside&&was.tick===now-1){r.remaining=(BigInt(r.remaining)>0n?BigInt(r.remaining)-1n:0n).toString();dirty=true;}
  last.set(p.id,{tick:now,inside:valid});
  if(BigInt(r.remaining)<=0n){clearActive(s,p.id);dirty=true;toRelease.push(p);continue;}
  if(!inside(p,target,c.dimId)&&alive)try{p.teleport(target,{dimension:world.getDimension(c.dimId),keepVelocity:false,checkForBlocks:true});}catch(error){if(now%100===0)tell(p,'§c감옥 이동 실패. 형기는 차감되지 않습니다. 관리자에게 확인을 요청하세요.');}
  if(now%20===0)try{p.onScreenDisplay?.setActionBar(`§c감옥 ${r.cell==null?'빈 칸 대기':(r.cell+1)+'번'} · ${displayTicks(r.remaining)} · 감옥 밖/미접속 시간은 차감되지 않습니다.`);}catch{}
 }
 if(toRelease.length){write(s);for(const p of toRelease){moveOut(p);tell(p,'§a[감옥] 형기를 마쳐 석방됐습니다.');}}else{cached=s;if(dirty&&now%20===0)write(s);}
}
function keepLoaded(c){const dim=world.getDimension(c.dimId);try{dim.runCommand('tickingarea remove '+AREA);}catch{}const r=dim.runCommand(`tickingarea add ${c.x} ${c.y} ${c.z} ${c.x+20} ${c.y+4} ${c.z+11} ${AREA} true`);if(r?.successCount===0)throw Error('감옥 청크 유지 영역을 만들 수 없습니다. tickingarea 여유를 확인하세요.');}
export function createPrison(admin,arg=''){
 requireAdmin(admin);if(state().config){showPrisonStatus(admin,'',true);return false;}
 if(!['minecraft:overworld','overworld'].includes(admin.dimension.id))throw Error('오버월드의 빈 공간에서 생성하세요.');
 const y=String(arg).trim()?Number(arg):Math.floor(admin.location.y)-1;if(!Number.isInteger(y)||y< -62||y>315)throw Error('감옥 바닥 Y는 -62~315 정수입니다.');
 const c={dimId:world.getDimension(admin.dimension.id).id,x:Math.floor(admin.location.x)+5,y,z:Math.floor(admin.location.z)+5,cells:[]};
 c.wait={x:c.x+1.5,y:y+1,z:c.z+1.5};c.exit={x:c.x+3.5,y:y+1,z:c.z+1.5};
 const ops=new Map(),put=(x,yy,z,type)=>ops.set(`${x},${yy},${z}`,{x, y:yy,z,type});
 for(let row=0;row<2;row++)for(let col=0;col<5;col++){
  const x=c.x+2+col*4,z=c.z+5+row*4;c.cells.push({x:x+.5,y:y+1,z:z+.5});
  for(let dy=0;dy<=4;dy++)for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++){
   if(dy===0||dy===4)put(x+dx,y+dy,z+dz,'minecraft:bedrock');else if(dx||dz)put(x+dx,y+dy,z+dz,'minecraft:iron_bars');else put(x,y+dy,z,'minecraft:air');
  }
 }
 for(let dx=0;dx<=4;dx++)for(let dz=0;dz<=2;dz++){put(c.x+dx,y,c.z+dz,'minecraft:bedrock');for(let dy=1;dy<=3;dy++)put(c.x+dx,y+dy,c.z+dz,'minecraft:air');}
 const dim=admin.dimension,prepared=[];let loaded=false;
 try{
  keepLoaded(c);loaded=true;
  for(const op of ops.values()){const block=dim.getBlock({x:op.x,y:op.y,z:op.z});if(!block)throw Error('감옥 위치 청크가 아직 로드되지 않았습니다. 잠시 뒤 다시 실행하세요.');if(!block.isAir&&!(op.y===y&&['minecraft:grass_block','minecraft:dirt','minecraft:sand','minecraft:gravel'].includes(block.typeId)))throw Error('감옥 생성 위치에 기존 블록/건물이 있습니다. 더 넓은 빈 공간으로 이동하세요.');prepared.push({block,old:block.permutation,type:op.type});}
  let count=0;try{for(const item of prepared){item.block.setPermutation(BlockPermutation.resolve(item.type));count++;}change(s=>{s.config=c;});}catch(error){for(const item of prepared.slice(0,count).reverse())try{item.block.setPermutation(item.old);}catch{}throw error;}
 }catch(error){if(loaded)try{dim.runCommand('tickingarea remove '+AREA);}catch{}throw error;}
 tell(admin,`§a감옥 10칸 생성 완료 · 내부 각 1×1 · 중심 ${c.x+10}, ${y+1}, ${c.z+7}\n§7내 상태 /rpg:jail · 관리 /rpg:jailstatus · 석방 /rpg:jailrelease 이름 · 배율 초기화 /rpg:jailreset [이름]`);tickPrison();return true;
}
export function registerPrison(){
 if(registered)return;registered=true;
 registerStructureProtection('pk_prison',(block,p)=>{const c=state().config,a=block?.location;return !!(c&&a&&block.dimension.id===c.dimId&&a.x>=c.x&&a.x<=c.x+20&&a.z>=c.z&&a.z<=c.z+11&&a.y>=c.y&&a.y<=c.y+4&&!prisonAdmin(p));});
 world.afterEvents.playerSpawn.subscribe(({player})=>{last.delete(player.id);system.run(()=>tickPrison());});
 world.afterEvents.playerLeave.subscribe(({playerId})=>{last.delete(playerId);const r=getPrisonRecord(playerId);if(r?.active){r.cell=null;dirty=true;}if(dirty)write(state());});
 system.run(()=>{const c=state().config;if(c)try{keepLoaded(c);}catch(error){console.warn('[RPG prison chunks] '+error);}tickPrison();});
 system.runInterval(()=>{try{tickPrison();}catch(error){console.warn('[RPG prison] '+error);}},1);
}
