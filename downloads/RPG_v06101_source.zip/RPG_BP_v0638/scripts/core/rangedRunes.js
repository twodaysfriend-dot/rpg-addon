import { system,world } from '@minecraft/server';
import { rangedRuneRate } from './combatRunes.js';

const DRAW_TICKS=new Map([['minecraft:bow',20],['rpg:archer_bow',10],['rpg:apprentice_bow',30]]);
const WEAPON_PROJECTILES=new Set(['minecraft:arrow','minecraft:thrown_trident','minecraft:snowball','minecraft:egg','minecraft:fireworks_rocket']);
const scripted=new Set(), draws=new Map(), releases=new Map();
let registered=false;

export function markScriptRangedShot(entity){scripted.add(entity.id);}
export function rangedShotDelay(player,ticks){return Math.max(1,Math.ceil(ticks/rangedRuneRate(player)));}

function bowPower(ticks,fullDraw){
  const draw=Math.min(1,ticks/fullDraw);
  return (draw*draw+2*draw)/3;
}

function accelerate(entity,retry=true){
  try{
    if(scripted.delete(entity.id) || !entity.isValid)return;
    const projectile=entity.getComponent('minecraft:projectile'), owner=projectile?.owner;
    if(!owner){if(retry)system.runTimeout(()=>accelerate(entity,false),1);return;}
    const rate=rangedRuneRate(owner);
    if(rate<=1)return;
    const velocity=entity.getVelocity(), speed=Math.hypot(velocity.x,velocity.y,velocity.z);
    if(speed<0.1)return;
    let boost=rate;
    const draw=releases.get(owner.id);
    if(entity.typeId==='minecraft:arrow'){
      if(draw&&draw.tick>=system.currentTick-3){
        boost*=bowPower(draw.held*rate,draw.full)/bowPower(draw.held,draw.full);
        releases.delete(owner.id);
      }
      boost=Math.min(boost,3*rate/speed);
    }
    projectile.shoot({x:velocity.x*boost,y:velocity.y*boost,z:velocity.z*boost},{uncertainty:0});
  }catch{}
}

export function registerRangedRunes(){
  if(registered)return;
  registered=true;
  world.afterEvents.itemStartUse?.subscribe(({source,itemStack})=>{
    const full=DRAW_TICKS.get(itemStack?.typeId);
    if(full)draws.set(source.id,{type:itemStack.typeId,full,tick:system.currentTick});
    else draws.delete(source.id);
  });
  world.afterEvents.itemReleaseUse?.subscribe(({source,itemStack})=>{
    const draw=draws.get(source.id);
    draws.delete(source.id);
    releases.delete(source.id);
    if(!draw || draw.type!==itemStack?.typeId || rangedRuneRate(source)<=1)return;
    const now=system.currentTick;
    releases.set(source.id,{full:draw.full,held:Math.max(1,now-draw.tick),tick:now});
  });
  world.afterEvents.entitySpawn.subscribe(({entity})=>{
    if(WEAPON_PROJECTILES.has(entity?.typeId))system.runTimeout(()=>accelerate(entity),1);
  });
  world.afterEvents.playerLeave.subscribe(({playerId})=>{draws.delete(playerId);releases.delete(playerId);});
}
