import {system} from '@minecraft/server';

export const BLOODEDGE_POOL_TAG='rpg:bloodedge_pool';
export const BLOODEDGE_MEASURE_TAG='rpg_be_measure';
export const shieldSessions=new Map();
export const siwangSessions=new Map();

export function siwangStatus(player){
  const session=siwangSessions.get(player.id);
  if(!session)return '';
  if(session.diving)return '§c급강하';
  const left=Math.max(0,session.until-system.currentTick);
  return '§a재사용: 급강하 §e'+(left/20).toFixed(1)+'초';
}
const bloodReserve=new Map();
export const bloodReserveOf=player=>bloodReserve.get(player.id)??0;
export const clearBloodReserve=id=>bloodReserve.delete(id);

export function gainBloodReserve(player,amount){
  if(Number.isFinite(amount)&&amount>0)bloodReserve.set(player.id,Math.min(100,bloodReserveOf(player)+amount));
}

export function spendBloodReserve(player){
  const amount=bloodReserveOf(player);
  if(amount<60)return false;
  bloodReserve.set(player.id,amount-60);
  return true;
}

export function creditBarrierBlock(player,damage){
  const shield=shieldSessions.get(player.id);
  if(!shield?.def.bloodReserve||system.currentTick>=shield.until||!Number.isFinite(damage)||damage<=0)return;
  const gain=Math.min(damage,40-(shield.bloodGained??0));
  shield.bloodGained=(shield.bloodGained??0)+gain;
  gainBloodReserve(player,gain);
}

export function isBloodedgePool(entity) {
  return entity?.typeId==='minecraft:player' && entity.hasTag?.(BLOODEDGE_POOL_TAG)===true;
}

export function isShieldFront(player,attacker) {
  if (!attacker || attacker.id===player.id || attacker.dimension.id!==player.dimension.id) return false;
  const victim=player.location,source=attacker.location,view=player.getViewDirection();
  const dx=source.x-victim.x,dz=source.z-victim.z;
  const length=Math.hypot(dx,dz),facing=Math.hypot(view.x,view.z);
  if (length<0.01 || facing<0.001) return false;
  return (dx*view.x+dz*view.z)/(length*facing)>=0.45;
}

export function blocksBloodedgeDamage(player,attacker) {
  const shield=shieldSessions.get(player?.id);
  return !!shield && system.currentTick < shield.until && shield.dimension===player.dimension.id &&
    isShieldFront(player,attacker);
}

export function catchCrimsonHit(player,attacker,damage) {
  if(!shieldSessions.get(player?.id)?.def.bloodReserve||!blocksBloodedgeDamage(player,attacker))return false;
  creditBarrierBlock(player,damage);
  return true;
}

export const plagueSessions=new Map();

export function activeBloodPlague(entity) {
  const mark=plagueSessions.get(entity?.id);
  return mark && mark.until>system.currentTick && mark.dimension===entity.dimension?.id ? mark : undefined;
}
