import {isRpgAdmin} from './adminPermissions.js';
import {sharesBuildingGroup} from './social.js';
import {world,system} from '@minecraft/server';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {showForm} from './skillMenu.js';
import {spawnRegion} from './spawnEffects.js';

export const LAND_DEED='rpg:land_deed';
export const LAND_SEIZURE='rpg:land_seizure';
export const LAND_KEY='rpg:town_land_v1';
const pending=new Set();
let registered=false, cachedLand;
const dim=id=>id?.replace(/^minecraft:/,'');
const chunkKey=(dimension,cx,cz)=>[dimension,cx,cz].join(':');
const chunkText=s=>s.dimension+' 청크 ['+s.cx+', '+s.cz+']';
const held=(p,id)=>p.getComponent('minecraft:inventory')?.container?.getItem(p.selectedSlotIndex)?.typeId===id;
const say=(p,result)=>p.sendMessage((result.ok?'§a':'§e')+result.message);

export function landSelection(source,region=spawnRegion()){
 const dimension=dim(source.dimension?.id), location=source.location;
 if(!dimension||!location||!Number.isFinite(location.x)||!Number.isFinite(location.z))return undefined;
 const cx=Math.floor(location.x/16),cz=Math.floor(location.z/16),x=cx*16,z=cz*16;
 const overlapsTown=region&&dimension===dim(region.dimId)&&
  x+16>region.x&&z+16>region.z&&x<region.x+region.size&&z<region.z+region.size;
 return {cx,cz,x,z,y:overlapsTown?region.y:undefined,dimension,key:chunkKey(dimension,cx,cz)};
}

function landStore(){
 const raw=world.getDynamicProperty(LAND_KEY);
 if(cachedLand&&cachedLand.raw===raw)return cachedLand;
 const records=raw===undefined?{}:JSON.parse(raw);
 if(!records||typeof records!=='object'||Array.isArray(records))throw Error('부동산 저장 데이터 오류');
 const chunks=new Map();
 for(const [storedKey,owner] of Object.entries(records)){
  const parts=storedKey.split(':');
  // Older deeds included the town's x, y, z and size before the chunk coordinates.
  const legacy=parts.length>=7;
  const dimension=dim(parts.slice(0,legacy?-6:-2).join(':'));
  const cx=Number(parts.at(-2)),cz=Number(parts.at(-1));
  if(!dimension||!Number.isSafeInteger(cx)||!Number.isSafeInteger(cz)||!owner?.id)continue;
  const key=chunkKey(dimension,cx,cz), previous=chunks.get(key);
  const entry=previous??{cx,cz,dimension,owner,storedKey,keys:[]};
  if(!previous||!legacy||previous.storedKey!==key){
   entry.owner=owner;
   entry.storedKey=storedKey;
  }
  entry.keys.push(storedKey);
  chunks.set(key,entry);
 }
 cachedLand={raw,records,chunks};
 return cachedLand;
}

export function landOwner(selection){return selection?landStore().chunks.get(selection.key)?.owner:undefined;}
export function ownsTownChunk(p,block,region=spawnRegion()){
 return !!p&&landOwner(landSelection(block,region))?.id===p.id;
}
export function hasLandAccess(player,owner){
 return !!player&&!!owner&&(owner.id===player.id||sharesBuildingGroup(player,owner));
}
export function canEditTownChunk(p,block,region=spawnRegion()){
 return hasLandAccess(p,landOwner(landSelection(block,region)));
}
function groundRule(selection){
 return selection.y===undefined?'소유자와 같은 길드·파티가 건축할 수 있습니다.':
  '소유자와 같은 길드·파티가 건축할 수 있습니다. 마을에 걸친 구역의 바닥 Y '+selection.y+'와 지하는 보호됩니다.';
}
function saveAdminChange(raw,records){
 const encoded=JSON.stringify(records);
 if(encoded.length>30000)return {ok:false,message:'부동산 저장 공간이 부족합니다.'};
 try{
  world.setDynamicProperty(LAND_KEY,encoded);
 }catch(error){
  try{world.setDynamicProperty(LAND_KEY,raw);}catch(restoreError){console.error('[RPG land rollback] '+restoreError);}
  return {ok:false,message:'토지 변경을 저장하지 못했습니다.'};
 }
 return {ok:true};
}

export function claimTownChunk(p,expectedKey){
 const selection=landSelection(p);
 if(!selection||expectedKey!==undefined&&selection.key!==expectedKey)return {ok:false,message:'청크가 변경됐습니다. 다시 선택하세요.'};
 const {raw,records,chunks}=landStore(),existing=chunks.get(selection.key)?.owner;
 if(existing)return {ok:false,message:'이미 구매한 청크입니다. 소유자 '+existing.name};
 const inv=p.getComponent('minecraft:inventory')?.container,slot=p.selectedSlotIndex,item=inv?.getItem(slot);
 if(item?.typeId!==LAND_DEED)return {ok:false,message:'부동산 구매권을 손에 들어 주세요.'};
 const original=item.clone();
 const encoded=JSON.stringify({...records,[selection.key]:{id:p.id,name:p.name}});
 if(encoded.length>30000)return {ok:false,message:'부동산 저장 공간이 부족합니다.'};
 try{
  if(item.amount===1)inv.setItem(slot,undefined);else{item.amount--;inv.setItem(slot,item);}
  world.setDynamicProperty(LAND_KEY,encoded);
 }catch(error){
  let restored=true;
  try{inv.setItem(slot,original);}catch{restored=false;}
  try{world.setDynamicProperty(LAND_KEY,raw);}catch{restored=false;}
  return {ok:false,message:restored?'구매 저장 실패로 구매권을 복구했습니다.':'구매 복구 실패. 관리자에게 문의하세요.'};
 }
 return {ok:true,message:chunkText(selection)+' 구매 완료. '+groundRule(selection)};
}
export async function useLandDeed(p){
 if(!p?.isValid||pending.has(p.id)||!held(p,LAND_DEED))return;
 pending.add(p.id);
 try{
  const selection=landSelection(p);
  if(!selection)return;
  const owner=landOwner(selection);
  if(owner){p.sendMessage('§e이미 구매한 청크입니다. 소유자 '+owner.name);return;}
  const answer=await showForm(new MessageFormData().title('부동산 구매')
   .body(chunkText(selection)+' 16×16을 구매할까요?\n구매권 1개 소비\n'+groundRule(selection))
   .button1('취소').button2('구매'),p);
  if(answer&&!answer.canceled&&answer.selection===1&&p.isValid)say(p,claimTownChunk(p,selection.key));
 }catch(error){p.sendMessage('§c[부동산] '+String(error));}
 finally{pending.delete(p.id);}
}

export function previewLand(p){
 const inv=p.getComponent('minecraft:inventory')?.container,item=inv?.getItem(p.selectedSlotIndex);
 const seizure=item?.typeId===LAND_SEIZURE;
 if(item?.typeId!==LAND_DEED&&(!seizure||!isRpgAdmin(p)))return;
 const selection=landSelection(p);if(!selection)return;
 const owner=landOwner(selection);
 const status=seizure?(owner?'소유자 '+owner.name+' · 사용해서 회수':'소유자 없음'):
  owner?'소유자 '+owner.name+(hasLandAccess(p,owner)?' · 수정 가능':' · 수정 불가'):'구매 가능 · 사용해서 구매';
 p.onScreenDisplay.setActionBar(chunkText(selection)+' · '+status);
 const height=Math.max(selection.y??p.location.y,p.location.y)+.15;
 for(let n=0;n<=16;n+=2)for(const at of [{x:selection.x+n,z:selection.z},{x:selection.x+n,z:selection.z+16},{x:selection.x,z:selection.z+n},{x:selection.x+16,z:selection.z+n}]){
  try{p.dimension.spawnParticle('minecraft:totem_particle',{...at,y:height});}catch{}
 }
}

export function administerTownLand(admin,target,expectedKey){
 if(!isRpgAdmin(admin))return {ok:false,message:'관리자만 토지를 지정할 수 있습니다.'};
 const selection=landSelection(admin);
 if(!selection||expectedKey!==undefined&&selection.key!==expectedKey)return {ok:false,message:'청크가 변경됐습니다. 다시 선택하세요.'};
 if(!target?.isValid||target.typeId!=='minecraft:player')return {ok:false,message:'토지를 지정할 플레이어가 접속해 있어야 합니다.'};
 const {raw,records,chunks}=landStore();
 if(chunks.has(selection.key))return {ok:false,message:'이미 소유자가 있습니다. 땅뺏기 아이템으로 소유권을 먼저 회수해 주세요.'};
 const result=saveAdminChange(raw,{...records,[selection.key]:{id:target.id,name:target.name}});
 return result.ok?{ok:true,message:chunkText(selection)+' · '+target.name+' 소유로 지정했습니다.'}:result;
}
export async function openAdminLand(admin,target){
 if(!isRpgAdmin(admin))return;
 const selection=landSelection(admin);if(!selection)return;
 const owner=landOwner(selection);
 if(owner){admin.sendMessage('§e'+chunkText(selection)+' · 소유자 '+owner.name+' · 회수하려면 땅뺏기 아이템을 사용하세요.');return;}
 const answer=await showForm(new MessageFormData().title('토지 소유자 지정')
  .body(chunkText(selection)+'\n'+target.name+'의 소유로 지정할까요?')
  .button1('취소').button2('지정'),admin);
 if(answer&&!answer.canceled&&answer.selection===1)say(admin,administerTownLand(admin,target,selection.key));
}
export async function inspectAdminLand(admin,target){
 if(!isRpgAdmin(admin))return;
 const selection=landSelection(admin),owner=landOwner(selection);
 const owned=[...landStore().chunks.values()].filter(entry=>entry.owner.id===target.id);
 const pageSize=10;
 for(let offset=0;isRpgAdmin(admin);){
  const page=owned.slice(offset,offset+pageSize);
  const text=target.name+' 소유 청크 '+owned.length+'개\n'+page.map(entry=>chunkText(entry)+' (X '+entry.cx*16+', Z '+entry.cz*16+')').join('\n');
  const form=new ActionFormData().title('부동산 소유자 조회')
   .body((selection?chunkText(selection)+' · 소유자 '+(owner?.name??'없음')+'\n\n':'')+text);
  const hasPrev=offset>0,hasNext=offset+pageSize<owned.length;
  if(hasPrev)form.button('이전');
  if(hasNext)form.button('다음');
  form.button('닫기');
  const answer=await showForm(form,admin);
  if(!answer||answer.canceled)return;
  if(hasPrev&&answer.selection===0)offset-=pageSize;
  else if(hasNext&&answer.selection===Number(hasPrev))offset+=pageSize;
  else return;
 }
}

export async function useLandSeizure(admin){
 if(!admin?.isValid||pending.has(admin.id))return;
 if(!isRpgAdmin(admin)){admin.sendMessage('§c관리자만 땅뺏기 아이템을 사용할 수 있습니다.');return;}
 if(!held(admin,LAND_SEIZURE))return;
 pending.add(admin.id);
 try{
  const selection=landSelection(admin),owner=landOwner(selection);
  if(!owner){admin.sendMessage('§e이 청크는 소유자가 없습니다.');return;}
  const answer=await showForm(new MessageFormData().title('토지 회수 확인')
   .body(chunkText(selection)+'\n'+owner.name+'의 소유권을 회수할까요?\n건축물은 그대로 유지되며 청크는 다시 구매할 수 있습니다.')
   .button1('취소').button2('회수'),admin);
  if(!answer||answer.canceled||answer.selection!==1||!admin.isValid)return;
  if(!isRpgAdmin(admin)||!held(admin,LAND_SEIZURE)){
   admin.sendMessage('§e관리자 권한과 손에 든 땅뺏기 아이템을 확인하세요.');
   return;
  }
  const current=landSelection(admin),{raw,records,chunks}=landStore(),entry=chunks.get(selection.key);
  if(current?.key!==selection.key||entry?.owner.id!==owner.id){
   admin.sendMessage('§e청크나 소유자가 변경됐습니다. 다시 선택하세요.');
   return;
  }
  const updated={...records};
  for(const key of entry.keys)delete updated[key];
  const result=saveAdminChange(raw,updated);
  say(admin,result.ok?{ok:true,message:chunkText(selection)+' · '+owner.name+'의 소유권을 회수했습니다.'}:result);
 }catch(error){admin.sendMessage('§c[부동산] '+String(error));}
 finally{pending.delete(admin.id);}
}

system.beforeEvents.startup.subscribe(e=>{
 for(const [id,use] of [[LAND_DEED,useLandDeed],[LAND_SEIZURE,useLandSeizure]]){
  try{e.itemComponentRegistry.registerCustomComponent(id,{onUse(ev){system.run(()=>use(ev.source));}});}
  catch(error){console.warn('[RPG land component] '+error);}
 }
});
export function registerRealEstate(){
 if(registered)return;
 registered=true;
 system.runInterval(()=>{for(const p of world.getAllPlayers())try{previewLand(p);}catch(error){console.warn('[RPG land preview] '+error);}},10);
 world.afterEvents.playerLeave.subscribe(e=>pending.delete(e.playerId));
}
