import {armorAttributeLines} from '../data/equipment.js';
import {ARMOR_PROTECTION_LEVEL,upgradeLevel} from '../data/upgrades.js';
import {world,system,EquipmentSlot} from '@minecraft/server';
import {classWeapon} from '../data/classWeapons.js';
import {RARITY_KEY,itemGrade} from '../data/grades.js';
import {itemRarity,rarityBadge} from '../data/rarity.js';
const KEY='rpg:last_grade_label',PROTECTION_LINE='§b강화 보호 · 피격 내구도 소모 없음';let registered=false;
export function decorateRarity(item){
 const jobWeapon=classWeapon(item?.typeId);
 let changed=false;
 const oldName=item?.typeId==='rpg:bloodedge_scythe'?item.getDynamicProperty('rpg:class_upgrade_label'):undefined;
 if(typeof oldName==='string'&&oldName.startsWith('블러드엣지의 피의 낫')&&item.nameTag===oldName){
  const level=upgradeLevel(item,'weapon');
  item.nameTag=jobWeapon.name+(level?' +'+level:'');
  item.setDynamicProperty('rpg:class_upgrade_label',item.nameTag);
  changed=true;
 }
 const assigned=jobWeapon&&item.getDynamicProperty(RARITY_KEY)!==undefined;
 const info=itemRarity(item)??(assigned&&{...jobWeapon,rank:itemGrade(item),kind:'weapon'});if(!info)return changed;
 const level=upgradeLevel(item,info.kind),label=rarityBadge(info.rank)+' '+info.name+(level?' +'+level:''),line='§8등급: '+rarityBadge(info.rank);
 const attributes=armorAttributeLines(item.typeId);
 const protectedArmor=info.kind==='armor'&&level>=ARMOR_PROTECTION_LEVEL;
 const old=item.getLore(),lore=[line,...attributes,...(protectedArmor?[PROTECTION_LINE]:[]),
  ...old.filter(s=>!s.startsWith('§8등급:')&&!attributes.includes(s)&&s!==PROTECTION_LINE)];
 if(JSON.stringify(lore)!==JSON.stringify(old)){item.setLore(lore);changed=true;}
 const managed=info.kind==='rune'?undefined:item.getDynamicProperty(KEY);
 if(!item.nameTag||item.nameTag===managed||(assigned&&item.nameTag===item.getDynamicProperty('rpg:class_upgrade_label'))){if(item.nameTag!==label){item.nameTag=label;if(info.kind!=='rune')item.setDynamicProperty(KEY,label);changed=true;}}
 return changed;
}
export function refreshRarityLabels(p){
 try{const inv=p.getComponent('minecraft:inventory')?.container;if(inv)for(let i=0;i<inv.size;i++){const item=inv.getItem(i);if(item&&decorateRarity(item))inv.setItem(i,item);}
 const eq=p.getComponent('minecraft:equippable');if(eq)for(const slot of [EquipmentSlot.Mainhand,EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet]){const item=eq.getEquipment(slot);if(item&&decorateRarity(item))eq.setEquipment(slot,item);}}catch{}
}
export function registerRarityLabels(){if(registered)return;registered=true;system.runInterval(()=>{for(const p of world.getAllPlayers())refreshRarityLabels(p);},100);world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{if(ev.player?.isValid)refreshRarityLabels(ev.player);},20));}
