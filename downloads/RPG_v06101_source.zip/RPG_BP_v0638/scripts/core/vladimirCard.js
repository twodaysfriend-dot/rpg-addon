import { EquipmentSlot } from '@minecraft/server';

export const VLADIMIR_CARD = 'rpg:vladimir_job_card';

export function hasVladimirCard(player) {
  try {
    return player.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand)?.typeId === VLADIMIR_CARD;
  } catch {
    return false;
  }
}
