import {world,system} from '@minecraft/server';
import {spawnRegion,insideSpawn} from './spawnEffects.js';
export const TOWN_VILLAGER_TAG='rpg_town_villager_protected';
export const VILLAGER_TYPES=Object.freeze(['minecraft:villager','minecraft:villager_v2']);
export function isTownVillager(entity){return VILLAGER_TYPES.includes(entity?.typeId)&&insideSpawn(entity,spawnRegion());}
function playerSource(source,seen=new Set()){
 if(!source||seen.has(source.id))return false;if(source.typeId==='minecraft:player')return true;seen.add(source.id);
 try{if(playerSource(source.getComponent?.('minecraft:projectile')?.owner,seen))return true;}catch{}
 try{if(source.getComponent?.('minecraft:tameable')?.tamedToPlayerId)return true;}catch{}
 try{if(source.getDynamicProperty?.('rpg:necro_owner'))return true;}catch{}
 return false;
}
export function blockTownVillagerDamage(target,source){return isTownVillager(target)&&playerSource(source);}
export function syncTownVillager(entity){
 if(!VILLAGER_TYPES.includes(entity?.typeId))return;
 if(isTownVillager(entity)){if(!entity.hasTag(TOWN_VILLAGER_TAG))entity.addTag(TOWN_VILLAGER_TAG);}
 else if(entity.hasTag(TOWN_VILLAGER_TAG))entity.removeTag(TOWN_VILLAGER_TAG);
}
export function tickTownVillagers(){
 for(const id of ['overworld','nether','the_end'])try{for(const e of world.getDimension(id).getEntities({families:['villager']}))syncTownVillager(e);}catch{}
}
let registered=false;
export function registerTownVillagers(){
 if(registered)return;registered=true;
 world.afterEvents.entitySpawn.subscribe(e=>{try{syncTownVillager(e.entity);}catch{}});
 world.afterEvents.entityLoad?.subscribe(e=>{try{syncTownVillager(e.entity);}catch{}});
 system.runInterval(tickTownVillagers,1);system.run(tickTownVillagers);
 // Newer engines may offer pre-hurt cancellation; native damage sensors cover stable 2.2.
 world.beforeEvents?.entityHurt?.subscribe(ev=>{try{if(blockTownVillagerDamage(ev.hurtEntity,ev.damageSource?.damagingEntity??ev.damageSource?.damagingProjectile))ev.cancel=true;}catch{}});
}
