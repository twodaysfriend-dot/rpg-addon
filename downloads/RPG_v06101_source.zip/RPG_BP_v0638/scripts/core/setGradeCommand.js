import * as mc from '@minecraft/server';
import { runSetGrade } from './setGrade.js';

let subscribed = false;
export function registerSetGradeCommand() {
  if (subscribed) return;
  subscribed = true;
  mc.system.beforeEvents.startup.subscribe(({customCommandRegistry}) => {
    const levels = [mc.CommandPermissionLevel, mc.CustomCommandPermissionLevel]
      .find(level => level?.GameDirectors !== undefined);
    const types = mc.CustomCommandParamType;
    const status = mc.CustomCommandStatus;
    if (!customCommandRegistry || !levels || !types || !status) return;

    try {
      customCommandRegistry.registerCommand({
        name: 'rpg:setgrade',
        description: '관리자: 장비 또는 룬 등급 지정',
        permissionLevel: levels.GameDirectors,
        cheatsRequired: false,
        mandatoryParameters: [{name: 'grade', type: types.String}],
        optionalParameters: [{name: 'target', type: types.String}, {name: 'slot', type: types.Integer}],
      }, (origin, ...args) => {
        const player = origin.sourceEntity ?? origin.initiator;
        if (player?.typeId !== 'minecraft:player') {
          return {status: status.Failure, message: '플레이어만 사용할 수 있습니다.'};
        }
        const values = Array.isArray(args[0]) ? args[0] : args;
        const text = values.filter(value => value != null).join(' ');
        mc.system.run(() => runSetGrade(player, text));
        return {status: status.Success};
      });
    } catch (error) {
      console.warn('[RPG] /rpg:setgrade 등록 실패: ' + String(error));
    }
  });
}
