import * as mc from '@minecraft/server';
import {createPrison,releasePrisoner,resetPrisonHistory,showPrisonStatus} from './prison.js';

const commands = [
  {name:'jail',description:'내 PK 스택과 남은 형기'},
  {name:'jailcreate',description:'관리자: 감옥 10칸 생성',admin:true,arg:'height',type:'Integer',optional:true},
  {name:'jailreset',description:'관리자: 본인 또는 지정한 플레이어의 PK 스택·수감 배율 초기화',admin:true,arg:'player',type:'String',optional:true},
  {name:'jailstatus',description:'관리자: 감옥과 수감자 상태',admin:true,arg:'player',type:'String',optional:true},
  {name:'jailrelease',description:'관리자: 수감자 석방',admin:true,arg:'player',type:'String'},
];

export function runPrisonCommand(name,player,arg=''){
  try{
    switch(name){
      case 'jail': return showPrisonStatus(player);
      case 'jailcreate': return createPrison(player,arg);
      case 'jailreset': return resetPrisonHistory(player,arg);
      case 'jailstatus': return showPrisonStatus(player,arg,true);
      case 'jailrelease': return releasePrisoner(player,arg);
    }
  }catch(error){
    try{player.sendMessage('§c[감옥] '+String(error?.message??error));}catch{}
    return false;
  }
}

let subscribed=false;
export function registerPrisonCommands(){
  if(subscribed)return;
  subscribed=true;
  mc.system.beforeEvents.startup.subscribe(event=>{
    const registry=event.customCommandRegistry;
    const levels=[mc.CommandPermissionLevel,mc.CustomCommandPermissionLevel]
      .find(value=>value?.Any!==undefined&&value.GameDirectors!==undefined);
    const types=mc.CustomCommandParamType,status=mc.CustomCommandStatus;
    if(!registry||!levels||!types||!status){console.warn('[RPG prison] 커스텀 명령어 API를 사용할 수 없습니다.');return;}
    for(const {name,description,admin,arg,type,optional} of commands){
      const def={name:'rpg:'+name,description,permissionLevel:admin?levels.GameDirectors:levels.Any,cheatsRequired:false};
      if(arg)def[optional?'optionalParameters':'mandatoryParameters']=[{name:arg,type:types[type]}];
      try{
        registry.registerCommand(def,(origin,...args)=>{
          const player=origin.sourceEntity??origin.initiator;
          if(player?.typeId!=='minecraft:player')return {status:status.Failure,message:'플레이어만 사용할 수 있습니다.'};
          const raw=Array.isArray(args[0])?args[0][0]:args[0];
          mc.system.run(()=>runPrisonCommand(name,player,raw));
          return {status:status.Success};
        });
      }catch(error){console.warn('[RPG prison] '+def.name+' 등록 실패: '+String(error));}
    }
  });
}
