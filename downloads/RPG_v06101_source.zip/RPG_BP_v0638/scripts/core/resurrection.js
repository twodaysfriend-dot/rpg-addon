import {isChameleonJob} from '../data/jobs.js';
import {world,system} from '@minecraft/server';
import {getJobId,getSkills} from './playerData.js';
import {areAllies} from './social.js';
import {pvpOwner,resurrectionPvpBlocked} from './pvp.js';
const KEY='rpg:resurrection_mark_v1';
export const RESURRECTION_ARMED='rpg:resurrection_armed';
export const RESURRECTION_PENDING='rpg:resurrection_pending';
const marks=new Map();let registered=false;
const alive=p=>{try{return p?.isValid&&p.typeId==='minecraft:player'&&p.getComponent('minecraft:health')?.currentValue>0;}catch{return false;}};
const casterAllowed=p=>getJobId(p)==='michael'||(isChameleonJob(getJobId(p))&&getSkills(p).includes('michael_resurrection'));
const properties=(p,armed,pending=false)=>{p.setProperty(RESURRECTION_ARMED,armed);p.setProperty(RESURRECTION_PENDING,pending);};
function clear(id){const s=marks.get(id);marks.delete(id);if(!s)return;try{properties(s.target,false);s.target.setDynamicProperty(KEY,undefined);}catch{}}
function eligible(s){return alive(s.caster)&&alive(s.target)&&casterAllowed(s.caster)&&s.caster.dimension.id===s.target.dimension.id&&areAllies(s.caster,s.target);}
export function markResurrection(caster,target){
 if(!alive(caster)||!alive(target)||caster.id===target.id||!casterAllowed(caster)||!areAllies(caster,target)||caster.dimension.id!==target.dimension.id)return false;
 if(resurrectionPvpBlocked(caster)||resurrectionPvpBlocked(target))return false;
 if(Math.hypot(caster.location.x-target.location.x,caster.location.y-target.location.y,caster.location.z-target.location.z)>6)return false;
 for(const [id,s]of marks)if(!eligible(s))clear(id);
 if(marks.has(target.id)||[...marks.values()].filter(s=>s.caster.id===caster.id).length>=2)return false;
 // Validate native property support before registering/spending the skill cost.
 try{properties(target,true);target.setDynamicProperty(KEY,JSON.stringify({version:1,caster:caster.id}));}
 catch{try{properties(target,false);}catch{}return false;}
 marks.set(target.id,{caster,target});return true;
}
function consume(s){
 const target=s.target;
 // Consume first: recursive/direct damage or duplicate native notifications cannot reuse it.
 clear(target.id);
 const hp=target.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return false;
 hp.setCurrentValue(hp.effectiveMax);
 try{target.dimension.spawnParticle('rpg:resurrection_mark',{...target.location,y:target.location.y+1.5});target.dimension.playSound('random.totem',target.location,{volume:1,pitch:1.2});target.sendMessage('§e리저렉션: 표식을 소모하고 부활했습니다.');}catch{}
 return true;
}
export function tryResurrection(target,source,nextHealth){
 const s=marks.get(target?.id);if(!s||nextHealth>0||!eligible(s)||resurrectionPvpBlocked(target)||resurrectionPvpBlocked(s.caster))return false;
 const owner=pvpOwner(source);if(owner?.typeId==='minecraft:player')return false;
 try{if(source?.hasTag?.('rpg_player_owned')||source?.getDynamicProperty?.('rpg:necro_owner')||source?.getComponent?.('minecraft:tameable')?.tamedToPlayerId)return false;}catch{return false;}
 return consume(s);
}
export function tickResurrection(){
 // Property changes are applied by the engine on a tick boundary. Clear orphaned
 // flags even if a queued native event arrives after the runtime mark was consumed.
 for(const p of world.getAllPlayers())if(!marks.has(p.id))try{if(p.getProperty(RESURRECTION_ARMED)||p.getProperty(RESURRECTION_PENDING))properties(p,false);}catch{}
 for(const [id,s]of marks){
  try{
   if(!eligible(s)){clear(id);continue;}
   const p=s.target,blocked=resurrectionPvpBlocked(p)||resurrectionPvpBlocked(s.caster);
   if(p.getProperty(RESURRECTION_PENDING)===true){if(!blocked)consume(s);else properties(p,false);continue;}
   p.setProperty(RESURRECTION_ARMED,!blocked);
   if(!blocked&&system.currentTick%4===0)p.dimension.spawnParticle('rpg:resurrection_mark',{x:p.location.x,y:p.location.y+2.5,z:p.location.z});
  }catch{clear(id);}
 }
}
export function registerResurrection(){
 if(registered)return;registered=true;
 // Runtime marks are deliberately cleared on reconnect/restart; stale native flags must not grant immunity.
 const reset=p=>{try{properties(p,false);p.setDynamicProperty(KEY,undefined);}catch{}};
 system.run(()=>{for(const p of world.getAllPlayers())reset(p);});
 world.afterEvents.playerSpawn.subscribe(ev=>{clear(ev.player.id);reset(ev.player);});
 world.afterEvents.playerLeave.subscribe(ev=>{for(const [id,s]of marks)if(id===ev.playerId||s.caster.id===ev.playerId)clear(id);});
 world.afterEvents.entityDie.subscribe(ev=>{for(const [id,s]of marks)if(id===ev.deadEntity?.id||s.caster.id===ev.deadEntity?.id)clear(id);});
 system.runInterval(tickResurrection,1);
 // Native sensor excludes player-owned projectiles/summons, including owner binding set after spawn.
 const waiting=new Map();
 const inspect=e=>{try{if(e?.typeId==='minecraft:player')return;const owner=pvpOwner(e);if(owner?.typeId==='minecraft:player'){e.addTag('rpg_player_owned');return;}waiting.set(e.id,{e,until:system.currentTick+8});}catch{}};
 system.run(()=>{for(const id of ['overworld','nether','the_end'])try{for(const e of world.getDimension(id).getEntities())inspect(e);}catch{}});
 world.afterEvents.entitySpawn.subscribe(ev=>inspect(ev.entity));
 world.afterEvents.entityLoad?.subscribe(ev=>inspect(ev.entity));
 system.runInterval(()=>{for(const [id,s]of waiting){try{if(!s.e.isValid||system.currentTick>s.until){waiting.delete(id);continue;}if(pvpOwner(s.e)?.typeId==='minecraft:player'){s.e.addTag('rpg_player_owned');waiting.delete(id);}}catch{waiting.delete(id);}}},1);
}
