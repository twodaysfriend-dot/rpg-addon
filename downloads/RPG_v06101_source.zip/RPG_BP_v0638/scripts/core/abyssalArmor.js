import {world,system,EquipmentSlot} from '@minecraft/server';
import {ARMOR_SETS,ARMOR_PARTS,armorInfo} from '../data/equipment.js';

// Bedrock caps native armor at 20 and has no Java armor-toughness attribute.
// Preserve native armor/enchantments; supplement only overflow armor and toughness.
export const ABYSSAL_PROFILE_PREFIX='rpg_abyssal_';
export const ABYSSAL_PROFILES=Object.freeze([
  {count:0,overflow:0},
  ...[1,2,3].flatMap(count=>Array.from({length:count*2+1},(_,overflow)=>({count,overflow}))),
  {count:4,overflow:8},
]);
const SLOTS=[EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet];
const VANILLA={leather:[1,3,2,1],golden:[2,5,3,1],chainmail:[2,5,4,1],iron:[2,6,5,2],diamond:[3,8,6,3],netherite:[3,8,6,3],turtle:[2,0,0,0]};
const APPLIED='rpg:abyssal_armor_applied_v1';
let registered=false;
export function abyssalArmorStats(player){
  const empty={count:0,armor:0,overflow:0,toughness:0,knockbackResistance:0,multiplier:1,profile:0};
  if(player?.typeId!=='minecraft:player')return empty;
  const eq=player.getComponent('minecraft:equippable');if(!eq)return empty;
  let count=0,armor=0;
  for(let i=0;i<SLOTS.length;i++){
    const item=eq.getEquipment(SLOTS[i]),info=armorInfo(item?.typeId);
    if(info?.part===ARMOR_PARTS[i]){
      armor+=info.protection[i];if(info.set==='abyssal')count++;
    }else if(item?.typeId?.startsWith('minecraft:')){
      const material=item.typeId.slice(10).replace('_'+ARMOR_PARTS[i],'');
      armor+=(VANILLA[material]?.[i]??0);
    }
  }
  const overflow=count?Math.min(count*2,Math.max(0,armor-20)):0;
  const toughness=count*ARMOR_SETS.abyssal.toughness;
  const knockbackResistance=count*ARMOR_SETS.abyssal.knockbackResistance;
  return {count,armor,overflow,toughness,knockbackResistance,
    multiplier:(1-overflow*.04)*(1-toughness*.01),profile:count*9+overflow};
}
export function abyssalDamageMultiplier(player){return abyssalArmorStats(player).multiplier;}
export function armorKnockbackScale(player){return 1-abyssalArmorStats(player).knockbackResistance*.1;}
export function syncAbyssalArmor(player,force=false){
  const stats=abyssalArmorStats(player);
  if(!force&&player.getDynamicProperty(APPLIED)===stats.profile&&player.hasTag('rpg_abyssal_active')===(stats.count>0)&&(!stats.count||player.hasTag(ABYSSAL_PROFILE_PREFIX+stats.profile)))return stats;
  for(const {count,overflow} of ABYSSAL_PROFILES){
    if(!count)continue;
    const tag=ABYSSAL_PROFILE_PREFIX+(count*9+overflow);
    if(count*9+overflow===stats.profile)player.addTag(tag);else player.removeTag(tag);
  }
  if(stats.count)player.addTag('rpg_abyssal_active');else player.removeTag('rpg_abyssal_active');
  player.triggerEvent('rpg:abyssal_knockback_'+stats.count);
  player.setDynamicProperty(APPLIED,stats.profile);
  return stats;
}
export function registerAbyssalArmor(){
  if(registered)return;registered=true;
  system.run(()=>{for(const p of world.getAllPlayers())syncAbyssalArmor(p,true);});
  world.afterEvents.playerSpawn.subscribe(({player})=>system.run(()=>syncAbyssalArmor(player,true)));
  // Re-read equipment after swaps/breakage; only mutate tags/components on a change.
  system.runInterval(()=>{for(const p of world.getAllPlayers())try{syncAbyssalArmor(p,system.currentTick%20===0);}catch(error){console.warn('[RPG armor] '+error);}},1);
}
