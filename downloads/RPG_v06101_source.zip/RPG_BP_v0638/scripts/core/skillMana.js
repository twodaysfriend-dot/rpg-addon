import { getJobId } from './playerData.js';
import { manaCostFor } from './stats.js';
import { hasDirectSkillPower, POWER_FIELDS, scaleSkillPower } from '../data/skillPower.js';

const KEY = 'rpg:skill_mana_settings';
export const MAX_SKILL_MANA_MULTIPLIER = 10;
const damageFields = new Set([
  ...[...POWER_FIELDS].filter(field => !field.startsWith('heal')),
  'bindBonus', 'burstRatio', 'reflect', 'nextMeleeMultiplier', 'beastNextMeleeMultiplier', 'beastDamage', 'beastLandingDamage',
]);
const sunSlashFields = new Set(['damageMultiplier']);
const holyDamageSkills = new Set(['holy_heal', 'angel_bless', 'angel_zone']);
const valid = value => Number.isInteger(value) && value >= 1 && value <= MAX_SKILL_MANA_MULTIPLIER;

function settings(player) {
  try {
    const raw = player.getDynamicProperty(KEY);
    if (typeof raw !== 'string') return {};
    const state = JSON.parse(raw);
    if (state && typeof state === 'object' && !Array.isArray(state)) return state;
  } catch {}
  return {};
}

export function canBoostSkillMana(def) {
  return def?.mana > 0 && (holyDamageSkills.has(def.id) || def.id === 'sun_slash' ||
    hasDirectSkillPower(def, damageFields) || hasDirectSkillPower(def.bloodBoost, damageFields));
}

export function skillManaSetting(player, id, job = getJobId(player)) {
  const value = settings(player)[job]?.[id ?? 'default'];
  return valid(value) ? value : id ? 0 : 1;
}

export function setSkillManaSetting(player, id, value, job = getJobId(player)) {
  if (!valid(value) && !(id && value === 0)) return false;
  const state = settings(player);
  const current = { ...state[job] };
  if ((id && value === 0) || (!id && value === 1)) delete current[id ?? 'default'];
  else current[id ?? 'default'] = value;
  if (Object.keys(current).length) state[job] = current;
  else delete state[job];
  player.setDynamicProperty(KEY, Object.keys(state).length ? JSON.stringify(state) : undefined);
  return true;
}

export function skillManaMultiplier(player, def, job = getJobId(player)) {
  const current = settings(player)[job];
  if (!current || !canBoostSkillMana(def)) return 1;
  if (valid(current?.[def.id])) return current[def.id];
  return valid(current?.default) ? current.default : 1;
}

export const manaDamageMultiplier = multiplier => (9 + multiplier) / 10;

export function skillManaCost(player, def, multiplier = skillManaMultiplier(player, def)) {
  const base = def.fixedMana || def.id === 'michael_resurrection' ? def.mana : manaCostFor(player, def.mana);
  return (def.id === 'world_stop' ? Math.max(300, base) : base) * multiplier;
}

export function manaBoostedDefinition(def, multiplier) {
  if (multiplier === 1) return def;
  const damage = manaDamageMultiplier(multiplier);
  const next = scaleSkillPower(def, damage, def.id === 'sun_slash' ? sunSlashFields : damageFields);
  if (def.bloodBoost) next.bloodBoost = scaleSkillPower(def.bloodBoost, damage, damageFields);
  if (holyDamageSkills.has(def.id)) next.manaDamageMultiplier = damage;
  return next;
}
