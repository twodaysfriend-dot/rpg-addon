// Raid species must survive generic cave, town, peace and night cleanup.
// Entity spawn causes do not reliably distinguish raid waves from natural spawns.
const RAID_TYPES=new Set(['minecraft:pillager','minecraft:vindicator','minecraft:evocation_illager','minecraft:evoker','minecraft:ravager','minecraft:witch','minecraft:vex']);
export function isRaidMob(e){return RAID_TYPES.has(e?.typeId);}
export const CHAMELEON_CONDITIONS_HIDDEN='카멜레온은 다른 직업의 전직 조건을 조회할 수 없습니다.';
