import {world,system,BlockPermutation} from '@minecraft/server';
import {CITY_SIZE,CITY_TILES,CITY_SPAWN,cityTile,makeFantasyCityPlan,tileOperations,CITY_TRAINERS} from '../data/fantasyCity.js';
import {setSpawnRegion} from './spawnEffects.js';
export const CITY_KEY='rpg:fantasy_city_v1';
const AREA='rpg_city_build_v1',BUDGET=256,TOTAL=CITY_TILES*CITY_TILES;
const TERRAIN=new Set(['minecraft:grass_block','minecraft:dirt','minecraft:podzol','minecraft:mycelium','minecraft:sand','minecraft:red_sand','minecraft:gravel','minecraft:snow_layer']);
let state,loadedTile=-1,wait=0,survey=0,ops,registered=false,lastNotice=-1;
const permutations=new Map(),city=makeFantasyCityPlan(),dim=()=>world.getDimension('overworld');
function read(){
 const value=world.getDynamicProperty(CITY_KEY);if(!value)return;
 const s=JSON.parse(value);
 // Retired designs are never resumed or used to alter existing world blocks.
 if(s.version===1)return;
 if(s.version===2&&['trim','decorate'].includes(s.phase))s.phase='done';
 if(s.version===2&&s.designRevision!==2&&s.phase!=='done'){s.phase='paused_legacy';s.manualPause=true;}

 if(s.version!==2||s.size!==250||![s.x,s.y,s.z].every(Number.isSafeInteger)||s.y< -62||s.y>286||!Number.isInteger(s.op)||s.op<0||!Number.isInteger(s.offset)||s.offset<0||!Number.isInteger(s.tile)||s.tile<0||s.tile>TOTAL||!['survey','build','npcs','done','paused_legacy'].includes(s.phase))throw Error('도시 저장 정보가 잘못되었습니다.');return s;
}
function permutationFor(op){const key=op.type+JSON.stringify(op.states??{});let p=permutations.get(key);if(!p){p=BlockPermutation.resolve(op.type,op.states);permutations.set(key,p);}return p;}
function save(){world.setDynamicProperty(CITY_KEY,JSON.stringify(state));}
function tell(message){const p=world.getAllPlayers().find(p=>p.id===state?.owner);if(p)p.sendMessage(message);}
function release(){try{dim().runCommand('tickingarea remove '+AREA);}catch{}loadedTile=-1;ops=undefined;survey=0;wait=0;}
function retry(reason){const different=state.error!==reason;state.error=reason;state.retryUntil=Date.now()+5000;save();release();if(different)tell('§e[성곽 마을] '+reason+'\n§75초 뒤 자동으로 다시 시도합니다. 재개 명령어는 필요하지 않습니다.');}
function at(x,y,z){return {x:state.x+x,y:state.y+y,z:state.z+z};}
function ensureBox(key,box){
 if(loadedTile!==key){release();const r=dim().runCommand(`tickingarea add ${box.x} ${box.y} ${box.z} ${box.x2} ${box.y} ${box.z2} ${AREA} true`);if(r?.successCount===0)throw Error('임시 청크 영역 여유가 없습니다.');loadedTile=key;wait=12;return false;}
 if(wait>0){wait--;return false;}
 try{for(const x of [box.x,box.x2])for(const z of [box.z,box.z2])if(!dim().getBlock({x,y:box.y,z}))throw Error('unloaded');}catch{if(++state.retries<120){wait=2;return false;}throw Error('지역 청크 로딩을 기다리고 있습니다.');}state.retries=0;state.error=undefined;return true;
}
function ensureLoaded(tileIndex){const t=cityTile(tileIndex);return ensureBox('new_'+tileIndex,{x:state.x+t.x,z:state.z+t.z,x2:state.x+t.x2,z2:state.z+t.z2,y:state.y});}
function complete(){const spawn=at(CITY_SPAWN.x,CITY_SPAWN.y,CITY_SPAWN.z);state.phase='done';state.tile=TOTAL;state.error=undefined;save();setSpawnRegion(state);release();tell(`§a250×250 성곽 마을 완성 · 월드 스폰 지정 완료\n§e이동: /tp @s ${spawn.x} ${spawn.y} ${spawn.z}`);}

function nextTile(){state.tile++;state.op=0;state.offset=0;save();release();}
function progress(){const n=Math.floor(state.tile/TOTAL*100);if(n!==lastNotice&&n%25===0){lastNotice=n;tell('§b[250×250 마을] '+(state.phase==='survey'?'공간 검사':'건축')+' '+n+'%');}}
export function cityStatus(p){const s=state??read();if(!s){p.sendMessage('§7/rpg:citycreate 로 현재 위치 중심에 250×250 마을을 생성하세요.');return;}p.sendMessage(`§b250×250 마을: ${({survey:'공간 검사',build:'건축 중',npcs:'전직관 배치',done:'완료',paused_legacy:'이전 버전의 중단된 작업'})[s.phase]}${s.manualPause?' (중지)':''}\n§7${s.tile}/${TOTAL}구역 · 중심 ${s.x+125}, ${s.z+125} · 바닥 Y=${s.y}${s.error?'\n§e'+s.error+' (자동 재시도)':''}`);}

export function createFantasyCity(p,height){
 const previous=state??read();
 if(previous&&previous.phase!=='done'&&previous.phase!=='survey'&&previous.phase!=='paused_legacy'){state=previous;if(previous.manualPause)resumeFantasyCity(p);else p.sendMessage('§a기존 마을을 자동으로 생성 중입니다. /rpg:citystatus 로 진행도를 확인하세요.');return false;}
 if(!['minecraft:overworld','overworld'].includes(p.dimension.id)){p.sendMessage('§e오버월드에서 실행하세요.');return false;}
 const automatic=height===''||height===undefined,y=automatic?Math.floor(p.location.y)-1:Number(height);
 if(!Number.isInteger(y)||y< -62||y>286){p.sendMessage('§e바닥 높이는 -62~286입니다. 예: /rpg:citycreate 200');return false;}
 release();state={version:2,designRevision:2,size:250,x:Math.floor(p.location.x)-125,z:Math.floor(p.location.z)-125,y,owner:p.id,phase:'survey',tile:0,op:0,offset:0,manualPause:false,retries:0,automatic,maxTop:-64};setSpawnRegion(state);save();
 p.sendMessage(`§a현재 좌표 중심 250×250 판타지 성곽 마을 생성 시작 · 건물 ${city.houses}동\n§7중심 X/Z: ${state.x+125}, ${state.z+125}. ${automatic?'높이는 지형·건물을 피해 자동 조정합니다.':'지정 바닥 Y='+y}\n§7검사·건축은 자동으로 진행하고 월드 재시작 후에도 이어집니다.`);return true;
}
export function stopFantasyCity(p){state=state??read();if(!state||state.phase==='done'){cityStatus(p);return;}state.manualPause=true;save();release();p.sendMessage('§e관리자 요청으로 마을 생성을 중지했습니다.');}
export function resumeFantasyCity(p){state=state??read();if(!state||state.phase==='done'){cityStatus(p);return false;}if(state.phase==='paused_legacy'){p.sendMessage('§e이전 버전의 중단된 작업은 재개하지 않습니다. /rpg:citycreate 로 새 위치에서 마을을 생성하세요.');return false;}state.owner=p.id;state.manualPause=false;state.error=undefined;state.retryUntil=0;state.retries=0;save();release();p.sendMessage('§a저장된 위치부터 생성을 진행합니다.');return true;}
export function tickFantasyCity(){
 if(!state||state.manualPause||state.phase==='done'||Date.now()<(state.retryUntil??0)||!world.getAllPlayers().length)return;
 try{
  if(state.phase==='survey'){
   if(state.tile>=TOTAL){
    if(state.automatic&&state.maxTop>state.y){const y=state.maxTop+1;if(y>286)throw Error('주변 지형이 너무 높습니다. 다른 위치에서 마을을 생성하세요.');state.y=y;setSpawnRegion(state);tell('§7기존 지형을 보존하기 위해 마을 바닥을 Y='+y+'로 조정했습니다.');}
    state.phase='build';state.tile=0;save();release();lastNotice=-1;tell('§a검사 완료. 250×250 마을 건축을 시작합니다.');return;
   }
   if(!ensureLoaded(state.tile))return;const t=cityTile(state.tile),width=t.x2-t.x+1,count=width*(t.z2-t.z+1);
   for(let n=0;n<BUDGET&&survey<count;n++,survey++){const x=state.x+t.x+survey%width,z=state.z+t.z+Math.floor(survey/width),top=dim().getTopmostBlock({x,z});if(top){state.maxTop=Math.max(state.maxTop,top.location.y);if(!state.automatic&&top.location.y>state.y)throw Error(`지정 높이의 건물·지형과 겹칩니다: ${x} ${top.location.y} ${z}`);}}
   if(survey>=count){nextTile();progress();}return;
  }
  if(state.phase==='build'){
   if(state.tile>=TOTAL){state.phase='npcs';state.tile=0;state.npc=0;save();release();return;}
   if(!ensureLoaded(state.tile))return;ops=ops??tileOperations(city.operations,cityTile(state.tile));
   for(let n=0;n<BUDGET&&state.op<ops.length;n++){
    const op=ops[state.op],width=op.x2-op.x+1,depth=op.z2-op.z+1,count=width*depth*(op.y2-op.y+1),off=state.offset,y=op.y+Math.floor(off/(width*depth));
    const block=dim().getBlock(at(op.x+off%width,y,op.z+Math.floor(off/width)%depth));if(!block)throw Error('건축 청크를 다시 로딩하고 있습니다.');
    if(block.isAir||(y===0&&TERRAIN.has(block.typeId))){block.setPermutation(permutationFor(op));}
    state.offset++;if(state.offset>=count){state.op++;state.offset=0;}
   }
   if(state.op>=ops.length){nextTile();progress();}else if(system.currentTick%100===0)save();return;
  }
  if(state.phase==='npcs'){
   if(state.npc>=CITY_TRAINERS.length){
    const spawn=at(CITY_SPAWN.x,CITY_SPAWN.y,CITY_SPAWN.z);world.setDefaultSpawnLocation(spawn);setSpawnRegion(state);
    complete();return;
   }
   const [type,x,z]=CITY_TRAINERS[state.npc],tile=Math.floor(z/64)*CITY_TILES+Math.floor(x/64);if(!ensureLoaded(tile))return;
   const location=at(x+.5,1,z+.5),identifier='rpg:hito_'+type;if(!dim().getEntities({type:identifier,location,maxDistance:2}).length)dim().spawnEntity(identifier,location);state.npc++;save();
  }

 }catch(error){retry(String(error.message??error));}
}
export function resetUnbuiltCity(p){state=state??read();if(!state)return;if(state.phase!=='survey'){p.sendMessage('§e이미 건축을 시작한 마을은 자동으로 완성합니다.');return;}release();state=undefined;world.setDynamicProperty(CITY_KEY,undefined);p.sendMessage('§a건축 전 검사를 취소했습니다. 현재 위치에서 다시 생성할 수 있습니다.');}
export function registerFantasyCity(){if(registered)return;registered=true;system.run(()=>{try{state=read();release();if(state){setSpawnRegion(state);state.retryUntil=0;if(!state.manualPause)state.error=undefined;save();}}catch(error){console.warn('[RPG city] '+error);}});system.runInterval(tickFantasyCity,1);}
