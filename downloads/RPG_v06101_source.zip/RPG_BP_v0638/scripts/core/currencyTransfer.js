import {world} from '@minecraft/server';
import {ActionFormData,ModalFormData,MessageFormData} from '@minecraft/server-ui';
import {getWallet,setWallet,BALANCE_MAX,CURRENCIES,walletText} from './wallet.js';
import {showForm} from './skillMenu.js';
const locks=new Set(),menus=new Set();
export function transferCurrency(from,to,currency,amount){
 if(!from?.isValid||!to?.isValid||from.typeId!=='minecraft:player'||to.typeId!=='minecraft:player'||from.id===to.id)return {ok:false,reason:'접속 중인 다른 플레이어를 선택하세요.'};
 if(!world.getAllPlayers().some(p=>p.id===to.id))return {ok:false,reason:'받는 플레이어가 접속을 종료했습니다.'};
 if(!Object.hasOwn(CURRENCIES,currency)||!Number.isSafeInteger(amount)||amount<=0||amount>BALANCE_MAX)return {ok:false,reason:'재화 종류와 1 이상의 정수 수량을 확인하세요.'};
 if(locks.has(from.id)||locks.has(to.id))return {ok:false,reason:'다른 송금 처리 중입니다.'};
 locks.add(from.id);locks.add(to.id);let a,b,started=false;
 try{
  a=getWallet(from);b=getWallet(to);if(a[currency]<amount)return {ok:false,reason:'보내는 재화가 부족합니다.'};if(b[currency]>BALANCE_MAX-amount)return {ok:false,reason:'받는 플레이어의 지갑 한도를 초과합니다.'};
  const nextA={...a,[currency]:a[currency]-amount},nextB={...b,[currency]:b[currency]+amount};started=true;setWallet(from,nextA);setWallet(to,nextB);
  if(getWallet(from)[currency]!==nextA[currency]||getWallet(to)[currency]!==nextB[currency])throw Error('지갑 저장 확인 실패');
  return {ok:true,currency,amount,target:to.name};
 }catch(error){let restored=true;if(started)for(const undo of [()=>setWallet(from,a),()=>setWallet(to,b)])try{undo();}catch{restored=false;}return {ok:false,reason:restored?'송금을 취소하고 재화를 복구했습니다. '+String(error.message??error):'송금 복구 실패. 관리자에게 문의하세요.'};}
 finally{locks.delete(from.id);locks.delete(to.id);}
}
export async function openCurrencyTransfer(p){
 if(menus.has(p.id))return;menus.add(p.id);
 try{
  const list=world.getAllPlayers().filter(t=>t.id!==p.id&&t.isValid),f=new ActionFormData().title('재화 송금').body(walletText(getWallet(p))+'\n접속 중인 받는 플레이어를 선택하세요. 수수료는 없습니다.');
  for(const t of list)f.button(t.name);f.button('닫기');const selected=await showForm(f,p);if(!selected||selected.canceled||!list[selected.selection])return;const target=list[selected.selection];
  const keys=Object.keys(CURRENCIES),kind=new ActionFormData().title('송금할 재화');for(const key of keys)kind.button(CURRENCIES[key]);kind.button('취소');const k=await showForm(kind,p);if(!k||k.canceled||!keys[k.selection])return;const currency=keys[k.selection];
  const input=await showForm(new ModalFormData().title('송금 수량').textField(CURRENCIES[currency]+' 수량','1 이상의 정수',{defaultValue:'1'}),p);if(!input||input.canceled)return;const text=String(input.formValues?.[0]??'').trim();if(!/^[1-9]\d*$/.test(text)){p.sendMessage('§e수량은 1 이상의 정수로 입력하세요.');return;}const amount=Number(text);if(!Number.isSafeInteger(amount)||amount>BALANCE_MAX){p.sendMessage('§e송금 수량이 너무 큽니다.');return;}
  const yes=await showForm(new MessageFormData().title('송금 확인').body(target.name+'에게 '+CURRENCIES[currency]+' '+amount.toLocaleString()+'개를 보낼까요?\n수수료 없음 · 확인 후 즉시 지급됩니다.').button1('취소').button2('송금'),p);if(!yes||yes.canceled||yes.selection!==1)return;
  const result=transferCurrency(p,target,currency,amount);p.sendMessage(result.ok?'§a'+target.name+'에게 '+CURRENCIES[currency]+' '+amount.toLocaleString()+' 송금 완료':'§e'+result.reason);if(result.ok)try{target.sendMessage('§a'+p.name+'님이 '+CURRENCIES[currency]+' '+amount.toLocaleString()+' 송금했습니다.');}catch{}
 }catch(error){try{p.sendMessage('§c송금 오류: '+String(error));}catch{}}
 finally{menus.delete(p.id);}
}
