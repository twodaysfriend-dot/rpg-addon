import {isChameleonJob} from '../data/jobs.js';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {getJobId} from './playerData.js';
import {SKILLS} from '../data/skills.js';
import {readChameleonProgress,chameleonSlots} from './chameleonProgress.js';
import {showForm} from './skillMenu.js';
import {transcendQuote,purchaseTranscend,transcendMultiplier,transcendTargets,transcendLevel,TRANSCEND_COSTS,TRANSCEND_UPGRADE_MAX} from './chameleonTranscend.js';
const open=new Set(),pct=level=>Math.round((transcendMultiplier(level)-1)*100);
export async function openTranscendMenu(p,mode='transcend'){
 if(open.has(p.id)||!isChameleonJob(getJobId(p)))return;open.add(p.id);
 try{
  for(let n=0;n<50&&p.isValid&&isChameleonJob(getJobId(p));n++){
   const state=readChameleonProgress(p),limit=chameleonSlots(p),ids=transcendTargets(p,state);
   const count=Math.min(Object.keys(state.transcended).length,limit);
   const unlocked=getJobId(p)==='all_for_one';
   const costs=TRANSCEND_COSTS.map(({gold,stone},i)=>`${i+1}번째 · ${gold.toLocaleString()}골드, 강화석 ${stone.toLocaleString()}개`);
   if(unlocked)costs[costs.length-1]=costs.at(-1).replace('3번째','3~5번째');
   const body=[
    '각성한 공격·직접 회복 기술만 초월할 수 있습니다.',
    ...(unlocked?['이전 버전에 각성 없이 초월한 기술도 먼저 각성하면 초월 효과가 적용됩니다.']:[]),
    `초월 ${count}/${limit}개 · 기술당 초월강화 최대 ${TRANSCEND_UPGRADE_MAX}회`,
    ...costs,
    '매번 네더라이트 주괴 2개와 다이아몬드 블록 9개 추가.',
    '초월강화는 매회 30,000골드와 강화석 100개.',
   ].join('\n');
   const form=new ActionFormData().title(mode==='transcend'?'스킬 초월':'초월 스킬 강화').body(body);
   for(const id of ids){const q=transcendQuote(p,id,mode),level=transcendLevel(p,id);form.button(SKILLS[id].name+'\n'+(q?(mode==='transcend'?'초월 · 위력 +'+pct(0)+'%':'초월강화 +'+q.level+' · 위력 +'+pct(q.level)+'%'):level===undefined?'초월 필요 / 슬롯 또는 대상 확인':'초월 +'+level+' · 위력 +'+pct(level)+'% / '+(mode==='transcend'?'초월 완료':'최대 강화')));}
   form.button('뒤로');const pick=await showForm(form,p);if(!pick||pick.canceled||!Number.isInteger(pick.selection)||!ids[pick.selection])return;
   const id=ids[pick.selection],q=transcendQuote(p,id,mode);if(!q){p.sendMessage('§e이미 완료했거나 초월 슬롯·강화 횟수를 모두 사용했습니다.');continue;}
   const confirm=await showForm(new MessageFormData().title(mode==='transcend'?'스킬 초월 확인':'초월강화 확인').body(SKILLS[id].name+'\n'+(mode==='transcend'?q.order+'번째 초월':'초월강화 +'+q.level)+' · 위력 +'+pct(q.level)+'%\n골드 '+q.cost.gold.toLocaleString()+' / 강화석 '+q.cost.stone.toLocaleString()+'개'+(mode==='transcend'?'\n네더라이트 주괴 2개 / 다이아몬드 블록 9개':'')+'\n\n피해·직접 회복 수치만 강화합니다.\n분해 시 재료·재화는 반환하지 않습니다.').button1('취소').button2(mode==='transcend'?'초월':'초월강화'),p);
   if(!confirm||confirm.canceled||confirm.selection!==1)continue;
   const r=purchaseTranscend(p,id,mode,q.fingerprint);p.sendMessage((r.ok?'§d':'§e')+r.message);
  }
 }catch(error){try{p.sendMessage('§c초월 메뉴: '+String(error));}catch{}}
 finally{open.delete(p.id);}
}
