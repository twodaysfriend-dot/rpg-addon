import {EntityDamageCause} from '@minecraft/server';
import {monsterAttackMultiplier} from '../data/monsterLevels.js';
import {noteManualDamage,scriptedHit,setCombatHealth} from './combatContext.js';
import {RESURRECTION_PENDING} from './resurrection.js';
import {deferStoppedDamage} from './timeStopDamage.js';

export function applyBossMechanicDamage(boss,target,baseDamage,cause=EntityDamageCause.magic,options) {
  return scriptedHit(target,boss,()=>{
    const health=target.getComponent('minecraft:health');
    const before=health?.currentValue;
    if (!(before>0)) return false;
    const amount=baseDamage*monsterAttackMultiplier(boss,options);
    if (!Number.isFinite(amount) || amount<=0) return false;
    if (deferStoppedDamage(target,boss,amount)) return true;
    let accepted=false;
    try { accepted=target.applyDamage(amount,{cause,damagingEntity:boss})!==false; } catch {}
    if (accepted || health.currentValue<before || target.getProperty?.(RESURRECTION_PENDING)) return true;

    // Rejected hits can occur during the engine's hurt cooldown. The direct combat
    // path keeps RPG defenses and resurrection while the hit still resolves once.
    if (cause===EntityDamageCause.fire && target.getEffect?.('fire_resistance')) return false;
    const resistance=target.getEffect?.('resistance');
    const multiplier=resistance ? Math.max(0,1-(resistance.amplifier+1)*0.2) : 1;
    if (!multiplier) return false;
    setCombatHealth(target,boss,health,Math.max(0,before-amount*multiplier));
    const dealt=Math.max(0,before-health.currentValue);
    if (dealt>0) noteManualDamage(boss,target,dealt,{incomingScaled:true});
    return dealt>0;
  });
}
