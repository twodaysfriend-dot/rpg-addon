import {projectileMotion} from '../core/combatRunes.js';
import {system,MolangVariableMap} from '@minecraft/server';
import {getLastHit} from '../core/tracking.js';
import {CONFIG} from '../config.js';
import {canUseSkill} from '../core/skillAccess.js';
import {markResurrection,registerResurrection} from '../core/resurrection.js';
import {getTargets,hurt,healthAlive,isSolidAt,headPos,norm3,dist3,particle,sound} from '../core/util.js';
import {areAllies} from '../core/social.js';
import {VANILLA_HOSTILES} from '../data/mobXp.js';
import {LEVELED_MONSTERS} from '../data/leveledMonsters.js';
const monster=e=>e.typeId!=='minecraft:player'&&(VANILLA_HOSTILES.has(e.typeId.replace('minecraft:',''))||LEVELED_MONSTERS.includes(e.typeId)||e.getComponent('minecraft:type_family')?.hasTypeFamily('monster'));
function hit(p,e,def){if(!healthAlive(e)||areAllies(p,e))return false;return hurt(e,p,def.damage*(monster(e)?def.monsterMultiplier:1),'magic');}
function spearImpact(dim,at){
 particle(dim,'rpg:holy_spear_impact',at);
 for(let i=0;i<12;i++){const a=i*Math.PI/6;particle(dim,'rpg:holy_spear_spark',{x:at.x+Math.cos(a)*.7,y:at.y,z:at.z+Math.sin(a)*.7});}
}
const orbitTicks=16, embeddedTicks=20;
function offset(at,dir,distance){
 return {x:at.x+dir.x*distance,y:at.y+dir.y*distance,z:at.z+dir.z*distance};
}
function toward(from,to){return norm3({x:to.x-from.x,y:to.y-from.y,z:to.z-from.z});}
function chest(e){
 const head=headPos(e),base=e.location;
 return {x:base.x,y:base.y+(head.y-base.y)*.65,z:base.z};
}
function eligible(p,e){
 return e?.isValid && e.dimension.id===p.dimension.id && healthAlive(e) && e.id!==p.id &&
   !areAllies(p,e) && !e.typeId.startsWith('rpg:hito_') &&
   !['rpg:gpt_guide','minecraft:armor_stand','minecraft:item','minecraft:xp_orb'].includes(e.typeId) &&
   (e.typeId!=='minecraft:player' || (CONFIG.pvp && !['creative','spectator'].includes(String(e.getGameMode?.()).toLowerCase())));
}
function acquire(p,origin,range){
 const candidates=getTargets(p,origin,range).filter(e=>eligible(p,e));
 const recent=getLastHit(p);
 if(recent && candidates.some(e=>e.id===recent.id))return recent;
 return candidates.filter(e=>monster(e)||e.typeId==='minecraft:player')
   .sort((a,b)=>dist3(origin,a.location)-dist3(origin,b.location))[0];
}
function drawSpear(dim,at,dir){
 try{
  const variables=new MolangVariableMap();
  variables.setVector3('variable.spear_direction',dir);
  dim.spawnParticle('rpg:holy_spear',at,variables);
 }catch{}
}
function obstructed(dim,from,to){
 const length=dist3(from,to),dir=toward(from,to);
 for(let d=0;d<length;d+=.2)if(isSolidAt(dim,offset(from,dir,d)))return true;
 return isSolidAt(dim,to);
}
function embedded(p,target,dir){
 const dim=p.dimension;
 spearImpact(dim,chest(target));
 let ticks=0;
 const yaw=target.getRotation?.().y??0;
 const draw=()=>{
  const turn=((target.getRotation?.().y??yaw)-yaw)*Math.PI/180;
  const axis={x:dir.x*Math.cos(turn)-dir.z*Math.sin(turn),y:dir.y,z:dir.x*Math.sin(turn)+dir.z*Math.cos(turn)};
  drawSpear(dim,offset(chest(target),axis,-.85),axis);
 };
 draw();
 const timer=system.runInterval(()=>{
  try{
   if(++ticks<embeddedTicks && p.isValid && target.isValid && target.dimension.id===dim.id && healthAlive(target)){
    draw();return;
   }
  }catch{}
  system.clearRun(timer);
 },1);
}
function spear(p,job,def,target){
 if(!canUseSkill(p,'michael_holy_spear',['michael']))return false;
 const dim=p.dimension,origin={...p.location};
 if(target){
  if(!eligible(p,target)||dist3(origin,target.location)>6)return false;
  if(obstructed(dim,headPos(p),chest(target)))return false;
  const dir=toward(headPos(p),chest(target));
  if(!hit(p,target,def))return false;
  if(target.isValid)embedded(p,target,dir);
  return true;
 }
 let lock=acquire(p,origin,def.range);
 if(!lock){p.sendMessage('§7홀리 스피어: 사거리 안에 공격할 적이 없습니다.');return false;}
 const motion=projectileMotion(p,def.speed,4);
 let age=0,travel=0,at,dir;
 const timer=system.runInterval(()=>{
  try{
   if(!p.isValid||!healthAlive(p)||p.dimension.id!==dim.id){system.clearRun(timer);return;}
   if(age<orbitTicks){
    const angle=++age*Math.PI*2/orbitTicks, head=headPos(p);
    at={x:head.x+.82*Math.cos(angle),y:head.y+.78+.12*Math.sin(angle*2),z:head.z+.82*Math.sin(angle)};
    drawSpear(dim,at,norm3({x:-Math.sin(angle),y:.12,z:Math.cos(angle)}));
    particle(dim,'rpg:holy_spear_spark',at);
    return;
   }
   if(!dir||!eligible(p,lock)||dist3(origin,lock.location)>def.range)lock=acquire(p,origin,def.range);
   if(!lock){system.clearRun(timer);return;}
   if(!dir && obstructed(dim,headPos(p),at)){system.clearRun(timer);return;}
   const aim=toward(at,chest(lock));
   if(!dir)sound(dim,'mob.blaze.shoot',at,{volume:.6,pitch:1.8});
   dir=dir?norm3({x:aim.x*.75+dir.x*.25,y:aim.y*.75+dir.y*.25,z:aim.z*.75+dir.z*.25}):aim;
   for(let sub=0;sub<motion.steps;sub++){
    const step=Math.min(motion.step,def.range-travel);
    if(step<=0){system.clearRun(timer);return;}
    at=offset(at,dir,step);travel+=step;
    if(isSolidAt(dim,at)){spearImpact(dim,at);system.clearRun(timer);return;}
    if(dist3(at,chest(lock))<=def.hitRadius){
     if(!obstructed(dim,at,chest(lock)) && hit(p,lock,def)&&lock.isValid)embedded(p,lock,dir);
     system.clearRun(timer);return;
    }
   }
   drawSpear(dim,at,dir);
   particle(dim,'rpg:holy_spear_spark',offset(at,dir,-.85));
  }catch{system.clearRun(timer);}
 },1);
 return true;
}
function resurrection(p,job,def,target){
 if(!canUseSkill(p,'michael_resurrection',['michael'])||!markResurrection(p,target)){try{p.sendMessage('§7리저렉션: 가까운 아군에게 사용하세요. 활성 표식은 최대 2명이며 PvP에서는 사용할 수 없습니다.');}catch{}return false;}
 particle(target.dimension,'rpg:resurrection_mark',{...target.location,y:target.location.y+2.5});sound(target.dimension,'random.orb',target.location,{volume:.8,pitch:1.5});return true;
}
export function registerMichael(){registerResurrection();}
export const RUNNERS={michael_holy_spear:spear,michael_resurrection:resurrection};
