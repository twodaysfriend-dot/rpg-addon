import {MolangVariableMap} from '@minecraft/server';
import {worldMudaFx} from './worldMudaFx.js';
import {flatDir,particle,isSolidAt} from '../core/util.js';
// Cosmetic only: no damage, movement, block mutation or scheduled combat callbacks.
export function strikeAxis(x,y,z){
 const length=Math.hypot(x,y,z)||1;
 try{
  const map=new MolangVariableMap();
  map.setVector3('variable.strike_axis',{x:x/length,y:y/length,z:z/length});
  return map;
 }catch{return undefined;}
}
function ray(dim,origin,dir,length){
 const axis=strikeAxis(dir.x,0,dir.z);
 for(let d=.65;d<=length;d+=.92){
  const at={x:origin.x+dir.x*d,y:origin.y,z:origin.z+dir.z*d};
  if(isSolidAt(dim,at))break;
  particle(dim,'rpg:war_god_wave',at,axis);
 }
}
export function warGodAttackFx(p,def,index){
 try{
  if(def.id==='world_muda'){worldMudaFx(p,def,index);return;}
  const dim=p.dimension,l=p.location,dir=flatDir(p),side={x:-dir.z,z:dir.x},origin={x:l.x,y:l.y+1,z:l.z};
  if(def.kick){
   for(let i=0;i<9;i++){
    const u=i/8,forward=.7+u*Math.min(3.8,def.range-.7),across=(index%2?1:-1)*Math.sin(u*Math.PI)*.4;
    const at={x:l.x+dir.x*forward+side.x*across,y:l.y+.3+Math.sin(u*Math.PI*.85)*2.4,z:l.z+dir.z*forward+side.z*across};
    if(isSolidAt(dim,at))break;
    const axis=strikeAxis(dir.x*Math.min(3.8,def.range-.7),2.4*Math.PI*.85*Math.cos(u*Math.PI*.85),dir.z*Math.min(3.8,def.range-.7));
    particle(dim,i%4===0?'rpg:war_god_kick_arc':'rpg:war_god_wave',at,axis);
   }
   particle(dim,'rpg:war_god_burst',{x:l.x+dir.x*2,y:l.y+2.1,z:l.z+dir.z*2});
  }else{
   const count=def.hits>1?3:5;
   for(let i=0;i<count;i++){
    const angle=(i/(count-1)-.5)*1.1,c=Math.cos(angle),s=Math.sin(angle);
    ray(dim,origin,{x:dir.x*c-dir.z*s,z:dir.x*s+dir.z*c},def.range);
   }
   particle(dim,'rpg:war_god_burst',{x:l.x+dir.x*.8,y:l.y+1.1,z:l.z+dir.z*.8});
  }
 }catch{/* Cosmetic failure must never interrupt a skill. */}
}
export function warGodImpactFx(p,target){
 try{particle(p.dimension,'rpg:war_god_burst',{x:target.location.x,y:target.location.y+1,z:target.location.z});}catch{}
}
export function warGodFinaleFx(p,target){
 try{
  const dim=p.dimension,origin={x:target.location.x,y:target.location.y+1,z:target.location.z};
  particle(dim,'rpg:war_god_finale',origin);
  for(let i=0;i<8;i++){
   const angle=i*Math.PI/4,dir={x:Math.cos(angle),z:Math.sin(angle)};
   ray(dim,origin,dir,2.6);
   const end={x:origin.x+dir.x*2.6,y:origin.y,z:origin.z+dir.z*2.6};
   if(!isSolidAt(dim,end))particle(dim,'rpg:war_god_burst',end);
  }
 }catch{}
}
