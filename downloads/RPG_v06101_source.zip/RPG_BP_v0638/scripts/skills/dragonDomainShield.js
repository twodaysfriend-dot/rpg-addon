import {world,system} from '@minecraft/server';

// Swept segment/sphere checks catch fast arrows that cross the whole zone in a tick.
export function crossesDomain(a,b,center,radius){
 const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,length=dx*dx+dy*dy+dz*dz;
 const u=length?Math.max(0,Math.min(1,((center.x-a.x)*dx+(center.y-a.y)*dy+(center.z-a.z)*dz)/length)):0;
 return (a.x+dx*u-center.x)**2+(a.y+dy*u-center.y)**2+(a.z+dz*u-center.z)**2<=radius*radius;
}
const flights=new Map();let registered=false;
function remember(entity,spawn=false){
 try{
  const projectile=entity.getComponent('minecraft:projectile');if(!projectile)return;
  let record=flights.get(entity.id);
  if(!record||record.dimId!==entity.dimension.id){
   const point={...entity.location},owner=projectile.owner;
   record={origin:spawn?point:{...(owner?.dimension?.id===entity.dimension.id?owner.location:point)},last:point,dimId:entity.dimension.id,seen:system.currentTick};
   flights.set(entity.id,record);
  }
  if(!record.sourceOrigin&&projectile.owner?.dimension?.id===entity.dimension.id)record.sourceOrigin={...projectile.owner.location};
  return record;
 }catch{return undefined;}
}
export function registerDragonDomainShield(zones){
 if(registered)return;registered=true;
 world.afterEvents.entitySpawn.subscribe(({entity})=>{remember(entity,true);});
 world.afterEvents.playerLeave.subscribe(({playerId})=>{for(const [id,z]of zones)if(z.ownerId===playerId)zones.delete(id);});
 system.runInterval(()=>{
  const now=system.currentTick,players=new Map(world.getAllPlayers().map(p=>[p.id,p])),dimensions=new Map();
  for(const [id,z]of zones){
   const owner=players.get(z.ownerId);
   if(now>=z.until||!owner?.isValid||owner.getComponent('minecraft:health')?.currentValue<=0||owner.dimension.id!==z.dimId){zones.delete(id);continue;}
   if(!dimensions.has(z.dimId))dimensions.set(z.dimId,{dim:owner.dimension,zones:[]});
   dimensions.get(z.dimId).zones.push(z);
  }
  for(const {dim,zones:active}of dimensions.values()){
   let entities;try{entities=dim.getEntities();}catch{continue;}
   for(const entity of entities){
    const record=remember(entity);if(!record)continue;
    try{
     const at={...entity.location},v=entity.getVelocity?.()??{x:0,y:0,z:0};
     const next={x:at.x+v.x,y:at.y+v.y,z:at.z+v.z};
     for(const z of active){
      const outside=!crossesDomain(record.origin,record.origin,z.center,z.radius)||(record.sourceOrigin&&!crossesDomain(record.sourceOrigin,record.sourceOrigin,z.center,z.radius));
      if(outside&&(crossesDomain(record.last,at,z.center,z.radius)||crossesDomain(at,next,z.center,z.radius))){
       entity.remove();flights.delete(entity.id);break;
      }
     }
     record.last=at;record.seen=now;
    }catch{flights.delete(entity.id);}
   }
  }
  for(const [id,record]of flights)if(now-record.seen>40)flights.delete(id);
 },1);
}
