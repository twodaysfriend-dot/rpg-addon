import { MolangVariableMap,system,world } from '@minecraft/server';
import { siwangSessions } from '../core/bloodedgeState.js';
import { checkSkillMovement } from '../core/dungeonMovement.js';
import { notify } from '../core/hud.js';
import { getJobId } from '../core/playerData.js';
import { isJailed } from '../core/prison.js';
import { isTimeFrozen } from '../core/timeStopDamage.js';
import { clearBlockPath,dist3,flatDir,getTargets,healthAlive,hurt,knockback,particle,sound } from '../core/util.js';

const PHASE_PROPERTY='rpg:siwang_phase';
const FALL_TAG='rpg_siwang_fall';
const WRAP_TICKS=4;
const MAX_DIVE_TICKS=220;
const SPARK='rpg:blood_spark',BURST='rpg:blood_burst',SIGIL='rpg:blood_sigil';
const offset=(at,y)=>({...at,y:at.y+y});
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));

function eligible(p,dimension){
  return p.isValid!==false&&p.dimension.id===dimension&&getJobId(p)==='crimson_lord'&&
    String(p.getGameMode?.()).toLowerCase()!=='spectator'&&healthAlive(p)&&!isJailed(p);
}

function setPhase(p,phase){
  try{p.setProperty(PHASE_PROPERTY,phase);}catch{}
}

function clearFallTag(p){
  try{p.removeTag(FALL_TAG);}catch{}
}

function finish(p,landed=false){
  siwangSessions.delete(p.id);
  setPhase(p,0);
  if(!landed){clearFallTag(p);return;}
  // Bedrock may deliver the landing's native fall damage just after this tick.
  system.runTimeout(()=>{if(!siwangSessions.has(p.id))clearFallTag(p);},4);
}

export function castSiwang(p,_job,def){
  const dim=p.dimension;
  if(siwangSessions.has(p.id)||!eligible(p,dim.id)||isTimeFrozen(p))return false;
  const from={...p.location};
  try{
    checkSkillMovement(p,offset(from,.55));
    p.addTag(FALL_TAG);
    p.applyImpulse({x:0,y:.55,z:0});
  }catch{
    clearFallTag(p);
    return false;
  }
  siwangSessions.set(p.id,{player:p,dimension:dim.id,def,diving:false,until:system.currentTick+def.duration,last:from});
  setPhase(p,1);
  particle(dim,BURST,offset(from,1.25));
  sound(dim,'mob.enderdragon.flap',from,{volume:.8,pitch:1.35});
  return true;
}

function beginDive(state,now){
  const p=state.player;
  state.diving=true;
  state.wrapUntil=now+WRAP_TICKS;
  state.diveUntil=now+MAX_DIVE_TICKS;
  const look=flatDir(p);
  state.heading={x:look.x*.14,z:look.z*.14};
  setPhase(p,2);
  p.clearVelocity();
  particle(p.dimension,BURST,offset(p.location,1.15));
  sound(p.dimension,'mob.blaze.shoot',p.location,{volume:.85,pitch:.63});
}

export function recastSiwang(p){
  const state=siwangSessions.get(p.id);
  if(!state)return false;
  if(!eligible(p,state.dimension)){finish(p);return true;}
  if(!state.diving&&!isTimeFrozen(p))beginDive(state,system.currentTick);
  return true;
}

function fly(p){
  const view=p.getViewDirection(),velocity=p.getVelocity(),loc=p.location;
  const impulse={
    x:clamp((view.x*.56-velocity.x)*.27,-.18,.18),
    y:clamp(.079+(clamp(view.y*.47+.055,-.23,.49)-velocity.y)*.33,-.20,.30),
    z:clamp((view.z*.56-velocity.z)*.27,-.18,.18),
  };
  try{
    checkSkillMovement(p,{x:loc.x+velocity.x+impulse.x,y:loc.y+velocity.y+impulse.y,z:loc.z+velocity.z+impulse.z});
  }catch{p.clearVelocity();return;}
  p.applyImpulse(impulse);
}

function onSurface(p){
  if(p.getVelocity().y>.08)return false;
  if(p.isOnGround)return true;
  const {x,y,z}=p.location;
  // A block just under the feet also covers a landing before isOnGround updates.
  for(const [dx,dz] of [[0,0],[-.24,-.24],[-.24,.24],[.24,-.24],[.24,.24]]){
    const block=p.dimension.getBlock({x:x+dx,y:y-.12,z:z+dz});
    if(typeof block?.isSolid==='function'?block.isSolid():block?.isSolid)return true;
  }
  return false;
}

function dive(state,now){
  const p=state.player,loc=p.location;
  p.clearVelocity();
  // Fold the wings first, then accelerate downward with a slight forward drift.
  if(now<state.wrapUntil){p.applyImpulse({x:0,y:.08,z:0});return;}
  const speed=Math.min(2.35,.65+(now-state.wrapUntil)*.22);
  let horizontal=state.heading;
  try{checkSkillMovement(p,{x:loc.x+horizontal.x,y:loc.y,z:loc.z+horizontal.z});}
  catch{horizontal={x:0,z:0};}
  p.applyImpulse({x:horizontal.x,y:-speed,z:horizontal.z});
}

function trail(state,now){
  const {player:p,diving}=state,dim=p.dimension,loc=p.location;
  if(diving){
    particle(dim,SPARK,offset(loc,1.85));
    if(now%2===0)particle(dim,BURST,offset(loc,2.45));
    if(now%3===0)particle(dim,'minecraft:basic_smoke_particle',offset(loc,2.9));
    return;
  }
  if(now%3!==0)return;
  const front=flatDir(p),side={x:-front.z,z:front.x};
  for(const sign of [-1,1]){
    const back=.48+(now%8)*.05,span=1.05+(now%12)*.09;
    const at={x:loc.x-front.x*back+sign*side.x*span,y:loc.y+1.45,z:loc.z-front.z*back+sign*side.z*span};
    particle(dim,SPARK,at);
    if(now%6===0)particle(dim,SIGIL,offset(at,-.42));
  }
}

function impact(state){
  const p=state.player,dim=p.dimension,origin={...p.location},def=state.def;
  finish(p,true);
  p.clearVelocity();
  try{
    const size=new MolangVariableMap();
    size.setFloat('variable.barrier_radius',def.radius);
    particle(dim,'rpg:bloodedge_rupture',offset(origin,.16),size);
  }catch{}
  particle(dim,'rpg:bloodedge_guard_flash',offset(origin,.9));
  particle(dim,BURST,offset(origin,1.3));
  for(let i=0;i<24;i++){
    const angle=i*Math.PI/12,radius=i%2===0?def.radius*.53:def.radius*.8;
    const at={x:origin.x+Math.cos(angle)*radius,y:origin.y+.22,z:origin.z+Math.sin(angle)*radius};
    particle(dim,i%3===0?BURST:SPARK,at);
  }
  sound(dim,'random.explode',origin,{volume:1.2,pitch:.58});
  sound(dim,'mob.irongolem.hit',origin,{volume:.8,pitch:.55});
  for(const target of getTargets(p,origin,def.radius)){
    try{
      if(dist3(origin,target.location)>def.radius||['creative','spectator'].includes(String(target.getGameMode?.()).toLowerCase())||
        !clearBlockPath(dim,offset(origin,.8),offset(target.location,.8)))continue;
      if(hurt(target,p,def.damage,'magic',{ignoreInvulnerability:true,immediatePlague:true})){
        knockback(target,target.location.x-origin.x,target.location.z-origin.z,1.35,.3);
      }
    }catch{}
  }
  notify(p,'§c극번 · 시왕 착지');
}

export function tickSiwang(){
  const now=system.currentTick;
  for(const state of siwangSessions.values()){
    const p=state.player;
    try{
      if(!eligible(p,state.dimension)||dist3(state.last,p.location)>6){finish(p);continue;}
      state.last={...p.location};
      if(isTimeFrozen(p))continue;
      if(!state.diving&&now>=state.until)beginDive(state,now);
      if(state.diving){
        if(now>=state.wrapUntil&&onSurface(p)){impact(state);continue;}
        if(now>=state.diveUntil){finish(p);continue;}
        dive(state,now);
      }else fly(p);
      trail(state,now);
    }catch{finish(p);}
  }
}

let registered=false;
export function registerSiwang(){
  if(registered)return;
  registered=true;
  world.afterEvents.playerSpawn.subscribe(({player})=>finish(player));
  world.afterEvents.entityDie.subscribe(({deadEntity})=>{if(deadEntity.typeId==='minecraft:player'&&siwangSessions.has(deadEntity.id))finish(deadEntity);});
  world.afterEvents.playerLeave.subscribe(({playerId})=>siwangSessions.delete(playerId));
  system.run(()=>{for(const player of world.getAllPlayers())finish(player);});
  system.runInterval(tickSiwang,1);
}
