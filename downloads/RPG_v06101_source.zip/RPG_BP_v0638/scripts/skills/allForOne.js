import { EquipmentSlot, system } from '@minecraft/server';
import { SKILLS, damageForJob } from '../data/skills.js';
import { classWeapon } from '../data/classWeapons.js';
import { COMMON_WEAPONS } from '../data/commonWeapons.js';
import { areAllies } from '../core/social.js';
import { getJobId, getSkills } from '../core/playerData.js';
import { transcendedSkillDefinition } from '../core/chameleonTranscend.js';
import { commonWeaponFactor } from '../core/commonWeaponDamage.js';
import { criticalRuneMultiplier, rangedRuneRate } from '../core/combatRunes.js';
import { runeMeleeBonus } from '../core/runeMelee.js';
import { healingFor } from '../core/stats.js';
import { holyMonsterDamage } from './holy.js';
import { isTrainingDummy } from '../core/positionLock.js';
import { monsterDefenseMultiplier } from '../data/monsterLevels.js';
import { isBloodedgePool } from '../core/bloodedgeState.js';
import { isJailed } from '../core/prison.js';
import { isTimeFrozen } from '../core/timeStopDamage.js';
import { clearBlockPath, dist3, getTargets, headPos, healthAlive, hurt, norm3, particle, sound } from '../core/util.js';
import { notify } from '../core/hud.js';

export const RELEASE_ID = 'all_for_one_release';
const BASE_KEY = 'rpg:all_for_one_release_base';
const MAGIC_LINES = new Set(['mage','blood','holy','fire','frost','tech','demon','hacker','celestial_sun']);
const PHYSICAL_EXCEPTIONS = new Set(['demon_reap','nen_zan','nen_ko','nen_shu','revenant_execution','sun_meteor_drive']);
const MAGIC_EXCEPTIONS = new Set(['fist_wind','dragon_breath','nen_renda','nen_ho','nen_hatsu','nen_boku','soul_harpoon','harpoon_throw','chameleon_ground_slam']);
const FIXED_SKILLS = new Set(['chameleon_crimson_dash','fist_finale','demon_contract']);
const BASIC_DAMAGE = {
  archer_fire: () => 1,
  archer_ice: () => 1,
  archer_lightning: () => 1,
  archer_bomb: () => 1,
  fist_strong: def => 2 * def.hits,
  berserker_execute: def => def.nextMeleeMultiplier,
  assassin_stealth: () => 3,
  assassin_mark: def => def.damageMultiplier,
  sun_slash: def => def.damageMultiplier,
  nen_in: def => def.firstHitMult,
  nen_en: def => def.critMult,
  nen_ko: () => 1,
  nen_shu: () => 1,
  dragon_triple_strike: () => 3,
};
const SECONDARY_DAMAGE = {
  revenant_rend: def => [['physical', def.bleedDamage * def.bleedHits]],
  dragon_domain: def => [['physical', def.pulseDamage * Math.floor(def.duration / 20)]],
  fire_emperor: def => [['magic', def.zoneDamage * Math.floor(def.zoneTicks / 20)]],
  sun_meteor_drive: def => [['magic', def.beamDamage]],
  dragon_triple_strike: def => [['physical', def.bonusDamage * 3]],
};
const SPLASH_DAMAGE = {
  blood_orb: def => ({type:'magic', amount:def.splashDamage, radius:def.burstRadius}),
  tech_bomb: def => ({type:'magic', amount:def.splashDamage, radius:def.splashRadius}),
  archer_heavenly: def => ({type:'physical', amount:def.burstDamage, radius:def.burstRadius}),
};
const SHOT_DAMAGE = {
  war_god_flurry: def => [def.damage, def.maxHits],
  war_god_eight_punch: def => [def.damage, def.waves],
  mage_bombaye: def => [def.damage * def.damageMultiplier, def.shots],
  frost_barrage: def => [def.damage, def.shots],
  nen_renda: def => [def.damage, def.shots],
  beast_flame_burst: def => [def.damagePerShot, def.shots],
  moon_chakram_split: def => [def.smallDamage, def.smallCount],
};
const HOLY_DAMAGE = {
  holy_heal: def => def.healByJob.cleric * 2,
  angel_bless: def => def.heal,
  angel_zone: def => def.heal * Math.floor(def.duration / 20),
};

function damageType(def) {
  if (FIXED_SKILLS.has(def.id)) return 'fixed';
  if (PHYSICAL_EXCEPTIONS.has(def.id)) return 'physical';
  return MAGIC_EXCEPTIONS.has(def.id) || MAGIC_LINES.has(def.line) ? 'magic' : 'physical';
}

function primaryDamage(def) {
  if (def.damagePerHit) return def.damagePerHit * (def.hits ?? def.slashes ?? 1);
  if (def.damagePerSlash) return def.damagePerSlash * def.slashes;
  if (def.damagePerSecond) return def.damagePerSecond * Math.floor(def.duration / 20);
  if (def.damagePerPulse) return def.damagePerPulse * Math.floor(def.duration * (def.pulsesPerSecond ?? 2) / 20);
  if (def.id === 'sword_flame_spin' || def.id === 'sword_rush') return damageForJob(def,'all_for_one') * def.hits;
  if (def.id === 'fallen_zone') return def.damage * Math.floor(def.duration / 20);
  return damageForJob(def,'all_for_one') ?? def.rangedDamage ?? def.entryDamage ?? def.impactDamage ??
    def.failDamage ?? def.extraDamage ?? def.enemyDamage ?? 0;
}

// Convert a skill to its single-target damage. Projectile volleys keep multiple
// seeking shots while melee combos, timed zones and buffs carry their total on impact.
export function releaseProfile(def) {
  if (!def || def.id === RELEASE_ID) return undefined;
  if (def.id === 'archer_rapid') return { count:3, parts:[['arrow',1]] };
  if (HOLY_DAMAGE[def.id]) return { count:1, parts:[['holy',HOLY_DAMAGE[def.id](def)]] };
  if (SHOT_DAMAGE[def.id]) {
    const [amount,count] = SHOT_DAMAGE[def.id](def);
    return { count, parts:[[damageType(def),amount]], speed:def.speed };
  }
  const parts = [];
  if (BASIC_DAMAGE[def.id]) {
    const method = def.line === 'archer' ? 'arrow' : 'melee';
    parts.push([method,BASIC_DAMAGE[def.id](def)]);
  }
  const primary = primaryDamage(def);
  if (primary > 0) parts.push([damageType(def),primary]);
  if (SECONDARY_DAMAGE[def.id]) parts.push(...SECONDARY_DAMAGE[def.id](def));
  if (!parts.length) return undefined;
  return { count:1, parts, speed:def.speed, monsterMultiplier:def.monsterMultiplier, splash:SPLASH_DAMAGE[def.id]?.(def) };
}

export function releaseSkillIds(player) {
  return [...new Set(getSkills(player))].filter(id => releaseProfile(SKILLS[id]));
}

export function releaseBaseSkill(player, ids = releaseSkillIds(player)) {
  const id = player.getDynamicProperty(BASE_KEY);
  return ids.includes(id) ? id : undefined;
}

export function setReleaseBaseSkill(player, id) {
  if (getJobId(player) !== 'all_for_one' || !releaseSkillIds(player).includes(id)) return false;
  player.setDynamicProperty(BASE_KEY,id);
  return true;
}

const offset = (a,b,f=1) => ({x:a.x+b.x*f,y:a.y+b.y*f,z:a.z+b.z*f});
const direction = (a,b) => norm3({x:b.x-a.x,y:b.y-a.y,z:b.z-a.z});
const dot = (a,b) => a.x*b.x+a.y*b.y+a.z*b.z;
const body = target => ({...target.location,y:target.location.y+0.9});
const isPlayer = target => target.typeId === 'minecraft:player';
const livingTarget = (player,target,dim) => target?.isValid && target.dimension.id===dim.id &&
  healthAlive(target) && !areAllies(player,target) && !isBloodedgePool(target) &&
  (!isPlayer(target) || !['creative','spectator'].includes(String(target.getGameMode?.()).toLowerCase()));

function aimTarget(player, range, playerTargets) {
  const dim=player.dimension, origin=headPos(player), view=player.getViewDirection();
  let best, bestAlignment=.5, bestDistance=Infinity;
  for (const candidate of getTargets(player,origin,range,.7)) {
    if (!livingTarget(player,candidate,dim) || (playerTargets!==undefined && isPlayer(candidate)!==playerTargets)) continue;
    const at=body(candidate), distance=dist3(origin,at);
    if (distance>range) continue;
    const alignment=distance<1.5?1:dot(direction(origin,at),view);
    if (alignment<bestAlignment || (alignment===bestAlignment && distance>=bestDistance) || !clearBlockPath(dim,origin,at)) continue;
    best=candidate;bestAlignment=alignment;bestDistance=distance;
  }
  return best;
}

function baseWeaponDamage(player) {
  const item=player.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand);
  const weapon=classWeapon(item?.typeId)??COMMON_WEAPONS.find(w=>w.id===item?.typeId);
  const strength=player.getEffect?.('strength');
  const bonus=strength?3*(strength.amplifier+1):0;
  return ((weapon?.damage??0)+1+bonus)*commonWeaponFactor(item)*(1+runeMeleeBonus(player));
}

function impact(player,target,profile,weaponDamage,center) {
  for (const [type,amount] of profile.parts) {
    if (!healthAlive(target)) break;
    if (type==='holy') {
      if (isTrainingDummy(target.typeId)) {
        hurt(target,player,healingFor(player,amount)*3,'fixed',{ignoreInvulnerability:true});
      } else {
        holyMonsterDamage(player,target,amount);
      }
    } else if (type==='melee' || type==='arrow') {
      const basic=type==='melee'?weaponDamage:6;
      const damage=basic*amount*criticalRuneMultiplier(player)*monsterDefenseMultiplier(target);
      hurt(target,player,damage,'fixed',{ignoreInvulnerability:true});
    } else {
      const factor=profile.monsterMultiplier&&!isPlayer(target)&&!isTrainingDummy(target.typeId)?profile.monsterMultiplier:1;
      hurt(target,player,amount*factor,type,{ignoreInvulnerability:true});
    }
  }
  if (profile.splash) {
    const {type,amount,radius}=profile.splash, dim=player.dimension;
    for (const neighbor of getTargets(player,center,radius,.9)) {
      if (neighbor.id===target.id || isPlayer(neighbor)!==isPlayer(target) || !livingTarget(player,neighbor,dim)) continue;
      if (dist3(body(neighbor),center)<=radius && clearBlockPath(dim,center,body(neighbor)))
        hurt(neighbor,player,amount,type,{ignoreInvulnerability:true});
    }
  }
}

export function castAllForOneRelease(player,_job,def) {
  if(getJobId(player)!=='all_for_one')return false;
  const ids=releaseSkillIds(player), base=releaseBaseSkill(player,ids);
  if (!base) { notify(player,'§e/rpg:skillbook에서 전인자 해방 기준 스킬을 지정하세요.');return false; }
  const dim=player.dimension;
  let target=aimTarget(player,def.range);
  if (!target) { notify(player,'§7조준 방향에 명중할 대상이 없습니다.');return false; }
  const playerTargets=isPlayer(target);
  const ordered=[base,...ids.filter(id=>id!==base)];
  const queue=ordered.flatMap(id=>{
    const profile=releaseProfile(transcendedSkillDefinition(player,SKILLS[id]));
    return Array.from({length:profile.count},()=>profile);
  });
  if (!queue.length) return false;
  const weaponDamage=baseWeaponDamage(player), rate=rangedRuneRate(player), flights=[];
  let index=0, age=0;
  particle(dim,'rpg:zoltraak_circle',headPos(player));
  sound(dim,'mob.wither.spawn',player.location,{volume:.9,pitch:.75});
  notify(player,'§5전인자 해방! §f'+SKILLS[base].name+' · 공격 스킬 '+ids.length+'개');
  const timer=system.runInterval(()=>{
    try {
      if(!player.isValid||player.dimension.id!==dim.id||getJobId(player)!=='all_for_one'||
         !healthAlive(player)||isJailed(player)||isTimeFrozen(player)) {
        system.clearRun(timer);
        return;
      }
      if (!livingTarget(player,target,dim) || dist3(player.location,target.location)>def.range+6) {
        target=aimTarget(player,def.range,playerTargets);
        if(!target){system.clearRun(timer);return;}
      }
      // Start with the selected skill and use the caster's live position for each launch.
      if(index<queue.length && age++%2===0) {
        const profile=queue[index++], origin=headPos(player);
        flights.push({ profile, pos:origin, left:def.range+10, step:Math.min(8,(profile.speed??2.1)*rate) });
      }
      const aim=body(target);
      for (let i=flights.length-1;i>=0;i--) {
        const flight=flights[i], distance=dist3(flight.pos,aim);
        const step=Math.min(distance,flight.step,flight.left);
        const next=offset(flight.pos,direction(flight.pos,aim),step);
        if (!clearBlockPath(dim,flight.pos,next) || flight.left<=0) {flights.splice(i,1);continue;}
        particle(dim,flight.profile.parts[0][0]==='magic'?'rpg:sage_sphere':'rpg:chameleon_crimson_trail',next);
        if(distance<=step+.001) {
          impact(player,target,flight.profile,weaponDamage,aim);
          flights.splice(i,1);
        } else {
          flight.pos=next;
          flight.left-=step;
        }
      }
      if(index>=queue.length&&!flights.length)system.clearRun(timer);
    } catch { system.clearRun(timer); }
  },1);
  return true;
}
