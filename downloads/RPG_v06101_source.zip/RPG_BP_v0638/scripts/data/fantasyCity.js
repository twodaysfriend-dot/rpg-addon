// Version 2 decoration: oriented stair roofs and deterministic patterned paving.
export const CITY_SIZE=250,CITY_TILE=64,CITY_TILES=Math.ceil(CITY_SIZE/CITY_TILE);
export const CITY_SPAWN={x:125,y:1,z:125};
export function cityTile(index){const x=index%CITY_TILES*CITY_TILE,z=Math.floor(index/CITY_TILES)*CITY_TILE;return {x,z,x2:Math.min(CITY_SIZE-1,x+63),z2:Math.min(CITY_SIZE-1,z+63)};}
// Shared house footprints keep build permissions aligned with the generated houses.
export const CITY_HOUSE_PLOTS=Object.freeze([
 ...[[30,30],[60,30],[180,30],[207,30],[30,65],[60,65],[180,65],[207,65],[25,102],[62,105],[176,105],[208,105],[25,160],[60,160],[174,160],[207,160],[30,207],[65,207],[170,207],[205,207]].map(([x,z],i)=>Object.freeze({x,z,w:16,d:14,theme:i})),
 ...[{x:30,z:132,w:26,d:20,theme:1},{x:182,z:132,w:26,d:20,theme:0},
 ...[90,108,126,144].map(x=>({x,z:194,w:12,d:10,theme:1}))].map(Object.freeze)
]);
export function makeFantasyCityPlan(){
 const plan=[];let houses=0;
 const emit=(x,y,z,x2,y2,z2,type,states)=>{if(x>x2||y>y2||z>z2)return;plan.push({x,y,z,x2,y2,z2,type:'minecraft:'+type,...(states?{states}:{})});};
 const pave=(x,z,dark)=>{
  const a=((x%8)+8)%8,b=((z%8)+8)%8,h=((x*7349+z*9151+x*z*31)>>>0)%19;
  if(dark){
   if((a===0||a===7)&&(b===0||b===7))return ['chiseled_stone_bricks'];
   if(a===0||b===0||a===7||b===7)return ['polished_blackstone_bricks'];
   if((a===2||a===5)&&(b===2||b===5))return ['polished_blackstone_brick_stairs',{weirdo_direction:a===2?0:1,upside_down_bit:true}];
   if(a===1||a===6||b===1||b===6)return ['stone_bricks'];
   return [h%3===0?'andesite':h%3===1?'smooth_stone':'polished_andesite'];
  }
  if((a===2||a===5)&&b===3)return ['mossy_stone_brick_stairs',{weirdo_direction:a===2?0:1,upside_down_bit:true}];
  return [h<3?'moss_block':h<6?'mossy_cobblestone':h<10?'mossy_stone_bricks':h<14?'stone_bricks':h<17?'cobblestone':'andesite'];
 };
 const rect=(x,y,z,x2,y2,z2,type,states)=>{
  if(y===0&&y2===0&&['smooth_quartz','polished_andesite','cobblestone'].includes(type)){
   for(let row=z;row<=z2;row++)for(let col=x;col<=x2;){const value=pave(col,row,type!=='cobblestone'),key=JSON.stringify(value);let end=col;
    while(end<x2&&JSON.stringify(pave(end+1,row,type!=='cobblestone'))===key)end++;
    emit(col,0,row,end,0,row,...value);col=end+1;
   }return;
  }emit(x,y,z,x2,y2,z2,type,states);
 };
 // Stair high sides face the ridge. Upside-down eaves support the overhang.
 const roof=(x,z,w,d,y,mat='spruce',gable='white_terracotta')=>{
  for(let step=0;step<Math.floor((w+2)/2);step++){
   const a=x-1+step,b=x+w-step,h=y+step;
   rect(a,h,z-1,a,h,z+d,mat+'_stairs',{weirdo_direction:0,upside_down_bit:false});
   rect(b,h,z-1,b,h,z+d,mat+'_stairs',{weirdo_direction:1,upside_down_bit:false});
   if(a+1<=b-1){rect(a+1,h,z,b-1,h,z,gable);rect(a+1,h,z+d-1,b-1,h,z+d-1,gable);}
  }
  const mid=x+Math.floor((w-1)/2),peak=y+Math.floor((w+2)/2);
  rect(mid,peak,z-1,mid+(w%2===0?1:0),peak,z+d,mat==='deepslate_tile'?'deepslate_tile_slab':mat+'_slab',{'minecraft:vertical_half':'bottom'});
  for(const [edge,dir]of [[x-1,0],[x+w,1]])rect(edge,y-1,z-1,edge,y-1,z+d,mat+'_stairs',{weirdo_direction:dir,upside_down_bit:true});
  for(const edge of [x,x+w-1])rect(edge,y,z,edge,y,z+d-1,mat==='deepslate_tile'?'deepslate_tiles':mat+'_planks');
 };
 const walls=(x,z,w,d,h,mat='stone_bricks',south=false)=>{
  const mid=x+Math.floor(w/2),front=south?z+d-1:z,back=south?z:z+d-1;
  rect(x,1,front,mid-2,h,front,mat);rect(mid+2,1,front,x+w-1,h,front,mat);rect(mid-1,4,front,mid+1,h,front,mat);
  rect(x,1,back,x+w-1,h,back,mat);rect(x,1,z+1,x,h,z+d-2,mat);rect(x+w-1,1,z+1,x+w-1,h,z+d-2,mat);
 };
 const house=(x,z,w=16,d=14,theme=0)=>{
  houses++;rect(x+2,1,z+d-3,x+2,1,z+d-3,'crafting_table');rect(x+w-3,1,z+d-3,x+w-3,1,z+d-3,'chest');rect(x+2,5,z+2,x+2,5,z+2,'sea_lantern');
  for(let n=3;n<w-2;n+=5){rect(x+n,3,z,x+n+1,4,z,'glass');rect(x+n,3,z+d-1,x+n+1,4,z+d-1,'glass');}
  for(const edge of [x,x+w-1])rect(edge,3,z+4,edge,4,z+6,'glass');
  roof(x,z,w,d,7,theme%2?'spruce':'dark_oak',theme%2?'white_terracotta':'stone_bricks');
  // Timber lintels, window sills, and stone foundation plinths.
  rect(x,6,z,x+w-1,6,z,'dark_oak_log');rect(x,6,z+d-1,x+w-1,6,z+d-1,'dark_oak_log');
  for(let n=3;n<w-2;n+=5)for(const edge of [z-1,z+d])rect(x+n,2,edge,x+n+1,2,edge,'stone_brick_stairs',{weirdo_direction:edge===z-1?2:3,upside_down_bit:true});
  for(const edge of [x,x+w-1])rect(edge,1,z,edge,1,z+d-1,'cobblestone');
  for(const a of [x,x+w-1])for(const b of [z,z+d-1])rect(a,1,b,a,6,b,'oak_log');
  walls(x,z,w,d,6,theme%2?'white_terracotta':'stone_bricks');rect(x,0,z,x+w-1,0,z+d-1,'oak_planks');
  const mid=x+Math.floor(w/2);rect(mid-1,0,z-4,mid+1,0,z-1,'cobblestone');
 };
 const tower=(x,z,w=12,h=18)=>{
  // A slate spire rises above the blue core and crenellated tower crown.
  for(let step=0;step<Math.floor((w-4)/2);step++){
   const lo=2+step,hi=w-3-step,yy=h+1+step;
   rect(x+lo,yy,z+lo,x+hi,yy,z+lo,'deepslate_tile_stairs',{weirdo_direction:2,upside_down_bit:false});
   rect(x+lo,yy,z+hi,x+hi,yy,z+hi,'deepslate_tile_stairs',{weirdo_direction:3,upside_down_bit:false});
   rect(x+lo,yy,z+lo+1,x+lo,yy,z+hi-1,'deepslate_tile_stairs',{weirdo_direction:0,upside_down_bit:false});
   rect(x+hi,yy,z+lo+1,x+hi,yy,z+hi-1,'deepslate_tile_stairs',{weirdo_direction:1,upside_down_bit:false});
   rect(x+lo+1,yy,z+lo+1,x+hi-1,yy,z+hi-1,'blue_concrete');
  }
  rect(x+Math.floor(w/2)-1,h+Math.floor((w-4)/2)+1,z+Math.floor(w/2)-1,x+Math.floor(w/2),h+Math.floor((w-4)/2)+1,z+Math.floor(w/2),'chiseled_stone_bricks');
  for(let i=0;i<w;i+=4)for(const edge of [0,w-1]){rect(x+i,h+1,z+edge,x+Math.min(i+1,w-1),h+2,z+edge,'stone_bricks');rect(x+edge,h+1,z+i,x+edge,h+2,z+Math.min(i+1,w-1),'stone_bricks');}
  rect(x,h,z,x+w-1,h,z+w-1,'stone_bricks');walls(x,z,w,w,h-1);rect(x,0,z,x+w-1,0,z+w-1,'stone_bricks');
 };
 // Benches, compact market awnings, and planted yards keep the main routes clear.
 for(const [x,z]of [[96,137],[150,137],[109,151],[136,151]]){
  rect(x,1,z,x+2,1,z,'spruce_stairs',{weirdo_direction:3,upside_down_bit:false});
  rect(x-1,1,z,x-1,1,z,'oak_fence');rect(x+3,1,z,x+3,1,z,'oak_fence');
  rect(x-2,1,z+1,x-2,1,z+1,'flowering_azalea');
 }
 for(const [i,x]of [105,135].entries()){
  for(const edge of [x,x+6])for(const z of [174,179])rect(edge,1,z,edge,4,z,'oak_fence');
  rect(x+1,1,177,x+5,1,177,'spruce_planks');
  for(let col=0;col<7;col++)rect(x+col,5,173,x+col,5,180,col%2?'white_wool':i?'red_wool':'blue_wool');
  rect(x,4,173,x+6,4,173,'spruce_stairs',{weirdo_direction:2,upside_down_bit:false});
  rect(x,0,174,x+6,0,179,'cobblestone');
 }
 for(const [x,z]of [[18,85],[18,185],[232,85],[232,185],[85,165],[165,165],[85,215],[165,215],[20,45],[230,45]]){
  rect(x,1,z,x,5,z,'oak_log');
  rect(x-2,4,z-1,x+2,5,z+1,'oak_leaves',{persistent_bit:true});
  rect(x-1,4,z-2,x+1,5,z+2,'oak_leaves',{persistent_bit:true});
  rect(x-1,6,z-1,x+1,6,z+1,'oak_leaves',{persistent_bit:true});
  for(const [dx,dz]of [[-2,-2],[2,2]])rect(x+dx,1,z+dz,x+dx,1,z+dz,'flowering_azalea');
 }
 // Central spawn square and fountains, south of the royal keep.
 rect(121,0,121,128,0,128,'gold_block');
 for(const x of [101,140]){
  rect(x+1,1,111,x+6,1,116,'water');rect(x+3,2,113,x+3,4,113,'sea_lantern');
  rect(x,1,110,x+7,1,110,'stone_bricks');rect(x,1,117,x+7,1,117,'stone_bricks');rect(x,1,111,x,1,116,'stone_bricks');rect(x+7,1,111,x+7,1,116,'stone_bricks');rect(x,0,110,x+7,0,117,'stone_bricks');
 }
 rect(93,0,104,156,0,154,'smooth_quartz');
 // Castle: visible glazing, throne, roof, walls and four spires.
 rect(121,1,68,128,2,72,'gold_block');
 for(const x of [108,134]){rect(x,8,35,x+5,12,35,'blue_stained_glass');rect(x,8,74,x+5,12,74,'blue_stained_glass');}
 roof(101,35,24,40,17,'deepslate_tile','polished_blackstone_bricks');roof(125,35,24,40,17,'deepslate_tile','polished_blackstone_bricks');
 walls(101,35,48,40,16,'polished_blackstone_bricks',true);rect(101,0,35,148,0,74,'polished_blackstone_bricks');
 for(const x of [84,154])for(const z of [23,80])tower(x,z,12,24);
 for(const [a,b]of [[80,118],[131,169]]){rect(a,1,20,b,7,22,'stone_bricks');rect(a,1,94,b,7,96,'stone_bricks');}
 rect(80,1,23,82,7,93,'stone_bricks');rect(167,1,23,169,7,93,'stone_bricks');rect(80,0,20,169,0,96,'stone_bricks');
 for(const {x,z,w,d,theme} of CITY_HOUSE_PLOTS)house(x,z,w,d,theme);
 for(const [a,b]of [[0,118],[131,249]]){rect(a,1,0,b,8,2,'stone_bricks');rect(a,1,247,b,8,249,'stone_bricks');rect(0,1,a,2,8,b,'stone_bricks');rect(247,1,a,249,8,b,'stone_bricks');}
 for(let n=0;n<250;n+=6)if(n<114||n>134)for(const edge of [0,248]){rect(n,9,edge,Math.min(n+2,249),10,edge+1,'stone_bricks');rect(edge,9,n,edge+1,10,Math.min(n+2,249),'stone_bricks');}
 for(const x of [5,231])for(const z of [5,231])tower(x,z,14,18);
 for(const a of [104,134]){tower(a,5,12,14);tower(a,233,12,14);tower(5,a,12,14);tower(233,a,12,14);}
 for(const x of [20,75,175,225])for(const z of [50,125,180,225]){rect(x,1,z,x,4,z,'oak_fence');rect(x,5,z,x,5,z,'sea_lantern');}
 rect(119,0,0,130,0,249,'polished_andesite');rect(0,0,119,249,0,130,'polished_andesite');
 for(const n of [50,100,150,200]){rect(n-2,0,3,n+2,0,246,'cobblestone');rect(3,0,n-2,246,0,n+2,'cobblestone');}
 rect(0,0,0,249,0,249,'grass_block');rect(0,-1,0,249,-1,249,'stone_bricks');
 return {operations:plan,houses};
}
export function tileOperations(plan,tile){return plan.map(op=>({...op,x:Math.max(op.x,tile.x),x2:Math.min(op.x2,tile.x2),z:Math.max(op.z,tile.z),z2:Math.min(op.z2,tile.z2)})).filter(op=>op.x<=op.x2&&op.z<=op.z2).sort((a,b)=>(a.type==='minecraft:water')-(b.type==='minecraft:water'));}
export const CITY_TRAINERS=[['archer',103,143],['holy',109,143],['sword',115,143],['mage',121,143],['fist',127,143],['nen',133,143],['the_world',139,143],['war_god',145,143]];
