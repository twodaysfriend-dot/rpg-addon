export const MISSION_HYDRA='rpg:hydra_boss';
export const MISSION_HYDRA_LEVEL=200;
export const MISSION_HYDRA_TAG='rpg_chameleon_mission_hydra';
export const CHAMELEON_MISSION_LEVEL=100;
export const CHAMELEON_MISSIONS=Object.freeze({
 dungeon:{name:'고독한 정복자',goal:1,text:'9단계 던전에 혼자 입장해 끝까지 클리어'},
 wither:{name:'위더 사냥',goal:1,text:'위더 1마리 처치'},
 dragon:{name:'엔드를 다시 위대하게',goal:1,text:'엔드 귀환 포탈에 마지막 엔드 수정을 놓아 드래곤 부활시키기'},
 diamond:{name:'다이아 한 세트',goal:64,text:'다이아몬드 64개 직접 채굴. 행운으로 나온 추가 수량도 인정'},
 raid:{name:'마을의 수호자',goal:1,text:'주민 습격에 직접 참여해 1회 승리'},
 guardian:{name:'심해 정복',goal:3,text:'엘더 가디언 3마리 처치'},
 worm:{name:'사막의 포식자',goal:5,text:'엘리트 데스웜 5마리 처치'},
 debris:{name:'네더 발굴',goal:16,text:'고대 잔해 16개 직접 채굴'},
 shulker:{name:'엔드 도시 탐험',goal:12,text:'엔드 도시에서 셜커 12마리 처치'},
 hydra:{name:'히드라 추적',goal:1,text:'오버월드의 지정 좌표에서 레벨 200 히드라 처치'},
});
