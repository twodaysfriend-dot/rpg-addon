import {MONSTER_BASE_STATS,MONSTER_STAT_MULTIPLIERS,DUNGEON_BALANCE} from './dungeonBalance.js';
import {DUNGEON_TIERS} from './dungeons.js';
export const MONSTER_LEVELS=Object.freeze([1,5,10,15,20,30,40,55,70,90,115,145,180,220,260]);
export const DUNGEON_LEVEL_INDEX=Object.freeze([2,4,5,6,7,8,9,10,11,12]);
export const DUNGEON_HEALTH_PRESSURE=Object.freeze([1,.9,.8,.7,.6,.52,.45,.37,.345,40000/129637.2]);
export const MONSTER_LEVEL_KEY='rpg:monster_level';
export const levelHealthMultiplier=level=>1+Math.max(0,level-1)*.035;
export const levelAttackMultiplier=level=>1+Math.max(0,level-1)*.018;
export const MONSTER_CONTEXT_KEY='rpg:monster_context';
export const WILD_HEALTH_SCALE=.9,WILD_ATTACK_SCALE=.9;
export function monsterContext(entity){try{const raw=entity?.getDynamicProperty?.(MONSTER_CONTEXT_KEY);const c=typeof raw==='string'?JSON.parse(raw):undefined;return c&&Number.isInteger(c.tier)&&c.tier>=1&&c.tier<=10&&['normal','elite','boss'].includes(c.kind)?c:undefined;}catch{return undefined;}}
// Two successive relative 20% reductions: original dungeon reduction ×0.8×0.8.
export const DUNGEON_REDUCTION_SCALE=.64;
export function monsterDefenseFor(level,context){
 if(!context)return 1; // Wild monsters have no level-based damage reduction.
 const tier=context.kind==='boss'?DUNGEON_TIERS[context.tier-1]?.bossProfileTier??context.tier:context.tier;
 const pressure=tier>=2?1+(tier-2)*.04:1;
 const original=1/(1+Math.max(0,level-1)*.004)/pressure;
 return 1-(1-original)*DUNGEON_REDUCTION_SCALE;
}
export function monsterDefenseMultiplier(entity){let level;try{level=entity?.getDynamicProperty?.(MONSTER_LEVEL_KEY);}catch{}return Number.isFinite(level)?monsterDefenseFor(level,monsterContext(entity)):1;}
const encounterScales=new Map();
function encounterScale(tier,kind){
 const key=tier.tier+'_'+kind;if(encounterScales.has(key))return encounterScales.get(key);
 const target=DUNGEON_BALANCE[tier.tier-1],base=MONSTER_BASE_STATS[tier.boss];
 let scale;
 if(kind==='boss'){
  const level=dungeonMonsterLevel(tier.tier,'boss');
  scale={health:target.bossHealth/base.health/levelHealthMultiplier(level),attack:target.bossAttack/base.attack/levelAttackMultiplier(level)};
 }else{
  const pool=tier[kind].map(id=>MONSTER_BASE_STATS[id]),level=dungeonMonsterLevel(tier.tier,kind,2);
  const kindHealth=tier.tier>=2&&kind==='elite'?1.35:1;
  const health=tier.hpMultiplier*kindHealth*DUNGEON_HEALTH_PRESSURE[tier.tier-1];
  scale={
   health:health*Math.min(1,target[kind+'Health']/(Math.max(...pool.map(s=>s.health))*levelHealthMultiplier(level)*health)),
   attack:tier.attackMultiplier*Math.min(1,target[kind+'Attack']/(Math.max(...pool.map(s=>s.attack))*levelAttackMultiplier(level)*tier.attackMultiplier))
  };
 }
 encounterScales.set(key,scale);return scale;
}
const hydraBossBoost={health:2,attack:1.5};
function isDungeonHydraBoss(context,type){
 return type==='rpg:hydra_boss'&&context?.kind==='boss'&&context.tier>=9;
}

export function monsterCombatMultipliers(level,context,type){
 const tier=context?DUNGEON_TIERS[context.tier-1]:undefined;
 const scale=tier?encounterScale(tier,context.kind):{health:WILD_HEALTH_SCALE,attack:WILD_ATTACK_SCALE};
 const boost=isDungeonHydraBoss(context,type??'rpg:'+tier?.boss)?hydraBossBoost:undefined;
 return {health:levelHealthMultiplier(level)*scale.health*(boost?.health??1),
  attack:levelAttackMultiplier(level)*scale.attack*(boost?.attack??1),defense:monsterDefenseFor(level,context)};
}
export function monsterAttackMultiplier(entity,{hydraBreath=false}={}){
 let level=1;try{level=entity?.getDynamicProperty?.(MONSTER_LEVEL_KEY)??1;}catch{}
 const context=monsterContext(entity);
 // Native attacks inherit the boosted entity base. Scripted attacks supply their own base.
 const multiplier=monsterCombatMultipliers(level,context,entity?.typeId).attack*(MONSTER_STAT_MULTIPLIERS[entity?.typeId]?.attack??1);
 return hydraBreath&&isDungeonHydraBoss(context,entity?.typeId) ? multiplier/hydraBossBoost.attack : multiplier;
}
export const levelRewardMultiplier=entity=>{
 let level;try{level=entity?.getDynamicProperty?.(MONSTER_LEVEL_KEY);}catch{}
 return Number.isFinite(level)?Math.min(4,1+Math.max(0,level-1)*.01):1;
};
export function dungeonMonsterLevel(tier,kind,index=0){
 const tierIndex=Math.max(0,Math.min(9,tier-1));
 const profileIndex=kind==='boss'?DUNGEON_TIERS[tierIndex].bossProfileTier-1:tierIndex;
 const base=DUNGEON_LEVEL_INDEX[profileIndex];
 const offset=kind==='boss'?2:kind==='elite'?1:[-1,0,1][index%3];
 return MONSTER_LEVELS[Math.max(0,Math.min(MONSTER_LEVELS.length-1,base+offset))];
}
export function wildMonsterLevel(location,random=Math.random){
 const distance=Math.max(Math.abs(location.x),Math.abs(location.z));
 const indices=distance<=1500?[0,1,2,3]:distance<=4000?[4,5,6,7]:[8,9,10,11];
 const n=random();if(!Number.isFinite(n)||n<0||n>=1)throw Error('몬스터 레벨 난수 오류');
 return MONSTER_LEVELS[indices[Math.floor(n*indices.length)]];
}
