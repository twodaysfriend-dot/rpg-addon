import {COMMON_WEAPONS} from './commonWeapons.js';
export const DESTRUCTION_WAIVER_ID = 'rpg:destruction_waiver';
export const ARMOR_SETS = {
  abyssal:{name:'심연 수호자',protection:[5,10,8,5],toughness:4,knockbackResistance:2,durability:[2200,3200,3000,2600],health:16,physical:1.08,magic:1.08,ward:true,description:'4세트: 최대 HP +16, 물리·마법 스킬 +8%, 저항 I 유지. 부위당 방어 +2·방어 강도 +4(추가 피해 감소 4%)·밀치기 저항 +2(20%). 방어 합계 28·기본 방어 상한 초과분도 적용·보호 인챈트 중첩'},
  adventurer: {name:'모험가', protection:[2,5,4,2], durability:[880,1280,1200,880], physical:1.08, description:'4세트: 물리 스킬 피해 +8%'},
  warden: {name:'숲 수호자', protection:[3,6,5,2], durability:[1200,1800,1680,1200], health:8, description:'4세트: 최대 HP +8'},
  astral: {name:'별빛 술사', protection:[2,5,4,2], durability:[1040,1600,1500,1040], magic:1.08, manaRegen:3, description:'4세트: 마법 스킬 피해 +8%, 초당 마나 +3'},
};
export const ARMOR_PARTS = ['helmet','chestplate','leggings','boots'];
export const PART_NAMES = ['투구','흉갑','각반','장화'];
export const RUNES = {
  power:{name:'힘의 룬', description:'물리 스킬 피해 +6.8%, 강화마다 +1.36%p. +1부터 공용·직업 무기 근접 평타에도 추가 피해. 영웅 이상: +8 물리 +1.2%p / +9 신속 I / +10 물리 +1.6%p (전설 ×1.5, 신화 ×2.25)', physical:1.17},
  ward:{name:'수호의 룬', description:'RPG 방어력 +4, 강화마다 +2 (일반 +10: +24). 방어력 1당 피해 감소 0.35%p. 저항 효과는 부여하지 않음. 영웅 이상: +8 최대 HP +6 / +9 재생 I / +10 최대 HP +10 (전설 ×1.5, 신화 ×2.25)', defense:4},
  mana:{name:'샘의 룬', description:'초당 최대 마나의 1% 추가 회복. 영웅 이상: +8 마나 회복 +0.3%p / +9 신속 I / +10 마나 회복 +0.5%p (전설 ×1.5, 신화 ×2.25)', manaRegenPercent:0.01},
  arcane:{name:'비전의 룬', description:'마법 스킬 피해 +6.8%, 강화마다 +1.36%p. +1부터 공용·직업 무기 근접 평타에도 추가 피해. 영웅 이상: +8 마법 +1.2%p / +9 마나 회복 +0.4%p / +10 마법 +1.6%p (전설 ×1.5, 신화 ×2.25)', magic:1.17},
  vitality:{name:'생명의 룬', description:'최대 HP +4, 강화마다 +2 (일반 +10: +24). 영웅 이상: +8 최대 HP +6 / +9 재생 I / +10 최대 HP +10 (전설 ×1.5, 신화 ×2.25)', health:4},
  absorption:{name:'흡수의 룬',description:'적에게 준 피해의 2.5%를 HP로 회복, 일반 최대 강화 6%. 영웅 이상: +8 흡혈 +0.5%p / +9 최대 HP +6 / +10 흡혈 +0.75%p (전설 ×1.5, 신화 ×2.25)',lifesteal:.05},
  attack_speed:{name:'공속의 룬',description:'활의 최대 위력에 필요한 장전 시간과 즉발 활의 발사 간격 감소. 무기와 스킬 투사체 속도 최대 3배.',rangedHaste:2},
  critical_hit:{name:'치명타의 룬',description:'공격 치명타 확률 최대 250%. 치명타 피해 175%, 100%를 넘긴 확률만큼 피해 배율에 가산.',criticalChance:2.5},
  cooldown_reduction:{name:'쿨타임 감소의 룬',description:'스킬 쿨타임 감소. 신화 +10에서 60%. 더 월드!, 시스템 재부팅, 혈촉수 제외.',cooldownReduction:0.6},
};
export const RUNE_KEY = 'rpg:chest_rune';
export function runeTypeId(id, hasModifiers = false) {
  return `rpg:rune_${id}${hasModifiers ? '_enhanced' : ''}`;
}
export function runeKind(typeId) {
  const match = /^rpg:rune_(.+?)(?:_enhanced)?$/.exec(typeId ?? '');
  return match && Object.hasOwn(RUNES, match[1]) ? match[1] : undefined;
}
export const ALL_EQUIPMENT_IDS = [
  'rpg:stand_manifestation_arrow','rpg:dragon_choice','rpg:armor_transfer_seal',...COMMON_WEAPONS.map(w=>w.id), 'rpg:enhancement_catalyst', DESTRUCTION_WAIVER_ID, 'rpg:random_skillbook', 'rpg:stat_reset_scroll', 'rpg:job_waiver',
  ...Object.keys(ARMOR_SETS).flatMap(set=>ARMOR_PARTS.map(part=>`rpg:${set}_${part}`)),
  ...Object.keys(RUNES).map(rune=>runeTypeId(rune)),
];
const armorTypes=new Map();
for(const [set,data] of Object.entries(ARMOR_SETS))for(const part of ARMOR_PARTS){
  const baseTypeId=`rpg:${set}_${part}`,protectedTypeId=baseTypeId+'_unbreakable';
  const info={set,part,...data,baseTypeId,protectedTypeId};
  armorTypes.set(baseTypeId,info);
  armorTypes.set(protectedTypeId,info);
}
export function armorInfo(typeId){return armorTypes.get(typeId);}

// Bedrock custom wearable items do not render Java-style toughness/knockback lines.
export function armorAttributeLines(typeId){
 const info=armorInfo(typeId);if(!info)return [];
 const lines=[];
 if(info.toughness)lines.push('§9+'+info.toughness+' 내구성 (방어 강인함)');
 if(info.knockbackResistance)lines.push('§9+'+info.knockbackResistance+' 밀치기 저항 ('+(info.knockbackResistance*10)+'%)');
 return lines;
}
