export const COMMON_WEAPONS = [
  {
    "id": "rpg:common_redmoon_blade",
    "key": "redmoon_blade",
    "name": "적월선",
    "damage": 14,
    "durability": 1600,
    "optionName": "핏빛 초승달"
  },
  {
    "id": "rpg:common_battle_sword",
    "key": "magitech_sword",
    "name": "마공학 검",
    "damage": 12,
    "durability": 1400,
    "optionName": "연쇄 전류"
  },
  {
    "id": "rpg:common_magitech_greatsword",
    "key": "magitech_greatsword",
    "name": "마공학 대검",
    "damage": 12,
    "durability": 1800,
    "optionName": "지연 포격"
  },
  {
    "id": "rpg:common_battle_spear",
    "key": "elite_knight_greatsword",
    "name": "정예기사의 대검",
    "damage": 17,
    "durability": 2000,
    "optionName": "기사의 반격"
  },
  {
    "id": "rpg:common_frost_greatsword",
    "key": "frost_greatsword",
    "name": "빙설의 대검",
    "damage": 13,
    "durability": 2000,
    "optionName": "빙결 파쇄"
  },
  {
    "id": "rpg:common_flame_greatsword",
    "key": "flame_greatsword",
    "name": "화염의 대검",
    "damage": 13,
    "durability": 2000,
    "optionName": "꺼지지 않는 불씨"
  },
  {
    "id": "rpg:common_beast_axe",
    "key": "beast_axe",
    "name": "마수의 도끼",
    "damage": 14,
    "durability": 2200,
    "optionName": "포식자의 송곳니"
  }
];

const OPTION_KEY='rpg:weapon_option_fusions';
function fusionCount(item){
 const count=item?.getDynamicProperty?.(OPTION_KEY);
 return Number.isInteger(count)?Math.max(0,Math.min(6,count)):0;
}
export function weaponOptionChance(item){
 const count=fusionCount(item);
 return count?12+count*3:0;
}
export function advanceWeaponOption(item){
 const weapon=COMMON_WEAPONS.find(w=>w.id===item.typeId);
 if(!weapon)return;
 item.setDynamicProperty(OPTION_KEY,Math.min(6,fusionCount(item)+1));
 const lore=item.getLore().filter(line=>!line.startsWith('§b합성 옵션:'));
 item.setLore([...lore,`§b합성 옵션: ${weapon.optionName} · ${weaponOptionChance(item)}%`]);
}
