import test from 'node:test';
import assert from 'node:assert/strict';
import {player,players,world,events,system,intervals,ItemStack} from './minecraftMock.mjs';
import {RUNNERS as HOLY,registerHoly,curseVulnerability} from '../RPG_BP_v0552/scripts/skills/holy.js';
import {RUNNERS as BERSERKER,registerBerserker} from '../RPG_BP_v0552/scripts/skills/berserker.js';
import {RUNNERS as BLOOD,registerBloodMagic} from '../RPG_BP_v0552/scripts/skills/blood.js';
import {registerLifesteal,skillLifestealRate} from '../RPG_BP_v0552/scripts/core/lifesteal.js';
import {tickHolyRecovery} from '../RPG_BP_v0552/scripts/core/holyRecovery.js';
import {hurt} from '../RPG_BP_v0552/scripts/core/util.js';
import {SKILLS} from '../RPG_BP_v0552/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0552/scripts/data/jobs.js';
import {setSkills,setIndex,setMana,getMana,cooldownLeft} from '../RPG_BP_v0552/scripts/core/playerData.js';
import {registerInput} from '../RPG_BP_v0552/scripts/core/input.js';
registerLifesteal();registerHoly();registerBerserker();registerBloodMagic();registerInput();let serial=0;
const emit=(key,ev)=>{for(const fn of events[key].listeners)fn(ev);};
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
function scene(job='fallen_angel'){
 const p=player('b552-'+serial++,1,{health:50,maxHealth:100}),t=player('b552t-'+serial,1,{typeId:'minecraft:zombie',health:500,maxHealth:500,location:{x:0,y:64,z:2}}),hits=[];
 p.setDynamicProperty('rpg:job',job);setSkills(p,JOBS[job].skills);players.push(p);
 p.getViewDirection=()=>({x:0,y:0,z:1});p.getHeadLocation=()=>({x:0,y:65.6,z:0});
 const dim={id:'minecraft:overworld',getEntities:()=>[t],getPlayers:()=>[p],getBlock:()=>({isSolid:false}),spawnParticle(){},playSound(){}};p.dimension=t.dimension=dim;
 t.applyDamage=(n,o)=>{hits.push({n,o});const actual=Math.min(n,t.health);t.health=Math.max(0,t.health-n);emit('entityHurt',{hurtEntity:t,damage:actual,damageSource:o});return true;};t.teleport=q=>{t.location=q;};return {p,t,hits};
}
test('curse attaches through real left-click input, consumes mana once and boosts incoming damage once',()=>{
 const {p,t}=scene();p.equipment.set('Mainhand',new ItemStack(JOBS.fallen_angel.weapon));setIndex(p,JOBS.fallen_angel.skills.indexOf('fallen_orb'));setMana(p,1000);
 emit('entityHitEntity',{damagingEntity:p,hitEntity:t});assert.equal(getMana(p),50);assert.equal(cooldownLeft(p,'fallen_orb'),200);assert.equal(t.effects.get('wither').amplifier,2);assert.equal(t.effects.get('wither').duration,200);
 const before=t.health;hurt(t,p,40,'fixed');close(before-t.health,54);
});
test('curse immediately expires at 30 blocks, dimension mismatch or caster death',()=>{
 for(const change of [(p,t)=>t.location.z=30,(p,t)=>p.dimension={id:'minecraft:nether'},p=>p.health=0]){const {p,t}=scene();HOLY.fallen_orb(p,JOBS.fallen_angel,SKILLS.fallen_orb,t);assert.equal(curseVulnerability(t),.35);change(p,t);assert.equal(curseVulnerability(t),0);}
 const {p,t}=scene();t.location.z=29.99;assert.equal(HOLY.fallen_orb(p,JOBS.fallen_angel,SKILLS.fallen_orb,t),true);
});
test('curse right click sends a projectile that attaches and never applies poison',()=>{
 const {p,t}=scene(),before=intervals.length;HOLY.fallen_orb(p,JOBS.fallen_angel,SKILLS.fallen_orb);intervals[before]();assert.equal(curseVulnerability(t),.35);assert.equal(t.effects.has('poison'),false);
});
test('curse replaces the caster previous target and multiple casters cannot stack its rate',()=>{
 const a=scene(),b=scene();b.p.dimension=a.p.dimension;HOLY.fallen_orb(a.p,JOBS.fallen_angel,SKILLS.fallen_orb,a.t);HOLY.fallen_orb(b.p,JOBS.fallen_angel,SKILLS.fallen_orb,a.t);assert.equal(curseVulnerability(a.t),.35);
 HOLY.fallen_orb(a.p,JOBS.fallen_angel,SKILLS.fallen_orb,b.t);b.p.health=0;assert.equal(curseVulnerability(a.t),0);assert.equal(curseVulnerability(b.t),.35);
});
test('non-healing holy buffs exclude hostile mobs; targeted heal remains allowed without allied credit',()=>{
 const {p,t}=scene('angel');t.health=100;HOLY.holy_sword(p,JOBS.angel,SKILLS.holy_sword);HOLY.holy_shield(p,JOBS.angel,SKILLS.holy_shield);HOLY.angel_bless(p,JOBS.angel,SKILLS.angel_bless);
 assert.equal(t.health,100);assert.equal(t.effects.has('strength'),false);assert.equal(t.effects.has('resistance'),false);HOLY.holy_heal(p,JOBS.angel,SKILLS.holy_heal,t);assert.ok(t.health>100);
});
test('blessing field has regeneration V cadence, protects only allies and cooldown is 150 seconds',()=>{
 const {p,t}=scene('angel'),n=intervals.length;HOLY.angel_zone(p,JOBS.angel,SKILLS.angel_zone);intervals[n]();const hp=p.health;system.currentTick+=3;tickHolyRecovery();assert.equal(p.health,hp+1);assert.equal(t.health,500);assert.equal(SKILLS.angel_zone.cooldown,3000);
});
test('slam deals 18 explosion damage before raising its surviving enemy',()=>{
 const {p,t}=scene('mangnani'),n=intervals.length;BERSERKER.berserker_slam(p,JOBS.mangnani,SKILLS.berserker_slam);assert.equal(t.health,482);assert.equal(t.location.y,64);intervals[n]();assert.equal(t.location.y,65);
});
test('execution uses pre-hit health, strictly below 15%, and excludes scripted attacks',()=>{
 for(const [hp,expected]of [[74,0],[75,71],[76,72]]){const {p,t}=scene('mangnani');p.equipment.set('Mainhand',new ItemStack('rpg:mangnani_axe'));t.health=hp;BERSERKER.berserker_execute(p,JOBS.mangnani,SKILLS.berserker_execute);t.applyDamage(1,{cause:'entityAttack',damagingEntity:p});assert.equal(t.health,expected);}
 const {p,t}=scene('mangnani');p.equipment.set('Mainhand',new ItemStack('rpg:mangnani_axe'));BERSERKER.berserker_execute(p,JOBS.mangnani,SKILLS.berserker_execute);hurt(t,p,10,'fixed');assert.equal(t.health,490);t.applyDamage(1,{cause:'entityAttack',damagingEntity:p});assert.equal(t.health,486);
});
test('Beast berserk heals 15% of real damage, retains absorption and expires',()=>{
 const {p,t}=scene('beast');BERSERKER.beast_berserk(p,JOBS.beast,SKILLS.beast_berserk);assert.equal(p.effects.get('absorption').amplifier,3);assert.equal(skillLifestealRate(p),.15);hurt(t,p,100,'fixed');close(p.health,65);system.currentTick+=400;assert.equal(skillLifestealRate(p),0);
});
test('blood spear replaces its native damage, ignores Strength and bypasses rejected damage immunity',()=>{
 const {p,t,hits}=scene('blood_mage');p.equipment.set('Mainhand',new ItemStack('rpg:blood_spear'));p.addEffect('strength',100,{amplifier:4});t.applyDamage(1,{cause:'entityAttack',damagingEntity:p});close(t.health,486);assert.equal(hits.at(-1).o.cause,'override');
 const original=t.applyDamage;t.applyDamage=(n,o)=>o.cause==='override'?false:original(n,o);t.applyDamage(1,{cause:'entityAttack',damagingEntity:p});close(t.health,472);
});
test('blood awakening applies Wither V at one minute and reuse removes it',()=>{
 const {p}=scene('blood_mage');BLOOD.blood_awaken(p,JOBS.blood_mage,SKILLS.blood_awaken);const tick=intervals.find(fn=>String(fn).includes('now-s.start'));system.currentTick+=1199;tick();assert.equal(p.effects.has('wither'),false);system.currentTick++;tick();assert.equal(p.effects.get('wither').amplifier,4);BLOOD.blood_awaken(p,JOBS.blood_mage,SKILLS.blood_awaken);assert.equal(p.effects.has('wither'),false);
});

test('curse also amplifies immunity-bypassing raw fallback once',()=>{const {p,t}=scene();HOLY.fallen_orb(p,JOBS.fallen_angel,SKILLS.fallen_orb,t);const before=t.health;t.applyDamage=()=>false;hurt(t,p,40,'fixed',{ignoreInvulnerability:true});close(before-t.health,54);});

test('blood spear damages when vanilla invulnerability prevents any hurt event, without duplicating normal hits',()=>{
 const {p,t}=scene('blood_mage');p.equipment.set('Mainhand',new ItemStack('rpg:blood_spear'));p.addEffect('strength',100,{amplifier:4});
 t.applyDamage(1,{cause:'entityAttack',damagingEntity:p});emit('entityHitEntity',{damagingEntity:p,hitEntity:t});close(t.health,486);
 system.currentTick++;t.applyDamage=()=>false;emit('entityHitEntity',{damagingEntity:p,hitEntity:t});close(t.health,472);
});
