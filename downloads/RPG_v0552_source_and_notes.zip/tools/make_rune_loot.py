"""Add an independent rune loot pool while preserving each mob's old drops."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]
BP=ROOT/'RPG_BP_v0552'
MONSTERS=['red_mushroom','blue_mushroom','green_goblin','red_goblin','gold_goblin','goblin_captain','scorpion','mantis','deathworm']
BOSSES=['rock_golem_boss','cyclops_boss','hydra_boss','tech_block_golem_boss']
RUNE_IDS=['power','ward','mana','arcane','vitality','absorption']
TIERS={**{m:1 for m in MONSTERS},**{'elite_'+m:3 for m in MONSTERS},**{m:30 for m in BOSSES}}

def is_rune_pool(pool):
    entries=pool.get('entries',[])
    return any(e.get('name','').startswith('rpg:rune_') for e in entries) and all(e.get('type')=='empty' or e.get('name','').startswith('rpg:rune_') for e in entries)

def write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

for name,percent in TIERS.items():
    path=BP/'entities'/f'{name}.json'
    entity=json.loads(path.read_text());components=entity['minecraft:entity']['components']
    original=components.get('minecraft:loot',{}).get('table')
    table=json.loads((BP/original).read_text()) if original else {'pools':[]}
    table['pools']=[p for p in table['pools'] if not is_rune_pool(p)]
    entries=[{'type':'item','name':'rpg:rune_'+r,'weight':percent} for r in RUNE_IDS]
    empty_weight=len(RUNE_IDS)*(100-percent)
    if empty_weight:entries.append({'type':'empty','weight':empty_weight})
    table['pools'].append({'rolls':1,'entries':entries})
    relative=f'loot_tables/entities/rpg_runes_{name}.json'
    write(BP/relative,table)
    components['minecraft:loot']={'table':relative}
    write(path,entity)
print(f'Updated {len(TIERS)} mob loot tables: normal 1%, elite 3%, boss 30%.')
