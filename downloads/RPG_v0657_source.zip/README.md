# RPG v0.6.57 · 공용 무기 합성 옵션

+10 공용 무기를 주장비로 합성에 성공하면 해당 무기의 고유 옵션이 열립니다. 무기에 기록된 성공 횟수에 따라 평타 적중 시 발동률은 15%, 18%, 21%, 24%, 27%, 30%입니다. 승급 후 +0부터 다시 강화해 다음 승급에 도전할 수 있습니다. 무기 설명에서 옵션과 발동률을 확인하세요.

| 무기 | 효과 |
| --- | --- |
| 적월선 | 표식을 남기고 3초 안에 재타격하면 첫 평타 피해의 60% 추가 |
| 마공학 검 | 4블록 안의 다른 적에게 두 차례 연쇄 전류. 첫 대상 80%, 다음 대상 50% |
| 마공학 대검 | 0.8초 뒤 반경 2.5블록에 평타 피해의 65% |
| 정예기사의 대검 | 3초 안에 받는 다음 적 공격의 35%를 방어하고 반격. 피해 전 이벤트를 지원하지 않는 환경에서는 생존 시 피해 일부를 회복 |
| 빙설의 대검 | 둔화 II 부여 후 2초 내 재타격 시 주변 적에게 35% 피해 |
| 화염의 대검 | 1초마다 15% 피해를 3회 부여. 불씨가 붙은 대상이 죽으면 3블록 내 다른 적에게 이전 |
| 마수의 도끼 | 30% 추가 피해. 타격 전 체력 30% 이하인 적에게는 75% 추가 피해와 사용자 체력 2 회복 |

아이템 기본 피해는 적월선 14, 정예기사의 대검 17, 마공학 검 12입니다. 무기 강화 촉매는 현재 +3인 무기를 +4로 강화할 때부터 사용할 수 있습니다.

천사는 노란 금빛 깃털, 미카엘은 사파이어 블루와 흰색 깃털을 장착합니다. 타락천사는 기존 적흑색 날개를 사용합니다. Bedrock 1.21.100 이상에서 세 팩을 모두 v0.6.57로 활성화하세요.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0657
```
