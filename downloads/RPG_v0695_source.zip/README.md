# RPG v0.6.95 · 플레이어 간 피해 8%

- 결투와 일반 지역에서 플레이어에게 귀속되는 평타·투사체·스킬의 대인 피해에 ×0.08을 적용합니다. 다른 보정이 같을 때 기존에 100 피해를 주는 공격은 8 피해를 줍니다. 가해자가 기록되지 않는 환경 피해에는 일반 피해 규칙을 적용합니다.
- 복수귀 처형은 플레이어에게 기본 50의 타격 피해를 사용하고, 망나니·야수의 처형은 플레이어에게 강화 평타로 적용됩니다. 두 타격 모두 대인 피해 8% 규칙을 따릅니다.
- 공격자의 스탯과 장비, 대상의 방어 보정과 함께 적용됩니다. 같은 타격에서 이미 반영한 대인 배율은 치명타와 추가 피해 계산에 한 번만 반영합니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.95로 활성화하세요. 피해 센서와 모의 전투를 검증했습니다. 샘플 스킬 검사는 근력 40, 레어 힘의 룬 +10, 투신 무기 +6, 힘 버프나 상대 방어구 없이 수행했습니다. 실제 Bedrock에서의 PvP는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0695
```
