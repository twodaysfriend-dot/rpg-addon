import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0638'),base=root+'/RPG_BP_v0638/scripts/';
async function dataModule(file){const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'));await m.link(()=>{});await m.evaluate();return m.namespace;}
const data=await dataModule('data/dungeons.js');
async function setup(initial=[],options={}){
 const props=new Map([['rpg:dungeons_v1',JSON.stringify({version:2,nextRun:1,dungeons:initial,legacyDungeons:[],outbox:[]})]]),blocks=new Map(),messages=[],commands=[];
 let writes=0,glitchCount=0;const active=new Map(),lobbies=new Map();const system={currentTick:0,runInterval:()=>1,runTimeout:()=>1};
 const p={id:'admin',typeId:'minecraft:player',playerPermissionLevel:2,location:{x:0,y:64,z:0},dimension:{id:'minecraft:overworld'},sendMessage:s=>messages.push(s)};
 const dim={id:p.dimension.id,runCommand:s=>{commands.push(s);return {successCount:1};},getBlock:at=>{
  if(options.glitch&&glitchCount++===5000){const e=Error('temporarily unloaded');e.name='UnloadedChunkError';throw e;}
  const key=[at.x,at.y,at.z].join(',');return {get isAir(){return !blocks.has(key);},get typeId(){return blocks.get(key)??'minecraft:air';},setType:type=>{blocks.set(key,type);writes++;}};
 },getEntities:()=>[]};
 const world={getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),getDimension:()=>dim,getAllPlayers:()=>[p]};
 const bindings={...Object.fromEntries(Object.keys(data).map(k=>[k,data[k]])),world,system,dungeonRuns:active,dungeonLobbies:lobbies,isRpgAdmin:player=>player.playerPermissionLevel===2,notify:()=>{},...options.bindings};
 const ctx=vm.createContext({console});const placement=new vm.SourceTextModule(fs.readFileSync(base+'core/dungeonPlacement.js','utf8'),{context:ctx});const dataExports=Object.keys(data);const dmod=new vm.SyntheticModule(dataExports,function(){for(const n of dataExports)this.setExport(n,data[n]);},{context:ctx});await placement.link(()=>dmod);await placement.evaluate();bindings.newDungeonSite=placement.namespace.newDungeonSite;
 const source=fs.readFileSync(base+'core/dungeons.js','utf8'),m=new vm.SourceTextModule(source,{context:ctx});
 await m.link(async spec=>{const names=[];for(const hit of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(hit[2]===spec)names.push(...hit[1].split(',').map(n=>n.trim().split(/\s+as\s+/)[0]));return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context:ctx});});await m.evaluate();
 const api=m.namespace;return {api,p,dim,blocks,messages,commands,props,system,active,placement:placement.namespace,get writes(){return writes;},tick(){system.currentTick++;api.dungeonTick();}};
}
const firstNine=Array.from({length:9},(_,i)=>({id:'dungeon_'+(i+1),tier:i+1,shape:'cave_v2',dimId:'minecraft:overworld',x:i%5*80,y:128,z:Math.floor(i/5)*80,status:'ready',buildRevision:3}));
{
 const {DUNGEON_NATIVE_XP}=await dataModule('data/dungeonNativeXp.js');
 for(const tier of [5,6,7,8,9,10]){
  const d={id:'dungeon_'+tier,tier,x:12,y:64,z:12,dimId:'minecraft:overworld'};
  const spawned=[];
  const t=await setup([d],{bindings:{
   healthAlive:()=>true,insideDungeon:()=>true,ItemStack:class {},
   applyMonsterLevel:(mob,level,context)=>{mob.kind=context.kind;assert.equal(context.tier,tier);},
   DUNGEON_NATIVE_XP,levelRewardMultiplier:()=>1,
  }});
  t.dim.spawnEntity=(typeId,location)=>{
   const mob={id:String(spawned.length),typeId,location,dimension:t.dim,addTag:()=>{},
    triggerEvent:id=>assert.equal(id,'rpg:dungeon_tier_'+tier),getComponent:()=>({currentValue:100})};
   spawned.push(mob);return mob;
  };
  t.dim.spawnItem=()=>{};
  const now=Date.now();
  const run={id:tier,d,phase:'mobs',initialPartySize:1,members:[{id:t.p.id}],live:new Map(),normalSpawned:0,
   eliteSpawned:0,normalKilled:0,eliteKilled:0,startedAt:now,deadline:now+60000};
  t.active.set(d.id,run);
  for(let batch=0;batch<60&&run.phase==='mobs';batch++){
   run.nextNormalAt=0;run.nextEliteAt=0;
   t.tick();
   for(const {mob} of [...run.live.values()])if(mob.kind!=='boss')t.api.dungeonDeath({deadEntity:mob});
  }
  assert.equal(run.phase,'boss');
  assert.equal(spawned.filter(m=>m.kind==='normal').length,50);
  assert.equal(spawned.filter(m=>m.kind==='elite').length,5);
  assert.equal(spawned.filter(m=>m.kind==='boss').length,1);
  const expectedBoss=tier<=6?'cyclops_boss':tier<=8?'tech_block_golem_boss':'hydra_boss';
  assert.equal(spawned.at(-1).typeId,'rpg:'+expectedBoss);
  assert.ok(spawned.every(m=>!/(mushroom|red_goblin)/.test(m.typeId)));
  const count=(id,kind)=>spawned.filter(m=>m.typeId==='rpg:'+id&&m.kind===kind).length;
  assert.equal(count('deathworm','normal'),tier===8?13:tier>=9?10:0);
  assert.equal(count('goblin_captain','normal'),tier>=9?10:0);
  assert.equal(count('elite_deathworm','elite'),tier===10?2:0);
  assert.equal(run.vanillaXp,spawned.filter(m=>m.kind!=='boss').reduce((xp,mob)=>xp+DUNGEON_NATIVE_XP[mob.typeId],0));
 }
 console.log('Tier 5–10 live spawn loop: no mushrooms/red goblins, exactly ten captains on tiers 9/10, deathworms on tiers 8–10, two elite deathworms on tier 10, XP pooled and boss appears after all 55 kills');
}
{
 for(const [tier,party,job,qualifies]of [[4,1,'bloodedge',false],[4,2,'bloodedge',false],[5,2,'bloodedge',true],[5,2,'mage',false],[5,1,'mage',false],[5,1,'bloodedge',true],[9,1,'bloodedge',true],[9,2,'bloodedge',true]]){
  const awards=[],missions=[];
  const bindings={healthAlive:()=>true,insideDungeon:()=>true,isActiveNearbyPlayer:()=>true,levelRewardMultiplier:()=>1,
   getJobId:()=>job,recordCrimsonTrial:p=>awards.push(p.id),creditDungeonClear:()=>({ok:true}),claimDungeonLoot:()=>({pending:0}),
   creditChameleonDungeon:(p,receipt)=>missions.push([p.id,receipt.tier,receipt.solo,receipt.startedAt,receipt.runId])};
  const t=await setup(firstNine,{bindings});
  const d=firstNine[tier-1],boss={id:'test-boss',typeId:'rpg:hydra_boss'};
  t.p.getDynamicProperty=()=>undefined;
  const startedAt=Date.now();
  const run={id:123,d,initialPartySize:party,phase:'boss',bossId:boss.id,startedAt,deadline:startedAt+30000,
   live:new Map([[boss.id,{kind:'boss',mob:boss}]]),members:[{id:t.p.id}]};
  t.active.set(d.id,run);
  t.api.dungeonDeath({deadEntity:boss});
  assert.equal(t.active.size,0);
  assert.deepEqual(awards,qualifies?[t.p.id]:[]);
  assert.deepEqual(missions,[[t.p.id,tier,party===1,startedAt,123]]);
 }
 console.log('Crimson trial records real boss clears from tier 5 for surviving solo and party participants with the correct job at clear');
}
{
 const t=await setup(firstNine,{glitch:true});const result=t.api.createDungeon(t.p,'10');assert.equal(result.tiers[0],10);let dungeon=t.api.listDungeons().find(d=>d.tier===10);assert.equal(dungeon.x,320);assert.equal(dungeon.z,80);for(const old of firstNine)assert.equal(t.placement.dungeonSitesOverlap(dungeon,old),false);
 assert.equal(t.api.createDungeon(t.p,'10').alreadyBuilding,true);let ticks=0;while(t.api.listDungeons().find(d=>d.tier===10).status!=='ready'&&ticks++<3000)t.tick();dungeon=t.api.listDungeons().find(d=>d.tier===10);assert.equal(dungeon.status,'ready');let expected=0;
 for(let y=0;y<=data.DUNGEON.height;y++)for(let x=-32;x<=32;x++)for(let z=-32;z<=32;z++)if(data.inCaveVolume(x,y,z)){const type=data.dungeonBlock(x,y,z);if(type){expected++;assert.equal(t.blocks.get([dungeon.x+x,dungeon.y+y,dungeon.z+z].join(',')),type);}}
 assert.equal(t.blocks.size,expected);assert.ok(t.messages.some(s=>s.includes('10 생성·완성 검사 완료')));assert.ok(t.commands.at(-1).startsWith('tickingarea remove '));
 const key=[dungeon.x,dungeon.y,dungeon.z].join(',');t.blocks.delete(key);t.api.createDungeon(t.p,10);ticks=0;while(t.api.listDungeons().find(d=>d.tier===10).status!=='ready'&&ticks++<3000)t.tick();assert.equal(t.blocks.get(key),'minecraft:sea_lantern');
 console.log('Tier 10: created with 1–9 already registered, complete shell verified, one chunk interruption, repeat status, missing-floor repair passed');
}
{
 const t=await setup();t.api.createDungeon(t.p,'all');let ticks=0;while(t.api.listDungeons().some(d=>d.status!=='ready')&&ticks++<20000)t.tick();assert.ok(t.api.listDungeons().every(d=>d.status==='ready'));assert.equal(t.api.listDungeons().length,10);
 console.log('All-tier creation: ten nonoverlapping dungeons reach ready, including tier 10');
}
{
 const t=await setup();t.api.createDungeon(t.p,10);let ticks=0;while(t.writes<500&&ticks++<2000)t.tick();assert.ok(t.writes>0);const written=t.blocks.size;t.api.recoverDungeons();ticks=0;while(t.api.listDungeons().find(d=>d.tier===10).status!=='ready'&&ticks++<3000)t.tick();assert.equal(t.api.listDungeons().find(d=>d.tier===10).status,'ready');assert.ok(t.blocks.size>written);
 console.log('Partially built tier 10 survives recovery and completes without erasing placed blocks');
}
