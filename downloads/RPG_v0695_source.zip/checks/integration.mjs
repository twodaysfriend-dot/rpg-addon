import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0638');
const bp=path.join(root,'RPG_BP_v0638/scripts');
const signals=new Map();function signal(key){if(!signals.has(key))signals.set(key,{callbacks:[],subscribe(fn){this.callbacks.push(fn);},fire(e){for(const fn of this.callbacks)fn(e);}});return signals.get(key);}
const events=new Proxy({},{get:(o,k)=>signal(k)});let time=1000;
const world={afterEvents:events,beforeEvents:{},getTimeOfDay:()=>time,getAllPlayers:()=>[],getDay:()=>1,getDynamicProperty:()=>undefined};
const timers=[];const system={currentTick:10,beforeEvents:events,afterEvents:events,run:fn=>{timers.push(fn);return timers.length;},runTimeout:fn=>{timers.push(fn);return timers.length;},runInterval:()=>1,clearRun:()=>{}};
const itemDirectory=path.join(root,'RPG_BP_v0638/items');
const runeStackLimits=new Map(fs.readdirSync(itemDirectory).filter(name=>/^rune_.*\.json$/.test(name)).map(name=>{
 const item=JSON.parse(fs.readFileSync(path.join(itemDirectory,name)))['minecraft:item'];
 return [item.description.identifier,item.components['minecraft:max_stack_size']];
}));
class ItemStack{
 constructor(id,amount=1){this.typeId=id;this.amount=amount;this.props=new Map();this.lore=[];this.lockMode='none';this.keepOnDeath=false;this.durability={damage:0,maxDurability:1600};}
 clone(){const n=new ItemStack(this.typeId,this.amount);n.props=new Map(this.props);n.lore=[...this.lore];n.nameTag=this.nameTag;n.lockMode=this.lockMode;n.keepOnDeath=this.keepOnDeath;n.durability={...this.durability};n.enchants=this.enchants?.map(e=>({type:{...e.type},level:e.level}));return n;}
 get maxAmount(){return runeStackLimits.get(this.typeId)??64;}
 isStackableWith(other){return this.maxAmount>1&&this.typeId===other.typeId&&!this.props.size&&!other.props.size&&!this.nameTag&&!other.nameTag;}
 get amount(){return this._amount;}set amount(n){if(!Number.isInteger(n)||n<1||n>this.maxAmount)throw Error('Native ItemStack amount must stay within its stack limit');this._amount=n;}
 getDynamicProperty(k){return this.props.get(k);}setDynamicProperty(k,v){if(runeStackLimits.get(this.typeId)>1)throw Error('Native dynamic properties require a non-stackable rune');if(v===undefined)this.props.delete(k);else this.props.set(k,v);}getDynamicPropertyIds(){return [...this.props.keys()];}getLore(){return this.lore;}setLore(v){this.lore=v;}getComponent(id){if(id==='minecraft:durability')return this.durability;if(id==='minecraft:enchantable')return {getEnchantments:()=>this.enchants??[]};}
}
class Form{title(){return this;}body(){return this;}button(){return this;}button1(){return this;}button2(){return this;}textField(){return this;}dropdown(){return this;}show(){return Promise.resolve({canceled:true});}}
const server={world,system,ItemStack,ItemLockMode:{slot:'slot',none:'none'},EquipmentSlot:{Mainhand:'Mainhand',Offhand:'Offhand',Head:'Head',Chest:'Chest',Legs:'Legs',Feet:'Feet'},EntityDamageCause:{override:'override',entityAttack:'entityAttack'},CustomCommandStatus:{Success:0,Failure:1},CommandPermissionLevel:{Any:0,GameDirectors:1},CustomCommandParamType:{String:0,Integer:1},BlockTypes:{get:id=>({id})}};
const ui={ActionFormData:Form,MessageFormData:Form,ModalFormData:Form};
server.BlockPermutation={resolve:type=>({type})};
const context=vm.createContext({console});const modules=new Map(),externalNames=new Map();
function discover(file){file=path.resolve(file);if(modules.has(file))return;const source=fs.readFileSync(file,'utf8');const m=new vm.SourceTextModule(source,{context,identifier:file});modules.set(file,m);
 for(const hit of source.matchAll(/import\s+(?:\{([^}]+)\}|\*\s+as\s+\w+)\s*from\s*['"]([^'"]+)['"]/g)){
  const spec=hit[2];if(spec.startsWith('.'))discover(path.resolve(path.dirname(file),spec));else{const names=externalNames.get(spec)??new Set();for(const n of (hit[1]??'').split(',').filter(Boolean))names.add(n.trim().split(/\s+as\s+/)[0]);externalNames.set(spec,names);}
 }
}
const wingsOnly=process.argv.includes('--gameplay-only-wings');
const commandPack=path.join(root,'RPG_Commands_BP_v0638/scripts/commands.js');
discover(path.join(bp,'gameplayEntry.js'));if(!wingsOnly){discover(path.join(bp,'commandBootstrap.js'));discover(commandPack);}
for(const [spec,names]of externalNames){const values=spec==='@minecraft/server'?server:ui;for(const n of Object.keys(values))names.add(n);const m=new vm.SyntheticModule([...names],function(){for(const n of names)this.setExport(n,values[n]??{});},{context,identifier:spec});modules.set(spec,m);}
const linker=(spec,parent)=>modules.get(spec.startsWith('.')?path.resolve(path.dirname(parent.identifier),spec):spec);
for(const m of modules.values())if(m.status==='unlinked')await m.link(linker);
for(const entry of (wingsOnly?['gameplayEntry.js']:['gameplayEntry.js','commandBootstrap.js']))await modules.get(path.join(bp,entry)).evaluate();
if(!wingsOnly)await modules.get(commandPack).evaluate();
const mod=file=>modules.get(path.join(bp,file)).namespace;
console.log('Complete active gameplay and command module graph linked/evaluated');
function player(job='swordsman'){
 const props=new Map([['rpg:job',job]]),items=Array(12),messages=[],tags=new Set();
 const inv={size:12,getItem:i=>items[i]?.clone(),setItem:(i,v)=>{items[i]=v?.clone();},addItem:item=>{const i=items.findIndex(x=>!x);if(i<0)return item;items[i]=item.clone();}};
 const health={currentValue:50,effectiveMax:100,setCurrentValue(v){const old=this.currentValue;this.currentValue=v;signal('entityHealthChanged').fire({entity:p,oldValue:old,newValue:v});}};
 const dim={id:'minecraft:overworld',getWeather:()=> 'Clear',getTopmostBlock:()=>({location:{y:63}}),spawnItem:()=>{throw Error('unexpected item drop');},playSound:()=>{}};
 const p={id:'player',name:'tester',typeId:'minecraft:player',isValid:true,selectedSlotIndex:0,location:{x:0,y:64,z:0},dimension:dim,onScreenDisplay:{setTitle:()=>{},setActionBar:()=>{}},getHeadLocation:()=>({x:0,y:65.6,z:0}),getGameMode:()=> 'survival',getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>{if(v===undefined)props.delete(k);else props.set(k,v);},getDynamicPropertyIds:()=>[...props.keys()],getComponent:id=>id==='minecraft:inventory'?{container:inv}:id==='minecraft:health'?health:id==='minecraft:equippable'?{getEquipment:()=>inv.getItem(p.selectedSlotIndex),setEquipment:(slot,item)=>{inv.setItem(p.selectedSlotIndex,item);return true;}}:undefined,hasTag:t=>tags.has(t),addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),getTags:()=>[...tags],sendMessage:s=>messages.push(s),getEffect:()=>undefined};
 return {p,props,items,inv,health,messages};
}
if(wingsOnly){
 const registry=new Map();
 signal('startup').fire({itemComponentRegistry:{registerCustomComponent:()=>{}},customCommandRegistry:{registerCommand:(d,fn)=>{assert.ok(d.name.includes(':'));assert.ok(!registry.has(d.name));registry.set(d.name,{d,fn});}}});
 const wings=mod('core/wings.js');
 for(const job of ['angel','michael']){
  const {p}=player(job);p.id='standalone-'+job;
  p.runCommand=()=>{throw Error('Commands BP is absent and no relay is allowed');};
  for(const [mode,multiplier]of [[1,1],[2,2],[3,5]]){
   const parsed=registry.get('rpg:wings');assert.equal(parsed.d.optionalParameters[0].type,server.CustomCommandParamType.Integer);
   parsed.fn({sourceEntity:p},mode);timers.at(-1)();assert.equal(wings.wingSpeedMultiplier(p),multiplier);
   const fixed=registry.get('rpg:wings'+mode);assert.equal(fixed.d.optionalParameters,undefined);
   fixed.fn({sourceEntity:p});timers.at(-1)();assert.equal(wings.wingSpeedMultiplier(p),multiplier);
  }
 }
 assert.equal(registry.size,14);
 const cleaner=registry.get('rpg:cleaner');
 assert.equal(cleaner.d.permissionLevel,server.CommandPermissionLevel.GameDirectors);
 assert.equal(cleaner.d.cheatsRequired,false);
 const force=registry.get('rpg:force');
 assert.equal(force.d.permissionLevel,server.CommandPermissionLevel.GameDirectors);
 assert.equal(force.d.cheatsRequired,false);
 assert.equal(force.d.optionalParameters.length,2);
 const forced=player('apprentice');
 forced.p.id='force-standalone';
 forced.p.playerPermissionLevel=2;
 forced.p.runCommand=()=>assert.fail('Gameplay BP /rpg:force must not relay a command');
 force.fn({sourceEntity:forced.p},'진홍의','군주');
 await timers.at(-1)();
 assert.equal(forced.p.getDynamicProperty('rpg:job'),'crimson_lord');
 assert.equal(forced.inv.getItem(0).typeId,'rpg:bloodedge_scythe');
 assert.equal(registry.get('rpg:jobchange').d.permissionLevel,server.CommandPermissionLevel.Any);
 assert.equal(registry.get('rpg:jobchange').d.cheatsRequired,false);
 assert.equal(registry.get('rpg:jailcreate').d.optionalParameters[0].type,server.CustomCommandParamType.Integer);
 assert.equal(registry.get('rpg:jailreset').d.optionalParameters[0].type,server.CustomCommandParamType.String);
 const {p,inv}=player();p.commandPermissionLevel=1;
 p.runCommand=()=>assert.fail('Gameplay BP grade command must not relay');
 inv.setItem(0,new ItemStack('rpg:common_redmoon_blade'));
 registry.get('rpg:setgrade').fn({sourceEntity:p},'신화','hand');
 timers.at(-1)();assert.equal(inv.getItem(0).getDynamicProperty('rpg:rarity'),6);
 console.log('Standalone gameplay BP registers wings, prison and grade commands; direct grade writes without a relay');
 process.exit(0);
}
{
 const social=mod('core/social.js'),oldRead=world.getDynamicProperty,oldOnline=world.getAllPlayers;
 const owner=player().p,editor=player().p;owner.id='shared-owner';owner.name='Owner';editor.id='shared-editor';editor.name='Editor';
 const outsider=player().p;outsider.id='outsider-id';outsider.name='SharedGuest';
 const partyEditor=player().p;partyEditor.id='party-editor';partyEditor.name='PartyEditor';
 const saved={version:1,nextId:4,guilds:[{id:1,name:'Guild',leader:'Owner',members:['Owner','Editor']},{id:2,name:'OtherGuild',leader:'SharedGuest',members:['SharedGuest']}],parties:[{id:3,leader:'Owner',members:['Owner','PartyEditor']}]};
 world.getDynamicProperty=key=>key==='rpg:social_v1'?JSON.stringify(saved):oldRead(key);world.getAllPlayers=()=>[];
 // This is the first social state load: it must use the persisted roster even offline.
 assert.equal(social.sharesBuildingGroup(editor,{id:owner.id,name:owner.name}),true);
 assert.equal(social.sharesBuildingGroup(outsider,{id:owner.id,name:owner.name}),false);
 const estate=mod('core/realEstate.js'),town=mod('core/townProtection.js'),region={x:0,y:64,z:0,size:250,dimId:owner.dimension.id};
 const block={dimension:owner.dimension,location:{x:32,y:70,z:32}};
 const selection=estate.landSelection({dimension:block.dimension,location:block.location},region);
 const oldProps=world.getDynamicProperty,land=JSON.stringify({[selection.key]:{id:owner.id,name:owner.name}});
 world.getDynamicProperty=key=>key===estate.LAND_KEY?land:oldProps(key);
 assert.equal(estate.canEditTownChunk(partyEditor,block,region),true);
 outsider.addTag('rpg_guild_1');outsider.addTag('rpg_team_test');assert.equal(estate.canEditTownChunk(outsider,block,region),false);
 assert.equal(estate.canEditTownChunk(editor,block,region),true);assert.equal(estate.ownsTownChunk(editor,block,region),false);
 assert.equal(town.townProtected(block,region,editor),false);assert.equal(town.townProtected(block,region,outsider),true);
 for(const y of [64,63,-64])assert.equal(town.townProtected({...block,location:{...block.location,y}},region,editor),true);
 assert.equal(town.townProtected({...block,location:{...block.location,y:64}},region,editor,'support'),false);
 // Exercise real leave-group UI. Mutate serializes and replaces cached social state.
 const oldShow=Form.prototype.show,oldWrite=world.setDynamicProperty;let serialized;
 world.setDynamicProperty=(key,value)=>{if(key==='rpg:social_v1')serialized=value;};
 try{
  const replies=[{selection:2},{selection:1},{canceled:true}]; // member's guild page: members, base travel, leave
  Form.prototype.show=()=>Promise.resolve(replies.shift()??{canceled:true});await social.openGuildMenu(editor);
  assert.ok(serialized);assert.equal(social.sharesBuildingGroup(editor,{id:owner.id,name:owner.name}),false);
  assert.equal(estate.canEditTownChunk(editor,block,region),false);
  assert.equal(estate.canEditTownChunk(partyEditor,block,region),true);
  const partyReplies=[{selection:1},{selection:1},{canceled:true}];Form.prototype.show=()=>Promise.resolve(partyReplies.shift()??{canceled:true});await social.openPartyMenu(partyEditor);
  assert.equal(estate.canEditTownChunk(partyEditor,block,region),false);
  assert.equal(estate.canEditTownChunk(owner,block,region),true);
 }finally{Form.prototype.show=oldShow;world.setDynamicProperty=oldWrite;world.getDynamicProperty=oldRead;world.getAllPlayers=oldOnline;}
 console.log('Shared building: saved guild membership grants offline-owner access; real guild/party leave immediately revokes edits; unrelated guild and forged tags excluded; guests rejected and floor/underground stay protected');
}
const races=mod('core/races.js'),data=mod('core/playerData.js'),jobs=mod('data/jobs.js').JOBS,binding=mod('core/weaponBinding.js'),advance=mod('core/advance.js');
{
 const {p,inv}=player();assert.equal(races.raceOf(p),'human');inv.setItem(0,new ItemStack('rpg:stone_mask',2));assert.equal(races.useStoneMask(p).ok,true);assert.equal(inv.getItem(0).amount,1);assert.equal(races.raceOf(p),'vampire');assert.equal(races.useStoneMask(p).ok,false);assert.equal(inv.getItem(0).amount,1);
 assert.equal(races.sunDamageMultiplier(p),1.5);p.dimension.getTopmostBlock=()=>({location:{y:70}});assert.equal(races.sunDamageMultiplier(p),1);p.dimension.getTopmostBlock=()=>({location:{y:63}});time=13000;assert.equal(races.sunDamageMultiplier(p),1);time=1000;
 data.setJobId(p,'mage');assert.equal(races.raceOf(p),'human');data.setJobId(p,'blood_mage');assert.equal(races.raceOf(p),'vampire');data.setJobId(p,'revenant');assert.equal(races.raceOf(p),'undead');
}
console.log('Races: mask consumption, redundant use, daylight/shade/night, job resets passed');
{
 const {p,inv}=player();inv.setItem(0,new ItemStack(jobs.swordsman.weapon));const w=new ItemStack('rpg:common_redmoon_blade');w.setDynamicProperty('rpg:weapon_upgrade',5);w.setDynamicProperty('rpg:rarity','epic');w.nameTag='chosen';w.durability.damage=123;inv.setItem(4,w);
 assert.equal(binding.bindCommonWeapon(p,4).ok,true);assert.equal(inv.getItem(0).nameTag,'chosen');assert.equal(inv.getItem(4).typeId,jobs.swordsman.weapon);const uid=inv.getItem(0).getDynamicProperty(binding.WEAPON_UID);
 advance.applyAdvance(p,jobs.sword_saint);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);assert.equal(inv.getItem(0).durability.damage,123);assert.equal(mod('core/context.js').getContext(p).substitute,true);assert.equal(mod('core/util.js').skillItemId(p),jobs.sword_saint.weapon);
 advance.applyAdvance(p,jobs.mage);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);assert.equal(mod('core/context.js').getContext(p).job.id,'mage');
 const upgraded=mod('core/gearState.js').setGearLevel(inv.getItem(0),'weapon',6);inv.setItem(0,upgraded);advance.ensureWeapon(p);assert.equal(inv.getItem(0).getDynamicProperty('rpg:weapon_upgrade'),6);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);
 const slot1=inv.getItem(0);inv.setItem(0,undefined);inv.setItem(8,slot1);advance.ensureWeapon(p);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);assert.equal(inv.getItem(8),undefined);
 inv.setItem(0,undefined);advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,jobs.mage.weapon);assert.equal(binding.weaponBinding(p),undefined);
}
console.log('Weapon binding: metadata/upgrade preservation, both advancements, job switch, moved-item recovery, break fallback passed');
{
 const {p,inv}=player();inv.setItem(0,new ItemStack(jobs.swordsman.weapon));inv.setItem(3,new ItemStack('rpg:common_redmoon_blade'));binding.bindCommonWeapon(p,3);data.setJobId(p,'the_world');data.setSkills(p,jobs.the_world.skills);assert.equal(mod('core/context.js').getContext(p).job.id,'the_world');
 binding.releaseWeaponBinding(p);advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,jobs.the_world.weapon);assert.equal(Array.from({length:inv.size},(_,i)=>inv.getItem(i)).filter(i=>i?.typeId==='rpg:common_redmoon_blade').length,1);
}
console.log('Weapon release preserves exactly one original common weapon');
{
 const {p,health}=player('the_world');const target={id:'enemy',typeId:'minecraft:zombie'};const life=mod('core/lifesteal.js');assert.equal(life.healLifesteal(p,target,20),2);health.currentValue=99;assert.equal(life.healLifesteal(p,target,20),1);data.setJobId(p,'swordsman');assert.equal(life.healLifesteal(p,target,20),0);
 const amounts=mod('core/damageAmounts.js');amounts.noteHealthChange({entity:target,oldValue:3,newValue:0});assert.equal(amounts.actualHurtAmount({hurtEntity:target,damage:100}),3);
}
console.log('Vampire 10% actual-damage lifesteal and overheal/overkill cap passed');
{
 const {p,messages}=player('mage');const trial=mod('core/jobTrials.js');for(let i=0;i<55;i++)trial.recordJobTrialKill(p,{typeId:'minecraft:stray'});assert.equal(messages.length,6);assert.equal(messages[0],'§r§l§b(???/50)');assert.equal(messages[5],'§r§l§b(50/50)');messages.length=0;for(let i=0;i<55;i++)trial.recordJobTrialKill(p,{typeId:'minecraft:blaze'});assert.equal(messages.length,6);assert.equal(messages[5],'§r§l§6(50/50)');
}
console.log('Stray/Blaze counters: exactly 1/10/20/30/40/50 announcements, colors and completion passed');
{
 const {p,inv}=player();mod('core/wallet.js').setWallet(p,{gold:10000000,stone:100000,dust:1000});inv.setItem(0,new ItemStack(jobs.swordsman.weapon));inv.setItem(5,new ItemStack('rpg:common_redmoon_blade'));binding.bindCommonWeapon(p,5);
 const uid=inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),upgrade=mod('core/upgrades.js');let quote=upgrade.enhancementQuote(p,'weapon','Mainhand');let result=upgrade.enhanceEquipped(p,'weapon','Mainhand',quote.fingerprint,{random:()=>0});assert.equal(result.ok,true);assert.equal(result.outcome,'success');assert.equal(inv.getItem(0).getDynamicProperty('rpg:weapon_upgrade'),1);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);
 inv.setItem(0,mod('core/gearState.js').setGearLevel(inv.getItem(0),'weapon',9));quote=upgrade.enhancementQuote(p,'weapon','Mainhand');result=upgrade.enhanceEquipped(p,'weapon','Mainhand',quote.fingerprint,{random:()=>.999});assert.equal(result.outcome,'destroy');advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,jobs.swordsman.weapon);assert.equal(binding.weaponBinding(p),undefined);
}
console.log('Actual upgrade transaction: success stays in slot 1, destruction restores class item passed');
{
 const {p,health}=player('cleric');health.currentValue=50;
 const target={id:'mob',typeId:'minecraft:zombie',isValid:true,location:{x:0,y:64,z:1},getTags:()=>[],getComponent:id=>id==='minecraft:health'?{currentValue:100}:undefined,applyDamage(amount){this.damage=amount;return true;}};
 const holy=mod('skills/holy.js');assert.equal(holy.holyMonsterDamage(p,target,20),true);assert.equal(target.damage,60);assert.equal(holy.holyMonsterDamage(p,p,20),false);
 const allyHeal=mod('core/holyRecovery.js').healHolyAlly(p,p,20);assert.equal(allyHeal,20);assert.equal(health.currentValue,70);
}
console.log('Holy healing: monster takes exactly healing x3, allied healing remains unchanged');
function filter(f,monster,sun,undead=false){
 if(f.all_of&&!f.all_of.every(x=>filter(x,monster,sun,undead)))return false;
 if(f.any_of&&!f.any_of.some(x=>filter(x,monster,sun,undead)))return false;
 if(f.none_of&&f.none_of.some(x=>filter(x,monster,sun,undead)))return false;
 if(!f.test)return true;
 const val=f.test==='is_family'?(f.value==='monster'?monster:false):f.test==='has_tag'?(f.value==='rpg_vampire_sun'?sun:f.value==='rpg_undead'?undead:false):false;
 return f.operator==='!='?!val:val;
}
{
 const json=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0638/entities/player.json'),'utf8'))['minecraft:entity'];
 for(const [m,s,expected]of [[true,false,1],[true,true,1.5],[false,true,1.5],[false,false,1]]){
  const hits=json.components['minecraft:damage_sensor'].triggers.filter(t=>filter(t.on_damage.filters,m,s));assert.equal(hits.length,1);assert.equal(hits[0].damage_multiplier,expected);
  for(const [id,g]of Object.entries(json.component_groups))if(id.startsWith('rpg:ward_defense_')){
   const hits=g['minecraft:damage_sensor'].triggers.filter(t=>filter(t.on_damage.filters,m,s));assert.equal(hits.length,1);const index=Number(id.split('_').at(-1));assert.ok(Math.abs(hits[0].damage_multiplier-(1-index/10*.0035)*expected)<1e-7);
  }
 }
 for(const [id,outer,center]of [['stone_mask_fragment','minecraft:stone','minecraft:gold_block'],['stone_mask','rpg:stone_mask_fragment','minecraft:netherite_ingot']]){
  const recipe=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0638/recipes/'+id+'.json'),'utf8'))['minecraft:recipe_shaped'];assert.deepEqual(recipe.pattern,['FFF','FCF','FFF']);assert.equal(recipe.key.F.item,outer);assert.equal(recipe.key.C.item,center);assert.equal(recipe.result.count,1);
 }
}
console.log('Damage sensor matrices: human monster x1, vampire sun x1.5, existing ward multipliers; both exact recipes passed');
const componentHandlers=new Map(),commandDefs=new Map(),allCommandDefs=new Map();
signal('startup').fire({itemComponentRegistry:{registerCustomComponent:(id,handler)=>componentHandlers.set(id,handler)},customCommandRegistry:{registerCommand:(d,fn)=>{if(!/^[a-z0-9_]+:[a-z0-9_]+$/.test(d.name))throw Error('CustomCommand name requires a namespace');commandDefs.set(d.name,{d,fn});const list=allCommandDefs.get(d.name)??[];list.push({d,fn});allCommandDefs.set(d.name,list);}}});
assert.ok(componentHandlers.has('rpg:stone_mask'));assert.ok(componentHandlers.has('rpg:bound_common'));assert.ok(commandDefs.has('rpg:weapon'));assert.equal(commandDefs.get('rpg:weapon').d.permissionLevel,0);
console.log('Startup registration: mask/common item components and public /rpg:weapon passed');
{
 const [{d,fn}]=allCommandDefs.get('rpg:force');
 assert.equal(allCommandDefs.get('rpg:force').length,1);
 assert.equal(d.permissionLevel,server.CommandPermissionLevel.GameDirectors);
 assert.equal(d.cheatsRequired,false);
 for(const [previous,args] of [
  ['apprentice',['진홍의','군주']],
  ['bloodedge',['진홍의 군주']],
  ['war_god',['진홍의군주']],
  ['swordsman',['crimson_lord']],
  ['mage',[['진홍의','군주']]],
 ]){
  const {p,inv}=player(previous);
  p.id='force-crimson-from-'+previous;
  p.playerPermissionLevel=2;
  p.runCommand=()=>assert.fail('Force must work without /scriptevent');
  assert.equal(fn({sourceEntity:p},...args).status,server.CustomCommandStatus.Success);
  await timers.at(-1)();
  assert.equal(data.getJobId(p),'crimson_lord');
  assert.equal(inv.getItem(0).typeId,jobs.crimson_lord.weapon);
  assert.ok(data.getSkills(p).includes('crimson_siwang'));
 }
 const denied=player('apprentice');
 fn({sourceEntity:denied.p},'crimson_lord');
 await timers.at(-1)();
 assert.equal(data.getJobId(denied.p),'apprentice');
 assert.match(denied.messages.at(-1),/관리자만/);
 const invalid=player('apprentice');invalid.p.playerPermissionLevel=2;
 fn({sourceEntity:invalid.p},'constructor');
 await timers.at(-1)();
 assert.equal(data.getJobId(invalid.p),'apprentice');
 assert.match(invalid.messages.at(-1),/알 수 없는 직업/);
}
console.log('Force command: one operator-only direct registration, spaced/display/ID forms, Crimson Lord weapon and skills, unknown job and non-operator rejection passed');
{
 const {openJobChangeMenu}=mod('core/jobChange.js');
 assert.equal(allCommandDefs.get('rpg:jobchange').length,1);
 assert.ok(mod('core/statusTablet.js').ALL_STATUS_ACTIONS.some(a=>a.action==='jobchange'));
 const create=(id,job)=>{
  const fixture=player(job);
  fixture.p.id=id;fixture.p.name=id;
  fixture.inv.setItem(0,new ItemStack(jobs[job].weapon));
  data.setSkills(fixture.p,jobs[job].skills);
  return fixture;
 };
 const a=create('job-change-A','swordsman'),b=create('job-change-B','mage');
 const oldOnline=world.getAllPlayers,oldShow=Form.prototype.show,oldTick=system.currentTick;
 const choose=async (p,...forms)=>{
  Form.prototype.show=async()=>{
   assert.ok(forms.length,'unexpected job change form');
   const choice=forms.shift();
   return typeof choice==='function'?choice():{selection:choice};
  };
  await openJobChangeMenu(p);
  assert.equal(forms.length,0);
 };
 const returnTo=(p,job)=>choose(p,0,data.jobHistory(p).filter(id=>id!==data.getJobId(p)).indexOf(job),0);
 try {
  world.getAllPlayers=()=>[a.p,b.p];
  const sword=a.inv.getItem(0);
  sword.setDynamicProperty('rpg:weapon_upgrade',7);sword.setDynamicProperty('rpg:rarity',5);
  sword.durability.damage=36;sword.enchants=[{type:{id:'sharpness'},level:3}];a.inv.setItem(0,sword);
  a.inv.setItem(4,new ItemStack('minecraft:diamond',5));
  data.setDisabled(a.p,['sword_wave']);data.setIndex(a.p,2);data.setMana(a.p,15);
  data.startCooldown(a.p,'sword_draw',100);
  const request=()=>choose(a.p,1,0,0);
  await request();
  assert.equal(data.getJobId(a.p),'swordsman');
  await choose(b.p,2,1);
  assert.equal(data.getJobId(b.p),'mage');
  await request();
  system.currentTick+=1200;
  await choose(b.p,2);
  assert.equal(data.getJobId(b.p),'mage');
  system.currentTick=oldTick;
  await request();
  await choose(b.p,2,()=>{data.setJobId(a.p,'archer');return {selection:0};});
  assert.equal(data.getJobId(a.p),'archer');assert.equal(data.getJobId(b.p),'mage');
  data.setJobId(a.p,'swordsman');

  const image=fixture=>({props:new Map(fixture.props),items:Array.from({length:fixture.inv.size},(_,i)=>fixture.inv.getItem(i))});
  const beforeA=image(a),beforeB=image(b);
  await request();
  const write=b.inv.setItem;
  let fail=true;
  b.inv.setItem=(slot,item)=>{
   if(fail&&slot===0&&item?.typeId===jobs.swordsman.weapon){fail=false;throw Error('injected job exchange inventory failure');}
   write(slot,item);
  };
  await choose(b.p,2,0);b.inv.setItem=write;
  assert.deepEqual(image(a),beforeA);
  assert.deepEqual(image(b),beforeB);
  assert.ok(b.messages.at(-1).includes('교환 실패'));

  await request();await choose(b.p,2,0);
  assert.equal(data.getJobId(a.p),'mage');assert.equal(data.getJobId(b.p),'swordsman');
  assert.equal(data.getMana(a.p),15);assert.equal(data.cooldownLeft(a.p,'sword_draw'),100);
  assert.equal(a.inv.getItem(0).typeId,jobs.mage.weapon);
  assert.equal(b.inv.getItem(0).getDynamicProperty('rpg:weapon_upgrade'),undefined);
  assert.equal(a.inv.getItem(4).amount,5);
  const oldWeapon=a.inv.getItem(1);
  assert.equal(oldWeapon.getDynamicProperty(advance.STORED_JOB_WEAPON),true);
  assert.equal(oldWeapon.getDynamicProperty('rpg:weapon_upgrade'),7);
  assert.ok(data.jobHistory(a.p).includes('mage'));
  for(let slot=2;slot<a.inv.size;slot++)if(!a.inv.getItem(slot))a.inv.setItem(slot,new ItemStack('minecraft:stone'));
  await returnTo(a.p,'swordsman');
  assert.equal(data.getJobId(a.p),'swordsman');
  const restored=a.inv.getItem(0);
  assert.equal(restored.getDynamicProperty(advance.STORED_JOB_WEAPON),undefined);
  assert.equal(restored.getDynamicProperty('rpg:rarity'),5);
  assert.equal(restored.getDynamicProperty('rpg:weapon_upgrade'),7);
  assert.equal(restored.durability.damage,36);assert.deepEqual(restored.enchants,sword.enchants);
  assert.equal([...data.getDisabled(a.p)].join(),'sword_wave');assert.equal(data.getIndex(a.p),2);
  // The archived mage focus survives a normal promotion and can still be recovered.
  advance.applyAdvance(a.p,jobs.sword_saint);
  assert.equal(a.inv.getItem(1).typeId,jobs.mage.weapon);
  assert.equal(data.getJobId(a.p),'sword_saint');
  await returnTo(a.p,'mage');assert.equal(data.getJobId(a.p),'mage');

  const legacy=create('job-change-legacy','michael');
  legacy.p.setDynamicProperty('rpg:progress',JSON.stringify({cham_job_list:['cleric','chameleon']}));
  legacy.p.setDynamicProperty('rpg:discovered_jobs_v1','["dragon_knight"]');
  assert.deepEqual([...data.jobHistory(legacy.p)],['cleric','michael']);
  for(let slot=1;slot<legacy.inv.size;slot++)legacy.inv.setItem(slot,new ItemStack('minecraft:stone'));
  await choose(legacy.p,0,0,0);assert.equal(data.getJobId(legacy.p),'michael');
  assert.match(legacy.messages.at(-1),/빈칸/);
  legacy.inv.setItem(2,undefined);
  await choose(legacy.p,0,0,0);assert.equal(data.getJobId(legacy.p),'cleric');

  const common=create('job-change-bound','chameleon');
  const learning=mod('core/chameleonProgress.js');
  const learned=learning.readChameleonProgress(common.p);
  learned.learned=['war_god_flurry'];learned.evolved=['war_god_flurry'];
  learned.transcended={war_god_flurry:1};learned.spentSp=9;
  learning.saveChameleonProgress(common.p,learned);learning.syncChameleonLoadout(common.p);
  common.inv.setItem(4,new ItemStack('rpg:common_redmoon_blade'));
  assert.ok(binding.bindCommonWeapon(common.p,4).ok);
  data.setJobId(common.p,'mage');data.setSkills(common.p,jobs.mage.skills);
  await choose(common.p,0,0,0);
  assert.equal(data.getJobId(common.p),'chameleon');assert.ok(binding.isBoundHeld(common.p,'rpg:common_redmoon_blade'));
  assert.ok(data.getSkills(common.p).includes('war_god_flurry'));
  const waiver=mod('core/progressionItems.js');
  common.inv.setItem(5,new ItemStack(waiver.JOB_WAIVER_ITEM));
  const waived=waiver.applyProgressionItem(common.p,waiver.JOB_WAIVER_ITEM);
  assert.equal(waived.ok,true);assert.equal(waived.refund,9);
  await returnTo(common.p,'chameleon');
  assert.equal(data.getJobId(common.p),'chameleon');
  assert.equal(data.getSkills(common.p).includes('war_god_flurry'),false);
  assert.equal(learning.learningSpent(common.p),0);
 } finally {
  world.getAllPlayers=oldOnline;Form.prototype.show=oldShow;system.currentTick=oldTick;
 }
}
console.log('Job change: double consent, decline, expiry, stale offers, rollback, previous jobs, full bags, bound weapons and personal loadouts passed');
{
 const {p,inv}=player('apprentice');inv.setItem(0,new ItemStack('rpg:apprentice_sword'));inv.setItem(4,new ItemStack('rpg:common_redmoon_blade'));binding.bindCommonWeapon(p,4);assert.equal(mod('core/context.js').getContext(p).substitute,true);inv.setItem(0,undefined);advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,'rpg:apprentice_sword');
}
console.log('Apprentice common-weapon break restores the selected starter line');
{
 const {p,inv}=player();for(let i=0;i<inv.size;i++)inv.setItem(i,new ItemStack(i===0?jobs.swordsman.weapon:i===4?'rpg:common_redmoon_blade':'minecraft:stone'));assert.equal(binding.bindCommonWeapon(p,4).ok,true);assert.equal(inv.getItem(4).typeId,jobs.swordsman.weapon);assert.equal(inv.getItem(0).typeId,'rpg:common_redmoon_blade');
 const uid=inv.getItem(0).getDynamicProperty(binding.WEAPON_UID);const props=p.getDynamicProperty(binding.BINDING_KEY);p.setDynamicProperty(binding.BINDING_KEY,props);advance.ensureWeapon(p);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);
 const before=inv.getItem(0);const result=binding.bindCommonWeapon(p,6);assert.equal(result.ok,false);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),before.getDynamicProperty(binding.WEAPON_UID));
}
console.log('Full-inventory replacement, persisted binding reuse and invalid selection preserve items');
{
 const {p,health}=player('the_world');const life=mod('core/lifesteal.js');life.registerLifesteal();
 const target={id:'lethal_enemy',typeId:'minecraft:zombie',getComponent:id=>id==='minecraft:health'?{currentValue:0,effectiveMax:20}:undefined};
 signal('entityHealthChanged').fire({entity:target,oldValue:3,newValue:0});signal('entityHurt').fire({hurtEntity:target,damage:100,damageSource:{cause:'entityAttack',damagingEntity:p}});
 assert.ok(Math.abs(health.currentValue-50.3)<1e-8);
}
console.log('Native hurt-event path: lethal overkill only heals 10% of remaining enemy HP');
{
 const {p,inv}=player('apprentice');const card=mod('core/chameleonCard.js');assert.equal(advance.checkAdvance(p,jobs.chameleon).ok,false);
 inv.setItem(3,new ItemStack(card.CHAMELEON_CARD));assert.equal(advance.checkAdvance(p,jobs.chameleon).ok,false);p.selectedSlotIndex=3;assert.equal(advance.checkAdvance(p,jobs.chameleon).ok,true);assert.equal(advance.requirementStatus(p,jobs.chameleon).met,true);
 await advance.requestAdvance(p,jobs.chameleon);assert.equal(data.getJobId(p),'chameleon');assert.equal(inv.getItem(3).typeId,card.CHAMELEON_CARD);assert.equal(inv.getItem(3).amount,1);
 const item=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0638/items/chameleon_job_card.json'),'utf8'))['minecraft:item'];assert.equal(item.description.menu_category.category,'items');
 const loot=path.join(root,'RPG_BP_v0638/loot_tables');function find(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?find(path.join(dir,e.name)):[path.join(dir,e.name)]);}for(const f of [...find(loot),...find(path.join(root,'RPG_BP_v0638/recipes'))])assert.ok(!fs.readFileSync(f,'utf8').includes(card.CHAMELEON_CARD));
}
console.log('Chameleon card: actual mainhand required, apprentice transfer without old trials, card retained, no recipe/loot passed');
{
 const {p,inv}=player('mage');data.setSkills(p,jobs.mage.skills);const card=mod('core/chameleonCard.js');inv.setItem(3,new ItemStack(card.CHAMELEON_CARD));p.selectedSlotIndex=3;
 const original=Form.prototype.show;Form.prototype.show=()=>{inv.setItem(3,undefined);return Promise.resolve({canceled:false,selection:0});};await advance.requestAdvance(p,jobs.chameleon);Form.prototype.show=original;assert.equal(data.getJobId(p),'mage');
 const hito=mod('core/hito.js'),line=hito.HITO_LINES.find(l=>l.id==='chameleon');assert.equal(line.label,'구욱');hito.registerHito();const npc={typeId:'rpg:hito_chameleon',nameTag:'카멜레온 전직관'};signal('entitySpawn').fire({entity:npc});timers.at(-1)();assert.equal(npc.nameTag,'구욱');
}
console.log('Chameleon card rechecked after confirmation; NPC name is exactly 구욱');
assert.equal(commandDefs.get('rpg:citycreate').d.permissionLevel,1);assert.equal(commandDefs.get('rpg:citycreate').d.optionalParameters[0].name,'height');
for(const name of ['citystop','cityresume','citystatus','cityreset'])assert.equal(commandDefs.get('rpg:'+name).d.permissionLevel,1);
console.log('City commands are operator-only with optional height');

{
 const {p}=player();const sent=[];p.runCommand=s=>sent.push(s);assert.equal(commandDefs.has('dungeoncreate'),false);
 const canonical=commandDefs.get('rpg:dungeoncreate');canonical.fn({sourceEntity:p},'10');timers.at(-1)();assert.equal(sent[0],'scriptevent rpg:dungeoncreate 10');
}
console.log('Actual Commands BP: /rpg:dungeoncreate 10 forwards the correct tier with admin permissions');
{
 const {p,inv}=player('chameleon');p.setDynamicProperty('rpg:rpg_level',100);inv.setItem(0,new ItemStack(jobs.chameleon.weapon));
 const cham=mod('core/chameleon.js');for(const line of ['the_world','nen']){const group=cham.CHAMELEON_GROUPS.find(g=>g.line===line);assert.ok(group);assert.equal(group.ids.length,jobs[line].skills.length);for(const id of group.ids){const r=cham.learnChameleonSkill(p,id);assert.equal(r.ok,true,r.message);assert.ok(data.getSkills(p).includes(id));}}
 assert.equal(data.getJobId(p),'chameleon');assert.equal(mod('core/races.js').raceOf(p),'human');assert.ok(mod('core/context.js').getContext(p).skills.includes('world_stop'));assert.ok(mod('core/context.js').getContext(p).skills.includes('nen_en'));
 console.log('Chameleon menus: all 6 World and 10 Nen skills actually purchased with SP, usable in context; job/race unchanged');
 const fx=new Map();p.getEffect=id=>fx.get(id);p.addEffect=(id,duration,o)=>fx.set(id,{duration,amplifier:o.amplifier});p.removeEffect=id=>fx.delete(id);
 p.dimension.getEntities=()=>[];p.inputInfo={getMovementVector:()=>({x:0,y:0}),getButtonState:()=>0};p.getRotation=()=>({x:0,y:0});p.clearVelocity=()=>{};p.applyImpulse=()=>{};
 const oldPlayers=world.getAllPlayers;world.getAllPlayers=()=>[p];const tw=mod('skills/theWorld.js');assert.equal(tw.startTheWorld(p),true);system.currentTick++;tw.tickTheWorld();assert.equal(tw.stopTheWorld(p),true);data.setJobId(p,'mage');assert.equal(tw.startTheWorld(p),false);
 data.setJobId(p,'chameleon');let hit=0;const target={id:'nen_target',isValid:true,typeId:'minecraft:zombie',location:{x:0,y:64,z:1},dimension:p.dimension,getTags:()=>[],getComponent:id=>id==='minecraft:health'?{currentValue:500,effectiveMax:500}:undefined,applyDamage:n=>{hit+=n;return true;}};
 const nen=mod('skills/nen.js'),defs=mod('data/skills.js').SKILLS;nen.registerNen();nen.RUNNERS.nen_ko(p,jobs.nen,defs.nen_ko);nen.RUNNERS.nen_shu(p,jobs.nen,defs.nen_shu);
 signal('entityHurt').fire({hurtEntity:target,damage:5,damageSource:{cause:'entityAttack',damagingEntity:p}});assert.equal(hit,70);signal('entityHurt').fire({hurtEntity:target,damage:5,damageSource:{cause:'entityAttack',damagingEntity:p}});assert.equal(hit,80);
 world.getAllPlayers=oldPlayers;console.log('Borrowed World stop survives tick; unlearned mage rejected; borrowed Nen Ko/Shu produce 70 then 10 damage');
}
{
 const {p,inv}=player('apprentice');const card=mod('core/bloodCard.js');assert.equal(advance.checkAdvance(p,jobs.blood_mage).ok,false);p.setDynamicProperty('rpg:progress',JSON.stringify({job_kills:1000}));assert.equal(advance.checkAdvance(p,jobs.blood_mage).ok,false);
 inv.setItem(3,new ItemStack(card.BLOOD_CARD));assert.equal(advance.checkAdvance(p,jobs.blood_mage).ok,false);p.selectedSlotIndex=3;assert.equal(advance.checkAdvance(p,jobs.blood_mage).ok,true);assert.equal(advance.requirementStatus(p,jobs.blood_mage).met,true);await advance.requestAdvance(p,jobs.blood_mage);assert.equal(data.getJobId(p),'blood_mage');assert.equal(inv.getItem(3).typeId,card.BLOOD_CARD);assert.equal(inv.getItem(3).amount,1);assert.equal(mod('core/races.js').raceOf(p),'vampire');
 const item=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0638/items/blood_job_card.json'),'utf8'))['minecraft:item'];assert.equal(item.description.menu_category.category,'items');
 function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}for(const f of [...files(path.join(root,'RPG_BP_v0638/recipes')),...files(path.join(root,'RPG_BP_v0638/loot_tables'))])assert.ok(!fs.readFileSync(f,'utf8').includes(card.BLOOD_CARD));
 console.log('Blood card: creative item only, mainhand needed, old kills not a bypass, apprentice allowed, card retained, vampire race applied');
}
{
 const {p,inv}=player('mage');data.setSkills(p,jobs.mage.skills);inv.setItem(3,new ItemStack('rpg:blood_job_card'));p.selectedSlotIndex=3;const original=Form.prototype.show;Form.prototype.show=()=>{inv.setItem(3,undefined);return Promise.resolve({canceled:false,selection:0});};await advance.requestAdvance(p,jobs.blood_mage);Form.prototype.show=original;assert.equal(data.getJobId(p),'mage');
 const client=JSON.parse(fs.readFileSync(path.join(root,'RPG_RP_v0638/entity/hito_blood.entity.json'),'utf8'))['minecraft:client_entity']['description'];assert.equal(client.geometry.default,'geometry.rpg.blood_master');
 const info=mod('core/worldMastery.js');p.setDynamicProperty(info.WORLD_MASTERY_KEY,25);assert.ok(info.worldMasteryText(p).includes('3.5초'));assert.ok(mod('core/skillGuide.js').skillGuideDetail('world_stop',p).includes('3.5초'));
 console.log('Blood card rechecked after form; blood skin geometry reference and dynamic mastery guide passed');
}

{
 const {p,inv}=player(),funds=mod('core/creativeFunds.js'),w=mod('core/wallet.js');
 assert.equal(funds.grantCreativeFunds(p).ok,false);assert.equal(w.getWallet(p).gold,0);
 p.getGameMode=()=> 'creative';assert.equal(funds.grantCreativeFunds(p).ok,true);assert.equal(w.getWallet(p).gold,w.BALANCE_MAX);assert.equal(w.getWallet(p).stone,w.BALANCE_MAX);assert.equal(w.getWallet(p).dust,w.BALANCE_MAX);
 w.setWallet(p,{gold:1,stone:2,dust:3});assert.equal(funds.grantCreativeFunds(p).ok,true);assert.equal(w.getWallet(p).dust,w.BALANCE_MAX);
 p.getGameMode=()=> 'survival';inv.setItem(0,new ItemStack(funds.CREATIVE_FUNDS_ITEM));w.setWallet(p,{gold:0,stone:0,dust:0});componentHandlers.get('rpg:creative_funds').onUse({source:p});timers.at(-1)();assert.equal(w.getWallet(p).gold,0);
 assert.equal(commandDefs.get('rpg:creativefunds').d.permissionLevel,0);assert.equal(commandDefs.get('rpg:runebatch').d.permissionLevel,0);
 const j=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0638/items/creative_funds.json'),'utf8'))['minecraft:item'];assert.equal(j.description.menu_category.category,'items');assert.ok(j.components['rpg:creative_funds']);
 for(const dir of ['recipes','loot_tables']){const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);for(const f of walk(path.join(root,'RPG_BP_v0638',dir)))assert.ok(!fs.readFileSync(f,'utf8').includes(funds.CREATIVE_FUNDS_ITEM));}
 console.log('Creative supply: creative mode required on command/item routes, all three currencies repeatably refill to 1 billion, forged survival item rejected, no recipe/drop');
}
{
 const {p}=player(),runes=mod('core/runeInventory.js'),batch=mod('core/runeBatch.js'),w=mod('core/wallet.js');
 const bag=runes.readRuneBag(p),added=[];for(const [id,level,grade]of [['power',0,0],['power',2,0],['power',9,0],['power',10,0],['power',0,1],['arcane',0,0]])added.push(runes.addRuneRecord(bag,id,level,grade));bag.equipped[0]=added[0].uid;runes.writeRuneBag(p,bag);w.setWallet(p,{gold:100000,stone:20,dust:1000});
 const q=batch.runeBatchQuote(p,'power',0);assert.equal(q.count,3);assert.equal(q.total,4);assert.equal(q.cost.dust,10);const draws=[0,.99,.999];const res=batch.executeRuneBatch(p,'power',0,q.fingerprint,{random:()=>draws.shift()});assert.equal(res.ok,true,res.reason);assert.equal(res.counts.success,1);assert.equal(res.counts.downgrade,1);assert.equal(res.counts.destroy,1);
 const after=runes.readRuneBag(p);assert.equal(after.runes.find(r=>r.uid===added[0].uid).level,1);assert.equal(after.runes.find(r=>r.uid===added[1].uid).level,1);assert.equal(after.runes.some(r=>r.uid===added[2].uid),false);assert.equal(after.runes.find(r=>r.uid===added[3].uid).level,10);assert.equal(after.runes.find(r=>r.uid===added[4].uid).level,0);assert.equal(after.runes.find(r=>r.uid===added[5].uid).level,0);assert.equal(after.equipped[0],added[0].uid);assert.equal(w.getWallet(p).gold,100000-q.cost.gold);assert.equal(w.getWallet(p).dust,1000-q.cost.dust);
 const stale=batch.runeBatchQuote(p,'power',0);after.runes[0].level++;runes.writeRuneBag(p,after);const snap=JSON.stringify(runes.readRuneBag(p));assert.equal(batch.executeRuneBatch(p,'power',0,stale.fingerprint).ok,false);assert.equal(JSON.stringify(runes.readRuneBag(p)),snap);
 const current=batch.runeBatchQuote(p,'power',0);w.setWallet(p,{gold:0,stone:0,dust:0});assert.equal(batch.executeRuneBatch(p,'power',0,current.fingerprint).ok,false);assert.equal(JSON.stringify(runes.readRuneBag(p)),snap);
 console.log('Rune batch enhancement: type/grade grouping, +10 skipped, single attempt per rune, correct combined cost, success/downgrade/destroy, other runes/equip preserved, stale selection and insufficient balance rejected');
}
{
 const {p}=player(),runes=mod('core/runeInventory.js'),batch=mod('core/runeBatch.js'),w=mod('core/wallet.js');const bag=runes.readRuneBag(p);for(let i=0;i<3;i++)runes.addRuneRecord(bag,'ward',0,0);runes.writeRuneBag(p,bag);w.setWallet(p,{gold:1000,stone:100,dust:100});const before=p.getDynamicProperty(runes.RUNE_BAG_KEY),money=p.getDynamicProperty(w.WALLET_KEY),q=batch.runeBatchQuote(p,'ward',0);let draw=0;
 const r=batch.executeRuneBatch(p,'ward',0,q.fingerprint,{random:()=>{if(draw++===1)throw Error('injected failure after first successful upgrade');return 0;}});assert.equal(r.ok,false);assert.equal(p.getDynamicProperty(runes.RUNE_BAG_KEY),before);assert.equal(p.getDynamicProperty(w.WALLET_KEY),money);
 console.log('Rune batch rollback: failure in second attempt restores first upgrade and entire original wallet/bag');
}{
 const {p}=player(),runes=mod('core/runeInventory.js'),batch=mod('core/runeBatch.js'),w=mod('core/wallet.js');const bag=runes.readRuneBag(p);runes.addRuneRecord(bag,'power',0,0);runes.addRuneRecord(bag,'power',0,0);runes.writeRuneBag(p,bag);w.setWallet(p,{gold:1000,stone:0,dust:100});
 const answers=[0,0,1,undefined],original=Form.prototype.show;Form.prototype.show=()=>{const n=answers.shift();return Promise.resolve(n===undefined?{canceled:true}:{canceled:false,selection:n});};try{await batch.openRuneBatch(p);}finally{Form.prototype.show=original;}assert.equal(w.getWallet(p).dust,98);
 console.log('Rune batch UI: group selection, confirmation and batch execution exercised through actual forms');
}
{
 const {DESTRUCTION_WAIVER_ID:waiver,ALL_EQUIPMENT_IDS}=mod('data/equipment.js');
 const {CATALYST_ID:catalyst}=mod('data/upgrades.js');
 const {enhanceEquipped,enhancementQuote}=mod('core/upgrades.js');
 const {setGearLevel}=mod('core/gearState.js'),{RARITY_KEY}=mod('data/grades.js');
 const {getWallet,setWallet}=mod('core/wallet.js');
 const runes=mod('core/runeInventory.js'),batch=mod('core/runeBatch.js'),auto=mod('core/runeAuto.js');
 const funds={gold:500000,stone:500,dust:500},destroy=()=>.999;
 const create=()=>{const fixture=player();setWallet(fixture.p,funds);return fixture;};
 for(const [kind,typeId,slot] of [
  ['weapon','rpg:common_magitech_greatsword',2],
  ['weapon',jobs.swordsman.weapon,'Mainhand'],
  ['armor','rpg:adventurer_helmet','Head'],
 ]){
  const {p,inv}=create(),item=setGearLevel(new ItemStack(typeId),kind,9);
  item.setDynamicProperty(RARITY_KEY,6);
  item.durability.damage=13;
  item.enchants=[{type:{id:'mending'},level:1}];
  const itemSlot=typeof slot==='number'?slot:0;
  inv.setItem(itemSlot,item);
  inv.setItem(7,new ItemStack(waiver,2));
  inv.setItem(8,new ItemStack(catalyst));
  inv.setItem(11,new ItemStack(waiver));
  const quote=enhancementQuote(p,kind,slot);
  const r=enhanceEquipped(p,kind,slot,quote.fingerprint,{random:destroy,catalystCount:1});
  assert.equal(r.outcome,'protected',r.reason);
  assert.equal(r.level,9);
  assert.equal(inv.getItem(7).amount,1);
  assert.equal(inv.getItem(11).amount,1);
  assert.equal(inv.getItem(8),undefined);
  assert.deepEqual(inv.getItem(itemSlot),item.clone());
  assert.equal(getWallet(p).gold,funds.gold-quote.cost.gold);
  for(const [draw,outcome] of [[.25,'fail'],[.65,'downgrade'],[0,'success']]){
   assert.equal(enhanceEquipped(p,kind,slot,undefined,{random:()=>draw}).outcome,outcome);
   assert.equal(inv.getItem(7).amount,1);
  }
 }
 const {p,inv}=create(),bag=runes.readRuneBag(p);
 const a=runes.addRuneRecord(bag,'power',9,6);runes.addRuneRecord(bag,'power',9,6);
 bag.equipped[0]=a.uid;
 runes.writeRuneBag(p,bag);
 inv.setItem(4,new ItemStack(waiver));
 inv.setItem(5,new ItemStack(catalyst,2));
 const quote=batch.runeBatchQuote(p,'power',6,1);
 const oldBag=runes.readRuneBag(p);
 const save=inv.setItem;
 inv.setItem=(slot,item)=>{save(slot,item);if(slot===4&&!item)throw Error('waiver slot write failed');};
 const failed=enhanceEquipped(p,'rune',a.uid,undefined,{random:destroy,catalystCount:1});
 inv.setItem=save;
 assert.equal(failed.ok,false);
 assert.deepEqual(runes.readRuneBag(p),oldBag);
 assert.equal(inv.getItem(4).amount,1);
 assert.equal(inv.getItem(5).amount,2);
 assert.equal(getWallet(p).gold,funds.gold);
 let attempts=0;
 const failedBatch=batch.executeRuneBatch(p,'power',6,quote.fingerprint,{catalystCount:1,random:()=>{
  if(attempts++===1)throw Error('later roll failed');
  return destroy();
 }});
 assert.equal(failedBatch.ok,false);
 assert.deepEqual(runes.readRuneBag(p),oldBag);
 assert.equal(inv.getItem(4).amount,1);
 assert.equal(inv.getItem(5).amount,2);
 assert.equal(getWallet(p).gold,funds.gold);
 const r=batch.executeRuneBatch(p,'power',6,quote.fingerprint,{catalystCount:1,random:destroy});
 assert.equal(r.ok,true,r.reason);
 assert.equal(r.counts.protected,1);
 assert.equal(r.counts.destroy,1);
 assert.equal(inv.getItem(4),undefined);
 assert.equal(inv.getItem(5),undefined);
 assert.deepEqual(Array.from(runes.readRuneBag(p).runes),[a]);
 assert.equal(runes.readRuneBag(p).equipped[0],a.uid);
 const updated=runes.readRuneBag(p);
 runes.addRuneRecord(updated,'power',9,6);
 runes.writeRuneBag(p,updated);
 inv.setItem(7,new ItemStack(waiver));
 assert.equal(auto.runeAutoStep(p,{id:'power',grade:6,level:10,catalysts:0},{random:destroy}).outcome,'protected');
 assert.equal(inv.getItem(7),undefined);
 assert.equal(runes.readRuneBag(p).runes.length,2);
 const recipe=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0638/recipes/destruction_waiver.json')))['minecraft:recipe_shapeless'];
 assert.equal(recipe.result.item,waiver);
 assert.equal(recipe.result.count,1);
 assert.deepEqual(recipe.ingredients.map(i=>i.item),['minecraft:paper',catalyst,'minecraft:diamond','minecraft:diamond']);
 assert.ok(ALL_EQUIPMENT_IDS.includes(waiver));
 console.log('Destruction waiver: armor, held and bag weapons, equipped runes, manual/batch/auto, one per destruction, preserved item state, rollback, and recipe verified');
}
{
 const life=mod('core/townWildlife.js'),spawn=mod('core/spawnEffects.js'),s={x:0,y:64,z:0,size:250,dimId:'minecraft:overworld'},oldGet=world.getDynamicProperty;
 world.getDynamicProperty=k=>k===spawn.SPAWN_REGION_KEY?JSON.stringify(s):undefined;
 function mob(type='minecraft:zombie',x=125,y=65,z=125){const tags=new Set(),dp=new Map();return {typeId:type,isValid:true,location:{x,y,z},dimension:{id:'minecraft:overworld'},getComponent:k=>k==='minecraft:type_family'?{hasTypeFamily:t=>t==='monster'&&type==='minecraft:zombie'}:undefined,getDynamicProperty:k=>dp.get(k),setDynamicProperty:(k,v)=>dp.set(k,v),hasTag:t=>tags.has(t),addTag:t=>tags.add(t),remove(){this.removed=true;}};}
 const zombie=mob(),cow=mob('minecraft:cow'),sheep=mob('minecraft:sheep'),villager=mob('minecraft:villager'),npc=mob('rpg:hito_blood'),bat=mob('minecraft:bat'),dungeon=mob(),below=mob('minecraft:zombie',125,10),outside=mob('minecraft:zombie',250),lastRow=mob('minecraft:zombie',249.9),ally=mob();dungeon.addTag('rpg_dungeon_mob');ally.setDynamicProperty('rpg:necro_owner','test');
 const list=[zombie,cow,sheep,villager,npc,bat,dungeon,below,outside,lastRow,ally];world.getDimension=()=>({getEntities:q=>{assert.equal(q.volume.x,250);return list;}});life.tickTownWildlife();assert.equal(zombie.removed,undefined);assert.equal(bat.removed,true);assert.equal(lastRow.removed,undefined);for(const e of [cow,sheep,villager,npc,dungeon,below,outside,ally])assert.equal(e.removed,undefined,e.typeId);
 mod('core/townZombies.js').registerTownZombies();life.registerTownWildlife();const egg=mob();signal('entitySpawn').fire({entity:egg,cause:'Spawned'});const callbacks=timers.slice();const {p}=player();p.location={x:125,y:65,z:125};signal('itemUse').fire({source:p,itemStack:new ItemStack('minecraft:zombie_spawn_egg')});callbacks.at(-1)();assert.equal(egg.removed,undefined);assert.equal(egg.hasTag(mod('core/townZombies.js').ZOMBIE_KEPT),true);
 system.currentTick+=10;const natural=mob();signal('entitySpawn').fire({entity:natural,cause:'Spawned'});timers.at(-1)();assert.equal(natural.removed,true);
 const loaded=mob();signal('entitySpawn').fire({entity:loaded,cause:'Loaded'});timers.at(-1)();assert.equal(loaded.removed,undefined);
 const manual=mob();signal('entitySpawn').fire({entity:manual,cause:'Event'});assert.equal(manual.hasTag('rpg_town_manual_spawn'),true);assert.equal(life.clearTownMonster(manual),false);
 const labeled=mob();labeled.nameTag='§cLv. 50';assert.equal(life.clearTownMonster(labeled),false);
 const zoned=mob();zoned.addTag('rpg_town_manual_spawn');zoned.addTag('rpg_hunt_zoned');mod('core/townZombies.js').noteTownZombieSpawn(zoned,'Spawned');assert.equal(life.clearTownMonster(zoned),true);
 world.getDynamicProperty=oldGet;
 console.log('Town wildlife: hostile natural mobs/bats removed including final edge column, animals/villagers/trainers/owned summons/dungeons preserved, finite height, intentional zombie egg kept and stale egg intent expires');
}
{
 const {p}=player(),runes=mod('core/runeInventory.js'),batch=mod('core/runeBatch.js'),w=mod('core/wallet.js'),bag=runes.readRuneBag(p);for(let i=0;i<3;i++)runes.addRuneRecord(bag,'ward',0,0);runes.writeRuneBag(p,bag);w.setWallet(p,{gold:1000,stone:100,dust:100});const before=p.getDynamicProperty(runes.RUNE_BAG_KEY),money=p.getDynamicProperty(w.WALLET_KEY),q=batch.runeBatchQuote(p,'ward',0);const setter=p.setDynamicProperty;let writes=0;
 p.setDynamicProperty=(key,value)=>{if(key===runes.RUNE_BAG_KEY&&++writes===2)throw Error('injected storage failure during second enhancement');setter(key,value);};
 const r=batch.executeRuneBatch(p,'ward',0,q.fingerprint,{random:()=>0});assert.equal(r.ok,false);assert.equal(p.getDynamicProperty(runes.RUNE_BAG_KEY),before);assert.equal(p.getDynamicProperty(w.WALLET_KEY),money);
 console.log('Rune batch storage rollback: second rune write failure restores all three original runes and entire wallet');
}
{
 const {p,inv}=player('apprentice');
 p.id='bloodedge-promotion';
 const target=jobs.bloodedge,advance=mod('core/advance.js'),catalog=mod('data/jobs.js');
 assert.equal(catalog.findJob('블레드엣지'),target);
 assert.equal(catalog.findJob('블러드엣지'),target);
 assert.equal(catalog.findJob('블라디미르'),target);
 assert.equal(target.name,'블라디미르');

 const hito=mod('core/hito.js'),discovery=mod('core/jobDiscovery.js');
 const npc={typeId:'rpg:hito_bloodedge',nameTag:''};
 const beforeSpawn=timers.length;
 signal('entitySpawn').fire({entity:npc});
 for(const callback of timers.slice(beforeSpawn))callback();
 assert.equal(npc.nameTag,'창셀혼');
 assert.ok(!hito.HITO_LINES.find(line=>line.id==='mage').jobs.includes(target.id));
 assert.equal(discovery.isJobDiscovered(p,target),false);
 const {VLADIMIR_CARD}=mod('core/vladimirCard.js');
 inv.setItem(3,new ItemStack(VLADIMIR_CARD));
 const original={show:Form.prototype.show,title:Form.prototype.title,body:Form.prototype.body,button:Form.prototype.button};
 let form,choose;
 Form.prototype.title=function(title){form={title,buttons:[]};return this;};
 Form.prototype.body=function(body){form.body=body;return this;};
 Form.prototype.button=function(label){form.buttons.push(label);return this;};
 Form.prototype.show=()=>Promise.resolve(choose());
 const talk=async()=>{
  system.currentTick+=8;
  const count=timers.length;
  signal('playerInteractWithEntity').fire({target:npc,player:p});
  assert.equal(timers.length,count+1);
  await timers.at(-1)();
 };
 data.setSkills(p,['fire_flame_burst','mage_fireball','blood_spear']);
 try{
  choose=()=>({selection:0});
  await talk();
  assert.deepEqual(form,{title:'창셀혼',body:'최고권력자 창셀혼입니다',buttons:['닫기']});
  assert.equal(discovery.isJobDiscovered(p,target),false);
  assert.equal(data.getJobId(p),'apprentice');
  p.selectedSlotIndex=3;
  assert.equal(advance.checkAdvance(p,target).ok,false);
  await advance.requestAdvance(p,target);
  assert.equal(data.getJobId(p),'apprentice');
  choose=()=>({selection:1});
  await talk();
  assert.equal(data.getJobId(p),'apprentice');
  assert.ok(form.buttons.includes('블라디미르로 전직'));
  choose=()=>{p.selectedSlotIndex=4;return {selection:0};};
  await talk();
  assert.equal(data.getJobId(p),'apprentice');
  p.selectedSlotIndex=3;choose=()=>({selection:0});
  await talk();
 }finally{Object.assign(Form.prototype,original);}
 assert.equal(data.getJobId(p),'bloodedge');
 assert.equal(discovery.isJobDiscovered(p,target),true);
 assert.equal(inv.getItem(3).typeId,VLADIMIR_CARD);
 assert.equal(hito.giveHitoEgg(p,'창셀혼'),true);
 assert.equal(inv.getItem(1).typeId,'rpg:hito_bloodedge_spawn_egg');
 const bp=path.join(root,'RPG_BP_v0638');
 const card=JSON.parse(fs.readFileSync(path.join(bp,'items/vladimir_job_card.json')))['minecraft:item'];
 assert.equal(card.description.identifier,VLADIMIR_CARD);
 assert.equal(card.description.menu_category.category,'items');
 function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}
 for(const file of [...files(path.join(bp,'recipes')),...files(path.join(bp,'loot_tables'))])assert.ok(!fs.readFileSync(file,'utf8').includes(VLADIMIR_CARD));
 assert.equal(inv.getItem(0).typeId,'rpg:bloodedge_scythe');
 p.selectedSlotIndex=0;
 const scythe=inv.getItem(0),labels=mod('core/rarityLabels.js');
 scythe.nameTag='블러드엣지의 피의 낫 +3';
 scythe.setDynamicProperty('rpg:class_upgrade_label',scythe.nameTag);
 scythe.setDynamicProperty('rpg:weapon_upgrade',3);
 assert.equal(labels.decorateRarity(scythe),true);
 assert.equal(scythe.nameTag,'블라디미르의 피의 낫 +3');
 scythe.nameTag='나만의 낫';
 assert.equal(labels.decorateRarity(scythe),false);
 assert.equal(scythe.nameTag,'나만의 낫');

 assert.deepEqual(Array.from(mod('core/context.js').getContext(p).skills),Array.from(target.skills));
 assert.equal(data.getJobId(p),'bloodedge');
 assert.equal(mod('core/races.js').jobRace(data.getJobId(p)),'human');
 assert.ok(data.getSkills(p).every(skill=>skill.startsWith('bloodedge_')));
 assert.equal(jobs.bloodedge.skills.length,8);
 data.setSkills(p,['bloodedge_shield','bloodedge_volley','bloodedge_pool']);
 assert.deepEqual(Array.from(data.getSkills(p)),Array.from(jobs.bloodedge.skills));
 const def=mod('data/skills.js').SKILLS;
 assert.equal(def.bloodedge_bind.trigger,'hit');
 assert.equal(def.bloodedge_pool.ultimate,true);
 p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:5,mag:5,vit:5,int:40}));
 p.getViewDirection=()=>({x:0,y:0,z:1});
 data.forceSetManaMax(p,'1000');data.setMana(p,1000);
 data.setIndex(p,jobs.bloodedge.skills.indexOf('bloodedge_volley'));
 data.startCooldown(p,'bloodedge_volley',120); // Simulate cooldown data left by an older version.
 for(let i=0;i<2;i++){
  system.currentTick+=3;
  componentHandlers.get('rpg:cast_item').onUse({source:p});
  timers.at(-1)();
  assert.equal(data.getMana(p),970-i*30);
  assert.equal(data.cooldownLeft(p,'bloodedge_volley'),0);
 }

 const {p:old}=player('blood_mage');assert.equal(advance.checkAdvance(old,target).ok,false);
 console.log('Vladimir promotion: neutral NPC dialogue and name, undiscovered class, card mainhand and stale selection gates, NPC-only route, no crafting or loot, card retained, dedicated scythe, eight skills and exact 30 mana through item input');
}
{
 const {p,inv}=player('bloodedge');p.id='royal-promotion';
 const hito=mod('core/hito.js'),trial=mod('core/jobTrials.js'),target=jobs.crimson_lord,stats=mod('core/stats.js');
 const npcLine=hito.HITO_LINES.find(line=>line.id==='bloodedge');
 const guide=mod('core/skillGuide.js'),oldShow=Form.prototype.show,oldBody=Form.prototype.body;
 const weapon=new ItemStack(jobs.bloodedge.weapon);weapon.setDynamicProperty('rpg:weapon_upgrade',8);
 weapon.setDynamicProperty('rpg:rarity',6);
 inv.setItem(0,weapon);
 p.getViewDirection=()=>({x:0,y:0,z:1});
 p.dimension.getBlock=()=>({isSolid:false});
 p.dimension.getEntities=()=>[];
 p.onScreenDisplay.setHudVisibility=()=>{};
 p.teleport=at=>{p.location={...at};};
 try{
  const bodies=[];
  Form.prototype.body=function(text){bodies.push(text);return this;};
  Form.prototype.show=()=>Promise.resolve({selection:0});
  p.setDynamicProperty('rpg:rpg_level',45);
  assert.equal(trial.jobTrialStatus(p,target).met,false);
  await hito.openHitoMenu(p,npcLine);
  assert.equal(data.getJobId(p),'bloodedge');
  assert.match(bodies.at(-1),/RPG 레벨 45\/45/);
  assert.match(bodies.at(-1),/솔로·파티.*0\/1/);
  mod('core/newTrials.js').recordCrimsonTrial(p);
  p.setDynamicProperty('rpg:rpg_level',44);
  assert.equal(trial.jobTrialStatus(p,target).met,false);
  p.setDynamicProperty('rpg:rpg_level',45);
  assert.equal(advance.checkAdvance(p,target).ok,false);
  Form.prototype.show=()=>{p.setDynamicProperty('rpg:rpg_level',44);return Promise.resolve({selection:0});};
  await hito.openHitoMenu(p,npcLine);assert.equal(data.getJobId(p),'bloodedge');
  p.setDynamicProperty('rpg:rpg_level',45);
  Form.prototype.show=()=>Promise.resolve({selection:0});
  data.setDisabled(p,['bloodedge_shield']);
  data.startCooldown(p,'bloodedge_pool',400);
  await hito.openHitoMenu(p,npcLine);
  assert.equal(data.getJobId(p),'crimson_lord');
  assert.deepEqual(Array.from(data.getSkills(p)),Array.from(target.skills));
  assert.deepEqual(Array.from(data.getDisabled(p)),['crimson_shield']);
  assert.equal(data.cooldownLeft(p,'crimson_pool'),400);
  data.resetNonUltimateCooldowns(p);assert.equal(data.cooldownLeft(p,'crimson_pool'),400);
  assert.equal(inv.getItem(0).getDynamicProperty('rpg:weapon_upgrade'),8);
  assert.equal(inv.getItem(0).getDynamicProperty('rpg:rarity'),6);
  assert.equal(stats.defaultDamageTypeFor(p),'magic');
  assert.equal(guide.visibleSkillGuideGroups(p).find(g=>g.line==='bloodedge').ids.length,10);
  assert.match(mod('core/hud.js').compactHudText(p),/혈기 0\/100/);
  const ctx=mod('core/context.js').getContext(p);
  data.setIndex(p,ctx.skills.indexOf('crimson_step'));
  data.forceSetManaMax(p,'1000');data.setMana(p,1000);
  system.currentTick+=10;
  componentHandlers.get('rpg:cast_item').onUse({source:p});timers.at(-1)();
  assert.equal(p.location.z,7);assert.equal(data.getMana(p),955);assert.equal(data.cooldownLeft(p,'crimson_step'),160);
 }finally{Form.prototype.show=oldShow;Form.prototype.body=oldBody;}
 console.log('Crimson promotion at the NPC without a card: level and clear status, selection recheck, same scythe and cooldowns, ten visible skills and actual cast-item dispatch');
}
{
 const skill=mod('skills/crimsonSiwang.js'),def=mod('data/skills.js').SKILLS.crimson_siwang;
 const {p,inv}=player('crimson_lord');p.id='test-siwang';
 const ctx=mod('core/context.js'),hud=mod('core/hud.js'),states=mod('core/bloodedgeState.js').siwangSessions;
 const phase=new Map(),damages=[],effects=[];
 let velocity={x:0,y:0,z:0},targets=[],wallX;
 p.setProperty=(key,value)=>phase.set(key,value);
 p.getVelocity=()=>({...velocity});
 p.clearVelocity=()=>{velocity={x:0,y:0,z:0};};
 p.applyImpulse=({x,y,z})=>{velocity={x:velocity.x+x,y:velocity.y+y,z:velocity.z+z};};
 p.getViewDirection=()=>({x:0,y:.6,z:.8});
 p.dimension.getBlock=at=>({isSolid:at.y<64||(wallX!==undefined&&at.x>=wallX)});
 p.dimension.getEntities=()=>targets;
 p.dimension.spawnParticle=(id,at)=>effects.push([id,at]);
 p.onScreenDisplay.setHudVisibility=()=>{};
 inv.setItem(0,new ItemStack(jobs.crimson_lord.weapon));
 data.setIndex(p,ctx.getContext(p).skills.indexOf(def.id));
 data.forceSetManaMax(p,'1000');data.setMana(p,1000);
 function itemUse(){
  componentHandlers.get('rpg:cast_item').onUse({source:p});
  timers.at(-1)();
 }
 function step(){
  system.currentTick++;
  const {x,y,z}=p.location;
  const landed=y+velocity.y<=64;
  p.location={x:x+velocity.x,y:Math.max(64,y+velocity.y),z:z+velocity.z};
  velocity.y=landed?0:velocity.y-.08;
  p.isOnGround=landed;
  skill.tickSiwang();
 }
 function target(id,delta,typeId='minecraft:zombie'){
  const t={id,typeId,dimension:p.dimension,isValid:true,location:{x:p.location.x+delta,y:64,z:p.location.z},
   getComponent:name=>name==='minecraft:health'?{currentValue:900}:undefined,
   getGameMode:()=>typeId==='minecraft:player'?'creative':undefined,
   applyDamage:amount=>{damages.push([id,amount]);return true;}};
  return t;
 }
 const advanceToLanding=()=>{
  for(let i=0;i<220&&states.has(p.id);i++)step();
  assert.equal(p.location.y,64);
  assert.equal(phase.get('rpg:siwang_phase'),0);
  assert.equal(states.has(p.id),false);
 };
 const at=system.currentTick;
 itemUse();
 assert.equal(phase.get('rpg:siwang_phase'),1);
 assert.equal(data.getMana(p),900);
 assert.equal(data.cooldownLeft(p,def.id),440);
 assert.match(hud.compactHudText(p),/재사용: 급강하/);
 for(let i=0;i<22;i++)step();
 assert.ok(p.location.y>64&&p.location.z>0);
 const cooldown=data.cooldownLeft(p,def.id);
 itemUse();
 assert.equal(data.getMana(p),900);assert.equal(data.cooldownLeft(p,def.id),cooldown);
 assert.equal(phase.get('rpg:siwang_phase'),2);
 for(let i=0;i<5;i++)step();
 assert.ok(p.getVelocity().y<0);
 itemUse();assert.equal(data.getMana(p),900);
 const behind=target('wall',7);
 wallX=p.location.x+4;
 targets=[target('open',2),behind,target('outside',12),target('survival-check',1,'minecraft:player')];
 advanceToLanding();
 assert.deepEqual(damages,[['open',90]]);
 assert.equal(effects.filter(([id])=>id==='rpg:bloodedge_guard_flash').length,1);
 const cleanupAfterLanding=timers.at(-1);
 cleanupAfterLanding();assert.equal(p.hasTag('rpg_siwang_fall'),false);
 step();assert.equal(damages.length,1);

 targets=[];wallX=undefined;
 assert.equal(skill.castSiwang(p,jobs.crimson_lord,def),true);
 const autoAt=system.currentTick;
 for(let i=0;i<199;i++)step();
 assert.equal(system.currentTick,autoAt+199);assert.equal(phase.get('rpg:siwang_phase'),1);
 step();assert.equal(phase.get('rpg:siwang_phase'),2);
 advanceToLanding();
 assert.ok(system.currentTick-at>200);
 assert.equal(effects.filter(([id])=>id==='rpg:bloodedge_guard_flash').length,2);

 assert.equal(skill.castSiwang(p,jobs.crimson_lord,def),true);
 p.dimension={...p.dimension,id:'minecraft:nether'};
 step();assert.equal(phase.get('rpg:siwang_phase'),0);
 assert.equal(p.hasTag('rpg_siwang_fall'),false);assert.equal(damages.length,1);
 const {p:old}=player('crimson_lord');old.id='v0683-siwang';
 old.setDynamicProperty('rpg:disabled_skills',JSON.stringify(['crimson_altar']));
 old.setDynamicProperty(data.COOLDOWN_KEY,JSON.stringify({version:1,until:{crimson_altar:Date.now()+5000}}));
 assert.deepEqual(Array.from(data.getDisabled(old)),[def.id]);
 assert.ok(data.cooldownLeft(old,def.id)>0);
 assert.ok(!data.getSkills(old).includes('crimson_altar'));
 console.log('Siwang: real item input, one mana charge and cooldown, early recast and 200-tick automatic dive, native-like trajectory, one impact, wall/range filtering, dimension cleanup and no stale altar settings');
}
{
 const hints=mod('data/jobStats.js'),guide=mod('core/skillGuide.js');
 for(const job of Object.values(jobs).filter(j=>!j.placeholder)){assert.ok(hints.LINE_STAT_GUIDES[job.line],job.id);assert.ok(hints.jobStatText(job).includes('추천 스탯:'));}
 assert.match(hints.jobStatText(jobs.chameleon,'mage'),/추천 스탯: 복합/);assert.match(hints.jobStatText(jobs.nen),/근력·마력/);assert.match(hints.jobStatText(jobs.fighter),/풍압은 마력/);
 const originalBody=Form.prototype.body,bodies=[];Form.prototype.body=function(text){bodies.push(text);return this;};
 try{
  for(const [job,expected]of [['swordsman','근력'],['mage','마력'],['cleric','마력'],['archer','근력'],['the_world','근력'],['war_god','근력'],['nen','복합'],['chameleon','복합']]){
   const {p,inv}=player(job);data.setSkills(p,jobs[job].skills);inv.setItem(0,new ItemStack(jobs[job].weapon));bodies.length=0;await guide.openSkillGuide(p);assert.match(bodies[0],new RegExp('추천 스탯: '+expected),job+' guide');bodies.length=0;await mod('core/skillMenu.js').openSkillMenu(p);assert.match(bodies[0],new RegExp('추천 스탯: '+expected),job+' settings');
  }
 }finally{Form.prototype.body=originalBody;}
 for(const [skill,stat]of [['world_stop','근력'],['mage_fireball','마력'],['holy_heal','마력'],['chameleon_crimson_dash','복합']])assert.ok(guide.skillGuideDetail(skill).includes('추천 스탯: '+stat));
 console.log('Stat guidance: every active job mapped, actual skill guide/settings form bodies show STR/MAG, Chameleon always 복합, Nen mixed and Fist exception displayed, skill details preserve effects');
}
{
 const grade=mod('core/setGrade.js'),rarity=mod('data/rarity.js'),grades=mod('data/grades.js');
 for(let i=0;i<7;i++){assert.equal(grade.parseGrade(String(i)),i);assert.equal(grade.parseGrade(grades.RARITIES[i]),i);}for(const value of ['',-1,7,'6.0','신화 추가','NaN'])assert.equal(grade.parseGrade(value),undefined);
 const {p,inv}=player();const item=new ItemStack('rpg:common_redmoon_blade');item.nameTag='my custom weapon';item.durability.damage=137;item.setDynamicProperty('rpg:weapon_upgrade',8);item.setDynamicProperty('rpg:weapon_uid','bound-unique');item.setDynamicProperty('custom:option',17);item.setLore(['custom lore']);inv.setItem(0,item);
 const before=mod('core/gearState.js').gearFingerprint(inv.getItem(0));assert.equal(grade.setEquipmentGrade(p,'신화').ok,false);assert.equal(mod('core/gearState.js').gearFingerprint(inv.getItem(0)),before);
 p.commandPermissionLevel=1;for(let i=6;i>=0;i--){const r=grade.setEquipmentGrade(p,String(i));assert.equal(r.ok,true,r.reason);const next=inv.getItem(0);assert.equal(rarity.itemRarity(next).rank,i);assert.equal(next.getDynamicProperty('rpg:weapon_upgrade'),8);assert.equal(next.getDynamicProperty('rpg:weapon_uid'),'bound-unique');assert.equal(next.getDynamicProperty('custom:option'),17);assert.equal(next.nameTag,'my custom weapon');assert.equal(next.durability.damage,137);assert.ok(next.getLore().includes('custom lore'));}
 inv.setItem(0,new ItemStack('minecraft:stone'));assert.equal(grade.setEquipmentGrade(p,'신화').ok,false);const jobWeapon=new ItemStack(jobs.swordsman.weapon);
 jobWeapon.setDynamicProperty('rpg:weapon_upgrade',8);
 inv.setItem(0,jobWeapon);
 delete p.selectedSlotIndex;
 const originalGet=p.getComponent;
 p.getComponent=id=>id==='minecraft:equippable'?{getEquipment:slot=>slot==='Mainhand'?inv.getItem(0):undefined,setEquipment:(slot,item)=>{assert.equal(slot,'Mainhand');inv.setItem(0,item);return true;}}:originalGet(id);
 assert.equal(grade.setEquipmentGrade(p,'신화 hand').ok,true);
 const mythic=inv.getItem(0);
 assert.equal(mythic.getDynamicProperty('rpg:rarity'),6);
 assert.equal(mythic.getDynamicProperty('rpg:weapon_upgrade'),8);
 assert.match(mythic.nameTag,/신화/);
 assert.ok(mod('core/commonWeaponDamage.js').commonWeaponFactor(mythic)>mod('core/commonWeaponDamage.js').commonWeaponFactor(jobWeapon));
 assert.match(mod('core/gearState.js').setGearLevel(mythic,'weapon',9).nameTag,/신화.*\+9/);
 const token=new ItemStack('rpg:rune_power',12);mod('core/rarityLabels.js').decorateRarity(token);inv.setItem(0,token);assert.equal(grade.setEquipmentGrade(p,'전설').ok,false);assert.equal(inv.getItem(0).amount,12);assert.equal(rarity.itemRarity(inv.getItem(0)).rank,0);
 console.log('Set grade: all seven names/numbers, admin-only, upgrade/UID/name/durability/custom options preserved, lowering allowed, unsupported items rejected, job weapon grade set through native mainhand, stackable rune tokens preserved and redirected to storage');
}
{
 const {p,inv}=player(),grade=mod('core/setGrade.js'),runes=mod('core/runeInventory.js'),gear=mod('core/equipment.js');p.commandPermissionLevel=1;const bag=runes.readRuneBag(p),r=runes.addRuneRecord(bag,'power',8,0),other=runes.addRuneRecord(bag,'ward',2,1);bag.equipped[0]=r.uid;runes.writeRuneBag(p,bag);const beforeBonus=gear.getEquipmentBonuses(p).physical;
 assert.equal(grade.setEquipmentGrade(p,'신화 rune1').ok,true);const next=runes.readRuneBag(p);assert.equal(next.runes[0].grade,6);assert.equal(next.runes[0].level,8);assert.equal(next.equipped[0],r.uid);assert.equal(next.runes[1].grade,1);assert.ok(gear.getEquipmentBonuses(p).physical>beforeBonus);
 assert.equal(grade.setEquipmentGrade(p,'일반 rune:'+other.uid).ok,true);assert.equal(runes.readRuneBag(p).runes[1].grade,0);assert.equal(grade.setEquipmentGrade(p,'신화 rune5').ok,false);assert.equal(grade.setEquipmentGrade(p,'신화 rune2').ok,false);
 const equipment=new Map(),originalGet=p.getComponent;p.getComponent=id=>id==='minecraft:equippable'?{getEquipment:s=>equipment.get(s)?.clone(),setEquipment:(s,i)=>{equipment.set(s,i?.clone());return true;}}:originalGet(id);const helmet=new ItemStack('rpg:adventurer_helmet');helmet.setDynamicProperty('rpg:armor_upgrade',6);helmet.durability.damage=33;equipment.set('Head',helmet);const hp=gear.getEquipmentBonuses(p).health;
 assert.equal(grade.setEquipmentGrade(p,'신화 head').ok,true);assert.equal(equipment.get('Head').getDynamicProperty('rpg:rarity'),6);assert.equal(equipment.get('Head').getDynamicProperty('rpg:armor_upgrade'),6);assert.equal(equipment.get('Head').durability.damage,33);assert.equal(gear.getEquipmentBonuses(p).health,hp+22);
 console.log('Grade targets: equipped armor preserves enhancement/durability and changes HP; equipped/bag UID rune grade changes real bonus and keeps level/equip; empty/locked targets refused');
}
{
 const {p,inv,messages}=player(),fusion=mod('core/fusion.js'),gear=mod('core/gearState.js');
 const ref={kind:'inventory',slot:4},helmet=new ItemStack('rpg:adventurer_helmet');
 helmet.nameTag='custom helmet';helmet.durability.damage=72;helmet.enchants=[{type:{id:'minecraft:mending'},level:1}];
 helmet.setDynamicProperty('rpg:armor_upgrade',9);
 inv.setItem(ref.slot,helmet);
 const book=new ItemStack('minecraft:enchanted_book');
 book.enchants=[{type:{id:'minecraft:protection'},level:4}];
 inv.setItem(5,book);
 assert.equal(fusion.fuseEquipment(p,ref).ok,false);
 helmet.setDynamicProperty('rpg:armor_upgrade',10);
 inv.setItem(ref.slot,helmet);
 inv.setItem(6,helmet);
 assert.equal(fusion.fusionQuote(p,ref,{kind:'inventory',slot:6}),undefined);
 const original=gear.gearFingerprint(inv.getItem(ref.slot)),originalBook=gear.gearFingerprint(inv.getItem(5));
 const q=fusion.fusionQuote(p,ref);
 assert.equal(q.chance,100);
 assert.equal(fusion.fuseEquipment(p,ref,undefined,'stale quote').ok,false);
 const set=inv.setItem;
 let fail=true;
 inv.setItem=(slot,item)=>{if(slot===ref.slot&&fail){fail=false;throw Error('injected promotion write failure');}set(slot,item);};
 assert.equal(fusion.fuseEquipment(p,ref,undefined,q.fingerprint).ok,false);
 assert.equal(gear.gearFingerprint(inv.getItem(ref.slot)),original);
 assert.equal(gear.gearFingerprint(inv.getItem(5)),originalBook);
 const wrongBook=book.clone();
 wrongBook.enchants[0].level=3;
 inv.setItem(5,wrongBook);
 assert.equal(fusion.fuseEquipment(p,ref,undefined,q.fingerprint).ok,false);
 assert.equal(gear.gearFingerprint(inv.getItem(ref.slot)),original);
 inv.setItem(5,book);
 const show=Form.prototype.show;
 const selections=[0,1];
 Form.prototype.show=async()=>selections.length?{selection:selections.shift()}:{canceled:true};
 try{await fusion.openFusionMenu(p);}finally{Form.prototype.show=show;}
 const next=inv.getItem(ref.slot);
 assert.match(messages.at(-1),/승급 성공/);
 assert.equal(inv.getItem(5),undefined);
 assert.equal(gear.gearFingerprint(inv.getItem(6)),original);
 assert.equal(next.getDynamicProperty('rpg:rarity'),1);
 assert.equal(next.getDynamicProperty('rpg:armor_upgrade'),0);
 assert.equal(next.nameTag,helmet.nameTag);
 assert.equal(next.durability.damage,72);
 assert.equal(next.enchants[0].type.id,'minecraft:mending');
 next.setDynamicProperty('rpg:rarity',6);
 next.setDynamicProperty('rpg:armor_upgrade',10);
 inv.setItem(ref.slot,next);
 assert.equal(fusion.fusionQuote(p,ref),undefined);
 console.log('Armor promotion: +10 plus one Protection IV book, UI confirmation, no duplicate consumed, full rollback and invalid inputs checked');
}
{
 const {p,inv}=player(),grade=mod('core/setGrade.js');p.commandPermissionLevel=1;inv.setItem(0,new ItemStack('rpg:common_redmoon_blade'));const original=mod('core/gearState.js').gearFingerprint(inv.getItem(0)),set=inv.setItem;let fail=true;inv.setItem=(i,item)=>{if(fail){fail=false;throw Error('injected grade write failure');}set(i,item);};assert.equal(grade.setEquipmentGrade(p,'신화').ok,false);assert.equal(mod('core/gearState.js').gearFingerprint(inv.getItem(0)),original);
 const {p:normal,inv:normalInv}=player();normalInv.setItem(0,new ItemStack('rpg:common_redmoon_blade'));mod('core/rpgActions.js').runRpgAction('setgrade',normal,'신화');assert.equal(normalInv.getItem(0).getDynamicProperty('rpg:rarity'),undefined);
 console.log('Grade command: direct script action permission enforced, failed item save rolls back');
}
{
 const [command,...duplicates]=allCommandDefs.get('rpg:setgrade');
 assert.equal(duplicates.length,0);
 assert.equal(command.d.permissionLevel,1);assert.equal(command.d.cheatsRequired,false);
 assert.equal(command.d.mandatoryParameters[0].name,'grade');
 assert.equal(command.d.optionalParameters[0].name,'target');assert.equal(command.d.optionalParameters[1].type,server.CustomCommandParamType.Integer);
 const {p,inv,messages}=player();
 p.runCommand=()=>assert.fail('Grade command must not relay through scriptevent');
 p.commandPermissionLevel=1;
 const run=(...args)=>{command.fn({sourceEntity:p},...args);timers.at(-1)();};
 inv.setItem(0,new ItemStack('rpg:common_redmoon_blade'));
 const equipment=new Map([['Head',new ItemStack('rpg:adventurer_helmet')],['Chest',new ItemStack('rpg:adventurer_chestplate')],['Legs',new ItemStack('rpg:adventurer_leggings')],['Feet',new ItemStack('rpg:adventurer_boots')]]);
 const getComponent=p.getComponent;
 p.getComponent=id=>id==='minecraft:equippable'?{getEquipment:s=>equipment.get(s)?.clone(),setEquipment:(s,item)=>{equipment.set(s,item?.clone());return true;}}:getComponent(id);
 run('레어','hand');assert.equal(inv.getItem(0).getDynamicProperty('rpg:rarity'),1);
 for(const [target,slot]of [['head','Head'],['chest','Chest'],['leggings','Legs'],['boots','Feet'],['legs','Legs'],['feet','Feet']]){
  run('고대',target);assert.equal(equipment.get(slot).getDynamicProperty('rpg:rarity'),3);
 }
 const runes=mod('core/runeInventory.js'),bag=runes.readRuneBag(p);
 bag.unlockedSlots=5;
 for(const [index,id]of ['power','ward','mana','arcane','vitality'].entries())bag.equipped[index]=runes.addRuneRecord(bag,id,9,0).uid;
 runes.writeRuneBag(p,bag);
 for(let i=1;i<=5;i++)run('신화','runes',i);
 assert.ok(runes.readRuneBag(p).runes.every(r=>r.grade===6&&r.level===9));
 run(['5','rune1']);assert.equal(runes.readRuneBag(p).runes[0].grade,5);
 const previous=p.getDynamicProperty(runes.RUNE_BAG_KEY);
 for(const args of [['신화','runes',0],['신화','runes',6],['신화','runes'],['신화','boots',2]]){
  run(...args);assert.match(messages.at(-1),/\/rpg:setgrade/);
  assert.equal(p.getDynamicProperty(runes.RUNE_BAG_KEY),previous);
 }
 p.commandPermissionLevel=0;run('일반','runes',1);
 assert.match(messages.at(-1),/관리자만/);
 assert.equal(p.getDynamicProperty(runes.RUNE_BAG_KEY),previous);
 console.log('Direct grade command: one owner, all armor aliases, 5 rune slots, legacy syntax, invalid combinations and non-operator rejected');
}
{
 const {p,inv}=player('chameleon'),progress=mod('core/chameleonProgress.js'),tr=mod('core/chameleonTranscend.js'),wallet=mod('core/wallet.js'),skills=mod('data/skills.js').SKILLS;
 const ids=['war_god_flurry','sage_zoltraak','fallen_end','dragon_domain'];const state=progress.readChameleonProgress(p);state.learned=[...ids];state.evolved=ids.slice(0,3);progress.saveChameleonProgress(p,state);data.setSkills(p,[...jobs.chameleon.skills,...ids]);wallet.setWallet(p,{gold:3000000,stone:10000,dust:123});
 inv.setItem(3,new ItemStack('minecraft:netherite_ingot',6));inv.setItem(4,new ItemStack('minecraft:diamond_block',27));
 const costs=[[200000,800],[500000,2000],[750000,3000]];const stale=tr.transcendQuote(p,ids[1]);
 for(let i=0;i<3;i++){const q=tr.transcendQuote(p,ids[i]);assert.equal(q.cost.gold,costs[i][0]);assert.equal(q.cost.stone,costs[i][1]);assert.equal(q.materials['minecraft:netherite_ingot'],2);assert.equal(q.materials['minecraft:diamond_block'],9);const r=tr.purchaseTranscend(p,ids[i],'transcend',q.fingerprint);assert.equal(r.ok,true,r.message);assert.equal(r.level,0);if(i===0){const snapshot=p.getDynamicProperty(progress.CHAMELEON_KEY),money=JSON.stringify(wallet.getWallet(p));assert.equal(tr.purchaseTranscend(p,ids[1],'transcend',stale.fingerprint).ok,false);assert.equal(p.getDynamicProperty(progress.CHAMELEON_KEY),snapshot);assert.equal(JSON.stringify(wallet.getWallet(p)),money);}}
 assert.equal(wallet.getWallet(p).gold,1550000);assert.equal(wallet.getWallet(p).stone,4200);assert.equal(wallet.getWallet(p).dust,123);assert.equal(inv.getItem(3),undefined);assert.equal(inv.getItem(4),undefined);assert.equal(Object.keys(progress.readChameleonProgress(p).transcended).length,3);assert.equal(tr.transcendQuote(p,ids[0]),undefined);assert.equal(tr.transcendQuote(p,ids[3]),undefined);
 for(let level=1;level<=3;level++){const q=tr.transcendQuote(p,ids[0],'upgrade');assert.equal(q.cost.gold,30000);assert.equal(q.cost.stone,100);assert.equal(Object.keys(q.materials).length,0);assert.equal(tr.purchaseTranscend(p,ids[0],'upgrade',q.fingerprint).ok,true);assert.equal(tr.transcendLevel(p,ids[0]),level);}assert.equal(tr.transcendQuote(p,ids[0],'upgrade'),undefined);assert.equal(wallet.getWallet(p).gold,1460000);assert.equal(wallet.getWallet(p).stone,3900);
 const base=JSON.stringify(skills.war_god_flurry),scaled=tr.transcendedSkillDefinition(p,skills.war_god_flurry);assert.equal(scaled.damage,16*1.55);assert.equal(scaled.projectiles,32);assert.equal(scaled.cooldown,0);assert.equal(JSON.stringify(skills.war_god_flurry),base);assert.equal(tr.transcendedSkillDefinition(p,skills.nen_ho),skills.nen_ho);assert.ok(mod('core/skillGuide.js').skillGuideDetail(ids[0],p).includes('초월 +3'));
 const {p:rejoin}=player('chameleon');for(const [k,v]of p.getDynamicPropertyIds().map(k=>[k,p.getDynamicProperty(k)]))rejoin.setDynamicProperty(k,v);assert.equal(tr.transcendLevel(rejoin,ids[0]),3);data.setJobId(rejoin,'mage');assert.equal(tr.transcendedSkillDefinition(rejoin,skills.war_god_flurry),skills.war_god_flurry);
 const qBefore=wallet.getWallet(p);assert.equal(progress.dismantleChameleonSkill(p,ids[0]).ok,true);assert.equal(tr.transcendLevel(p,ids[0]),undefined);assert.equal(Object.keys(progress.readChameleonProgress(p).transcended).length,2);assert.equal(JSON.stringify(wallet.getWallet(p)),JSON.stringify(qBefore));
 console.log('Transcend: exact 200k/500k/750k and 800/2000/3000 costs, 2 ingots+9 blocks each, stale quote refused, max 3 skills, +3 upgrades at 30k+100, power snapshots, rejoin/job changes, dismantle without refund');
}
{
 const progress=mod('core/chameleonProgress.js'),tr=mod('core/chameleonTranscend.js'),wallet=mod('core/wallet.js');
 function setup(){const {p,inv}=player('chameleon'),s=progress.readChameleonProgress(p);s.learned=['war_god_flurry'];s.evolved=['war_god_flurry'];progress.saveChameleonProgress(p,s);data.setSkills(p,[...jobs.chameleon.skills,'war_god_flurry']);wallet.setWallet(p,{gold:200000,stone:800,dust:3});inv.setItem(3,new ItemStack('minecraft:netherite_ingot',1));inv.setItem(4,new ItemStack('minecraft:netherite_ingot',1));inv.setItem(5,new ItemStack('minecraft:diamond_block',9));return {p,inv};}
 for(const failure of ['material','wallet','inventory_write','progress_write']){
  const {p,inv}=setup();if(failure==='material')inv.setItem(5,new ItemStack('minecraft:diamond_block',8));if(failure==='wallet')wallet.setWallet(p,{gold:199999,stone:800,dust:3});
  const before=p.getDynamicProperty(progress.CHAMELEON_KEY),funds=p.getDynamicProperty(wallet.WALLET_KEY),items=Array.from({length:inv.size},(_,i)=>inv.getItem(i)?.amount);
  if(failure==='inventory_write'){const set=inv.setItem;let writes=0;inv.setItem=(i,v)=>{if(++writes===2)throw Error('second material write failure');set(i,v);};}
  if(failure==='progress_write'){const set=p.setDynamicProperty;let fail=true;p.setDynamicProperty=(k,v)=>{if(k===progress.CHAMELEON_KEY&&fail){fail=false;throw Error('progress write failure');}set(k,v);};}
  const r=tr.purchaseTranscend(p,'war_god_flurry');assert.equal(r.ok,false,failure);assert.equal(p.getDynamicProperty(progress.CHAMELEON_KEY),before,failure);assert.equal(p.getDynamicProperty(wallet.WALLET_KEY),funds,failure);assert.deepEqual(Array.from({length:inv.size},(_,i)=>inv.getItem(i)?.amount),items,failure);
 }
 const {p}=setup();data.setJobId(p,'mage');assert.equal(tr.purchaseTranscend(p,'war_god_flurry').ok,false);
 console.log('Transcend transactions: missing materials/funds, failed second material write and progress write leave all original items/wallet/progress intact; other jobs denied');
}
{
 const {p,inv}=player('chameleon'),progress=mod('core/chameleonProgress.js'),tr=mod('core/chameleonTranscend.js'),skill=mod('data/skills.js').SKILLS.mage_gravity;
 const state=progress.readChameleonProgress(p);state.learned=['mage_gravity'];state.evolved=['mage_gravity'];state.transcended={mage_gravity:0};progress.saveChameleonProgress(p,state);data.setSkills(p,[...jobs.chameleon.skills,'mage_gravity']);data.setDisabled(p,jobs.chameleon.skills);data.setIndex(p,0);inv.setItem(0,new ItemStack(jobs.chameleon.weapon));data.forceSetManaMax(p,'5000');data.setMana(p,5000);system.currentTick+=50;p.getViewDirection=()=>({x:0,y:0,z:1});
 const targetHealth={currentValue:1000,effectiveMax:1000,setCurrentValue(n){this.currentValue=n;}},hits=[];const target={id:'gravity-target',typeId:'minecraft:zombie',isValid:true,dimension:p.dimension,location:{x:0,y:64,z:3},getTags:()=>[],hasTag:()=>false,getDynamicProperty:()=>undefined,getComponent:k=>k==='minecraft:health'?targetHealth:undefined,applyDamage(n){hits.push(n);targetHealth.currentValue-=n;return true;},addEffect:()=>{}};
 p.dimension.getEntities=()=>[target];p.dimension.getBlock=()=>({isAir:true,isSolid:false,typeId:'minecraft:air'});componentHandlers.get('rpg:cast_item').onUse({source:p});const cast=timers.at(-1);cast();assert.equal(hits.length,1);assert.ok(Math.abs(hits[0]-skill.damage*1.25)<1e-7,JSON.stringify({hits,base:skill.damage}));assert.equal(data.cooldownLeft(p,skill.id),skill.cooldown);assert.equal(skill.damage,10);assert.equal(progress.remainingSkillUses(p,skill.id),null);
 console.log('Actual input cast path: evolved transcended mage skill deals exactly +25%, original cooldown/shared definition retained, evolved use remains unlimited');
}
{
 const {p,inv}=player('chameleon'),progress=mod('core/chameleonProgress.js'),wallet=mod('core/wallet.js'),tr=mod('core/chameleonTranscend.js'),s=progress.readChameleonProgress(p);s.learned=['war_god_flurry'];s.evolved=['war_god_flurry'];progress.saveChameleonProgress(p,s);data.setSkills(p,[...jobs.chameleon.skills,'war_god_flurry']);wallet.setWallet(p,{gold:230000,stone:900,dust:0});inv.setItem(3,new ItemStack('minecraft:netherite_ingot',2));inv.setItem(4,new ItemStack('minecraft:diamond_block',9));
 const show=Form.prototype.show;
 try{
  for(const [button,level]of [[5,0],[6,1]]){const answers=[button,0,1,undefined,undefined];Form.prototype.show=()=>{const n=answers.shift();return Promise.resolve(n===undefined?{canceled:true}:{canceled:false,selection:n});};await mod('core/chameleon.js').openChameleonSkillbook(p);assert.equal(tr.transcendLevel(p,'war_god_flurry'),level);}
 }finally{Form.prototype.show=show;}
 assert.equal(wallet.getWallet(p).gold,0);assert.equal(wallet.getWallet(p).stone,0);
 console.log('Actual Chameleon skillbook UI: transcend and upgrade buttons, target and confirmation each execute at stated prices');
}
{
 const {p,inv}=player('chameleon'),progress=mod('core/chameleonProgress.js'),tr=mod('core/chameleonTranscend.js'),defs=mod('data/skills.js').SKILLS,s=progress.readChameleonProgress(p);s.learned=['sage_zoltraak'];s.evolved=['sage_zoltraak'];s.transcended={sage_zoltraak:0};progress.saveChameleonProgress(p,s);data.setSkills(p,['sage_zoltraak']);p.getViewDirection=()=>({x:0,y:0,z:1});
 const hits=[],target={id:'delayed-target',typeId:'minecraft:zombie',location:{x:0,y:64,z:3},getTags:()=>[],hasTag:()=>false,getDynamicProperty:()=>undefined,getComponent:k=>k==='minecraft:health'?{currentValue:1000}:undefined,applyDamage:n=>{hits.push(n);return true;}};p.dimension.getEntities=()=>[target];p.dimension.getBlock=()=>({isAir:true,typeId:'minecraft:air'});
 const castDef=tr.transcendedSkillDefinition(p,defs.sage_zoltraak);mod('skills/mage.js').RUNNERS.sage_zoltraak(p,jobs.sage,castDef);const delayed=timers.at(-1);s.transcended.sage_zoltraak=3;progress.saveChameleonProgress(p,s);delayed();assert.equal(hits.length,1);assert.equal(hits[0],120);assert.equal(defs.sage_zoltraak.damage,96);
 console.log('Delayed spell power snapshot: charge retains cast-time +25% even after upgrade, shared original stays 96');
}
{
 const defs=mod('data/skills.js').SKILLS;
 for(const job of ['nen','chameleon']){
  const {p,inv}=player(job);p.id='cannon-'+job;p.getViewDirection=()=>({x:0,y:0,z:1});p.dimension.getEntities=()=>[];p.dimension.getBlock=()=>({isAir:true,typeId:'minecraft:air'});data.setSkills(p,job==='nen'?jobs.nen.skills:[...jobs.chameleon.skills,'nen_ho']);data.setDisabled(p,(job==='nen'?jobs.nen.skills:jobs.chameleon.skills).filter(id=>id!=='nen_ho'));data.setIndex(p,0);inv.setItem(0,new ItemStack(jobs[job].weapon));data.forceSetManaMax(p,'5000');data.setMana(p,5000);system.currentTick+=100;componentHandlers.get('rpg:cast_item').onUse({source:p});timers.at(-1)();assert.equal(data.cooldownLeft(p,'nen_ho'),900,job);
 }
 console.log('Actual input cooldown: Nen and borrowed Chameleon cannon both start exactly 45 seconds');
}
{
 const {p}=player('chameleon'),progress=mod('core/chameleonProgress.js');p.setDynamicProperty(progress.CHAMELEON_KEY,JSON.stringify({version:1,spentSp:15,learned:['world_stop'],charges:{world_stop:0},evolved:['world_stop'],levelsToBook:3,pendingBooks:2}));const legacy=progress.readChameleonProgress(p);assert.equal(Object.keys(legacy.transcended).length,0);assert.equal(legacy.charges.world_stop,0);assert.equal(legacy.spentSp,15);assert.equal(legacy.levelsToBook,3);assert.equal(legacy.pendingBooks,2);assert.equal(legacy.evolved[0],'world_stop');
 console.log('Legacy Chameleon progression gains empty transcend data without resetting SP, charges, evolution or pending books');
}
{
 const pages=mod('core/rulebook.js').RULEBOOK_PAGES;assert.ok(pages.length<=50);assert.ok(pages.every(p=>p.length<=256));console.log('Rulebook remains within native 50-page / 256-character limits');
}
{
 const {p,inv}=player('swordsman'),def=mod('data/skills.js').SKILLS;
 p.id='sword-draw';
 inv.setItem(0,new ItemStack(jobs.swordsman.weapon));
 const context=mod('core/context.js');
 assert.ok(context.getContext(p).skills.includes('sword_draw'),'Existing Swordsman learns Draw');
 assert.ok(jobs.sword_saint.skills.includes('sword_annihilation'));
 assert.ok(!jobs.sword_saint.skills.includes('sword_draw'));
 const hits=[],moves=[];
 const mob=(id,x,z)=>({id,typeId:'minecraft:zombie',isValid:true,dimension:p.dimension,location:{x,y:64,z},getComponent:()=>({currentValue:1000}),applyDamage(n){hits.push([id,n]);return true;},getTags:()=>[],hasTag:()=>false,getDynamicProperty:()=>undefined});
 const targets=[mob('fourth',3.9,.2),mob('second',3,1),mob('third',3.5,-.4),mob('nearest',2,0),mob('blocked',0,1.1)];
 p.dimension.getEntities=()=>targets;
 // Keep the light cover only in front of the blocked target and leave the next candidate visible.
 p.dimension.getBlock=({x,z})=>({isSolid:x<1&&z>=.5});
 p.teleport=(pos,options)=>moves.push([pos,options]);
 const runner=mod('skills/sword.js').RUNNERS.sword_draw;
 assert.equal(runner(p,jobs.swordsman,def.sword_draw),true);
 assert.equal(moves[0][0].x,1);
 assert.deepEqual(hits.map(([id])=>id),['nearest','second','third']);
 const stats=mod('core/stats.js');
 const reference=stats.skillDamageFor(p,def.sword_annihilation.damage,'physical');
 assert.ok(hits.every(([,amount])=>Math.abs(amount/reference-.6)<1e-10));
 p.dimension.getEntities=()=>[targets.at(-1)];
 assert.equal(runner(p,jobs.swordsman,def.sword_draw),false);
 assert.equal(moves.length,1);
 assert.equal(runner(p,jobs.sword_saint,def.sword_draw),false);
 const rewards=mod('core/economy.js');
 assert.equal(rewards.currencyReward('minecraft:zombie',()=>.299).dust,1);
 assert.equal(rewards.currencyReward('minecraft:zombie',()=>.3).dust,0);
 assert.equal(rewards.currencyReward('rpg:elite_deathworm').dust,2);
 assert.equal(rewards.currencyReward('rpg:hydra_boss').dust,12);
 console.log('Draw unlock and Saint replacement, closest reachable target, three unique hits, 60% physical ratio, wall and rune-dust checks passed');
}

{
 const {p,inv}=player('chameleon');p.id='rebalance-reference';
 const progress=mod('core/chameleonProgress.js'),runes=mod('core/runeInventory.js'),skill=mod('data/skills.js').SKILLS.sword_annihilation;
 const state=progress.readChameleonProgress(p);state.learned=['sword_annihilation'];state.evolved=['sword_annihilation'];progress.saveChameleonProgress(p,state);
 data.setSkills(p,[...jobs.chameleon.skills,skill.id]);data.setDisabled(p,jobs.chameleon.skills);data.setIndex(p,0);
 const weapon=new ItemStack(jobs.chameleon.weapon);weapon.setDynamicProperty('rpg:weapon_upgrade',6);inv.setItem(0,weapon);
 p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:25,mag:5,vit:5,int:5}));
 const bag=runes.readRuneBag(p),rune=runes.addRuneRecord(bag,'power',0,1);bag.equipped[0]=rune.uid;runes.writeRuneBag(p,bag);
 data.forceSetManaMax(p,'5000');data.setMana(p,5000);system.currentTick+=100;
 p.getViewDirection=()=>({x:0,y:0,z:1});p.getRotation=()=>({x:0,y:0});p.teleport=at=>p.location={...at};
 const hp={currentValue:1000,effectiveMax:1000,setCurrentValue(n){this.currentValue=n;}},hits=[];
 const target={id:'annihilation-balance-dummy',typeId:'minecraft:zombie',isValid:true,dimension:p.dimension,location:{x:0,y:64,z:3},getTags:()=>[],hasTag:()=>false,getDynamicProperty:()=>undefined,getComponent:k=>k==='minecraft:health'?hp:undefined,applyDamage:n=>{hits.push(n);hp.currentValue-=n;return true;}};
 p.dimension.getEntities=()=>[target,target];p.dimension.getBlock=()=>({isAir:true,isSolid:false,typeId:'minecraft:air'});
 componentHandlers.get('rpg:cast_item').onUse({source:p});timers.at(-1)();
 assert.equal(hits.length,1);assert.ok(Math.abs(hits[0]-74.407886336)<1e-7,JSON.stringify(hits));assert.equal(skill.damage,41);assert.equal(data.cooldownLeft(p,skill.id),100);
 console.log('Actual Chameleon input -> Annihilation -> equipment/rune/stat/native damage: STR25, rare rune +0, weapon +6 hits exactly once for 74.408, 5s cooldown preserved');
}
{
 const d=mod('core/jobDiscovery.js'),{p,messages}=player('apprentice');p.id='discovery-new';
 assert.ok(mod('core/statusTablet.js').ALL_STATUS_ACTIONS.some(a=>a.action==='jobs'));
 assert.ok(mod('core/statusTablet.js').ALL_STATUS_ACTIONS.some(a=>a.action==='spawn'));
 for(const id of ['frost_controller','fire_controller','hacker','beast','shadow_assassin','revenant']){
  assert.ok(!d.visiblePromotionJobs(p).some(j=>j.id===id),id);
  assert.equal(advance.requirementStatus(p,jobs[id]).label,d.UNDISCOVERED_JOB_TEXT,id);
  assert.equal(advance.checkAdvance(p,jobs[id]).reason,d.UNDISCOVERED_JOB_TEXT,id);
 }
 assert.ok(d.visiblePromotionJobs(p).some(j=>j.id==='swordsman'));
 const before=p.getDynamicProperty(d.JOB_DISCOVERY_KEY);advance.checkAdvance(p,jobs.frost_controller);assert.equal(p.getDynamicProperty(d.JOB_DISCOVERY_KEY),before);
 const captured=[],show=Form.prototype.show,button=Form.prototype.button;Form.prototype.button=function(s){captured.push(s);return this;};
 try{
  await mod('core/jobMenu.js').openJobMenu(p);assert.ok(!captured.some(s=>s.includes('냉기')));
  await mod('core/hito.js').openHitoMenu(p,{id:'frost',label:'냉기',hidden:true,jobs:['frost_controller']});
  assert.equal(d.isJobDiscovered(p,jobs.frost_controller),true);
  assert.ok(advance.requirementStatus(p,jobs.frost_controller).label.includes('스트레이'));
  captured.length=0;await mod('core/jobMenu.js').openJobMenu(p);assert.ok(captured.some(s=>s.includes('냉기')));
 }finally{Form.prototype.show=show;Form.prototype.button=button;}
 const saved=p.getDynamicProperty(d.JOB_DISCOVERY_KEY),other=player('apprentice').p;other.id='other-player';assert.equal(d.isJobDiscovered(other,jobs.frost_controller),false);
 other.setDynamicProperty(d.JOB_DISCOVERY_KEY,saved);assert.equal(d.isJobDiscovered(other,jobs.frost_controller),true);
 const previous=player('frost_controller').p;previous.id='legacy-hidden';assert.equal(d.isJobDiscovered(previous,jobs.frost_controller),true);data.setJobId(previous,'apprentice');assert.equal(d.isJobDiscovered(previous,jobs.frost_controller),true);
 data.setJobId(p,'mage');messages.length=0;mod('core/rpgActions.js').runRpgAction('status',p);assert.ok(messages.length>0);assert.ok(!messages.join('').includes('→'));assert.ok(!messages.join('').includes('전직 조건'));assert.ok(!messages.join('').includes('마나 소비'));
 console.log('Discovery: status advancement route available; undiscovered hidden classes and descendants absent from jobs, guessed commands redact conditions; actual trainer encounter unlocks only that player/class, persists across reload/job changes, legacy current hidden class preserved');
}
{
 const discovery=mod('core/jobDiscovery.js'),temple=mod('data/temple.js'),{p,messages}=player('apprentice');p.id='temple-discovery';
 const originalRead=world.getDynamicProperty,originalDim=world.getDimension,originalBody=Form.prototype.body;
 const t={x:2000,y:100,z:2000,dimId:'minecraft:overworld',status:'ready'},bodies=[];
 world.getDynamicProperty=k=>k===temple.TEMPLE_KEY?JSON.stringify({version:1,temple:t}):originalRead(k);
 world.getDimension=()=>({getBlock:()=>({typeId:'minecraft:gold_block'})});Form.prototype.body=function(s){bodies.push(s);return this;};
 try{
  await mod('core/temples.js').openTemple(p);assert.equal(bodies.length,0);assert.equal(discovery.isJobDiscovered(p,jobs.sun_heir),false);assert.ok(!messages.join('').includes('60'));
  p.location={...temple.altarPosition(t,'sun')};await mod('core/temples.js').openTemple(p);assert.equal(discovery.isJobDiscovered(p,jobs.sun_heir),true);assert.equal(discovery.isJobDiscovered(p,jobs.moon_heir),false);assert.ok(bodies.some(s=>s.includes('60마리')));
 }finally{world.getDynamicProperty=originalRead;world.getDimension=originalDim;Form.prototype.body=originalBody;}
 const chameleon=player('chameleon').p;chameleon.id='chameleon-shrine';chameleon.location={...temple.altarPosition(t,'sun')};
 const captured=[];world.getDynamicProperty=k=>k===temple.TEMPLE_KEY?JSON.stringify({version:1,temple:t}):originalRead(k);world.getDimension=()=>({getBlock:()=>({typeId:'minecraft:gold_block'})});Form.prototype.body=function(s){captured.push(s);return this;};
 try{await mod('core/temples.js').openTemple(chameleon);assert.equal(captured.length,1);assert.ok(captured[0].includes('조회할 수 없습니다'));assert.ok(!captured[0].includes('60마리'));assert.ok(!captured[0].includes('레벨 20'));}
 finally{world.getDynamicProperty=originalRead;world.getDimension=originalDim;Form.prototype.body=originalBody;}
 const loto=player('apprentice').p;loto.id='loto-discovery';await mod('core/loto.js').openLotoDialogue(loto);assert.equal(discovery.isJobDiscovered(loto,jobs.hacker),true);
 console.log('Discovery locations: remote temple command reveals no conditions; visiting the active altar unlocks only its branch; Loto conversation records Hacker discovery');
}
{
 const {p,inv}=player('apprentice');p.id='card-discovery';const d=mod('core/jobDiscovery.js');d.registerJobDiscovery();inv.setItem(3,new ItemStack('rpg:chameleon_job_card'));signal('playerInventoryItemChange').fire({player:p});assert.equal(d.isJobDiscovered(p,jobs.chameleon),true);assert.equal(advance.checkAdvance(p,jobs.chameleon).ok,false);inv.setItem(3,undefined);assert.equal(d.isJobDiscovered(p,jobs.chameleon),true);
 console.log('Discovery cards: inventory acquisition persists knowledge after card removal; holding-card promotion requirement remains enforced');
}
{
 const choice=mod('core/dragonChoice.js'),discovery=mod('core/jobDiscovery.js'),originalShow=Form.prototype.show;
 const setup=()=>{const r=player('apprentice');r.p.id='dragon-'+Math.random();r.inv.setItem(0,new ItemStack(jobs.apprentice.weapon));r.inv.setItem(3,new ItemStack(choice.DRAGON_CHOICE));r.p.selectedSlotIndex=3;return r;};
 try{
  const {p,inv}=setup();assert.equal(advance.checkAdvance(p,jobs.dragon_knight).ok,true);Form.prototype.show=()=>Promise.resolve({canceled:false,selection:1});componentHandlers.get('rpg:dragon_choice').onUse({source:p});await timers.at(-1)();assert.equal(data.getJobId(p),'dragon_knight');assert.equal(inv.getItem(3),undefined);assert.equal(inv.getItem(0).typeId,jobs.dragon_knight.weapon);assert.ok(data.getSkills(p).includes('dragon_domain'));assert.equal(discovery.isJobDiscovered(p,jobs.dragon_knight),true);assert.equal(advance.checkAdvance(p,jobs.dragon_knight).ok,false);
  const cancel=setup();Form.prototype.show=()=>Promise.resolve({canceled:true});await advance.requestAdvance(cancel.p,jobs.dragon_knight);assert.equal(data.getJobId(cancel.p),'apprentice');assert.equal(cancel.inv.getItem(3).typeId,choice.DRAGON_CHOICE);
  const stale=setup();Form.prototype.show=()=>{stale.inv.setItem(4,stale.inv.getItem(3));stale.inv.setItem(3,undefined);return Promise.resolve({canceled:false,selection:1});};await advance.requestAdvance(stale.p,jobs.dragon_knight);assert.equal(data.getJobId(stale.p),'apprentice');assert.equal(stale.inv.getItem(4).typeId,choice.DRAGON_CHOICE);
  const fail=setup(),write=fail.p.setDynamicProperty;let once=true;fail.p.setDynamicProperty=(k,v)=>{if(k==='rpg:job'&&v==='dragon_knight'&&once){once=false;throw Error('injected promotion save failure');}write(k,v);};Form.prototype.show=()=>Promise.resolve({canceled:false,selection:1});await advance.requestAdvance(fail.p,jobs.dragon_knight);assert.equal(data.getJobId(fail.p),'apprentice');assert.equal(fail.inv.getItem(3).typeId,choice.DRAGON_CHOICE);assert.equal(fail.inv.getItem(0).typeId,jobs.apprentice.weapon);
  const noItem=player('fighter');noItem.p.setDynamicProperty('rpg:rpg_level',100);noItem.p.setDynamicProperty('rpg:progress',JSON.stringify({job_enderman:999,job_boss:999}));assert.equal(advance.checkAdvance(noItem.p,jobs.dragon_knight).ok,false);
  const egg=player('apprentice');egg.inv.setItem(4,new ItemStack('minecraft:dragon_egg'));assert.equal(discovery.isJobDiscovered(egg.p,jobs.dragon_knight),true);assert.equal(advance.checkAdvance(egg.p,jobs.dragon_knight).ok,false);
 }finally{Form.prototype.show=originalShow;}
 console.log('Dragon Choice: actual item component -> confirmation -> consumes 1 -> dragon weapon/skills from level-1 apprentice; cancel/stale item/save error restore state; old kill counters and egg alone cannot promote; egg reveals discovery');
}
{
 const unlock=mod('core/worldUnlock.js'),discovery=mod('core/jobDiscovery.js'),{p,inv}=player('fighter');p.id='world-unlock-new';
 inv.setItem(0,new ItemStack(jobs.fighter.weapon));inv.setItem(3,new ItemStack('rpg:stone_mask'));p.selectedSlotIndex=3;
 assert.equal(races.useStoneMask(p).ok,true);assert.equal(p.getDynamicProperty(unlock.STONE_MASK_USED_KEY),true);assert.equal(inv.getItem(3),undefined);
 p.setDynamicProperty('rpg:progress',JSON.stringify({job_boss:3,job_night:60}));p.setDynamicProperty('rpg:rpg_level',59);inv.setItem(4,new ItemStack(unlock.STAND_ARROW));
 assert.equal(advance.checkAdvance(p,jobs.the_world).ok,false);p.setDynamicProperty('rpg:rpg_level',60);assert.equal(advance.checkAdvance(p,jobs.the_world).ok,true);
 inv.setItem(4,undefined);assert.equal(advance.checkAdvance(p,jobs.the_world).ok,false);inv.setItem(4,new ItemStack(unlock.STAND_ARROW));
 p.setDynamicProperty('rpg:progress',JSON.stringify({job_boss:2,job_night:60}));assert.equal(advance.checkAdvance(p,jobs.the_world).ok,false);p.setDynamicProperty('rpg:progress',JSON.stringify({job_boss:3,job_night:59}));assert.equal(advance.checkAdvance(p,jobs.the_world).ok,false);p.setDynamicProperty('rpg:progress',JSON.stringify({job_boss:3,job_night:60}));
 data.setSkills(p,jobs.fighter.skills);p.selectedSlotIndex=4;const show=Form.prototype.show;
 try{Form.prototype.show=()=>Promise.resolve({canceled:false,selection:0});componentHandlers.get('rpg:stand_manifestation_arrow').onUse({source:p});await timers.at(-1)();}finally{Form.prototype.show=show;}
 assert.equal(data.getJobId(p),'the_world');assert.equal(inv.getItem(0).typeId,jobs.the_world.weapon);assert.equal(inv.getItem(4).typeId,unlock.STAND_ARROW);assert.equal(p.getDynamicProperty('rpg:mask_job'),undefined);assert.equal(unlock.hasUsedStoneMask(p),true);assert.equal(discovery.isJobDiscovered(p,jobs.the_world),true);
 const innate=player('blood_mage').p;assert.equal(races.raceOf(innate),'vampire');assert.equal(unlock.hasUsedStoneMask(innate),false);
 const legacy=player('mage').p;legacy.setDynamicProperty('rpg:mask_job','mage');races.syncRace(legacy);assert.equal(legacy.getDynamicProperty(unlock.STONE_MASK_USED_KEY),true);data.setJobId(legacy,'fighter');assert.equal(unlock.hasUsedStoneMask(legacy),true);
 console.log('World unlock: real mask consumption records persistent history; exact RPG level 60 + owned crafted-arrow item + boss3/night60 + tier2 gates; actual item-use promotion retains arrow, innate vampire does not satisfy mask use; legacy mask state migrates across job change');
}
// v0.6.38 requested workflows, using the linked gameplay graph.
{
 const {p}=player('mage'),d=mod('core/jobDiscovery.js');p.id='two-conditions';
 p.setDynamicProperty('rpg:rpg_level',15);
 assert.equal(d.isJobDiscovered(p,jobs.frost_controller),false);
 p.setDynamicProperty('rpg:progress',JSON.stringify({job_kills:50,job_stray:49}));
 assert.equal(d.isJobDiscovered(p,jobs.frost_controller),true);
 assert.ok(advance.requirementStatus(p,jobs.frost_controller).label.includes('49/50'));
 assert.equal(advance.checkAdvance(p,jobs.frost_controller).ok,false);
 p.setDynamicProperty('rpg:progress','{}');assert.equal(d.isJobDiscovered(p,jobs.frost_controller),true);
 console.log('Two completed conditions reveal remaining promotion requirements; actual unlock still enforced and discovery persists');
}
for(const job of ['cleric','angel','michael','mage']){
 const {p,inv}=player(job),ally=player().p;p.id='healer-'+job;ally.id='ally-'+job;
 p.addTag('rpg_team_test');ally.addTag('rpg_team_test');
 const hp=ally.getComponent('minecraft:health');hp.effectiveMax=1000;hp.currentValue=1;
 const recovery=mod('core/holyRecovery.js'),reward=mod('core/angelHealing.js');
 assert.equal(recovery.healHolyAlly(p,ally,299,false),299);
 assert.equal(inv.getItem(1),undefined);
 assert.equal(recovery.healHolyAlly(p,ally,1,false),1);
 const eligible=job!=='mage';assert.equal(inv.getItem(1)?.amount,eligible?1:undefined);
 recovery.healHolyAlly(p,ally,650,false);
 assert.equal(inv.getItem(1)?.amount,eligible?3:undefined);
 if(eligible)assert.equal(reward.readAngelHealing(p).remainder,50);
 // Overhealing and self healing cannot award lights.
 hp.currentValue=1000;assert.equal(recovery.healHolyAlly(p,ally,500,false),0);
 reward.recordAngelHealing(p,p,300);assert.equal(inv.getItem(1)?.amount,eligible?3:undefined);
}
console.log('Cleric/Angel/Michael: real effective ally healing awards one light per 300 HP with remainder; mage, self and overhealing excluded');
{
 const {p,inv}=player(),u=mod('core/upgrades.js'),w=mod('core/wallet.js');
 w.setWallet(p,{gold:100000,stone:1000,dust:1000});inv.setItem(0,new ItemStack('minecraft:stick'));inv.setItem(5,new ItemStack('rpg:common_redmoon_blade'));
 let q=u.inventoryWeaponQuotes(p)[0];assert.equal(q.slot,5);
 assert.equal(u.enhanceEquipped(p,'weapon',5,q.fingerprint,{random:()=>0}).outcome,'success');
 assert.equal(inv.getItem(5).getDynamicProperty('rpg:weapon_upgrade'),1);assert.equal(inv.getItem(0).typeId,'minecraft:stick');
 const money=w.getWallet(p).gold;
 assert.equal(u.enhanceEquipped(p,'weapon',5,q.fingerprint,{random:()=>0}).ok,false);assert.equal(w.getWallet(p).gold,money);
 q=u.enhancementQuote(p,'weapon',5);inv.setItem(5,new ItemStack('minecraft:stone'));
 assert.equal(u.enhanceEquipped(p,'weapon',5,q.fingerprint).ok,false);assert.equal(w.getWallet(p).gold,money);
 assert.equal(u.enhancementQuote(p,'weapon',-1),undefined);
 console.log('Inventory weapon upgrades work while holding a stick; stale/replaced slots rejected without debit');
}
{
 const {p}=player(),travel=mod('core/menuTravel.js'),social=mod('core/social.js');
 const original={getDimension:world.getDimension,getDefaultSpawnLocation:world.getDefaultSpawnLocation,getAllPlayers:world.getAllPlayers,setDynamicProperty:world.setDynamicProperty};
 const shown=Form.prototype.show,stored=new Map(),moves=[];
 world.getDimension=id=>({id});world.getDefaultSpawnLocation=()=>({x:20,y:80,z:30});world.getAllPlayers=()=>[p];world.setDynamicProperty=(k,v)=>stored.set(k,v);
 p.teleport=(at,options)=>moves.push({at,options});
 Form.prototype.textField=function(){return this;};Form.prototype.submitButton=function(){return this;};
 try{
  travel.returnToSpawn(p);assert.equal(moves.length,1);assert.equal(moves[0].at.x,20);assert.equal(moves[0].options.dimension.id,'overworld');
  p.setDynamicProperty('rpg:dungeon_return_v1','{}');travel.returnToSpawn(p);assert.equal(moves.length,1);p.setDynamicProperty('rpg:dungeon_return_v1',undefined);
  const answers=[{selection:0},{formValues:['테스트길드']},{canceled:true}];Form.prototype.show=()=>Promise.resolve(answers.shift()??{canceled:true});
  await social.openGuildMenu(p);assert.equal(social.setGuildBase(p),true);
  assert.equal(JSON.parse(stored.get('rpg:social_v1')).guilds.at(-1).base.dimension,p.dimension.id);
  social.travelGuildBase(p);assert.equal(moves.length,2);assert.equal(moves[1].at.y,p.location.y);
  const outsider=player().p;outsider.name='outsider';assert.throws(()=>social.travelGuildBase(outsider),/가입/);assert.equal(social.setGuildBase(outsider),false);
  p.setDynamicProperty('rpg:dungeon_return_v1','{}');assert.throws(()=>social.travelGuildBase(p),/이동할 수 없습니다/);assert.equal(moves.length,2);
 }finally{Object.assign(world,original);Form.prototype.show=shown;}
 console.log('Spawn and guild travel execute teleports; guild base saved, outsiders denied, dungeon escape denied');
}
assert.ok(commandDefs.get('rpg:wings').d.optionalParameters);
assert.equal(commandDefs.has('wings'),false);
{
 const {p,inv}=player('cleric'),ally=player().p;ally.id='fullbag-ally';p.addTag('rpg_team_full');ally.addTag('rpg_team_full');
 for(let i=0;i<inv.size;i++)inv.setItem(i,new ItemStack('minecraft:stone',64));
 const r=mod('core/angelHealing.js');assert.equal(r.recordAngelHealing(p,ally,600),2);assert.equal(r.readAngelHealing(p).pending,2);
 inv.setItem(4,undefined);assert.equal(r.claimAngelLight(p),2);assert.equal(inv.getItem(4).amount,2);assert.equal(r.readAngelHealing(p).pending,0);assert.equal(r.claimAngelLight(p),0);
}
{
 const {p,inv}=player(),u=mod('core/upgrades.js'),w=mod('core/wallet.js');w.setWallet(p,{gold:100000,stone:1000,dust:1000});inv.setItem(6,new ItemStack('rpg:common_redmoon_blade'));
 const q=u.enhancementQuote(p,'weapon',6),old=inv.setItem,balance=w.getWallet(p).gold;let fail=true;
 inv.setItem=(slot,item)=>{if(slot===6&&fail){fail=false;throw Error('storage failure');}return old(slot,item);};
 assert.equal(u.enhanceEquipped(p,'weapon',6,q.fingerprint,{random:()=>0}).ok,false);assert.equal(w.getWallet(p).gold,balance);assert.equal(inv.getItem(6).getDynamicProperty('rpg:weapon_upgrade'),undefined);
}
console.log('Full inventory queues blessing rewards without loss/duplicates; inventory upgrade write failure refunds wallet and restores weapon');

{
 const api=mod('core/wings.js'),actions=mod('core/rpgActions.js');
 assert.ok(mod('core/statusTablet.js').ALL_STATUS_ACTIONS.some(a=>a.action==='wingspeed'));
 for(const job of ['angel','michael']){
  const {p}=player(job);p.id='speed-command-'+job;
  // Wing commands are now registered directly by the gameplay BP, without relay.
  p.runCommand=command=>{const match=/^scriptevent rpg:(\w+)\s*(.*)$/.exec(command);assert.ok(match);actions.runRpgAction(match[1],p,match[2]);};
  for(const mode of [1,2,3]){commandDefs.get('rpg:wings').fn({sourceEntity:p},String(mode));timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),({1:1,2:2,3:5})[mode]);}
  const old=Form.prototype.show;
  try{
   for(const [selection,expected]of [[0,1],[1,2],[2,5]]){Form.prototype.show=()=>Promise.resolve({selection});await api.openWingSpeedMenu(p);assert.equal(api.wingSpeedMultiplier(p),expected);}
   for(const picked of [{canceled:true},{selection:3},{selection:-1},{selection:99}]){Form.prototype.show=()=>Promise.resolve(picked);await api.openWingSpeedMenu(p);assert.equal(api.wingSpeedMultiplier(p),5);}
  }finally{Form.prototype.show=old;}
 }
 console.log('Native namespace registration enforced; direct gameplay /rpg:wings callback sets all speeds; status speed menu sets 1/2/5x and cancellation preserves selection');
}

{
 const api=mod('core/wings.js');
 assert.equal(commandDefs.get('rpg:wings').d.optionalParameters[0].type,server.CustomCommandParamType.Integer);
 assert.equal(commandDefs.get('rpg:wingspeed').d.optionalParameters[0].type,server.CustomCommandParamType.Integer);
 for(const name of ['wings','wingspeed','wings1','wings2','wings3'])assert.equal(allCommandDefs.get('rpg:'+name).length,1,'only gameplay pack owns '+name);
 for(const job of ['angel','michael']){
  const {p}=player(job);p.id='direct-command-'+job;
  p.runCommand=()=>{throw Error('wing commands must not relay through scriptevent');};
  for(const [mode,expected]of [[1,1],[2,2],[3,5]]){
   const fixed=commandDefs.get('rpg:wings'+mode);assert.equal(fixed.d.optionalParameters,undefined);
   fixed.fn({sourceEntity:p});timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),expected);
   commandDefs.get('rpg:wings').fn({sourceEntity:p},mode);timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),expected);
  }
  commandDefs.get('rpg:wings').fn({sourceEntity:p},[2]);timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),2);
  commandDefs.get('rpg:wingspeed').fn({sourceEntity:p},3);timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),5);
  for(const invalid of [0,4,-1]){commandDefs.get('rpg:wings').fn({sourceEntity:p},invalid);timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),5);}
 }
 console.log('Gameplay BP is sole owner of five wing commands; integer 1/2/3 and argument-free wings1/2/3 set 1x/2x/5x, with no command pack relay');
}
// v0.6.38 offer rewards: physical consumption, trial overlap and atomic rollback.
for(const job of ['apprentice','mage','cleric','michael','swordsman']){
 const {p,inv}=player(job),offer=mod('core/offer.js');p.id='mana-offer-'+job;
 inv.setItem(2,new ItemStack('minecraft:book',2));inv.setItem(3,new ItemStack('minecraft:enchanted_book',3));inv.setItem(4,new ItemStack('minecraft:diamond_block',2));
 const before=data.maxManaOf(p);data.setMana(p,17);
 const result=offer.offerItems(p);assert.equal(result.ok,true,result.message);assert.equal(result.counts.books,5);assert.equal(result.counts.diamonds,2);
 assert.equal(data.maxManaOf(p)-before,650);assert.equal(data.getMana(p),667);
 for(const slot of [2,3,4])assert.equal(inv.getItem(slot),undefined);
 assert.equal(offer.offerItems(p).ok,false);assert.equal(data.maxManaOf(p)-before,650);
 const prog=data.getProgress(p);assert.equal(prog.mana_offer_books,5);assert.equal(prog.mana_offer_diamonds,2);
 if(job==='mage')assert.equal(prog.tech_books,3);if(job==='apprentice')assert.equal(prog.books,3);
 const persisted=p.getDynamicProperty('rpg:progress'),copy=player(job).p;copy.setDynamicProperty('rpg:progress',persisted);assert.equal(data.maxManaOf(copy),data.maxManaOf(p));
 inv.setItem(2,new ItemStack('minecraft:book'));assert.equal(offer.offerItems(p).ok,true);assert.equal(data.maxManaOf(p)-before,700);
}
{
 const {p,inv}=player('mage'),offer=mod('core/offer.js');p.setDynamicProperty('rpg:progress',JSON.stringify({books:30,tech_books:9}));
 const before=data.maxManaOf(p);assert.equal(before,800);
 inv.setItem(2,new ItemStack('minecraft:enchanted_book',4));assert.equal(offer.offerItems(p).ok,true);assert.equal(data.maxManaOf(p)-before,200);
 assert.equal(data.getProgress(p).tech_books,10);assert.equal(data.getProgress(p).books,33);assert.equal(data.getProgress(p).mana_legacy_books,30);
 data.setJobId(p,'swordsman');assert.equal(data.maxManaOf(p),1000);data.setJobId(p,'mage');assert.equal(data.maxManaOf(p),1000);
 inv.setItem(2,new ItemStack('minecraft:enchanted_book'));assert.equal(offer.offerTechBooks(p).ok,false);
 assert.equal(offer.offerBooks(p).ok,true);assert.equal(data.maxManaOf(p),1050);
}
for(const failAt of ['inventory','progress','mana']){
 const {p,inv}=player('mage'),offer=mod('core/offer.js');p.setDynamicProperty('rpg:progress',JSON.stringify({books:20}));data.setMana(p,100);
 inv.setItem(2,new ItemStack('minecraft:book',2));inv.setItem(3,new ItemStack('minecraft:diamond_block',2));
 const oldProgress=p.getDynamicProperty('rpg:progress'),before=data.maxManaOf(p),setter=p.setDynamicProperty,write=inv.setItem;let failed=false;
 inv.setItem=(slot,item)=>{if(failAt==='inventory'&&slot===3&&!failed){failed=true;throw Error('inventory save failure');}return write(slot,item);};
 p.setDynamicProperty=(key,v)=>{if(!failed&&((failAt==='progress'&&key==='rpg:progress')||(failAt==='mana'&&key==='rpg:mana'))){failed=true;throw Error('property save failure');}return setter(key,v);};
 assert.equal(offer.offerItems(p).ok,false);assert.equal(failed,true);assert.equal(p.getDynamicProperty('rpg:progress'),oldProgress);assert.equal(data.maxManaOf(p),before);assert.equal(data.getMana(p),100);assert.equal(inv.getItem(2).amount,2);assert.equal(inv.getItem(3).amount,2);
}
console.log('Offer: normal/enchanted book +50 and diamond block +200 for five job types; current/max mana, legacy progress, trial overlap, persistence, repeats and inventory/progress/mana failure rollback passed');
{
 const {p,inv}=player('mage'),offer=mod('core/offer.js');data.forceSetManaMax(p,'100000');inv.setItem(2,new ItemStack('minecraft:diamond_block'));
 const denied=offer.offerItems(p);assert.equal(denied.ok,false);assert.ok(denied.message.includes('reset'));assert.equal(inv.getItem(2).amount,1);assert.equal(data.maxManaOf(p),100000);
 data.forceSetManaMax(p,'reset');const before=data.maxManaOf(p);assert.equal(offer.offerItems(p).ok,true);assert.equal(data.maxManaOf(p)-before,200);
}
// v0.6.38 real estate, ownership protection, preview and diamond shop.
{
 const estate=mod('core/realEstate.js'),shop=mod('core/xpShop.js'),town=mod('core/townProtection.js'),protection=mod('core/structureProtection.js');
 const {p,inv}=player();p.id='land-owner';p.location={x:48,y:80,z:64};p.selectedSlotIndex=3;
 const other=player().p;other.id='land-guest';other.name='LandGuest';const globals=new Map(),old={getDynamicProperty:world.getDynamicProperty,setDynamicProperty:world.setDynamicProperty,beforeEvents:world.beforeEvents};
 world.getDynamicProperty=k=>globals.get(k);world.setDynamicProperty=(k,v)=>v===undefined?globals.delete(k):globals.set(k,v);
 const region={x:0,y:64,z:0,size:250,dimId:'minecraft:overworld'};globals.set('rpg:spawn_town_region_v1',JSON.stringify(region));
 const at=(x,y,z)=>({location:{x,y,z},dimension:p.dimension,typeId:'minecraft:stone'});
 try{
  assert.equal(shop.XP_PRODUCTS[5].currency,'diamond');inv.setItem(1,new ItemStack('minecraft:diamond',4));assert.equal(shop.purchaseXpProduct(p,5).ok,false);assert.equal(inv.getItem(1).amount,4);
  inv.setItem(2,new ItemStack('minecraft:diamond',3));assert.equal(shop.purchaseXpProduct(p,5).ok,true);assert.equal(inv.getItem(1),undefined);assert.equal(inv.getItem(2).amount,2);
  const voucher=Array.from({length:inv.size},(_,i)=>inv.getItem(i)).find(i=>i?.typeId===estate.LAND_DEED);assert.ok(voucher);
  // Before purchase even an existing house footprint is protected.
  assert.equal(town.townProtected(at(49,65,65),region,p),true);
  inv.setItem(3,voucher);const selection=estate.landSelection(p);assert.equal(selection.cx,3);assert.equal(selection.cz,4);
  assert.equal(estate.claimTownChunk(p,selection.key).ok,true);assert.equal(inv.getItem(3),undefined);assert.equal(estate.landOwner(selection).id,p.id);
  for(const y of [65,90,250,319])assert.equal(town.townProtected(at(49,y,65),region,p),false);
  for(const y of [64,63,-64])assert.equal(town.townProtected(at(49,y,65),region,p),true);
  assert.equal(town.townProtected(at(49,65,65),region,other),true);assert.equal(town.townProtected(at(64,65,90),region,p),true);assert.equal(town.townProtected(at(49,65,65),region),true);
  inv.setItem(3,new ItemStack(estate.LAND_DEED,2));assert.equal(estate.claimTownChunk(p).ok,false);assert.equal(inv.getItem(3).amount,2);
  const particles=[];p.dimension.spawnParticle=(id,at)=>particles.push(at);p.onScreenDisplay.setActionBar=()=>{};estate.previewLand(p);assert.equal(particles.length,36);assert.ok(particles.every(at=>at.x===48||at.x===64||at.z===64||at.z===80));
  const data=globals.get(estate.LAND_KEY);assert.ok(JSON.parse(data)[selection.key]); // Reload from persisted world property on every read.
  p.location.x=-0.1;assert.equal(estate.landSelection(p).cx,-1);assert.equal(estate.landSelection(p).y,undefined);
  p.location.x=249;assert.equal(estate.landSelection(p).cx,15);assert.equal(estate.landSelection(p).y,64);p.location.x=80;
  let failed=false;world.setDynamicProperty=(key,value)=>{if(key===estate.LAND_KEY&&!failed){failed=true;throw Error('disk failure');}globals.set(key,value);};
  assert.equal(estate.claimTownChunk(p).ok,false);assert.equal(inv.getItem(3).amount,2);assert.equal(globals.get(estate.LAND_KEY),data);world.setDynamicProperty=(key,value)=>globals.set(key,value);
  const expected=estate.landSelection(p).key;p.location.z+=16;assert.equal(estate.claimTownChunk(p,expected).ok,false);assert.equal(inv.getItem(3).amount,2);
  // Run the actual protection event hooks with actor identity.
  world.beforeEvents=new Proxy({},{get:(_,key)=>({subscribe:fn=>signal('before:'+key).subscribe(fn)})});town.registerTownProtection();
  const fire=(key,event)=>{signal('before:'+key).fire(event);return !!event.cancel;};
  assert.equal(fire('playerBreakBlock',{player:p,block:at(49,65,65)}),false);assert.equal(fire('playerBreakBlock',{player:other,block:at(49,65,65)}),true);assert.equal(fire('playerBreakBlock',{player:p,block:at(49,64,65)}),true);
  const interaction={player:p,block:at(49,64,65),blockFace:'Up',itemStack:new ItemStack('minecraft:stone')};assert.equal(fire('playerInteractWithBlock',interaction),false);
  assert.equal(fire('playerInteractWithBlock',{...interaction,player:other,cancel:false}),true);
  let remaining;fire('explosion',{getImpactedBlocks:()=>[at(49,65,65),at(49,64,65)],setImpactedBlocks:v=>remaining=v});assert.equal(remaining.length,0);
  globals.delete('rpg:spawn_town_region_v1');p.location={x:-224,y:30,z:318};
  const wild=at(-224,12,318),unclaimed=at(-225,12,318);
  assert.equal(estate.claimTownChunk(p).ok,true);
  assert.equal(fire('playerBreakBlock',{player:p,block:wild}),false);
  assert.equal(fire('playerBreakBlock',{player:other,block:wild}),true);
  assert.equal(fire('playerPlaceBlock',{player:other,block:wild}),true);
  assert.equal(fire('playerBreakBlock',{player:other,block:unclaimed}),false);
  assert.equal(fire('playerInteractWithBlock',{player:other,block:wild,blockFace:'Up',itemStack:new ItemStack(estate.LAND_SEIZURE)}),false);
  fire('explosion',{getImpactedBlocks:()=>[wild,unclaimed],setImpactedBlocks:v=>remaining=v});
  assert.deepEqual(Array.from(remaining),[unclaimed]);
 }finally{Object.assign(world,old);}
}
{
 const {p,inv}=player(),shop=mod('core/xpShop.js');for(let i=0;i<inv.size;i++)inv.setItem(i,new ItemStack('minecraft:stone',64));inv.setItem(3,new ItemStack('minecraft:diamond',6));
 assert.equal(shop.purchaseXpProduct(p,5).ok,false);assert.equal(inv.getItem(3).amount,6);for(let i=0;i<inv.size;i++)assert.notEqual(inv.getItem(i)?.typeId,'rpg:land_deed');
}
console.log('Land: five diamonds per deed with insufficient/full-bag refund; persistent full-chunk ownership, floor/underground/guest/neighbour protection, owner placement on floor, explosion protection, negative coordinates, selection changes and save rollback; held-deed boundary particles passed');
{
 const mage=mod('core/mageBasic.js'),skills=mod('data/skills.js').SKILLS;
 for(const [id,expected]of [['mage_fireball',7.5],['mage_lightning',20],['mage_thunder',100],['mage_gravity',80],['mage_bombaye',60],['mage_flame_on',75],['mage_ice_fire',90]])assert.equal(skills[id].mana,expected);
 assert.equal(skills.holy_heal.mana,30); // Other families keep their prior cost.
 const {p,inv}=player('mage');p.id='mage-basic-test';inv.setItem(0,new ItemStack(jobs.mage.weapon));data.setSkills(p,jobs.mage.skills);data.setMana(p,200);const ctx=mod('core/context.js').getContext(p);
 const originalTick=system.currentTick;
 try{
  for(const id of mage.MAGE_BASIC_IDS){
   assert.equal(mage.setMageBasic(p,id),true);const def=mage.mageBasicDefinition(p);assert.equal(def.cooldown,20);assert.ok(Math.abs(def.damage-skills[id].damage*.8)<1e-9);assert.notEqual(def,skills[id]);
   system.currentTick+=20;data.setMana(p,200);const before=data.getMana(p);let seen;
   assert.equal(mage.castMageBasic(p,ctx,(_p,_j,d)=>{seen=d;}),true);assert.equal(seen.id,id);assert.equal(data.getMana(p),before-Math.ceil(skills[id].mana));
   const next=mage.MAGE_BASIC_IDS[(mage.MAGE_BASIC_IDS.indexOf(id)+1)%4];mage.setMageBasic(p,next);assert.equal(mage.castMageBasic(p,ctx,()=>{throw Error('cooldown must block');}),false);
  }
  assert.equal(mage.setMageBasic(p,'sage_meteor'),false);system.currentTick+=20;data.setMana(p,0);assert.equal(mage.castMageBasic(p,ctx,()=>{throw Error('insufficient mana');}),false);
  const nonMage=player('cleric').p;assert.equal(mage.mageBasicDefinition(nonMage),undefined);assert.equal(mage.setMageBasic(nonMage,'mage_fireball'),false);
  mage.setMageBasic(p,'mage_gravity');data.setMana(p,200);p.dimension.getEntities=()=>[];p.dimension.playSound=()=>{};p.dimension.spawnParticle=()=>{};
  mod('core/input.js').registerInput();signal('playerSwingStart').fire({player:p});assert.equal(data.cooldownLeft(p,'mage_basic'),20);assert.equal(data.getMana(p),120);
 }finally{system.currentTick=originalTick;}
}
console.log('Mage: mana halved; one chosen basic spell at .8 damage/20 ticks, other definitions untouched, shared cooldown blocks switching exploit, mana/class gates and actual swing input passed');
{
 const tablet=mod('core/statusTablet.js'),{p}=player(),calls=[],old=Form.prototype.show;const root=tablet.STATUS_ACTIONS;assert.equal(root.length,9);
 const all=tablet.ALL_STATUS_ACTIONS.map(a=>a.action);for(const id of ['jobs','spawn','party','guild','dungeon','pvp','tpa','tpaaccept','magebasic','upgrade','wallet'])assert.ok(all.includes(id));assert.equal(new Set(all).size,all.length);
 tablet.registerStatusTablet((action)=>calls.push(action));
 try{
  for(const [group,action]of [['social','party'],['social','guild'],['combat','dungeon'],['combat','pvp'],['travel','tpa'],['travel','tpaaccept'],['character','magebasic'],['shop','xpshop']]){
   const answers=[{selection:root.findIndex(a=>a.action==='group:'+group)},{selection:tablet.STATUS_GROUPS[group].items.findIndex(a=>a[0]===action)}];Form.prototype.show=()=>Promise.resolve(answers.shift());await tablet.openStatusTablet(p);timers.at(-1)();assert.equal(calls.at(-1),action);
  }
  const answers=[{selection:root.findIndex(a=>a.action==='group:travel')},{selection:tablet.STATUS_GROUPS.travel.items.length},{selection:root.findIndex(a=>a.action==='close')}];Form.prototype.show=()=>Promise.resolve(answers.shift());const count=calls.length;await tablet.openStatusTablet(p);assert.equal(calls.length,count);assert.equal(answers.length,0);
 }finally{Form.prototype.show=old;}
}
console.log('Status: nine root buttons, all previous actions preserved in seven categories; party/guild, dungeon/PvP and TPA request/accept routes and Back/Close execute correctly');
{
 const estate=mod('core/realEstate.js'),shop=mod('core/xpShop.js'),town=mod('core/townProtection.js'),{p,inv}=player(),saved=new Map(),old={getDynamicProperty:world.getDynamicProperty,setDynamicProperty:world.setDynamicProperty},show=Form.prototype.show;
 p.id='land-end-to-end';p.location={x:-112,y:65,z:390};p.level=0;inv.setItem(0,new ItemStack(jobs.swordsman.weapon));inv.setItem(2,new ItemStack('minecraft:diamond',5));
 world.getDynamicProperty=k=>saved.get(k);world.setDynamicProperty=(k,v)=>saved.set(k,v);saved.set('rpg:spawn_town_region_v1',JSON.stringify({x:0,y:64,z:0,size:250,dimId:p.dimension.id}));
 try{
  const answers=[{selection:5},{selection:1},{selection:shop.XP_PRODUCTS.length}];Form.prototype.show=()=>Promise.resolve(answers.shift());await shop.openXpShop(p);assert.equal(answers.length,0);assert.equal(inv.getItem(2),undefined);assert.equal(p.level,0);
  const slot=Array.from({length:inv.size},(_,i)=>i).find(i=>inv.getItem(i)?.typeId===estate.LAND_DEED);assert.notEqual(slot,undefined);p.selectedSlotIndex=slot;
  Form.prototype.show=()=>Promise.resolve({selection:0});await estate.useLandDeed(p);assert.equal(inv.getItem(slot).amount,1);assert.equal(saved.get(estate.LAND_KEY),undefined);
  Form.prototype.show=()=>Promise.resolve({selection:1});componentHandlers.get('rpg:land_deed').onUse({source:p});timers.at(-1)();await new Promise(resolve=>setImmediate(resolve));
  const wilderness={dimension:p.dimension,location:{...p.location,y:5}};
  assert.equal(estate.landOwner(estate.landSelection(p)).id,p.id);assert.equal(inv.getItem(slot),undefined);
  assert.equal(town.townProtected(wilderness,undefined,p),false);
  const outsider=player().p;outsider.name='WildOutsider';
  assert.equal(town.townProtected(wilderness,undefined,outsider),true);
  assert.equal(town.townProtected({...wilderness,dimension:{id:'minecraft:nether'}}),false);
  assert.equal(town.townProtected({...wilderness,location:{...wilderness.location,x:p.location.x-1}}),false);
  saved.set(estate.LAND_KEY,'broken JSON');assert.equal(town.townProtected({dimension:p.dimension,location:p.location},undefined,p),true);
 }finally{Object.assign(world,old);Form.prototype.show=show;}
 console.log('Actual shop UI -> diamond purchase -> held item custom component -> confirmation -> persistent ownership; cancellation spends nothing, corrupt land data fails closed');
}
{
 const estate=mod('core/realEstate.js'),town=mod('core/townProtection.js'),protect=mod('core/structureProtection.js'),{p:admin,inv}=player(),{p:owner,inv:ownerInv}=player(),{p:guest,inv:guestInv}=player();
 admin.id='land-admin';admin.name='LandAdmin';admin.commandPermissionLevel=1;
 owner.id='admin-target-owner';owner.name='ChosenOwner';
 guest.id='house-guest';guest.name='PublicGuest';
 admin.location={x:34,y:65,z:34};
 const region={x:0,y:64,z:0,size:250,dimId:admin.dimension.id};
 const regionKey='rpg:spawn_town_region_v1',globals=new Map([[regionKey,JSON.stringify(region)]]);
 const old={getDynamicProperty:world.getDynamicProperty,setDynamicProperty:world.setDynamicProperty,getAllPlayers:world.getAllPlayers};
 const oldShow=Form.prototype.show,oldBody=Form.prototype.body;
 world.getDynamicProperty=k=>globals.get(k);world.setDynamicProperty=(k,v)=>globals.set(k,v);world.getAllPlayers=()=>[admin,owner,guest];
 const block=(x=34,y=65,z=34)=>({location:{x,y,z},dimension:admin.dimension,typeId:'minecraft:stone'});
 const item=new ItemStack(estate.LAND_SEIZURE);
 inv.setItem(0,item);guestInv.setItem(0,item);
 const activate=async p=>{componentHandlers.get(estate.LAND_SEIZURE).onUse({source:p});await timers.at(-1)();};
 try{
  assert.equal(town.townProtected(block(),region,guest),false);
  assert.equal(town.townProtected(block(34,64),region,guest),true);
  assert.equal(town.townProtected(block(34,64),region,guest,'support'),false);
  assert.equal(town.townProtected(block(34,81),region,guest),true);
  assert.equal(estate.administerTownLand(guest,owner).ok,false);
  assert.equal(globals.get(estate.LAND_KEY),undefined);
  const key=estate.landSelection(admin).key,legacy='overworld:0:64:0:250:2:2';
  const savedOwner={id:owner.id,name:owner.name};
  globals.set(estate.LAND_KEY,JSON.stringify({[legacy]:savedOwner}));
  assert.equal(estate.landOwner(estate.landSelection(admin)).id,owner.id);
  globals.delete(regionKey);
  assert.equal(estate.landOwner(estate.landSelection(admin)).id,owner.id);
  assert.equal(town.townProtected(block(),undefined,guest),true);
  globals.set(regionKey,JSON.stringify(region));
  assert.equal(town.townProtected(block(),region,owner),false);
  assert.equal(town.townProtected(block(),region,guest),true);
  assert.equal(estate.administerTownLand(admin,guest).ok,false);
  assert.equal(estate.administerTownLand(admin,undefined).ok,false);

  // A physical item and Creative mode alone cannot authorize the operation.
  guest.location={...admin.location};guest.getGameMode=()=> 'creative';
  Form.prototype.show=()=>assert.fail('unauthorized player opened seizure form');
  await activate(guest);
  assert.ok(guestInv.getItem(0));
  assert.equal(estate.landOwner(estate.landSelection(admin)).id,owner.id);
  const stable=globals.get(estate.LAND_KEY);
  const approve={selection:1};
  for(const disturbance of ['cancel','move','dimension','permission','item','save']){
   Form.prototype.show=()=>{
    if(disturbance==='cancel')return Promise.resolve({selection:0});
    if(disturbance==='move')admin.location.x+=16;
    if(disturbance==='dimension')admin.dimension={id:'minecraft:nether'};
    if(disturbance==='permission')admin.commandPermissionLevel=0;
    if(disturbance==='item')inv.setItem(0,undefined);
    return Promise.resolve(approve);
   };
   const location={...admin.location},dimension=admin.dimension;
   if(disturbance==='save'){
    let fail=true;
    world.setDynamicProperty=(k,v)=>{globals.set(k,v);if(k===estate.LAND_KEY&&fail){fail=false;throw Error('save failed');}};
   }
   await activate(admin);
   assert.equal(globals.get(estate.LAND_KEY),stable,disturbance);
   Object.assign(admin,{location,dimension,commandPermissionLevel:1});
   inv.setItem(0,item);
   world.setDynamicProperty=(k,v)=>globals.set(k,v);
  }
  Form.prototype.show=()=>{
   globals.set(estate.LAND_KEY,JSON.stringify({[key]:{id:guest.id,name:guest.name}}));
   return Promise.resolve(approve);
  };
  await activate(admin);
  assert.equal(estate.landOwner(estate.landSelection(admin)).id,guest.id);
  globals.set(estate.LAND_KEY,JSON.stringify({[legacy]:savedOwner,[key]:savedOwner,'nether:2:2':savedOwner}));
  const observed=[];Form.prototype.body=function(text){observed.push(text);return this;};
  const answers=[{selection:0},{selection:1},{selection:9},{selection:0},{selection:11}];
  Form.prototype.show=()=>Promise.resolve(answers.shift()??{canceled:true});
  await mod('core/adminTool.js').openAdminTool(admin);
  assert.equal(answers.length,0);
  assert.ok(observed.some(text=>text.includes('소유자 ChosenOwner')&&text.includes('소유 청크 2개')&&text.includes('nether 청크 [2, 2]')));
  world.getAllPlayers=()=>[admin,guest]; // Offline parcels can still be recovered.
  Form.prototype.show=()=>Promise.resolve(approve);
  await activate(admin);
  assert.equal(estate.landOwner(estate.landSelection(admin)),undefined);
  assert.ok(!JSON.parse(globals.get(estate.LAND_KEY))[legacy]);
  assert.equal(estate.landOwner({...estate.landSelection(admin),key:'nether:2:2'}).id,owner.id);
  assert.equal(inv.getItem(0).typeId,estate.LAND_SEIZURE);
  assert.equal(town.townProtected(block(),region,guest),false);

  admin.location={x:250,y:64,z:40};owner.location={...admin.location};
  ownerInv.setItem(0,new ItemStack(estate.LAND_DEED,2));
  await estate.useLandDeed(owner);
  assert.equal(ownerInv.getItem(0).amount,1);
  assert.equal(estate.landOwner(estate.landSelection(admin)).id,owner.id);
  assert.equal(town.townProtected(block(249,64,40),region,owner),true);
  assert.equal(town.townProtected(block(250,64,40),region,owner),false);
  assert.equal(town.townProtected(block(250,64,40),region,guest),true);
  await activate(admin);
  assert.equal(town.townProtected(block(250,64,40),region,guest),false);
  assert.equal(estate.claimTownChunk(owner).ok,true);

  // Horizontal piston placement is still allowed for public and owned houses.
  admin.dimension.getBlock=()=>({isAir:true,typeId:'minecraft:air'});guest.dimension=admin.dimension;guest.location={x:34,y:65,z:36};guest.getViewDirection=()=>({x:0,y:0,z:-1});guest.getHeadLocation=()=>({x:34,y:66.6,z:36});
  for(const type of ['minecraft:piston','minecraft:sticky_piston']){const e={player:guest,block:block(34,64,34),blockFace:'up',itemStack:new ItemStack(type)};protect.protectStructureInteraction(e);assert.equal(e.cancel,undefined,type);}
  admin.location={x:98,y:65,z:98};assert.equal(estate.administerTownLand(admin,owner).ok,true);owner.dimension=admin.dimension;owner.location={x:98,y:65,z:100};owner.getViewDirection=()=>({x:0,y:0,z:-1});owner.getHeadLocation=()=>({x:98,y:66.6,z:100});
  const ownedPiston={player:owner,block:block(98,64,98),blockFace:'up',itemStack:new ItemStack('minecraft:piston')};protect.protectStructureInteraction(ownedPiston);assert.equal(ownedPiston.cancel,undefined);
  guest.location={x:34,y:62,z:34};guest.getHeadLocation=()=>({x:34,y:63.6,z:34});const down={player:guest,block:block(34,64,34),blockFace:'up',itemStack:new ItemStack('minecraft:piston')};protect.protectStructureInteraction(down);assert.equal(down.cancel,true);

  const itemJson=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0638/items/land_seizure.json')))['minecraft:item'];
  assert.equal(itemJson.description.menu_category.category,'items');
  assert.ok(itemJson.components[estate.LAND_SEIZURE]);
  assert.ok(!mod('data/equipment.js').ALL_EQUIPMENT_IDS.includes(estate.LAND_SEIZURE));
  assert.ok(!mod('core/xpShop.js').XP_PRODUCTS.some(item=>item.id===estate.LAND_SEIZURE));
  for(const dir of ['recipes','loot_tables']){
   const list=fs.readdirSync(path.join(root,'RPG_BP_v0638',dir),{recursive:true,withFileTypes:true});
   for(const e of list)if(e.isFile())assert.ok(!fs.readFileSync(path.join(e.parentPath,e.name),'utf8').includes(estate.LAND_SEIZURE));
  }
 }finally{Object.assign(world,old);Form.prototype.show=oldShow;Form.prototype.body=oldBody;}
 console.log('Land admin: real creative item and management forms, offline and legacy parcels, dimension isolation, owner/held item/permission/position rechecks and save rollback, public/owned piston protections, and no survival acquisition paths');
}
{
 const tracker=mod('core/townZombies.js'),life=mod('core/townWildlife.js'),peace=mod('core/peaceZones.js'),hunt=mod('core/huntingZones.js'),night=mod('core/nightMobs.js');
 const region={x:0,y:64,z:0,size:250,dimId:'minecraft:overworld'},original={getDynamicProperty:world.getDynamicProperty,getDimension:world.getDimension},list=[];let previousTime=time;
 world.getDynamicProperty=k=>k==='rpg:spawn_town_region_v1'?JSON.stringify(region):k==='rpg:peace_zones_v1'?JSON.stringify([{dimension:region.dimId,x:125,y:65,z:125}]):undefined;
 world.getDimension=()=>({getEntities:()=>list.filter(e=>!e.removed)});
 function zombie(x=125){const tags=new Set();return {id:'zombie-'+Math.random(),typeId:'minecraft:zombie',isValid:true,dimension:{id:region.dimId},location:{x,y:65,z:125},hasTag:t=>tags.has(t),addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),getComponent:k=>k==='minecraft:type_family'?{hasTypeFamily:f=>f==='monster'}:undefined,remove(){this.removed=true;}};}
 try{
  system.currentTick+=100;
  const arriving=zombie(300);tracker.noteTownZombieSpawn(arriving,'Spawned');assert.equal(arriving.hasTag(tracker.ZOMBIE_NATURAL),false);arriving.location.x=125;arriving.addTag('rpg_night_spawn');list.push(arriving);
  assert.equal(life.clearTownMonster(arriving),false);assert.equal(hunt.enforceVanillaCaveSpawn(arriving).action,'ignored');peace.tickPeaceZones();assert.equal(arriving.removed,undefined);
  const natural=zombie();tracker.noteTownZombieSpawn(natural,'Spawned');assert.equal(tracker.keepTownZombie(natural),false);assert.equal(life.clearTownMonster(natural),true);
  const egg=zombie();tracker.noteTownZombieSpawn(egg,'Spawned');const {p}=player();p.id='zombie-egg-user';p.location={x:125,y:65,z:125};signal('itemUse').fire({source:p,itemStack:new ItemStack('minecraft:zombie_spawn_egg')});assert.equal(tracker.keepTownZombie(egg),true);assert.equal(egg.hasTag(tracker.ZOMBIE_NATURAL),false);list.push(egg);peace.tickPeaceZones();assert.equal(egg.removed,undefined);
  const loaded=zombie();tracker.noteTownZombieSpawn(loaded,'Loaded');assert.equal(life.clearTownMonster(loaded),false);list.push(loaded);
  const raid=zombie();raid.typeId='minecraft:witch';raid.addTag('rpg_night_spawn');list.push(raid);
  const callbacks=[],runInt=system.runInterval;system.runInterval=fn=>{callbacks.push(fn);return 1;};night.registerNightMobs();system.runInterval=runInt;
  time=18000;callbacks[0]();time=1000;callbacks[0]();for(const e of [arriving,egg,loaded,raid])assert.equal(e.removed,undefined);
  assert.equal(tracker.keepTownZombie({...arriving,typeId:'minecraft:skeleton'}),false);
 }finally{Object.assign(world,original);time=previousTime;}
 console.log('Zombies: external natural spawn -> transport inside -> town/cave/peace/night cleanup survives; natural spawn inside denied, spawn egg after spawn callback retained, load retained, other mob rules unchanged');
}
{
 const tracker=mod('core/townZombies.js'),life=mod('core/townWildlife.js'),peace=mod('core/peaceZones.js'),hunt=mod('core/huntingZones.js'),old={getDynamicProperty:world.getDynamicProperty,getDimension:world.getDimension},region={x:0,y:64,z:0,size:250,dimId:'minecraft:overworld'},all=[];
 world.getDynamicProperty=k=>k==='rpg:spawn_town_region_v1'?JSON.stringify(region):k==='rpg:peace_zones_v1'?JSON.stringify([{dimension:region.dimId,x:100,y:65,z:100}]):undefined;
 world.getDimension=()=>({getEntities:()=>all.filter(e=>!e.removed)});
 function undead(type,x=100){const tags=new Set();return {typeId:type,id:'villager-zombie-'+type,isValid:true,location:{x,y:65,z:100},dimension:{id:region.dimId},hasTag:t=>tags.has(t),addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),getComponent:k=>k==='minecraft:type_family'?{hasTypeFamily:f=>f==='monster'}:undefined,remove(){this.removed=true;}};}
 try{
  for(const type of ['minecraft:zombie_villager','minecraft:zombie_villager_v2']){
   const carried=undead(type,300);tracker.noteTownZombieSpawn(carried,'Spawned');carried.location.x=100;carried.addTag('rpg_night_spawn');all.push(carried);assert.equal(life.clearTownMonster(carried),false);assert.equal(hunt.enforceVanillaCaveSpawn(carried).action,'ignored');peace.tickPeaceZones();signal('entityLoad').fire({entity:carried});timers.at(-1)();assert.equal(carried.removed,undefined);
   const natural=undead(type);tracker.noteTownZombieSpawn(natural,'Spawned');assert.equal(life.clearTownMonster(natural),true);
   const transformed=undead(type);tracker.noteTownZombieSpawn(transformed,'Transformed');assert.equal(life.clearTownMonster(transformed),false);
   system.currentTick+=20;const egg=undead(type);tracker.noteTownZombieSpawn(egg,'Spawned');const {p}=player();p.location={x:100,y:65,z:100};p.id='zv-egg-'+type;signal('itemUse').fire({source:p,itemStack:new ItemStack('minecraft:zombie_villager_spawn_egg')});assert.equal(tracker.keepTownZombie(egg),true);assert.equal(life.clearTownMonster(egg),false);
  }
 }finally{Object.assign(world,old);}
 console.log('Both zombie-villager identifiers: external transport, load and conversion retained; native egg alias matches v2, town/cave/peace/night cleanup excluded; natural village spawning still denied');
}
{
 const protection=mod('core/townVillagers.js'),combat=mod('core/combatContext.js'),util=mod('core/util.js'),{p}=player(),old={getDynamicProperty:world.getDynamicProperty,getDimension:world.getDimension},region={x:0,y:64,z:0,size:250,dimId:'minecraft:overworld'},entities=[];
 p.id='villager-player';world.getDynamicProperty=k=>k==='rpg:spawn_town_region_v1'?JSON.stringify(region):undefined;world.getDimension=()=>({getEntities:()=>entities});
 function villager(type){const tags=new Set(),health={currentValue:20,effectiveMax:20,setCurrentValue:n=>health.currentValue=n};return {id:type,typeId:type,isValid:true,dimension:p.dimension,location:{x:100,y:65,z:100},hasTag:t=>tags.has(t),addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),getTags:()=>[...tags],getComponent:k=>k==='minecraft:health'?health:undefined,applyDamage(n){this.damageCalls=(this.damageCalls??0)+1;health.currentValue=Math.max(0,health.currentValue-n);return true;},hp:health};}
 try{
  protection.registerTownVillagers();
  const projectile={id:'player-arrow',typeId:'minecraft:arrow',getComponent:k=>k==='minecraft:projectile'?{owner:p}:undefined};
  const minion={id:'player-minion',typeId:'rpg:necro_minion',getDynamicProperty:k=>k==='rpg:necro_owner'?p.id:undefined};
  for(const type of protection.VILLAGER_TYPES){
   const v=villager(type);entities.push(v);signal('entitySpawn').fire({entity:v,cause:'Event'});assert.equal(v.hasTag(protection.TOWN_VILLAGER_TAG),true);
   for(const source of [p,projectile,minion])assert.equal(protection.blockTownVillagerDamage(v,source),true);
   assert.equal(protection.blockTownVillagerDamage(v,{id:'hostile',typeId:'minecraft:zombie'}),false);
   assert.equal(util.hurt(v,p,999),false);assert.equal(combat.scriptedHit(v,p,()=>{throw Error('player skill runner must not run');}),false);combat.setCombatHealth(v,p,v.hp,0);assert.equal(v.hp.currentValue,20);assert.equal(v.damageCalls,undefined);
   p.dimension.getEntities=()=>entities;assert.equal(util.getTargets(p,{x:100,y:65,z:100},5).some(e=>e.id===v.id),false);
   v.location.x=250;protection.syncTownVillager(v);assert.equal(v.hasTag(protection.TOWN_VILLAGER_TAG),false);assert.equal(protection.blockTownVillagerDamage(v,p),false);combat.setCombatHealth(v,p,v.hp,10);assert.equal(v.hp.currentValue,10);
   v.location.x=249.9;protection.tickTownVillagers();assert.equal(v.hasTag(protection.TOWN_VILLAGER_TAG),true);v.dimension={id:'minecraft:nether'};protection.syncTownVillager(v);assert.equal(v.hasTag(protection.TOWN_VILLAGER_TAG),false);
  }
 }finally{Object.assign(world,old);}
 console.log('Villager protection: spawn/load/position tags for legacy and modern villagers; player, projectile and summon ownership blocked before RPG damage/manual HP writes; target selection excludes them, hostile zombie and outside/different-dimension behavior retained');
}

// v0.6.38 regression coverage through the active module graph.
{
 const hunt=mod('core/huntingZones.js'),life=mod('core/townWildlife.js'),peace=mod('core/peaceZones.js');
 const original={getDynamicProperty:world.getDynamicProperty,getDimension:world.getDimension};
 const region={x:0,y:64,z:0,size:250,dimId:'minecraft:overworld'},list=[],spawned=[];
 const dimension={id:region.dimId,getBiome:()=>({id:'minecraft:plains'}),getTopmostBlock:()=>({location:{y:63},typeId:'minecraft:grass_block'}),getBlock:()=>({typeId:'minecraft:air'}),spawnEntity(id,location){const e=mob(id);e.location={...location};spawned.push(e);return e;}};
 function mob(id){const tags=new Set();return {id:id+list.length,typeId:id,isValid:true,dimension,location:{x:125,y:65,z:125},nameTag:'',hasTag:t=>tags.has(t),addTag:t=>tags.add(t),getDynamicProperty:()=>undefined,getComponent:k=>k==='minecraft:type_family'?{hasTypeFamily:f=>f==='monster'}:undefined,remove(){this.removed=true;}};}
 world.getDynamicProperty=k=>k==='rpg:spawn_town_region_v1'?JSON.stringify(region):k==='rpg:peace_zones_v1'?JSON.stringify([{dimension:region.dimId,x:125,y:65,z:125}]):undefined;
 world.getDimension=()=>({getEntities:()=>list});
 try{
  for(const type of ['pillager','vindicator','evocation_illager','evoker','ravager','witch','vex']){
   const e=mob('minecraft:'+type);list.push(e);e.addTag('rpg_night_spawn');
   assert.equal(hunt.enforceVanillaCaveSpawn(e).action,'ignored',type);
   assert.equal(life.clearTownMonster(e),false,type);peace.tickPeaceZones();signal('entityLoad').fire({entity:e});assert.ok(!e.removed,type);
  }
  const ordinary=mob('minecraft:skeleton');assert.equal(hunt.enforceVanillaCaveSpawn(ordinary).action,'removed');assert.equal(ordinary.removed,true);
  for(const id of mod('data/leveledMonsters.js').LEVELED_MONSTERS){
   const e=mob(id);e.dimension={...dimension,id:'minecraft:the_end'};e.addTag('rpg_dungeon_mob');e.nameTag='previously spawned';
   assert.equal(hunt.applyHuntingZone(e).zone,'end');assert.equal(e.removed,true,id);
  }
  const drowned=mob('minecraft:drowned');assert.equal(hunt.enforceVanillaCaveSpawn(drowned).action,'kept');assert.ok(!drowned.removed);
  const guardian=mob('minecraft:guardian');assert.equal(hunt.enforceVanillaCaveSpawn(guardian).id,'minecraft:drowned');assert.equal(guardian.removed,true);assert.equal(spawned.at(-1).typeId,'minecraft:drowned');
 }finally{Object.assign(world,original);}
 console.log('v0.6.38: all 22 RPG mob types excluded from End, seven raid species survive cave/town/peace cleanup, normal cave restriction retained, surface drowned survives and natural guardian converts to drowned');
}
{
 const {p,messages}=player('chameleon'),d=mod('core/jobDiscovery.js');p.id='chameleon-condition-privacy';
 p.setDynamicProperty('rpg:rpg_level',100);data.addProgress(p,'job_stray',1000);
 assert.equal(d.isJobDiscovered(p,jobs.frost_controller),false);
 d.discoverJob(p,'frost_controller');
 assert.equal(advance.requirementStatus(p,jobs.frost_controller).label,mod('core/spawnPolicy.js').CHAMELEON_CONDITIONS_HIDDEN);
 assert.equal(advance.checkAdvance(p,jobs.frost_controller).reason,mod('core/spawnPolicy.js').CHAMELEON_CONDITIONS_HIDDEN);
 let shown=0;const show=Form.prototype.show;Form.prototype.show=function(){shown++;return Promise.resolve({canceled:true});};
 try{await mod('core/jobMenu.js').openJobMenu(p);assert.equal(shown,0);assert.ok(messages.every(s=>!s.includes('스트레이')));}
 finally{Form.prototype.show=show;}
 console.log('v0.6.38: Chameleon cannot auto-discover through trial counters or view promotion conditions through menu, shrine or known-job status/failed commands; skillbook remains covered by existing tests');
}

{
 const {p,inv}=player('beast');p.id='beast-taunt-input';inv.setItem(0,new ItemStack(jobs.beast.weapon));
 data.setSkills(p,jobs.beast.skills.filter(id=>id!=='beast_taunt'));data.setDisabled(p,[]);data.setMana(p,200);
 p.dimension.getEntities=()=>[];p.dimension.playSound=()=>{};p.dimension.spawnParticle=()=>{};
 const ctx=mod('core/context.js').getContext(p);assert.ok(data.getSkills(p).includes('beast_taunt'),'existing Beast gains taunt');
 assert.ok(ctx.all.includes('beast_taunt'));assert.ok(!jobs.mangnani.skills.includes('beast_taunt'));
 assert.ok(mod('core/chameleonProgress.js').CHAMELEON_ALLOWED.includes('beast_taunt'));
 data.setIndex(p,ctx.all.indexOf('beast_taunt'));const before=data.getMana(p);
 signal('itemUse').fire({source:p,itemStack:inv.getItem(0)});
 assert.equal(data.cooldownLeft(p,'beast_taunt'),600);assert.equal(data.getMana(p),before-80);
 signal('itemUse').fire({source:p,itemStack:inv.getItem(0)});assert.equal(data.getMana(p),before-80,'cooldown prevents double spend');
 console.log('v0.6.38: existing Beast gains Taunt; real axe item-use input dispatches new runner, spends 80 mana, sets 600-tick cooldown and blocks repeat; Chameleon learning registry includes the new skill');
}

{
 const {p,inv}=player('michael');p.id='michael-input-637';p.setDynamicProperty('rpg:admin_mana_max',2000);data.setMana(p,2000);inv.setItem(0,new ItemStack(jobs.michael.weapon));
 data.setSkills(p,jobs.michael.skills.filter(id=>!id.startsWith('michael_')));data.setDisabled(p,[]);
 const allies=['a','b','c'].map(id=>{const q=player('mage');q.p.id='res637-'+id;q.p.location={x:1,y:64,z:0};return q;});
 for(const actor of [p,...allies.map(q=>q.p)]){actor.addTag('rpg_team_res637');const native=new Map();actor.setProperty=(k,v)=>native.set(k,v);actor.getProperty=k=>native.get(k);actor.dimension.spawnParticle=()=>{};actor.dimension.playSound=()=>{};}
 p.dimension.getEntities=()=>[];const originalOnline=world.getAllPlayers;world.getAllPlayers=()=>[p,...allies.map(q=>q.p)];
 const res=mod('core/resurrection.js'),ctx=mod('core/context.js').getContext(p),runs=mod('core/dungeonState.js').dungeonRuns;
 assert.ok(data.getSkills(p).includes('michael_holy_spear'));assert.ok(data.getSkills(p).includes('michael_resurrection'));assert.ok(!jobs.angel.skills.includes('michael_resurrection'));
 data.setIndex(p,ctx.skills.indexOf('michael_resurrection'));let before=data.getMana(p);
 mod('core/input.js').handleFriendlyHit(p,allies[0].p);assert.equal(data.getMana(p),before-500);assert.equal(data.cooldownLeft(p,'michael_resurrection'),1800);
 system.currentTick+=1800;mod('core/input.js').handleFriendlyHit(p,allies[1].p);assert.equal(data.getMana(p),before-1000);
 system.currentTick+=1800;before=data.getMana(p);mod('core/input.js').handleFriendlyHit(p,allies[2].p);assert.equal(data.getMana(p),before);assert.equal(data.cooldownLeft(p,'michael_resurrection'),0,'full slots do not spend cooldown');
 const run={id:'res637-run',d:{id:'res637-dungeon',tier:1},members:[{id:allies[0].p.id}],phase:'boss',deadline:Date.now()+100000,live:new Map()};runs.set(run.d.id,run);
 const target=allies[0].p;allies[0].health.currentValue=2;let teleports=0;target.teleport=()=>teleports++;
 try{
  const monster={id:'native-zombie',typeId:'minecraft:zombie',getComponent:()=>undefined};
  mod('core/combatContext.js').setCombatHealth(target,monster,allies[0].health,0);
  assert.equal(allies[0].health.currentValue,100);assert.equal(target.getProperty(res.RESURRECTION_ARMED),false);assert.equal(runs.get(run.d.id),run);assert.equal(run.members.length,1);assert.equal(run.phase,'boss');assert.equal(teleports,0);
  // Native fatal damage handoff uses properties, not a death/respawn or dungeon re-entry.
  allies[1].health.currentValue=3;allies[1].p.setProperty(res.RESURRECTION_ARMED,false);allies[1].p.setProperty(res.RESURRECTION_PENDING,true);res.tickResurrection();assert.equal(allies[1].health.currentValue,100);assert.equal(allies[1].p.getProperty(res.RESURRECTION_PENDING),false);
  assert.equal(res.markResurrection(p,allies[2].p),true);
  const attacker=player().p;attacker.id='pvp-637';mod('core/combatContext.js').setCombatHealth(allies[2].p,attacker,allies[2].health,-1000);assert.equal(allies[2].health.currentValue,0,'PvP damage that remains lethal after reduction is not resurrected');
  data.setIndex(p,ctx.skills.indexOf('michael_holy_spear'));let dealt=0;
  p.dimension.getBlock=()=>({isSolid:false});
  const enemy={id:'spear-monster',typeId:'minecraft:zombie',isValid:true,location:{x:0,y:64,z:3},dimension:p.dimension,getComponent:k=>k==='minecraft:health'?{currentValue:100,effectiveMax:100}:k==='minecraft:type_family'?{hasTypeFamily:f=>f==='monster'}:undefined,getDynamicProperty:()=>undefined,applyDamage:n=>{dealt+=n;return true;}};
  signal('entityHitEntity').fire({damagingEntity:p,hitEntity:enemy});assert.equal(dealt,30);assert.equal(data.cooldownLeft(p,'michael_holy_spear'),60);
 }finally{runs.delete(run.d.id);data.setJobId(p,'apprentice');res.tickResurrection();world.getAllPlayers=originalOnline;}
 console.log('v0.6.38 actual input: existing Michael auto-learns both skills; allied left click spends exactly 500 mana/1800-tick cooldown, two-target cap refuses free of cost; native handoff/direct PvE rescue keep HP>0 and dungeon boss membership without teleport; PvP stays lethal; spear left click deals monster 30 on 60-tick cooldown');
}

for(const [initial,books]of [['mage',30],['cleric',70],['swordsman',30]]){
 const {p,inv}=player(initial);p.id='mana-stable-'+initial;p.setDynamicProperty('rpg:progress',JSON.stringify({books,mana_offer_books:2,mana_offer_diamonds:1}));
 // No prior maxManaOf read: setJobId itself must migrate from the old job.
 const expected=(jobs[initial].highMana?200+books*20:1000)+300;
 data.setJobId(p,initial==='mage'?'swordsman':'mage');assert.equal(data.maxManaOf(p),expected);
 for(const job of ['michael','revenant','chameleon','swordsman','mage']){advance.applyAdvance(p,jobs[job]);assert.equal(data.maxManaOf(p),expected,initial+' -> '+job);}
 advance.resetToApprentice(p);assert.equal(data.maxManaOf(p),expected);
 const restored=player('michael').p;restored.setDynamicProperty('rpg:mana_base_v1',p.getDynamicProperty('rpg:mana_base_v1'));restored.setDynamicProperty('rpg:progress',p.getDynamicProperty('rpg:progress'));assert.equal(data.maxManaOf(restored),expected,'persisted base survives reload');
 data.forceSetManaMax(p,'5000');data.setJobId(p,'cleric');assert.equal(data.maxManaOf(p),5000);data.forceSetManaMax(p,'reset');assert.equal(data.maxManaOf(p),expected);
 inv.setItem(2,new ItemStack('minecraft:book'));inv.setItem(3,new ItemStack('minecraft:diamond_block'));data.setJobId(p,'swordsman');assert.equal(mod('core/offer.js').offerItems(p).ok,true);assert.equal(data.maxManaOf(p),expected+250);
 data.setJobId(p,'mage');assert.equal(data.maxManaOf(p),expected+250);
}
console.log('v0.6.38: migrate current mana before first job change; actual advances/reset/reload preserve max; donations add exactly 50/200 across classes; admin max/reset preserves underlying base');

{
 const definition=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0638/entities/player.json'),'utf8'))['minecraft:entity'];
 for(const undead of [false,true])for(const monster of [false,true])for(const sun of [false,true]){
  const expected=(sun?1.5:1)*(undead&&monster?.7:1);
  const hits=definition.components['minecraft:damage_sensor'].triggers.filter(t=>filter(t.on_damage.filters,monster,sun,undead));assert.equal(hits.length,1);assert.ok(Math.abs(hits[0].damage_multiplier-expected)<1e-9);
  for(const [id,g]of Object.entries(definition.component_groups))if(id.startsWith('rpg:ward_defense_')){const hits=g['minecraft:damage_sensor'].triggers.filter(t=>filter(t.on_damage.filters,monster,sun,undead));assert.equal(hits.length,1);assert.ok(Math.abs(hits[0].damage_multiplier-(1-Number(id.split('_').at(-1))/10*.0035)*expected)<1e-9);}
 }
 const {p,health,inv}=player('revenant');p.id='undead638';races.syncRace(p);assert.equal(p.hasTag('rpg_undead'),true);
 const monster={typeId:'minecraft:zombie',getComponent:()=>undefined};assert.equal(races.undeadMonsterDamageMultiplier(p,monster),.7);
 health.currentValue=100;mod('core/combatContext.js').setCombatHealth(p,monster,health,60);assert.equal(health.currentValue,72);
 const human=player('mage').p;assert.equal(races.undeadMonsterDamageMultiplier(human,monster),1);assert.equal(races.undeadMonsterDamageMultiplier(p,human),1);
 health.currentValue=100;mod('core/combatContext.js').setCombatHealth(p,human,health,60);assert.equal(health.currentValue,96.8);
 inv.setItem(0,new ItemStack('rpg:stone_mask'));assert.equal(races.useStoneMask(p).ok,true);assert.equal(p.hasTag('rpg_undead'),false);assert.equal(races.undeadMonsterDamageMultiplier(p,monster),1);
 data.setJobId(p,'mage');assert.equal(p.hasTag('rpg_undead'),false);data.setJobId(p,'revenant');assert.equal(p.hasTag('rpg_undead'),true);
}
console.log('v0.6.38: undead-only monster x0.7 in native ward/base sensors and direct HP path; direct PvP x0.08, environment x1, vampire sun and ward stack separately');

// v0.6.39: execute real equipment reads, synchronization, direct damage and impulses.
{
 const armor=mod('core/abyssalArmor.js'),util=mod('core/util.js'),combat=mod('core/combatContext.js');
 const {p,health}=player('mage'),worn=new Map(),events=[];const get=p.getComponent;
 p.getComponent=id=>id==='minecraft:equippable'?{getEquipment:slot=>worn.get(slot)}:get(id);
 p.triggerEvent=id=>events.push(id);
 const slots=['Head','Chest','Legs','Feet'],parts=['helmet','chestplate','leggings','boots'];
 for(let count=0;count<=4;count++){
  worn.clear();for(let i=0;i<count;i++)worn.set(slots[i],new ItemStack('rpg:abyssal_'+parts[i]));
  const s=armor.syncAbyssalArmor(p,true);assert.equal(s.count,count);assert.equal(s.toughness,count*4);assert.equal(s.knockbackResistance,count*2);
  assert.equal(p.hasTag('rpg_abyssal_active'),count>0);assert.equal(events.at(-1),'rpg:abyssal_knockback_'+count);
  assert.equal(p.getTags().filter(t=>t.startsWith('rpg_abyssal_')&&t!=='rpg_abyssal_active').length,count?1:0);
  const beforeEvents=events.length;armor.syncAbyssalArmor(p);assert.equal(events.length,beforeEvents);
  health.currentValue=100;combat.setCombatHealth(p,{typeId:'minecraft:zombie'},health,60);
  assert.ok(Math.abs(health.currentValue-(100-40*s.multiplier))<1e-8);
 }
 const full=armor.abyssalArmorStats(p);assert.equal(full.armor,28);assert.equal(full.overflow,8);assert.ok(Math.abs(full.multiplier-.5712)<1e-9);
 // Armor can turn a lethal direct HP write into a survivable hit before resurrection.
 health.currentValue=50;combat.setCombatHealth(p,{typeId:'minecraft:zombie'},health,-10);assert.ok(Math.abs(health.currentValue-15.728)<1e-8);
 let impulse;p.applyImpulse=v=>impulse=v;p.applyKnockback=()=>{throw Error('Armored scripted impulse must not apply native resistance twice');};
 util.knockback(p,1,0,2,.5);assert.ok(Math.abs(impulse.x-.4)<1e-8);assert.ok(Math.abs(impulse.y-.1)<1e-8);
 util.push(p,2,.5,0);assert.ok(Math.abs(impulse.x-.4)<1e-8);
 // Mixed armor: a single abyssal item gets its bonuses without a full-set gate.
 for(let i=0;i<4;i++)worn.set(slots[i],new ItemStack('minecraft:netherite_'+parts[i]));
 worn.set('Chest',new ItemStack('rpg:abyssal_chestplate'));
 const mixed=armor.syncAbyssalArmor(p);assert.equal(mixed.count,1);assert.equal(mixed.armor,22);assert.equal(mixed.overflow,2);assert.ok(Math.abs(mixed.multiplier-.8832)<1e-8);
 // Remove/break a piece, then load again: no stale active profile or knockback.
 worn.clear();armor.syncAbyssalArmor(p);assert.equal(p.hasTag('rpg_abyssal_active'),false);assert.equal(events.at(-1),'rpg:abyssal_knockback_0');
 armor.syncAbyssalArmor(p,true);assert.equal(armor.abyssalDamageMultiplier(p),1);
 // Restore lost tags even when the saved equipment profile has not changed.
 worn.set('Chest',new ItemStack('rpg:abyssal_chestplate'));armor.syncAbyssalArmor(p);
 p.removeTag('rpg_abyssal_active');p.removeTag('rpg_abyssal_9');const beforeRepair=events.length;
 armor.syncAbyssalArmor(p);assert.equal(events.length,beforeRepair+1);assert.equal(p.hasTag('rpg_abyssal_active'),true);assert.equal(p.hasTag('rpg_abyssal_9'),true);
 // Existing custom-named/enchanted/upgraded items gain attribute lore without data loss.
 const labels=mod('core/rarityLabels.js'),item=new ItemStack('rpg:abyssal_chestplate');item.nameTag='내 갑옷';item.setLore(['원래 설명']);item.setDynamicProperty('rpg:armor_upgrade',10);item.setDynamicProperty('rpg:rarity',6);item.durability.damage=123;
 assert.equal(labels.decorateRarity(item),true);assert.ok(item.getLore().includes('§9+4 내구성 (방어 강인함)'));assert.ok(item.getLore().includes('§9+2 밀치기 저항 (20%)'));assert.ok(item.getLore().includes('원래 설명'));assert.equal(item.nameTag,'내 갑옷');assert.equal(item.durability.damage,123);assert.equal(item.getDynamicProperty('rpg:armor_upgrade'),10);assert.equal(item.getDynamicProperty('rpg:rarity'),6);
 const lore=JSON.stringify(item.getLore());assert.equal(labels.decorateRarity(item),false);assert.equal(JSON.stringify(item.getLore()),lore);
 console.log('v0.6.39: per-piece armor/toughness/knockback, mixed netherite overflow, swap/break/reload cleanup, lethal direct mitigation and single-pass scripted impulse passed');
}

{
 const {p}=player('sword_saint'),worn=new Map(),get=p.getComponent;
 const sword=new ItemStack('rpg:sword_saint_sword');sword.setDynamicProperty('rpg:weapon_upgrade',10);worn.set('Mainhand',sword);
 p.getComponent=id=>id==='minecraft:equippable'?{getEquipment:slot=>worn.get(slot)}:get(id);
 p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:250,mag:5,vit:5,int:5}));
 const runes=mod('core/runeInventory.js'),bag=runes.readRuneBag(p),r=runes.addRuneRecord(bag,'power',10,5);bag.equipped[0]=r.uid;runes.writeRuneBag(p,bag);
 const stats=mod('core/stats.js'),gear=mod('core/equipment.js').getEquipmentBonuses(p);
 const annihilation=stats.skillDamageFor(p,41,'physical'),rush=stats.skillDamageFor(p,6,'physical');
 assert.ok(Math.abs(annihilation-862.09340604)<1e-8);assert.ok(Math.abs(rush-126.16001064)<1e-8);assert.ok(Math.abs(annihilation/rush-41/6)<1e-9);
 console.log('STR250 legendary power rune+10 class sword+10, no armor-set/Strength/other buffs:',JSON.stringify({runeMultiplier:gear.physical,annihilation,rushPerHit:rush,rushTotal:rush*8}));
 const veteran=player('war_god').p;veteran.setDynamicProperty('rpg:skills',JSON.stringify(['war_god_punch']));assert.ok(data.getSkills(veteran).includes('war_god_eight_punch'),'Existing War Gods learn the new skill');
}

{
 assert.equal(jobs.beast_lord,undefined);
 const {p}=player('beast_lord');assert.equal(data.getJobId(p),'apprentice');
 console.log('Removed unimplemented beast_lord placeholder; old saved placeholder job safely resolves to apprentice');
}

{
 for(const name of ['jailcreate','jailrelease','jailreset','jailstatus']){
  const defs=allCommandDefs.get('rpg:'+name);assert.equal(defs.length,1,name);
  assert.equal(defs[0].d.permissionLevel,1,name);
 }
 assert.equal(commandDefs.get('rpg:jail').d.permissionLevel,0);
 const {p,messages}=player();mod('core/rpgActions.js').runRpgAction('jailrelease',p,'Other');assert.ok(messages.at(-1).includes('관리자'));
 const {p:admin,messages:adminMessages}=player();admin.id='jail-command-admin';admin.name='Game Op';admin.commandPermissionLevel=1;
 const {p:target}=player();target.id='jail-command-target';target.name='Offline User';
 const oldGetDimension=world.getDimension,oldSet=world.setDynamicProperty;
 const writes=new Map(),blocks=new Map();
 admin.dimension.runCommand=()=>({successCount:1});
 admin.dimension.getBlock=({x,y,z})=>{
  const key=`${x},${y},${z}`;
  return {get isAir(){return !blocks.has(key);},get permutation(){return blocks.get(key)??{type:'minecraft:air'};},setPermutation(value){blocks.set(key,value);}};
 };
 world.getDimension=()=>admin.dimension;
 world.setDynamicProperty=(key,value)=>writes.set(key,value);
 const prison=mod('core/prison.js');
 function run(name,source,...args){
  const before=timers.length;
  assert.equal(commandDefs.get('rpg:'+name).fn({sourceEntity:source},...args).status,0);
  assert.equal(timers.length,before+1);
  timers.at(-1)();
 }
 try{
  run('jailcreate',p);
  assert.match(messages.at(-1),/관리자/);
  assert.equal(blocks.size,0);
  run('jailcreate',admin,-70);
  assert.match(adminMessages.at(-1),/-62~315/);
  assert.equal(blocks.size,0);
  run('jailcreate',admin);
  const config=JSON.parse(writes.get(prison.PRISON_KEY)).config;
  assert.equal(config.cells.length,10);
  assert.equal(config.y,Math.floor(admin.location.y)-1);
  assert.ok(blocks.size>0);
  prison.recordPrisonPk(admin);prison.recordPrisonPk(target);
  run('jailreset',p,'Offline User');
  assert.match(messages.at(-1),/관리자/);
  assert.equal(prison.getPrisonRecord(target).stacks,1);
  run('jailreset',admin);
  assert.equal(prison.getPrisonRecord(admin).stacks,0);
  assert.equal(prison.getPrisonRecord(target).stacks,1);
  run('jailreset',admin,['Offline User']);
  assert.equal(prison.getPrisonRecord(target).stacks,0);
  assert.match(adminMessages.at(-1),/Offline User/);
 }finally{
  world.getDimension=oldGetDimension;world.setDynamicProperty=oldSet;
 }
 console.log('Prison slash callbacks: one registry owner, public/operator permissions, omitted height, visible errors, self reset and offline quoted-name reset, no command relay');
}

await (await import('./commerceCases.mjs')).default({assert,mod,player,ItemStack,Form,world,signal});
for(const name of ['pay','runeauto','runeautostop'])for(const {d} of allCommandDefs.get('rpg:'+name))assert.equal(d.permissionLevel,0);


{
 const {p:admin,messages:adminMessages,inv}=player();
 const {p:target,messages:targetMessages}=player();
 admin.id='currency-admin';admin.name='Operator';admin.commandPermissionLevel=1;
 target.id='currency-recipient';target.name='Recipient';
 const tool=mod('core/adminTool.js'),wallet=mod('core/wallet.js');
 const originalPlayers=world.getAllPlayers,originalShow=Form.prototype.show,originalSubmit=Form.prototype.submitButton;
 const before={gold:20,stone:30,dust:40};
 const pick=(selection)=>({selection});
 const choices=(currency,amount,answer=pick(1))=>[pick(0),pick(1),pick(10),pick(currency),{formValues:[amount]},answer];
 async function useTool(answers) {
  Form.prototype.show=async()=>{const next=answers.shift();return typeof next==='function'?next():next??{canceled:true};};
  await tool.openAdminTool(admin);
  assert.equal(answers.length,0);
 }
 try {
  world.getAllPlayers=()=>[admin,target];
  Form.prototype.submitButton=function(){return this;};
  mod('core/rpgActions.js').runRpgAction('admin',admin);
  assert.equal(inv.getItem(0).typeId,tool.ADMIN_TOOL_ID);
  wallet.setWallet(target,before);
  for(const [i,amount] of [[0,'1200'],[1,'35'],[2,'82']]) await useTool(choices(i,amount));
  const expected={gold:1220,stone:65,dust:122};
  assert.deepEqual({...wallet.getWallet(target)},expected);
  assert.deepEqual({...wallet.getWallet(admin)},{gold:0,stone:0,dust:0});
  assert.match(targetMessages.at(-1),/룬 가루 82개/);
  assert.match(adminMessages.at(-1),/Recipient.*82개/);

  await useTool(choices(0,'9',{canceled:true}));
  await useTool(choices(1,'1.5').slice(0,-1));
  await useTool(choices(2,String(wallet.BALANCE_MAX)));
  await useTool(choices(0,'1',()=>{admin.commandPermissionLevel=0;return pick(1);}));
  await useTool([]);
  admin.commandPermissionLevel=1;
  await useTool(choices(0,'1',()=>{world.getAllPlayers=()=>[admin];return pick(1);}));
  assert.deepEqual({...wallet.getWallet(target)},expected);
  assert.deepEqual({...wallet.getWallet(admin)},{gold:0,stone:0,dust:0});
  assert.equal(targetMessages.length,3);
 } finally {
  world.getAllPlayers=originalPlayers;
  Form.prototype.show=originalShow;
  Form.prototype.submitButton=originalSubmit;
 }
 console.log('Admin tool: exact grants of all three wallet currencies to another player, cancellation/invalid amount/cap/revoked permission/disconnect protected');
}

{
 const {p,inv}=player(), fusion=mod('core/fusion.js'), options=mod('data/commonWeapons.js');
 const main={kind:'inventory',slot:1},material={kind:'inventory',slot:2};
 for(let rank=0;rank<6;rank++){
  const blade=inv.getItem(1)??new ItemStack('rpg:common_battle_sword');
  blade.setDynamicProperty('rpg:weapon_upgrade',10);
  inv.setItem(1,blade);inv.setItem(2,blade);
  const book=new ItemStack('minecraft:enchanted_book');
  book.enchants=[{type:{id:'minecraft:sharpness'},level:5}];inv.setItem(4,book);
  assert.equal(fusion.fuseEquipment(p,main,material).ok,true);
  assert.equal(options.weaponOptionChance(inv.getItem(1)),15+rank*3);
  assert.equal(inv.getItem(1).getDynamicProperty('rpg:weapon_upgrade'),0);
 }
}

{
 const {p,inv}=player();p.id='combat-runes';
 const bag=mod('core/runeInventory.js'),combat=mod('core/combatRunes.js'),ranged=mod('core/rangedRunes.js');
 const stats=mod('core/stats.js'),{SKILLS}=mod('data/skills.js');
 assert.equal(combat.criticalMultiplier(.5,()=>.5),1);
 assert.equal(combat.criticalMultiplier(.5,()=>.49),1.75);
 for(const [chance,multiplier] of [[1,1.75],[1.5,2.25],[2.5,3.25]])assert.equal(combat.criticalMultiplier(chance),multiplier);
 assert.equal(stats.skillDamageFor(p,20,'physical'),20);
 assert.equal(combat.rangedRuneRate(p),1);
 assert.deepEqual({...combat.projectileMotion(p,1.5,3)},{speed:1.5,steps:3,step:.5});
 for(const [i,id] of ['attack_speed','critical_hit','cooldown_reduction'].entries()){
  const token=new ItemStack('rpg:rune_'+id+'_enhanced');
  token.setDynamicProperty('rpg:rarity',6);token.setDynamicProperty('rpg:rune_upgrade',10);
  inv.setItem(1,token);
  const deposited=bag.depositRune(p,1);assert.equal(deposited.ok,true);
  assert.equal(bag.equipRune(p,deposited.rune.uid,i).ok,true);
 }
 assert.ok(Math.abs(stats.skillDamageFor(p,20,'magic')-65)<1e-8);
 assert.ok(Math.abs(stats.skillDamageFor(p,20,'physical')-65)<1e-8);
 assert.equal(stats.skillDamageFor(p,20,'fixed'),20);
 const hp={currentValue:100,effectiveMax:100,setCurrentValue(n){this.currentValue=n;}};
 const target={id:'crit-target',typeId:'minecraft:zombie',getComponent:()=>hp};
 const damage=mod('core/commonWeaponDamage.js').applyCommonWeaponBonus;
 const ev={damage:20,hurtEntity:target,damageSource:{damagingProjectile:{},cause:'projectile'}};
 assert.equal(damage(ev,false,p),65);assert.equal(hp.currentValue,55);
 assert.equal(damage(ev,true,p),20);assert.equal(hp.currentValue,55);

 for(const [id,ticks] of [['dragon_sprint',160],['world_stop',400],['hacker_reboot',800],['blood_tentacle',100]]){
  data.startCooldown(p,id,SKILLS[id].cooldown);
  assert.equal(data.cooldownLeft(p,id),ticks,id);
 }
 data.startCooldown(p,'revenant_execution',SKILLS.revenant_execution.successCooldown);
 assert.equal(data.cooldownLeft(p,'revenant_execution'),40);
 assert.equal(ranged.rangedShotDelay(p,10),4);
 assert.deepEqual({...combat.projectileMotion(p,1.5,3)},{speed:4.5,steps:9,step:.5});
 assert.equal(ranged.rangedShotDelay(p,15),5);
 ranged.registerRangedRunes();
 function spawnShot(id,velocity,typeId='minecraft:arrow',owner=p,alreadyScripted=false){
  const speeds=[],component={owner,shoot:v=>speeds.push(v.z)};
  const entity={id,isValid:true,typeId,getVelocity:()=>({x:0,y:0,z:velocity}),getComponent:()=>component};
  if(alreadyScripted)ranged.markScriptRangedShot(entity);
  const start=timers.length;
  signal('entitySpawn').fire({entity});
  for(const callback of timers.slice(start))callback();
  return speeds;
 }
 const bow={source:p,itemStack:{typeId:'minecraft:bow'}};
 const savedTick=system.currentTick;
 signal('itemStartUse').fire(bow);system.currentTick+=7;
 signal('itemReleaseUse').fire(bow);
 const draw=7/20;
 assert.ok(Math.abs(spawnShot('fast-draw',draw*draw+2*draw)[0]-9)<1e-8);
 assert.deepEqual(spawnShot('trident',2,'minecraft:thrown_trident'),[6]);
 assert.deepEqual(spawnShot('untouched-mob-shot',2,'minecraft:arrow',{typeId:'minecraft:skeleton'}),[]);
 assert.deepEqual(spawnShot('already-scripted-shot',9,'minecraft:arrow',p,true),[]);
 system.currentTick=savedTick;
 const rune=bag.equippedRunes(p).find(r=>r.id==='critical_hit');
 assert.equal(bag.withdrawRune(p,rune.uid).ok,true);
 assert.equal(inv.getItem(0).getDynamicProperty('rpg:rarity'),6);
 assert.equal(inv.getItem(0).getDynamicProperty('rpg:rune_upgrade'),10);
 assert.equal(stats.skillDamageFor(p,20,'magic'),20);
 console.log('Combat runes: real bag equip/withdraw, critical probability/overflow and physical/magic/native paths, +10 cooldown exceptions, alternate cooldown, shortened draw and projectile velocity without double acceleration');
}

{
 const {p,health}=player('bloodedge');p.id='vladimir-contract';
 const stats=mod('core/stats.js'),limits=mod('core/healthLimits.js'),guide=mod('core/skillGuide.js');
 const profile={str:5,vit:6,int:5,mag:10};
 p.setDynamicProperty('rpg:stat_values',JSON.stringify(profile));
 p.setDynamicProperty('rpg:rpg_level',20);
 p.addEffect=(id,_duration,{amplifier})=>{if(id==='health_boost')health.effectiveMax=20+4*(amplifier+1);};
 p.removeEffect=()=>{health.effectiveMax=20;};
 stats.applyVitality(p);
 assert.deepEqual({...stats.bloodContractBonus(p)},{magic:.5,health:5.25});
 assert.equal(health.effectiveMax,32);assert.equal(limits.rpgMaxHealth(p,health),29.25);
 assert.equal(health.currentValue,29.25);
 assert.ok(Math.abs(stats.skillDamageFor(p,20,'magic')-20*(1+5.5*.0588))<1e-8);
 assert.ok(Math.abs(stats.healingFor(p,20)-20*(1+5.5*.0098))<1e-8);
 assert.equal(stats.allocateStat(p,'mag',1).ok,true);
 assert.equal(limits.rpgMaxHealth(p,health),29.75);
 assert.equal(stats.getStats(p).mag,11);
 assert.match(mod('core/statusTablet.js').statusBody(p),/HP 29\.25 \/ 29\.75/);
 const category=guide.visibleSkillGuideGroups(p).find(g=>g.line==='bloodedge');
 assert.equal(category.ids.length,8);
 assert.match(guide.skillGuideDetail('bloodedge_awakening',p),/초당 MP 10 \/ 쿨 0초/);
 assert.match(guide.skillGuideDetail('bloodedge_volley',p),/피해 5\.2/);
 p.setDynamicProperty('rpg:job','mage');stats.applyVitality(p);
 assert.deepEqual({...stats.bloodContractBonus(p)},{magic:0,health:0});
 assert.equal(limits.rpgMaxHealth(p,health),24);
}
{
 const {p}=player('chameleon');p.id='vlad-excluded-chameleon';
 const progress=mod('core/chameleonProgress.js'),skills=mod('core/chameleon.js');
 const state=progress.readChameleonProgress(p);
 state.learned=['bloodedge_volley','bloodedge_pool','mage_fireball'];state.spentSp=21;
 state.charges.bloodedge_pool=2;state.evolved=['bloodedge_pool'];state.transcended.bloodedge_pool=1;
 progress.saveChameleonProgress(p,state);data.setSkills(p,state.learned);
 assert.equal(skills.learnChameleonSkill(p,'혈액 난사').ok,false);
 assert.equal(progress.purchaseChameleonSkill(p,'bloodedge_pool').ok,false);
 assert.equal(progress.CHAMELEON_ALLOWED.some(id=>id.startsWith('bloodedge_')),false);
 assert.equal(mod('core/skillAccess.js').hasBorrowedSkill(p,'bloodedge_pool'),false);
 assert.equal(progress.executeChameleonSkill(p,'bloodedge_pool',()=>assert.fail('exclusive runner called')).ok,false);
 progress.syncChameleonLoadout(p);progress.syncChameleonLoadout(p);
 const next=progress.readChameleonProgress(p);
 assert.deepEqual(Array.from(next.learned),['mage_fireball']);assert.equal(next.refundedSp,18);
 assert.equal(next.evolved.length,0);assert.equal(Object.keys(next.transcended).length,0);
 assert.ok(data.getSkills(p).includes('mage_fireball'));
 console.log('Vladimir: exact fractional RPG HP/MAG and stat allocation, own skill guide, Chameleon eligibility/legacy refunds and rejection before dispatch');
}
{
 const sandbag=mod('core/superSandbag.js');
 mod('core/lifesteal.js').registerLifesteal();
 sandbag.registerSuperSandbag();
 const first=player('bloodedge').p, second=player('bloodedge').p;
 first.id='dummy-first';first.name='First';
 second.id='dummy-second';second.name='Second';
 const health={effectiveMax:65536,currentValue:65536,resetToMaxValue(){this.currentValue=this.effectiveMax;}};
 const props=new Map();
 const target={
  id:'super-dummy',typeId:sandbag.SUPER_SANDBAG_ID,nameTag:'',isValid:true,
  getComponent:id=>id==='minecraft:health'?health:undefined,
  getDynamicProperty:key=>props.get(key),
  setDynamicProperty(key,value){if(value===undefined)props.delete(key);else props.set(key,value);}
 };
 signal('entitySpawn').fire({entity:target});
 assert.match(target.nameTag,/슈퍼 샌드백.*HP ∞/);
 function strike(damage,damageSource){
  health.currentValue-=damage;
  signal('entityHurt').fire({hurtEntity:target,damage,damageSource});
  assert.equal(health.currentValue,health.effectiveMax);
 }
 strike(16,{cause:'entityAttack',damagingEntity:first});
 const arrow={getComponent:id=>id==='minecraft:projectile'?{owner:first}:undefined};
 strike(5.25,{cause:'projectile',damagingProjectile:arrow});
 assert.match(target.nameTag,/First · 누적 피해 §e21\.25$/);
 strike(99,{cause:'fall'});
 assert.match(target.nameTag,/First · 누적 피해 §e21\.25$/);
 strike(9,{cause:'entityAttack',damagingEntity:second});
 assert.match(target.nameTag,/Second · 누적 피해 §e9$/);
 mod('core/combatContext.js').setCombatHealth(target,first,health,health.currentValue-14.5);
 assert.match(target.nameTag,/First · 누적 피해 §e35\.75$/);
 assert.equal(health.currentValue,health.effectiveMax);
 assert.equal(mod('core/util.js').hurt(target,second,100000,'fixed'),true);
 assert.match(target.nameTag,/Second · 누적 피해 §e100,009$/);
 signal('playerInteractWithEntity').fire({target,player:first});
 assert.match(target.nameTag,/Second · 누적 피해 §e100,009$/);
 first.isSneaking=true;
 signal('playerInteractWithEntity').fire({target,player:first});
 assert.match(target.nameTag,/First · 누적 피해 §e0$/);
 strike(1,{cause:'entityAttack',damagingEntity:first});
 assert.match(target.nameTag,/First · 누적 피해 §e1$/);
 strike(2,{cause:'entityAttack',damagingEntity:second});
 assert.match(target.nameTag,/Second · 누적 피해 §e100,011$/);
 const classWeapon=mod('data/classWeapons.js').classWeapon('rpg:bloodedge_scythe');
 assert.equal(classWeapon.damage,20);
 for(const pack of ['RPG_BP_v0638','RPG_RP_v0638']){
  const item=JSON.parse(fs.readFileSync(path.join(root,pack,'items/bloodedge_scythe.json')));
  assert.equal(item['minecraft:item'].components['minecraft:damage'],20);
 }
 console.log('Super Sandbag: native melee and arrow attribution, environmental healing, scripted and overkill damage, separate persistent totals and sneaking reset; Blood Scythe stats match both packs');
}

{
 const blood=mod('skills/blood.js'),stats=mod('core/stats.js'),warGod=mod('skills/warGod.js');
 const {SKILLS}=mod('data/skills.js'),runes=mod('core/runeInventory.js');
 const near=(actual,expected)=>assert.ok(Math.abs(actual-expected)<1e-8,`${actual} != ${expected}`);
 function setup(job,rune){
  const fixture=player(job),{p,inv}=fixture;
  p.id='v0686-'+job;p.getViewDirection=()=>({x:0,y:0,z:1});
  const weapon=new ItemStack(jobs[job].weapon);weapon.setDynamicProperty('rpg:weapon_upgrade',10);inv.setItem(0,weapon);
  p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:45,mag:45,vit:5,int:5}));
  const bag=runes.readRuneBag(p),record=runes.addRuneRecord(bag,rune,10,5);
  bag.equipped[0]=record.uid;runes.writeRuneBag(p,bag);
  const hp={currentValue:5000,effectiveMax:5000},hits=[],effects=[];
  const target={id:p.id+'-target',typeId:'minecraft:zombie',dimension:p.dimension,isValid:true,
   location:{x:0,y:64,z:1.5},getComponent:id=>id==='minecraft:health'?hp:undefined,
   getDynamicProperty:()=>undefined,hasTag:()=>false,
   applyDamage(amount){hits.push(amount);hp.currentValue-=amount;return true;},
   addEffect:(id,duration)=>effects.push({id,duration}),
  };
  p.dimension.getEntities=()=>[target];p.dimension.getBlock=()=>({isSolid:false});
  return {...fixture,target,hits,effects};
 }
 const mage=setup('blood_mage','arcane');
 const {p,inv,target,hits,effects}=mage;
 assert.ok(stats.skillDamageFor(p,28,'magic')>28);
 assert.equal(blood.RUNNERS.blood_tentacle(p,jobs.blood_mage,SKILLS.blood_tentacle),true);
 blood.tickBloodTentacles();blood.tickBloodTentacles();
 assert.equal(hits.length,1);near(hits[0],stats.skillDamageFor(p,28,'magic')*.8);
 assert.equal(blood.RUNNERS.blood_bind(p,jobs.blood_mage,SKILLS.blood_bind),true);
 near(hits[1],stats.skillDamageFor(p,10,'magic')*2);
 assert.equal(mage.health.currentValue,62);
 assert.deepEqual(effects[0],{id:'slowness',duration:100});
 for(const pack of ['RPG_BP_v0638','RPG_RP_v0638']){
  const {components}=JSON.parse(fs.readFileSync(path.join(root,pack,'items/blood_spear.json')))['minecraft:item'];
  assert.equal(components['minecraft:durability'].max_durability,10);
 }
 blood.registerBloodMagic();
 assert.equal(blood.RUNNERS.blood_spear(p),true);
 p.selectedSlotIndex=1;
 assert.match(inv.getItem(1).getLore().at(-1),/10\/10$/);
 const beforeSpearHits=hits.length;
 for(let hit=1;hit<=10;hit++){
  system.currentTick+=10;
  if(hit%2===1){
   componentHandlers.get('rpg:blood_spear_reach').onUse({source:p});
   timers.at(-1)();
  }else signal('entityHitEntity').fire({damagingEntity:p,hitEntity:target});
  assert.equal(hits.length,beforeSpearHits+hit);
  const held=inv.getItem(1);
  if(hit===10)assert.equal(held,undefined);
  else {
   assert.equal(held.durability.damage,hit);
   assert.match(held.getLore().at(-1),new RegExp((10-hit)+'/10$'));
  }
 }
 const previouslyUsedSpear=new ItemStack('rpg:blood_spear');
 previouslyUsedSpear.setDynamicProperty('rpg:spear_hits',5);
 previouslyUsedSpear.durability.damage=5;
 previouslyUsedSpear.setLore(['§7남은 사용 횟수: 1/6']);
 inv.setItem(1,previouslyUsedSpear);
 signal('entityHitEntity').fire({damagingEntity:p,hitEntity:target});
 const upgradedSpear=inv.getItem(1);
 assert.equal(upgradedSpear.durability.damage,6);
 assert.equal(upgradedSpear.getDynamicProperty('rpg:spear_hits'),6);
 assert.match(upgradedSpear.getLore().at(-1),/4\/10$/);
 const fighter=setup('war_god','power');
 for(const [skill,key,previous] of [
  ['punch','damagePerHit',80],['slash','damagePerHit',20],['kick','damagePerHit',96],
  ['kick_flurry','damagePerHit',36],['eight_punch','damage',36],
 ]){
  const def=SKILLS['war_god_'+skill];
  near(stats.skillDamageFor(fighter.p,def[key],'physical'),stats.skillDamageFor(fighter.p,previous,'physical')*1.3);
 }
 near(stats.skillDamageFor(fighter.p,SKILLS.war_god_flurry.damage,'physical'),stats.skillDamageFor(fighter.p,8,'physical')*2);
 assert.equal(warGod.armBlackFlash(fighter.p),true);
 assert.equal(warGod.attack(fighter.p,jobs.war_god,SKILLS.war_god_punch),true);
 assert.equal(fighter.hits.length,1);
 near(fighter.hits[0],stats.skillDamageFor(fighter.p,80,'physical')*1.3*2);
 console.log('Blood magic and War God: skill and gear scaling, Blood Bind heal cap, ten mixed spear hits, saved spear wear after update, and Black Flash stacking passed');
}

{
 const social=mod('core/social.js'),recovery=mod('core/holyRecovery.js');
 const healer=player('cleric'),lower=player(),other=player(),outsider=player();
 for(const [label,fixture] of [['caster',healer],['lowest',lower],['higher',other],['outsider',outsider]]){
  fixture.p.id='holy-party-'+label;
  fixture.p.name=fixture.p.id;
 }
 const {p,inv}=healer;
 inv.setItem(0,new ItemStack(jobs.cleric.weapon));data.setSkills(p,jobs.cleric.skills);data.forceSetManaMax(p,250);
 lower.health.currentValue=16;other.health.currentValue=30;outsider.health.currentValue=2;
 const oldOnline=world.getAllPlayers,oldWrite=world.setDynamicProperty,oldShow=Form.prototype.show;
 const formChoices=(...selections)=>{Form.prototype.show=()=>Promise.resolve(selections.length?{selection:selections.shift()}:{canceled:true});};
 world.setDynamicProperty=()=>{};
 try{
  world.getAllPlayers=()=>[p,lower.p];
  formChoices(0);await social.openPartyMenu(p);
  for(const member of [lower.p,other.p]){
   world.getAllPlayers=()=>[p,lower.p,member];
   formChoices(1,0);await social.openPartyMenu(p);
   formChoices(0,1);await social.openInvites(member);
  }
  world.getAllPlayers=()=>[p,lower.p,other.p,outsider.p];
  p.addTag('rpg_guild_test-heal');outsider.p.addTag('rpg_guild_test-heal');
  assert.equal(social.partyMembership(p).members.length,3);
  for(const type of ['apprentice_cross','cleric_cross','angel_hands','michael_wings','fallen_angel_wings']){
   const item=JSON.parse(fs.readFileSync(path.join(itemDirectory,type+'.json')))['minecraft:item'];
   assert.ok('rpg:cast_item' in item.components);
  }
  componentHandlers.get('rpg:cast_item').onUse({source:p});
  timers.at(-1)();
  signal('itemUse').fire({source:p,itemStack:inv.getItem(0)});
  assert.equal(lower.health.currentValue,24);
  assert.equal(other.health.currentValue,30);
  assert.equal(outsider.health.currentValue,2);
  assert.equal(data.getMana(p),220);
  assert.equal(data.cooldownLeft(p,'holy_heal'),20);
  system.currentTick+=20;
  lower.health.currentValue=lower.health.effectiveMax;
  other.health.currentValue=other.health.effectiveMax;
  signal('itemUse').fire({source:p,itemStack:inv.getItem(0)});
  assert.equal(data.getMana(p),220);
  assert.equal(data.cooldownLeft(p,'holy_heal'),0);
  recovery.applyHolyRegeneration(p,lower.p,40,2);
  recovery.applyHolyRegeneration(p,lower.p,40,3,'orb:'+p.id);
  recovery.stopHolyRegeneration(lower.p,'orb:'+p.id);
  assert.equal(recovery.hasHolyRegeneration(lower.p),true);
  recovery.stopHolyRegeneration(lower.p,p.id);
  assert.equal(recovery.hasHolyRegeneration(lower.p),false);
 }finally{
  formChoices(4,1);await social.openPartyMenu(p);
  world.getAllPlayers=oldOnline;world.setDynamicProperty=oldWrite;Form.prototype.show=oldShow;
 }
}
{
 const {p,inv}=player('war_god');
 p.id='no-cooldown-flurry';
 p.getViewDirection=()=>({x:0,y:0,z:1});
 p.dimension.getBlock=()=>({isSolid:false});
 p.dimension.getEntities=()=>[];
 inv.setItem(0,new ItemStack(jobs.war_god.weapon));data.setSkills(p,jobs.war_god.skills);
 data.setIndex(p,jobs.war_god.skills.indexOf('war_god_flurry'));
 data.forceSetManaMax(p,1000);
 data.startCooldown(p,'war_god_flurry',200);
 for(const expected of [880,760]){
  system.currentTick+=3;
  componentHandlers.get('rpg:cast_item').onUse({source:p});
  timers.at(-1)();
  assert.equal(data.getMana(p),expected);
  assert.equal(data.cooldownLeft(p,'war_god_flurry'),0);
 }
 console.log('Actual inputs: party heal chooses a wounded recipient and skips mana/cooldown at full HP; orb regen key preserves other regen; old Flurry cooldown never blocks repeat casts');
}
{
 const defs=mod('data/chameleonMissions.js');
 const missions=mod('core/chameleonMissions.js'),missionWorld=mod('core/chameleonMissionWorld.js');
 const progress=mod('core/chameleonProgress.js'),chameleon=mod('core/chameleon.js');
 const ids=Object.keys(defs.CHAMELEON_MISSIONS);
 assert.equal(ids.length,10);
 const character=(id='mission-player')=>{const fixture=player('chameleon');fixture.p.id=id;fixture.p.setDynamicProperty('rpg:rpg_level',100);return fixture;};
 const select=(p,id)=>missions.ensureChameleonMission(p,()=>((ids.indexOf(id)+.5)/ids.length));
 const books=inv=>Array.from({length:inv.size},(_,i)=>inv.getItem(i)).filter(item=>item?.typeId===progress.SKILLBOOK_ID).reduce((sum,item)=>sum+item.amount,0);
 const {p,inv}=character();
 p.setDynamicProperty('rpg:rpg_level',99);
 assert.equal(select(p,'wither'),undefined);
 p.setDynamicProperty('rpg:rpg_level',100);
 const first=select(p,'wither');
 assert.equal(first.id,'wither');
 assert.equal(select(p,'hydra').id,'wither');
 for(let i=0;i<inv.size;i++)inv.setItem(i,new ItemStack('minecraft:stone',64));
 assert.equal(missions.advanceChameleonMission(p,'wither',first.serial,1,()=>0),true);
 const next=missions.activeChameleonMission(p);
 assert.equal(next.id,'dungeon');
 assert.equal(next.serial,2);
 assert.equal(progress.readChameleonProgress(p).pendingBooks,1);
 assert.equal(missions.advanceChameleonMission(p,'wither',first.serial),false);
 const recovered=character().p;
 for(const key of p.getDynamicPropertyIds())recovered.setDynamicProperty(key,p.getDynamicProperty(key));
 assert.deepEqual(missions.activeChameleonMission(recovered),next);
 inv.setItem(1,undefined);
 assert.equal(progress.deliverSkillBooks(p),1);
 assert.equal(books(inv),1);
 assert.equal(progress.readChameleonProgress(p).pendingBooks,0);
 for(const receipt of [{tier:8,solo:true},{tier:10,solo:true},{tier:9,solo:false},{tier:9,solo:true,startedAt:next.assignedAt-1}]){
  assert.equal(missions.creditChameleonDungeon(p,{startedAt:next.assignedAt,runId:88,...receipt}),false);
 }
 const solo={tier:9,solo:true,startedAt:next.assignedAt,runId:89};
 assert.equal(missions.creditChameleonDungeon(p,solo),true);
 assert.equal(missions.creditChameleonDungeon(p,solo),false);
 assert.equal(books(inv),2);
 const oldForm=Form.prototype.show,oldBody=Form.prototype.body;
 const forms=[];
 try{
  const answers=[{selection:chameleon.CHAMELEON_GROUPS.length+7},{selection:0},{canceled:true}];
  Form.prototype.body=function(text){forms.push(text);return this;};
  Form.prototype.show=()=>Promise.resolve(answers.shift());
  await chameleon.openChameleonSkillbook(p);
  assert.equal(answers.length,0);
  assert.ok(forms.some(text=>text.includes('진행 0/')&&text.includes('랜덤 스킬북 1권')));
 }finally{Form.prototype.show=oldForm;Form.prototype.body=oldBody;}

 missionWorld.registerChameleonMissions();
 const globals=new Map(),saved={getAllPlayers:world.getAllPlayers,getEntity:world.getEntity,
  getDynamicProperty:world.getDynamicProperty,setDynamicProperty:world.setDynamicProperty};
 world.getDynamicProperty=key=>globals.get(key);
 world.setDynamicProperty=(key,value)=>value===undefined?globals.delete(key):globals.set(key,value);
 world.getAllPlayers=()=>[];
 try{
  // Real death attribution, including the regular scripted kill callback route.
  mod('core/stats.js').registerRpgStats(undefined,missions.recordChameleonMissionKill);
  function death(p,typeId,extras={}){
   const deadEntity={id:'quest-test-'+typeId,typeId,location:{...p.location},dimension:p.dimension,hasTag:()=>false,...extras};
   signal('entityDie').fire({deadEntity,damageSource:{damagingEntity:p}});
  }
  for(const [id,type,goal]of [['wither','minecraft:wither',1],['guardian','minecraft:elder_guardian',3],['worm','rpg:elite_deathworm',5],['shulker','minecraft:shulker',12]]){
   const {p,inv}=character('kill-'+id);
   const m=select(p,id);
   assert.equal(m.count,0);
   if(id==='shulker'){
    death(p,type);
    assert.equal(missions.activeChameleonMission(p).count,0);
    p.location={x:1200,y:70,z:1200};
    p.dimension={id:'minecraft:the_end',getBlock:()=>({typeId:'minecraft:purpur_block'})};
   }
   death(p,type,{hasTag:tag=>tag==='rpg_town_manual_spawn'});
   assert.equal(missions.activeChameleonMission(p).count,0);
   for(let i=0;i<goal;i++)death(p,type);
   assert.equal(books(inv),1,id);
   assert.notEqual(missions.activeChameleonMission(p).id,id);
  }

  {
   const {p,inv}=character('raid');
   select(p,'raid');
   const effect={entity:p,effect:{typeId:'minecraft:village_hero'}};
   signal('effectAdd').fire(effect);
   assert.equal(books(inv),0);
   death(p,'minecraft:pillager');
   signal('effectAdd').fire(effect);
   signal('effectAdd').fire(effect);
   assert.equal(books(inv),1);
  }

  const ore=({p,type='minecraft:diamond_ore',x=-18,amount=1,fortune=0,silk=0,tool='minecraft:diamond_pickaxe',placed=false,dropFirst=false})=>{
   const location={x,y:32,z:15},block={typeId:type,location,dimension:p.dimension};
   const itemStackBeforeBreak={typeId:tool,getComponent:()=>({getEnchantment:id=>({level:id==='fortune'?fortune:silk})})};
   const drop={typeId:'minecraft:item',dimension:p.dimension,location:{x:x+.5,y:32.5,z:15.5},
    getComponent:()=>({itemStack:new ItemStack('minecraft:diamond',amount)})};
   if(placed)signal('playerPlaceBlock').fire({block,player:p});
   if(amount&&dropFirst)signal('entitySpawn').fire({entity:drop});
   signal('playerBreakBlock').fire({block,player:p,brokenBlockPermutation:{type:{id:type}},itemStackBeforeBreak});
   if(amount&&!dropFirst)signal('entitySpawn').fire({entity:drop});
   system.currentTick+=3;
   missionWorld.flushMissionDiamonds();
  };
  {
   const {p,inv}=character('diamond');
   select(p,'diamond');
   ore({p,placed:true});
   ore({p,silk:1});
   ore({p,tool:'minecraft:wooden_pickaxe'});
   assert.equal(missions.activeChameleonMission(p).count,0);
   for(let n=0;n<16;n++){
    ore({p,type:'minecraft:deepslate_diamond_ore',amount:4,fortune:3,dropFirst:n%2===0,x:-18+n});
    if(n<15)assert.equal(missions.activeChameleonMission(p).count,4*(n+1));
   }
   assert.equal(books(inv),1);
  }
  {
   const {p,inv}=character('debris');
   select(p,'debris');
   ore({p,type:'minecraft:ancient_debris',tool:'minecraft:iron_pickaxe',amount:0});
   ore({p,type:'minecraft:ancient_debris',amount:0,placed:true});
   assert.equal(missions.activeChameleonMission(p).count,0);
   for(let n=0;n<16;n++)ore({p,type:'minecraft:ancient_debris',amount:0,x:-18+n});
   assert.equal(books(inv),1);
  }
  {
   const {p,inv}=character('dragon');
   select(p,'dragon');
   const crystals=[[-3,0],[0,-3],[0,3],[3,0]].map(([x,z])=>({location:{x:x+.5,y:70,z:z+.5}}));
   p.dimension={id:'minecraft:the_end',getEntities:({type})=>type==='minecraft:ender_crystal'?crystals:[]};
   const dragon={typeId:'minecraft:ender_dragon',dimension:p.dimension,location:{x:0,y:90,z:0}};
   signal('entitySpawn').fire({entity:dragon});
   assert.equal(books(inv),0);
   signal('playerInteractWithBlock').fire({player:p,beforeItemStack:new ItemStack('minecraft:end_crystal'),
    block:{typeId:'minecraft:bedrock',dimension:p.dimension,location:{x:3,y:69,z:0}}});
   signal('entitySpawn').fire({entity:dragon});
   missionWorld.tickMissionWorld();
   assert.equal(books(inv),0); // Receipt stays stored while the player is disconnected.
   world.getAllPlayers=()=>[p];
   missionWorld.tickMissionWorld();
   missionWorld.tickMissionWorld();
   assert.equal(books(inv),1);
   world.getAllPlayers=()=>[];
  }
  {
   const {p,inv}=character('hydra');
   const m=select(p,'hydra');
   assert.ok([-500,499].every((bound,i)=>i===0?m.target.x>=bound&&m.target.z>=bound:m.target.x<=bound&&m.target.z<=bound));
   p.location={x:m.target.x,y:65,z:m.target.z};
   p.dimension.getEntities=()=>[];
   p.dimension.heightRange={max:320};
   const spawned=[],effects=[],property=new Map(),tags=new Set(),hp={currentValue:11469};
   p.dimension.spawnEntity=(typeId,location)=>{
    const boss={typeId,id:'mission-hydra',isValid:true,dimension:p.dimension,location,nameTag:'',
     setDynamicProperty:(key,value)=>property.set(key,value),getDynamicProperty:key=>property.get(key),
     addTag:tag=>tags.add(tag),hasTag:tag=>tags.has(tag),triggerEvent:event=>effects.push(event),
     getComponent:id=>id==='minecraft:health'?hp:undefined,remove(){this.isValid=false;}};
    spawned.push(boss);return boss;
   };
   world.getEntity=id=>spawned.find(e=>e.id===id);
   world.getAllPlayers=()=>[p];
   missions.tickChameleonMissions();
   missions.tickChameleonMissions();
   assert.equal(spawned.length,1);
   const boss=spawned[0];
   assert.equal(boss.typeId,defs.MISSION_HYDRA);
   assert.equal(property.get('rpg:monster_level'),200);
   assert.ok(effects.includes('rpg:level_200'));
   assert.equal(boss.location.x,m.target.x+.5);
   death(p,boss.typeId);
   assert.equal(books(inv),0);
   death(p,boss.typeId,boss);
   assert.equal(books(inv),1);
  }
 }finally{Object.assign(world,saved);}
 console.log('Chameleon missions: all ten objectives, level gate, repeat rotation, saved progression, full bag, solo dungeon receipts, native kill/raid/dragon/break events, Fortune, placed ore and Lv.200 Hydra tested');
}
{
 const {p:attacker,inv}=player('war_god'),{p:victim,health}=player('mage');
 attacker.id='pvp-balance-attacker';attacker.name='PvP Attacker';victim.id='pvp-balance-victim';victim.name='PvP Victim';
 const stats=mod('core/stats.js'),runes=mod('core/runeInventory.js'),gear=mod('core/gearState.js');
 const combat=mod('core/combatContext.js'),pvp=mod('core/pvp.js'),util=mod('core/util.js');
 const melee=mod('core/commonWeaponDamage.js'),runeMelee=mod('core/runeMelee.js');
 const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
 const weapon=gear.setGearLevel(new ItemStack(jobs.war_god.weapon),'weapon',6);
 inv.setItem(0,weapon);
 attacker.setDynamicProperty('rpg:stat_values',JSON.stringify({str:40,vit:5,mag:5,int:5}));
 const bag=runes.readRuneBag(attacker),rune=runes.addRuneRecord(bag,'power',10,1);
 bag.equipped[0]=rune.uid;
 runes.writeRuneBag(attacker,bag);
 const base=stats.skillDamageFor(attacker,80,'physical');
 assert.ok(base>100);
 // A native hit rejected by temporary immunity must still use the complete raw
 // attack for its fallback, even when the old attack would have been lethal.
 health.currentValue=100;
 victim.applyDamage=()=>false;
 assert.equal(util.hurt(victim,attacker,80,'physical',{ignoreInvulnerability:true}),true);
 close(100-health.currentValue,base*.08);
 assert.equal(combat.scriptKiller(victim),undefined);
 // Engine-delivered damage is already scaled in the player sensor. Its gear
 // bonus scales that hit once, using the same real weapon and rune data.
 const nativeRaw=50,nativeScaled=nativeRaw*.08;
 health.currentValue=100-nativeScaled;
 const hit={damage:nativeScaled,hurtEntity:victim,damageSource:{cause:'entityAttack',damagingEntity:attacker}};
 const expected=nativeRaw*melee.commonWeaponFactor(weapon)*(1+runeMelee.runeMeleeBonus(attacker))*.08;
 close(melee.applyCommonWeaponBonus(hit),expected);
 close(100-health.currentValue,expected);
 const arrow={id:'pvp-balance-arrow',typeId:'minecraft:arrow',getComponent:key=>key==='minecraft:projectile'?{owner:attacker}:undefined};
 close(pvp.pvpDamageMultiplier(arrow,victim),.08);
 close(pvp.pvpDamageMultiplier(victim,attacker),.08);
 close(pvp.pvpDamageMultiplier(arrow,attacker),1);
 health.currentValue=100;
 combat.setCombatHealth(victim,arrow,health,50);
 close(health.currentValue,96);
 const skeleton={typeId:'minecraft:skeleton',id:'pvp-test-skeleton'};
 combat.setCombatHealth(victim,skeleton,health,86);
 close(health.currentValue,86);
 combat.setCombatHealth(victim,undefined,health,76);
 close(health.currentValue,76);

 const {p:revenant}=player('revenant');revenant.id='pvp-execution';revenant.name='PvP Revenant';
 const skills=mod('data/skills.js').SKILLS,def=skills.revenant_execution;
 revenant.getViewDirection=()=>({x:0,y:0,z:1});
 victim.location={x:0,y:64,z:2};
 victim.dimension=revenant.dimension;
 revenant.dimension.getEntities=()=>[victim];
 revenant.dimension.spawnParticle=()=>{};
 victim.kill=()=>assert.fail('Player execution bypassed the damage reduction');
 health.currentValue=18;
 victim.applyDamage=amount=>{health.setCurrentValue(health.currentValue-amount*.08);return true;};
 const result=mod('skills/harpoon.js').RUNNERS.revenant_execution(revenant,jobs.revenant,def);
 assert.equal(result.cooldown,def.cooldown);
 close(18-health.currentValue,stats.skillDamageFor(revenant,def.failDamage,'physical')*.08);
 console.log('PvP balance: actual STR40/rare Power +10/War God weapon +6, no defensive gear or Strength; fallback, native gear bonus, projectile ownership, environmental damage, PK credit and player execute passed');
}
