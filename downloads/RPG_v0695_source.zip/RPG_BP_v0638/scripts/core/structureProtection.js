import {world,BlockTypes} from '@minecraft/server';
const providers=new Map(),subscribed=new Set();
const offsets={up:{x:0,y:1,z:0},down:{x:0,y:-1,z:0},north:{x:0,y:0,z:-1},south:{x:0,y:0,z:1},east:{x:1,y:0,z:0},west:{x:-1,y:0,z:0}};
export function structureProtected(block,player,operation){
 if(!block?.location||!block.dimension?.id)return false;
 for(const fn of providers.values())if(fn(block,player,operation))return true;return false;
}
function neighbor(block,face){const d=offsets[String(face).toLowerCase()];return d?{dimension:block.dimension,location:{x:block.location.x+d.x,y:block.location.y+d.y,z:block.location.z+d.z}}:undefined;}
export function structureChangingItem(item){
 const id=item?.typeId;if(!id)return false;
 if(id.endsWith('_spawn_egg')||id==='rpg:land_deed'||id==='rpg:land_seizure')return false;
 if(id.endsWith('bucket')||['minecraft:flint_and_steel','minecraft:fire_charge','minecraft:bone_meal','minecraft:shears'].includes(id)||/_(axe|shovel|hoe)$/.test(id))return true;
 try{return Boolean(BlockTypes.get(id));}catch{return true;}
}
export function protectStructureInteraction(ev){
 if(!ev.block||!structureChangingItem(ev.itemStack))return;
 let placing=false;try{placing=!!BlockTypes.get(ev.itemStack?.typeId);}catch{}
 if(structureProtected(ev.block,ev.player,placing?'support':'interact')||structureProtected(neighbor(ev.block,ev.blockFace),ev.player,'place'))ev.cancel=true;
 // Only inspect the inferred facing line, rather than all six axes.
 if(!ev.cancel&&['minecraft:piston','minecraft:sticky_piston'].includes(ev.itemStack?.typeId)){
  const base=neighbor(ev.block,ev.blockFace);if(!base){ev.cancel=true;return;}
  const look=ev.player?.getViewDirection?.();if(!look){ev.cancel=true;return;}
  const eye=ev.player.getHeadLocation?.()??ev.player.location;
  let direction;
  if(Math.abs(ev.player.location.x-base.location.x)<2&&Math.abs(ev.player.location.z-base.location.z)<2&&eye.y>base.location.y+2)direction=offsets.up;
  else if(Math.abs(ev.player.location.x-base.location.x)<2&&Math.abs(ev.player.location.z-base.location.z)<2&&eye.y<base.location.y)direction=offsets.down;
  else direction=Math.abs(look.x)>Math.abs(look.z)?{x:look.x>0?-1:1,y:0,z:0}:{x:0,y:0,z:look.z>0?-1:1};
  const sticky=ev.itemStack.typeId==='minecraft:sticky_piston';
  for(let n=1;n<=13;n++){
   const location={x:base.location.x+direction.x*n,y:base.location.y+direction.y*n,z:base.location.z+direction.z*n};
   let block;try{block=ev.block.dimension.getBlock(location);}catch{ev.cancel=true;return;}
   // Always validate head space and the sticky pull position. Stop after air.
   if(structureProtected({dimension:ev.block.dimension,location},ev.player,'piston')){ev.cancel=true;return;}
   if(block?.isAir||block?.typeId==='minecraft:air'){if(!sticky||n>=2)break;}
  }
 }

}
function subscribe(name,fn){const event=world.beforeEvents?.[name];if(!event?.subscribe||subscribed.has(name))return;event.subscribe(fn);subscribed.add(name);}
export function registerStructureProtection(id,protect){
 providers.set(id,protect);
 subscribe('playerBreakBlock',ev=>{if(structureProtected(ev.block,ev.player,'break'))ev.cancel=true;});
 // Some newer engines expose this; interaction protection also works on stable 2.2.
 subscribe('playerPlaceBlock',ev=>{if(structureProtected(ev.block,ev.player,'place'))ev.cancel=true;});
 subscribe('playerInteractWithBlock',protectStructureInteraction);
 subscribe('explosion',ev=>{
  try{const all=ev.getImpactedBlocks(),allowed=all.filter(b=>!structureProtected(b));if(allowed.length!==all.length)ev.setImpactedBlocks(allowed);}catch{ev.cancel=true;}
 });
}
