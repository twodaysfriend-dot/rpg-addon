import {currentScriptHit} from '../core/combatContext.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import {teleportForSkill} from '../core/dungeonMovement.js';
import { hasBorrowedSkill,isChameleonWeapon } from "../core/skillAccess.js";
import { world, system, EntityDamageCause } from '@minecraft/server';
import { CONFIG } from '../config.js';
import { grantPiercing, hasPiercing, clearPiercing } from '../core/piercing.js';
import { getJobId, getSkills } from '../core/playerData.js';
import { getTargets, hurt, flatDir, norm3, particle, sound, heldItemId, healthAlive } from '../core/util.js';
import { areAllies } from '../core/social.js';
import { notify } from '../core/hud.js';

// 하늘이 열려 있는 오버월드에서만 빛이 들어온다. 밤/동굴에서는 저장 에너지 사용.
const MAX_LIGHT=500, CHARGE=4;
const KEY_SUN='rpg:sun_light', KEY_MOON='rpg:moon_light';
const SUN='rpg:rpg_sun_spark', MOON='rpg:rpg_moon_spark';
const SUN_PROJECTILE='rpg:sun_projectile', MOON_PROJECTILE='rpg:moon_projectile';
const RADIANT_GLOW='rpg:radiant_glow', RADIANT_CORE='rpg:radiant_core';
const RADIANT_ARC='rpg:radiant_arc', RADIANT_CHARGE='rpg:radiant_charge';
const slashBuff=new Map(); // 공격자 id -> {until}
const blessings=new Map(); // 피격 보호자 id -> {until, reflected}
const satBuffs=new Map();
const sunImmunity=new Map(); // player id -> {until, player}
const moonSplitUntil=new Map(); // player id -> expires on this tick
const lastActualMelee=new Map(); // attacker:target -> last tick vanilla hit actually dealt damage
// Bedrock standard harmful potion/status effects. Do not remove positive buffs.
const NEGATIVE_EFFECTS=new Set([
 'slowness','mining_fatigue','weakness','blindness','nausea',
 'poison','fatal_poison','wither','hunger','levitation','darkness',
 'bad_omen','raid_omen','trial_omen','infested','oozing','weaving'
]);
function harmful(effectId){
  return NEGATIVE_EFFECTS.has(String(effectId??'').replace(/^minecraft:/,'').toLowerCase());
}
function removeDebuffs(p){
  try{
    for(const e of p.getEffects()) if(harmful(e.typeId)){
      try{p.removeEffect(e.typeId);}catch{}
    }
  }catch{
    for(const id of NEGATIVE_EFFECTS){
      try{if(p.getEffect(id))p.removeEffect(id);}catch{}
    }
  }
}
function isSunImmune(p){
  const s=sunImmunity.get(p?.id);
  if(!s)return false;
  if(system.currentTick>=s.until){sunImmunity.delete(p.id);return false;}
  return true;
}
function additionalMoonDamage(target,p,amount,type='fixed'){
  if(!enemy(p,target)||(!CONFIG.pvp&&target.typeId==='minecraft:player'))return false;
  return hurt(target,p,amount,type,{ignoreInvulnerability:true});
}

const valid=(e)=>{try{return !!e?.isValid && healthAlive(e);}catch{return false;}};
const enemy=(p,e)=>valid(e)&&e.id!==p.id&&!areAllies(p,e);
function energy(p,sun){
 try{return Math.min(MAX_LIGHT,Math.max(0,Number(p.getDynamicProperty(sun?KEY_SUN:KEY_MOON))||0));}catch{return 0;}
}
function saveEnergy(p,sun,v){try{p.setDynamicProperty(sun?KEY_SUN:KEY_MOON,Math.max(0,Math.min(MAX_LIGHT,v)));}catch{}}
function day(){try{const t=world.getTimeOfDay();return t>=0&&t<12000;}catch{return false;}}
function openSky(p){
 try{
  if(p.dimension.id!=='minecraft:overworld')return false;
  const q=p.location, x=Math.floor(q.x),z=Math.floor(q.z);
  // 지붕·동굴을 포함하여 머리 위를 검사. 새 엔진 높이 상한 320.
  for(let y=Math.floor(q.y)+2;y<320;y++){
   const b=p.dimension.getBlock({x,y,z});
   if(!b)return false;
   if(!b.isAir && !['minecraft:air','minecraft:cave_air'].includes(b.typeId))return false;
  }
  return true;
 }catch{return false;}
}
function ambient(p,sun){return p.dimension.id==='minecraft:overworld'&&day()===sun&&openSky(p);}
function charge(p,sun,def){
 if(!ambient(p,sun)){notify(p,sun?'§c지상에서 햇빛을 받을 때만 충전할 수 있습니다.':'§c지상에서 달빛을 받을 때만 충전할 수 있습니다.');return false;}
 const value=energy(p,sun);saveEnergy(p,sun,value+def.restore);
 notify(p,`§e빛 에너지 ${energy(p,sun)} / ${MAX_LIGHT}`);
 particle(p.dimension,sun?SUN:MOON,{...p.location,y:p.location.y+1.4});return true;
}
function ready(p,sun,cost=10){
 if(ambient(p,sun))return true;
 if(energy(p,sun)<cost){notify(p,`§c빛 에너지가 부족합니다. (${energy(p,sun)}/${cost})`);return false;}
 saveEnergy(p,sun,energy(p,sun)-cost);return true;
}
function apply(p,name,ticks,amp){try{applyStatus(p,name,ticks,{amplifier:amp,showParticles:false});}catch{}}
function ring(dim,at,r,color,count=16){
 for(let i=0;i<count;i++){
  const a=i*Math.PI*2/count;
  particle(dim,color,{x:at.x+Math.cos(a)*r,y:at.y+.65,z:at.z+Math.sin(a)*r});
 }
}
function sunCharge(p,j,d){return charge(p,true,d);}
function moonCharge(p,j,d){return charge(p,false,d);}

// 달빛: 현재 최대 HP의 50%를 회복하고 가진 달빛의 정확히 30%를 소비.
// 마나는 스킬 공통 시스템이 250에서 지능 효율을 적용해 차감한다.
function moonMoonlight(p,j,d){
  let hp;
  try { hp=p.getComponent('minecraft:health'); } catch {}
  if(!hp)return false;
  const max=Number(hp.effectiveMax ?? hp.defaultValue ?? 20);
  if(!Number.isFinite(max)||max<=0)return false;
  const current=Math.max(0,Number(hp.currentValue)||0);
  if(current>=max){notify(p,'§7체력이 이미 가득 찼습니다.');return false;}
  // 다른 달빛 스킬과 다르게 고정 차감 없이 보유량에 비례해서 소모한다.
  const previous=energy(p,false);
  if(!ambient(p,false)&&previous<=0){notify(p,'§c낮이나 동굴에서는 저장된 달빛이 필요합니다.');return false;}
  const restore=Math.min(max-current,max*d.healRatio);
  try {hp.setCurrentValue(Math.min(max,current+restore));}catch{return false;}
  saveEnergy(p,false,previous*(1-d.lightRatio));
  ring(p.dimension,p.location,1.35,MOON,12);
  sound(p.dimension,'random.orb',p.location,{volume:.8,pitch:1.4});
  notify(p,`§b달빛: §f체력 +${restore.toFixed(1)} / 달빛 -${(previous*d.lightRatio).toFixed(1)} (${energy(p,false).toFixed(1)}/${MAX_LIGHT})`);
  return true;
}

// 삼지창처럼 직접 던지는 달의 차크람. 스킬 '월광 차크람'과 별개이며
// 자체 피해(물리 11)·이동·귀환을 가지므로 마나/스킬 쿨타임이 들지 않는다.
const moonThrowTick=new Map();
// Three separate miniature discs travel alongside the main thrown chakram.
// The three entities are display-only; each disc has its own hit detection.
function launchMiniChakrams(player, direction, count, damage){
  const dim=player.dimension, eye=player.getHeadLocation();
  const horizontal=Math.hypot(direction.x,direction.z)||1;
  const side={x:-direction.z/horizontal,z:direction.x/horizontal};
  const offsets=[-0.55,0,0.55];
  for(let i=0;i<count;i++){
    const lateral=offsets[i]??((i-(count-1)/2)*0.55);
    system.runTimeout(()=>{
      try{
        if(!player.isValid||dim.id!==player.dimension.id)return;
        const head=player.getHeadLocation();
        let pos={x:head.x+direction.x*0.9+side.x*lateral,
          y:head.y+direction.y*0.9+(i===1?0.18:-0.06),
          z:head.z+direction.z*0.9+side.z*lateral};
        let model;
        try{model=dim.spawnEntity('rpg:moon_small_chakram',pos);model.addTag('rpg_visual_only');}catch{}
        let ticks=0;
        const task=system.runInterval(()=>{
          const finish=()=>{try{system.clearRun(task);}catch{}try{if(model?.isValid)model.remove();}catch{}};
          try{
            if(!player.isValid||player.dimension.id!==dim.id||++ticks>19){finish();return;}
            // Three side-by-side projectiles. Each inflicts exactly one hit.
            for(let sub=0;sub<2;sub++){
              const step=0.83;
              pos={x:pos.x+direction.x*step,y:pos.y+direction.y*step,z:pos.z+direction.z*step};
              const b=dim.getBlock(pos);
              if(b&&!b.isAir){finish();return;}
              for(const e of getTargets(player,pos,1.22,0.9)){
                if(!enemy(player,e)||Math.abs(e.location.y+0.9-pos.y)>1.45)continue;
                if(additionalMoonDamage(e,player,damage,'physical')){
                  particle(dim,MOON,{x:e.location.x,y:e.location.y+1,z:e.location.z});
                  finish();return;
                }
              }
            }
            if(model?.isValid) model.teleport(pos,{dimension:dim,keepVelocity:false});
            particle(dim,MOON_PROJECTILE,pos);
          }catch{finish();}
        },1);
      }catch{}
    },i*2);
  }
}
// Repeated use during the borrowed split buff throws without paying a second skill charge.
export function tryBorrowedMoonThrow(p){
 if(!hasBorrowedSkill(p,'moon_chakram_split') || (moonSplitUntil.get(p.id)??0)<=system.currentTick)return false;
 throwMoonWeapon(p);return true;
}
export function throwMoonWeapon(p){
  try{
    const borrowed=hasBorrowedSkill(p,'moon_chakram_split') && isChameleonWeapon(heldItemId(p)) && (moonSplitUntil.get(p.id)??0)>system.currentTick;
    if(p?.typeId!=='minecraft:player'||!(getJobId(p)==='moon_heir' && heldItemId(p)==='rpg:moon_heir_blade' || borrowed))return false;
    const now=system.currentTick;
    if(now-(moonThrowTick.get(p.id)??-100)<15)return false;
    moonThrowTick.set(p.id,now);
    const dim=p.dimension, direction=p.getViewDirection(), head=p.getHeadLocation();
    const length=Math.hypot(direction.x,direction.y,direction.z)||1;
    const dir={x:direction.x/length,y:direction.y/length,z:direction.z/length};
    let pos={x:head.x+dir.x*.9,y:head.y+dir.y*.9,z:head.z+dir.z*.9};
    let visual;
    try {visual=dim.spawnEntity('rpg:moon_weapon_chakram',pos);visual.addTag('rpg_visual_only');}catch{}
    sound(dim,'random.bow',p.location,{volume:.65,pitch:1.2});
    // When split buff is active, the main throw always releases 3 small discs.
    if((moonSplitUntil.get(p.id)??0)>now){
      launchMiniChakrams(p,dir,3,4);
    }
    let ticks=0,returning=false,hit=false;
    const stop=()=>{try{system.clearRun(task);}catch{}try{if(visual?.isValid)visual.remove();}catch{}};
    const task=system.runInterval(()=>{
      try{
        if(!p.isValid||p.dimension.id!==dim.id||ticks++>65){stop();return;}
        if(!returning){
          const step=1.65;
          pos={x:pos.x+dir.x*step,y:pos.y+dir.y*step,z:pos.z+dir.z*step};
          // 벽이나 지형과 부딪히면 바로 귀환한다.
          try {const b=dim.getBlock(pos);if(b&&!b.isAir)returning=true;}catch{}
          if(!returning){
            // 명중한 적 하나에게만 11의 물리 기본 피해. 길드/파티 아군 제외.
            for(const target of getTargets(p,pos,1.75,0.9)){
              if(!enemy(p,target)||Math.abs(target.location.y+0.9-pos.y)>1.6)continue;
              if(hurt(target,p,11,'physical')){hit=true;returning=true;break;}
            }
          }
          if(ticks>=18)returning=true;
        }else{
          const q=p.getHeadLocation();const dx=q.x-pos.x,dy=q.y-pos.y,dz=q.z-pos.z;
          const dist=Math.hypot(dx,dy,dz);
          if(dist<1.2){stop();return;}
          const step=Math.min(2.1,dist);
          pos={x:pos.x+dx/dist*step,y:pos.y+dy/dist*step,z:pos.z+dz/dist*step};
        }
        if(visual?.isValid)visual.teleport(pos,{dimension:dim,keepVelocity:false});
        particle(dim,MOON_PROJECTILE,pos);
        if(ticks%4===0)particle(dim,MOON,pos);
      }catch{stop();}
    },1);
    return true;
  }catch{return false;}
}
function sunSlash(p,j,d){
 if(!ready(p,true))return false;
 slashBuff.set(p.id,{until:system.currentTick+140,multiplier:d.damageMultiplier,slowAmp:d.slowAmp,slowTicks:d.slowTicks});
 ring(p.dimension,p.location,1.1,SUN,12);
 notify(p,'§6일륜참 준비: §f다음 도끼 타격 4배, 둔화 III 1초');return true;
}
function sunBless(p,j,d){
 if(!ready(p,true,15))return false;
 apply(p,'resistance',d.duration,1); // 저항 II
 apply(p,'absorption',d.duration,3); // 흡수 IV
 blessings.set(p.id,{until:system.currentTick+d.duration,reflected:false});
 ring(p.dimension,p.location,1.1,SUN,16);
 notify(p,'§6해의 가호: §f저항 II·흡수 IV 20초 / 첫 공격 100% 반사');return true;
}
function sunDivineBlessing(p,j,d){
 if(!ready(p,true,20))return false;
 removeDebuffs(p);
 sunImmunity.set(p.id,{player:p,until:system.currentTick+d.immunityTicks});
 grantPiercing(p,d.pierceTicks);
 ring(p.dimension,p.location,2.0,SUN,24);
 sound(p.dimension,'random.levelup',p.location,{volume:0.75,pitch:1.35});
 notify(p,'§6해의 축복: §f디버프 제거·3분 면역, 3초간 연속 타격의 무적시간 무시');
 return true;
}
function sunMeteor(p,j,d){
 const start={...p.location},f=flatDir(p);
 let targets=getTargets(p,start,d.range).filter(e=>enemy(p,e)).map(e=>({e,forward:(e.location.x-start.x)*f.x+(e.location.z-start.z)*f.z})).filter(x=>x.forward>0&&Math.hypot((x.e.location.x-start.x)-f.x*x.forward,(x.e.location.z-start.z)-f.z*x.forward)<4);
 targets.sort((a,b)=>a.forward-b.forward);
 if(!targets.length){notify(p,'§c전방에 메테오드라이브 대상이 없습니다.');return false;}
 if(!ready(p,true,15))return false;
 const target=targets[0].e,dim=p.dimension;
 // 해의 광선이 목표를 향해 나아간 뒤 시전자가 같은 Y높이로 돌진.
 for(let n=1;n<=16;n++){
  const t=n/16;
  particle(dim,SUN,{x:start.x+(target.location.x-start.x)*t,y:start.y+1.1+(target.location.y-start.y)*t,z:start.z+(target.location.z-start.z)*t});
 }
 if(enemy(p,target))hurt(target,p,d.beamDamage,'magic');
 system.runTimeout(()=>{
  try{
   if(!p.isValid||!enemy(p,target)||p.dimension.id!==dim.id)return;
   const q=target.location,dx=q.x-p.location.x,dz=q.z-p.location.z,len=Math.hypot(dx,dz)||1;
   teleportForSkill(p,{x:q.x-dx/len*1.5,y:start.y,z:q.z-dz/len*1.5},{dimension:dim,keepVelocity:false});
   hurt(target,p,d.impactDamage,'physical');ring(dim,target.location,1.3,SUN,12);
  }catch{}
 },5);
 return true;
}
// 방사열선 v0.4.81: 레퍼런스의 백색 중심/분홍·보라 외광과 회전하는 에너지 실선.
// 가벼운 점 파티클을 반복 배치하여 0.28 블록 이내의 광선 폭을 유지한다.
function radiantCharge(dim, p, face, tick){
 const o=p.location, cx=o.x+face.x*.92, cy=o.y+1.25+face.y*.92, cz=o.z+face.z*.92;
 const t=tick*.43;
 particle(dim,RADIANT_CHARGE,{x:cx,y:cy,z:cz});
 // 충전 중 빛줄기가 작은 반경으로 회전한다 (큰 입자/폭발 사용 안 함).
 for(let i=0;i<3;i++){
  const a=t+i*Math.PI*2/3, radius=.11+tick*.0035;
  particle(dim,RADIANT_ARC,{
   x:cx-face.z*Math.cos(a)*radius,
   y:cy+Math.sin(a)*radius,
   z:cz+face.x*Math.cos(a)*radius
  });
 }
}
function radiantLaser(dim, origin, face, range, active){
 const horizontal=Math.hypot(face.x,face.z);
 const side=horizontal>.0001?{x:-face.z/horizontal,y:0,z:face.x/horizontal}:{x:1,y:0,z:0};
 const up={x:side.y*face.z-side.z*face.y,y:side.z*face.x-side.x*face.z,z:side.x*face.y-side.y*face.x};
 const height=origin.y+1.25;
 // 0.17 간격의 백색 중심과 0.28 너비 분홍/보라 빛을 함께 깐다.
 // 모든 광선 파티클의 크기는 0.28 이하이며 3틱마다 새로 갱신한다.
 let n=0;
 for(let t=.76;t<=range;t+=.17){
  const at={x:origin.x+face.x*t,y:height+face.y*t,z:origin.z+face.z*t};
  particle(dim,RADIANT_CORE,at);
  if((n++ & 1)===0)particle(dim,RADIANT_GLOW,at);
 }
 // 핵심 광선 바깥에 옅은 보라색 전기가 두 가닥으로 나선형을 그린다.
 for(let t=1;t<=range;t+=.72){
  const angle=t*2.3+active*.27;
  const radius=.13+.04*Math.sin(t*1.7+active*.12);
  const lateral=Math.sin(angle)*radius;
  const upOffset=Math.cos(angle)*radius;
  particle(dim,RADIANT_ARC,{
   x:origin.x+face.x*t+side.x*lateral+up.x*upOffset,
   y:height+face.y*t+up.y*upOffset,
   z:origin.z+face.z*t+side.z*lateral+up.z*upOffset
  });
  // 다른 위상에서 짧게 반짝이는 두 번째 전기줄기
  if(Math.floor(t*1.35+active*.14)%3!==0)continue;
  particle(dim,RADIANT_ARC,{
   x:origin.x+face.x*t-side.x*lateral-up.x*upOffset,
   y:height+face.y*t-up.y*upOffset,
   z:origin.z+face.z*t-side.z*lateral-up.z*upOffset
  });
 }
 // 광선 끝과 발사 지점의 작은 빛. 최대 0.28 블록.
 particle(dim,RADIANT_CHARGE,{x:origin.x+face.x*.75,y:height+face.y*.75,z:origin.z+face.z*.75});
 particle(dim,RADIANT_CHARGE,{x:origin.x+face.x*range,y:height+face.y*range,z:origin.z+face.z*range});
}
function sunBeam(p,j,d){
 if(!ready(p,true,20))return false;
 const dim=p.dimension;let tick=0;
 notify(p,'§d방사열선: §f광선 충전 중...');
 const task=system.runInterval(()=>{
  try{
   if(!p.isValid||!healthAlive(p)||p.dimension.id!==dim.id){system.clearRun(task);return;}
   tick++;const face=norm3(p.getViewDirection());
   if(tick<=d.chargeTicks){
    if(tick%2===0)radiantCharge(dim,p,face,tick);
    return;
   }
   const active=tick-d.chargeTicks;
   if(active>d.duration){system.clearRun(task);return;}
   const origin=p.location;
   // 반복하는 작은 파티클이 한 줄로 겹쳐져 지속형 레이저를 표현.
   if(active===1||active%3===0)radiantLaser(dim,origin,face,d.range,active);
   // 매 틱 타격: 피격 무적 시간을 우회하고 방어·스탯 보정은 공통 피해 경로로 유지.
   if(Math.floor(active*d.pulsesPerSecond/20)===Math.floor((active-1)*d.pulsesPerSecond/20))return;
   for(const e of getTargets(p,origin,d.range+1).filter(e=>enemy(p,e))){
    const q=e.location,dx=q.x-origin.x,dy=q.y+.9-(origin.y+1.25),dz=q.z-origin.z,forward=dx*face.x+dy*face.y+dz*face.z;
    if(forward<0||forward>d.range)continue;
    if(Math.hypot(dx-face.x*forward,dy-face.y*forward,dz-face.z*forward)>1.45)continue;
    hurt(e,p,d.damagePerPulse,'magic',{ignoreInvulnerability:true});
    try{e.setOnFire(2,true);}catch{}
    apply(e,'weakness',40,1);
   }
  }catch{system.clearRun(task);}
 },1);
 sound(dim,'mob.blaze.shoot',p.location,{volume:.7,pitch:.8});return true;
}
function sunDescent(p,j,d){
 if(!ready(p,true,25))return false;
 for(const e of getTargets(p,p.location,d.radius))if(enemy(p,e))hurt(e,p,d.damage,'magic');
 apply(p,'strength',d.buffTicks,2); // 힘 III
 apply(p,'regeneration',d.buffTicks,1); // 재생 II
 apply(p,'absorption',d.buffTicks,9); // 흡수 X
 satBuffs.set(p.id,system.currentTick+d.buffTicks); // 포화 15초간 주기적 발동
 apply(p,'saturation',20,0);
 ring(p.dimension,p.location,d.radius,SUN,28);
 notify(p,'§6일륜강림! §f12블럭 범위 피해 20 / 힘 III·재생 II·포화·흡수 X (15초)');return true;
}
function moonSlash(p,j,d){
 if(!ready(p,false))return false;
 const f=flatDir(p),pos=p.location;
 for(const e of getTargets(p,pos,d.range+1)){
  const dx=e.location.x-pos.x,dz=e.location.z-pos.z,len=Math.hypot(dx,dz);
  if(len<=d.range&&len>.01&&(dx*f.x+dz*f.z)/len>.4)hurt(e,p,d.damage,'physical');
 }
 for(let i=1;i<=d.range;i+=.6)particle(p.dimension,MOON,{x:pos.x+f.x*i,y:pos.y+1.2,z:pos.z+f.z*i});
 return true;
}
// 달의 차크람을 던져 시전 시점의 10블럭 이내 적 한 명을 추적한다.
// 기본 피해량 28 / 기존 쿨타임·마나 유지. 대상을 잃거나 시간이 끝나면 소멸한다.
function moonHoming(p,j,d){
 const origin=p.location, face=flatDir(p), dim=p.dimension;
 const list=getTargets(p,origin,d.range).filter(e=>enemy(p,e)&&e.typeId!=='rpg:moon_chakram_projectile');
 if(!list.length){notify(p,'§7주변 10블럭 이내에 적이 없습니다.');return false;}
 list.sort((a,b)=>{
  const score=e=>{
   const dx=e.location.x-origin.x,dz=e.location.z-origin.z;
   const dist=Math.hypot(dx,e.location.y-origin.y,dz)||.001;
   const facing=(dx*face.x+dz*face.z)/(Math.hypot(dx,dz)||1);
   return facing*4-dist*.14;
  };
  return score(b)-score(a);
 });
 if(!ready(p,false,12))return false;
 const target=list[0];
 let pos={x:origin.x+face.x*.9,y:origin.y+1.35,z:origin.z+face.z*.9};
 let visual;
 try{visual=dim.spawnEntity('rpg:moon_chakram_projectile',pos);}catch{}
 try{visual?.addTag('rpg_visual_only');}catch{}
 sound(dim,'random.bow',origin,{volume:.8,pitch:1.5});
 let elapsed=0;
 const cleanup=()=>{try{system.clearRun(task);}catch{}try{if(visual?.isValid)visual.remove();}catch{}};
 const task=system.runInterval(()=>{
  try{
   elapsed++;
   if(elapsed>45||!p.isValid||p.dimension.id!==dim.id||!enemy(p,target)){cleanup();return;}
   const q=target.location,aim={x:q.x,y:q.y+1.05,z:q.z};
   const dx=aim.x-pos.x,dy=aim.y-pos.y,dz=aim.z-pos.z;
   const distance=Math.hypot(dx,dy,dz);
   // 명중 시 1회만 물리 피해를 준다. 시전 후 길드/파티가 같아져도 공격하지 않는다.
   if(distance<=1.1){if(enemy(p,target))hurt(target,p,d.damage,'physical');particle(dim,MOON,aim);cleanup();return;}
   const step=Math.min(1.4,distance);
   pos={x:pos.x+dx/distance*step,y:pos.y+dy/distance*step,z:pos.z+dz/distance*step};
   if(visual?.isValid)visual.teleport(pos,{dimension:dim,keepVelocity:false});
   // 오래된 클라이언트에서 커스텀 모델이 보이지 않아도 위치를 알 수 있는 작은 궤적.
   particle(dim,MOON_PROJECTILE,pos);
   if(elapsed%4===0)particle(dim,MOON,pos);
  }catch{cleanup();}
 },1);
 return true;
}
function moonSplit(p,j,d){
 if(!ready(p,false,15))return false;
 moonSplitUntil.set(p.id,system.currentTick+d.duration);
 if(hasBorrowedSkill(p,'moon_chakram_split'))throwMoonWeapon(p);
 ring(p.dimension,p.location,1.3,MOON,16);
 sound(p.dimension,'random.orb',p.location,{volume:0.8,pitch:1.45});
 notify(p,'§d차크람 분열: §f60초간 무기 투척마다 소형 차크람 3개(각각 피해 4)');
 return true;
}
function moonVeil(p,j,d){
 if(!ready(p,false,15))return false;
 apply(p,'invisibility',d.duration,0);apply(p,'speed',d.duration,3); // 신속 IV, 20초
 return true;
}
function moonWave(p,j,d){
 if(!ready(p,false,25))return false;
 for(const e of getTargets(p,p.location,d.radius))if(enemy(p,e)){
  hurt(e,p,d.damage,'physical');apply(e,'slowness',d.slowTicks,2);
 }
 ring(p.dimension,p.location,d.radius,MOON,28);return true;
}
export const RUNNERS={
 sun_charge:sunCharge,sun_slash:sunSlash,sun_blessing:sunBless,sun_divine_blessing:sunDivineBlessing,sun_meteor_drive:sunMeteor,sun_radiant_beam:sunBeam,sun_descent:sunDescent,
 moon_charge:moonCharge,moon_slash:moonSlash,moon_moonlight:moonMoonlight,moon_homing:moonHoming,moon_chakram_split:moonSplit,moon_veil:moonVeil,moon_fullwave:moonWave,
};
let registered=false;
export function registerCelestial(){
 if(registered)return;registered=true;
 try{
  world.beforeEvents.effectAdd?.subscribe(ev=>{
   try{if(harmful(ev.effectType)&&isSunImmune(ev.entity))ev.cancel=true;}catch{}
  });
 }catch{}
 // Fallback to remove harmful effects that bypass the before-event.
 system.runInterval(()=>{
  for(const [id,state] of sunImmunity){
   if(system.currentTick>=state.until || !state.player?.isValid){sunImmunity.delete(id);continue;}
   removeDebuffs(state.player);
  }
  for(const [id,until] of moonSplitUntil){if(system.currentTick>=until)moonSplitUntil.delete(id);}
 },5);
 // Track successful natural hits; only fill in *missing* melee damage during
 // the 3-second no-invulnerability window to avoid double-damaging normal hits.
 world.afterEvents.entityHurt.subscribe(ev=>{
  try{
   const a=ev.damageSource?.damagingEntity,v=ev.hurtEntity;
   if(a?.typeId==='minecraft:player' && ev.damageSource?.cause===EntityDamageCause.entityAttack && v){
    lastActualMelee.set(a.id+':'+v.id,system.currentTick);
   }
  }catch{}
 });
 world.afterEvents.entityHitEntity.subscribe(ev=>{
  try{
   const a=ev.damagingEntity,v=ev.hitEntity;
   if(!hasPiercing(a)||!v||!enemy(a,v)||(!CONFIG.pvp&&v.typeId==='minecraft:player'))return;
   const tick=system.currentTick,key=a.id+':'+v.id;
   // The engine reports ordinary melee hits via entityHurt. Only when it does
   // not (target still invulnerable) do we deliver bypass damage ourselves.
   system.run(()=>{
    try{
     if(!a.isValid||!valid(v)||!hasPiercing(a))return;
     if((lastActualMelee.get(key)??-100)>=tick)return;
     additionalMoonDamage(v,a,12); // Matches the equipped sun axe's base 12 damage.
    }catch{}
   });
  }catch{}
 });
 system.runInterval(()=>{
  for(const p of world.getAllPlayers()){
   const id=getJobId(p);
   if(id==='sun_heir' || (id==='chameleon' && getSkills(p).includes('sun_charge'))){
     if(ambient(p,true))saveEnergy(p,true,energy(p,true)+CHARGE);
   }
   if(id==='moon_heir' || (id==='chameleon' && getSkills(p).includes('moon_charge'))){
     if(ambient(p,false))saveEnergy(p,false,energy(p,false)+CHARGE);
   }
   const exp=satBuffs.get(p.id);
   if(exp&&system.currentTick<exp)apply(p,'saturation',40,0);
   else if(exp)satBuffs.delete(p.id);
  }
 },20);
 world.afterEvents.entityHurt.subscribe(ev=>{
  try{
   const p=ev.hurtEntity,attacker=ev.damageSource?.damagingEntity;
   if(p?.typeId==='minecraft:player'&&(getJobId(p)==='sun_heir'||(getJobId(p)==='chameleon'&&getSkills(p).includes('sun_blessing')))){
    const state=blessings.get(p.id);
    if(state&&state.until>=system.currentTick&&!state.reflected&&enemy(p,attacker)){
     state.reflected=true;
     hurt(attacker,p,ev.damage,'fixed');
     particle(p.dimension,SUN,{x:attacker.location.x,y:attacker.location.y+1.1,z:attacker.location.z});
    }
   }
   if(attacker?.typeId==='minecraft:player'&&(getJobId(attacker)==='sun_heir'||(getJobId(attacker)==='chameleon'&&getSkills(attacker).includes('sun_slash')))&&enemy(attacker,p)){
    const buff=slashBuff.get(attacker.id);
    if(ev.damageSource?.cause===EntityDamageCause.entityAttack&&!currentScriptHit(attacker,p)&&buff&&buff.until>=system.currentTick&&['rpg:sun_heir_axe','rpg:chameleon_flame_blade','rpg:chameleon_moon_scythe'].includes(heldItemId(attacker))&&Math.hypot(attacker.location.x-p.location.x,attacker.location.y-p.location.y,attacker.location.z-p.location.z)<4.4){
     slashBuff.delete(attacker.id);
     hurt(p,attacker,ev.damage*(buff.multiplier-1),'fixed',{ignoreInvulnerability:true}); // 원래 타격 포함 총 4배
     apply(p,'slowness',buff.slowTicks,buff.slowAmp); // 둔화 III 1초
     particle(attacker.dimension,SUN,{x:p.location.x,y:p.location.y+1,z:p.location.z});
    }
   }
  }catch{}
 });
 world.afterEvents.playerLeave.subscribe(ev=>{slashBuff.delete(ev.playerId);blessings.delete(ev.playerId);satBuffs.delete(ev.playerId);moonThrowTick.delete(ev.playerId);moonSplitUntil.delete(ev.playerId);sunImmunity.delete(ev.playerId);clearPiercing(ev.playerId);for(const k of lastActualMelee.keys())if(k.startsWith(ev.playerId+':')||k.endsWith(':'+ev.playerId))lastActualMelee.delete(k);});
}
