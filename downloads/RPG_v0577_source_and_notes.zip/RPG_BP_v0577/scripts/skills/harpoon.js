import {applyDuelDamage} from '../core/pvp.js';
import {rememberScriptKiller} from '../core/combatContext.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import {teleportForSkill} from '../core/dungeonMovement.js';
import { skillDamageFor } from "../core/stats.js";
import { areAllies } from "../core/social.js";
import { system, world, EntityDamageCause } from '@minecraft/server';
import { CONFIG } from '../config.js';
import { getTargets, headPos, flatDir, norm3, dist3, isSolidAt, particle, sound, hurt, healthAlive } from '../core/util.js';
import { notify } from '../core/hud.js';
import { getLastHit } from '../core/tracking.js';

// 작살꾼 → 복수귀 (v0.4.45). 1틱=1/20초, 모든 연출은 작은 파티클로 제한.
const TRAIL = 'rpg:harpoon_trail';
const CHAIN = 'rpg:soul_chain';
const GHOST = 'rpg:soul_trace';
const pins = new Map();
const bleeding = new Map();
const TEAM_PREFIX = 'rpg_team_';
let installed = false;

function alive(e) { try { return !!e?.isValid && healthAlive(e); } catch { return false; } }
function friendly(p,e) {
  if (areAllies(p,e)) return true;
  if (e.id === p.id) return true;
  if (e.typeId !== 'minecraft:player') return false;
  const tag=p.getTags().find(t=>t.startsWith(TEAM_PREFIX));
  return !!tag && e.hasTag(tag);
}
function enemy(p,e) {
  return alive(e) && !friendly(p,e) && (e.typeId!=='minecraft:player' || CONFIG.pvp);
}
function effect(entity,id,duration,amp=0) {
  try { applyStatus(entity,id,duration,{amplifier:amp,showParticles:false}); } catch {}
}
function point(e,height=0.95) { const p=e.location;return {x:p.x,y:p.y+height,z:p.z}; }
function line(dim,from,to,fx,spacing=0.5) {
  const distance=dist3(from,to);const n=Math.min(65,Math.max(1,Math.ceil(distance/spacing)));
  for(let i=0;i<=n;i++) {const t=i/n;particle(dim,fx,{x:from.x+(to.x-from.x)*t,y:from.y+(to.y-from.y)*t,z:from.z+(to.z-from.z)*t});}
}
function safeSpot(dim,p,ground=true) {
  return !isSolidAt(dim,{x:p.x,y:p.y+0.15,z:p.z}) &&
    !isSolidAt(dim,{x:p.x,y:p.y+1.45,z:p.z}) &&
    (!ground || isSolidAt(dim,{x:p.x,y:p.y-0.8,z:p.z}));
}
function hitFx(dim,p) {
  for(let i=0;i<7;i++) {
    const a=i*2*Math.PI/7;
    particle(dim,TRAIL,{x:p.x+Math.cos(a)*.25,y:p.y+.07*(i%3),z:p.z+Math.sin(a)*.25});
  }
}

// 실제 작살 투사체: 1틱마다 2분할 충돌 판정, 0.2블록짜리 픽셀 궤적.
function shoot(p,def,onHit) {
  const d=norm3(p.getViewDirection()),dim=p.dimension,eye=headPos(p);
  const origin={x:eye.x+d.x*.65,y:eye.y+d.y*.65,z:eye.z+d.z*.65};
  let travel=0;
  const handler=system.runInterval(()=>{
    try {
      if(!p.isValid || travel>=def.range){system.clearRun(handler);return;}
      for(let i=0;i<3;i++) {
        travel+=def.speed/3;
        const at={x:origin.x+d.x*travel,y:origin.y+d.y*travel,z:origin.z+d.z*travel};
        if(isSolidAt(dim,at)) {hitFx(dim,at);system.clearRun(handler);return;}
        particle(dim,TRAIL,at);
        if(i===0 && (Math.floor(travel*4)%3===0))particle(dim,CHAIN,at);
        const victim=getTargets(p,at,1.1,.9).find(e=>enemy(p,e));
        if(victim) {
          hurt(victim,p,def.damage);hitFx(dim,at);onHit?.(victim,at);
          system.clearRun(handler);return;
        }
      }
    }catch {system.clearRun(handler);}
  },1);
  sound(dim,'mob.guardian.attack',p.location,{volume:.6,pitch:1.25});
  return true;
}
function throwHarpoon(p,job,def){return shoot(p,def);}

function frontTargets(p,def){
 const origin=p.location,dir=flatDir(p);
 return getTargets(p,{x:origin.x,y:origin.y+.9,z:origin.z},def.range+1,.9).filter(e=>{
  if(!enemy(p,e))return false;
  const at=e.location,dx=at.x-origin.x,dz=at.z-origin.z,front=dx*dir.x+dz*dir.z,side=Math.abs(dx*dir.z-dz*dir.x);
  if(front<0||front>def.range||side>def.halfWidth||Math.abs(at.y-origin.y)>2.5)return false;
  const distance=Math.hypot(dx,dz)||1;
  for(let d=.4;d<distance;d+=.4)if(isSolidAt(p.dimension,{x:origin.x+dx*d/distance,y:origin.y+.9+(at.y-origin.y)*d/distance,z:origin.z+dz*d/distance}))return false;
  return true;
 });
}
function deepPierce(p,job,def){
 const dir=flatDir(p),from=point(p),to={x:from.x+dir.x*def.range,y:from.y,z:from.z+dir.z*def.range};
 line(p.dimension,from,to,TRAIL,.35);sound(p.dimension,'item.trident.throw',p.location,{volume:.65,pitch:1.4});
 for(const target of frontTargets(p,def)){hurt(target,p,def.damage,'physical');hitFx(p.dimension,point(target));}
 return true;
}
function rend(p,job,def){
 const dim=p.dimension,dir=flatDir(p),from=point(p);
 for(let i=0;i<9;i++){const angle=Math.atan2(dir.z,dir.x)-Math.PI*.4+i*Math.PI*.1;particle(dim,GHOST,{x:from.x+Math.cos(angle)*2,y:from.y,z:from.z+Math.sin(angle)*2});}
 sound(dim,'mob.player.attack.sweep',p.location,{volume:.75,pitch:.8});
 for(const target of frontTargets(p,def)){
  if(!hurt(target,p,def.damage,'physical'))continue;hitFx(dim,point(target));
  const key=p.id+':'+target.id,state={ticks:0};bleeding.set(key,state);
  const timer=system.runInterval(()=>{
   try{
    if(bleeding.get(key)!==state||!p.isValid||!healthAlive(p)||!enemy(p,target)||p.dimension.id!==target.dimension.id){system.clearRun(timer);if(bleeding.get(key)===state)bleeding.delete(key);return;}
    hurt(target,p,def.bleedDamage,'physical');particle(dim,GHOST,point(target));
    if(++state.ticks>=def.bleedHits){bleeding.delete(key);system.clearRun(timer);}
   }catch{if(bleeding.get(key)===state)bleeding.delete(key);system.clearRun(timer);}
  },def.bleedInterval);
 }
 return true;
}

// 복수귀 영혼작살: 사슬에 맞은 대상은 시전자 앞 1.8칸까지 10틱 동안 당겨집니다.
function soulHarpoon(p,job,def) {
  return shoot(p,def,(target)=>{
    const dim=p.dimension;
    effect(target,'slowness',25,6);
    let ticks=0;
    const timer=system.runInterval(()=>{
      try {
        if(!p.isValid||!enemy(p,target)||p.dimension.id!==target.dimension.id) {system.clearRun(timer);return;}
        const me=p.location, t=target.location, dir=flatDir(p);
        const dest={x:me.x+dir.x*1.8,y:me.y,z:me.z+dir.z*1.8};
        line(dim,point(target),point(p),CHAIN,0.8);
        const length=dist3(t,dest);
        if(length>0.45) {
          const ratio=Math.min(.34,Math.max(0.03,1.8/length));
          const next={x:t.x+(dest.x-t.x)*ratio,y:t.y+(dest.y-t.y)*ratio,z:t.z+(dest.z-t.z)*ratio};
          if(safeSpot(dim,next,false))target.teleport(next,{dimension:dim,keepVelocity:false});
        }
        ticks++;
        if(ticks>=ccTicks(target,10) || length<.45){system.clearRun(timer);hitFx(dim,point(target));}
      } catch {system.clearRun(timer);}
    },1);
    sound(dim,'mob.endermen.portal',target.location,{volume:.55,pitch:1.3});
  });
}

function dive(p,job,def) {
  const upgraded=job.id==='revenant';
  const duration=upgraded?200:100;
  effect(p,'invisibility',duration,0);
  effect(p,'speed',duration,upgraded?3:2);
  if(upgraded)effect(p,'regeneration',duration,1);
  sound(p.dimension,'mob.guardian.flop',p.location,{volume:.6,pitch:1.1});
  notify(p,upgraded?'§b잠수: §f10초간 투명화·신속 IV·재생 II':'§b잠수: §f5초간 투명화·신속 III');
  return true;
}

// 전방 다섯 블럭의 적에게 무조건 적중하는 돌진. 지면·벽 검사 없이 Y 고정.
function charge(p,job,def){
  const dim=p.dimension,origin={...p.location},dir=flatDir(p),side={x:-dir.z,z:dir.x};
  const targets=getTargets(p,origin,def.length+2).filter(e=>{
    if(!enemy(p,e))return false;
    const at=e.location,dx=at.x-origin.x,dz=at.z-origin.z;
    const front=dx*dir.x+dz*dir.z,sideDist=Math.abs(dx*side.x+dz*side.z);
    return front>=0 && front<=def.length && sideDist<=def.width/2;
  });
  const dest={x:origin.x+dir.x*def.length,y:origin.y,z:origin.z+dir.z*def.length};
  // 판정은 돌진 당시 전방 5칸에 대한 고정 범위. 적이 있으면 무조건 공격.
  for(const victim of targets){
    hurt(victim,p,def.damage);hitFx(dim,point(victim));
  }
  line(dim,point(p),{x:dest.x,y:dest.y+1,z:dest.z},TRAIL,0.4);
  try{teleportForSkill(p,dest,{dimension:dim,keepVelocity:false});}catch{}
  sound(dim,'mob.irongolem.throw',origin,{volume:.8,pitch:.85});
  if(!targets.length) notify(p,'§7돌진했지만 전방 5블럭 안에 적이 없습니다.');
  else notify(p,`§b돌진: §f${targets.length}명에게 타격`);
  return true;
}

// 진짜 기절: 구속 및 무력화 + 위치 고정 (3초).
function pin(target,duration){
  effect(target,'slowness',duration,255);
  effect(target,'weakness',duration,255);
  effect(target,'mining_fatigue',duration,255);
  const existing=pins.get(target.id);
  pins.set(target.id,{entity:target,anchor:existing?.anchor??{...target.location},until:Math.max(system.currentTick+ccTicks(target,duration),existing?.until??0),dimension:target.dimension.id});
}
function distanceToSegment(p,a,b){
  const vx=b.x-a.x,vy=b.y-a.y,vz=b.z-a.z,wx=p.x-a.x,wy=p.y-a.y,wz=p.z-a.z;
  const dot=vx*vx+vy*vy+vz*vz||1;
  const t=Math.max(0,Math.min(1,(wx*vx+wy*vy+wz*vz)/dot));
  return Math.hypot(p.x-a.x-vx*t,p.y-a.y-vy*t,p.z-a.z-vz*t);
}
function soulSeparation(p,job,def) {
  const dim=p.dimension,origin={...p.location},dir=flatDir(p),dest={x:origin.x+dir.x*def.range,y:origin.y,z:origin.z+dir.z*def.range};
  if(!safeSpot(dim,dest,false)) {notify(p,'§7영혼분리: 도착 위치가 블록으로 막혀 있습니다.');return false;}
  for(let s=.5;s<def.range;s+=.5){
    const at={x:origin.x+dir.x*s,y:origin.y,z:origin.z+dir.z*s};
    if(!safeSpot(dim,at,false)){notify(p,'§7영혼분리: 앞에 장애물이 있습니다.');return false;}
  }
  try{teleportForSkill(p,dest,{dimension:dim,keepVelocity:false});}catch{return false;}
  line(dim,{...origin,y:origin.y+1},{...dest,y:dest.y+1},GHOST,.7);
  sound(dim,'mob.endermen.portal',dest,{volume:.85,pitch:1.3});
  // 1초 뒤 원래 위치에서 영혼이 시전자에게 돌아오며, 그 경로 주위 3블럭 기절.
  system.runTimeout(()=>{
    if(!p.isValid||p.dimension.id!==dim.id)return;
    const end={...p.location};
    const start={x:origin.x,y:origin.y+1,z:origin.z};
    const finish={x:end.x,y:end.y+1,z:end.z};
    line(dim,start,finish,GHOST,.35);
    line(dim,start,finish,CHAIN,.75);
    const travel=dist3(start,finish),center={x:(start.x+finish.x)/2,y:(start.y+finish.y)/2,z:(start.z+finish.z)/2};
    let hits=0;
    for(const e of getTargets(p,center,travel/2+def.radius+1,0.9)){
      if(!enemy(p,e))continue;
      if(distanceToSegment(point(e),start,finish)<=def.radius){pin(e,def.stun);hitFx(dim,point(e));hits++;}
    }
    sound(dim,'mob.endermen.portal',end,{volume:.6,pitch:.6});
    notify(p,`§b영혼분리: §f영혼 귀환 · ${hits}명 3초 기절`);
  },def.delay);
  return true;
}

// 성공: 시전자 반경 4칸의 25% 이하 적 처형, 5초 쿨타임 + 재생 III 5초.
// 실패: 같은 반경 안의 최근 공격/조준 대상 50피해, 60초 쿨타임.
function execution(p,job,def) {
  const dim=p.dimension;
  const nearby=getTargets(p,p.location,def.radius).filter(e=>enemy(p,e)&&dist3(e.location,p.location)<=def.radius);
  for(let i=0;i<32;i++){const angle=i*Math.PI*2/32;particle(dim,GHOST,{x:p.location.x+Math.cos(angle)*def.radius,y:p.location.y+.1,z:p.location.z+Math.sin(angle)*def.radius});}
  let victims=[];
  try {
    for(const e of nearby){
      if(!enemy(p,e))continue;
      const hp=e.getComponent('minecraft:health');
      if(!hp)continue;
      if(hp.currentValue>0 && hp.currentValue<=hp.effectiveMax*def.healthThreshold)victims.push(e);
    }
  }catch{}
  if(victims.length){
    let killed=0;
    for(const e of victims){
      try {
        const at=point(e);
        const life=e.getComponent('minecraft:health')?.currentValue??0;if(!applyDuelDamage(p,e,life)){rememberScriptKiller(p,e);e.kill();}killed++;
        hitFx(dim,at);
        particle(dim,GHOST,at);
      }catch{}
    }
    if(killed>0){
      effect(p,'regeneration',100,2);
      sound(dim,'random.anvil_land',p.location,{volume:.9,pitch:.55});
      notify(p,`§5처형 성공! §f${killed}명 · 쿨타임 5초 · 재생 III 5초`);
      return {cooldown:def.successCooldown};
    }
  }
  let target=getLastHit(p);
  if(!enemy(p,target)||target.dimension.id!==dim.id||dist3(target.location,p.location)>def.radius){
    let closest=Infinity;target=null;
    const eye=headPos(p),look=norm3(p.getViewDirection());
    for(const e of nearby){
      if(!enemy(p,e))continue;
      const v=point(e),delta={x:v.x-eye.x,y:v.y-eye.y,z:v.z-eye.z};
      const distance=Math.hypot(delta.x,delta.y,delta.z)||1;
      if((delta.x*look.x+delta.y*look.y+delta.z*look.z)/distance<.78)continue;
      if(distance<closest){closest=distance;target=e;}
    }
  }
  if(target){
    try{target.applyDamage(skillDamageFor(p,def.failDamage,"physical"),{cause:EntityDamageCause.override,damagingEntity:p});}
    catch{hurt(target,p,def.failDamage);}
    hitFx(dim,point(target));
  }
  sound(dim,'mob.endermen.portal',p.location,{volume:.7,pitch:.55});
  notify(p,target?'§c처형 실패: §f대상에게 50 피해 · 쿨타임 60초':'§c처형 실패: §f적이 없음 · 쿨타임 60초');
  return {cooldown:def.cooldown};
}

export const RUNNERS={
  revenant_deep_pierce:deepPierce,revenant_rend:rend,
  harpoon_throw:throwHarpoon,harpoon_dive:dive,harpoon_charge:charge,
  soul_harpoon:soulHarpoon,soul_separation:soulSeparation,revenant_execution:execution,
};
export function registerHarpoon(){
  if(installed)return;installed=true;
  system.runInterval(()=>{
    for(const [id,pinState] of pins){
      const {entity,anchor,until,dimension}=pinState;
      try {
        if(!alive(entity)||system.currentTick>=until||entity.dimension.id!==dimension){pins.delete(id);continue;}
        if(dist3(entity.location,anchor)>.3)entity.teleport(anchor,{dimension:entity.dimension,keepVelocity:false});
        if(system.currentTick%10===0)particle(entity.dimension,CHAIN,point(entity));
      }catch{pins.delete(id);}
    }
  },5);
  world.afterEvents.entityDie.subscribe(ev=>pins.delete(ev.deadEntity?.id));
}
