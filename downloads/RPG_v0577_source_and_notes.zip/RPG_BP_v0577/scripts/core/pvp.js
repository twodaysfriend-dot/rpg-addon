import {world,system} from '@minecraft/server';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {getWallet,setWallet,BALANCE_MAX} from './wallet.js';
import {dungeonRuns} from './dungeonState.js';
import {showForm} from './skillMenu.js';
const STORE='rpg:pk_registry_v1',RECOVER='rpg:duel_recover';
const duels=new Map(),offers=new Map(),grace=new Map(),lastHits=new Map(),deaths=new Map();let registered=false;
const online=id=>world.getAllPlayers().find(p=>p.id===id);
const hp=p=>p?.getComponent('minecraft:health');
const tell=(p,s)=>{try{p?.sendMessage(s);}catch{}};
const active=p=>p?.isValid&&p.typeId==='minecraft:player'&&hp(p)?.currentValue>0&&!['creative','spectator'].includes(String(p.getGameMode()).toLowerCase());
const distance=(a,b)=>a.dimension.id===b.dimension.id?Math.hypot(a.location.x-b.location.x,a.location.y-b.location.y,a.location.z-b.location.z):Infinity;
const inDungeon=p=>[...dungeonRuns.values()].some(r=>r.members.some(m=>m.id===p.id));
export function pvpOwner(source){if(!source||source.typeId==='minecraft:player')return source;try{const owner=source.getComponent('minecraft:projectile')?.owner;if(owner?.typeId==='minecraft:player')return owner;const id=source.getComponent('minecraft:tameable')?.tamedToPlayerId??source.getDynamicProperty('rpg:necro_owner');return online(id)??source;}catch{return source;}}
export function notePvpAttack(source,target,damage){source=pvpOwner(source);if(damage>0&&source?.typeId==='minecraft:player'&&target?.typeId==='minecraft:player'&&source.id!==target.id&&!duelOf(target)&&!pvpBlocked(source,target))lastHits.set(target.id,{id:source.id,name:source.name,until:Date.now()+10000});}
function registry(){return JSON.parse(world.getDynamicProperty(STORE)??'{"version":1,"pk":{}}');}
function save(s){const raw=JSON.stringify(s);if(raw.length>29000)throw Error('PK 저장 공간 부족');world.setDynamicProperty(STORE,raw);}
export function isPk(p){return Boolean(registry().pk[p?.id]);}
function refreshPk(p){if(!p)return;const marked=isPk(p);try{if(marked)p.addTag('rpg_pk');else p.removeTag('rpg_pk');}catch{}try{if(marked){if(p.getDynamicProperty('rpg:pk_name')===undefined)p.setDynamicProperty('rpg:pk_name',p.nameTag??p.name);p.nameTag='§c[PK] §r'+p.name;}else{const old=p.getDynamicProperty('rpg:pk_name');if(old!==undefined){p.nameTag=old;p.setDynamicProperty('rpg:pk_name',undefined);}}}catch{}}
export function markPk(p){const s=registry(),old=s.pk[p.id];s.pk[p.id]={name:p.name,kills:(old?.kills??0)+1,since:old?.since??Date.now()};save(s);refreshPk(p);tell(p,'§c[PK] 합의된 결투 밖에서 플레이어를 살해했습니다. PK 표식·현상금 패널티가 적용됩니다.');}
export function transferBounty(killer,victim){const a=getWallet(killer),b=getWallet(victim),amount=Math.min(50000,b.gold,BALANCE_MAX-a.gold);try{setWallet(victim,{...b,gold:b.gold-amount});setWallet(killer,{...a,gold:a.gold+amount});}catch(error){try{setWallet(victim,b);setWallet(killer,a);}catch{}throw error;}return amount;}
export function duelOf(p){return duels.get(typeof p==='string'?p:p?.id);}
export function duelOpponents(a,b){const d=duelOf(a);return Boolean(d&&d===duelOf(b)&&a.id!==b.id);}
export function pvpBlocked(source,target){
 source=pvpOwner(source);
 if(target?.typeId!=='minecraft:player')return false;
 const now=system.currentTick;
 if((grace.get(target.id)??0)>now||(grace.get(source?.id)??0)>now)return true;
 const a=duelOf(source),b=duelOf(target);if(!a&&!b)return false;
 return !duelOpponents(source,target)||a.phase!=='active';
}
function fullHealth(p){const h=hp(p);if(h)h.setCurrentValue(h.effectiveMax??20);}
function floorOn(p){p.triggerEvent('rpg:duel_enter');p.setDynamicProperty(RECOVER,true);if(hp(p)?.effectiveMin!==1)throw Error('결투 최소 HP가 적용되지 않았습니다.');}
function floorOff(p){try{p.triggerEvent('rpg:duel_exit');p.setDynamicProperty(RECOVER,undefined);}catch{}}
export function finishDuel(d,winner,reason='결투 종료'){
 if(!d||d.finished)return;d.finished=true;for(const id of d.ids)duels.delete(id);
 for(const id of d.ids)lastHits.delete(id);
 for(const id of d.ids){const p=online(id);grace.set(id,system.currentTick+60);if(p)try{fullHealth(p);}catch{}tell(p,`§e[결투] ${reason}${winner?' · 승자 '+winner.name:''}. 결투 PK·현상금은 없습니다.`);}
 system.runTimeout(()=>{for(const id of d.ids){grace.delete(id);const p=online(id);if(p&&!duelOf(p)){floorOff(p);try{fullHealth(p);}catch{}}}},60);
}
export function requestDuel(p,target){
 if(!active(p)||!active(target)||p.id===target.id)throw Error('생존한 다른 서바이벌 플레이어를 선택하세요.');
 if(distance(p,target)>32)throw Error('같은 차원 32칸 안의 플레이어에게 신청하세요.');
 if(duelOf(p)||duelOf(target)||inDungeon(p)||inDungeon(target))throw Error('던전·결투 진행 중에는 신청할 수 없습니다.');
 const existing=offers.get(target.id);if(existing&&existing.until>Date.now()&&existing.from!==p.id)throw Error('상대가 다른 결투 신청에 응답 중입니다.');offers.set(target.id,{from:p.id,until:Date.now()+30000});tell(p,'§e[결투] '+target.name+'에게 신청했습니다.');tell(target,'§e[결투] '+p.name+'의 신청입니다. /rpg:pvp에서 30초 안에 수락하세요.');return true;
}
export function acceptDuel(p,expectedFrom){
 const offer=offers.get(p.id),other=online(offer?.from);if(!offer||offer.until<Date.now())throw Error('유효한 결투 신청이 없습니다.');if(expectedFrom&&offer.from!==expectedFrom)throw Error('신청자가 바뀌었습니다. 결투 메뉴를 다시 여세요.');
 if(!active(p)||!active(other)||distance(p,other)>32||duelOf(p)||duelOf(other)||inDungeon(p)||inDungeon(other))throw Error('결투 참가 상태·거리·던전 상태를 확인하세요.');
 // Refuse to start without the native player health-floor event: no fake nonlethal guarantee.
 try{floorOn(p);floorOn(other);fullHealth(p);fullHealth(other);}catch(error){floorOff(p);floorOff(other);throw Error('결투 보호 플레이어 정의를 적용하지 못했습니다. 새 BP를 확인하세요.');}
 const d={ids:[p.id,other.id],phase:'countdown',until:Date.now()+303000,finished:false};duels.set(p.id,d);duels.set(other.id,d);offers.delete(p.id);offers.delete(other.id);for(const [id,o]of offers)if(o.from===p.id||o.from===other.id)offers.delete(id);
 for(const a of [p,other])tell(a,'§e[결투] 체력을 회복했습니다. 3초 뒤 시작합니다.');
 system.runTimeout(()=>{if(d.finished)return;const a=online(d.ids[0]),b=online(d.ids[1]);if(!active(a)||!active(b)||distance(a,b)>48){finishDuel(d,undefined,'시작 조건 불충족');return;}fullHealth(a);fullHealth(b);d.phase='active';d.until=Date.now()+300000;for(const p of [a,b])tell(p,'§c[결투] 시작! 패배 직전에 비살상 종료됩니다.');},60);return d;
}
// Direct-health script attacks use this path, so execution bonuses cannot set a duelist to zero.
export function applyDuelDamage(source,target,damage){
 source=pvpOwner(source);
 if(!duelOpponents(source,target))return undefined;
 if(pvpBlocked(source,target))return {handled:true,actual:0};
 const h=hp(target),before=h?.currentValue??0;if(before<=0)return {handled:true,actual:0};
 const actual=Math.min(Math.max(0,damage),Math.max(0,before-1));h.setCurrentValue(Math.max(1,before-actual));
 if(before-damage<=1)finishDuel(duelOf(target),source,'승부 결정');return {handled:true,actual};
}
export function observePvpHurt(ev){
 const target=ev.hurtEntity;if(target?.typeId!=='minecraft:player')return;
 const source=pvpOwner(ev.damageSource?.damagingEntity??ev.damageSource?.damagingProjectile?.getComponent('minecraft:projectile')?.owner);
 const d=duelOf(target);
 if(pvpBlocked(source,target)){const h=hp(target);if(h?.currentValue>0)h.setCurrentValue(Math.min(h.effectiveMax??20,h.currentValue+ev.damage));return;}
 notePvpAttack(source,target,ev.damage);
 if(d&&d.phase==='active'&&(hp(target)?.currentValue??0)<=1)finishDuel(d,source,'승부 결정');
}
export function recordPvpDeath(killer,victim){
 if(victim?.typeId!=='minecraft:player')return;
 const d=duelOf(victim);if(d){finishDuel(d,killer,'결투 참가자 사망');return;}
 if((grace.get(victim.id)??0)>system.currentTick)return;
 if(deaths.get(victim.id)===system.currentTick)return;deaths.set(victim.id,system.currentTick);
 if(killer?.typeId!=='minecraft:player'){const last=lastHits.get(victim.id);killer=last?.until>Date.now()?(online(last.id)??{id:last.id,name:last.name,typeId:'minecraft:player',isValid:false}):undefined;}
 lastHits.delete(victim.id);if(!killer||killer.id===victim.id)return;
 if(isPk(victim)){
  let amount;const s=registry();if(killer.isValid===false){const before=getWallet(victim);s.credits??={};const owed=s.credits[killer.id]??0;amount=Math.min(50000,before.gold,BALANCE_MAX-owed);try{setWallet(victim,{...before,gold:before.gold-amount});s.credits[killer.id]=owed+amount;delete s.pk[victim.id];save(s);}catch(error){setWallet(victim,before);throw error;}}else{const ka=getWallet(killer),va=getWallet(victim);try{amount=transferBounty(killer,victim);delete s.pk[victim.id];save(s);}catch(error){setWallet(killer,ka);setWallet(victim,va);throw error;}}refreshPk(victim);tell(killer,'§6[현상금] PK 플레이어 지갑에서 '+amount.toLocaleString()+'골드를 받았습니다. 추가 PK 패널티는 없습니다.');tell(victim,'§c[PK] '+amount.toLocaleString()+'골드가 현상금으로 지급되었고 PK 표식이 해제됐습니다.');
 }else markPk(killer);
}
export function recoverPvpPlayer(p){const state=registry(),owed=state.credits?.[p.id]??0;if(owed){const before=getWallet(p),amount=Math.min(owed,BALANCE_MAX-before.gold);try{setWallet(p,{...before,gold:before.gold+amount});state.credits[p.id]=owed-amount;save(state);}catch(error){setWallet(p,before);throw error;}}if(p.getDynamicProperty(RECOVER)&&!duelOf(p)){floorOff(p);fullHealth(p);}refreshPk(p);}
export async function openPvp(p,arg=''){
 try{
  const text=String(arg).trim();if(text){if(['수락','accept'].includes(text))return acceptDuel(p);if(['거절','reject'].includes(text)){offers.delete(p.id);return;}if(['항복','surrender'].includes(text)){const d=duelOf(p);if(d)finishDuel(d,online(d.ids.find(id=>id!==p.id)),'항복');return;}const target=world.getAllPlayers().find(a=>a.name.toLowerCase()===text.toLowerCase());if(!target)throw Error('접속 중인 플레이어를 찾지 못했습니다.');return requestDuel(p,target);}
  const d=duelOf(p);if(d){const r=await showForm(new MessageFormData().title('진행 중인 결투').body('결투를 포기할까요?').button1('계속').button2('항복'),p);if(r&&!r.canceled&&r.selection===1)finishDuel(d,online(d.ids.find(id=>id!==p.id)),'항복');return;}
  const pending=offers.get(p.id);if(pending&&pending.until>Date.now()){const from=online(pending.from);const r=await showForm(new MessageFormData().title('결투 신청').body((from?.name??'상대')+'의 결투를 수락할까요? 두 사람 체력을 채운 뒤 시작합니다.').button1('거절').button2('수락'),p);if(r&&!r.canceled&&r.selection===1)return acceptDuel(p,pending.from);if(r&&!r.canceled&&offers.get(p.id)===pending)offers.delete(p.id);return;}
  const list=world.getAllPlayers().filter(a=>a.id!==p.id&&active(a)&&distance(p,a)<=32),f=new ActionFormData().title('결투 신청 · PvP').body('서로 수락한 결투는 체력 회복 후 시작하며 비살상으로 끝납니다.\n결투 밖 살인은 PK 표식·최대 50,000골드 현상금 패널티.\n내 PK 상태: '+(isPk(p)?'PK':'없음'));
  for(const a of list)f.button(a.name);f.button('닫기');const r=await showForm(f,p);if(r&&!r.canceled&&r.selection<list.length)requestDuel(p,list[r.selection]);
 }catch(error){tell(p,'§c[PvP] '+String(error.message??error));}
}
export function registerPvp(){
 if(registered)return;registered=true;
 world.afterEvents.entityHurt.subscribe(ev=>{try{observePvpHurt(ev);}catch(error){console.warn('[RPG PvP hurt] '+error);}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{try{recoverPvpPlayer(ev.player);}catch{}},20));
 world.afterEvents.playerLeave.subscribe(ev=>{const d=duelOf(ev.playerId);if(d)finishDuel(d,online(d.ids.find(id=>id!==ev.playerId)),'접속 종료로 패배');offers.delete(ev.playerId);});
 system.run(()=>{for(const p of world.getAllPlayers())try{recoverPvpPlayer(p);}catch{}});
 system.runInterval(()=>{for(const [id,o]of offers)if(o.until<Date.now())offers.delete(id);for(const [id,h]of lastHits)if(h.until<Date.now())lastHits.delete(id);for(const d of new Set(duels.values())){const a=online(d.ids[0]),b=online(d.ids[1]);if(!active(a)||!active(b)||distance(a,b)>48||Date.now()>d.until)finishDuel(d,undefined,'시간 초과·범위 이탈·참가 상태 변경');}},20);
}
