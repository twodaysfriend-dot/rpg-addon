import { world, system } from '@minecraft/server';
import { BASIC_JOB_IDS } from '../data/jobs.js';
import { getJobId, getProgress, addProgress } from './playerData.js';
import { isTrialTarget } from './jobTrials.js';
import { notify } from './hud.js';

// ------------------------------------------------------------------
// 추가 전직 시련 추적기
//  - 작살꾼: 낚시 성공 횟수 (fish_catches)
//  - 그림자 암살자: 암살자 상태 기습 처치 (assassin_ambush)
//  - 복수귀: 작살꾼 상태에서 나를 죽인 플레이어 사살 (revenge_kills)
//  - 투신: 무투가 상태 2단계 이상 던전 솔로 클리어 (solo_d5)
//  - 카멜레온: 기본 직업 3종 습득(cham_jobs) → 전직 포기각서(cham_waived) → 전직관 발견(cham_found)
// ------------------------------------------------------------------

const active = p => p && !['creative', 'spectator'].includes(String(p.getGameMode?.()).toLowerCase());
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
const setProgress = (p, o) => p.setDynamicProperty('rpg:progress', JSON.stringify(o));

// ---------------- 카멜레온 ----------------
// 기본 5직업(검사/마법사/궁수/무투가/성직자) 중 서로 다른 직업을 몇 개 거쳤는지 기록합니다.
export function recordBasicJobAdvance(p, jobId) {
  if (!BASIC_JOB_IDS.includes(jobId)) return;
  const o = getProgress(p);
  const list = Array.isArray(o.cham_job_list) ? o.cham_job_list : [];
  if (list.includes(jobId)) return;
  list.push(jobId);
  o.cham_job_list = list;
  o.cham_jobs = list.length;
  setProgress(p, o);
  if (list.length <= 3) notify(p, `§7카멜레온의 길 · 기본 직업 습득 ${list.length}/3`);
}
// 기본 직업을 3개 이상 거친 뒤 전직 포기각서를 쓰면 기록됩니다.
export function noteChameleonWaiver(p) {
  const o = getProgress(p);
  if ((o.cham_jobs ?? 0) < 3 || o.cham_waived) return;
  o.cham_waived = 1;
  setProgress(p, o);
  p.sendMessage('§8[???] §7모든 길을 버린 자에게만 보이는 흔적이 있다. 카멜레온 전직관을 찾아라.');
}
// 앞의 두 단계를 마친 뒤 카멜레온 전직관(rpg:hito_chameleon)과 상호작용하면 발견으로 기록됩니다.
export function markChameleonTrainerFound(p) {
  const o = getProgress(p);
  if ((o.cham_jobs ?? 0) < 3 || !o.cham_waived || o.cham_found) return;
  o.cham_found = 1;
  setProgress(p, o);
  p.sendMessage('§d[카멜레온 시련] 카멜레온 전직관을 찾아냈다!');
}

// ---------------- 투신: 5단계 던전 솔로 ----------------
export function recordSoloDungeonClear(p, tier, solo) {
  if (!solo || tier < 2 || getJobId(p) !== 'fighter' || !active(p)) return;
  if (getProgress(p).solo_d5) return;
  addProgress(p, 'solo_d5');
  p.sendMessage('§c[투신 시련] 무투가로 2단계 이상 던전 솔로 클리어 완료!');
}

// ---------------- 복수귀: 나를 죽인 플레이어 ----------------
const KILLED_BY = 'rpg:killed_by_v1';
function readKillers(p) {
  try {
    const v = JSON.parse(p.getDynamicProperty(KILLED_BY) ?? '[]');
    return Array.isArray(v) ? v : [];
  } catch { return []; }
}
function writeKillers(p, list) { p.setDynamicProperty(KILLED_BY, JSON.stringify(list.slice(-64))); }

// ---------------- 그림자 암살자: 기습 ----------------
// 암살자가 적의 등 뒤(후방 120도)에서 첫 타격을 넣고 10초 안에 처치하면 기습 처치로 인정합니다.
const ambushed = new Map(); // victimId -> { by, tick }
function isBehind(attacker, victim) {
  const v = victim.getViewDirection();
  const dx = attacker.location.x - victim.location.x;
  const dz = attacker.location.z - victim.location.z;
  const dl = Math.hypot(dx, dz), vl = Math.hypot(v.x, v.z);
  if (dl < 0.01 || vl < 0.01) return false;
  return (v.x * dx + v.z * dz) / (dl * vl) < -0.5;
}

// stats.js 의 처치 판정에서 호출합니다. (killer 는 이미 플레이어로 확정된 상태)
export function recordTrialKillExtras(killer, dead) {
  if (!killer || !dead) return;
  if (dead.typeId === 'minecraft:player') {
    if (dead.id === killer.id) return;
    // 복수귀 시련: 작살꾼이 자신을 죽였던 플레이어를 사살
    if (getJobId(killer) === 'harpooner' && active(killer) && active(dead)) {
      const mine = readKillers(killer);
      if (mine.some(k => k.id === dead.id)) {
        writeKillers(killer, mine.filter(k => k.id !== dead.id));
        const n = addProgress(killer, 'revenge_kills');
        killer.sendMessage(`§3[복수귀 시련] 나를 죽인 ${dead.name} 사살 ${Math.min(n, 3)}/3`);
      }
    }
    // 죽은 쪽의 '나를 죽인 사람' 목록에 기록
    if (active(killer) && active(dead)) {
      const list = readKillers(dead).filter(k => k.id !== killer.id);
      list.push({ id: killer.id, name: killer.name });
      writeKillers(dead, list);
    }
    return;
  }
  const a = ambushed.get(dead.id);
  if (!a) return;
  ambushed.delete(dead.id);
  if (a.by === killer.id && system.currentTick - a.tick <= 200 && getJobId(killer) === 'assassin' && active(killer) && isTrialTarget(dead.typeId)) {
    const n = addProgress(killer, 'assassin_ambush');
    notify(killer, `§5기습 처치 ${Math.min(n, 50)}/50`);
  }
}

// ---------------- 작살꾼: 낚시 성공 ----------------
// 낚시 성공 전용 이벤트가 없어 찌(minecraft:fishing_hook) 사라짐 + 같은 위치 아이템 생성으로 판정합니다.
const hooks = new Map();   // hookId -> { owner, pos, dim, wasWater }
const pending = [];        // 사라진 찌 { owner, pos, dim, at }
const drops = [];          // 최근 생성된 아이템 { pos, dim, tick }
const isWater = (dim, loc) => {
  try {
    const id = dim.getBlock({ x: Math.floor(loc.x), y: Math.floor(loc.y), z: Math.floor(loc.z) })?.typeId ?? '';
    return id === 'minecraft:water' || id === 'minecraft:flowing_water';
  } catch { return false; }
};
function hookOwner(h) {
  try {
    const o = h.getComponent('minecraft:projectile')?.owner;
    if (o?.typeId === 'minecraft:player') return o.id;
  } catch { /* 소유자 정보 없음 */ }
  let best, bd = 6;
  try {
    for (const p of h.dimension.getPlayers({ location: h.location, maxDistance: 6 })) {
      const d = dist(p.location, h.location);
      if (d < bd) { bd = d; best = p; }
    }
  } catch { /* ignore */ }
  return best?.id;
}
function creditCatch(ownerId) {
  const p = world.getAllPlayers().find(x => x.id === ownerId);
  if (!p || !active(p)) return;
  const n = addProgress(p, 'fish_catches');
  if (n <= 200 && (n % 10 === 0 || n === 1)) notify(p, `§b낚시 성공 ${n}/200`);
}
function trackFishing() {
  const now = system.currentTick, seen = new Set();
  for (const dimId of ['overworld', 'nether', 'the_end']) {
    let list = [];
    try { list = world.getDimension(dimId).getEntities({ type: 'minecraft:fishing_hook' }); } catch { continue; }
    for (const h of list) {
      try {
        if (!h.isValid) continue;
        seen.add(h.id);
        let s = hooks.get(h.id);
        if (!s) { s = { owner: hookOwner(h), wasWater: false }; hooks.set(h.id, s); }
        s.pos = { ...h.location };
        s.dim = h.dimension.id;
        if (isWater(h.dimension, h.location)) s.wasWater = true;
      } catch { /* 찌가 사라지는 중 */ }
    }
  }
  for (const [id, s] of [...hooks]) {
    if (seen.has(id)) continue;
    hooks.delete(id);
    if (s.wasWater && s.owner && s.pos) pending.push({ owner: s.owner, pos: s.pos, dim: s.dim, at: now });
  }
  while (drops.length && now - drops[0].tick > 40) drops.shift();
  for (let i = pending.length - 1; i >= 0; i--) {
    const q = pending[i];
    const j = drops.findIndex(d => d.dim === q.dim && Math.abs(d.tick - q.at) <= 10 && dist(d.pos, q.pos) <= 3.5);
    if (j >= 0) {
      drops.splice(j, 1);
      pending.splice(i, 1);
      creditCatch(q.owner);
    } else if (now - q.at > 12) {
      pending.splice(i, 1);
    }
  }
  for (const [id, a] of ambushed) if (now - a.tick > 400) ambushed.delete(id);
}

let registered = false;
export function registerNewTrials() {
  if (registered) return;
  registered = true;
  world.afterEvents.entitySpawn.subscribe(ev => {
    try {
      const e = ev.entity;
      if (e?.typeId === 'minecraft:item') drops.push({ pos: { ...e.location }, dim: e.dimension.id, tick: system.currentTick });
    } catch { /* ignore */ }
  });
  world.afterEvents.entityHurt.subscribe(ev => {
    try {
      const attacker = ev.damageSource?.damagingEntity;
      const victim = ev.hurtEntity;
      if (attacker?.typeId !== 'minecraft:player' || !victim || victim.typeId === 'minecraft:player') return;
      if (getJobId(attacker) !== 'assassin' || !active(attacker) || !isTrialTarget(victim.typeId)) return;
      if (ambushed.has(victim.id)) return; // 첫 타격만 판정
      ambushed.set(victim.id, { by: isBehind(attacker, victim) ? attacker.id : null, tick: system.currentTick });
    } catch { /* ignore */ }
  });
  system.runInterval(() => { try { trackFishing(); } catch (error) { console.warn('[RPG fishing] ' + String(error)); } }, 2);
}
