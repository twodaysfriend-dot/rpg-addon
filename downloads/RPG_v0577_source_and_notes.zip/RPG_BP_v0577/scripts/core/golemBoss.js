import {levelAttackMultiplier,MONSTER_LEVEL_KEY} from '../data/monsterLevels.js';
import {playBossMotion} from './bossMotion.js';
import { world, system, EntityDamageCause } from "@minecraft/server";

// 고대 마력 골렘: 실제 보스바와 450 XP 보상은 엔티티 컴포넌트로 처리.
const IDS = ["rpg:rock_golem_boss"];
const active = new Map();
const PARTICLE = "minecraft:critical_hit_emitter";
const DUST = "minecraft:basic_smoke_particle";

function okay(e) {
  try { return !!e?.isValid && (e.getComponent("minecraft:health")?.currentValue ?? 0) > 0; }
  catch { return false; }
}
function sameDimension(a, b) {
  try { return a.dimension.id === b.dimension.id; } catch { return false; }
}
function distance(a,b) {
  const dx=a.x-b.x, dy=a.y-b.y, dz=a.z-b.z;
  return Math.sqrt(dx*dx+dy*dy+dz*dz);
}
function playersNear(boss,range) {
  const center=boss.location;
  return world.getAllPlayers().filter(p=> okay(p) && sameDimension(p,boss) && distance(p.location,center)<=range &&
     p.getGameMode?.() !== "creative" && p.getGameMode?.() !== "spectator");
}
function safeParticle(dim, id, pos) {
  try { dim.spawnParticle(id,pos); } catch {}
}
function ring(dim,c,r,n=18,id=DUST) {
  for(let i=0;i<n;i++) {
    const angle=i*Math.PI*2/n;
    safeParticle(dim,id,{x:c.x+Math.cos(angle)*r,y:c.y+0.16,z:c.z+Math.sin(angle)*r});
  }
}
function damage(boss,target,amount,knock=0) {
  if(!okay(target))return;
  try { target.applyDamage(amount*levelAttackMultiplier(boss.getDynamicProperty?.(MONSTER_LEVEL_KEY)??1),{cause:EntityDamageCause.entityAttack,damagingEntity:boss}); } catch {}
  if(knock>0) {
    try {
      const a=target.location,b=boss.location,dx=a.x-b.x,dz=a.z-b.z;
      const l=Math.hypot(dx,dz)||1;
      target.applyImpulse({x:dx/l*knock,y:0.28,z:dz/l*knock});
    } catch {}
  }
}
function groundSlam(boss) {
  if(!okay(boss))return;
  playBossMotion(boss,'slam');
  const dim=boss.dimension,loc={...boss.location}, radius=4.5;
  ring(dim,loc,radius,16,"minecraft:critical_hit_emitter");
  try{ dim.playSound("mob.irongolem.throw",loc,{volume:1.3,pitch:0.7}); }catch{}
  system.runTimeout(()=>{
    if(!okay(boss))return;
    const c=boss.location;
    ring(dim,c,radius,24,PARTICLE);
    for(const p of playersNear(boss,radius+0.6)) {
      damage(boss,p,11.25,1.1);
    }
    try{dim.playSound("random.explode",c,{volume:1.0,pitch:0.55});}catch{}
  },14);
}
function shockwave(boss) {
  if(!okay(boss))return;
  playBossMotion(boss,'wave');
  const dim=boss.dimension,origin={...boss.location}, touched=new Set();
  try{dim.playSound("mob.irongolem.hit",origin,{volume:1.1,pitch:0.6});}catch{}
  let step=0;
  const id=system.runInterval(()=>{
    if(!okay(boss)||step>=10){system.clearRun(id);return;}
    step++;
    const r=step*0.9;
    ring(dim,origin,r,18,step%2===0?PARTICLE:DUST);
    for(const p of playersNear(boss,12)) {
      const d=Math.hypot(p.location.x-origin.x,p.location.z-origin.z);
      if(!touched.has(p.id)&&d>=r-1.1&&d<=r+1.0&&Math.abs(p.location.y-origin.y)<=3) {
        touched.add(p.id);damage(boss,p,6.75,0.55);
      }
    }
  },2);
}
export function registerGolemBoss() {
  const dimensions=["overworld","nether","the_end"];
  system.runInterval(()=>{
    const now=system.currentTick;
    const seen=new Set();
    for(const id of dimensions) {
      let dim;
      try { dim=world.getDimension(id); } catch { continue; }
      let bosses;
      try { bosses=IDS.flatMap(type => dim.getEntities({type})); } catch { continue; }
      for(const boss of bosses) {
        if(!okay(boss))continue;
        seen.add(boss.id);
        let state=active.get(boss.id);
        if(!state) { state={slam:now+100,wave:now+180};active.set(boss.id,state); }
        const hp=boss.getComponent("minecraft:health");
        const enraged=(hp?.currentValue??600) <= (hp?.effectiveMax??600)*0.5;
        const near=playersNear(boss,16);
        if(!near.length)continue;
        if(now>=state.slam&&near.some(p=>distance(p.location,boss.location)<5.4)) {
          state.slam=now+(enraged?115:165);
          groundSlam(boss);
        }
        if(now>=state.wave) {
          state.wave=now+(enraged?220:320);
          shockwave(boss);
        }
        if(enraged&&now%40<10) safeParticle(dim,PARTICLE,{x:boss.location.x,y:boss.location.y+2.0,z:boss.location.z});
      }
    }
    for(const id of [...active.keys()])if(!seen.has(id))active.delete(id);
  },10);
}
