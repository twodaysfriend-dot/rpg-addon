// Class items have enhancement only; deliberately absent from itemRarity.
export const CLASS_WEAPONS=Object.freeze([
  {
    "id": "rpg:apprentice_sword",
    "name": "견습의 검",
    "damage": 8
  },
  {
    "id": "rpg:apprentice_book",
    "name": "견습의 마법책",
    "damage": 0
  },
  {
    "id": "rpg:apprentice_cross",
    "name": "견습의 십자가",
    "damage": 0
  },
  {
    "id": "rpg:apprentice_fist",
    "name": "견습의 주먹",
    "damage": 7
  },
  {
    "id": "rpg:apprentice_bow",
    "name": "견습 활",
    "damage": 0
  },
  {
    "id": "rpg:war_god_gauntlets",
    "name": "투신의 흑염 건틀릿",
    "damage": 18
  },
  {
    "id": "rpg:swordsman_sword",
    "name": "검사의 검",
    "damage": 10
  },
  {
    "id": "rpg:sword_saint_sword",
    "name": "검성의 검",
    "damage": 13
  },
  {
    "id": "rpg:fallen_sword_saint_sword",
    "name": "타락검성의 검",
    "damage": 9
  },
  {
    "id": "rpg:mage_book",
    "name": "마법사의 마법서",
    "damage": 0
  },
  {
    "id": "rpg:sage_staff",
    "name": "현자의 지팡이",
    "damage": 0
  },
  {
    "id": "rpg:archer_bow",
    "name": "궁수 활",
    "damage": 0
  },
  {
    "id": "rpg:heavenly_bow",
    "name": "천궁 활",
    "damage": 0
  },
  {
    "id": "rpg:mangnani_axe",
    "name": "망나니의 전투 도끼",
    "damage": 9
  },
  {
    "id": "rpg:beast_axe",
    "name": "야수의 전투 도끼",
    "damage": 12
  },
  {
    "id": "rpg:frost_gauntlet",
    "name": "냉기 능력자의 서리 손",
    "damage": 7
  },
  {
    "id": "rpg:fire_gauntlet",
    "name": "화염술사의 불꽃 손",
    "damage": 7
  },
  {
    "id": "rpg:dragon_knight_lance",
    "name": "용기사의 창",
    "damage": 10
  },
  {
    "id": "rpg:demon_scythe",
    "name": "악마의 영혼 낫",
    "damage": 11
  },
  {
    "id": "rpg:tech_staff",
    "name": "마법공학사의 지팡이",
    "damage": 6
  },
  {
    "id": "rpg:hacker_core",
    "name": "해커 코어",
    "damage": 4
  },
  {
    "id": "rpg:blood_crystal",
    "name": "혈술사의 피 결정",
    "damage": 5
  },
  {
    "id": "rpg:assassin_blade",
    "name": "암살자의 단검",
    "damage": 8
  },
  {
    "id": "rpg:shadow_assassin_blade",
    "name": "그림자 암살자의 단검",
    "damage": 10
  },
  {
    "id": "rpg:harpooner_harpoon",
    "name": "작살꾼의 작살",
    "damage": 7
  },
  {
    "id": "rpg:revenant_harpoon",
    "name": "복수귀의 영혼작살",
    "damage": 11
  },
  {
    "id": "rpg:sun_heir_axe",
    "name": "해의 한손 도끼",
    "damage": 12
  },
  {
    "id": "rpg:moon_heir_blade",
    "name": "달의 차크람",
    "damage": 11
  },
  {
    "id": "rpg:chameleon_flame_blade",
    "name": "흑염 대검",
    "damage": 12
  },
  {
    "id": "rpg:fighter_fist",
    "name": "무투가의 주먹",
    "damage": 10
  },
  {
    "id": "rpg:fist_bone_fist",
    "name": "권골의 주먹",
    "damage": 13
  },
  {
    "id": "rpg:cleric_cross",
    "name": "성직자의 성십자",
    "damage": 0
  },
  {
    "id": "rpg:angel_hands",
    "name": "천사의 기도",
    "damage": 0
  },
  {
    "id": "rpg:michael_wings",
    "name": "미카엘의 날개",
    "damage": 0
  },
  {
    "id": "rpg:fallen_angel_wings",
    "name": "타락천사의 날개",
    "damage": 0
  },
  {
    "id": "rpg:chameleon_moon_scythe",
    "name": "백월의 낫",
    "damage": 12
  }
]);
export const classWeapon=id=>CLASS_WEAPONS.find(w=>w.id===id);
