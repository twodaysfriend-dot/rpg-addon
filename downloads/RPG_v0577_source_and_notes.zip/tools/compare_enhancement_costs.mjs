// Exact finite-state expectations. Destruction returns to +0 with a replacement
// provided; replacement crafting/loot costs are deliberately reported separately.
import {enhancementRates,upgradeCost,catalystAllowed,ARMOR_MAX,RUNE_MAX} from '../RPG_BP_v0577/scripts/data/upgrades.js';
import {currencyReward} from '../RPG_BP_v0577/scripts/core/economy.js';
import {HUNT_REWARDS,CLEAR_REWARD,DUNGEON,WAVES} from '../RPG_BP_v0577/scripts/data/dungeons.js';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
function solve(matrix,vector){
 const a=matrix.map((row,i)=>[...row,vector[i]]),n=vector.length;
 for(let col=0;col<n;col++){
  let pivot=col;for(let row=col+1;row<n;row++)if(Math.abs(a[row][col])>Math.abs(a[pivot][col]))pivot=row;
  [a[col],a[pivot]]=[a[pivot],a[col]];if(Math.abs(a[col][col])<1e-12)throw Error('Non-absorbing enhancement configuration');
  const divisor=a[col][col];for(let k=col;k<=n;k++)a[col][k]/=divisor;
  for(let row=0;row<n;row++)if(row!==col){const factor=a[row][col];for(let k=col;k<=n;k++)a[row][k]-=factor*a[col][k];}
 }
 return a.map(row=>row[n]);
}
export function expectedEnhancement(kind,catalysts=0){
 const n=kind==='armor'?ARMOR_MAX:RUNE_MAX,metrics=['attempts','gold','stone','dust','catalysts','destroyed'];
 const matrix=[],rewards=Object.fromEntries(metrics.map(k=>[k,[]]));
 for(let level=0;level<n;level++){
  const count=catalystAllowed(kind,level)?catalysts:0,rates=enhancementRates(kind,level,count),cost=upgradeCost(kind,level);
  if(!rates)throw Error('Invalid enhancement configuration');
  const row=Array(n).fill(0);row[level]=1;
  for(const [next,chance]of [[level+1,rates.success],[level,rates.fail],[Math.max(0,level-1),rates.downgrade],[0,rates.destroy]])if(next<n)row[next]-=chance/100;
  matrix.push(row);const reward={attempts:1,...cost,catalysts:count,destroyed:rates.destroy/100};for(const k of metrics)rewards[k].push(reward[k]);
 }
 return Object.fromEntries(metrics.map(k=>[k,solve(matrix,rewards[k])[0]]));
}
export function sumEnhancements(armor,rune,armorCount=4,runeCount=3){return Object.fromEntries(Object.keys(armor).map(k=>[k,armor[k]*armorCount+rune[k]*runeCount]));}
export function calculate(){
 return [0,5].map(catalysts=>{const armor=expectedEnhancement('armor',catalysts),rune=expectedEnhancement('rune',catalysts);return {catalystsPerEligibleAttempt:catalysts,armor,rune,equippedSet:sumEnhancements(armor,rune),allFiveRunes:sumEnhancements(armor,rune,4,5),allRunes:sumEnhancements(armor,rune,4,6)};});
}
const f=(n,d=0)=>n.toLocaleString('ko-KR',{minimumFractionDigits:d,maximumFractionDigits:d});
function table(rows){return '| 대상 | 촉매 | 평균 시도 | 골드 | 강화석 | 룬 가루 | 촉매 소비 | 파괴 후 교체 |\n|---|---:|---:|---:|---:|---:|---:|---:|\n'+rows.map(([name,c,r])=>`| ${name} | ${c} | ${f(r.attempts,1)} | ${f(r.gold)} | ${f(r.stone,1)} | ${f(r.dust,1)} | ${f(r.catalysts,1)} | ${f(r.destroyed,2)} |`).join('\n')+'\n';}
export function targetSummary(data=calculate()){
 const normal=currencyReward('minecraft:zombie',()=>.5);normal.dust=HUNT_REWARDS.normal.dustChance;
 const required=(cost,reward)=>Math.max(...['gold','stone','dust'].map(k=>cost[k]/reward[k]));
 const guaranteedCats=CLEAR_REWARD.catalysts+1/CLEAR_REWARD.bonusEvery;
 const perClear={...CLEAR_REWARD};for(const wave of WAVES)for(const type of wave.types){const r=currencyReward('rpg:'+type,()=>.5);for(const k of ['gold','stone','dust'])perClear[k]+=r[k];if(!type.includes('elite_')&&!type.includes('boss'))perClear.dust+=HUNT_REWARDS.normal.dustChance;}
 return data.map(d=>{
  const cost=d.allRunes;
  return {catalystsPerEligibleAttempt:d.catalystsPerEligibleAttempt,allRunes:cost,
   normalKills:required(cost,normal),normalHoursWithoutCatalystSourcing:required(cost,normal)*5/3600,
   guaranteedCatalystsPerClear:guaranteedCats,killPlusClearReward:perClear,
   dungeonClears:Math.max(required(cost,perClear),cost.catalysts/guaranteedCats,5),
   dungeonHours:Math.max(required(cost,perClear),cost.catalysts/guaranteedCats,5)*DUNGEON.baselineMinutes/60};
 });
}
export function report(data){
 const [none,max]=data,[noTarget,yesTarget]=targetSummary(data);
 const simulation=fs.existsSync('v0577_성장시간_모의실험.json')?JSON.parse(fs.readFileSync('v0577_성장시간_모의실험.json','utf8')):null;
 const experiment=simulation?`\n\n고정 난수 시드 533으로 각 경로를 10,000번 모의 계산한 결과:\n\n| 경로 | 평균 | 중앙값 | 90% 지점 |\n|---|---:|---:|---:|\n${simulation.map(x=>`| ${x.strategy?'던전 촉매':'일반 사냥 무촉매'} | ${f(x.meanHours,1)}시간 | ${f(x.medianHours,1)}시간 | ${f(x.p90Hours,1)}시간 |`).join('\n')}\n\n이 표는 강화 변동을 반영한 모델이며 실제 게임 플레이 측정이 아닙니다. 재현: node --experimental-loader ./tests/loader.mjs tools/simulate_progression.mjs\n`:'';
 return `# RPG v0.5.77: 일반 등급 갑옷·룬 +10 비용과 시간

v0.5.77 던전은 일반 50·엘리트 5를 5분, 이후 보스 1마리를 3분 안에 잡는 원형 동굴입니다. 시간 모델의 10분/회는 입장·대기·정비를 포함하는 가정입니다.

기준은 캐릭터 1명의 갑옷 4부위 +10과 일반 등급 룬 6종 전체 +10입니다. 장착은 기존대로 서로 다른 룬 3개까지입니다. 룬 +10 확대에 맞춰 룬 비용을 단계별 반올림(2.5×다음 단계²) 골드·가루 1개로 조정하고 던전 촉매를 7개부터 지급합니다. 이 모델은 일반 등급 +10까지만 계산하며 합성 승급·공용 무기·신화 풀세트는 포함하지 않습니다.

상태전이 연립방정식 E=비용+P·E를 풀어 실패는 현 단계, 강등은 한 단계 아래, 파괴는 새 +0 장비로 재시작하는 비용까지 계산했습니다.

`+
 table(data.flatMap(x=>[['갑옷 4부위',x.catalystsPerEligibleAttempt,sumEnhancements(x.armor,x.rune,4,0)],['장착 룬 3개',x.catalystsPerEligibleAttempt,sumEnhancements(x.armor,x.rune,0,3)],['갑옷 4 + 룬 6종 전체',x.catalystsPerEligibleAttempt,x.allRunes]]))+
 `
## 사냥 보상 상향

| 적 | 골드 | 강화석 | 룬 가루 |
|---|---:|---:|---|
| 일반 | ${HUNT_REWARDS.normal.gold} | ${HUNT_REWARDS.normal.stone} | 15% 확률 1 |
| 정예 | ${HUNT_REWARDS.elite.gold} | ${HUNT_REWARDS.elite.stone} | ${HUNT_REWARDS.elite.dust} |
| 보스 | ${HUNT_REWARDS.boss.gold} | ${HUNT_REWARDS.boss.stone} | ${HUNT_REWARDS.boss.dust} |

일반 몹을 이동 포함 5초당 1마리 잡으면 시간당 720마리·골드 ${f(720*HUNT_REWARDS.normal.gold)}입니다. 무촉매 갑옷 4 + 룬 6종 풀강은 골드 ${f(none.allRunes.gold)} 기준 평균 약 **${f(noTarget.normalHoursWithoutCatalystSourcing,2)}시간**입니다. 강화석·룬 가루도 이 사냥량 안에서 평균적으로 충분합니다. 기존 약 285시간의 강화 재화 파밍 목표를 약 20시간으로 줄였습니다.

## 던전 보상과 촉매 포함 경로

한 번 클리어할 때 각 생존 참여자에게 골드 ${CLEAR_REWARD.gold}·강화석 ${CLEAR_REWARD.stone}·룬 가루 ${CLEAR_REWARD.dust}, 촉매 ${CLEAR_REWARD.catalysts}개를 줍니다. 개인 누적 ${CLEAR_REWARD.bonusEvery}회마다 촉매 1개를 더 주므로 확정 보상만 평균 ${f(yesTarget.guaranteedCatalystsPerClear,3)}개입니다. 보스 바닥 전리품의 기존 촉매 25% 드롭은 별도 보너스이며 이 계산에 포함하지 않았습니다. 파티 4명에게도 확정 보상은 각각 동일합니다.

룬은 힘→비전→생명→샘→수호→흡수 순환으로 매 클리어 1개를 보급하여 6번이면 6종을 모두 확보합니다. 최초 클리어에는 모험가 갑옷 4부위를 지급합니다. 매번 철 8·구리 2·에메랄드 2·참나무 판자 2·자수정 2·청금석 1도 보급하여 파괴 후 갑옷 재제작 재료를 공급합니다. 몬스터 룬 드롭 1%·정예 3%·보스 30%는 유지합니다.

고위 강화마다 촉매 5개를 쓰면 갑옷 4 + 룬 6종에 평균 골드 ${f(max.allRunes.gold)}·강화석 ${f(max.allRunes.stone,1)}·가루 ${f(max.allRunes.dust,1)}·촉매 ${f(max.allRunes.catalysts,1)}개가 필요합니다. 촉매 확정 수급 기준 약 **${f(yesTarget.dungeonClears,1)}회**, 1회 입장·이동·정비·강화 포함 10분을 가정하면 **${f(yesTarget.dungeonHours,2)}시간**입니다. 룬을 장착할 3개만 강화하면 약 ${f(max.equippedSet.catalysts/yesTarget.guaranteedCatalystsPerClear*DUNGEON.baselineMinutes/60,1)}시간으로 줄어듭니다.

## 수치의 의미

20시간은 고정 보장이나 실제 플레이 실측이 아니라 보상 설계의 평균 목표입니다. 일반 사냥 5초/마리, 던전 10분/회라는 가정입니다. 각 평균 요구량을 평균 공급량으로 나눈 계획용 근사치이며 실제 종료 시각의 정확한 기대값은 아닙니다. 강화 운과 전투·이동·정비 속도, 실패한 던전 횟수에 따라 달라집니다. 최종 강화에서도 촉매 5개를 쓸 때 파괴 확률 3%는 남습니다.

강화 원가 계산에는 파괴 후 재강화가 포함되지만, 위저·소환 재료·직접 제작 등 외부 경로를 추가 이용하는 시간은 합산하지 않았습니다. 던전 보급 재료는 별도 채집 부담을 줄이도록 제공합니다. 일반 몹 경로에는 갑옷 제작 재료의 별도 채집 시간이 포함되지 않습니다. 던전 자체의 실전 클리어 속도는 Bedrock에서 측정 후 조정해야 합니다.

재현: node --experimental-loader ./tests/loader.mjs tools/compare_enhancement_costs.mjs${experiment}
`;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){const data=calculate();fs.writeFileSync('강화비용_계산결과.json',JSON.stringify({costs:data,targets:targetSummary(data)},null,2)+'\n');fs.writeFileSync('v0577_풀강_비용과_시간.md',report(data));console.log(JSON.stringify(data,null,2));}
