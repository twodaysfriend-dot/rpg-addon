import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,replies,forms} from './minecraftMock.mjs';
import {chooseBeginnerLine,tryBeginnerLine,openBeginnerGuide} from '../RPG_BP_v0577/scripts/core/beginner.js';
import {getBeginnerState,INTRO_KEY} from '../RPG_BP_v0577/scripts/core/beginnerData.js';
import {getContext} from '../RPG_BP_v0577/scripts/core/context.js';
import {STARTER_BY_LINE,APPRENTICE_SKILLS} from '../RPG_BP_v0577/scripts/data/jobs.js';
import {getSkills} from '../RPG_BP_v0577/scripts/core/playerData.js';
test('one apprentice can try all five lines while food and arrows are granted only once',()=>{
 const p=player('all-trials');chooseBeginnerLine(p,'sword');for(const line of ['mage','holy','fist','archer','sword','archer'])assert.equal(tryBeginnerLine(p,line).ok,true);
 for(const id of Object.values(STARTER_BY_LINE))assert.equal(p.slots.filter(i=>i?.typeId===id).length,1);
 assert.equal(p.slots.filter(i=>i?.typeId==='minecraft:bread').reduce((n,i)=>n+i.amount,0),16);assert.equal(p.slots.filter(i=>i?.typeId==='minecraft:arrow').reduce((n,i)=>n+i.amount,0),64);assert.equal(getBeginnerState(p).tried.length,5);
});
test('existing apprentices can use any starter item regardless of stored learned list or original line',()=>{
 const p=player('legacy');p.setDynamicProperty(INTRO_KEY,JSON.stringify({line:'sword',kills:4,rewarded:false,offered:true}));p.setDynamicProperty('rpg:skills','[]');
 for(const [line,id]of Object.entries(STARTER_BY_LINE)){p.equipment.set('Mainhand',new ItemStack(id));const c=getContext(p);assert.equal(c.line,line);assert.deepEqual(c.all,APPRENTICE_SKILLS[line]);}
 assert.equal(tryBeginnerLine(p,'mage').ok,true);assert.equal(getBeginnerState(p).kills,4);assert.equal(getBeginnerState(p).rewarded,false);
});
test('legacy bow recipients do not obtain more arrows when trying another line and returning',()=>{
 const p=player('old-archer');p.setDynamicProperty(INTRO_KEY,JSON.stringify({line:'archer',kills:5,rewarded:true,offered:true}));p.slots[0]=new ItemStack(STARTER_BY_LINE.archer);tryBeginnerLine(p,'mage');tryBeginnerLine(p,'archer');assert.equal(p.slots.filter(i=>i?.typeId==='minecraft:arrow').length,0);assert.equal(getBeginnerState(p).rewarded,true);assert.equal(getBeginnerState(p).kills,5);
});
test('full inventory or failed save cannot overwrite items or mark an unissued trial as received',()=>{
 const p=player('full-trial');chooseBeginnerLine(p,'sword');for(let i=2;i<36;i++)p.slots[i]=new ItemStack('minecraft:stone',64);const state=p.getDynamicProperty(INTRO_KEY);assert.equal(tryBeginnerLine(p,'mage').ok,false);assert.equal(p.getDynamicProperty(INTRO_KEY),state);
 p.slots[2]=undefined;const write=p.setDynamicProperty.bind(p);let fail=true;p.setDynamicProperty=(k,v)=>{if(fail&&k===INTRO_KEY){fail=false;throw Error('save');}write(k,v);};const skills=getSkills(p);assert.equal(tryBeginnerLine(p,'mage').ok,false);assert.equal(p.slots[2],undefined);assert.equal(p.getDynamicProperty(INTRO_KEY),state);assert.deepEqual(getSkills(p),skills);
});
test('lost trial gear can be recovered without more food, while advanced classes cannot request trial kits',()=>{
 const p=player('no-farm');chooseBeginnerLine(p,'mage');p.slots[0]=undefined;assert.equal(tryBeginnerLine(p,'mage').ok,true);assert.equal(p.slots.filter(i=>i?.typeId==='minecraft:bread').reduce((n,i)=>n+i.amount,0),16);p.setDynamicProperty('rpg:job','mage');assert.equal(tryBeginnerLine(p,'sword').ok,false);assert.equal(tryBeginnerLine(p,'unknown').ok,false);
});
test('normal guide exposes the trial picker without OP and grants the requested additional kit',async()=>{
 const p=player('guide-trial');chooseBeginnerLine(p,'sword');replies.push({selection:1},{selection:1});await openBeginnerGuide(p);assert.ok(forms.some(f=>f.heading==='견습 5계열 자유 체험'));assert.ok(p.slots.some(i=>i?.typeId===STARTER_BY_LINE.mage));
});
