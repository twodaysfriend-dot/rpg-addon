import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {COMMON_WEAPONS} from '../RPG_BP_v0577/scripts/data/commonWeapons.js';
import {ALL_EQUIPMENT_IDS} from '../RPG_BP_v0577/scripts/data/equipment.js';
import {CRAFTING_RECIPES} from '../RPG_BP_v0577/scripts/data/crafting.js';
import {JOBS} from '../RPG_BP_v0577/scripts/data/jobs.js';
import {getContext} from '../RPG_BP_v0577/scripts/core/context.js';
import {player,ItemStack} from './minecraftMock.mjs';
import {answerRpgQuestion} from '../RPG_BP_v0577/scripts/core/rpgAssistant.js';
const json=p=>JSON.parse(fs.readFileSync(new URL('../'+p,import.meta.url)));
test('all seven weapon names, recipes, combat components, atlas and RP records are linked',()=>{
 assert.deepEqual(COMMON_WEAPONS.map(w=>w.name),['적월선','마공학 검','마공학 대검','정예기사의 대검','빙설의 대검','화염의 대검','마수의 도끼']);
 const atlas=json('RPG_RP_v0577/textures/item_texture.json').texture_data;
 for(const w of COMMON_WEAPONS){const item=json('RPG_BP_v0577/items/'+w.id.slice(4)+'.json')['minecraft:item'];assert.equal(item.components['minecraft:display_name'].value,w.name);assert.equal(item.components['minecraft:damage'],w.damage);assert.equal(item.components['minecraft:durability'].max_durability,w.durability);assert.equal(item.components['rpg:cast_item'],undefined);assert.ok(ALL_EQUIPMENT_IDS.includes(w.id));const recipe=json('RPG_BP_v0577/recipes/'+w.id.slice(4)+'.json')['minecraft:recipe_shapeless'];assert.equal(recipe.result.item,w.id);assert.ok(recipe.ingredients.length<=9);assert.ok(CRAFTING_RECIPES.some(r=>r.id===w.id&&r.category==='weapon'));const texture=atlas[item.components['minecraft:icon']].textures;const png=fs.readFileSync(new URL('../RPG_RP_v0577/'+texture+'.png',import.meta.url));assert.equal(png.readUInt32BE(16),128);assert.equal(png.readUInt32BE(20),128);assert.equal(json('RPG_RP_v0577/items/'+w.id.slice(4)+'.json')['minecraft:item'].description.identifier,w.id);}
});
test('old saved item IDs are directly renamed replacements without losing per-item properties',()=>{
 for(const [id,name]of [['rpg:common_battle_sword','마공학 검'],['rpg:common_battle_spear','정예기사의 대검']]){const w=COMMON_WEAPONS.find(w=>w.id===id);assert.equal(w.name,name);const held=new ItemStack(id);held.setDynamicProperty('saved:property','retain');const clone=held.clone();assert.equal(clone.getDynamicProperty('saved:property'),'retain');assert.equal(json('RPG_BP_v0577/items/'+id.slice(4)+'.json')['minecraft:item'].components['minecraft:display_name'].value,name);}
});
test('new common weapons remain separate from job casting items across every implemented class',()=>{
 for(const w of COMMON_WEAPONS)for(const j of Object.values(JOBS).filter(j=>!j.placeholder&&j.weapon)){const p=player('common-'+j.id);p.setDynamicProperty('rpg:job',j.id);p.equipment.set('Mainhand',new ItemStack(w.id));assert.notEqual(j.weapon,w.id);assert.ok(!getContext(p));}
});
test('offline NPC knowledge and crafting guide describe the seven replacements and no retired names',async()=>{
 const answer=(await answerRpgQuestion('공용 무기 알려줘')).text;for(const w of COMMON_WEAPONS)assert.ok(answer.includes(w.name));assert.ok(!answer.includes('모험가 전투검'));assert.ok(!answer.includes('별빛 전투창'));assert.equal(CRAFTING_RECIPES.filter(r=>r.category==='weapon').length,7);
});
