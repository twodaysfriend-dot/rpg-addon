import test from 'node:test';
import assert from 'node:assert/strict';
import {world,ItemStack,player} from './minecraftMock.mjs';
import {registerStructureProtection} from '../RPG_BP_v0577/scripts/core/structureProtection.js';
const sig=()=>({listeners:[],subscribe(fn){this.listeners.push(fn);}});
for(const n of ['playerBreakBlock','playerInteractWithBlock','explosion'])world.beforeEvents[n]=sig();
const dim={id:'minecraft:overworld'},block=(x=0,id=dim.id)=>({location:{x,y:80,z:0},dimension:{id}});
registerStructureProtection('test-dungeon',b=>b.dimension.id===dim.id&&Math.abs(b.location.x)<=5&&b.location.y===80&&b.location.z===0);
const emit=(name,e)=>{for(const f of world.beforeEvents[name].listeners)f(e);return e;};
test('stable 2.2 break protection includes creative/admin players without a place-before event',()=>{
 assert.equal(world.beforeEvents.playerPlaceBlock,undefined);for(const admin of [false,true])assert.equal(emit('playerBreakBlock',{block:block(),player:player('p',1,{commandPermissionLevel:admin?1:0}),cancel:false}).cancel,true);
 assert.equal(emit('playerBreakBlock',{block:block(20),cancel:false}).cancel,false);assert.equal(emit('playerBreakBlock',{block:block(0,'minecraft:nether'),cancel:false}).cancel,false);
});
test('placing blocks and destructive tools/buckets are canceled on protected blocks through native interaction events',()=>{
 for(const id of ['minecraft:stone','minecraft:tnt','minecraft:water_bucket','minecraft:bucket','minecraft:lava_bucket','minecraft:flint_and_steel','minecraft:fire_charge','minecraft:bone_meal','minecraft:diamond_axe','minecraft:iron_shovel','minecraft:iron_hoe'])assert.equal(emit('playerInteractWithBlock',{block:block(),itemStack:new ItemStack(id),cancel:false}).cancel,true,id);
});
test('an exterior click cannot place a block into the protected boundary',()=>{
 assert.equal(emit('playerInteractWithBlock',{block:block(6),blockFace:'West',itemStack:new ItemStack('minecraft:stone'),cancel:false}).cancel,true);
 assert.equal(emit('playerInteractWithBlock',{block:block(6),blockFace:'East',itemStack:new ItemStack('minecraft:stone'),cancel:false}).cancel,false);
});
test('trainer eggs, RPG skill items, ordinary combat items and empty hands remain usable',()=>{
 for(const id of ['rpg:hito_sword_spawn_egg','rpg:war_god_gauntlets','minecraft:bow','minecraft:bread',undefined])assert.equal(emit('playerInteractWithBlock',{block:block(),itemStack:id?new ItemStack(id):undefined,cancel:false}).cancel,false);
});
test('piston placement within pushing distance of a protected boundary is rejected',()=>{
 for(const id of ['minecraft:piston','minecraft:sticky_piston'])assert.equal(emit('playerInteractWithBlock',{block:block(15),itemStack:new ItemStack(id),cancel:false}).cancel,true);
 assert.equal(emit('playerInteractWithBlock',{block:block(30),itemStack:new ItemStack('minecraft:piston'),cancel:false}).cancel,false);
});
test('TNT/creeper explosion blocks are filtered across both structures without canceling unrelated damage',()=>{
 registerStructureProtection('test-temple',b=>b.dimension.id===dim.id&&b.location.x===100);const blocks=[block(),block(100),block(50),block(0,'minecraft:nether')];let filtered;
 emit('explosion',{getImpactedBlocks:()=>blocks,setImpactedBlocks:bs=>{filtered=bs;}});assert.deepEqual(filtered,[blocks[2],blocks[3]]);
 const e=emit('explosion',{getImpactedBlocks(){throw Error('engine error');},cancel:false});assert.equal(e.cancel,true);
});
