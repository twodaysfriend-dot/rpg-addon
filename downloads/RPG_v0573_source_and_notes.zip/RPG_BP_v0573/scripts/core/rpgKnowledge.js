import {dungeonMonsterLevel} from '../data/monsterLevels.js';
import {PROMOTION_RATES,GRADE_MULTIPLIERS,ARMOR_GRADE_HP} from '../data/grades.js';
import {RARITIES,itemRarity,runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {skillScalingInfo} from '../data/skillScaling.js';
import {isBalanceQuestion,isHiddenPromotionQuestion} from './assistantPolicy.js';
import {JOBS,APPRENTICE_SKILLS} from '../data/jobs.js';
import {SKILLS} from '../data/skills.js';
import {LINE_NOTES,SKILL_NOTES} from '../data/skillGuide.js';
import {JOB_TRIALS} from '../data/jobTrials.js';
import {CRAFTING_RECIPES} from '../data/crafting.js';
import {RUNES,ARMOR_SETS} from '../data/equipment.js';
import {upgradedRune,RUNE_MAX,ARMOR_MAX,MAX_CATALYSTS,upgradeCost,enhancementRates} from '../data/upgrades.js';
import {DUNGEON,DUNGEON_TIERS,clearRewardForTier,netheriteChanceForTier} from '../data/dungeons.js';
import {CONFIG} from '../config.js';
import {defaultDamageTypeFor} from './stats.js';
export const QUESTION_LIMIT=200;
export const UNKNOWN_ANSWER='이 애드온의 직업·스킬·룬·갑옷·제작·강화·던전·성장 정보만 안내합니다. 도감에 없는 내용은 확인할 수 없습니다. 예: 월룡륜미 범위 / 검사 전직 / 생명의 룬 / 샌드백 제작';
export const normalizeQuestion=s=>String(s??'').normalize('NFKC').toLowerCase().replace(/§./g,'').replace(/[^a-z0-9가-힣]/g,'');
const clean=s=>String(s??'').replace(/§./g,'').replace(/[\u0000-\u0008\u000b-\u001f]/g,'');
const bossName=id=>({rock_golem_boss:'바위 골렘',cyclops_boss:'외눈 거인',hydra_boss:'히드라',tech_block_golem_boss:'마공학 골렘'}[id]??'던전 보스');
const percent=n=>Number((n*100).toFixed(3))+'%';
function runeEffects(r){
 const a=[];if(r.physical)a.push('물리 피해 +'+percent(r.physical-1));if(r.magic)a.push('마법 피해 +'+percent(r.magic-1));
 if(r.health)a.push('최대 HP +'+r.health);if(r.manaRegenPercent)a.push('초당 최대 MP의 '+percent(r.manaRegenPercent)+' 추가 회복');
 if(r.lifesteal)a.push('준 피해의 '+percent(r.lifesteal)+' HP 회복');if(r.ward)a.push('저항 '+(r.wardAmplifier+1)+'단계 유지');return a.join(', ');
}
const EFFECT_GROUPS=[
 {id:'damagebuff',title:'피해 증가·공격 강화 기술',match:q=>/딜뻥|공증|뎀증|힘버프|공격력버프|((데미지|대미지|피해|공격력|딜).*(버프|증가|강화|올려|높여))/.test(q),groups:[
 ['힘 효과를 주는 기술',['holy_sword','fist_stance','beast_berserk','blood_awaken','fire_armor','fire_emperor','sun_descent']],
 ['평타·후속 타격을 강화하는 기술',['war_god_black_flash','sun_slash','fist_strong','berserker_execute','assassin_stealth','dragon_triple_strike']],
 ['적이 받는 피해를 늘리는 기술',['assassin_mark','fallen_orb','berserker_charge']],
 ['적에게 힘을 주는 예외: 자가 공격 강화용 지원기가 아님',['demon_contract']]]},
 {id:'healing',title:'회복·흡혈 기술',match:q=>/회복|힐|치유|흡혈/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|있는|주는/.test(q),groups:[['회복·재생·흡혈 효과',['holy_heal','holy_orb','angel_bless','angel_zone','demon_vampirism','fallen_sword_frenzy','beast_berserk','moon_moonlight','sun_descent']]]},
 {id:'defense',title:'보호·방어 강화 기술',match:q=>/보호막|방어버프|저항버프|피해흡수/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['보호·저항·피해 흡수',['holy_shield','holy_orb','angel_bless','angel_zone','fallen_shield','fist_stance','fire_armor','sun_blessing','sun_descent','demon_contract']]]},
 {id:'control',title:'적 제어 기술',match:q=>/기절|동결|빙결|속박|둔화|cc/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['제어 효과를 갖는 기술 예시',['fist_face','frost_grasp','frost_absolute','blood_bind','tech_prison','sage_zero','moon_fullwave','sun_slash']]]}
];
function effectKnowledge(q){
 const g=EFFECT_GROUPS.find(g=>g.match(q));if(!g)return undefined;
 
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder&&j.id!=='chameleon');
 const groups=g.groups.map(([title,ids])=>title+'\n'+ids.filter(id=>SKILLS[id]&&SKILL_NOTES[id]).map(id=>{
 const skill=SKILLS[id],owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name).join('·');
 return '• '+skill.name+' ('+owners+'): '+SKILL_NOTES[id].split(/\.\s+(?=[가-힣A-Z])/)[0]+'.';
 }).join('\n')).join('\n\n');
 return Object.freeze({id:'effect:'+g.id,title:g.title,aliases:[],body:groups+'\n\n효과별 안내이며 강함·티어 순위가 아닙니다. 개별 기술명으로 상세 수치·조건을 확인하세요.',source:'data/skills.js · data/skillGuide.js · data/jobs.js'});
}
const PUBLIC_JOBS=new Set(['swordsman','mage','archer','fighter','cleric']);
let catalog;
export function knowledgeEntries(){
 if(catalog)return catalog;
 const entries=[];
 const add=(id,title,aliases,body,source)=>entries.push(Object.freeze({id,title,aliases:Object.freeze([...new Set([title,...aliases].map(normalizeQuestion).filter(x=>x.length>=2))]),body:clean(body),source}));
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder),active=new Set([...jobs.flatMap(j=>j.skills),...Object.values(APPRENTICE_SKILLS).flat()]);
 for(const id of active){
  const s=SKILLS[id];if(!s||!SKILL_NOTES[id])continue;
  const owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name);
  add('skill:'+id,s.name,[id,s.name.replace(/\s*\([^)]*\)/g,''),s.name.replace(/\s*제작$/,'')],`피해 보정: ${skillScalingInfo(id)}\n기본 MP ${s.mana} / 쿨 ${s.cooldown/20}초\n${SKILL_NOTES[id]}\n사용 직업: ${owners.join('·')}\n피해 수치는 스탯·힘 버프·장비 보정 전입니다.`, 'data/skills.js · data/skillGuide.js');
 }
 for(const j of jobs){
  const publicPromotion=PUBLIC_JOBS.has(j.id);
  const trial=publicPromotion?JOB_TRIALS[j.id]:undefined,condition=trial?`레벨 ${trial.level}\n`+['all','any'].filter(k=>trial[k]).map(k=>trial[k].map(c=>`${c.label} ${c.need}`).join(k==='all'?' + ':' 또는 ')).join('\n'):'견습 시작 직업';
  const from=trial?.allowedFrom?.map(id=>JOBS[id].name).join('·')??(j.hidden&&j.parent===null?'아무 2차 이상 직업':JOBS[j.parent]?.name??'없음');
  const type=defaultDamageTypeFor({getDynamicProperty:()=>j.id});
  const special=!publicPromotion?'전직 방법·조건은 공개하지 않습니다.':j.id==='hacker'?'전직: 로토와 23회 대화 후 퀴즈 정답. 월드 최초 정답자 1명만 전직 가능. 직업·레벨 제한 없음.':`직전 직업: ${from}\n전직 조건: ${condition}`;
  const shrine=trial?.shrine?`\n전직 장소: 천체 신전의 ${trial.shrine==='sun'?'해 제단·낮':'달 제단·밤'} 4칸 안. /rpg:temple에서 위치 확인.`:'';
  const extra='';
  add('job:'+j.id,j.name,[j.id],`${special}${extra}${shrine}\n기본 피해 계열: ${type==='magic'?'마력(마법)':'근력(물리)'}. 개별 기술에 다른 피해 판정이 있으면 해당 판정을 따릅니다.\n보유 기술: ${j.skills.map(id=>SKILLS[id]?.name??id).join('·')||'시작 장비에 따라 사용'}\n${j.id==='chameleon'?LINE_NOTES.chameleon:''}`,'data/jobs.js · data/jobTrials.js · data/skillGuide.js');
 }
 for(const [id,r]of Object.entries(RUNES)){
  const recipe=CRAFTING_RECIPES.find(c=>c.id==='rpg:rune_'+id);
  add('rune:'+id,r.name,[r.name.replace('의 ',''),'rune_'+id],`등급: 일반~신화, 강화와 별개인 합성 승급. 아래는 일반 등급 기준\n기본: ${runeEffects(upgradedRune(r,0))}\n최대 +${RUNE_MAX}: ${runeEffects(upgradedRune(r,RUNE_MAX))}\n/rpg:runes 보관함에서 장착해야 효과를 받습니다.\n${recipe?.text??'룬 드롭으로 획득'}`,'data/equipment.js · data/upgrades.js · data/crafting.js');
 }
 for(const [id,a]of Object.entries(ARMOR_SETS))add('armor:'+id,a.name+' 갑옷',[a.name,id,...(id==='abyssal'?['심연갑옷','상위갑옷','네더라이트이상']:[])],`${a.description}\n등급: 일반~신화. 부위당 등급 추가 HP ${ARMOR_GRADE_HP.join(' / ')}\n부위별 방어력: ${a.protection.join(' / ')}\n최대 강화 +${ARMOR_MAX}. 부위별 제작법은 /rpg:craft에서 확인하세요.`,'data/equipment.js · data/upgrades.js');
 for(const r of CRAFTING_RECIPES)add('craft:'+r.id,r.name+' 제작법',[r.name,r.id,r.name.replace('훈련용 ','').replace(' 소환',''),...(r.id==='rpg:stat_reset_scroll'?['스탯초기화']:[])],r.text,'data/crafting.js (실제 조합법에서 생성)');
 add('rule:offer','검과 책 바치기',['공물','바치기','검바치기','책바치기'], '/rpg:offer: 검과 책을 바칩니다. 인벤토리에서 현재 직업과 진행도에 맞게 소비합니다. 바친 아이템은 사라집니다. 효과부여 책은 시련과 마나 공물 중 현재 필요한 용도로 사용됩니다.','core/offer.js');
 add('rule:huntingzones','사냥 구역과 자연 출현',['사냥구역','초반사냥','중반사냥','후반사냥','몹스폰','몬스터출현'], '오버월드 X·Z 중 절댓값이 큰 좌표를 기준으로 초반 ±1500, 초반 밖 중반 ±4000, 중반 밖 후반 ±10000입니다. 경계는 안쪽 구역에 포함하고 10000 밖도 후반을 유지합니다. 밤에는 구역에 맞는 RPG 몬스터가 출현합니다. 바닐라 적대 몹 자연 출현은 동굴로 제한합니다. 사막 몬스터는 사막에서 밤낮·좌표 제한 없이 출현합니다.','data/huntingZones.js · spawn_rules');
 add('rule:rarity','아이템 등급·합성',['등급','아이템등급','무기등급','갑옷등급','룬등급','희귀도','합성','승급'],RARITIES.join(' → ')+'\n룬·RPG 갑옷·공용 무기 7종은 모두 일반~신화가 존재합니다. 같은 종류·같은 등급의 +5 이상 두 개를 /rpg:fuse에서 합성합니다. 성공하면 다음 등급 +0, 실패하면 두 장비를 보존하며 50% 확률로 주장비만 -1강. 둘 다 +10이면 성공률 100%. 신화는 최종 등급. 갑옷은 보호 IV 책 1권, 공용 무기는 날카로움 V 책 1권이 추가로 필요하고 성공·실패 모두 소모합니다. 룬은 책이 필요 없습니다.\n다음 등급 성공률: '+PROMOTION_RATES.join(' / ')+'%. 무기 기본 피해·룬 수치 효과 배율: '+GRADE_MULTIPLIERS.join(' / ')+'. 갑옷 부위당 추가 HP: '+ARMOR_GRADE_HP.join(' / ')+'. 직업 기본 무기는 등급·승급 없이 +10 강화만 가능하며, 강화 단계당 근접 피해 +1·물리/마법 스킬 피해 +2%. 고정 피해·회복량은 제외. 바닐라 장비는 제외.','data/grades.js · core/fusion.js');
 add('rule:armor','갑옷 종류·제작',['갑옷','방어구'],Object.values(ARMOR_SETS).map(a=>a.name+': '+a.description).join('\n')+'\n4부위를 같은 세트로 입어야 세트 효과를 받습니다. /rpg:craft에서 부위별 제작법, /rpg:upgrade에서 강화를 확인하세요.','data/equipment.js · data/crafting.js');
 add('rule:scalingjobs','근력·마력 직업 안내',['근력직업','마력직업','근력캐','마력캐','힘캐','마법직업'],['근력(물리) 기본 계열: '+jobs.filter(j=>j.id!=='apprentice'&&defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='physical').map(j=>j.name).join('·'),'마력(마법) 기본 계열: '+jobs.filter(j=>defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='magic').map(j=>j.name).join('·'),'직업 기본 계열과 개별 기술은 다를 수 있습니다. 풍압·용의 브레스는 마력, 달 계열 공격은 근력, 메테오드라이브/혈인은 혼합, 대미장식은 고정 피해입니다. 스킬명과 함께 물어보세요.'].join('\n'),'core/stats.js · data/skillScaling.js');
 add('rule:damage','피해 계산·힘 버프',['힘버프','힘효과','힘스킬','마법딜','고정피해','마법피해','피해계산'],`힘 효과는 물리·마법 스킬 피해를 단계당 ${CONFIG.skillDamage.strengthPerLevel*100}% 증가시킵니다. 힘 I +5%·II +10%·III +15%. 단타와 연타 총합에 같은 비율로 적용합니다. 이후 물리는 근력, 마법은 마력과 장비·룬 보정을 받습니다. 고정 피해는 유지합니다.\n무투가 기존 힘 계산 및 평타 배수에는 중복 적용하지 않습니다. 기본 평타의 힘 효과는 마인크래프트 엔진 규칙입니다.`,'core/stats.js · skills/fist.js');
 add('rule:transfer','갑옷 강화 이전',['강화이전','이전서','강화추출'],`/rpg:transfer에서 제작 전에 강화를 이전서로 추출하세요. 단계당 골드 500, 원래 갑옷은 +0. 새 RPG 갑옷을 만든 뒤 같은 부위에 100% 적용하며 이전서는 소모됩니다. 기존 단계보다 높은 이전서만 적용하며 합산하지 않습니다. 인챈트·내구도는 대상 장비 것을 유지합니다.`,'core/armorTransfer.js');
 add('rule:bosscc','보스 CC 저항',['보스cc','보스기절','보스빙결','보스둔화'],`커스텀 보스 4종·드래곤·위더·워든에게 기절·빙결·둔화·속박 1회 지속시간은 50%, 넉백·끌어당김 강도는 50%입니다. 일반 몬스터와 플레이어는 그대로입니다. 장판에서 CC를 다시 적용하는 동작은 유지하며, 피해·화상·독은 CC 감소 대상이 아닙니다.`,'core/crowdControl.js');
 add('rule:farm','좀벌레 보상',['좀벌레','좀벌레팜','공장'],`좀벌레는 XP 5, 골드 2, 강화석·룬 가루 0, 룬 확률 0.1%입니다. 일반 적과 다른 전용 보상을 적용합니다.`,'core/economy.js · core/runeDrops.js');
 add('rule:commonweapons','공용 전투 무기',['공용무기','무기제작','평타무기'],COMMON_WEAPONS.map(w=>w.name+': 추가 근접 피해 설정 '+w.damage+'·내구도 '+w.durability).join('\n')+'\n누구나 제작하는 평타용 무기입니다. 직업 스킬은 기존 전용 아이템으로 사용합니다. /rpg:craft에서 재료를 확인하세요.','data/commonWeapons.js · data/crafting.js');
 for(const w of COMMON_WEAPONS)add('weapon:'+w.key,w.name,[w.key,w.id],`공용 RPG 평타 무기. 일반~신화 합성 승급 가능, 최대 +10 강화(단계당 추가 근접 피해 +1) · 추가 근접 피해 설정 ${w.damage}·내구도 ${w.durability}. 직업 제한 없음. /rpg:craft에서 제작법을 확인하세요. 직업 스킬은 전용 아이템을 사용합니다.`,'data/commonWeapons.js');
 add('rule:stats','레벨·스탯',['스탯','근력','마력','지능','체력스탯','레벨업'],`자연 성장 최대 레벨 100, 레벨마다 SP 3. 근력·체력·마력 투자 상한 없음. 지능 최대 50이며 마나 소모 감소는 최대 40%.\n근력은 물리 피해, 마력은 마법 피해·회복량, 체력은 최대 HP입니다. /rpg:stats에서 분배합니다.`,'core/stats.js');
 add('rule:pvp','PvP·결투·PK',['pvp','피케이','결투','현상금','pk패널티'], '일반 PvP 허용. /rpg:pvp 또는 지원되는 환경의 /pvp로 신청하고 서로 수락하면 최대 HP로 회복 후 3초 뒤 결투 시작, 패배 직전 비살상 종료합니다. 결투 밖 플레이어 살인은 PK 표식. PK 플레이어를 죽이면 그 지갑에서 최대 50,000골드를 지급하고 새 PK가 되지 않습니다. 잔액만 지급하며 부족분은 생성하지 않습니다. PK는 플레이어에게 처치돼야 해제됩니다. 던전에서는 결투 불가.','core/pvp.js');
 add('rule:party','파티 경험치',['파티','경험치','쩔','xp'],`최대 4명. 같은 차원·처치자 ${CONFIG.partyXp.radius}칸 안·생존한 파티원은 각자 원래 XP의 ${percent(CONFIG.partyXp.multiplier)} 획득. 90 XP 몹이면 각자 ${90*CONFIG.partyXp.multiplier} XP.\n일반 마크 생물 10, 대부분 적대 몹 30, 좀벌레·좀비화 피글린 5 XP. 커스텀 몹/보스는 별도 값.\n전직 처치는 최근 30초 공격·탱킹·유효 회복에 기여한 같은 차원·시체 32칸 안 생존 파티원도 인정합니다.`,'config.js · data/mobXp.js · core/combatContribution.js');
 add('rule:runes','룬 획득·장착',['룬','룬획득','룬드랍','룬드롭','룬장착'],`일반 몬스터 1%·RPG 엘리트 3%·보스 30% 확률로 룬 드롭(좀벌레만 0.1%). 현재 룬 ${Object.values(RUNES).map(r=>r.name).join('·')}.\n/rpg:runes 전용 보관함 30칸, 장착 3개. 같은 종류는 하나만 장착. 원하는 룬은 /rpg:craft 제작법을 확인하세요.`,'core/runeDrops.js · loot_tables/rpg · core/runeInventory.js');
 const ar=enhancementRates('armor',ARMOR_MAX-1),rr=enhancementRates('rune',RUNE_MAX-1),ac=upgradeCost('armor',ARMOR_MAX-1),rc=upgradeCost('rune',RUNE_MAX-1);
 add('rule:classweapon','직업 기본 무기 강화',['직업무기강화','기본무기강화','직업무기등급'], '직업·견습 기본 무기 36종은 /rpg:upgrade에서 +10까지 강화합니다. 등급·승급은 없습니다. 강화당 근접 피해 +1, 그 무기를 들고 사용하는 물리·마법 스킬 피해 +2%(+10은 +20%). 고정 피해와 회복량은 증가하지 않습니다. 공용 무기와 같은 비용·실패·강등·파괴·촉매 규칙입니다. 카멜레온 무기 전환과 직업 무기 재지급·전직 시 강화 단계를 유지합니다.','data/classWeapons.js · core/upgrades.js');
 add('rule:upgrade','강화·촉매·재화',['강화','촉매','골드','강화석','룬가루'],`/rpg:upgrade에서 갑옷·공용·직업 무기 최대 +${ARMOR_MAX}, 룬 최대 +${RUNE_MAX}. 실패·강등·파괴에도 비용 소모.\n갑옷 마지막 단계: 골드 ${ac.gold}·강화석 ${ac.stone}, 성공 ${ar.success}% / 유지 ${ar.fail}% / 강등 ${ar.downgrade}% / 파괴 ${ar.destroy}%.\n룬 마지막 단계: 골드 ${rc.gold}·룬 가루 ${rc.dust}, 성공 ${rr.success}% / 유지 ${rr.fail}% / 강등 ${rr.downgrade}% / 파괴 ${rr.destroy}%.\n촉매는 갑옷·무기 +5·룬 +2부터 1회 최대 ${MAX_CATALYSTS}개, 1개당 성공 +9%p·파괴 -3%p(파괴 0% 하한). 최종 확률은 확인창에 표시.`,'data/upgrades.js');
 add('rule:monsterlevels','몬스터 레벨',['몬스터레벨','몹레벨','필드레벨','던전난이도'], 'RPG 몬스터 22종은 레벨에 따라 체력·공격·방어가 증가합니다. 초반 필드 Lv.1/5/10/15, 중반 Lv.20/30/40/55, 후반 Lv.70/90/115/145. 같은 종도 여러 레벨로 등장합니다. 10단계는 일반 Lv.145~220, 엘리트 Lv.220, 보스 Lv.260입니다. 무기·RPG 갑옷·장착 룬 전설 +10 수준의 4인 파티 권장선이며 장비 입장 제한은 없습니다. 고정 피해는 레벨 방어를 상쇄합니다.','data/monsterLevels.js');
 add('rule:dungeon','던전 입장·진행',['던전','던젼','보스제한시간','솔플','솔로보상','혼자던전'],`난이도 ${DUNGEON_TIERS.length}개. /rpg:dungeon에서 참가, /rpg:dungeonstart로 최대 ${DUNGEON.maxParty}명 출발. 혼자는 /rpg:dungeonsolo 1. 처음부터 혼자 출발하면 클리어 골드·강화석·룬 가루·촉매 1.5배(올림). 룬·보급품·처치 보상은 그대로입니다.\n파티는 일반 ${DUNGEON.normalCount}·엘리트 ${DUNGEON.eliteCount}마리를 ${DUNGEON.mobLimitMs/60000}분 안에 처치한 뒤 보스 1마리를 ${DUNGEON.bossLimitMs/60000}분 안에 잡습니다. 혼자 출발하면 전반 7분 30초·보스 4분 30초입니다. 몹이 없으면 후속 몹이 일찍 나옵니다. 전투 중 임의 퇴장 불가, 사망·완료·제한시간 종료로 귀환.\n종료 시 남은 아이템과 몹의 마크 XP를 피해+유효 회복 기여도에 따라 분배합니다. RPG 처치 XP는 기존 방식이며 가방 부족 전리품은 /rpg:dungeonloot로 받습니다.\n관리자 생성: /rpg:dungeoncreate 1 또는 all.`,'data/dungeons.js · core/dungeons.js');
 for(const d of DUNGEON_TIERS){const r=clearRewardForTier(d.tier),solo=clearRewardForTier(d.tier,true);add('dungeon:'+d.tier,`던전 ${d.tier} ${d.name}`,[d.name,'던전'+d.tier,d.tier+'번던전',d.tier+'단계던전',d.tier+'티어던전'],`난이도 ${d.tier}. 일반 Lv.${dungeonMonsterLevel(d.tier,'normal',0)}~${dungeonMonsterLevel(d.tier,'normal',2)}, 엘리트 Lv.${dungeonMonsterLevel(d.tier,'elite')}, 보스 Lv.${dungeonMonsterLevel(d.tier,'boss')}. 10단계는 전설 +10 세트 권장, 입장 제한 없음. 보스: ${bossName(d.boss)}.\n클리어 보상: 골드 ${r.gold}·강화석 ${r.stone}·룬 가루 ${r.dust}·촉매 ${r.catalysts}·룬 ${r.runes}개. 보급품 ${r.supplyMultiplier}배. 솔로 클리어는 골드 ${solo.gold}·강화석 ${solo.stone}·룬 가루 ${solo.dust}·촉매 ${solo.catalysts}입니다. 던전 엘리트는 다이아 1개 40%·3개 10%·없음 50%로 공동 전리품을 남깁니다. 클리어 시 네더라이트 주괴 1개 확률 ${Math.round(netheriteChanceForTier(d.tier)*100)}%(6~10단계 한정, 각자 추첨). 개별 몬스터 처치 재화는 별도.`,'data/dungeons.js');}
 add('rule:temple','해·달의 신전',['신전','해의신전','달의신전','천체신전'],'낮에는 해의 제단, 밤에는 달의 제단이 활성화되는 구조물입니다. 히든 직업의 전직 방법·조건은 안내하지 않습니다.','data/temple.js');
 add('rule:melee','추가 근접 피해 없는 기본 아이템',['근접피해없는직업','근접데미지없는직업','기본아이템피해'],`기본 아이템에 추가 근접 피해 설정이 없는 직업은 마법사·현자·궁수·천궁·성직자·천사·미카엘·타락천사입니다. 공격이 완전히 0인 뜻은 아니며 맨손 수준 기본 피해·힘·인챈트와 화살/스킬 피해는 별도입니다. 공용 전투검/전투창으로 근접 사냥을 보완할 수 있습니다.`,'items/*.json · data/jobs.js');
 add('rule:start','처음 시작',['초보','시작','처음','막혔','막힘'],`/rpg:guide의 견습 5계열 체험에서 시작 계열과 관계없이 검·마법·활·격투·회복 견습 장비를 바꿔 사용할 수 있습니다. 빵과 화살은 처음 한 번만 지급합니다. 첫 전직은 레벨 10과 각 직업 시련이 필요합니다. /rpg:jobs에서 현재 전직 조건, /rpg:craft에서 재료, /rpg:skillguide에서 기술을 확인하세요.`,'core/beginner.js · core/jobMenu.js');
 catalog=Object.freeze(entries);return catalog;
}
export function lookupRpgQuestion(question){
 const raw=String(question??'').trim();if(!raw)return {status:'empty',entries:[]};
 if(raw.length>QUESTION_LIMIT)return {status:'too_long',entries:[]};
 if(isBalanceQuestion(raw))return {status:'balance',entries:[]};
 if(isHiddenPromotionQuestion(raw))return {status:'hidden',entries:[]};
 const q=normalizeQuestion(raw);if(!q)return {status:'unknown',entries:[]};
 if(/전직(방법|조건|하는법|하려면|알려)|직업.*조건/.test(q)&&!Object.values(JOBS).some(j=>j.id!=='apprentice'&&q.includes(normalizeQuestion(j.name)))){return {status:'answer',entries:[{id:'rule:publicpromotions',title:'공개 전직 안내: 기본 직업 5종',body:knowledgeEntries().filter(e=>['job:swordsman','job:mage','job:archer','job:fighter','job:cleric'].includes(e.id)).map(e=>e.title+'\n'+e.body).join('\n\n'),source:'data/jobTrials.js'}],effect:true};}
 const named=knowledgeEntries().some(e=>e.id.startsWith('skill:')&&e.aliases.some(a=>q.includes(a)));
 const effect=!named&&effectKnowledge(q);if(effect)return {status:'answer',entries:[effect],effect:true};
 const ranked=knowledgeEntries().map(e=>({entry:e,score:Math.max(0,...e.aliases.filter(a=>q.includes(a)&&(!/[0-9]$/.test(a)||new RegExp(a+'(?![0-9])').test(q))).map(a=>a.length*10+(/등급|희귀도/.test(q)&&/^(weapon|armor|rune):/.test(e.id)?100:0)+(named&&/근력|마력|물리|마법|피해계열/.test(q)&&e.id.startsWith('skill:')?100:0)+(e.id.startsWith('skill:')?2:e.id.startsWith('rune:')?3:0)+(e.id.startsWith('craft:')&&/제작|만드|만들|조합|재료/.test(q)?5:0)))})).filter(e=>e.score>0).sort((a,b)=>b.score-a.score||a.entry.id.localeCompare(b.entry.id));
 return {status:ranked.length?'answer':'unknown',entries:ranked.slice(0,6).map(r=>r.entry)};
}
// Only canonical records may be rendered; remote services cannot inject answer text.
export function selectKnowledgeEntries(candidates,ids){
 if(!Array.isArray(ids)||ids.length>3||ids.some(id=>typeof id!=='string'))return undefined;
 const unique=[...new Set(ids)],selected=unique.map(id=>candidates.find(e=>e.id===id));
 return selected.some(e=>!e)?undefined:selected;
}
export function formatKnowledge(entries){
 if(!entries?.length)return UNKNOWN_ANSWER;
 return entries.slice(0,3).map(e=>`${e.title}\n${e.body}`).join('\n\n')+'\n\n자료: 이 애드온의 게임 도감 v0.5.73';
}
