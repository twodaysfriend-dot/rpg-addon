import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve('.'),rp=path.join(root,'RPG_RP_v0573');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const pose=read(path.join(root,'held_weapon_pose.json'));
const models=read(path.join(rp,'models/entity/upright_weapons.geo.json'))['minecraft:geometry'];
const animations=read(path.join(rp,'animations/upright_weapons.animation.json')).animations;
const eps=1e-7,near=(a,b)=>{assert.equal(a.length,b.length);a.forEach((x,i)=>assert.ok(Math.abs(x-b[i])<eps,`${a} != ${b}`));};
const minus=(a,b)=>a.map((x,i)=>x-b[i]),plus=(a,b)=>a.map((x,i)=>x+b[i]);
// Independent evaluator of the Bedrock -> Blockbench import: model X mirrors,
// rotation X/Y invert, and bones use ZYX order (rotate X, then Y, then Z).
function rotate(v,native){
 const [a,b,c]=[-native[0],-native[1],native[2]].map(x=>x*Math.PI/180);
 let [x,y,z]=v;[y,z]=[y*Math.cos(a)-z*Math.sin(a),y*Math.sin(a)+z*Math.cos(a)];
 [x,z]=[x*Math.cos(b)+z*Math.sin(b),-x*Math.sin(b)+z*Math.cos(b)];
 return [x*Math.cos(c)-y*Math.sin(c),x*Math.sin(c)+y*Math.cos(c),z];
}
function pixelInModel(model,face,[x,y]){
 const sprite=model.bones.find(b=>b.name==='sprite'),cube=sprite.cubes[0],uv=cube.uv[face];
 const from=[-cube.origin[0]-cube.size[0],cube.origin[1],cube.origin[2]],to=plus(from,cube.size);
 const u=(x-uv.uv[0])/uv.uv_size[0],v=(y-uv.uv[1])/uv.uv_size[1];
 const p=[face==='north'?to[0]+(from[0]-to[0])*u:from[0]+(to[0]-from[0])*u,to[1]+(from[1]-to[1])*v,0];
 const pivot=[-sprite.pivot[0],sprite.pivot[1],sprite.pivot[2]];
 return plus(pivot,rotate(minus(p,pivot),sprite.rotation));
}
const modelFor=s=>models.find(g=>g.description.identifier==='geometry.rpg.hand.'+s.id.slice(4));
test('every visible common/class weapon has a measured profile, real slot binding and double-size mesh',()=>{
 assert.equal(models.length,39);assert.equal(pose.items.length,39);
 for(const spec of pose.items){
  const m=modelFor(spec);assert.ok(m,spec.id);const [anchor,sprite]=m.bones;
  assert.equal(anchor.binding,'q.item_slot_to_bone_name(c.item_slot)');near(anchor.pivot,[0,24,0]);near(sprite.pivot,anchor.pivot);assert.equal(sprite.parent,anchor.name);
  assert.equal(sprite.cubes.length,1);assert.equal(sprite.cubes[0].size[0],32);assert.equal(spec.nativeSide*2,spec.heldSide);
  const a=read(path.join(rp,'attachables',spec.id.slice(4)+'.json'))['minecraft:attachable'].description;
  assert.equal(a.geometry.default,m.description.identifier);assert.equal(a.identifier,spec.id);
 }
});
test('actual north AND south UVs put each measured grip at the compensated hand, not at mirrored X or Y=0',()=>{
 for(const spec of pose.items){
  const m=modelFor(spec),grip=spec.gripPixel.map(x=>x+.5);
  for(const face of ['north','south'])near(pixelInModel(m,face,grip),[0,24,0]);
 }
});
test('grips stay at the palm through both camera rotations and idle/walking/swinging arm transforms',()=>{
 for(const spec of pose.items){const m=modelFor(spec);for(const mode of ['first','third']){
  const anchor=m.bones[0],p=[-anchor.pivot[0],anchor.pivot[1],anchor.pivot[2]],anim=animations['animation.rpg.hand.'+mode].bones[anchor.name];
  near(anim.position??[0,0,0],[0,0,0]);
  const g=plus(p,rotate(minus(pixelInModel(m,'north',spec.gripUv),p),anim.rotation));
  // Documented bind offset and right-hand guide put the grip inside the fist.
  const bound=plus(g,[6,-9,-1]);near(bound,[6,15,-1]);
  for(const arm of [[0,0,0],[25,0,-10],[-50,15,10]])near(rotate(minus(bound,[5,22,0]),arm),rotate([1,-7,-1],arm));
 }}
});
test('measured blade/shaft/upper-limb directions point up consistently on both texture faces',()=>{
 for(const spec of pose.items)for(const face of ['north','south']){
  const m=modelFor(spec),g=pixelInModel(m,face,spec.gripUv),tip=pixelInModel(m,face,spec.axisPixel.map(x=>x+.5)),delta=minus(tip,g);
  assert.ok(Math.abs(delta[0])<eps,spec.id);assert.ok(delta[1]>0,spec.id);
 }
});
test('first-person arm guide is compensated in the correct rotation convention and the broad face stays visible',()=>{
 const native=animations['animation.rpg.hand.first'].bones.hand_anchor.rotation;
 const up=rotate(rotate([0,1,0],native),[95,-45,115]);
 const normal=rotate(rotate([0,0,1],native),[95,-45,115]);
 near(up,rotate([0,1,0],[-60,20,-15]));
 assert.ok(up[1]>.5&&up[2]>.8);assert.ok(normal[2]>.45);
 near(animations['animation.rpg.hand.third'].bones.hand_anchor.rotation,[10,0,-10]);
});
test('original common pixels and every profiled PNG remain byte-identical; broad tokens no longer rotate sideways',()=>{
 for(const spec of pose.items){const data=fs.readFileSync(path.join(rp,spec.texture+'.png'));assert.equal(crypto.createHash('sha256').update(data).digest('hex'),spec.sha256);assert.equal(data.readUInt32BE(16),spec.imageSize[0]);assert.equal(data.readUInt32BE(20),spec.imageSize[1]);}
 for(const r of read(path.join(root,'original_weapon_texture_mapping.json')))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(rp,'textures/items/common_weapons',r.target))).digest('hex'),r.sha256);
 for(const id of ['rpg:michael_wings','rpg:fallen_angel_wings'])assert.equal(pose.items.find(s=>s.id===id).normalizeZ,0);
});
test('private War God first-person model and invisible fist models remain separate',()=>{
 assert.match(JSON.stringify(read(path.join(rp,'attachables/war_god_gauntlets.json'))),/context.is_first_person/);
 assert.deepEqual(read(path.join(rp,'models/entity/war_god_private.geo.json'))['minecraft:geometry'][0].bones[0].cubes[0].size,[16,16,.2]);
 assert.ok(!pose.items.some(s=>['rpg:war_god_gauntlets','rpg:fighter_fist','rpg:fist_bone_fist','rpg:apprentice_fist'].includes(s.id)));
});
