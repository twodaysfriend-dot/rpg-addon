import test,{afterEach} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,players,timeouts,world,system} from './minecraftMock.mjs';
import {requestDuel,acceptDuel,duelOf,duelOpponents,applyDuelDamage,finishDuel,isPk,markPk,recordPvpDeath,transferBounty,observePvpHurt,pvpBlocked,recoverPvpPlayer,notePvpAttack,pvpOwner} from '../RPG_BP_v0573/scripts/core/pvp.js';
import {getWallet,setWallet} from '../RPG_BP_v0573/scripts/core/wallet.js';
import {areAllies} from '../RPG_BP_v0573/scripts/core/social.js';
import {hurt} from '../RPG_BP_v0573/scripts/core/util.js';
let serial=0;
function actor(){const p=player('pvp'+serial++,30,{maxHealth:160,health:40});p.getTags=()=>[];p.hasTag=()=>false;p.addTag=()=>{};p.removeTag=()=>{};p.triggerEvent=id=>{p.floor=id==='rpg:duel_enter';};players.push(p);return p;}
function countdown(){system.currentTick+=60;for(const fn of timeouts.splice(0))fn();}
afterEach(()=>{for(const p of players){const d=duelOf(p);if(d)finishDuel(d,undefined,'test cleanup');}countdown();players.length=0;world.setDynamicProperty('rpg:pk_registry_v1',undefined);system.currentTick+=100;});
test('request does not heal, explicit acceptance heals both, and combat waits three seconds',()=>{
 const a=actor(),b=actor();requestDuel(a,b);assert.equal(a.health,40);assert.equal(duelOf(a),undefined);
 const d=acceptDuel(b);assert.equal(a.health,160);assert.equal(b.health,160);assert.equal(d.phase,'countdown');assert.equal(pvpBlocked(a,b),true);
 countdown();assert.equal(d.phase,'active');assert.equal(pvpBlocked(a,b),false);assert.equal(duelOpponents(a,b),true);
});
test('a stale modal cannot accept an invitation from another player and a busy recipient cannot be overwritten',()=>{
 const a=actor(),b=actor(),c=actor();requestDuel(a,b);assert.throws(()=>requestDuel(c,b),/응답 중/);assert.throws(()=>acceptDuel(b,c.id),/신청자가/);assert.equal(duelOf(b),undefined);
});
test('consented party/guild friends become opponents only for their duel',()=>{
 const a=actor(),b=actor();a.getTags=b.getTags=()=>['rpg_party_test'];a.hasTag=b.hasTag=()=>true;assert.equal(areAllies(a,b),true);
 requestDuel(a,b);acceptDuel(b);countdown();assert.equal(areAllies(a,b),false);finishDuel(duelOf(a),a);countdown();assert.equal(areAllies(a,b),true);
});
test('direct lethal attack ends a duel without player death, PK or bounty and protects delayed projectiles',()=>{
 const a=actor(),b=actor();setWallet(a,{gold:100,stone:0,dust:0});setWallet(b,{gold:100000,stone:0,dust:0});requestDuel(a,b);acceptDuel(b);countdown();
 const r=applyDuelDamage(a,b,99999);assert.equal(r.actual,159);assert.ok(b.health>0);assert.equal(duelOf(a),undefined);assert.equal(isPk(a),false);assert.equal(getWallet(a).gold,100);assert.equal(pvpBlocked(a,b),true);
 const before=b.health;assert.equal(hurt(b,a,99999,'fixed',{ignoreInvulnerability:true}),false);assert.equal(b.health,before);
 countdown();assert.equal(pvpBlocked(a,b),false);assert.equal(b.floor,false);
});
test('native damage reaching the health floor declares a winner without granting PK',()=>{
 const a=actor(),b=actor();requestDuel(a,b);acceptDuel(b);countdown();b.health=1;observePvpHurt({hurtEntity:b,damage:999,damageSource:{damagingEntity:a}});assert.equal(duelOf(a),undefined);assert.equal(isPk(a),false);assert.equal(b.health,160);
});
test('third-party PvP is blocked during a duel and cannot steal its outcome',()=>{
 const a=actor(),b=actor(),c=actor();requestDuel(a,b);acceptDuel(b);countdown();assert.equal(pvpBlocked(c,b),true);assert.equal(hurt(b,c,100,'fixed'),false);assert.ok(duelOf(b));
});
test('unconsented player kill gives persistent PK marker; environmental death and reconnect do not clear it',()=>{
 const a=actor(),b=actor();recordPvpDeath(a,b);assert.equal(isPk(a),true);system.currentTick++;recordPvpDeath(undefined,a);recoverPvpPlayer(a);assert.equal(isPk(a),true);assert.match(a.nameTag,/PK/);
});
test('a PK victim pays exactly 50000 from its wallet, hunter has no new PK, duplicates never pay twice',()=>{
 const killer=actor(),victim=actor();markPk(victim);setWallet(victim,{gold:70000,stone:4,dust:9});setWallet(killer,{gold:100,stone:1,dust:2});
 recordPvpDeath(killer,victim);assert.equal(getWallet(killer).gold,50100);assert.equal(getWallet(victim).gold,20000);assert.equal(isPk(killer),false);assert.equal(isPk(victim),false);recordPvpDeath(killer,victim);assert.equal(getWallet(killer).gold,50100);
});
test('insufficient bounty balance transfers only existing gold, without debt or currency creation',()=>{
 const a=actor(),b=actor();setWallet(a,{gold:0,stone:0,dust:0});setWallet(b,{gold:1234,stone:8,dust:9});assert.equal(transferBounty(a,b),1234);assert.equal(getWallet(a).gold+getWallet(b).gold,1234);assert.equal(getWallet(b).stone,8);
});
test('second wallet write failure restores both wallets and does not mint bounty',()=>{
 const a=actor(),b=actor();setWallet(a,{gold:100,stone:0,dust:0});setWallet(b,{gold:60000,stone:0,dust:0});const write=a.setDynamicProperty.bind(a);let fail=true;a.setDynamicProperty=(k,v)=>{if(k==='rpg:wallet_v1'&&fail){fail=false;throw Error('wallet write');}write(k,v);};assert.throws(()=>transferBounty(a,b));assert.equal(getWallet(a).gold,100);assert.equal(getWallet(b).gold,60000);
});
test('an outlaw does not add a new PK count by killing another outlaw',()=>{
 const a=actor(),b=actor();markPk(a);markPk(b);const before=JSON.parse(world.getDynamicProperty('rpg:pk_registry_v1')).pk[a.id].kills;recordPvpDeath(a,b);assert.equal(JSON.parse(world.getDynamicProperty('rpg:pk_registry_v1')).pk[a.id].kills,before);assert.equal(isPk(a),true);
});
test('native player definition preserves vanilla and adds only the temporary nonlethal health floor',()=>{
 const root=new URL('../',import.meta.url),base=JSON.parse(fs.readFileSync(new URL('vanilla_player_base.json',root)))['minecraft:entity'],now=JSON.parse(fs.readFileSync(new URL('RPG_BP_v0573/entities/player.json',root)))['minecraft:entity'];assert.deepEqual(now.components,base.components);assert.equal(now.component_groups['rpg:duel_safe']['minecraft:health'].min,1);assert.ok(now.events['rpg:duel_exit']);
});
test('a recent projectile hit still attributes an indirect death after its owner disconnects',()=>{
 const a=actor(),b=actor(),projectile={typeId:'minecraft:arrow',getComponent:()=>({owner:a})};assert.equal(pvpOwner(projectile),a);notePvpAttack(projectile,b,5);players.splice(players.indexOf(a),1);recordPvpDeath(undefined,b);assert.equal(isPk(a),true);
});
test('offline bounty is deducted once, escrowed, and delivered on reconnect without minting gold',()=>{
 const a=actor(),b=actor();setWallet(a,{gold:100,stone:0,dust:0});setWallet(b,{gold:60000,stone:0,dust:0});markPk(b);notePvpAttack(a,b,5);players.splice(players.indexOf(a),1);recordPvpDeath(undefined,b);assert.equal(getWallet(b).gold,10000);assert.equal(getWallet(a).gold,100);players.push(a);recoverPvpPlayer(a);assert.equal(getWallet(a).gold,50100);recoverPvpPlayer(a);assert.equal(getWallet(a).gold,50100);assert.equal(isPk(a),false);
});
test('ending a duel clears pre-duel hit attribution so later environmental death is not a PK',()=>{
 const a=actor(),b=actor();notePvpAttack(a,b,5);requestDuel(a,b);acceptDuel(b);countdown();finishDuel(duelOf(a),a);countdown();recordPvpDeath(undefined,b);assert.equal(isPk(a),false);
});
test('unavailable native duel health protection aborts acceptance and cleans up both players',()=>{
 const a=actor(),b=actor();b.triggerEvent=id=>{if(id==='rpg:duel_enter')throw Error('missing player event');b.floor=false;};requestDuel(a,b);assert.throws(()=>acceptDuel(b),/보호 플레이어 정의/);assert.equal(duelOf(a),undefined);assert.equal(duelOf(b),undefined);assert.equal(a.floor,false);assert.equal(b.floor,false);assert.equal(a.getDynamicProperty('rpg:duel_recover'),undefined);
});
test('a silently ignored player event cannot start an unprotected native duel',()=>{
 const a=actor(),b=actor();b.triggerEvent=()=>{};requestDuel(a,b);assert.throws(()=>acceptDuel(b),/보호 플레이어 정의/);assert.equal(duelOf(a),undefined);assert.equal(a.floor,false);assert.equal(b.health,40);
});
