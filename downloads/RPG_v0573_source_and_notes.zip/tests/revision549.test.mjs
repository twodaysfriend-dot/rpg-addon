import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,players,ItemStack,system,intervals} from './minecraftMock.mjs';
import {currencyReward} from '../RPG_BP_v0573/scripts/core/economy.js';
import {vanillaRuneChance,rollVanillaRune} from '../RPG_BP_v0573/scripts/core/runeDrops.js';
import {mobXp} from '../RPG_BP_v0573/scripts/data/mobXp.js';
import {skillDamageFor} from '../RPG_BP_v0573/scripts/core/stats.js';
import {ccTicks,applyStatus} from '../RPG_BP_v0573/scripts/core/crowdControl.js';
import {knockback,push} from '../RPG_BP_v0573/scripts/core/util.js';
import {RUNNERS as FROST,registerFrost} from '../RPG_BP_v0573/scripts/skills/frost.js';
import {SKILLS} from '../RPG_BP_v0573/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0573/scripts/data/jobs.js';
import {ARMOR_SETS} from '../RPG_BP_v0573/scripts/data/equipment.js';
import {getEquipmentBonuses,registerEquipment} from '../RPG_BP_v0573/scripts/core/equipment.js';
import {creditDungeonClear,readDungeonLoot} from '../RPG_BP_v0573/scripts/core/dungeonRewards.js';
import {clearRewardForTier} from '../RPG_BP_v0573/scripts/data/dungeons.js';
import {getWallet,setWallet} from '../RPG_BP_v0573/scripts/core/wallet.js';
import {ARMOR_LEVEL_KEY} from '../RPG_BP_v0573/scripts/data/upgrades.js';
import {extractArmorEnhancement,applyArmorEnhancement,transferFingerprint,readTransferSeal,TRANSFER_SEAL} from '../RPG_BP_v0573/scripts/core/armorTransfer.js';
const bp=new URL('../RPG_BP_v0573/',import.meta.url),json=path=>JSON.parse(fs.readFileSync(new URL(path,bp)));
const armor=(set='adventurer',part='chestplate',level=7)=>{const i=new ItemStack('rpg:'+set+'_'+part);i.setDynamicProperty(ARMOR_LEVEL_KEY,level);i.setLore(['personal lore',`§7강화: +${level}`]);i.nameTag='my armor';return i;};
const source={kind:'inventory',slot:2},dest={kind:'inventory',slot:3};let seq=0;
function ready(){const p=player('transfer-'+seq++);p.slots[2]=armor();p.slots[3]=armor('abyssal','chestplate',1);setWallet(p,{gold:10000,stone:22,dust:33});return p;}
test('silverfish farm retains five XP but gives two gold, no enhancement currency, and 0.1% runes',()=>{
 assert.deepEqual(currencyReward('minecraft:silverfish'),{gold:2,stone:0,dust:0});assert.equal(mobXp('minecraft:silverfish'),5);assert.equal(vanillaRuneChance('minecraft:silverfish'),.001);
 assert.equal(rollVanillaRune('minecraft:silverfish',()=>.00099),'rpg:rune_power');assert.equal(rollVanillaRune('minecraft:silverfish',()=>.001),undefined);
 assert.equal(currencyReward('minecraft:zombie',()=>0).gold,114);assert.equal(vanillaRuneChance('minecraft:zombie'),.01);
});
test('Strength buffs single and multiple hits by the same percent while fixed damage is identical',()=>{
 const p=player('percent');p.addEffect('strength',100,{amplifier:1});
 assert.equal(skillDamageFor(p,40,'physical'),44);assert.equal(skillDamageFor(p,10,'physical')*6,66);assert.equal(skillDamageFor(p,10,'magic')*6,66);assert.equal(skillDamageFor(p,60,'fixed'),60);
});
test('all supported bosses receive half-duration CC, while poison, buffs, normal mobs and players are unchanged',()=>{
 for(const typeId of ['rpg:rock_golem_boss','rpg:cyclops_boss','rpg:hydra_boss','rpg:tech_block_golem_boss','minecraft:ender_dragon','minecraft:wither','minecraft:warden']){
  const t=player(typeId,1,{typeId});assert.equal(ccTicks(t,41),21);
  for(const id of ['slowness','weakness','mining_fatigue','blindness','darkness','levitation']){applyStatus(t,id,100,{amplifier:2});assert.equal(t.getEffect(id).duration,50);assert.equal(t.getEffect(id).amplifier,2);}
  for(const id of ['poison','wither','strength']){applyStatus(t,id,100,{amplifier:1});assert.equal(t.getEffect(id).duration,100);}
 }
 for(const typeId of ['minecraft:player','minecraft:zombie','rpg:elite_green_goblin'])assert.equal(ccTicks(player(typeId,1,{typeId}),100),100);
});
test('boss knockback and impulse scale once without changing normal targets',()=>{
 for(const [typeId,scale]of [['rpg:hydra_boss',.5],['minecraft:zombie',1]]){
  const t=player(typeId,1,{typeId});let k,v;t.applyKnockback=(force,y)=>{k={force,y};};t.applyImpulse=vector=>{v=vector;};knockback(t,1,0,4,2);push(t,4,2,6);
  assert.deepEqual(k,{force:{x:4*scale,z:0},y:2*scale});assert.deepEqual(v,{x:4*scale,y:2*scale,z:6*scale});
 }
});
test('actual frost root and native slowness expire together at half duration on bosses',()=>{
 registerFrost();const update=intervals.at(-1);
 for(const [typeId,duration]of [['rpg:hydra_boss',20],['minecraft:zombie',40]]){
  const p=player('frost-'+typeId),t=player('frozen-'+typeId,1,{typeId,health:500,location:{x:0,y:64,z:2}});
  const dim={id:'minecraft:overworld',getEntities:()=>[t],getBlock:()=>({isSolid:false}),spawnParticle(){},playSound(){}};p.dimension=t.dimension=dim;p.getViewDirection=()=>({x:0,y:0,z:1});t.applyDamage=()=>true;t.teleport=at=>{t.location={...at};};system.currentTick=100;
  assert.equal(FROST.frost_grasp(p,JOBS.frost_controller,SKILLS.frost_grasp),true);assert.equal(t.getEffect('slowness').duration,duration);
  t.location.z=3;system.currentTick=100+duration-1;update();assert.equal(t.location.z,2);t.location.z=3;system.currentTick=100+duration;update();assert.equal(t.location.z,3);
 }
});
test('extraction and application preserve total enhancement, lore/name, other currencies and create a single-use part seal',()=>{
 const p=ready(),r=extractArmorEnhancement(p,source,transferFingerprint(p.slots[2]));assert.equal(r.ok,true);assert.equal(r.cost,3500);assert.equal(p.slots[2].getDynamicProperty(ARMOR_LEVEL_KEY),0);assert.equal(p.slots[2].nameTag,'my armor');assert.ok(p.slots[2].getLore().includes('personal lore'));assert.deepEqual(getWallet(p),{gold:6500,stone:22,dust:33});
 assert.deepEqual(readTransferSeal(p.slots[r.slot]),{level:7,part:'chestplate'});assert.equal(applyArmorEnhancement(p,r.slot,dest).ok,true);assert.equal(p.slots[3].getDynamicProperty(ARMOR_LEVEL_KEY),7);assert.equal(p.slots[r.slot],undefined);assert.equal(applyArmorEnhancement(p,r.slot,dest).ok,false);
});
test('equipped armor can be extracted and enhanced inventory armor can receive it',()=>{
 const p=ready(),eqref={kind:'equipment',slot:'Chest'};p.equipment.set('Chest',p.slots[2]);p.slots[2]=undefined;const r=extractArmorEnhancement(p,eqref);assert.equal(r.ok,true);assert.equal(p.equipment.get('Chest').getDynamicProperty(ARMOR_LEVEL_KEY),0);assert.equal(applyArmorEnhancement(p,r.slot,dest).ok,true);
});
test('extraction refuses full bags, insufficient gold and stale item confirmation without touching armor',()=>{
 for(const mode of ['full','money','stale']){
  const p=ready(),original=transferFingerprint(p.slots[2]);if(mode==='full')for(let i=1;i<p.slots.length;i++)if(!p.slots[i])p.slots[i]=new ItemStack('minecraft:stone',64);if(mode==='money')setWallet(p,{gold:1,stone:2,dust:3});
  const wallet=getWallet(p),r=extractArmorEnhancement(p,source,mode==='stale'?'wrong':original);assert.equal(r.ok,false);assert.equal(transferFingerprint(p.slots[2]),original);assert.deepEqual(getWallet(p),wallet);
 }
});
test('invalid, forged, mismatched, stale and weaker seals cannot upgrade or overwrite a target',()=>{
 const p=ready(),r=extractArmorEnhancement(p,source),seal=p.slots[r.slot];assert.equal(applyArmorEnhancement(p,r.slot,dest,'wrong').ok,false);
 p.slots[3]=armor('abyssal','helmet',0);assert.equal(applyArmorEnhancement(p,r.slot,dest).ok,false);p.slots[3]=armor('abyssal','chestplate',10);assert.equal(applyArmorEnhancement(p,r.slot,dest).ok,false);assert.equal(p.slots[r.slot],seal);
 for(const i of [new ItemStack(TRANSFER_SEAL),new ItemStack(TRANSFER_SEAL,2)])assert.equal(readTransferSeal(i),undefined);
});
test('failed extraction inventory write restores source armor, wallet and empty seal slot',()=>{
 const p=ready(),before=transferFingerprint(p.slots[2]),wallet=getWallet(p),inv=p.getComponent('minecraft:inventory').container,write=inv.setItem;let fail=true;inv.setItem=(slot,item)=>{if(fail&&item?.typeId===TRANSFER_SEAL){fail=false;throw Error('write');}write(slot,item);};assert.equal(extractArmorEnhancement(p,source).ok,false);assert.equal(transferFingerprint(p.slots[2]),before);assert.deepEqual(getWallet(p),wallet);assert.ok(!p.slots.some(i=>i?.typeId===TRANSFER_SEAL));
});
test('failed seal consumption restores target and seal, so retries cannot duplicate enhancements',()=>{
 const p=ready(),r=extractArmorEnhancement(p,source),before=transferFingerprint(p.slots[3]),seal=transferFingerprint(p.slots[r.slot]),inv=p.getComponent('minecraft:inventory').container,write=inv.setItem;let fail=true;inv.setItem=(slot,item)=>{if(slot===r.slot&&!item&&fail){fail=false;throw Error('remove');}write(slot,item);};assert.equal(applyArmorEnhancement(p,r.slot,dest).ok,false);assert.equal(transferFingerprint(p.slots[3]),before);assert.equal(transferFingerprint(p.slots[r.slot]),seal);assert.equal(applyArmorEnhancement(p,r.slot,dest).ok,true);
});
test('abyssal armor matches netherite armor points and exceeds each durability, with survival recipes and visible attachables',()=>{
 const expected=[['helmet',3,407],['chestplate',8,592],['leggings',6,555],['boots',3,481]];
 for(const [part,protection,durability]of expected){const c=json('items/abyssal_'+part+'.json')['minecraft:item'].components;assert.equal(c['minecraft:wearable'].protection,protection);assert.ok(c['minecraft:durability'].max_durability>durability);assert.equal(c['minecraft:max_stack_size'],1);assert.ok(json('recipes/abyssal_'+part+'.json')['minecraft:recipe_shapeless'].ingredients.some(i=>i.item==='minecraft:netherite_ingot'));const a=JSON.parse(fs.readFileSync(new URL('../RPG_RP_v0573/attachables/abyssal_'+part+'.json',import.meta.url)));assert.equal(a['minecraft:attachable'].description.identifier,'rpg:abyssal_'+part);}
 assert.equal(ARMOR_SETS.abyssal.protection.reduce((a,b)=>a+b),20);
});
test('abyssal full-set HP, physical/magic and resistance actually apply; missing piece removes set bonus',()=>{
 const p=player('abyssal');for(const [slot,part]of [['Head','helmet'],['Chest','chestplate'],['Legs','leggings'],['Feet','boots']])p.equipment.set(slot,armor('abyssal',part,0));let b=getEquipmentBonuses(p);assert.equal(b.health,16);assert.equal(b.physical,1.08);assert.equal(b.magic,1.08);assert.equal(b.ward,true);players.push(p);registerEquipment();intervals.at(-1)();assert.equal(p.getEffect('resistance').amplifier,0);p.equipment.delete('Head');b=getEquipmentBonuses(p);assert.equal(b.health,0);assert.equal(b.ward,false);
});
test('common weapons are craftable and unlocked for all jobs, without replacing or impersonating job cast items',()=>{
 for(const name of ['common_battle_sword','common_battle_spear']){
  const d=json('items/'+name+'.json')['minecraft:item'],c=d.components;assert.ok(c['minecraft:damage']>=7);assert.ok(c['minecraft:durability'].max_durability>=800);assert.equal(c['rpg:cast_item'],undefined);assert.ok(json('recipes/'+name+'.json')['minecraft:recipe_shapeless'].ingredients.length<=9);assert.ok(!Object.values(JOBS).some(j=>j.weapon==='rpg:'+name));
 }
});
test('solo clear bonus affects currencies/catalysts exactly once, leaves runes/supplies unchanged, and persists in ledger',()=>{
 for(const tier of [1,10]){
  const normal=clearRewardForTier(tier),solo=clearRewardForTier(tier,true);for(const key of ['gold','stone','dust','catalysts'])assert.equal(solo[key],Math.ceil(normal[key]*1.5));assert.equal(solo.runes,normal.runes);assert.equal(solo.supplyMultiplier,normal.supplyMultiplier);
  const p=player('solo-'+tier);creditDungeonClear(p,tier,tier,true);const before=getWallet(p);assert.equal(before.gold,solo.gold);assert.equal(readDungeonLoot(p).pending['rpg:enhancement_catalyst'],solo.catalysts);creditDungeonClear(p,tier,tier,true);assert.deepEqual(getWallet(p),before);
 }
});
