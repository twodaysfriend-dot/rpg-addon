# RPG v0.6.72 · 피의 낫과 블라디미르 전투 연출

- 피의 낫은 제공된 붉은 낫 이미지를 바탕으로 낫날, 금속 장식, 손잡이를 감싸는 붉은 띠를 살린 512×512 텍스처를 사용합니다.
- 블러드 배리어는 플레이어의 전방에 반투명한 붉은 방어막을 펼칩니다. 공격을 막으면 방어막이 빛나고, 해제될 때는 반경 14칸으로 붉은 파동이 퍼집니다.
- 혈액 난사는 시전자 주변 360도로 파편 24발을 동시에 발사합니다. 파편의 좌우 방향과 상하 각도는 시전마다 달라집니다. 마나 30, 쿨타임 0초, 발당 기본 마법 피해 4, 대상당 최대 10발입니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.72로 활성화하고 월드를 다시 여세요. 모의 전투에서 방어막 발동·방어·해제, 파편의 360도 분산, 시전마다 다른 탄도, 대상당 적중 상한을 검증했습니다. 실제 Bedrock 화면에서의 렌더링은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0672
```
