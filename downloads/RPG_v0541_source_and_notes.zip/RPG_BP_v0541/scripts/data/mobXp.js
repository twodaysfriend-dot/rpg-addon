// RPG XP is independent of vanilla experience orbs.
export const VANILLA_HOSTILES=new Set(['zombie','husk','drowned','skeleton','stray','bogged','wither_skeleton','spider','cave_spider','creeper','witch','slime','magma_cube','phantom','endermite','enderman','blaze','ghast','pillager','vindicator','evocation_illager','evoker','vex','ravager','guardian','elder_guardian','piglin','piglin_brute','hoglin','zoglin','shulker','breeze','creaking']);
const ZERO=new Set(['minecraft:player','minecraft:armor_stand','minecraft:item','minecraft:xp_orb','minecraft:npc','minecraft:agent','rpg:sandbag_entity','rpg:tech_prison_dome']);
const BOSSES={'rpg:rock_golem_boss':450,'rpg:cyclops_boss':600,'rpg:hydra_boss':900,'rpg:tech_block_golem_boss':850,'minecraft:ender_dragon':600,'minecraft:wither':500,'minecraft:warden':250};
export function mobXp(typeId=''){
 if(ZERO.has(typeId)||!typeId)return 0;
 if(BOSSES[typeId]!==undefined)return BOSSES[typeId];
 if(['minecraft:silverfish','minecraft:zombie_pigman','minecraft:zombified_piglin'].includes(typeId))return 5;
 if(typeId.startsWith('minecraft:'))return VANILLA_HOSTILES.has(typeId.slice(10))?30:10;
 return 20;
}
