import { world } from '@minecraft/server';
import { JOB_TRIALS } from '../data/jobTrials.js';
import { JOBS } from '../data/jobs.js';
import { getProgress,getJobId } from './playerData.js';
import { beginnerAdvanceUnlocked } from './beginnerData.js';
import { isBeginnerTarget } from './beginnerData.js';
import {VANILLA_HOSTILES} from '../data/mobXp.js';
export function jobTrialStatus(p,target){
  const rule=JOB_TRIALS[target?.id];if(!rule)return null;
  const progress=getProgress(p),level=Number(p.getDynamicProperty('rpg:rpg_level'))||1;
  const checks=[{met:level>=rule.level,text:`레벨 ${level}/${rule.level}`}];
  if(rule.starter)checks.push({met:beginnerAdvanceUnlocked(p,target),text:'선택 계열 첫 사냥 5마리 보상 수령'});
  for(const c of rule.all??[])checks.push({met:(progress[c.key]??0)>=c.need,text:`${c.label} ${Math.min(progress[c.key]??0,c.need)}/${c.need}`});
  if(rule.any?.length){const met=rule.any.some(c=>(progress[c.key]??0)>=c.need);checks.push({met,text:rule.any.map(c=>`${c.label} ${Math.min(progress[c.key]??0,c.need)}/${c.need}`).join(' 또는 ')});}
  return {met:checks.every(c=>c.met),have:checks.filter(c=>c.met).length,need:checks.length,label:checks.map(c=>(c.met?'§a✔ ':'§e· ')+c.text).join('\n'),checks};
}
export const TRIAL_BOSSES=new Set(['rpg:rock_golem_boss','rpg:cyclops_boss','rpg:hydra_boss','rpg:tech_block_golem_boss','minecraft:ender_dragon','minecraft:wither','minecraft:warden']);
const BOSS=TRIAL_BOSSES;
const OTHER_HOSTILES=new Set(['minecraft:guardian','minecraft:elder_guardian','minecraft:piglin','minecraft:piglin_brute','minecraft:zombie_pigman','minecraft:hoglin','minecraft:zoglin','minecraft:shulker','minecraft:breeze']);
export function isTrialTarget(id){return isBeginnerTarget(id)||BOSS.has(id)||OTHER_HOSTILES.has(id)||(id?.startsWith('minecraft:')&&VANILLA_HOSTILES.has(id.slice(10)))||['minecraft:silverfish','minecraft:zombified_piglin'].includes(id);}
export function recordJobTrialKill(p,entity){
  const id=entity?.typeId;if(!isTrialTarget(id))return;
  const mode=String(p.getGameMode()).toLowerCase();if(mode==='creative'||mode==='spectator')return;
  const progress=getProgress(p),bump=(key,n=1)=>{progress[key]=Math.min(1000000,(Number(progress[key])||0)+n);};
  bump('job_kills');const job=JOBS[getJobId(p)];if(job)bump('line_'+job.line);
  if(id.startsWith('rpg:elite_'))bump('job_elite');if(BOSS.has(id))bump('job_boss');
  if(['minecraft:zombie','minecraft:husk','minecraft:drowned','minecraft:skeleton','minecraft:stray','minecraft:bogged','minecraft:wither_skeleton','minecraft:phantom'].includes(id))bump('job_undead');
  for(const [type,key]of [['minecraft:stray','job_stray'],['minecraft:blaze','job_blaze'],['minecraft:drowned','job_drowned'],['minecraft:enderman','job_enderman']])if(id===type)bump(key);
  if(p.dimension.id==='minecraft:nether'||p.dimension.id==='nether')bump('job_nether');
  if(['minecraft:overworld','overworld'].includes(p.dimension.id)){const time=world.getTimeOfDay();bump(time<12000?'job_day':'job_night');}
  const types=Array.isArray(progress.job_types)?progress.job_types:[];if(!types.includes(id)&&types.length<200)types.push(id);progress.job_types=types;progress.job_unique=types.length;
  p.setDynamicProperty('rpg:progress',JSON.stringify(progress));
}
