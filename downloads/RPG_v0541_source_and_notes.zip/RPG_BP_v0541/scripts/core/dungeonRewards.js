import { ItemStack } from '@minecraft/server';
import { getWallet,setWallet,creditWallet } from './wallet.js';
import { CATALYST_ID } from '../data/upgrades.js';
import { CLEAR_REWARD,clearRewardForTier,RUNE_CYCLE,ARMOR_KIT,SUPPLIES } from '../data/dungeons.js';
export const DUNGEON_LOOT_KEY='rpg:dungeon_loot_v1';
export function readDungeonLoot(p){
 const raw=p.getDynamicProperty(DUNGEON_LOOT_KEY);
 if(raw===undefined)return {version:1,clears:0,receipts:[],pending:{}};
 const s=JSON.parse(raw);
 if(s.version!==1||!Number.isSafeInteger(s.clears)||s.clears<0||!Array.isArray(s.receipts)||!s.pending||typeof s.pending!=='object')throw Error('던전 보상 저장 데이터 오류');
 for(const [id,n]of Object.entries(s.pending))if(!/^[a-z0-9_:]+$/.test(id)||!Number.isSafeInteger(n)||n<0)throw Error('던전 보급 수량 오류');
 return s;
}
export function creditDungeonClear(p,runId,tier=1){
 const before=p.getDynamicProperty(DUNGEON_LOOT_KEY),s=readDungeonLoot(p);
 if(s.receipts.includes(runId))return {ok:true,duplicate:true};
 if(!Number.isSafeInteger(runId)||runId<1)throw Error('던전 보상 번호 오류');
 const wallet=getWallet(p);s.clears++;
 const add=(id,n=1)=>{s.pending[id]=(s.pending[id]??0)+n;};
 const reward=clearRewardForTier(tier),cats=reward.catalysts+(s.clears%CLEAR_REWARD.bonusEvery===0?1:0);
 add(CATALYST_ID,cats);for(const [id,n]of Object.entries(SUPPLIES))add(id,n*reward.supplyMultiplier);
 for(let i=0;i<reward.runes;i++)add('rpg:rune_'+RUNE_CYCLE[(s.clears-1+i)%RUNE_CYCLE.length]);
 if(s.clears===1)for(const id of ARMOR_KIT)add('rpg:'+id);
 s.receipts.push(runId);s.receipts=s.receipts.slice(-64);
 const encoded=JSON.stringify(s);if(encoded.length>29000)throw Error('보급함이 가득 찼습니다. /rpg:dungeonloot');
 try{creditWallet(p,reward);p.setDynamicProperty(DUNGEON_LOOT_KEY,encoded);}
 catch(error){setWallet(p,wallet);p.setDynamicProperty(DUNGEON_LOOT_KEY,before);throw error;}
 return {ok:true,catalysts:cats,clears:s.clears};
}
// Slot 0 is reserved for the RPG weapon. Plan the entire inventory change first. A full bag leaves rewards in storage.
export function claimDungeonLoot(p){
 const before=p.getDynamicProperty(DUNGEON_LOOT_KEY),s=readDungeonLoot(p),c=p.getComponent('minecraft:inventory')?.container;
 if(!c)throw Error('인벤토리를 사용할 수 없습니다.');
 const old=Array.from({length:c.size},(_,i)=>c.getItem(i)?.clone()),next=old.map(it=>it?.clone());const changed=new Set();let delivered=0;
 for(const [id,count]of Object.entries(s.pending)){
  let left=count;const template=new ItemStack(id,1),cap=template.maxAmount??(id.startsWith('rpg:adventurer_')?1:64);
  for(let i=1;i<next.length&&left;i++)if(next[i]?.isStackableWith?.(template)){
   const take=Math.min(left,cap-next[i].amount);if(take>0){next[i].amount+=take;left-=take;changed.add(i);}
  }
  for(let i=1;i<next.length&&left;i++)if(!next[i]){const take=Math.min(left,cap);next[i]=new ItemStack(id,take);left-=take;changed.add(i);}
  delivered+=count-left;if(left)s.pending[id]=left;else delete s.pending[id];
 }
 if(!delivered)return {delivered:0,pending:Object.values(s.pending).reduce((a,n)=>a+n,0)};
 const written=[];
 try{
  for(const i of changed){written.push(i);c.setItem(i,next[i]);}
  p.setDynamicProperty(DUNGEON_LOOT_KEY,JSON.stringify(s));
 }catch(error){for(const i of written)c.setItem(i,old[i]);p.setDynamicProperty(DUNGEON_LOOT_KEY,before);throw error;}
 return {delivered,pending:Object.values(s.pending).reduce((a,n)=>a+n,0)};
}
