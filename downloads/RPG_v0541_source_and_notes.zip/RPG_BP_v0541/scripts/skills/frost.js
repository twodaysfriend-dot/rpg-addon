import {teleportForSkill} from '../core/dungeonMovement.js';
import { areAllies } from "../core/social.js";
import { world, system } from '@minecraft/server';
import { CONFIG } from '../config.js';
import { getTargets, hurt as hurtBase, headPos, flatDir, norm3, dist3, isSolidAt, particle, sound, healthAlive } from '../core/util.js';
import { notify } from '../core/hud.js';

// 히든 직업 냉기 능력자: 모든 시각 효과는 지름 0.15~0.21블럭의 작은 픽셀 파티클.
const SHARD='rpg:frost_shard';
const DUST='rpg:frost_dust';
const SEAL='rpg:frost_seal';
const TEAM_PREFIX='rpg_team_';
const frozen=new Map();
let started=false;

function valid(e){try{return !!e?.isValid && healthAlive(e);}catch{return false;}}
function enemy(p,e){
  if(!valid(e)||e.id===p.id||areAllies(p,e))return false;
  if(e.typeId==='minecraft:player'){
    if(!CONFIG.pvp)return false;
    const team=p.getTags().find(t=>t.startsWith(TEAM_PREFIX));
    if(team && e.hasTag(team))return false;
  }
  return true;
}
function fx(p,id,ticks,amplifier=0){try{p.addEffect(id,ticks,{amplifier,showParticles:false});}catch{}}
function at(e,y=1){const p=e.location;return {x:p.x,y:p.y+y,z:p.z};}
function ring(dim,center,r,id,n=18,y=0){
  for(let i=0;i<n;i++){
    const a=i*2*Math.PI/n;
    particle(dim,id,{x:center.x+Math.cos(a)*r,y:center.y+y,z:center.z+Math.sin(a)*r});
  }
}
function trail(dim,from,to,id,spacing=.6){
  const steps=Math.min(65,Math.max(1,Math.ceil(dist3(from,to)/spacing)));
  for(let i=0;i<=steps;i++){
    const t=i/steps;
    particle(dim,id,{x:from.x+(to.x-from.x)*t,y:from.y+(to.y-from.y)*t,z:from.z+(to.z-from.z)*t});
  }
}
function hasSpace(dim,p,needsGround=true){
  return !isSolidAt(dim,{x:p.x,y:p.y+.15,z:p.z})&&
    !isSolidAt(dim,{x:p.x,y:p.y+1.5,z:p.z})&&
    (!needsGround||isSolidAt(dim,{x:p.x,y:p.y-.8,z:p.z}));
}
function freeze(target,ticks){
  if(!valid(target))return;
  const old=frozen.get(target.id);
  frozen.set(target.id,{
    entity:target,dimensionId:target.dimension.id,
    position:old?.position??{...target.location},
    expires:Math.max(old?.expires??0,system.currentTick+ticks),
  });
  fx(target,'slowness',ticks,255);
  fx(target,'weakness',ticks,4);
  fx(target,'mining_fatigue',ticks,4);
  ring(target.dimension,at(target,.9),.7,SEAL,12);
}

// 궤적에 얇은 얼음 픽셀이 남고 적/벽에서 사라지는 실제 투사체 판정.
function shoot(p,dir,range,speed,damage,extra,{offset=0,fxId=SHARD}={}){
  const dim=p.dimension,eye=headPos(p),from={x:eye.x+dir.x*.7,y:eye.y+dir.y*.7,z:eye.z+dir.z*.7};
  let travel=offset;
  const ticker=system.runInterval(()=>{
    try{
      if(!p.isValid||p.dimension.id!==dim.id||travel>=range){system.clearRun(ticker);return;}
      for(let sub=0;sub<3;sub++){
        travel+=speed/3;
        const v={x:from.x+dir.x*travel,y:from.y+dir.y*travel,z:from.z+dir.z*travel};
        if(isSolidAt(dim,v)){particle(dim,DUST,v);system.clearRun(ticker);return;}
        particle(dim,fxId,v);
        if(sub===0)particle(dim,DUST,{x:v.x,y:v.y-.13,z:v.z});
        const target=getTargets(p,v,1.1,.9).find(e=>enemy(p,e));
        if(target){
          hurt(target,p,damage);
          extra?.(target,v);
          ring(dim,v,.4,DUST,9);
          system.clearRun(ticker);return;
        }
      }
    }catch{system.clearRun(ticker);}
  },1);
}
function shard(p,job,def){
  const v=norm3(p.getViewDirection());
  shoot(p,v,def.range,def.speed,def.damage,t=>fx(t,'slowness',def.slowTicks,1));
  sound(p.dimension,'mob.guardian.attack',p.location,{volume:.45,pitch:1.45});return true;
}
function grasp(p,job,def){
  const eye=headPos(p),v=norm3(p.getViewDirection());
  let nearest=null, best=Infinity;
  for(const t of getTargets(p,p.location,def.range+1)){
    if(!enemy(p,t))continue;
    const h=at(t,1),dx=h.x-eye.x,dy=h.y-eye.y,dz=h.z-eye.z,d=Math.hypot(dx,dy,dz)||1;
    if(d>def.range||((dx*v.x+dy*v.y+dz*v.z)/d)<.7||d>=best)continue;
    // 벽 너머의 엔티티는 얼리지 않습니다.
    let blocked=false;
    for(let s=.5;s<d;s+=.5){if(isSolidAt(p.dimension,{x:eye.x+dx*s/d,y:eye.y+dy*s/d,z:eye.z+dz*s/d})){blocked=true;break;}}
    if(!blocked){nearest=t;best=d;}
  }
  if(!nearest){notify(p,'§7빙결의 손: 가까운 정면에 적이 없습니다.');return false;}
  hurt(nearest,p,def.damage);freeze(nearest,def.freezeTicks);
  trail(p.dimension,eye,at(nearest,1),SHARD,.35);
  sound(p.dimension,'random.glass',nearest.location,{volume:.75,pitch:.7});
  notify(p,'§b빙결의 손: §f대상 2초 동결');return true;
}
function barrage(p,job,def){
  const v=norm3(p.getViewDirection());
  const side=norm3({x:-v.z,y:0,z:v.x});
  const up=norm3({x:-v.x*v.y,y:Math.hypot(v.x,v.z),z:-v.z*v.y});
  for(let i=0;i<def.shots;i++){
    const spread=(i-(def.shots-1)/2)*def.spread;
    const dir=norm3({x:v.x+side.x*spread+up.x*Math.sin(i*2.3)*.05,
      y:v.y+side.y*spread+up.y*Math.sin(i*2.3)*.05,
      z:v.z+side.z*spread+up.z*Math.sin(i*2.3)*.05});
    // 날아가는 타이밍을 각각 조금씩 달리해 눈보라처럼 퍼짐
    system.runTimeout(()=>{if(p.isValid)shoot(p,dir,def.range,def.speed,def.damage,(target)=>fx(target,'slowness',50,1));},i*2);
  }
  sound(p.dimension,'mob.guardian.attack',p.location,{volume:.8,pitch:1.2});return true;
}
function iceStep(p,job,def){
  const start={...p.location},dir=flatDir(p),dim=p.dimension;
  let dest=null;
  for(let d=def.distance;d>=1;d-=.5){
    const candidate={x:start.x+dir.x*d,y:start.y,z:start.z+dir.z*d};
    if(!hasSpace(dim,candidate))continue;
    let clear=true;
    for(let s=.5;s<d;s+=.5){if(!hasSpace(dim,{x:start.x+dir.x*s,y:start.y,z:start.z+dir.z*s},false)){clear=false;break;}}
    if(clear){dest=candidate;break;}
  }
  if(!dest){notify(p,'§7빙하보: 앞에 이동 가능한 공간이 없습니다.');return false;}
  trail(dim,at(p,.4),{x:dest.x,y:dest.y+.4,z:dest.z},DUST,.5);
  try{teleportForSkill(p,dest,{dimension:dim,keepVelocity:false});}catch{return false;}
  fx(p,'speed',def.buffTicks,2);
  fx(p,'resistance',def.buffTicks,0);
  sound(dim,'mob.endermen.portal',dest,{volume:.5,pitch:1.6});return true;
}
function field(p,job,def){
  const dim=p.dimension,center={...p.location};
  let n=0;const hit=new Set();
  sound(dim,'mob.guardian.elder_hit',center,{volume:.65,pitch:.9});
  const ticker=system.runInterval(()=>{
    try{
      if(!p.isValid||p.dimension.id!==dim.id||n>=def.duration){system.clearRun(ticker);return;}
      if(n%10===0){
        ring(dim,{x:center.x,y:center.y+.15,z:center.z},def.radius,SEAL,24);
        ring(dim,{x:center.x,y:center.y+.55,z:center.z},def.radius*.7,DUST,16);
        for(const t of getTargets(p,center,def.radius)){
          if(!enemy(p,t))continue;
          fx(t,'slowness',30,2);
          if(!hit.has(t.id)){hit.add(t.id);hurt(t,p,def.damage);}
        }
      }
      n+=2;
    }catch{system.clearRun(ticker);}
  },2);
  notify(p,'§b설한결계: §f주변에 냉기 지대 생성');return true;
}
function absolute(p,job,def){
  const dim=p.dimension,center={...p.location};
  const list=getTargets(p,center,def.radius).filter(t=>enemy(p,t));
  for(const t of list){
    hurt(t,p,def.damage);freeze(t,def.freezeTicks);
    for(let i=0;i<7;i++){
      const a=i*Math.PI*2/7;
      particle(dim,SHARD,{x:t.location.x+Math.cos(a)*.5,y:t.location.y+.4+(i%3)*.35,z:t.location.z+Math.sin(a)*.5});
    }
  }
  ring(dim,{x:center.x,y:center.y+.2,z:center.z},def.radius,SEAL,36);
  ring(dim,{x:center.x,y:center.y+1,z:center.z},def.radius*.6,SHARD,24);
  sound(dim,'random.glass',center,{volume:1,pitch:.5});
  sound(dim,'mob.guardian.elder_hit',center,{volume:.9,pitch:.7});
  notify(p,`§b영점빙옥! §f${list.length}명에게 ${def.damage} 피해 · 5초 동결`);
  return true;
}

// 대빙해소: 냉기를 약 0.4초 압축한 뒤, 정면 10블럭 안의 가장 가까운 적을 향해 돌진.
// 블록·낙하 구간을 무시하고 시작 Y를 유지하며, 적중 대상에게 3초 동결을 적용합니다.
function greatIceRelease(p, job, def) {
  const dim = p.dimension;
  const start = { ...p.location };
  const facing = norm3(p.getViewDirection());
  const eye = headPos(p);
  let best = null;
  let bestDistance = Infinity;

  for (const t of getTargets(p, start, def.range + 0.5)) {
    if (!enemy(p, t) || t.dimension.id !== dim.id) continue;
    const loc = at(t, 1.0);
    const delta = { x: loc.x - eye.x, y: loc.y - eye.y, z: loc.z - eye.z };
    const length = Math.hypot(delta.x, delta.y, delta.z) || 0.001;
    if (length > def.range || length >= bestDistance) continue;
    if ((delta.x * facing.x + delta.y * facing.y + delta.z * facing.z) / length < 0.55) continue;
    // 고도 차이와 경로의 지형을 돌진 가능 여부에 반영하지 않습니다.
    best = t;
    bestDistance = length;
  }
  if (!best) {
    notify(p, '§7대빙해소: 정면 10블럭 안에 돌진할 수 있는 적이 없습니다.');
    return false;
  }

  // 안전한 바닥이나 벽 유무와 관계없이 시작 Y좌표를 유지합니다.
  const dashY = start.y;

  const chargeTicks = def.chargeTicks ?? 8;
  const dashSpeed = def.dashSpeed ?? 1.8;
  let elapsed = 0;
  let traveled = 0;
  sound(dim, 'mob.guardian.attack', start, { volume: .6, pitch: .65 });
  const ticker = system.runInterval(() => {
    try {
      if (!p.isValid || !valid(best) || p.dimension.id !== dim.id || best.dimension.id !== dim.id) {
        system.clearRun(ticker); return;
      }
      elapsed++;
      if (elapsed <= chargeTicks) {
        const c = at(p, .85);
        ring(dim, c, .72 - elapsed * .065, DUST, 8);
        if (elapsed % 2 === 0) particle(dim, SHARD, { x: c.x, y: c.y + .15, z: c.z });
        return;
      }
      const here = p.location;
      const target = best.location;
      const px = target.x - here.x, pz = target.z - here.z;
      const remaining = Math.hypot(px, pz);
      if (remaining <= 1.95) {
        hurt(best, p, def.damage);
        freeze(best, def.freezeTicks);
        ring(dim, at(best, 1), .75, SEAL, 12);
        sound(dim, 'random.glass', target, { volume: .9, pitch: .65 });
        notify(p, '§b대빙해소! §f돌진 명중 · 3초 동결');
        system.clearRun(ticker);
        return;
      }
      const step = Math.min(dashSpeed, remaining - 1.35, Math.max(.1, def.range - traveled));
      const next = { x: here.x + px * step / remaining, y: dashY, z: here.z + pz * step / remaining };
      teleportForSkill(p,next, { dimension: dim, facingLocation: at(best, 1), keepVelocity: false });
      trail(dim, { x: here.x, y: here.y + .8, z: here.z }, { x: next.x, y: next.y + .8, z: next.z }, SHARD, .48);
      particle(dim, DUST, { x: next.x, y: next.y + .65, z: next.z });
      traveled += step;
      if (traveled >= def.range || elapsed > chargeTicks + 15) system.clearRun(ticker);
    } catch {
      system.clearRun(ticker);
    }
  }, 1);
  return true;
}

export const RUNNERS={
  frost_shard:shard,
  frost_grasp:grasp,
  frost_barrage:barrage,
  frost_step:iceStep,
  frost_field:field,
  frost_great_release:greatIceRelease,
  frost_absolute:absolute,
};
export function registerFrost(){
  if(started)return;started=true;
  system.runInterval(()=>{
    for(const [id,f] of frozen){
      try{
        if(!valid(f.entity)||f.entity.dimension.id!==f.dimensionId||system.currentTick>=f.expires){frozen.delete(id);continue;}
        if(dist3(f.entity.location,f.position)>.2)f.entity.teleport(f.position,{dimension:f.entity.dimension,keepVelocity:false});
        if(system.currentTick%10===0)particle(f.entity.dimension,SEAL,at(f.entity,1));
      }catch{frozen.delete(id);}
    }
  },2);
  world.afterEvents.entityDie.subscribe(e=>{if(e.deadEntity)frozen.delete(e.deadEntity.id);});
}

// Borrowed spells use MAG just like their original spell class.
function hurt(target,source,amount,type="magic"){return hurtBase(target,source,amount,type);}
