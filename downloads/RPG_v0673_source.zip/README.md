# RPG v0.6.73 · 용기사의 용의 시선과 무쌍돌격

- **용의 시선**은 전방 120도, 사거리 28칸 안에서 벽에 가리지 않은 모든 적에게 10초 표식을 부여합니다. 조준선에 걸린 첫 적은 기본 물리 피해 40을 받습니다. 받는 피해 30% 증가는 Bedrock의 피격 전 이벤트 지원 여부에 따릅니다.
- **무쌍돌격**은 26칸 안에서 자신이 표식을 남긴 적 중 벽에 가리지 않은 가장 가까운 적에게 돌진해 기본 물리 피해 56을 줍니다. 표식은 남고, 돌진할 수 없으면 마나와 쿨타임을 소모하지 않습니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.73으로 활성화하고 월드를 다시 여세요. 모의 전투에서 다중 표식, 시야각·벽·사거리, 시전자별 표식과 만료, 돌진 피해와 이동 실패를 검증했습니다. 실제 Bedrock 월드에서의 플레이는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0673
```
