import vm from 'node:vm';import fs from 'node:fs';import assert from 'node:assert/strict';
const root=process.argv[2]??'.',bp=root+'/RPG_BP_v0638/';
async function load(file,bindings={}){const source=fs.readFileSync(bp+file,'utf8'),context=vm.createContext({console}),m=new vm.SourceTextModule(source,{context});await m.link(async spec=>{const names=new Set();for(const h of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(h[2]===spec)for(const n of h[1].split(','))names.add(n.trim().split(/\s+as\s+/)[0]);return new vm.SyntheticModule([...names],function(){for(const n of names)this.setExport(n,bindings[n]??(()=>{}));},{context});});await m.evaluate();return m.namespace;}
const skillData=await load('scripts/data/skills.js'),defs=skillData.SKILLS;
assert.equal(defs.dragon_triple_strike.bonusDamage,24);assert.equal(defs.dragon_gaze.damage,40);assert.equal(defs.dragon_charge.damage,56);assert.equal(defs.dragon_sprint.damage,28);assert.equal(defs.dragon_breath.damage,72);assert.equal(defs.dragon_domain.entryDamage,50);assert.equal(defs.dragon_domain.pulseDamage,10);
function setup(){let serial=0;const timers=new Map(),hooks={},hits=[],effects=[],teleports=[];let entities=[];
 const system={currentTick:0,runInterval:(fn,n)=>{timers.set(++serial,{fn,n,next:system.currentTick+n});return serial;},clearRun:id=>timers.delete(id)};
 const events=new Proxy({},{get:(_,key)=>({subscribe:fn=>(hooks[key]??=[]).push(fn)})});
 const dim={id:'minecraft:overworld',blocked:false,getEntities:(query)=>entities.filter(e=>!e.removed&&(!query?.location||Math.hypot(e.location.x-query.location.x,e.location.y-query.location.y,e.location.z-query.location.z)<=query.maxDistance))};
 const p={id:'p',typeId:'minecraft:player',isValid:true,job:'dragon_knight',hp:100,location:{x:0,y:64,z:0},dimension:dim,view:{x:0,y:0,z:1},getViewDirection(){return this.view;},getRotation:()=>({x:0,y:0}),getComponent:k=>k==='minecraft:health'?{currentValue:p.hp,effectiveMax:100,setCurrentValue:n=>p.hp=n}:undefined};
 const world={afterEvents:events,beforeEvents:{entityHurt:{subscribe:fn=>(hooks.beforeHurt??=[]).push(fn)}},getAllPlayers:()=>p.isValid?[p]:[]};
 function mob(id,at,hostile=true){const e={id,typeId:hostile?'minecraft:zombie':'minecraft:cow',hp:1000,location:at,dimension:dim,getComponent:k=>k==='minecraft:health'?{currentValue:e.hp,setCurrentValue:n=>e.hp=n}:k==='minecraft:type_family'?{hasTypeFamily:()=>hostile}:undefined,applyDamage:n=>{hits.push({id,n,type:'native'});return true;},applyImpulse:()=>{},setOnFire:n=>effects.push({id,effect:'burn',n})};entities.push(e);return e;}
 p.clearVelocity=()=>{};p.applyImpulse=v=>{p.location={x:p.location.x+v.x,y:p.location.y+v.y,z:p.location.z+v.z};};
 const bindings={world,system,SKILLS:defs,DRAGON_PASSIVE:skillData.DRAGON_PASSIVE,EntityDamageCause:{override:'override',entityAttack:'entityAttack'},LEVELED_MONSTERS:[],VANILLA_HOSTILES:new Set(['zombie']),getJobId:p=>p.job,canUseSkill:p=>p.job==='dragon_knight',areAllies:(p,e)=>e.ally===true,healthAlive:e=>e.hp>0,norm3:v=>{const n=Math.hypot(v.x,v.y,v.z)||1;return {x:v.x/n,y:v.y/n,z:v.z/n};},headPos:p=>({...p.location,y:p.location.y+1.6}),dist3:(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z),getTargets:(p,at,r,offset=0)=>entities.filter(e=>e.hp>0&&!e.removed&&Math.hypot(e.location.x-at.x,e.location.y+offset-at.y,e.location.z-at.z)<=r),isSolidAt:()=>dim.blocked,clearBlockPath:()=>!dim.blocked,checkSkillMovement:()=>{},teleportForSkill:(p,at,options)=>{teleports.push({at,options});p.location={...at};},hurt:(t,p,n,type)=>{hits.push({id:t.id,n,type});return true;},skillDamageFor:(p,n)=>n,setCombatHealth:(t,p,hp,n)=>hp.setCurrentValue(n),ccScale:()=>1,armorKnockbackScale:()=>1,applyStatus:(e,effect,n,opt)=>effects.push({id:e.id,effect,n,amp:opt.amplifier})};
 function step(n){for(let i=0;i<n;i++){system.currentTick++;for(const [id,t]of [...timers])if(timers.has(id)&&system.currentTick>=t.next){t.next+=t.n;t.fn();}}}
 return {p,dim,world,system,hits,effects,hooks,bindings,mob,step,timers,entities,teleports};
}
{
 const h=setup(),api=await load('scripts/skills/dragon.js',h.bindings);api.registerDragon();
 const t=h.mob('target',{x:0,y:64,z:3});api.RUNNERS.dragon_gaze(h.p,null,defs.dragon_gaze);assert.equal(h.hits.at(-1).n,40);
 t.location.y=64.6;api.RUNNERS.dragon_charge(h.p,null,defs.dragon_charge);assert.equal(h.hits.at(-1).n,56);assert.ok(Math.abs(h.p.location.z-1.9)<1e-8);
 h.p.location={x:0,y:64,z:0};api.RUNNERS.dragon_triple_strike(h.p,null,defs.dragon_triple_strike);
 for(let i=0;i<3;i++)for(const fn of h.hooks.entityHurt)fn({damage:1,hurtEntity:t,damageSource:{damagingEntity:h.p,cause:'entityAttack'}});
 assert.equal(t.hp,1000-24*3-10-10);assert.ok(h.effects.some(e=>e.effect==='slowness'&&e.n===20));
 api.RUNNERS.dragon_breath(h.p,null,defs.dragon_breath);h.step(5);assert.ok(h.hits.some(x=>x.n===72&&x.type==='magic'));assert.ok(h.effects.some(e=>e.effect==='burn'&&e.n===4));
}
{
 const h=setup(),api=await load('scripts/skills/dragon.js',h.bindings);
 h.mob('front',{x:0,y:64,z:1});h.mob('right',{x:2,y:64,z:1});
 assert.equal(api.RUNNERS.dragon_sprint(h.p,null,defs.dragon_sprint),true);h.step(1);assert.ok(Math.abs(h.p.location.z-1.05)<1e-8);
 h.p.view={x:1,y:0,z:0};h.step(2);assert.ok(h.p.location.x>2);assert.ok(Math.abs(h.p.location.z-1.05)<1e-8);
 assert.deepEqual(h.hits.map(x=>x.n),[28,42]);
 assert.equal(h.teleports.length,0,'Sprint must not teleport or reset client camera');
 h.p.view={x:-1,y:0,z:0};const turnX=h.p.location.x;h.step(1);assert.ok(h.p.location.x<turnX,'Mid-sprint 180-degree reversal works');
 h.p.view={x:1,y:0,z:0};h.step(2);h.p.view={x:0,y:1,z:0};h.step(1);assert.ok(h.p.location.x>3);
 h.dim.blocked=true;const at={...h.p.location};h.step(2);assert.deepEqual(h.p.location,at);assert.equal(h.timers.size,0);
}
{
 const h=setup(),api=await load('scripts/skills/dragon.js',h.bindings);api.registerDragon();
 h.mob('inside',{x:0,y:64,z:2});h.mob('animal',{x:0,y:64,z:3},false);h.mob('outside',{x:0,y:64,z:9});const ally=h.mob('ally',{x:0,y:64,z:1});ally.ally=true;
 api.RUNNERS.dragon_domain(h.p,null,defs.dragon_domain);assert.ok(h.hits.some(x=>x.id==='inside'&&x.n===50));
 h.step(20);assert.ok(h.hits.some(x=>x.id==='inside'&&x.n===10));assert.ok(h.effects.some(e=>e.id==='inside'&&e.effect==='weakness'&&e.amp===1));
 assert.ok(!h.effects.some(e=>['animal','outside','ally'].includes(e.id)&&e.effect==='weakness'));
 h.entities.find(e=>e.id==='inside').location.z=12;const count=h.effects.filter(e=>e.id==='inside'&&e.effect==='weakness').length;h.step(10);assert.equal(h.effects.filter(e=>e.id==='inside'&&e.effect==='weakness').length,count);
 h.step(200);const hits=h.hits.length;h.step(20);assert.equal(h.hits.length,hits);
}
{
 const h=setup(),api=await load('scripts/skills/dragonDomainShield.js',h.bindings),zones=new Map([['z',{ownerId:'p',dimId:h.dim.id,center:{x:0,y:64,z:0},radius:7,until:100}]]);
 api.registerDragonDomainShield(zones);
 function arrow(id,x,v,owner){const e={id,typeId:'minecraft:arrow',dimension:h.dim,location:{x,y:64,z:0},v:{x:v,y:0,z:0},getVelocity(){return this.v;},getComponent:k=>k==='minecraft:projectile'?{owner}:undefined,remove(){this.removed=true;}};h.entities.push(e);for(const fn of h.hooks.entitySpawn)fn({entity:e});return e;}
 const fast=arrow('fast',-10,30),miss=arrow('miss',-10,-2),out=arrow('internal',0,20),outside=arrow('ally-outside',10,-5,h.p);
 h.step(1);assert.equal(fast.removed,true);assert.equal(outside.removed,true);assert.ok(!miss.removed);assert.ok(!out.removed);
 const swept=arrow('swept',-10,0);swept.location.x=10;h.step(1);assert.equal(swept.removed,true);
 const fromOutside={dimension:h.dim,location:{x:10,y:64,z:0}};const inside=arrow('spawn-inside',6,-3,fromOutside);h.step(1);assert.equal(inside.removed,true);
 const ordinary=h.mob('ordinary',{x:0,y:64,z:0});h.step(1);assert.ok(!ordinary.removed);
 h.step(100);const expired=arrow('expired',10,-10);h.step(1);assert.ok(!expired.removed);assert.equal(zones.size,0);
 zones.set('death',{ownerId:'p',dimId:h.dim.id,center:{x:0,y:64,z:0},radius:7,until:1000});h.p.hp=0;h.step(1);assert.equal(zones.size,0);
 assert.equal(api.crossesDomain({x:-10,y:64,z:8},{x:10,y:64,z:8},{x:0,y:64,z:0},7),false);
}
console.log('Dragon: doubled attacks/triple follow-up, magic breath72, live sprint steering/unique hits/wall stop, domain50+10 and enemy-monster Weakness II, stable projectile deletion incl fast/swept/external-friendly shots; internal shots, misses, nonprojectiles and expiration preserved');
{
 const h=setup();
 h.bindings.clearBlockPath=(_dim,_from,to)=>to.x!==-4;
 const api=await load('scripts/skills/dragon.js',h.bindings);api.registerDragon();
 const straight=h.mob('straight',{x:0,y:64,z:8});
 const side=h.mob('side',{x:3,y:64,z:3});
 const far=h.mob('far',{x:0,y:64,z:27});
 const behind=h.mob('behind',{x:0,y:64,z:-1});
 const outsideCone=h.mob('outside-cone',{x:4,y:64,z:1});
 const hidden=h.mob('hidden',{x:-4,y:64,z:4});
 const tooFar=h.mob('too-far',{x:0,y:64,z:29});
 const ally=h.mob('ally',{x:0,y:64,z:2});ally.ally=true;
 const gaze=p=>api.RUNNERS.dragon_gaze(p,null,defs.dragon_gaze);
 const charge=p=>api.RUNNERS.dragon_charge(p,null,defs.dragon_charge);
 const incomingDamage=target=>{
  const event={hurtEntity:target,damage:10};
  for(const fn of h.hooks.beforeHurt)fn(event);
  return event.damage;
 };
 assert.equal(charge(h.p),false);
 assert.equal(gaze(h.p),true);
 assert.deepEqual(h.hits,[{id:'straight',n:40,type:'physical'}]);
 for(const t of [straight,side,far])assert.equal(incomingDamage(t),13,t.id);
 for(const t of [behind,outsideCone,hidden,tooFar,ally])assert.equal(incomingDamage(t),10,t.id);

 const second={...h.p,id:'second'};
 assert.equal(charge(second),false,'another caster cannot use the first caster’s marks');
 assert.equal(gaze(second),true);
 assert.equal(incomingDamage(side),13,'overlapping marks do not stack the damage multiplier');
 h.p.view={x:0,y:0,z:-1};
 assert.equal(charge(h.p),true,'a previously marked enemy remains eligible after facing away');
 assert.deepEqual(h.hits.at(-1),{id:'side',n:56,type:'physical'});
 assert.ok(Math.abs(Math.hypot(h.p.location.x-3,h.p.location.z-3)-1.1)<1e-8);
 assert.equal(incomingDamage(side),13,'charge leaves the mark active');

 h.p.location={x:0,y:64,z:0};
 side.location.x=-4;
 assert.equal(charge(h.p),true,'a wall makes the closest mark ineligible');
 assert.deepEqual(h.hits.at(-1),{id:'straight',n:56,type:'physical'});
 h.p.location={x:0,y:64,z:0};
 straight.hp=0;
 assert.equal(charge(h.p),false,'a mark at 27 blocks is outside the charge range');
 side.location.x=3;
 h.step(defs.dragon_gaze.markDuration-1);
 assert.equal(incomingDamage(side),13);
 h.step(1);
 assert.equal(incomingDamage(side),10);
 assert.equal(charge(h.p),false,'expired marks cannot enable a charge');
}
{
 const h=setup();
 h.bindings.teleportForSkill=()=>{throw Error('DungeonBoundary');};
 const api=await load('scripts/skills/dragon.js',h.bindings);
 h.mob('target',{x:0,y:64,z:3});
 api.RUNNERS.dragon_gaze(h.p,null,defs.dragon_gaze);
 assert.equal(api.RUNNERS.dragon_charge(h.p,null,defs.dragon_charge),false);
 assert.deepEqual(h.hits,[{id:'target',n:40,type:'physical'}]);
}
console.log('Dragon Gaze and Charge: visible 120-degree cone, all enemy marks, aim-line hit preserved, owner isolation, nearest valid mark, walls and range, non-stacking marks and expiry, blocked movement without damage');
{
 const h=setup();h.p.hp=70;h.bindings.skillDamageFor=(p,n)=>n*3;
 const api=await load('scripts/skills/dragon.js',h.bindings);api.registerDragon();
 const a=h.mob('first',{x:0,y:64,z:2}),b=h.mob('third',{x:0,y:64,z:3});
 const fire=(target,damage=1,cause='entityAttack')=>{for(const fn of h.hooks.entityHurt)fn({damage,hurtEntity:target,damageSource:{damagingEntity:h.p,cause}});};
 fire(a,0);fire(a,1,'override');fire(a);fire(a);assert.equal(a.hp,1000);assert.equal(h.p.hp,70);
 fire(b);assert.equal(a.hp,1000);assert.equal(b.hp,963,'3rd hit: STR-scaled 10*3 + pre-heal current HP70*10%');assert.equal(h.p.hp,79);
 h.p.hp=98;fire(b);fire(b);fire(b);assert.ok(Math.abs(b.hp-(963-30-9.8))<1e-8);assert.equal(h.p.hp,100);
 h.p.hp=20;fire(b);fire(b);fire(b);assert.ok(Math.abs(b.hp-(963-30-9.8-32))<1e-8);assert.equal(h.p.hp,29);
 const saved=b.hp;h.p.hp=0;fire(b);fire(b);fire(b);assert.equal(b.hp,saved);assert.equal(h.p.hp,0);
}
{
 const h=setup();h.p.job='chameleon';h.p.hp=50;h.bindings.canUseSkill=()=>true;
 const api=await load('scripts/skills/dragon.js',h.bindings);api.registerDragon();const t=h.mob('target',{x:0,y:64,z:1});
 for(let i=0;i<3;i++)for(const fn of h.hooks.entityHurt)fn({damage:1,hurtEntity:t,damageSource:{damagingEntity:h.p,cause:'entityAttack'}});
 assert.equal(t.hp,1000);assert.equal(h.p.hp,50);
}
console.log('Dragon passive: every third positive entityAttack, physical scaling once + pre-heal caster current HP10% without second STR scaling, heal9 capped at max; low/high HP, counter reset, split targets, zero/override/dead/Chameleon exclusions passed');

{
 const h=setup(),api=await load('scripts/skills/dragon.js',h.bindings);let impulses=0;
 h.p.applyImpulse=v=>{impulses++;assert.ok(Math.abs(Math.hypot(v.x,v.z)-1.05)<1e-8);h.p.location={x:h.p.location.x+v.x,y:h.p.location.y,z:h.p.location.z+v.z};};
 api.RUNNERS.dragon_sprint(h.p,null,defs.dragon_sprint);
 for(let i=0;i<100;i++){const angle=i*Math.PI/25;h.p.view={x:Math.sin(angle),y:.8,z:Math.cos(angle)};h.step(1);}
 assert.equal(impulses,100);assert.ok(Math.hypot(h.p.location.x,h.p.location.z)<1e-7,'Two full curves return to the starting point');
 h.step(1);assert.equal(h.timers.size,0);assert.equal(impulses,100);assert.equal(h.teleports.length,0);
}
{
 const h=setup();h.bindings.checkSkillMovement=()=>{throw Error('DungeonBoundary');};const api=await load('scripts/skills/dragon.js',h.bindings);
 api.RUNNERS.dragon_sprint(h.p,null,defs.dragon_sprint);h.step(1);assert.equal(h.p.location.z,0);assert.equal(h.timers.size,0);assert.equal(h.hits.length,0);
}
console.log('Sprint native motion: two continuous full curves, normalized horizontal impulse, 100-tick expiry, no teleports, boundary rejection before movement/hits passed');
