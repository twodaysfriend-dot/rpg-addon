import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root=process.argv[2]??'.';
const bp=root+'/RPG_BP_v0638';
const seededMath=Object.create(Math);
let randomState=672;
seededMath.random=()=>{
 randomState=(Math.imul(randomState,1664525)+1013904223)>>>0;
 return randomState/2**32;
};
const context=vm.createContext({console,Math:seededMath});
const callbacks=new Map(),ticks=new Map(),timeouts=[];
let next=0,entities=[],wall=false,p,magicMultiplier=1;
const dimension={id:'overworld',getEntities:()=>entities};
const world={getAllPlayers:()=>[p],beforeEvents:{entityHurt:{subscribe:fn=>callbacks.set('beforeHurt',fn)}},
 afterEvents:new Proxy({},{get:(_t,key)=>({subscribe:fn=>callbacks.set(key,fn)})})};
const system={currentTick:0,run:()=>{},runInterval:fn=>{const id=++next;ticks.set(id,fn);return id;},
 clearRun:id=>ticks.delete(id),runTimeout:(fn,delay)=>timeouts.push({at:system.currentTick+delay,fn})};
const shots=[],particles=[],moves=[],events=[];
function actor(id,x,z,max=200,typeId='minecraft:zombie'){
 const tags=new Set(),props=new Map(),effects=new Map();
 const hp={currentValue:max,effectiveMax:max,setCurrentValue(n){this.currentValue=n;}};
 return {id,typeId,location:{x,y:0,z},dimension,hp,isValid:true,addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),hasTag:t=>tags.has(t),
  getViewDirection:()=>({x:0,y:0,z:1}),getComponent:()=>hp,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),
  triggerEvent:id=>events.push(id),getEffect:id=>effects.get(id),addEffect:(id,duration,o)=>effects.set(id,{duration,...o}),removeEffect:id=>effects.delete(id),
  teleport(at){moves.push(id);this.location={...at};},clearVelocity(){}};
}
const dist3=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
const bindings={world,system,CONFIG:{pvp:true},MolangVariableMap:class{
 setFloat(_key,value){this.radius=value;}
 setVector3(_key,value){this.axis={...value};}
},
 actualHurtAmount:ev=>ev.damage,flatDir:()=>({x:0,z:1}),
 abyssalDamageMultiplier:()=>1,undeadMonsterDamageMultiplier:()=>1,tryResurrection:()=>false,blockTownVillagerDamage:()=>false,notePvpAttack:()=>{},getJobId:e=>e.job,isJailed:()=>false,isTimeFrozen:()=>false,
 areAllies:()=>false,ccTicks:(e,t)=>e.boss?t/2:t,dist3,healthAlive:e=>e.hp.currentValue>0,
 getTargets:(player,at,r,bodyOffset=0)=>entities.filter(e=>e!==player&&e.hp.currentValue>0&&dist3(e.location,{...at,y:at.y-bodyOffset})<=r),
 clearBlockPath:(_d,a,b)=>!wall||Math.max(a.z,b.z)<2,isSolidAt:(_d,at)=>wall&&at.z>=2,
 headPos:e=>({...e.location,y:e.location.y+0.9}),norm3:v=>{const n=Math.hypot(v.x,v.y,v.z)||1;return {x:v.x/n,y:v.y/n,z:v.z/n};},
 hurt:(e,_p,n,type)=>{shots.push({id:e.id,n,type});e.hp.setCurrentValue(Math.max(0,e.hp.currentValue-n*magicMultiplier));return true;},
 knockback:e=>moves.push(e.id),particle:(_d,id,pos,v)=>particles.push({id,pos,radius:v?.radius,axis:v?.axis}),sound:()=>{},notify:()=>{}};
const script=path=>new vm.SourceTextModule(fs.readFileSync(bp+'/scripts/'+path,'utf8'),{context});
const state=script('core/bloodedgeState.js'),combat=script('core/combatContext.js');
function linker(spec){
 if(spec.endsWith('/bloodedgeState.js'))return state;
 if(spec.endsWith('/combatContext.js'))return combat;
 return new vm.SyntheticModule(Object.keys(bindings),function(){
  for(const [key,value] of Object.entries(bindings))this.setExport(key,value);
 },{context});
}
async function load(path){
 const module=script(path);
 await module.link(linker);
 await module.evaluate();
 return module.namespace;
}
const skills=await load('data/skills.js');
const blood=await load('skills/bloodedge.js');
const {SKILLS}=skills;
let p2;
p=actor('bloodedge',0,0,200,'minecraft:player');p.job='bloodedge';
blood.registerBloodedge();
const front=actor('front',0,8),behind=actor('behind',0,-4),outside=actor('outside',0,14.1);
entities=[p,front,behind,outside];
const cast=(id,target)=>blood.RUNNERS['bloodedge_'+id](p,{},SKILLS['bloodedge_'+id],target);
function advance(n){
 for(let i=0;i<n;i++){
  system.currentTick++;
  for(let j=timeouts.length-1;j>=0;j--)if(timeouts[j].at<=system.currentTick)timeouts.splice(j,1)[0].fn();
  for(const [,fn] of ticks)fn();
 }
}
assert.equal(cast('shield'),true);
assert.deepEqual(particles.at(-1).axis,{x:0,y:0,z:1});
assert.equal(particles.at(-1).id,'rpg:bloodedge_barrier');
assert.equal(p.hasTag('rpg_be_guard_0'),true);
assert.equal(front.hasTag('rpg_be_front_0'),true);
assert.equal(behind.hasTag('rpg_be_front_0'),false);
for(const [attacker,cancel] of [[front,true],[behind,false]]){
 const ev={hurtEntity:p,damageSource:{damagingEntity:attacker},cancel:false};
 callbacks.get('beforeHurt')(ev);assert.equal(ev.cancel,cancel);
}
callbacks.get('dataDrivenEntityTrigger')({entity:p,eventId:'rpg:bloodedge_block_front'});
assert.equal(particles.at(-1).id,'rpg:bloodedge_guard_flash');
p2=actor('second',0,10,100,'minecraft:player');p2.job='bloodedge';entities.push(p2);
assert.equal(blood.RUNNERS.bloodedge_shield(p2,{},SKILLS.bloodedge_shield),true);
assert.equal(front.hasTag('rpg_be_front_1'),false,'the same attacker is behind the other guard');
callbacks.get('playerLeave')({playerId:p2.id});entities.pop();
advance(99);assert.equal(shots.length,0);
advance(1);assert.deepEqual(shots.map(s=>s.id),['front','behind']);
assert.equal(particles.find(fx=>fx.id==='rpg:bloodedge_rupture').radius,14);
assert.ok(shots.every(hit=>hit.n===32));
assert.deepEqual(moves,['front','behind']);
assert.equal(front.hasTag('rpg_be_front_0'),false);
shots.length=0;moves.length=0;

const projectileTarget=actor('dummy',0,.05,600);
entities=[p];
function sampleBurst(){
 const first=particles.length;
 assert.equal(cast('volley'),true);advance(1);
 const rays=particles.slice(first).filter(fx=>fx.id==='rpg:bloodedge_shard');
 advance(30);
 return rays.map(ray=>ray.axis);
}
const rays=sampleBurst();
assert.equal(rays.length,24);
const angles=rays.map(ray=>Math.atan2(ray.x,ray.z)*180/Math.PI).sort((a,b)=>a-b);
for(let i=0;i<angles.length;i++)assert.ok((angles[i+1]??angles[0]+360)-angles[i]<=30);
assert.ok(rays.some(ray=>ray.y>0)&&rays.some(ray=>ray.y<0));
assert.notDeepEqual(sampleBurst(),rays);
entities=[p,projectileTarget];
assert.equal(cast('volley'),true);advance(22);
assert.equal(shots.length,10);assert.ok(shots.every(s=>s.n===4&&s.type==='magic'));
shots.length=0;
projectileTarget.location.z=7;
const splash=actor('splash',7,7,500),outsideSplash=actor('outside-splash',12,10,500);
entities=[p,splash,outsideSplash,projectileTarget];
assert.equal(cast('lance'),true);advance(39);assert.equal(shots.length,0);
const beforeRelease=particles.filter(fx=>fx.id==='rpg:bloodedge_lance');
assert.ok(beforeRelease[0].radius<beforeRelease.at(-1).radius && beforeRelease.at(-1).radius<4);
advance(1);assert.equal(particles.filter(fx=>fx.id==='rpg:bloodedge_lance').at(-1).radius,4);
advance(17);assert.deepEqual(shots.map(hit=>hit.id).sort(),['dummy','splash']);
assert.ok(shots.every(hit=>hit.n===60));
shots.length=0;
wall=true;cast('volley');advance(40);assert.equal(shots.length,0);
wall=false;

const secondBound=actor('second-bound',-10,0),outsideBind=actor('outside-bind',10.01,0);
const spectator=actor('spectator',0,-2,100,'minecraft:player');spectator.getGameMode=()=> 'spectator';
entities=[p,projectileTarget,secondBound,outsideBind,spectator];
assert.equal(cast('bind'),false,'only an actual melee target starts the area bind');
assert.equal(cast('bind',outsideBind),false);
assert.equal(cast('bind',projectileTarget),true);
assert.equal(SKILLS.bloodedge_bind.cooldown,300);
for(const e of [projectileTarget,secondBound,outsideBind,spectator])e.location.z+=1;
advance(1);
assert.equal(projectileTarget.location.z,7);
assert.equal(secondBound.location.z,0,'exactly ten blocks is included');
assert.equal(outsideBind.location.z,1);
assert.equal(spectator.location.z,-1);
advance(97);secondBound.location.z--;advance(1);assert.equal(secondBound.location.z,0);
advance(1);secondBound.location.z--;advance(1);assert.equal(secondBound.location.z,-1);

const strong=actor('strong',0,8,700),weak=actor('weak',0,1,30);
strong.hp.currentValue=10;entities=[p,weak,strong];p.hp.currentValue=30;
assert.equal(cast('transfusion'),true);
assert.deepEqual(shots,[{id:'strong',n:20,type:'magic'}]);assert.equal(p.hp.currentValue,33);
shots.length=0;

const infected=actor('infected',0,15.2,500);
entities=[p,infected,actor('outside-plague',0,16.1)];
assert.equal(cast('plague'),true);
infected.hp.currentValue-=100;
callbacks.get('entityHurt')({hurtEntity:infected,damage:100,damageSource:{}});
assert.equal(infected.hp.currentValue,380);
combat.namespace.setCombatHealth(infected,p,infected.hp,360);
assert.equal(infected.hp.currentValue,356,'manual damage is likewise amplified once');
combat.namespace.scriptedHit(infected,p,()=>{
 combat.namespace.currentScriptHit(p,infected).plagueIncluded=true;
 infected.hp.currentValue-=12;
 callbacks.get('entityHurt')({hurtEntity:infected,damage:12,damageSource:{damagingEntity:p}});
 return true;
});
assert.equal(infected.hp.currentValue,344,'pre-amplified skill hit is not amplified twice');
magicMultiplier=2;
advance(199);assert.equal(shots.length,0);
advance(1);assert.equal(shots.length,1);assert.equal(shots[0].id,'infected');assert.equal(shots[0].type,'magic');assert.ok(Math.abs(shots[0].n-7.8)<1e-9);
assert.ok(Math.abs(infected.hp.currentValue-328.4)<1e-8);
shots.length=0;

const low=actor('low',0,2,6),moved=actor('moved',17,0),edge=actor('edge',18.01,0);
entities=[p,low,moved,edge];p.hp.currentValue=30;
assert.equal(cast('pool'),true);assert.equal(p.hasTag('rpg:bloodedge_pool'),true);
assert.equal(events.at(-1),'rpg:bloodedge_pool_on');
const oldView=p.getViewDirection;p.getViewDirection=()=>({x:0,y:0,z:-1});
const shieldSkill=SKILLS.bloodedge_shield;
assert.equal(blood.RUNNERS.bloodedge_shield(p,{},{...shieldSkill,duration:300}),true,'can cast barrier during the pool');
p.getViewDirection=oldView;
advance(20);assert.deepEqual(shots,[{id:'low',n:10,type:'magic'}]);
p.location.x=12;advance(179);assert.equal(p.hp.currentValue,30);
advance(1);
assert.equal(shots.filter(s=>s.id==='moved').length,9);
assert.equal(shots.filter(s=>s.id==='edge').length,0);
assert.equal(p.hp.currentValue,123,'six actual HP from the first kill plus 180 magic damage, then heal half');
assert.equal(p.hasTag('rpg:bloodedge_pool'),false);
assert.equal(events.at(-1),'rpg:bloodedge_pool_off');
assert.ok(particles.some(s=>s.id==='rpg:bloodedge_pool'&&s.pos.x===12));
assert.equal(p.getEffect('invisibility'),undefined);
const def=JSON.parse(fs.readFileSync(bp+'/entities/player.json'))['minecraft:entity'];
assert.ok(def.component_groups['rpg:bloodedge_untargetable']['minecraft:cannot_be_attacked']);
assert.ok(def.component_groups['rpg:bloodedge_untargetable']['minecraft:is_hidden_when_invisible']);
for(const c of [def.components,...Object.values(def.component_groups)]){
 const sensor=c['minecraft:damage_sensor'];if(!sensor)continue;
 const guard=sensor.triggers[0];
 assert.equal(guard.deals_damage,false);
 assert.equal(guard.on_damage.filters.any_of.length,16);
}
console.log('Bloodedge: barrier and rupture, 24 randomized radial shards, 10-hit target cap, 8-block orb and splash, five-second melee bind, strongest-target transfusion, timed plague scaling, concurrent moving magic pool');
