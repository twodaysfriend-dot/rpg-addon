import {system} from '@minecraft/server';

export const BLOODEDGE_POOL_TAG='rpg:bloodedge_pool';
export const shieldSessions=new Map();

export function isBloodedgePool(entity) {
  return entity?.typeId==='minecraft:player' && entity.hasTag?.(BLOODEDGE_POOL_TAG)===true;
}

export function isShieldFront(player,attacker) {
  if (!attacker || attacker.id===player.id || attacker.dimension.id!==player.dimension.id) return false;
  const victim=player.location,source=attacker.location,view=player.getViewDirection();
  const dx=source.x-victim.x,dz=source.z-victim.z;
  const length=Math.hypot(dx,dz),facing=Math.hypot(view.x,view.z);
  if (length<0.01 || facing<0.001) return false;
  return (dx*view.x+dz*view.z)/(length*facing)>=0.45;
}

export function blocksBloodedgeDamage(player,attacker) {
  const shield=shieldSessions.get(player?.id);
  return !!shield && system.currentTick < shield.until && shield.dimension===player.dimension.id &&
    isShieldFront(player,attacker);
}

export const plagueSessions=new Map();

export function activeBloodPlague(entity) {
  const mark=plagueSessions.get(entity?.id);
  return mark && mark.until>system.currentTick && mark.dimension===entity.dimension?.id ? mark : undefined;
}
