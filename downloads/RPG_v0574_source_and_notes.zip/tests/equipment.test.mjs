import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,EquipmentSlot} from './minecraftMock.mjs';
import {getEquipmentBonuses} from '../RPG_BP_v0574/scripts/core/equipment.js';
import {readRuneBag,writeRuneBag,addRuneRecord,depositRune,equipRune,unequipRune,withdrawRune,migrateChestRune} from '../RPG_BP_v0574/scripts/core/runeInventory.js';
import {enhanceEquipped,enhancementQuote} from '../RPG_BP_v0574/scripts/core/upgrades.js';
import {setWallet,getWallet} from '../RPG_BP_v0574/scripts/core/wallet.js';
import {RUNE_KEY} from '../RPG_BP_v0574/scripts/data/equipment.js';
import {RUNE_LEVEL_KEY,ARMOR_LEVEL_KEY,CATALYST_ID} from '../RPG_BP_v0574/scripts/data/upgrades.js';
function add(p,id,level=0){const bag=readRuneBag(p),r=addRuneRecord(bag,id,level);writeRuneBag(p,bag);return r.uid;}
function armor(p,set){for(const [slot,part]of [[EquipmentSlot.Head,'helmet'],[EquipmentSlot.Chest,'chestplate'],[EquipmentSlot.Legs,'leggings'],[EquipmentSlot.Feet,'boots']])p.equipment.set(slot,new ItemStack(`rpg:${set}_${part}`));}
test('set bonuses require all 4 parts',()=>{const p=player('set');armor(p,'adventurer');assert.equal(getEquipmentBonuses(p).physical,1.08);p.equipment.delete(EquipmentSlot.Feet);assert.equal(getEquipmentBonuses(p).physical,1);armor(p,'warden');assert.equal(getEquipmentBonuses(p).health,8);armor(p,'astral');assert.equal(getEquipmentBonuses(p).manaRegen,3);});
test('deposit consumes one physical rune, bag capacity blocks extra consumption',()=>{const p=player('bag');p.slots[0]=new ItemStack('rpg:rune_power',40);for(let i=0;i<30;i++)assert.equal(depositRune(p,0).ok,true);assert.equal(p.slots[0].amount,10);assert.equal(depositRune(p,0).ok,false);assert.equal(p.slots[0].amount,10);});
test('three independent slots, duplicate kinds rejected, no armor required',()=>{const p=player('slots'),a=add(p,'power',10),b=add(p,'vitality',10),c=add(p,'mana',10),same=add(p,'power');assert.equal(equipRune(p,a,0).ok,true);assert.equal(equipRune(p,b,1).ok,true);assert.equal(equipRune(p,c,2).ok,true);assert.equal(equipRune(p,same,1).ok,false);const bonuses=getEquipmentBonuses(p);assert.ok(Math.abs(bonuses.physical-1.3)<1e-9);assert.equal(bonuses.health,24);assert.equal(bonuses.manaRegenPercent,.03);unequipRune(p,b);assert.equal(getEquipmentBonuses(p).health,0);});
test('stored inactive rune gives no effect; enhanced rune remains player-owned on armor loss',()=>{const p=player('independent'),r=add(p,'vitality',6);assert.equal(getEquipmentBonuses(p).health,0);equipRune(p,r,0);armor(p,'adventurer');p.equipment.clear();assert.equal(getEquipmentBonuses(p).health,16);const rejoin=player('rejoin');rejoin.setDynamicProperty('rpg:rune_bag_v1',p.getDynamicProperty('rpg:rune_bag_v1'));assert.equal(getEquipmentBonuses(rejoin).health,16);});
test('legacy chest rune migrates once with grade and armor enhancement preserved',()=>{const p=player('legacy'),item=new ItemStack('rpg:warden_chestplate');item.setDynamicProperty(RUNE_KEY,'power');item.setDynamicProperty(RUNE_LEVEL_KEY,4);item.setDynamicProperty(ARMOR_LEVEL_KEY,7);p.equipment.set(EquipmentSlot.Chest,item);assert.equal(migrateChestRune(p).migrated,true);assert.equal(migrateChestRune(p).migrated,false);assert.equal(readRuneBag(p).runes.length,1);assert.equal(readRuneBag(p).runes[0].level,8);assert.equal(p.equipment.get(EquipmentSlot.Chest).getDynamicProperty(ARMOR_LEVEL_KEY),7);assert.equal(p.equipment.get(EquipmentSlot.Chest).getDynamicProperty(RUNE_KEY),undefined);});
test('failed migration restores both old chest and empty bag',()=>{const p=player('fail'),item=new ItemStack('rpg:warden_chestplate');item.setDynamicProperty(RUNE_KEY,'ward');p.equipment.set(EquipmentSlot.Chest,item);const get=p.getComponent.bind(p),eq=get('minecraft:equippable');let fail=true;p.getComponent=n=>n==='minecraft:equippable'?{...eq,setEquipment:(s,i)=>{if(fail){fail=false;return false;}return eq.setEquipment(s,i);}}:get(n);assert.equal(migrateChestRune(p).ok,false);assert.equal(readRuneBag(p).runes.length,0);assert.equal(p.equipment.get(EquipmentSlot.Chest).getDynamicProperty(RUNE_KEY),'ward');});
test('withdraw +0 returns item and removes equipment; upgraded rune cannot be exported',()=>{const p=player('withdraw'),a=add(p,'power'),b=add(p,'mana',1);equipRune(p,a,0);assert.equal(withdrawRune(p,a).ok,true);assert.equal(p.slots[0].typeId,'rpg:rune_power');assert.equal(readRuneBag(p).equipped[0],null);assert.equal(withdrawRune(p,b).ok,false);});
test('stored rune upgrades charge gold/dust and destruction removes only selected bag entry',()=>{const p=player('upgrade'),a=add(p,'power',4),b=add(p,'mana',2);equipRune(p,a,0);setWallet(p,{gold:10000,stone:100,dust:100});const result=enhanceEquipped(p,'rune',a,undefined,{random:()=>.99});assert.equal(result.outcome,'destroy');assert.equal(readRuneBag(p).runes.length,1);assert.equal(readRuneBag(p).runes[0].uid,b);assert.equal(readRuneBag(p).equipped[0],null);assert.equal(getWallet(p).gold,9937);assert.equal(getWallet(p).stone,100);});
test('bag rune success updates equipped bonus; cap blocks payment and stale quote blocks reuse',()=>{
  const p=player('cap'),uid=add(p,'power',9);equipRune(p,uid,0);setWallet(p,{gold:10000,stone:100,dust:100});
  const q=enhancementQuote(p,'rune',uid);assert.equal(enhanceEquipped(p,'rune',uid,q.fingerprint,{random:()=>0}).ok,true);
  assert.ok(Math.abs(getEquipmentBonuses(p).physical-1.3)<1e-9);const wallet=getWallet(p);
  assert.equal(enhanceEquipped(p,'rune',uid,q.fingerprint).ok,false);assert.deepEqual(getWallet(p),wallet);
});
test('rune failure keeps grade; downgrade preserves equipped uid',()=>{
  const p=player('downgrade'),uid=add(p,'ward',3);equipRune(p,uid,0);setWallet(p,{gold:10000,stone:100,dust:100});
  assert.equal(enhanceEquipped(p,'rune',uid,undefined,{random:()=>.7}).outcome,'fail');assert.equal(readRuneBag(p).runes[0].level,3);
  assert.equal(enhanceEquipped(p,'rune',uid,undefined,{random:()=>.97}).outcome,'downgrade');assert.equal(readRuneBag(p).runes[0].level,2);assert.equal(readRuneBag(p).equipped[0],uid);
});
test('failed rune save rolls back grade, wallet, and catalysts from multiple stacks',()=>{
  const p=player('runerollback'),uid=add(p,'mana',4);equipRune(p,uid,0);setWallet(p,{gold:10000,stone:100,dust:100});p.slots[2]=new ItemStack(CATALYST_ID,2);p.slots[8]=new ItemStack(CATALYST_ID,3);
  const bag=readRuneBag(p),wallet=getWallet(p),write=p.setDynamicProperty.bind(p);let fail=true;
  p.setDynamicProperty=(key,v)=>{if(fail&&key==='rpg:rune_bag_v1'){fail=false;throw Error('storage');}write(key,v);};
  assert.equal(enhanceEquipped(p,'rune',uid,undefined,{catalystCount:5,random:()=>0}).ok,false);
  assert.deepEqual(readRuneBag(p),bag);assert.deepEqual(getWallet(p),wallet);assert.equal(p.slots[2].amount,2);assert.equal(p.slots[8].amount,3);
});
