from pathlib import Path
import json,subprocess,re,sys
r=Path(sys.argv[1] if len(sys.argv)>1 else '/workspace/rpg-work/v0624');count=0
for p in r.rglob('*.json'):
 try:json.loads(p.read_text())
 except Exception as e:raise RuntimeError(str(p)) from e
 count+=1
print(f'JSON parsed: {count}')
files=list(r.rglob('*.js'))
for p in files:
 t=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
 assert t.returncode==0,(str(p),t.stderr)
 for imp in ([] if p.is_relative_to(r/'RPG_RP_v0624') else re.findall(r'(?:from\s*|import\s*)[\'"](\.[^\'"]+)[\'"]',p.read_text())):assert (p.parent/imp).is_file(),(p,imp)
print(f'JavaScript syntax/import paths: {len(files)}')
for p in (r/'RPG_RP_v0624/particles').glob('rpg_nen_*.json'):
 d=json.loads(p.read_text())['particle_effect']['description']['basic_render_parameters'];assert (r/'RPG_RP_v0624'/(d['texture']+'.png')).is_file()
print('Nen particle texture references: 10 passed')
