import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0624'),base=root+'/RPG_BP_v0624/scripts/';
async function setup(){
 let now=100000,entities=[],blocked=false,failQuery=false,failHit=false;const hits=[];const system={currentTick:0,runInterval:()=>1,run:()=>{},clearRun:()=>{}};
 const context=vm.createContext({console,Date:class extends Date{static now(){return now;}}});
 async function pure(file){const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});await m.link(()=>{});await m.evaluate();return m.namespace;}
 const mastery=await pure('core/worldMastery.js'),skills=(await pure('data/skills.js')).SKILLS;
 const world={getAllPlayers:()=>[p],getDimension:()=>dim},dim={id:'minecraft:overworld',getEntities:()=>{if(failQuery)throw Error('query failure');return entities;},spawnParticle:()=>{}};
 function entity(id,type,location={x:0,y:0,z:1}){
  const props=new Map(),effects=new Map(),tags=new Set(),health={currentValue:50,effectiveMax:100,setCurrentValue(n){this.currentValue=n;}};
  return {id,typeId:type,isValid:true,dimension:dim,location,props,effects,health,allied:false,boss:false,getComponent:id=>id==='minecraft:health'?health:undefined,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>v===undefined?props.delete(k):props.set(k,v),getEffect:id=>effects.get(id),addEffect:(id,d,o)=>effects.set(id,{duration:d,amplifier:o.amplifier}),removeEffect:id=>effects.delete(id),addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),getTags:()=>[...tags],hasTag:t=>tags.has(t),getVelocity:()=>({x:0,y:0,z:0}),clearVelocity:()=>{},applyImpulse:()=>{},getRotation:()=>({x:0,y:0}),teleport:()=>{},getViewDirection:()=>({x:0,y:0,z:1}),getGameMode:()=> 'creative',sendMessage:()=>{}};
 }
 const p=entity('p','minecraft:player',{x:0,y:0,z:0});p.job='the_world';p.learned=[];
 const bindings={...Object.fromEntries(Object.keys(mastery).map(k=>[k,mastery[k]])),world,system,SKILLS:skills,getJobId:p=>p.job,canUseSkill:(p,id,jobs)=>!!p&&(jobs.includes(p.job)||(p.job==='chameleon'&&p.learned.includes(id))),getTargets:()=>entities,areAllies:(p,t)=>t.allied,isBoss:e=>e.boss===true,isSolidAt:(d,at)=>blocked&&at.x<-.5,hurt:(target,source,n)=>{hits.push(target.id);return !failHit;},EntityDamageCause:{override:'override'},scriptedHit:(t,p,fn)=>fn(),isTimeFrozen:()=>false,registerStoppedTarget:()=>{},takeStoppedDamage:()=>undefined,duelOf:()=>undefined};
 const source=fs.readFileSync(base+'skills/theWorld.js','utf8'),m=new vm.SourceTextModule(source,{context});await m.link(async spec=>{const names=[];for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(n=>n.trim().split(/\s+as\s+/)[0]));return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});});await m.evaluate();
 return {api:m.namespace,p,entity,mastery,skills,system,hits,get entities(){return entities;},set entities(v){entities=v;},set blocked(v){blocked=v;},set failQuery(v){failQuery=v;},set failHit(v){failHit=v;},set now(v){now=v;}};
}
{
 const t=await setup();assert.equal(t.mastery.baseWorldTicks(t.p),20);for(let i=0;i<55;i++){const before=t.mastery.worldMastery(t.p);assert.equal(t.api.startTheWorld(t.p),true);assert.equal(t.p.getEffect('resistance').duration,Math.min(120,20+i*2)+10);assert.equal(t.api.startTheWorld(t.p),false);assert.equal(t.mastery.worldMastery(t.p),Math.min(50,before+1));assert.equal(t.api.stopTheWorld(t.p),true);}
 assert.equal(t.mastery.worldMastery(t.p),50);assert.equal(t.mastery.baseWorldTicks(t.p),120);t.p.job='mage';assert.equal(t.api.startTheWorld(t.p),false);t.p.job='chameleon';t.p.learned=['world_stop'];assert.equal(t.mastery.baseWorldTicks(t.p),120);
 console.log('Mastery: first cast 1s, +0.1s per successful use, 6s cap at 50, duplicate/unauthorized rejected, job change retains practice');
}
{
 const t=await setup();t.p.setDynamicProperty(t.mastery.WORLD_BLOOD_KEY,160000);const boss=t.entity('boss','rpg:hydra_boss');boss.boss=true;t.entities=[boss];assert.equal(t.api.startTheWorld(t.p),true);assert.equal(t.p.getEffect('resistance').duration,40);assert.equal(boss.getEffect('slowness').duration,15);assert.equal(t.p.getDynamicProperty(t.mastery.WORLD_BLOOD_KEY),undefined);t.system.currentTick=29;t.api.tickTheWorld();assert.equal(t.api.startTheWorld(t.p),false);t.system.currentTick=30;t.api.tickTheWorld();assert.equal(t.api.stopTheWorld(t.p),false);
 t.p.setDynamicProperty(t.mastery.WORLD_MASTERY_KEY,50);t.p.setDynamicProperty(t.mastery.WORLD_BLOOD_KEY,160000);assert.equal(t.api.startTheWorld(t.p),true);assert.equal(t.p.getEffect('resistance').duration,190);assert.equal(boss.getEffect('slowness').duration,90);t.api.stopTheWorld(t.p);
 console.log('Blood multiplier: 1s -> 1.5s and 6s -> 9s, bosses half, exact expiry, single-use charge consumed');
}
{
 const t=await setup();const normal=t.entity('normal','minecraft:zombie'),near=t.entity('near','rpg:deathworm',{x:-3,y:0,z:0}),far=t.entity('far','rpg:hydra_boss',{x:0,y:0,z:5});far.boss=true;t.entities=[normal,far,near];assert.equal(t.api.automaticBloodTarget(t.p).id,'near');t.api.RUNNERS.world_blood(t.p,null,t.skills.world_blood);assert.equal(t.hits.at(-1),'near');assert.equal(t.p.getDynamicProperty(t.mastery.WORLD_BLOOD_KEY),160000);assert.equal(t.mastery.worldMastery(t.p),0);
 // A direct left-click honors the clicked target. It does not acquire a new charge on a normal mob.
 t.p.setDynamicProperty(t.mastery.WORLD_BLOOD_KEY,undefined);t.api.RUNNERS.world_blood(t.p,null,t.skills.world_blood,normal);assert.equal(t.hits.at(-1),'normal');assert.equal(t.p.getDynamicProperty(t.mastery.WORLD_BLOOD_KEY),undefined);
 t.entities=[normal,near];t.blocked=true;t.api.RUNNERS.world_blood(t.p,null,t.skills.world_blood);assert.equal(t.hits.at(-1),'normal');assert.equal(t.p.getDynamicProperty(t.mastery.WORLD_BLOOD_KEY),undefined);
 t.blocked=false;near.allied=true;assert.equal(t.api.automaticBloodTarget(t.p),undefined);near.allied=false;near.location.x=-6.01;assert.equal(t.api.automaticBloodTarget(t.p),undefined);near.location.x=-6;assert.equal(t.api.automaticBloodTarget(t.p).id,'near');near.health.currentValue=0;assert.equal(t.api.automaticBloodTarget(t.p),undefined);
 console.log('Automatic blood: nearest eligible mob behind caster preferred over normal front target; direct click, walls, allies, range and dead exclusions passed');
}
{
 const t=await setup();const boss=t.entity('boss','rpg:hydra_boss');boss.boss=true;t.entities=[boss];t.failHit=true;t.api.RUNNERS.world_blood(t.p,null,t.skills.world_blood);assert.equal(t.p.health.currentValue,50);assert.equal(t.p.getDynamicProperty(t.mastery.WORLD_BLOOD_KEY),undefined);
 t.failHit=false;t.api.RUNNERS.world_blood(t.p,null,t.skills.world_blood);assert.equal(t.p.health.currentValue,58);assert.equal(t.p.getDynamicProperty(t.mastery.WORLD_BLOOD_KEY),160000);t.now=110000;t.api.RUNNERS.world_blood(t.p,null,t.skills.world_blood);assert.equal(t.p.getDynamicProperty(t.mastery.WORLD_BLOOD_KEY),170000);assert.equal(t.mastery.worldDurationTicks(t.p),30);
 t.failQuery=true;assert.throws(()=>t.api.startTheWorld(t.p));assert.equal(t.mastery.worldMastery(t.p),0);assert.equal(t.p.getDynamicProperty(t.mastery.WORLD_BLOOD_KEY),170000);t.failQuery=false;assert.equal(t.api.startTheWorld(t.p),true);assert.equal(t.p.getEffect('resistance').duration,40);t.api.stopTheWorld(t.p);assert.equal(t.mastery.worldDurationTicks(t.p),22);
 console.log('Blood refresh does not stack; failed hit grants no charge; failed cast rolls back practice and preserves charge; later success consumes it');
}
