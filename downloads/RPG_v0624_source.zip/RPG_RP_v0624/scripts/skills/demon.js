import { world, system } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { getJobId } from "../core/playerData.js";
import { areAllies } from "../core/social.js";
import { getTargets, healthAlive, headPos, flatDir, particle, sound, hurt, knockback, dist3 } from "../core/util.js";
import { notify } from "../core/hud.js";

// 악마: 낫 5종 액티브 + 영혼 수확 처치 패시브.
// 모든 피해 스킬은 getTargets/hurt 및 areAllies를 통해 길드·파티 아군을 제외합니다.
const FEAR = "rpg:demon_fear";
const SOUL = "rpg:demon_soul";
const badEffects = new Set([
  "slowness", "weakness", "poison", "wither", "blindness", "darkness", "hunger",
  "nausea", "mining_fatigue", "levitation", "fatal_poison", "unluck",
  "bad_omen", "raid_omen", "trial_omen", "infested", "oozing", "weaving",
]);
let registered = false;
const pos = (p, y=1) => ({ x:p.location.x, y:p.location.y+y, z:p.location.z });
const valid = e => { try { return e?.isValid && healthAlive(e); } catch { return false; } };
function applyEffect(entity, name, ticks, amplifier) {
  try { entity.addEffect(name, ticks, { amplifier, showParticles:false }); return true; } catch { return false; }
}
function ring(dim, center, radius, count, effect, spin=0) {
  for (let i=0;i<count;i++) {
    const a=spin+i*Math.PI*2/count;
    particle(dim,effect,{x:center.x+Math.cos(a)*radius,y:center.y,z:center.z+Math.sin(a)*radius});
  }
}
function enemy(p,e) {
  return valid(e) && e.id!==p.id && !areAllies(p,e) && (CONFIG.pvp || e.typeId!=="minecraft:player");
}

// 공포: 작고 검붉은 감정 구체를 직선으로 발사. 명중 시 공포 디버프
// (시야 차단·둔화·약화)와 밀려남 효과를 부여합니다.
function fear(p,job,def) {
  const dim=p.dimension, start=headPos(p), f=p.getViewDirection();
  const origin={x:start.x,y:start.y-.13,z:start.z};
  let travel=0;
  sound(dim,"mob.ghast.charge",p.location,{volume:.65,pitch:.5});
  const id=system.runInterval(()=>{
    try {
      if (!p.isValid || p.dimension.id!==dim.id || travel>=def.range) {system.clearRun(id);return;}
      for(let sub=0;sub<2;sub++) {
        travel+=def.speed/2;
        const q={x:origin.x+f.x*travel,y:origin.y+f.y*travel,z:origin.z+f.z*travel};
        particle(dim,FEAR,q);
        if ((Math.ceil(travel*2))%3===0) particle(dim,SOUL,{x:q.x-.17,y:q.y+.07,z:q.z+.08});
        const target=getTargets(p,q,1.15,.8).find(e=>enemy(p,e));
        if (target) {
          hurt(target,p,def.damage);
          applyEffect(target,"slowness",def.fearTicks,2);
          applyEffect(target,"weakness",def.fearTicks,1);
          applyEffect(target,"blindness",def.fearTicks,0);
          const dx=target.location.x-p.location.x,dz=target.location.z-p.location.z;
          knockback(target,dx,dz,1.1,.14);
          ring(dim,pos(target,.9),.68,12,FEAR);
          sound(dim,"mob.endermen.scream",q,{volume:.5,pitch:1.3});
          system.clearRun(id);return;
        }
      }
    } catch {system.clearRun(id);}
  },1);
  return true;
}

// 흡혈: 반경 6 안의 유효한 적 수를 그대로 재생 단계로 사용 (최대 50).
// 예: 1명=재생 I, 5명=재생 V, 36명=재생 XXXVI. 유지 7초.
function vampirism(p,job,def) {
  const targets=getTargets(p,p.location,def.radius).filter(e=>enemy(p,e));
  if (!targets.length) {notify(p,"§7흡혈할 적이 없습니다.");return false;}
  for (const e of targets) {
    hurt(e,p,def.damage);
    particle(p.dimension,SOUL,pos(e,.85));
    // 빨간 영혼 입자가 자신의 몸으로 모이는 모습.
    const a=pos(e,1), b=pos(p,1.2);
    for (let i=1;i<=4;i++) {
      const t=i/5;
      particle(p.dimension,FEAR,{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t});
    }
  }
  const level=Math.min(def.maxLevel,targets.length);
  applyEffect(p,"regeneration",def.regenerationTicks,level-1);
  sound(p.dimension,"mob.evocation_illager.cast_spell",p.location,{volume:.8,pitch:.75});
  notify(p,`§c흡혈! §f${targets.length}명 적중 · 재생 ${level} (7초)`);
  return true;
}

// 수확: 전방 낫 모양 참격 (0.18~0.2블럭 파티클만 사용).
function reap(p,job,def) {
  const dim=p.dimension,f=flatDir(p),l=p.location;
  const targets=getTargets(p,l,def.range+0.3).filter(e=>{
    if (!enemy(p,e))return false;
    const dx=e.location.x-l.x,dz=e.location.z-l.z, d=Math.hypot(dx,dz);
    return d<=def.range && (d<.01 || (dx*f.x+dz*f.z)/d>=.24) && Math.abs(e.location.y-l.y)<3;
  });
  for(const e of targets) hurt(e,p,def.damage);
  // 낫 궤적: 플레이어 정면을 가로지르는 얇은 붉은 초승달
  const s={x:-f.z,z:f.x};
  for(let i=0;i<21;i++){
    const t=i/20,a=(t-.5)*2.25;
    const r=2.3+Math.sin(t*Math.PI)*.42;
    particle(dim,i%3?FEAR:SOUL,{
      x:l.x+f.x*r+ s.x*Math.sin(a)*2.25,
      y:l.y+.7+Math.cos(a)*.95,
      z:l.z+f.z*r+ s.z*Math.sin(a)*2.25,
    });
  }
  sound(dim,"random.anvil_use",l,{volume:.75,pitch:1.65});
  notify(p,`§c수확! §f${targets.length}명 적중`);
  return true;
}

// 계약은 입력 두 개를 동시에 지원한다.
// 우클릭=자신의 체력 5칸(HP 10) 소모 + 저항 III / 흡수 X 2분.
// 좌클릭=대상에게 HP 14 피해 + 힘 III 5초 (같은 길드/파티 아군 제외).
function contract(p,job,def,target) {
  if (target) {
    if (!enemy(p,target) || dist3(target.location,p.location)>5.5) return false;
    hurt(target,p,def.enemyDamage);
    applyEffect(target,"strength",def.enemyStrengthTicks,2);
    particle(p.dimension,SOUL,pos(target,.95));
    ring(p.dimension,pos(target,.95),.7,12,FEAR);
    sound(p.dimension,"mob.enderdragon.growl",target.location,{volume:.55,pitch:1.6});
    notify(p,"§c계약: §f적에게 7칸 피해 / 힘 III 5초");
    return true;
  }
  const health=p.getComponent("minecraft:health");
  if (!health || health.currentValue<=def.healthCost) {
    notify(p,"§c계약에 필요한 체력이 부족합니다. (5칸 초과 필요)");
    return false;
  }
  try { health.setCurrentValue(Math.max(1,health.currentValue-def.healthCost)); }
  catch {notify(p,"§c체력을 소모할 수 없습니다.");return false;}
  applyEffect(p,"resistance",def.buffTicks,2);    // 저항 III
  applyEffect(p,"absorption",def.buffTicks,9);    // 흡수 X
  ring(p.dimension,pos(p,1),1.1,18,FEAR);
  sound(p.dimension,"mob.evocation_illager.prepare_summon",p.location,{volume:.8,pitch:.8});
  notify(p,"§4계약: §f체력 5칸 소모 / 저항 III + 흡수 X (2분)");
  return true;
}
function cleanse(p) {
  let cleared=0;
  try {
    for (const fx of p.getEffects()) {
      const name=String(fx.typeId ?? "").replace(/^minecraft:/,"");
      if (!badEffects.has(name)) continue;
      try {p.removeEffect(name);cleared++;} catch {}
    }
  } catch {}
  return cleared;
}

// 공포의 폭풍: 시전자 중심 반경 10, 10초, 1초마다 정확히 HP 6의 피해.
function storm(p,job,def) {
  const cured=cleanse(p),dim=p.dimension;
  sound(dim,"mob.wither.spawn",p.location,{volume:.9,pitch:1.65});
  let elapsed=0, hits=0;
  const id=system.runInterval(()=>{
    try{
      if(!p.isValid || p.dimension.id!==dim.id || elapsed>=def.duration){system.clearRun(id);return;}
      elapsed+=5;
      const q=pos(p,.65);
      const r=def.radius;
      // 얇은 검붉은 폭풍 띠. 파티클 자체는 0.18~0.2 블럭.
      ring(dim,q,r,18,FEAR,elapsed*.06);
      ring(dim,{x:q.x,y:q.y+1.3,z:q.z},r*.63,12,SOUL,-elapsed*.13);
      if(elapsed%20!==0)return;
      const targets=getTargets(p,p.location,r).filter(e=>enemy(p,e));
      for(const e of targets){if(hurt(e,p,def.damagePerSecond))hits++;}
    } catch {system.clearRun(id);}
  },5);
  notify(p,`§4공포의 폭풍! §f디버프 ${cured}개 해제 · 10초간 주위 적 공격`);
  return true;
}
export const RUNNERS={
  demon_fear:fear,
  demon_vampirism:vampirism,
  demon_reap:reap,
  demon_contract:contract,
  demon_storm:storm,
};

// 패시브 '영혼 수확': 악마가 엔티티를 쓰러뜨릴 때 HP 6(체력 3칸) 즉시 회복
// + 재생 II 5초. 자신/아군 처치는 제외.
export function registerDemon() {
  if(registered)return;
  registered=true;
  world.afterEvents.entityDie.subscribe(ev=>{
    try{
      let killer=ev.damageSource?.damagingEntity;
      if(killer?.typeId!=="minecraft:player") {
        killer=ev.damageSource?.damagingProjectile?.getComponent("minecraft:projectile")?.owner;
      }
      if(killer?.typeId!=="minecraft:player" || getJobId(killer)!=="demon") return;
      const dead=ev.deadEntity;
      if(!dead || dead.id===killer.id || areAllies(killer,dead))return;
      const hp=killer.getComponent("minecraft:health");
      if(!hp)return;
      const cap=hp.effectiveMax??hp.defaultValue??20;
      hp.setCurrentValue(Math.min(cap,hp.currentValue+6));
      applyEffect(killer,"regeneration",100,1);
      particle(killer.dimension,SOUL,pos(killer,1.3));
      sound(killer.dimension,"random.orb",killer.location,{volume:.6,pitch:.7});
    }catch{}
  });
}
