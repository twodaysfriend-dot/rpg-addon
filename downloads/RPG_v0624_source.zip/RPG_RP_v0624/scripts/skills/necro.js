import { world, system, EntityDamageCause } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { getJobId, addProgress } from "../core/playerData.js";
import { firstTargetInView, dist3, healthAlive, sound, particle, flatDir } from "../core/util.js";
import { getLastHit } from "../core/tracking.js";
import { notify } from "../core/hud.js";

const MINION = "rpg:bone_minion";
const OWNER = "rpg:necro_owner";
const TARGET = "rpg:necro_target";
const LIFE = "rpg:necro_remaining";
const LIMIT = { apprentice: 1, necromancer: 3, deathlord: 6 };
const DAMAGE = { apprentice: 3, necromancer: 5, deathlord: 8 };
const HOSTILE = new Set([
 "minecraft:zombie","minecraft:husk","minecraft:drowned","minecraft:skeleton",
 "minecraft:stray","minecraft:creeper","minecraft:spider","minecraft:cave_spider",
 "minecraft:pillager","minecraft:vindicator","minecraft:evoker","minecraft:ravager",
 "minecraft:witch","minecraft:phantom","minecraft:endermite","minecraft:silverfish",
 "minecraft:slime","minecraft:magma_cube","minecraft:blaze","minecraft:ghast",
 "minecraft:hoglin","minecraft:zoglin","minecraft:piglin_brute","minecraft:wither_skeleton",
 "minecraft:breeze","minecraft:bogged","minecraft:shulker","minecraft:guardian",
 "minecraft:elder_guardian","minecraft:warden"
]);
const nextHit = new Map();
const isMinion = e => e?.typeId === MINION;
const ownerOf = e => {try{return e.getDynamicProperty(OWNER);}catch{return undefined;}};
const valid = e => {try{return e?.isValid && healthAlive(e);}catch{return false;}};

function allMine(p, distance = 55) {
  try {return p.dimension.getEntities({type:MINION, location:p.location, maxDistance:distance})
    .filter(e => ownerOf(e) === p.id && valid(e));}
  catch {return [];}
}
function safeSpawn(p, step) {
  const d = flatDir(p), pos=p.location;
  let point={x:pos.x+d.x*(2+step%2)+((step%3)-1)*1.2,y:pos.y+0.2,z:pos.z+d.z*(2+step%2)+((step%2)-0.5)};
  try {
    const feet=p.dimension.getBlock(point), head=p.dimension.getBlock({...point,y:point.y+1.1});
    if(feet?.isSolid || head?.isSolid)point={x:pos.x+(step%3-1)*1.4,y:pos.y+0.2,z:pos.z+1.8};
  }catch{}
  return point;
}
function summon(p,count,life=3600) {
  const max=LIMIT[getJobId(p)]??1;
  const current=allMine(p).length;
  const slots=Math.max(0,max-current);
  if(slots===0){notify(p,`§7이미 최대 ${max}마리를 소환했습니다.`);return false;}
  let made=0;
  for(let i=0;i<Math.min(count,slots);i++) {
    try {
      const e=p.dimension.spawnEntity(MINION,safeSpawn(p,i+current));
      e.setDynamicProperty(OWNER,p.id);
      e.setDynamicProperty(LIFE,life);
      e.nameTag=`§5${p.name}의 망자`;
      made++;
    }catch(err){console.warn('[rpg-necro] summon error: '+err);}
  }
  if(!made)return false;
  sound(p.dimension,'mob.skeleton.say',p.location,{volume:0.5,pitch:0.7});
  notify(p,`§d망자 ${made}마리 소환! §7(${current+made}/${max})`);
  return true;
}
function isEnemy(e, owner, manual=false) {
  if(!valid(e)||e.id===owner.id||isMinion(e)||e.typeId==='rpg:sandbag_entity')return false;
  if(e.typeId==='minecraft:player')return manual && CONFIG.pvp;
  return manual || HOSTILE.has(e.typeId);
}
function commandedTarget(owner,def) {
  try {
    const hits=owner.getEntitiesFromViewDirection({maxDistance:def.range??30});
    for(const h of hits){ if(isEnemy(h.entity,owner,true))return h.entity; }
  }catch{}
  const viewed=firstTargetInView(owner,def.range??30);
  if(isEnemy(viewed,owner,true))return viewed;
  const last=getLastHit(owner);
  if(isEnemy(last,owner,true) && dist3(last.location,owner.location)<=(def.range??30))return last;
  return null;
}
function summonRunner(p,job,def){
  const cnt=job.id==='deathlord'?3:job.id==='necromancer'?2:1;
  return summon(p,cnt,def.duration??3600);
}
function commandRunner(p,job,def){
  const target=commandedTarget(p,def);
  if(!target){notify(p,'§7바라보는 적 또는 최근 공격한 적이 없습니다.');return false;}
  const army=allMine(p);
  if(!army.length){notify(p,'§7소환수가 없습니다.');return false;}
  for(const e of army){try{e.setDynamicProperty(TARGET,target.id);}catch{}}
  notify(p,`§c집중 공격: ${target.nameTag||target.typeId}`);
  return true;
}
function recallRunner(p){
  const army=allMine(p);
  if(!army.length){notify(p,'§7집결할 소환수가 없습니다.');return false;}
  for(let i=0;i<army.length;i++) {
    try {army[i].setDynamicProperty(TARGET,undefined); army[i].teleport(safeSpawn(p,i));}catch{}
  }
  notify(p,`§d망자 ${army.length}마리 집결`);
  return true;
}
function legionRunner(p,job,def){ return summon(p,6,def.duration??2400); }

export const RUNNERS={
 necro_summon:summonRunner,
 necro_command:commandRunner,
 necro_recall:recallRunner,
 necro_legion:legionRunner
};

function stepMinion(minion,owner,now, nearby) {
  let life=minion.getDynamicProperty(LIFE);
  if(typeof life!=='number')life=3600;
  life-=5;
  if(life<=0){minion.remove();return;}
  minion.setDynamicProperty(LIFE,life);
  let target=null;
  const tid=minion.getDynamicProperty(TARGET);
  if(typeof tid==='string'&&tid) {
    target=nearby.find(e=>e.id===tid && isEnemy(e,owner,true))??null;
    if(!target)minion.setDynamicProperty(TARGET,undefined);
  }
  if(!target){
    const last=getLastHit(owner);
    if(last && isEnemy(last,owner,true)&&dist3(last.location,minion.location)<16)target=last;
  }
  if(!target){
    let dist=11;
    for(const e of nearby){
      if(!isEnemy(e,owner))continue;
      const d=dist3(e.location,minion.location);
      if(d<dist){dist=d;target=e;}
    }
  }
  let destination=target?.location??owner.location;
  const distance=dist3(minion.location,destination);
  const leash=dist3(minion.location,owner.location);
  if(leash>30){
    minion.teleport(safeSpawn(owner, (now/5)%4));
    return;
  }
  if(target && distance<2.1){
    const last=nextHit.get(minion.id)??0;
    if(now-last>=15){
      nextHit.set(minion.id,now);
      try{
        target.applyDamage(DAMAGE[getJobId(owner)]??3,{
          cause:EntityDamageCause.entityAttack,damagingEntity:minion
        });
        particle(owner.dimension,'minecraft:basic_crit_particle',target.location);
      }catch{}
    }
    return;
  }
  // Step-wise movement + collision checks. Teleport back to the owner if paths are blocked.
  if(!target && distance<2.8)return;
  if(distance>0.3) {
    const scale=Math.min(0.7,distance)/distance;
    let p={x:minion.location.x+(destination.x-minion.location.x)*scale,
      y:minion.location.y+Math.max(-0.4,Math.min(0.4,destination.y-minion.location.y)),
      z:minion.location.z+(destination.z-minion.location.z)*scale};
    try{
      const feet=owner.dimension.getBlock({...p,y:p.y+0.2});
      const head=owner.dimension.getBlock({...p,y:p.y+1.4});
      if(feet?.isSolid||head?.isSolid)return;
      minion.teleport(p,{facingLocation:destination});
    }catch{}
  }
}

export function registerNecromancer(){
  // Owner-tracked entities are persistent through world reloads via dynamic properties.
  system.runInterval(()=>{
    const now=system.currentTick;
    for(const p of world.getAllPlayers()){
      try {
        if(!['apprentice','necromancer','deathlord'].includes(getJobId(p)))continue;
        const army=allMine(p);
        const nearby=p.dimension.getEntities({location:p.location,maxDistance:38,
          excludeTypes:['minecraft:item','minecraft:xp_orb','minecraft:armor_stand']});
        for(const m of army)stepMinion(m,p,now,nearby);
      }catch(err){console.warn('[rpg-necro] update error: '+err);}
    }
  },5);
  world.afterEvents.entityDie.subscribe(ev=>{
    const dead=ev.deadEntity;
    if(isMinion(dead)){nextHit.delete(dead.id);return;}
    const killer=ev.damageSource?.damagingEntity;
    if(!isMinion(killer))return;
    const id=ownerOf(killer);
    const player=world.getAllPlayers().find(p=>p.id===id);
    if(!player||!['necromancer','deathlord'].includes(getJobId(player)))return;
    const n=addProgress(player,'necro_minion_kills',1);
    if(n===40)notify(player,'§a소환수 처치 40회 달성! 반물질의 신으로 전직할 수 있습니다.');
  });
  world.afterEvents.playerLeave.subscribe(ev=>{
    // Linked minions will be removed when a player leaves instead of remaining hostile ghosts.
    for(const dimId of ['overworld','nether','the_end']) {
      try{
        for(const m of world.getDimension(dimId).getEntities({type:MINION})) {
          if(ownerOf(m)===ev.playerId){nextHit.delete(m.id);m.remove();}
        }
      }catch{}
    }
  });
}
