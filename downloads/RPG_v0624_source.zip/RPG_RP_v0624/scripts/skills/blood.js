import { world, system, ItemStack, EquipmentSlot } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { getJobId } from "../core/playerData.js";
import { getTargets, hurt, particle, sound, headPos, norm3, dist3, isSolidAt, firstTargetInView } from "../core/util.js";
import { notify } from "../core/hud.js";

const BLOOD = "rpg:blood_spark";
const SIGIL = "rpg:blood_sigil";
const BURST = "rpg:blood_burst";
const SPEAR = "rpg:blood_spear";
const bursts = new Map();
const pinned = new Map();
let installed = false;

function valid(e) { try {return !!e?.isValid && (e.getComponent('minecraft:health')?.currentValue ?? 0)>0;}catch{return false;} }
function enemy(p,e){return valid(e) && e.id!==p.id && (e.typeId!=="minecraft:player" || CONFIG.pvp);}
function pos(p,y=1){let a=p.location; return {x:a.x,y:a.y+y,z:a.z};}
function emit(dim,location,id=BLOOD,n=1){for(let i=0;i<n;i++)particle(dim,id,{x:location.x+(i%3-1)*0.10,y:location.y+((i*3)%5)*0.09,z:location.z+(i%5-2)*0.10});}
function trace(dim,a,b,id=BLOOD,step=.6){const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z; const total=Math.hypot(dx,dy,dz);for(let k=0;k<=Math.min(64,Math.ceil(total/step));k++){let t=k/Math.max(1,Math.ceil(total/step));particle(dim,id,{x:a.x+dx*t,y:a.y+dy*t,z:a.z+dz*t});}}
function shot(player,dir,range,velocity,hitRadius,onImpact,fx=BLOOD){
  const dim=player.dimension,source=headPos(player),from={x:source.x+dir.x*.75,y:source.y+dir.y*.75,z:source.z+dir.z*.75};
  let travel=0;
  const ticker=system.runInterval(()=>{
    try{
      if(!player.isValid || travel>=range){system.clearRun(ticker);return;}
      for(let sub=0;sub<3;sub++){
        travel+=velocity/3;
        const pt={x:from.x+dir.x*travel,y:from.y+dir.y*travel,z:from.z+dir.z*travel};
        if(isSolidAt(dim,pt)){emit(dim,pt,SIGIL,4);system.clearRun(ticker);return;}
        if(sub===0 || sub===2) particle(dim,fx,pt);
        const targets=getTargets(player,pt,hitRadius,.8).filter(e=>enemy(player,e));
        if(targets.length){onImpact(targets[0],pt);emit(dim,pt,SIGIL,8);system.clearRun(ticker);return;}
      }
    }catch{system.clearRun(ticker);}
  },1);
}

function spear(player,job,def){
  try{
    const item=new ItemStack(SPEAR,1);
    item.setDynamicProperty("rpg:spear_hits",0);
    item.setLore(["§c피의 창§r", "§7공격력 10 · 명중 시 시듦 I 3초", "§7남은 사용 횟수: 10/10"]);
    const container=player.getComponent('minecraft:inventory')?.container;
    if(!container)return false;
    const leftover=container.addItem(item);
    if(leftover)player.dimension.spawnItem(leftover,pos(player,.5));
    emit(player.dimension,pos(player,1),SIGIL,12);
    notify(player,"§c피의 창 생성! §7창으로 10회 공격할 수 있습니다.");
    sound(player.dimension,'mob.blaze.shoot',player.location,{volume:.65,pitch:.65});
    return true;
  }catch{return false;}
}
function orb(player,job,def){
  const d=norm3(player.getViewDirection());
  shot(player,d,def.range,def.speed,1.5,(target,point)=>{
    hurt(target,player,def.damage);
    const list=getTargets(player,point,def.burstRadius,.7).filter(e=>enemy(player,e)&&e.id!==target.id);
    for(const e of list)hurt(e,player,def.splashDamage);
    for(let j=0;j<12;j++){
      const a=j*Math.PI*2/12;
      particle(player.dimension,BURST,{x:point.x+Math.cos(a)*0.8,y:point.y+0.1,z:point.z+Math.sin(a)*0.8});
    }
    emit(player.dimension,point,SIGIL,4);
    sound(player.dimension,'random.explode',point,{volume:.8,pitch:.5});
  },SIGIL);
  emit(player.dimension,pos(player,1.2),BURST,3);
  sound(player.dimension,'mob.blaze.shoot',player.location,{volume:1,pitch:.45});return true;
}
function supernova(player,job,def){
  const v=norm3(player.getViewDirection());
  const side=norm3({x:-v.z,y:0,z:v.x});
  const up=norm3({x:-v.x*v.y,y:Math.sqrt(v.x*v.x+v.z*v.z),z:-v.z*v.y});
  const hitCounts=new Map(), base=headPos(player),dim=player.dimension;
  for(let i=0;i<def.pellets;i++){
    const theta=i*Math.PI*2/def.pellets;
    const radius=.09+((i*7)%5)/5*def.spread;
    const dir=norm3({x:v.x+side.x*Math.cos(theta)*radius+up.x*Math.sin(theta)*radius,
      y:v.y+side.y*Math.cos(theta)*radius+up.y*Math.sin(theta)*radius,
      z:v.z+side.z*Math.cos(theta)*radius+up.z*Math.sin(theta)*radius});
    for(let t=1;t<=def.range;t+=.65){
      const point={x:base.x+dir.x*t,y:base.y+dir.y*t,z:base.z+dir.z*t};
      if(isSolidAt(dim,point))break;
      particle(dim,(i+t*10)%2<1?BLOOD:SIGIL,point);
      if(Math.round(t*10)%15===0) particle(dim,BURST,point);
      const target=getTargets(player,point,.75,.85).find(e=>enemy(player,e));
      if(target){
        const old=hitCounts.get(target.id)??0;
        if(old<3){hurt(target,player,def.pelletDamage);hitCounts.set(target.id,old+1); emit(dim, pos(target,1.0), BURST, 2);}
        break;
      }
    }
  }
  emit(dim,{x:base.x+v.x*1.2,y:base.y+v.y*1.2,z:base.z+v.z*1.2},BURST,5);
  emit(dim,{x:base.x+v.x*1.5,y:base.y+v.y*1.5,z:base.z+v.z*1.5},SIGIL,6);
  sound(dim,'random.explode',player.location,{volume:.8,pitch:.7});return true;
}
function bloodMark(player,job,def){
  const target=firstTargetInView(player,def.range);
  if(target && enemy(player,target) && dist3(player.location,target.location)<=def.meleeRange){
    trace(player.dimension,pos(player,1.25),pos(target,1.0),SIGIL,.25);
    emit(player.dimension,pos(target,1.0),BURST,5);
    hurt(target,player,def.meleeDamage);
    sound(player.dimension,'random.anvil_land',target.location,{volume:.35,pitch:1.7});
    notify(player,'§c혈인: 근거리 혈검');return true;
  }
  const dir=norm3(player.getViewDirection());
  shot(player,dir,def.range,1.45,1.45,(e,hit)=>{
    hurt(e,player,def.rangedDamage);
    for(let j=0;j<16;j++){
      const a=j*Math.PI*2/16;
      particle(player.dimension,SIGIL,{x:hit.x+Math.cos(a)*1.25,y:hit.y+Math.sin(a)*0.15,z:hit.z+Math.sin(a)*0.15});
      if(j%2===0) particle(player.dimension,BURST,{x:hit.x+Math.cos(a)*0.9,y:hit.y,z:hit.z+Math.sin(a)*0.9});
    }
    emit(player.dimension,hit,BLOOD,6);
  },BURST);
  sound(player.dimension,'mob.blaze.shoot',player.location,{volume:.5,pitch:1.6});
  notify(player,'§c혈인: 원거리 혈원반');return true;
}
export function bloodAwakenIsActive(p){return bursts.has(p.id);}
export function bloodAwakenStop(p){
  if(!bursts.delete(p.id))return false;
  for(const effect of ['strength','resistance','hunger','wither'])try{p.removeEffect(effect);}catch{}
  notify(p,'§7혁린약동•재 해제');return true;
}
function awaken(player,job,def){
  if(bursts.has(player.id)){bloodAwakenStop(player);return false;}
  bursts.set(player.id,{start:system.currentTick,def});
  notify(player,'§c혁린약동•재 활성화! §7다시 사용하면 해제합니다.');
  return true;
}
function bloodBind(player,job,def){
  const dim=player.dimension, targets=getTargets(player,player.location,def.radius).filter(e=>enemy(player,e));
  let total=0;
  for(const e of targets){
    const anchor={...e.location};
    pinned.set(e.id,{entity:e,anchor,until:system.currentTick+def.duration,dimensionId:dim.id});
    try{e.addEffect('slowness',def.duration,{amplifier:255,showParticles:true});}catch{}
    for(let j=0;j<14;j++){
      const angle=j*Math.PI*2/14;
      particle(dim,SIGIL,{x:anchor.x+Math.cos(angle)*.7,y:anchor.y+.5+(j%3)*.4,z:anchor.z+Math.sin(angle)*.7});
    }
    total++;
  }
  if(!total){notify(player,'§716블럭 안에 묶을 대상이 없습니다.');return false;}
  sound(dim,'mob.endermen.portal',player.location,{volume:.8,pitch:.6});
  notify(player,`§c적박: §f${total}마리 3초 결박`);return true;
}
export const RUNNERS={
  blood_spear:spear,
  blood_orb:orb,
  blood_supernova:supernova,
  blood_mark:bloodMark,
  blood_awaken:awaken,
  blood_bind:bloodBind,
};

export function registerBloodMagic(){
  if(installed)return;installed=true;
  world.afterEvents.entityHitEntity.subscribe(event=>{
    const p=event.damagingEntity;
    if(p?.typeId!=='minecraft:player'||!event.hitEntity)return;
    try{
      const eq=p.getComponent('minecraft:equippable');
      const weapon=eq?.getEquipment(EquipmentSlot.Mainhand);
      if(weapon?.typeId!==SPEAR)return;
      if(enemy(p,event.hitEntity)){
        event.hitEntity.addEffect('wither',60,{amplifier:0,showParticles:true});
      }
      const hits=Number(weapon.getDynamicProperty('rpg:spear_hits')??0)+1;
      if(hits>=10){eq.setEquipment(EquipmentSlot.Mainhand,undefined);notify(p,'§7피의 창이 소멸했습니다.');}
      else{
        weapon.setDynamicProperty('rpg:spear_hits',hits);
        const d=weapon.getComponent('minecraft:durability');
        if(d)d.damage=Math.min(hits,9);
        weapon.setLore(['§c피의 창§r','§7공격력 10 · 시듦 I 3초',`§7남은 사용 횟수: ${10-hits}/10`]);
        eq.setEquipment(EquipmentSlot.Mainhand,weapon);
      }
    }catch{}
  });
  system.runInterval(()=>{
    const now=system.currentTick;
    for(const [id,s] of bursts){
      const p=world.getAllPlayers().find(x=>x.id===id);
      if(!p || getJobId(p)!=='blood_mage'){bursts.delete(id);continue;}
      try{
        for(const [name,level] of [['strength',2],['resistance',2],['hunger',2]])p.addEffect(name,35,{amplifier:level,showParticles:false});
        if(now-s.start>=3600){p.addEffect('wither',35,{amplifier:0,showParticles:false});}
      }catch{bursts.delete(id);}
    }
    for(const [id,s] of pinned){
      if(now>=s.until || !valid(s.entity)){pinned.delete(id);continue;}
      try{
        if(s.entity.dimension.id!==s.dimensionId){pinned.delete(id);continue;}
        const here=s.entity.location;
        if(dist3(here,s.anchor)>.35)s.entity.teleport(s.anchor,{dimension:s.entity.dimension,keepVelocity:false});
        if(now%10===0)emit(s.entity.dimension,pos(s.entity,1),SIGIL,4);
      }catch{pinned.delete(id);}
    }
  },5);
  world.afterEvents.playerLeave.subscribe(ev=>bursts.delete(ev.playerId));
  world.afterEvents.entityDie.subscribe(ev=>{if(ev.deadEntity?.typeId==='minecraft:player')bursts.delete(ev.deadEntity.id);});
}
