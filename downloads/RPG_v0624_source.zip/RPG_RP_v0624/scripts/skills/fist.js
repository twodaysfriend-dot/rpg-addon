import { system, world, EntityDamageCause } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { JOBS } from "../data/jobs.js";
import {
  getTargets, hurt, knockback, particle, sound, flatDir, isSolidAt, dist3, healthAlive, headPos,
} from "../core/util.js";
import { notify } from "../core/hud.js";
import { getLastHit } from "../core/tracking.js";
import { getJobId } from "../core/playerData.js";
import {
  giveDoubleBuff, doubleLeft, takeDouble, markSkillHit, consumeSkillMark, clearFistRuntime,
} from "../core/fistState.js";

// ---------------------------------------------------------------------------
// 무투가 / 권골 (line: "fist")
//  무투가 : 강펀치, 난타, 스매쉬
//  권골   : + 풍압, 안면강타, 강자의 자세, 대미장식(궁극기)
//  패시브 : 낙하 피해 없음 (무투가, 권골)
// 숫자는 data/skills.js 와 config.js 의 fist 항목에서 조정합니다.
// ---------------------------------------------------------------------------

const RED = "minecraft:redstone_ore_dust_particle";
const HIT = "minecraft:critical_hit_emitter";
const BOOM = "minecraft:large_explosion";
const HUGE = "minecraft:huge_explosion_emitter";
const SMOKE = "minecraft:basic_smoke_particle";

// ---- 작은 도우미들 ----
function fx(entity, id, ticks, amp = 0, show = false) {
  try {
    entity.addEffect(id, ticks, { amplifier: amp, showParticles: show });
  } catch {
    // 효과를 받을 수 없는 대상
  }
}

function unfx(entity, ids) {
  for (const id of ids) {
    try {
      entity.removeEffect(id);
    } catch {
      // 이미 사라진 효과/엔티티
    }
  }
}

// 움직이지도, 점프하지도, 제대로 때리지도 못하게 만듭니다.
const STUN_EFFECTS = ["slowness", "jump_boost", "weakness", "mining_fatigue"];
function stun(entity, ticks) {
  fx(entity, "slowness", ticks, 255);
  fx(entity, "jump_boost", ticks, 200);
  fx(entity, "weakness", ticks, 255);
  fx(entity, "mining_fatigue", ticks, 255);
}

// 힘 효과로 늘어나는 피해량
function strengthBonus(entity) {
  try {
    const e = entity.getEffect("strength");
    return e ? (e.amplifier + 1) * CONFIG.fist.strengthPerLevel : 0;
  } catch {
    return 0;
  }
}

// (기본 피해 + 힘 버프 증가분) x 강펀치 배율
function power(player, base, mult) {
  return (base + strengthBonus(player)) * mult;
}

function bodyCenter(e) {
  const l = e.location;
  return { x: l.x, y: l.y + 1, z: l.z };
}

// 일반 피해(방어력 적용). 강펀치가 '평타'로 착각하지 않도록 표시를 남깁니다.
function strike(target, player, amount) {
  markSkillHit(target.id, player.id);
  return hurt(target, player, amount);
}

// 방어력/무적 시간을 무시하는 고정 피해
function trueHit(target, player, amount) {
  try {
    target.applyDamage(amount, { cause: EntityDamageCause.override, damagingEntity: player });
    return true;
  } catch {
    return strike(target, player, amount);
  }
}

function ring(dim, c, r, id, n = 16, dy = 0) {
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    particle(dim, id, { x: c.x + Math.cos(a) * r, y: c.y + dy, z: c.z + Math.sin(a) * r });
  }
}

function pathClear(dim, a, b) {
  const d = dist3(a, b);
  const n = Math.max(1, Math.floor(d));
  for (let i = 1; i < n; i++) {
    const p = {
      x: a.x + ((b.x - a.x) * i) / n,
      y: a.y + ((b.y - a.y) * i) / n,
      z: a.z + ((b.z - a.z) * i) / n,
    };
    if (isSolidAt(dim, p)) return false;
  }
  return true;
}

// 바라보는 방향(원뿔) 안에서 가장 가까운 대상. minDot 은 시선과의 cos 값(0.85 ≈ 32도).
function nearestInView(player, range, minDot) {
  const dim = player.dimension;
  const eye = headPos(player);
  const v = player.getViewDirection();
  let best;
  let bestD = Infinity;
  for (const t of getTargets(player, eye, range)) {
    const c = bodyCenter(t);
    const dx = c.x - eye.x;
    const dy = c.y - eye.y;
    const dz = c.z - eye.z;
    const d = Math.hypot(dx, dy, dz) || 0.001;
    if ((dx * v.x + dy * v.y + dz * v.z) / d < minDot) continue;
    if (!pathClear(dim, eye, c)) continue;
    if (d < bestD) {
      bestD = d;
      best = t;
    }
  }
  return best;
}

function validTarget(target, player, radius) {
  try {
    return (
      !!target &&
      healthAlive(target) &&
      target.dimension.id === player.dimension.id &&
      dist3(target.location, player.location) <= radius
    );
  } catch {
    return false;
  }
}

function trail(dim, a, b) {
  const n = Math.min(24, Math.max(1, Math.floor(dist3(a, b) / 0.6)));
  for (let i = 0; i <= n; i++) {
    particle(dim, RED, {
      x: a.x + ((b.x - a.x) * i) / n,
      y: a.y + 1 + ((b.y - a.y) * i) / n,
      z: a.z + ((b.z - a.z) * i) / n,
    });
  }
}

// ---------------------------------------------------------------------------
// 스킬
// ---------------------------------------------------------------------------
export const RUNNERS = {
  // 강펀치: 사용 후 다음 N번의 공격(평타 1회 / 피해를 주는 스킬 1회)이 2배 피해.
  // 피해량은 힘 버프가 적용된 최종 피해를 기준으로 2배가 됩니다.
  fist_strong(player, job, def) {
    giveDoubleBuff(player, def.hits, def.duration);
    const dim = player.dimension;
    const l = player.location;
    ring(dim, { x: l.x, y: l.y, z: l.z }, 0.9, RED, 14, 0.2);
    ring(dim, { x: l.x, y: l.y, z: l.z }, 0.9, HIT, 8, 1.0);
    sound(dim, "random.anvil_land", l, { volume: 0.5, pitch: 1.6 });
    sound(dim, "mob.irongolem.throw", l, { volume: 0.8, pitch: 0.8 });
    notify(player, `§c강펀치! §7다음 ${def.hits}번 공격 피해 2배`);
  },

  // 난타: 대상에게 달라붙어 연속으로 때립니다. damage 는 전체 합계(체력 10칸 = 20).
  fist_flurry(player, job, def) {
    const dim = player.dimension;
    const origin = { ...player.location };
    const rot = player.getRotation();

    let target = getLastHit(player);
    if (!validTarget(target, player, def.radius)) target = nearestInView(player, def.range, 0.7);
    if (!target) {
      notify(player, "§7난타할 대상이 없습니다. 먼저 공격하거나 대상을 바라보세요.");
      return false;
    }

    const mult = takeDouble(player);
    const perHit = power(player, def.damage, mult) / def.hits;
    if (mult > 1) notify(player, `§c강펀치 적용! §7남은 횟수 ${doubleLeft(player)}`);

    fx(player, "resistance", def.hits * def.stepTicks + 20, 1);

    let hitCount = 0;
    let tick = 0;
    let last = origin;

    const finish = () => {
      system.clearRun(id);
      try {
        if (def.returnToOrigin) {
          trail(dim, last, origin);
          player.teleport(origin, { rotation: rot });
        }
      } catch {
        // 플레이어가 사라진 경우
      }
    };

    const id = system.runInterval(() => {
      try {
        if (hitCount >= def.hits || !healthAlive(target)) {
          finish();
          return;
        }
        if (tick % def.stepTicks === 0) {
          const tl = target.location;
          // 대상 둘레를 돌며 매번 다른 각도에서 때린다
          const ang = hitCount * 2.4;
          let stand = { x: tl.x + Math.cos(ang) * 1.3, y: tl.y, z: tl.z + Math.sin(ang) * 1.3 };
          if (isSolidAt(dim, stand) || isSolidAt(dim, { x: stand.x, y: stand.y + 1, z: stand.z })) {
            stand = { x: tl.x, y: tl.y, z: tl.z };
          }
          player.teleport(stand, { facingLocation: { x: tl.x, y: tl.y + 1, z: tl.z } });
          trueHit(target, player, perHit);
          const finisher = hitCount === def.hits - 1;
          knockback(target, tl.x - stand.x, tl.z - stand.z, finisher ? 1.0 : 0.1, finisher ? 0.4 : 0.05);
          particle(dim, HIT, { x: tl.x, y: tl.y + 1, z: tl.z });
          particle(dim, finisher ? BOOM : RED, { x: tl.x, y: tl.y + 1, z: tl.z });
          sound(dim, finisher ? "random.explode" : "mob.irongolem.hit", tl, {
            volume: finisher ? 0.7 : 0.5,
            pitch: 1.2 + hitCount * 0.04,
          });
          last = stand;
          hitCount++;
        }
        tick++;
      } catch {
        finish();
      }
    }, 1);
  },

  // 스매쉬: 1초 모았다가 바라보는 방향의 가장 가까운 대상에게 날아가 주먹을 날림 (최대 32블럭)
  fist_smash(player, job, def) {
    const dim = player.dimension;
    const target = nearestInView(player, def.range, def.coneDot);
    if (!target) {
      notify(player, "§7바라보는 방향에 대상이 없습니다.");
      return false;
    }

    const mult = takeDouble(player);
    const damage = power(player, def.damage, mult);
    if (mult > 1) notify(player, `§c강펀치 적용! §7남은 횟수 ${doubleLeft(player)}`);

    // 모으는 동안은 제자리에 서 있고, 날아가는 동안에는 받는 피해가 크게 줄어듭니다.
    fx(player, "slowness", def.charge + 2, 255);
    fx(player, "jump_boost", def.charge + 2, 200);
    fx(player, "resistance", def.charge + 60, 1);
    sound(dim, "mob.irongolem.repair", player.location, { volume: 1.0, pitch: 0.6 });

    const punch = () => {
      try {
        if (!healthAlive(target) || dist3(target.location, player.location) > 3.2) return;
        const tl = target.location;
        const pl = player.location;
        strike(target, player, damage);
        knockback(target, tl.x - pl.x, tl.z - pl.z, def.knockback, 0.45);
        const c = bodyCenter(target);
        particle(dim, BOOM, c);
        particle(dim, HIT, c);
        ring(dim, c, 1.2, RED, 14);
        sound(dim, "random.explode", tl, { volume: 0.9, pitch: 1.1 });
        sound(dim, "mob.irongolem.hit", tl, { volume: 1.0, pitch: 0.7 });
      } catch {
        // 대상이 사라짐
      }
    };

    const dash = () => {
      try {
        if (!healthAlive(target) || target.dimension.id !== dim.id) return;
        let last = { ...player.location };
        const maxSteps = Math.ceil((def.range + 10) / def.dashSpeed) + 4;
        let steps = 0;
        const did = system.runInterval(() => {
          try {
            if (!healthAlive(target)) {
              system.clearRun(did);
              return;
            }
            const p = player.location;
            const tl = target.location;
            const dx = tl.x - p.x;
            const dy = tl.y - p.y;
            const dz = tl.z - p.z;
            const d = Math.hypot(dx, dy, dz) || 0.001;
            if (d <= 1.9 || ++steps > maxSteps) {
              system.clearRun(did);
              punch();
              return;
            }
            const mv = Math.min(def.dashSpeed, d - 1.6);
            const next = { x: p.x + (dx / d) * mv, y: p.y + (dy / d) * mv, z: p.z + (dz / d) * mv };
            // 벽에 막히면 그 자리에서 멈춤
            if (
              isSolidAt(dim, { x: next.x, y: next.y + 0.5, z: next.z }) ||
              isSolidAt(dim, { x: next.x, y: next.y + 1.5, z: next.z })
            ) {
              system.clearRun(did);
              return;
            }
            trail(dim, last, next);
            player.teleport(next, { facingLocation: bodyCenter(target) });
            particle(dim, SMOKE, { x: next.x, y: next.y + 1, z: next.z });
            sound(dim, "item.trident.riptide_1", next, { volume: 0.4, pitch: 1.5 });
            last = next;
          } catch {
            system.clearRun(did);
          }
        }, 1);
      } catch {
        // 플레이어 상태를 읽을 수 없음
      }
    };

    let t = 0;
    const cid = system.runInterval(() => {
      try {
        const l = player.location;
        // 주먹으로 기운이 빨려 들어가는 연출
        const r = 2.6 * (1 - t / def.charge) + 0.3;
        for (let k = 0; k < 8; k++) {
          const a = (k / 8) * Math.PI * 2 + t * 0.4;
          particle(dim, RED, { x: l.x + Math.cos(a) * r, y: l.y + 0.6 + (k % 3) * 0.4, z: l.z + Math.sin(a) * r });
        }
        if (t % 5 === 0) sound(dim, "note.bass", l, { volume: 0.6, pitch: 0.6 + t * 0.06 });
        if (++t >= def.charge) {
          system.clearRun(cid);
          unfx(player, ["slowness", "jump_boost"]);
          dash();
        }
      } catch {
        system.clearRun(cid);
      }
    }, 1);
  },

  // 풍압: 엔더드래곤 몸통박치기처럼 앞쪽 넓은 범위의 적을 멀리 날려 보냄
  fist_wind(player, job, def) {
    const dim = player.dimension;
    const l = player.location;
    const dir = flatDir(player);
    const mult = takeDouble(player);
    const damage = power(player, def.damage, mult);
    if (mult > 1) notify(player, `§c강펀치 적용! §7남은 횟수 ${doubleLeft(player)}`);

    sound(dim, "mob.enderdragon.flap", l, { volume: 1.5, pitch: 0.7 });
    sound(dim, "mob.warden.sonic_boom", l, { volume: 0.6, pitch: 1.4 });

    for (const t of getTargets(player, { x: l.x, y: l.y + 1, z: l.z }, def.range)) {
      const tl = t.location;
      const dx = tl.x - l.x;
      const dz = tl.z - l.z;
      const len = Math.hypot(dx, dz) || 0.001;
      if ((dx * dir.x + dz * dir.z) / len < def.coneDot) continue;
      strike(t, player, damage);
      knockback(t, dx, dz, def.knockback, def.vertical);
      const c = bodyCenter(t);
      particle(dim, BOOM, c);
      particle(dim, HIT, c);
    }

    // 앞으로 퍼져 나가는 충격파
    const side = { x: -dir.z, z: dir.x };
    let dist = 1;
    const id = system.runInterval(() => {
      try {
        const o = player.location;
        const spread = dist * 0.9;
        for (let w = -spread; w <= spread; w += 0.8) {
          const p = {
            x: o.x + dir.x * dist + side.x * w,
            y: o.y + 1,
            z: o.z + dir.z * dist + side.z * w,
          };
          particle(dim, SMOKE, p);
          if (Math.abs(w) > spread * 0.7) particle(dim, HIT, p);
        }
        dist += 1.6;
        if (dist > def.range) system.clearRun(id);
      } catch {
        system.clearRun(id);
      }
    }, 1);
  },

  // 안면강타: 세트 E처럼 주변 적을 시전자 정면으로 강하게 끌어당긴 뒤 기절
  fist_face(player, job, def) {
    const dim = player.dimension;
    const l = player.location;
    const facing = flatDir(player);
    const side = { x: -facing.z, z: facing.x };
    const list = getTargets(player, { x: l.x, y: l.y + 1, z: l.z }, def.radius);
    sound(dim, "mob.ravager.roar", l, { volume: 1.0, pitch: 0.92 });
    ring(dim, l, def.radius, RED, 36, 0.3);
    ring(dim, l, def.radius * 0.6, HIT, 20, 0.9);
    if (list.length === 0) return;

    const pullTicks = 6;
    const front = { x: l.x + facing.x * 1.35, y: l.y, z: l.z + facing.z * 1.35 };

    const safeSpot = (p) => !isSolidAt(dim, { x: p.x, y: p.y + 0.1, z: p.z }) &&
      !isSolidAt(dim, { x: p.x, y: p.y + 1.5, z: p.z }) &&
      isSolidAt(dim, { x: p.x, y: p.y - 0.4, z: p.z });

    list.forEach((t, idx) => {
      stun(t, pullTicks + def.stun);
      let from;
      try { from = { ...t.location }; } catch { return; }
      const lane = idx === 0 ? 0 : (idx % 2 ? 1 : -1) * Math.ceil(idx / 2) * 0.55;
      const candidate = { x: front.x + side.x * lane, y: front.y, z: front.z + side.z * lane };
      const to = safeSpot(candidate) ? candidate : safeSpot(front) ? front : from;

      for (let s = 0; s <= 8; s++) {
        const tLine = s / 8;
        particle(dim, RED, { x: from.x + (to.x - from.x) * tLine, y: from.y + 1 + (to.y - from.y) * tLine, z: from.z + (to.z - from.z) * tLine });
      }

      let i = 0;
      const id = system.runInterval(() => {
        try {
          if (!healthAlive(t)) { system.clearRun(id); return; }
          i++;
          const f = Math.min(1, i / pullTicks);
          const trailPos = { x: from.x + (to.x - from.x) * f, y: from.y + (to.y - from.y) * f, z: from.z + (to.z - from.z) * f };
          particle(dim, SMOKE, { x: trailPos.x, y: trailPos.y + 1, z: trailPos.z });
          particle(dim, RED, { x: trailPos.x, y: trailPos.y + 1.1, z: trailPos.z });
          if (i >= pullTicks) {
            if (to !== from) t.teleport(to, { keepVelocity: false });
            system.clearRun(id);
            const c = bodyCenter(t);
            particle(dim, BOOM, c);
            particle(dim, HIT, c);
            if (def.damage > 0) strike(t, player, power(player, def.damage, 1));
            let s = 0;
            const sid = system.runInterval(() => {
              try {
                const h = t.location;
                particle(dim, HIT, { x: h.x, y: h.y + 2.1, z: h.z });
                if (++s >= Math.ceil(def.stun / 4)) system.clearRun(sid);
              } catch { system.clearRun(sid); }
            }, 4);
          }
        } catch {
          system.clearRun(id);
        }
      }, 1);
    });
    sound(dim, "random.anvil_land", l, { volume: 1.0, pitch: 0.75 });
  },

  // 강자의 자세: 3초간 움직일 수 없지만 힘/저항 버프를 얻음
  fist_stance(player, job, def) {
    const dim = player.dimension;
    const l = player.location;
    fx(player, "slowness", def.freeze, 255);
    fx(player, "jump_boost", def.freeze, 200);
    fx(player, "strength", def.buffTicks, def.strengthAmp, true);
    fx(player, "resistance", def.buffTicks, def.resistanceAmp, true);
    sound(dim, "mob.irongolem.repair", l, { volume: 1.0, pitch: 0.5 });
    sound(dim, "beacon.activate", l, { volume: 0.8, pitch: 1.2 });
    notify(player, `§6강자의 자세! §7${def.freeze / 20}초간 움직일 수 없습니다.`);

    let t = 0;
    const id = system.runInterval(() => {
      try {
        const p = player.location;
        const r = 1.4 - (t % 20) * 0.04;
        ring(dim, p, Math.max(0.4, r), RED, 12, (t % 10) * 0.2);
        if (t % 10 === 0) particle(dim, HIT, { x: p.x, y: p.y + 1, z: p.z });
        t += 2;
        if (t >= def.freeze) system.clearRun(id);
      } catch {
        system.clearRun(id);
      }
    }, 2);
  },

  // 대미장식 (궁극기): 마지막에 때린 대상을 붙잡고 15블럭 위로 올라간 뒤 바닥에 내리꽂음 (고정 피해)
  fist_finale(player, job, def) {
    const dim = player.dimension;
    const target = getLastHit(player);
    if (!validTarget(target, player, def.radius)) {
      notify(player, "§7최근에 타격한 대상이 주변에 없습니다. 먼저 공격하세요.");
      return false;
    }

    const origin = { ...player.location };
    const originRotation = player.getRotation();
    const base = { x: origin.x, z: origin.z };
    const dir = flatDir(player);
    const totalTicks = def.riseTicks + def.hoverTicks + 60 + 40;
    const step = def.rise / def.riseTicks;

    fx(player, "resistance", totalTicks, 4);
    stun(target, totalTicks);
    sound(dim, "mob.ravager.roar", origin, { volume: 1.2, pitch: 0.7 });

    let phase = "rise"; // rise -> hover -> slam
    let py = origin.y;
    let rose = 0;
    let wait = 0;
    let groundY = origin.y;
    let safety = 0;

    const place = () => {
      player.teleport({ x: base.x, y: py, z: base.z }, { keepVelocity: false });
      target.teleport({ x: base.x, y: py + def.holdOffset, z: base.z }, { keepVelocity: false });
    };

    let released = false;
    const release = () => {
      if (released) return;
      released = true;
      system.clearRun(id);
      unfx(target, STUN_EFFECTS);
      unfx(player, ["resistance"]);
      // Regardless of whether the target died, the skill timed out, or the
      // slam finished, never leave the caster at an unsafe height. The original
      // location was occupied by the caster before casting even on superflat.
      try {
        if (player.dimension.id === dim.id) {
          player.teleport(origin, { rotation: originRotation, keepVelocity: false });
          try { player.clearVelocity(); } catch {}
          // Extra protection during the landing tick in flat/deep worlds.
          fx(player, "slow_falling", 30, 0);
        }
      } catch {
        // Teleport may fail while the player is leaving or changing dimension.
      }
    };

    const id = system.runInterval(() => {
      try {
        if (!healthAlive(target) || ++safety > totalTicks + 40) {
          release();
          return;
        }

        if (phase === "rise") {
          // 천장이 있으면 거기까지만 올라감
          const top = py + step + def.holdOffset + 2.1;
          if (rose >= def.rise || isSolidAt(dim, { x: base.x, y: top, z: base.z })) {
            phase = "hover";
            wait = 0;
            sound(dim, "random.anvil_land", { x: base.x, y: py, z: base.z }, { volume: 0.8, pitch: 0.5 });
            return;
          }
          py += step;
          rose += step;
          place();
          particle(dim, RED, { x: base.x, y: py - 0.2, z: base.z });
          particle(dim, SMOKE, { x: base.x, y: py - 0.5, z: base.z });
          return;
        }

        if (phase === "hover") {
          place();
          const c = { x: base.x, y: py, z: base.z };
          ring(dim, c, 1.6 - wait * 0.1, RED, 14, 0.5);
          particle(dim, HIT, { x: base.x, y: py + def.holdOffset + 1, z: base.z });
          if (++wait >= def.hoverTicks) {
            // 내리꽂을 바닥 높이 찾기
            groundY = origin.y;
            for (let y = py; y > py - 80; y -= 1) {
              if (isSolidAt(dim, { x: base.x, y, z: base.z })) {
                groundY = Math.floor(y) + 1;
                break;
              }
            }
            phase = "slam";
            sound(dim, "mob.enderdragon.growl", c, { volume: 1.0, pitch: 1.4 });
          }
          return;
        }

        // slam
        py -= def.slamSpeed;
        if (py > groundY) {
          place();
          particle(dim, RED, { x: base.x, y: py + 1, z: base.z });
          particle(dim, HIT, { x: base.x, y: py + def.holdOffset, z: base.z });
          return;
        }

        // 충돌: 플레이어는 바닥에 서고, 대상은 그 앞에 꽂힘
        py = groundY;
        player.teleport({ x: base.x, y: py, z: base.z }, { keepVelocity: false });
        let spot = { x: base.x + dir.x * 1.1, y: py, z: base.z + dir.z * 1.1 };
        if (isSolidAt(dim, spot) || isSolidAt(dim, { x: spot.x, y: spot.y + 1, z: spot.z })) {
          spot = { x: base.x, y: py, z: base.z };
        }
        target.teleport(spot, { keepVelocity: false });
        trueHit(target, player, def.damage);

        const c = { x: spot.x, y: spot.y + 0.3, z: spot.z };
        particle(dim, HUGE, c);
        particle(dim, BOOM, c);
        ring(dim, c, 2.5, SMOKE, 24, 0.2);
        ring(dim, c, 4.5, RED, 36, 0.3);
        ring(dim, c, 6.5, HIT, 36, 0.3);
        sound(dim, "random.explode", c, { volume: 1.6, pitch: 0.6 });
        sound(dim, "mob.irongolem.hit", c, { volume: 1.5, pitch: 0.5 });
        sound(dim, "random.anvil_land", c, { volume: 1.2, pitch: 0.5 });
        release();
      } catch {
        release();
      }
    }, 1);
  },
};

// ---------------------------------------------------------------------------
// 패시브 / 이벤트
//  - 강펀치: 일반 공격(평타)도 2배 피해로 만들어 줌 (힘 버프가 적용된 최종 피해 기준)
//  - 낙하 피해 무효 (무투가, 권골)
// ---------------------------------------------------------------------------
function isFistLine(p) {
  return JOBS[getJobId(p)]?.line === "fist";
}
function noFall(p) {
  const j = JOBS[getJobId(p)];
  return j?.line === "fist" && j.tier >= 2;
}

export function registerFist() {
  world.afterEvents.playerLeave.subscribe((ev) => clearFistRuntime(ev.playerId));

  world.afterEvents.entityHurt.subscribe((ev) => {
    const victim = ev.hurtEntity;
    const cause = ev.damageSource?.cause;

    // 낙하 피해: 받은 만큼 되돌려 줌 (아래 인터벌의 '착지 직전 슬로우 폴링'이 즉사도 막아 줌)
    if (victim?.typeId === "minecraft:player" && cause === EntityDamageCause.fall && noFall(victim)) {
      try {
        const hp = victim.getComponent("minecraft:health");
        if (hp && hp.currentValue > 0) hp.setCurrentValue(Math.min(hp.effectiveMax, hp.currentValue + ev.damage));
      } catch {
        // 상태를 읽을 수 없음
      }
      return;
    }

    // 강펀치: 평타 2배
    const attacker = ev.damageSource?.damagingEntity;
    if (attacker?.typeId !== "minecraft:player" || cause !== EntityDamageCause.entityAttack) return;
    if (!victim || victim.id === attacker.id || !isFistLine(attacker)) return;
    if (consumeSkillMark(victim.id, attacker.id)) return; // 스킬 피해는 스킬 쪽에서 이미 처리함
    if (doubleLeft(attacker) <= 0) return;

    takeDouble(attacker);
    // ev.damage 는 힘 버프까지 반영된 실제 피해량이므로 같은 만큼 더 주면 정확히 2배
    trueHit(victim, attacker, ev.damage);
    const c = bodyCenter(victim);
    particle(victim.dimension, HIT, c);
    particle(victim.dimension, RED, c);
    sound(victim.dimension, "random.anvil_land", victim.location, { volume: 0.4, pitch: 1.5 });
    const left = doubleLeft(attacker);
    notify(attacker, left > 0 ? `§c강펀치! §7남은 횟수 ${left}` : "§c강펀치 효과가 끝났습니다.");
  });

  // 큰 높이에서 떨어질 땐 착지 직전에 잠깐 슬로우 폴링을 걸어 낙하 피해로 죽는 일을 막음
  system.runInterval(() => {
    for (const p of world.getAllPlayers()) {
      try {
        if (!noFall(p) || p.isOnGround) continue;
        if (p.getVelocity().y > -0.6) continue;
        const l = p.location;
        for (let d = 1; d <= 6; d++) {
          if (isSolidAt(p.dimension, { x: l.x, y: l.y - d, z: l.z })) {
            fx(p, "slow_falling", 10, 0);
            break;
          }
        }
      } catch {
        // 플레이어 상태를 읽을 수 없음
      }
    }
  }, 1);
}
