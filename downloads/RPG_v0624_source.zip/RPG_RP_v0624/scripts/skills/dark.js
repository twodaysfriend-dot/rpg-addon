import { world, system } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { getLastHit } from "../core/tracking.js";
import {
  getTargets, healthAlive, hurt, particle, sound, dist3, norm3,
  headPos, isSolidAt, flatDir,
} from "../core/util.js";
import { notify } from "../core/hud.js";

const FX_ENERGY = "rpg:dark_energy";
const FX_WALL = "rpg:dark_prison";
const FX_CHAIN = "rpg:dark_chain";
const activeCages = [];
const activeDeathDomains = [];
const activeStuns = new Map();
let registered = false;

function available(e) {
  try { return !!e && e.isValid && healthAlive(e); } catch { return false; }
}
function enemy(p, e) {
  if (!available(e) || e.id === p.id || e.typeId === "rpg:bone_minion") return false;
  return e.typeId !== "minecraft:player" || CONFIG.pvp;
}
function lastEnemy(p, range) {
  const e = getLastHit(p);
  try {
    if (enemy(p, e) && e.dimension.id === p.dimension.id && dist3(e.location, p.location) <= range) return e;
  } catch {}
  return null;
}
function drawLine(dim, a, b, fx, spacing = 0.7) {
  const delta = { x: b.x-a.x, y: b.y-a.y, z: b.z-a.z };
  const len = Math.hypot(delta.x, delta.y, delta.z);
  const count = Math.min(70, Math.max(1, Math.ceil(len / spacing)));
  for (let i=0;i<=count;i++) {
    const t=i/count;
    particle(dim, fx, { x:a.x+delta.x*t, y:a.y+delta.y*t, z:a.z+delta.z*t });
  }
}

// 멈춤 중력/속도 보정: 물리적인 감옥 블록을 생성하지 않으므로 기존 건축물은 손상되지 않습니다.
function stun(e, ticks) {
  if (!available(e)) return;
  const now = system.currentTick;
  const old = activeStuns.get(e.id);
  const pos = old?.position ?? { ...e.location };
  activeStuns.set(e.id, { entity:e, position:pos, until:Math.max(old?.until ?? 0,now+ticks), dimensionId:e.dimension.id });
  try { e.addEffect("slowness", ticks, { amplifier: 255, showParticles: true }); } catch {}
  try { e.addEffect("weakness", ticks, { amplifier: 255, showParticles: false }); } catch {}
}

// 반물질의 신 암흑 에너지: 지름 6블럭(반경 3) 범위 내 적 전체에 1회 피해.
// 흑마법사는 기존의 직선 투사체를 계속 사용합니다.
function antimatterEnergy(p, def) {
  const dim = p.dimension;
  const center = { ...p.location, y:p.location.y + 0.7 };
  const radius = def.burstRadius ?? 3;
  const damage = def.burstDamage ?? def.damage;
  const enemies = getTargets(p, p.location, radius, 0).filter(e=>enemy(p,e));
  for (const e of enemies) {
    hurt(e,p,damage);
    for(let n=0;n<5;n++) {
      const a = (n/5)*Math.PI*2;
      particle(dim,FX_CHAIN,{x:e.location.x+0.6*Math.cos(a),y:e.location.y+0.9,z:e.location.z+0.6*Math.sin(a)});
    }
  }
  for(let layer=0;layer<3;layer++) {
    const height=layer*0.8;
    for(let i=0;i<36;i++) {
      const a=2*Math.PI*i/36;
      particle(dim, i%3===0?FX_CHAIN:FX_ENERGY, {
        x:center.x+radius*Math.cos(a), y:center.y+height,z:center.z+radius*Math.sin(a),
      });
    }
  }
  sound(dim,"random.explode",p.location,{volume:0.8,pitch:0.5});
  return true;
}

function energy(p,job,def) {
  if(job.id === "deathlord") return antimatterEnergy(p,def);
  const dir = norm3(p.getViewDirection());
  const origin = headPos(p);
  const dim = p.dimension;
  let dist=0;
  const touched=new Set();
  sound(dim,"mob.endermen.portal",origin,{volume:0.8,pitch:0.6});
  const handle=system.runInterval(() => {
    try {
      if (dist >= def.range || !p.isValid) {system.clearRun(handle);return;}
      for (let s=0;s<2;s++) {
        dist += def.speed/2;
        const pt={x:origin.x+dir.x*dist,y:origin.y+dir.y*dist,z:origin.z+dir.z*dist};
        if (isSolidAt(dim, pt)) {particle(dim,FX_CHAIN,pt);system.clearRun(handle);return;}
        particle(dim,FX_ENERGY,pt);
        for (const e of getTargets(p,pt,def.radius,0.9)) {
          if (!enemy(p,e)||touched.has(e.id)) continue;
          touched.add(e.id);
          hurt(e,p,def.damage);
          for(let i=0;i<10;i++)particle(dim,FX_CHAIN,{
            x:e.location.x+Math.sin(i*2.39)*0.7,
            y:e.location.y+0.4+(i%4)*0.4,
            z:e.location.z+Math.cos(i*2.39)*0.7,
          });
          sound(dim,"random.explode",e.location,{volume:0.55,pitch:0.75});
          system.clearRun(handle);return;
        }
      }
    } catch { system.clearRun(handle); }
  },1);
  return true;
}

// 5x5x5 particle lattice. Ground/base stays untouched, so teardown cannot delete player blocks.
function showCage(cage) {
  const {dim, base, size} = cage;
  const half=size/2;
  for(let h=0;h<=size+0.01;h+=1) {
    for(let axis=-half;axis<=half+0.01;axis+=0.625) {
      particle(dim,FX_WALL,{x:base.x+axis,y:base.y+h,z:base.z-half});
      particle(dim,FX_WALL,{x:base.x+axis,y:base.y+h,z:base.z+half});
      particle(dim,FX_WALL,{x:base.x-half,y:base.y+h,z:base.z+axis});
      particle(dim,FX_WALL,{x:base.x+half,y:base.y+h,z:base.z+axis});
    }
  }
  for(let x=-half;x<=half+0.01;x+=1.25) {
    for(let z=-half;z<=half+0.01;z+=1.25) {
      particle(dim,FX_CHAIN,{x:base.x+x,y:base.y+size,z:base.z+z});
    }
  }
}
function cageContact(cage,e) {
  const dx=Math.abs(e.location.x-cage.base.x);
  const dz=Math.abs(e.location.z-cage.base.z);
  const dy=e.location.y-cage.base.y;
  const half=cage.size/2;
  if (dy<-0.6 || dy>cage.size+0.3 || dx>half+0.6 || dz>half+0.6) return false;
  return dx>=half-0.65 || dz>=half-0.65 || dy>=cage.size-0.6;
}
function eventHorizon(p,job,def) {
  const viewed=getLastHit(p);
  let pos;
  if (enemy(p,viewed) && viewed.dimension.id===p.dimension.id && dist3(viewed.location,p.location)<=def.range) {
    pos=viewed.location;
  } else {
    const v=flatDir(p), l=p.location;
    pos={x:l.x+v.x*8,y:l.y,z:l.z+v.z*8};
  }
  // Point in the center of the prison's footprint.
  const cage={owner:p,dim:p.dimension,base:{x:pos.x,y:Math.floor(pos.y),z:pos.z},size:def.size,until:system.currentTick+def.duration,stunTicks:def.stunTicks,hit:new Set()};
  activeCages.push(cage);
  showCage(cage);
  sound(p.dimension,"mob.endermen.portal",pos,{volume:1,pitch:0.55});
  notify(p,"§5사건의 지평선: §d5×5×5 감옥 생성 (5초)");
  return true;
}
function darkChains(p,job,def) {
  const target=lastEnemy(p,def.range);
  if(!target){notify(p,"§7마지막으로 타격한 살아 있는 적이 35블럭 안에 없습니다.");return false;}
  const dim=p.dimension;
  const t0=system.currentTick;
  sound(dim,"mob.endermen.portal",target.location,{volume:1,pitch:0.45});
  const handle=system.runInterval(() => {
    try {
      if (!available(target) || !p.isValid || dim.id!==target.dimension.id) {system.clearRun(handle);return;}
      const now=system.currentTick;
      const end={...target.location,y:target.location.y+1.2};
      if ((now-t0)%5<2) {
        drawLine(dim,headPos(p),end,FX_CHAIN,0.95);
        for(let a=0;a<8;a++){
          const angle=a*Math.PI/4+(now-t0)*0.09;
          particle(dim,FX_CHAIN,{x:target.location.x+Math.cos(angle)*1.15,y:target.location.y+0.9,z:target.location.z+Math.sin(angle)*1.15});
        }
      }
      if(now-t0>=def.delay) {
        hurt(target,p,def.damage);
        for(let i=0;i<22;i++)particle(dim,FX_ENERGY,{
          x:target.location.x+Math.cos(i*2.4)*0.85,y:target.location.y+0.2+(i%7)*0.27,z:target.location.z+Math.sin(i*2.4)*0.85,
        });
        sound(dim,"random.explode",target.location,{volume:1,pitch:0.5});
        system.clearRun(handle);
      }
    } catch {system.clearRun(handle);}
  },1);
  return true;
}
function darkTouch(p,job,def) {
  const target=lastEnemy(p,def.range);
  if(!target){notify(p,"§7마지막으로 타격한 살아 있는 적이 35블럭 안에 없습니다.");return false;}
  const forward=flatDir(p);
  const here=p.location;
  const dest={x:here.x+forward.x*def.pullDistance,y:here.y,z:here.z+forward.z*def.pullDistance};
  // Avoid trapping the target inside walls or teleporting it into empty void.
  const dim=p.dimension;
  const feet=isSolidAt(dim,{x:dest.x,y:dest.y+0.15,z:dest.z});
  const head=isSolidAt(dim,{x:dest.x,y:dest.y+1.3,z:dest.z});
  const ground=isSolidAt(dim,{x:dest.x,y:dest.y-0.85,z:dest.z});
  if(feet||head||!ground){notify(p,"§7대상을 끌어올 안전한 바닥이 없습니다.");return false;}
  const from={...target.location,y:target.location.y+1.0};
  const to={...dest,y:dest.y+1.0};
  drawLine(dim,from,to,FX_CHAIN,0.5);
  try {target.teleport(dest,{dimension:dim});}
  catch {notify(p,"§7대상을 끌어오지 못했습니다.");return false;}
  hurt(target,p,def.damage);
  for(let i=0;i<10;i++)particle(dim,FX_ENERGY,{x:dest.x+Math.cos(i*2.4)*0.65,y:dest.y+0.8,z:dest.z+Math.sin(i*2.4)*0.65});
  sound(dim,"mob.endermen.portal",dest,{volume:0.9,pitch:0.55});
  return true;
}

// 죽음의 영역: 월드 블록을 건드리지 않는 파티클 장벽.
// 영역 내에는 시전자와 마지막 타격 대상만 남을 수 있습니다.
// 접속 상태와 엔티티 생존은 매 틱 점검하여, 사라진 대상/시전자 때문에 영역이 남지 않습니다.
function insideDeathDomain(domain, pos, margin=0) {
  const dx=pos.x-domain.center.x, dz=pos.z-domain.center.z;
  return Math.hypot(dx,dz)<domain.radius+margin &&
    pos.y>=domain.center.y-2.0-margin && pos.y<=domain.center.y+6.0+margin;
}
function safeOnGround(dim, x, z, referenceY) {
  // 엔티티를 공허 위에 놓거나 벽 속에 넣지 않도록 바닥이 있는 지점을 탐색.
  for(const dy of [0,1,-1,2,-2,3,-3]) {
    const y=Math.floor(referenceY+dy)+0.02;
    if(isSolidAt(dim,{x,y:y+0.25,z}) || isSolidAt(dim,{x,y:y+1.45,z})) continue;
    if(!isSolidAt(dim,{x,y:y-0.85,z})) continue;
    return {x,y,z};
  }
  return null;
}
function domainTeleport(entity,dim,pos) {
  try { entity.teleport(pos,{dimension:dim,keepVelocity:false});return true; } catch {return false;}
}
function drawDeathDomain(domain) {
  const {dim,center,radius}=domain;
  // 검정·보라색 원형 경계와 돔. 매 8틱 새로 그려 지형을 손상시키지 않습니다.
  for(let k=0;k<=2;k++) {
    const y=center.y+k*3;
    for(let i=0;i<40;i++) {
      const a=i*Math.PI*2/40;
      particle(dim, k===1?FX_CHAIN:FX_WALL, {
        x:center.x+radius*Math.cos(a), y,z:center.z+radius*Math.sin(a),
      });
    }
  }
  for(let i=0;i<12;i++) {
    const a=i*Math.PI*2/12;
    for(let k=1;k<=3;k++) {
      const r=radius*Math.cos(k*Math.PI/8);
      const y=center.y+6*Math.sin(k*Math.PI/8);
      particle(dim,FX_ENERGY,{x:center.x+r*Math.cos(a),y,z:center.z+r*Math.sin(a)});
    }
  }
}
function returnInsider(domain,e,keepDistance) {
  const center=domain.center;
  // 시전자의 좌표는 중심, 표적은 2칸 앞으로 되돌립니다.
  const theta=domain.angle;
  const r=keepDistance;
  for(const t of [0,0.6,-0.6,1.2,-1.2]) {
    const a=theta+t;
    const x=center.x+Math.cos(a)*r,z=center.z+Math.sin(a)*r;
    const spot=safeOnGround(domain.dim,x,z,center.y);
    if(spot && domainTeleport(e,domain.dim,spot)) return;
  }
  // 안전한 복귀 위치가 없으면 강제 이동을 하지 않아 질식·공허 사고를 방지.
}
function expelOutsider(domain,e) {
  if(!available(e) || e.id===domain.owner.id || e.id===domain.target.id)return;
  if(e.typeId==='minecraft:player'&&!CONFIG.pvp)return; // 기존 서버 PVP 규칙 준수
  const l=e.location;
  if(!insideDeathDomain(domain,l))return;
  let a=Math.atan2(l.z-domain.center.z,l.x-domain.center.x);
  if(!Number.isFinite(a))a=domain.angle;
  for(const offset of [0,0.4,-0.4,0.8,-0.8,1.4,-1.4,Math.PI]) {
    const angle=a+offset;
    const distance=domain.radius+1.5;
    const x=domain.center.x+Math.cos(angle)*distance;
    const z=domain.center.z+Math.sin(angle)*distance;
    const spot=safeOnGround(domain.dim,x,z,l.y);
    if(spot && domainTeleport(e,domain.dim,spot)) {
      particle(domain.dim,FX_CHAIN,{x:spot.x,y:spot.y+1,z:spot.z});
      return;
    }
  }
  // 출입구에 안전한 바닥이 없을 경우, 기존 지형을 훼손하지 않고 강제 이동 생략.
}
function deathDomain(p,job,def) {
  if(job.id!=='deathlord')return false;
  const target=lastEnemy(p,def.range);
  if(!target){notify(p,'§7마지막으로 타격한 적이 사라졌거나 범위 밖에 있습니다.');return false;}
  if(activeDeathDomains.some(d=>d.owner.id===p.id)){
    notify(p,'§7죽음의 영역이 이미 유지 중입니다.');return false;
  }
  const center={...p.location};
  if(activeDeathDomains.some(d=>d.dim.id===p.dimension.id && dist3(d.center,center)<d.radius+def.radius+2)) {
    notify(p,'§7기존 죽음의 영역과 겹치는 위치입니다.');return false;
  }
  const view=flatDir(p);
  const angle=Math.atan2(view.z,view.x);
  const initial={x:center.x+view.x*2.1,z:center.z+view.z*2.1};
  // 마지막 타격 대상이 원 밖에 있다면 안전한 안쪽 위치로 당깁니다.
  if(!insideDeathDomain({center,radius:def.radius},target.location,-0.4)) {
    const spot=safeOnGround(p.dimension,initial.x,initial.z,center.y);
    if(!spot || !domainTeleport(target,p.dimension,spot)){
      notify(p,'§7마지막 타격 대상을 영역 안으로 옮길 안전한 위치가 없습니다.');return false;
    }
  }
  const domain={owner:p,target,dim:p.dimension,center,radius:def.radius,
    angle,until:system.currentTick+def.duration,
    lastSafeOwner:{...p.location},lastSafeTarget:{...target.location},
    darknessLevel:def.darknessLevel??0,weaknessLevel:def.weaknessLevel??1};
  activeDeathDomains.push(domain);
  // 발동 즉시 영역 안에 있던 다른 엔티티를 밖으로 내보냅니다.
  try {
    for(const e of domain.dim.getEntities({location:center,maxDistance:def.radius+7})) expelOutsider(domain,e);
  } catch {}
  drawDeathDomain(domain);
  sound(domain.dim,'mob.endermen.portal',center,{volume:1,pitch:0.45});
  notify(p,`§5죽음의 영역: §d대상 격리 (${(def.duration/20).toFixed(0)}초)`);
  return true;
}

export const RUNNERS={dark_energy:energy,event_horizon:eventHorizon,dark_chains:darkChains,dark_touch:darkTouch,death_domain:deathDomain};

export function registerDarkMagic() {
  if(registered)return;
  registered=true;
  system.runInterval(() => {
    const now=system.currentTick;
    // Global stun management ensures the 3-second stun persists even if the 5-second cage disappears.
    for (const [id,s] of activeStuns) {
      if (now>=s.until || !available(s.entity)) {activeStuns.delete(id);continue;}
      try {
        if(s.entity.dimension.id!==s.dimensionId){activeStuns.delete(id);continue;}
        s.entity.teleport(s.position,{dimension:s.entity.dimension});
      } catch { activeStuns.delete(id); }
    }
    // 죽음의 영역 경계·격리·디버프 유지. 내부 ID는 기존 캐릭터 저장과 호환됩니다.
    for(let i=activeDeathDomains.length-1;i>=0;i--) {
      const d=activeDeathDomains[i];
      if(now>=d.until || !available(d.owner) || !available(d.target) ||
         d.owner.dimension.id!==d.dim.id || d.target.dimension.id!==d.dim.id) {
        activeDeathDomains.splice(i,1); continue;
      }
      if(now%10===0)drawDeathDomain(d);
      try {
        // 대상에 효과 1.5초씩 갱신: 영역 종료 후에는 자연스럽게 사라짐.
        if(now%10===0) {
          d.target.addEffect('darkness',30,{amplifier:d.darknessLevel,showParticles:true});
          d.target.addEffect('weakness',30,{amplifier:d.weaknessLevel,showParticles:true});
        }
        // 영역에서 나가려는 시전자/상대를 안전한 내부 좌표로 되돌림.
        if(!insideDeathDomain(d,d.owner.location,-0.35)) returnInsider(d,d.owner,0);
        if(!insideDeathDomain(d,d.target.location,-0.35)) returnInsider(d,d.target,2.1);
        // 들어온 타 엔티티는 즉시 밖으로 퇴거. 아이템/구슬에는 영향 없음.
        const entities=d.dim.getEntities({location:d.center,maxDistance:d.radius+7});
        for(const e of entities) expelOutsider(d,e);
      } catch {}
    }
    for(let i=activeCages.length-1;i>=0;i--) {
      const cage=activeCages[i];
      if(now>=cage.until || !cage.owner?.isValid) {activeCages.splice(i,1);continue;}
      if(now%6===0) showCage(cage);
      if(now%2!==0)continue;
      try {
        const entities=cage.dim.getEntities({location:{x:cage.base.x,y:cage.base.y+2.5,z:cage.base.z},maxDistance:5});
        for(const e of entities){
          if(cage.hit.has(e.id)||!enemy(cage.owner,e))continue;
          if(cageContact(cage,e)){
            cage.hit.add(e.id);stun(e,cage.stunTicks);
            sound(cage.dim,"mob.endermen.portal",e.location,{volume:0.45,pitch:1.5});
          }
        }
      } catch{}
    }
  },1);
  world.afterEvents.playerLeave.subscribe(ev=>{
    for(let i=activeCages.length-1;i>=0;i--)if(activeCages[i].owner?.id===ev.playerId)activeCages.splice(i,1);
    for(let i=activeDeathDomains.length-1;i>=0;i--)if(activeDeathDomains[i].owner?.id===ev.playerId || activeDeathDomains[i].target?.id===ev.playerId)activeDeathDomains.splice(i,1);
  });
}
