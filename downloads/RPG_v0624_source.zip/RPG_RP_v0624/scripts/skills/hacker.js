import { world, system } from '@minecraft/server';
import { CONFIG } from '../config.js';
import { getLastHit } from '../core/tracking.js';
import { getTargets, particle, sound, dist3 } from '../core/util.js';
import { notify } from '../core/hud.js';
import { getJobId, resetNonUltimateCooldowns } from '../core/playerData.js';
import { SKILLS } from '../data/skills.js';
import { JOBS } from '../data/jobs.js';
import { RUNNERS as swordRunners } from './sword.js';
import { RUNNERS as fistRunners } from './fist.js';
import { RUNNERS as archerRunners } from './archer.js';
import { RUNNERS as mageRunners } from './mage.js';
import { RUNNERS as holyRunners } from './holy.js';
import { RUNNERS as berserkerRunners } from './berserker.js';
import { RUNNERS as bloodRunners } from './blood.js';
import { beginFrenzy } from '../core/frenzy.js';
const copied={...swordRunners,...fistRunners,...archerRunners,...mageRunners,...holyRunners,...berserkerRunners,...bloodRunners};
const stealth=new Map();
const TEAM='rpg_team_';
const FX_HEX='rpg:hacker_hex';
const FX_GLITCH='rpg:hacker_glitch';
const FX_EMP='rpg:hacker_emp_arc';
function emit(dim,id,loc,n=1){ for(let i=0;i<n;i++) particle(dim,id,{x:loc.x+((i%3)-1)*0.14,y:loc.y+((i*2)%5)*0.10,z:loc.z+((i%5)-2)*0.14}); }
function line(dim,a,b,id,step=.6){ const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z; const total=Math.hypot(dx,dy,dz)||0.001; const n=Math.min(64,Math.max(1,Math.ceil(total/step))); for(let i=0;i<=n;i++){ const t=i/n; particle(dim,id,{x:a.x+dx*t,y:a.y+dy*t,z:a.z+dz*t}); } }
function team(player){return player.getTags().find(t=>t.startsWith(TEAM))??null;}
function ally(p,e){return e?.id===p.id ||(e?.typeId==='minecraft:player' && team(p)!==null && team(p)===team(e));}
function valid(e){try{return e?.isValid && (e.getComponent('minecraft:health')?.currentValue??0)>0;}catch{return false;}}
function effect(e,name,ticks,amp){try{e.addEffect(name,ticks,{amplifier:amp,showParticles:false});}catch{}}
function hacking(p,job,def){
  const e=getLastHit(p);
  if(!valid(e)||ally(p,e)||e.dimension.id!==p.dimension.id||dist3(e.location,p.location)>def.range){notify(p,'§7최근 타격한 적이 사정거리 안에 없습니다.');return false;}
  effect(e,'weakness',60,3);effect(e,'slowness',60,2);effect(e,'blindness',60,0);
  const from={x:p.location.x,y:p.location.y+1.05,z:p.location.z};
  const to={x:e.location.x,y:e.location.y+1.0,z:e.location.z};
  line(p.dimension,from,to,FX_GLITCH,0.82);
  for(let i=0;i<10;i++){
    const a=i*Math.PI*2/10;
    particle(p.dimension,FX_HEX,{x:to.x+Math.cos(a)*0.8,y:to.y+Math.sin(a*2)*0.12,z:to.z+Math.sin(a)*0.8});
  }
  emit(p.dimension,FX_GLITCH,to,3);
  sound(p.dimension,'mob.endermen.portal',e.location,{volume:.6,pitch:1.2});
  notify(p,'§d해킹 성공');
  return true;
}
function reboot(p,job,def){
  const candidates=world.getAllPlayers().filter(e=>e.dimension.id===p.dimension.id && dist3(e.location,p.location)<=def.radius && ally(p,e));
  for(const e of candidates)resetNonUltimateCooldowns(e);
  notify(p,`§d시스템 재부팅: §f${candidates.length}명 일반 스킬 쿨타임 초기화`);
  return true;
}
export function isHackerStealthActive(p){return stealth.has(p.id);}
export function stopHackerStealth(p){
  if(!stealth.delete(p.id))return false;
  for(const name of ['invisibility','speed','hunger'])try{p.removeEffect(name);}catch{}
  notify(p,'§7은신 해제');return true;
}
function cloak(p,job,def){
  if(stealth.has(p.id)){stopHackerStealth(p);return false;}
  stealth.set(p.id,true);notify(p,'§5은신 활성화');return true;
}
// 카피: 기존 궁극기 5종 + 혈술사/해커/야수/타락검성/미카엘 5종.
// 미카엘의 마지막 액티브 스킬은 축복 영역(angel_zone).
// 타락검성 광분화는 날개 장착이 직업 제한을 받기 때문에
// 해커가 사용할 때는 동일한 흡혈 효과만 별도로 실행합니다.
const ultimates=[
 ['sword_rush','sword_saint'],
 ['fist_finale','fist_bone'],
 ['archer_heavenly','heavenly_archer'],
 ['sage_zoltraak','sage'],
 ['fallen_end','fallen_angel'],
 ['hacker_emp','hacker'],
 ['blood_bind','blood_mage'],
 ['beast_berserk','beast'],
 ['fallen_sword_frenzy','fallen_sword_saint'],
 ['angel_zone','michael'],
];

function copiedFallenFrenzy(p,job,def){
  // 원래 직업만 사용 가능한 날개 강제 활성화는 건너뛰고 전투 효과만 복제.
  beginFrenzy(p,def.duration,def.lifesteal);
  sound(p.dimension,'mob.wither.spawn',p.location,{volume:.75,pitch:.85});
  return true;
}

function copy(p,job,def){
  // Fisher-Yates: 실제 실행 가능한 궁극기를 무작위 순서로 시도.
  const order=[...ultimates];
  for(let i=order.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [order[i],order[j]]=[order[j],order[i]];
  }
  for(const [skillId,jobId] of order){
    const runner=skillId==='hacker_emp'?emp:
      skillId==='fallen_sword_frenzy'?copiedFallenFrenzy:copied[skillId];
    const skill=SKILLS[skillId], targetJob=JOBS[jobId];
    if(!runner||!skill||!targetJob)continue;
    try{
      if(runner(p,targetJob,skill)!==false){
        notify(p,`§d카피 발동: §f${targetJob.name} - ${skill.name}`);
        return true;
      }
    }catch{}
  }
  notify(p,'§7현재 복제할 수 있는 궁극기가 없습니다.');
  return false;
}
function emp(p,job,def){
  const origin={...p.location}, dim=p.dimension, expires=system.currentTick+def.duration;
  sound(dim,'mob.endermen.portal',origin,{volume:1,pitch:.4});
  const ticker=system.runInterval(()=>{
    if(!p.isValid||system.currentTick>=expires){system.clearRun(ticker);return;}
    try{
      for(const e of getTargets(p,origin,def.radius)){
        if(ally(p,e)||!valid(e))continue;
        effect(e,'weakness',35,3);effect(e,'slowness',35,2);effect(e,'blindness',35,0);
        if(system.currentTick%20===0) emit(dim, FX_GLITCH, {x:e.location.x,y:e.location.y+1.0,z:e.location.z}, 2);
      }
      for(let i=0;i<32;i++){
        const theta=i*Math.PI*2/32;
        const ring={x:origin.x+def.radius*Math.cos(theta),y:origin.y+1.0,z:origin.z+def.radius*Math.sin(theta)};
        particle(dim, i%2===0?FX_HEX:FX_EMP, ring);
      }
      for(let i=0;i<6;i++){
        const theta=(system.currentTick*0.12)+(i*Math.PI*2/6);
        particle(dim, FX_GLITCH, {x:origin.x+Math.cos(theta)*(def.radius*0.55),y:origin.y+1.2+(i%2)*0.4,z:origin.z+Math.sin(theta)*(def.radius*0.55)});
      }
    }catch{system.clearRun(ticker);}
  },10);
  notify(p,'§5EMP: §f주변 적에게 5초간 해킹 디버프');return true;
}
export const RUNNERS={hacker_hack:hacking,hacker_reboot:reboot,hacker_stealth:cloak,hacker_copy:copy,hacker_emp:emp};
export function registerHacker(){
  system.runInterval(()=>{
    for(const id of stealth.keys()){
      const p=world.getAllPlayers().find(e=>e.id===id);
      if(!p || getJobId(p)!=='hacker'){stealth.delete(id);continue;}
      try{
        const hunger=p.getComponent('minecraft:player.hunger')?.currentValue;
        if(typeof hunger==='number'&&hunger<=6){stopHackerStealth(p);continue;}
        effect(p,'invisibility',35,0);effect(p,'speed',35,3);effect(p,'hunger',35,1);
      }catch{stealth.delete(id);}
    }
  },10);
  world.afterEvents.playerLeave.subscribe(ev=>stealth.delete(ev.playerId));
}
