import { ItemStack } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { JOBS } from "../data/jobs.js";
import {
  getJobId, getProgress, addProgress, maxManaOf, getMana, setMana, formatMana,
} from "./playerData.js";

// 인벤토리에서 itemId 를 최대 limit 개까지 꺼내서 실제로 꺼낸 개수를 돌려줍니다.
function takeItems(player, itemId, limit) {
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c || limit <= 0) return 0;
  let taken = 0;
  for (let i = 0; i < c.size && taken < limit; i++) {
    const it = c.getItem(i);
    if (!it || it.typeId !== itemId) continue;
    const take = Math.min(it.amount, limit - taken);
    if (take >= it.amount) {
      c.setItem(i, undefined);
    } else {
      it.amount -= take;
      c.setItem(i, it);
    }
    taken += take;
  }
  return taken;
}

// /rpg:book : 인벤토리의 인챈트 책을 자동으로 바칩니다. 바친 만큼 최대 마나가 늘어납니다.
export function offerBooks(player) {
  const have = getProgress(player).books ?? 0;
  const high = !!JOBS[getJobId(player)]?.highMana;
  // 마법사/성직자 계열은 책을 제한 없이 바칠 수 있습니다.
  const room = high ? Infinity : CONFIG.mana.maxBooks - have;
  if (room <= 0) {
    player.sendMessage(`§7이미 책을 최대(${CONFIG.mana.maxBooks}권)까지 바쳤습니다.`);
    return;
  }

  const beforeMax = maxManaOf(player);
  const taken = takeItems(player, "minecraft:enchanted_book", room);
  if (taken === 0) {
    player.sendMessage("§c인벤토리에 인챈트 책이 없습니다.");
    return;
  }

  const total = addProgress(player, "books", taken);
  const afterMax = maxManaOf(player);
  setMana(player, getMana(player) + (afterMax - beforeMax));

  let msg = `§a인챈트 책 ${taken}권을 바쳤습니다. (총 ${total}권) §9최대 마나 ${formatMana(afterMax)}`;
  const need = JOBS.mage.req.need;
  if (have < need && total >= need) msg += `\n§e마법사 전직 조건(책 ${need}권)을 채웠습니다!`;
  player.sendMessage(msg);
}

// /rpg:sword : 검사 상태에서 인벤토리의 다이아몬드 검을 자동으로 바칩니다. (검성 전직 조건)
export function offerSwords(player) {
  const jobId = getJobId(player);
  if (jobId !== "swordsman") {
    player.sendMessage("§c검사 상태에서만 다이아몬드 검을 바칠 수 있습니다.");
    return;
  }
  const need = JOBS.sword_saint.req.need;
  const have = getProgress(player).diamond_swords ?? 0;
  const room = need - have;
  if (room <= 0) {
    player.sendMessage(`§7이미 다이아몬드 검 ${need}개를 모두 바쳤습니다.`);
    return;
  }

  const taken = takeItems(player, "minecraft:diamond_sword", room);
  if (taken === 0) {
    player.sendMessage("§c인벤토리에 다이아몬드 검이 없습니다.");
    return;
  }

  const total = addProgress(player, "diamond_swords", taken);
  let msg = `§a다이아몬드 검 ${taken}개를 바쳤습니다. (총 ${total}/${need})`;
  if (total >= need) msg += "\n§e검성 전직 조건을 채웠습니다!";
  player.sendMessage(msg);
}


// /rpg:bless : 인벤토리의 축복의 빛을 바쳐 다음 전직 조건을 채웁니다.
//   성직자 → 천사 : 1세트(64개), 천사 → 미카엘 : 10세트(640개)
export function offerLight(player) {
  const cur = getJobId(player);
  const target = cur === "cleric" ? JOBS.angel : cur === "angel" ? JOBS.michael : null;
  if (!target?.req) {
    player.sendMessage("§7성직자 또는 천사 상태에서만 축복의 빛을 바칠 수 있습니다.");
    return;
  }
  const { key, need } = target.req;
  const have = getProgress(player)[key] ?? 0;
  const room = need - have;
  if (room <= 0) {
    player.sendMessage(`§7${target.name} 전직에 필요한 축복의 빛을 이미 모두 바쳤습니다. (/rpg:job ${target.name})`);
    return;
  }
  const taken = takeItems(player, "rpg:blessing_light", room);
  if (taken === 0) {
    player.sendMessage(`§7인벤토리에 축복의 빛이 없습니다. (${have}/${need})`);
    return;
  }
  const total = addProgress(player, key, taken);
  let msg = `§a축복의 빛 ${taken}개를 바쳤습니다. (${target.name} ${total}/${need})`;
  if (total >= need) msg += `\n§e조건 달성! /rpg:job ${target.name} 으로 전직할 수 있습니다.`;
  player.sendMessage(msg);
}

function isWaterBottle(item) {
  if (item.typeId !== "minecraft:potion") return false;
  try {
    const id = String(item.getComponent("minecraft:potion")?.potionEffectType?.id ?? "").toLowerCase();
    return id === "water";
  } catch {
    return false;
  }
}

// /rpg:holywater : 작업대 조합이 안 될 때 쓰는 대체 수단. 물병 1개 + 축복의 빛 1개 → 성수 1개
export function craftHolyWater(player) {
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c) return;
  let bottleSlot = -1;
  let lightSlot = -1;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (!it) continue;
    if (bottleSlot < 0 && isWaterBottle(it)) bottleSlot = i;
    if (lightSlot < 0 && it.typeId === "rpg:blessing_light") lightSlot = i;
  }
  if (bottleSlot < 0 || lightSlot < 0) {
    player.sendMessage("§7물병 1개와 축복의 빛 1개가 필요합니다.");
    return;
  }
  const dec = (slot) => {
    const it = c.getItem(slot);
    if (it.amount <= 1) c.setItem(slot, undefined);
    else {
      it.amount -= 1;
      c.setItem(slot, it);
    }
  };
  dec(bottleSlot);
  dec(lightSlot);
  const left = c.addItem(new ItemStack("rpg:holy_water", 1));
  if (left) player.dimension.spawnItem(left, player.location);
  player.sendMessage("§a성수를 만들었습니다.");
}
