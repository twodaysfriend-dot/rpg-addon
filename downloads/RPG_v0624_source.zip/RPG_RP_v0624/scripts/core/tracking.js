import { world } from "@minecraft/server";
import { JOBS } from "../data/jobs.js";
import { CONFIG } from "../config.js";
import { getJobId, addProgress } from "./playerData.js";
import { heldItemId } from "./util.js";
import { notify } from "./hud.js";

// 플레이어가 가장 최근에 타격한 엔티티 (러쉬 스킬이 사용)
const lastHit = new Map();
export function getLastHit(player) {
  return lastHit.get(player.id)?.entity ?? null;
}

const VILLAGERS = ["minecraft:villager", "minecraft:villager_v2"];

function bump(player, key, label, need) {
  const n = addProgress(player, key);
  if (n < need) {
    notify(player, `§7${label} ${n}/${need}`);
  } else if (n === need) {
    notify(player, `§a${label} ${need}/${need} 달성! 전직 조건을 채웠습니다.`);
  }
}

// 처치 기반 전직 조건을 세어 줍니다.
//  - 검사: 견습 상태에서 검을 든 채 엔티티(플레이어 제외) 처치
//  - 무투가 계열 전직 조건은 core/sandbag.js 에서 샌드백 파괴 수로 계산합니다.
//  - 타락검성: 검성 상태에서 주민 처치 (무기 무관, 스킬로 잡아도 인정)
export function registerTracking() {
  world.afterEvents.projectileHitEntity?.subscribe((ev) => {
    try {
      const p = ev.source;
      if (p?.typeId !== "minecraft:player" || ev.projectile?.typeId !== "minecraft:arrow") return;
      const victim = ev.getEntityHit()?.entity;
      if (!victim || victim.id === p.id || victim.typeId === "minecraft:player") return;
      // Projectile hits count as the most recent target for Judgement.
      lastHit.set(p.id, { entity: victim });
      const job = getJobId(p);
      const held = heldItemId(p);
      if (job === "apprentice" && held === "rpg:apprentice_bow") {
        bump(p, "apprentice_arrow_hits", "견습 활 명중", JOBS.archer.req.need);
      } else if (job === "archer" && held === "rpg:archer_bow") {
        bump(p, "archer_arrow_hits", "궁수 활 명중", JOBS.heavenly_archer.req.need);
      }
    } catch { /* 화살 회수/대상 소멸 시 무시 */ }
  });

  world.afterEvents.entityHurt.subscribe((ev) => {
    const attacker = ev.damageSource?.damagingEntity;
    if (attacker?.typeId !== "minecraft:player") return;
    const victim = ev.hurtEntity;
    if (!victim || victim.id === attacker.id || (victim.typeId === "minecraft:player" && !CONFIG.pvp)) return;
    lastHit.set(attacker.id, { entity: victim });
  });

  world.afterEvents.entityDie.subscribe((ev) => {
    const killer = ev.damageSource?.damagingEntity;
    if (killer?.typeId !== "minecraft:player") return;
    const victim = ev.deadEntity;
    if (!victim || victim.typeId === "minecraft:player") return;

    const jobId = getJobId(killer);

    if (jobId === "apprentice") {
      const held = heldItemId(killer) ?? "";
      if (held.endsWith("_sword")) {
        const need = JOBS.swordsman.req.need;
        bump(killer, "sword_kills", "검 처치", need);
      }
    } else if (jobId === "angel" && VILLAGERS.includes(victim.typeId)) {
      bump(killer, "angel_villager_kills", "주민 처치", JOBS.fallen_angel.req.need);
    } else if (jobId === "sword_saint" && VILLAGERS.includes(victim.typeId)) {
      const need = JOBS.fallen_sword_saint.req.need;
      bump(killer, "villager_kills", "주민 처치", need);
    }
  });
}
