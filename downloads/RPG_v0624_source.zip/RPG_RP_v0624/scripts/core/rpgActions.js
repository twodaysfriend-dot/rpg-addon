import { CONFIG } from "../config.js";
import { JOBS, findJob } from "../data/jobs.js";
import { SKILLS } from "../data/skills.js";
import {
  getJobId, getSkills, getMana, setMana, maxManaOf, manaText, maxManaText, getProgress, getDisabled, resetCooldowns,
} from "./playerData.js";
import {
  requestAdvance, resetToApprentice, giveStarter, requirementStatus, giveAllItems,
} from "./advance.js";
import { offerBooks, offerSwords, offerLight, craftHolyWater } from "./offer.js";
import { openSkillMenu } from "./skillMenu.js";
import { refreshHud } from "./hud.js";
import { toggleWings, inspectWings, refreshWings } from "./wings.js";
import { getFistCoatingStatus } from "./fistCoating.js";
import { openGuildMenu, openPartyMenu, openInvites } from "./social.js";

// 슬래시 명령어(/rpg:...)와 /scriptevent rpg:... 가 같은 동작을 하도록 한 곳에 모았습니다.
export const HELP =
  "§e사용법: /rpg:job <직업> | /rpg:status | /rpg:skills | /rpg:book | /rpg:sword | /rpg:bless | /rpg:holywater | " +
  "/rpg:guild | /rpg:party | /rpg:invites | " +
  "(관리자) /rpg:force <직업> | /rpg:reset | /rpg:starter <sword|mage|holy|fist|archer> | /rpg:items | /rpg:charge | /rpg:wings | /rpg:wingcheck | /rpg:wingrefresh | /rpg:fistcheck | /rpg:boss";

export function runRpgAction(action, p, arg = "") {
  const text = String(arg ?? "").trim();
  switch (action) {
    case "boss": {
      try {
        const loc = p.location;
        const view = p.getViewDirection();
        const flat = Math.hypot(view.x,view.z)||1;
        p.dimension.spawnEntity("rpg:rock_golem_boss",{x:loc.x+view.x/flat*7,y:loc.y+0.2,z:loc.z+view.z/flat*7});
        p.sendMessage("§b바위 골렘이 소환되었습니다! §7처치 경험치 450 XP");
      }catch(e){p.sendMessage("§c골렘 소환 실패: "+String(e));}
      return;
    }
    case "guild":
      openGuildMenu(p); return;
    case "party":
      openPartyMenu(p); return;
    case "invites":
      openInvites(p); return;
    case "job":
    case "force": {
      const target = findJob(text);
      if (!target) {
        const names = Object.values(JOBS).map((j) => j.name).join(", ");
        p.sendMessage(`§c알 수 없는 직업입니다: ${text}\n§7가능: ${names}`);
        return;
      }
      requestAdvance(p, target, action === "force");
      return;
    }
    case "reset":
      resetToApprentice(p);
      p.sendMessage("§7견습으로 초기화했습니다.");
      return;
    case "starter": {
      const r = giveStarter(p, text);
      p.sendMessage(r.ok ? "§a견습 시작 아이템과 스킬을 받았습니다." : `§c${r.reason}`);
      return;
    }
    case "items": {
      const n = giveAllItems(p);
      p.sendMessage(n > 0 ? `§a애드온 전용 아이템 ${n}개를 받았습니다.` : "§7이미 모두 가지고 있습니다.");
      return;
    }
    case "charge":
      setMana(p, maxManaOf(p));
      resetCooldowns(p);
      refreshHud(p, true);
      p.sendMessage("§b마나를 가득 채우고 쿨타임을 초기화했습니다.");
      return;
    case "book":
      offerBooks(p);
      return;
    case "sword":
      offerSwords(p);
      return;
    case "bless":
      offerLight(p);
      return;
    case "holywater":
      craftHolyWater(p);
      return;
    case "wings":
      toggleWings(p);
      return;
    case "fistcheck":
      p.sendMessage(getFistCoatingStatus(p));
      return;
    case "wingcheck":
      inspectWings(p);
      return;
    case "wingrefresh":
      refreshWings(p);
      return;
    case "skills":
      p.sendMessage("§7채팅창을 닫으면 스킬 설정창이 열립니다.");
      openSkillMenu(p);
      return;
    case "status": {
      const job = JOBS[getJobId(p)];
      const skills = getSkills(p).map((id) => SKILLS[id]?.name ?? id).join(", ") || "없음";
      const off = getDisabled(p).map((id) => SKILLS[id]?.name ?? id).join(", ");
      const prog = getProgress(p);
      let msg =
        `§e직업: ${job?.name ?? "없음"} §7/ 마나 ${manaText(p)}/${maxManaText(p)}` +
        ` §7/ 책 ${prog.books ?? 0}권\n§7스킬: ${skills}${off ? `\n§7꺼 둔 스킬: ${off}` : ""}`;
      // 지금 직업에서 갈 수 있는 전직과 조건 진행도
      for (const t of Object.values(JOBS)) {
        if (t.parent !== job?.id || t.placeholder || t.hidden) continue;
        const st = requirementStatus(p, t);
        msg += `\n§7→ ${t.name}: ${st ? `${st.label} ${st.have}/${st.need}` : "조건 없음"}`;
      }
      p.sendMessage(msg);
      return;
    }
    default:
      p.sendMessage(HELP);
  }
}
