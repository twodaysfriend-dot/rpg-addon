import { system, world } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { SKILLS } from "../data/skills.js";
import { manaText, maxManaText, getIndex, cooldownLeft } from "./playerData.js";
import { getContext } from "./context.js";
import { doubleLeft } from "./fistState.js";

// 알림 메시지가 곧바로 HUD에 덮어씌워지지 않도록 잠시 갱신을 멈춥니다.
const hold = new Map(); // playerId -> 이 틱까지 보류

export function notify(player, msg) {
  try {
    player.onScreenDisplay.setActionBar(msg);
    hold.set(player.id, system.currentTick + 30);
  } catch {
    // 화면 표시 실패는 무시
  }
}

function buildText(player, ctx) {
  const { job, skills } = ctx;
  const color = job.corrupt ? "§c" : "§b";
  let head = `${color}[${job.name}]§r §9MP ${manaText(player)}/${maxManaText(player)}`;
  const dbl = doubleLeft(player);
  if (dbl > 0) head += ` §c[강펀치 x${dbl}]`;
  if (skills.length === 0) return head;

  const i = getIndex(player) % skills.length;
  const def = SKILLS[skills[i]];
  const left = cooldownLeft(player, def.id);
  const state = left > 0 ? `§c${(left / 20).toFixed(1)}초` : "§a준비";
  let text = `${head} §8| §e§l${def.name}§r §7(${i + 1}/${skills.length}) ${state}`;
  if (skills.length > 1) {
    const next = SKILLS[skills[(i + 1) % skills.length]];
    text += ` §8| §7다음: ${next.name}`;
  }
  return text;
}

export function refreshHud(player, force = false) {
  try {
    const ctx = getContext(player);
    if (!ctx) return;
    if (!force && (hold.get(player.id) ?? 0) > system.currentTick) return;
    player.onScreenDisplay.setActionBar(buildText(player, ctx));
  } catch {
    // 플레이어가 막 나간 경우 등
  }
}

export function startHud() {
  system.runInterval(() => {
    for (const p of world.getAllPlayers()) refreshHud(p);
  }, CONFIG.hudInterval);
}
