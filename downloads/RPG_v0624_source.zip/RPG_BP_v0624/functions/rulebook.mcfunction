# 실행: /function rulebook
# Always responds with vanilla tellraw even when Script API fails.
tellraw @s {"rawtext":[{"text":"§a[RPG] 안내서 지급을 요청했습니다. 책이 안 나오면 /function rpg_help 를 입력해 주세요."}]}
scriptevent rpg:rulebook
