tellraw @s {"rawtext":[{"text":"§a[RPG v0.5.22] 코어 행동팩 데이터가 로드되었습니다."}]}
scriptevent rpg:ping
