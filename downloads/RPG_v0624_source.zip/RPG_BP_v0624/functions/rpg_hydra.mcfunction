# OP-only fallback: summons the hydra even without Script API custom command registration.
summon rpg:hydra_boss ~ ~ ~
