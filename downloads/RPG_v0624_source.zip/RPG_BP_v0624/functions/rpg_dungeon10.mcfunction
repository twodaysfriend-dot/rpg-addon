# Run as an operator player. No namespace-free custom command is required.
scriptevent rpg:dungeoncreate 10
