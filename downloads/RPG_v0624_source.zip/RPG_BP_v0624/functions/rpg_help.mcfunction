tellraw @s {"rawtext":[{"text":"§6[RPG] 진단: /function rpg_ping, /function rpg_diagnose, /rpg:ping, /rpg:diag"}]}
tellraw @s {"rawtext":[{"text":"§e[RPG] 일반: /rpg:job /rpg:status /rpg:stats /rpg:skills /rpg:help"}]}
tellraw @s {"rawtext":[{"text":"§c[RPG] 관리자: /rpg:egg /rpg:hito /rpg:hydra /rpg:techgolem /rpg:admin"}]}
