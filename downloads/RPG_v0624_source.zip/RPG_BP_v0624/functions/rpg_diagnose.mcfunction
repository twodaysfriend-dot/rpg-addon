tellraw @s {"rawtext":[{"text":"§6[RPG v0.5.22] 코어 행동팩 함수는 로드됨. 명령어와 스크립트 응답을 확인합니다."}]}
scriptevent rpg:diag
