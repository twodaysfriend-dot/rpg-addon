# Player/operator only. Default elevation 200.
scriptevent rpg:citycreate
