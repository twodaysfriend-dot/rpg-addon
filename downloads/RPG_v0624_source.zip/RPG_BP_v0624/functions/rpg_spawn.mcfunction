# 관리자 플레이어로 실행: /function rpg_spawn
scriptevent rpg:spawncreate
