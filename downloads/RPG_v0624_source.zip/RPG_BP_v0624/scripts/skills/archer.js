import {isBoundHeld} from '../core/weaponBinding.js';
import {setCombatHealth,rememberScriptKiller} from '../core/combatContext.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import { areAllies } from "../core/social.js";
import { world, system, InputButton, ButtonState } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { getJobId,getMana,setMana } from "../core/playerData.js";
import { getLastHit } from "../core/tracking.js";
import { aimPoint, firstTargetInView, getTargets, headPos, healthAlive, hurt, isSolidAt, particle, sound, norm3, burn, slow } from "../core/util.js";

// Real arrow entities are used for rapid shots, homing, and instant heavenly shots.
// Each arrow is tagged in memory with the skill that created it; no blocks are exploded.
const VFX = "minecraft:critical_hit_emitter";
const VFX_HEAVEN = "minecraft:totem_particle";
const airwalkEnd = new Map();      // playerId -> expiration tick
const homingEnd = new Map();       // playerId -> expiration tick
const shotWindow = new Map();      // playerId -> {mode,until}
const arrowInfo = new Map();       // arrowId -> {entity,mode,player,expires,hitHandled}
const ARROW_LIFETIME = 100;        // Every archer arrow disappears 5 seconds after release.
const FULL_DRAW_ARROW_SPEED = 3.0; // Velocity of a fully charged vanilla bow shot.
const recentRapidHits = new Map(); // playerId:targetId -> {hp,tick}
const stunList = new Map();        // targetId -> {entity,position,until}
const manaFlights=new Map();
export const MANA_ARROW_COST=20;
export const MANA_ARROW_ID='rpg:mana_arrow';

const add = (a,b) => ({x:a.x+b.x,y:a.y+b.y,z:a.z+b.z});
const scale = (v,s) => ({x:v.x*s,y:v.y*s,z:v.z*s});
const dist = (a,b) => Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
const validEnemy = (p,t) => {
  try { return t && t.id!==p.id && !areAllies(p,t) && (CONFIG.pvp || t.typeId!=="minecraft:player") && healthAlive(t); }
  catch { return false; }
};

// Guaranteed flat bonus damage (health component is changed directly). Used only
// for explicitly defined bonus damage or an arrow blocked by temporary hit i-frames.
function extraDamage(target, amount, source) {
  try {
    const hp=target.getComponent("minecraft:health");
    if(!hp || hp.currentValue<=0) return;
    if(amount>=hp.currentValue&&source)rememberScriptKiller(source,target);setCombatHealth(target,source,hp,Math.max(0,hp.currentValue-amount));
  } catch { /* invalid or non-living entity */ }
}

function markNativeShot(p,mode) {
  shotWindow.set(p.id,{mode,until:system.currentTick+5});
}
const archerJobs = new Set(["apprentice", "archer", "heavenly_archer", "chameleon"]);

function trackArrow(arrow, player, mode = null) {
  try {
    if (!arrow?.isValid || arrow.typeId !== "minecraft:arrow" || !player || !archerJobs.has(getJobId(player))) return;
    if (arrowInfo.has(arrow.id)) return; // Never restart the lifetime for a known arrow.
    arrowInfo.set(arrow.id, {
      entity: arrow, mode, player, hitHandled: false,
      expires: system.currentTick + ARROW_LIFETIME,
    });
  } catch { /* entity was unloaded or its owner is no longer present */ }
}
function trackNativeArrow(arrow) {
  try {
    if (!arrow?.isValid || arrowInfo.has(arrow.id) || arrow.typeId !== "minecraft:arrow") return;
    const p = arrow.getComponent("minecraft:projectile")?.owner;
    if (p?.typeId !== "minecraft:player" || !archerJobs.has(getJobId(p))) return;
    const recent = shotWindow.get(p.id);
    const mode = recent && recent.until >= system.currentTick ? recent.mode : null;
    trackArrow(arrow, p, mode);
  } catch { /* arrow may be removed in the same tick */ }
}
function spawnArrow(p,location,velocity,mode) {
  let a;
  try {
    a=p.dimension.spawnEntity("minecraft:arrow",location);
    const proj=a.getComponent("minecraft:projectile");
    if(!proj){a.remove();return;}
    proj.owner=p;
    proj.shoot(velocity,{uncertainty:0});
    trackArrow(a,p,mode);
    return a;
  } catch {try{a?.remove();}catch{}return undefined;}
}
export function heavenlyAmmoCost(p,count=1){
  if(getJobId(p)!=='heavenly_archer')return Infinity;
  if(String(p.getGameMode?.()??'').toLowerCase().includes('creative'))return 0;
  const inv=p.getComponent('minecraft:inventory')?.container;
  if(inv)for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId==='minecraft:arrow')return 0;
  return MANA_ARROW_COST*count;
}
function spawnManaArrow(p,location,velocity,mode){
  if(getJobId(p)!=='heavenly_archer'||getMana(p)<MANA_ARROW_COST)return undefined;
  let arrow;const mana=getMana(p);
  try{
    arrow=p.dimension.spawnEntity(MANA_ARROW_ID,location);
    setMana(p,mana-MANA_ARROW_COST); // Fixed passive cost: no INT discount.
    manaFlights.set(arrow.id,{entity:arrow,player:p,dimension:p.dimension,velocity,mode,expires:system.currentTick+ARROW_LIFETIME});
    return arrow;
  }catch{try{arrow?.remove();}catch{}try{setMana(p,mana);}catch{}return undefined;}
}
// Called once per heavenly bow right-click, instead of charging native shooter.
// Consumes one regular arrow in survival; creative players can fire for free.
export function shootHeavenlyInstant(p){
  let shot,original,ammoSlot=-1;
  try{
    if(getJobId(p)!=='heavenly_archer'&&!(isBoundHeld(p)&&['archer','apprentice'].includes(getJobId(p))))return false;
    const gm=String(p.getGameMode?.()??"").toLowerCase();
    const creative=gm.includes("creative");
    const inv=p.getComponent("minecraft:inventory")?.container;
    if(!creative){
      if(!inv)return false;
      for(let i=0;i<inv.size;i++){
        if(inv.getItem(i)?.typeId==="minecraft:arrow"){ammoSlot=i;break;}
      }
    }
    if(!creative&&ammoSlot<0&&getJobId(p)!=='heavenly_archer')return false;
    const d=norm3(p.getViewDirection());
    const at=add(headPos(p),scale(d,0.85));
    const recent=shotWindow.get(p.id);
    const mode=recent&&recent.until>=system.currentTick?recent.mode:null;
    shot=!creative&&ammoSlot<0?spawnManaArrow(p,at,scale(d,FULL_DRAW_ARROW_SPEED),mode):spawnArrow(p,at,scale(d,FULL_DRAW_ARROW_SPEED),mode);
    if(!shot)return false;
    if(ammoSlot>=0){
      original=inv.getItem(ammoSlot).clone();const stack=original.clone();
      if(stack.amount<=1)inv.setItem(ammoSlot,undefined);
      else {stack.amount--;inv.setItem(ammoSlot,stack);}
    }
    sound(p.dimension,"random.bow",p.location,{volume:0.8,pitch:1.35});
    return true;
  }catch{
    try{shot?.remove();if(shot)arrowInfo.delete(shot.id);}catch{}
    if(original)try{p.getComponent('minecraft:inventory').container.setItem(ammoSlot,original);}catch{}
    return false;
  }
}

export function clearPreparedBowMode(p){shotWindow.delete(p.id);}

function fireAdditional(p,count,mode) {
  const d=norm3(p.getViewDirection());
  const side=norm3({x:-d.z,y:0,z:d.x});
  const origin=add(headPos(p),scale(d,0.7));
  for(let i=0;i<count;i++){
    const spread=(i-(count-1)/2)*0.105 + (count%2===0?0.055:0);
    const v=norm3(add(d,scale(side,spread)));
    const velocity=scale(v,getJobId(p)==="heavenly_archer"?FULL_DRAW_ARROW_SPEED:2.7);
    if(getJobId(p)==='heavenly_archer'&&heavenlyAmmoCost(p)>0)spawnManaArrow(p,origin,velocity,mode);
    else spawnArrow(p,origin,velocity,mode);
  }
}
function holdStill(target,ticks){
  try {
    const at={...target.location};
    applyStatus(target,"slowness",ticks,{amplifier:255,showParticles:true});
    applyStatus(target,"weakness",ticks,{amplifier:255,showParticles:false});
    stunList.set(target.id,{entity:target,position:at,until:system.currentTick+ccTicks(target,ticks)});
  } catch {}
}
function arrowExplode(p,target,where) {
  // Visual blast only; does not break terrain or damage unintended bystanders.
  for(let i=0;i<12;i++){
    const a=2*Math.PI*i/12;
    particle(p.dimension,"minecraft:basic_crit_particle",{x:where.x+Math.cos(a)*1.1,y:where.y+1.0,z:where.z+Math.sin(a)*1.1});
  }
  if(target)extraDamage(target,14,p);
  sound(p.dimension,"random.explode",where,{volume:0.5,pitch:1.3});
}
function arrowHit(p,target,mode,location){
  if(!validEnemy(p,target))return;
  const now=system.currentTick;
  if(mode==="rapid"){
    const key=p.id+":"+target.id;
    const old=recentRapidHits.get(key);
    const hp=target.getComponent("minecraft:health");
    // The first arrow deals native damage. Further simultaneous arrows which
    // could not reduce health due to hit immunity still each deal 4 HP damage.
    if(hp){
      if(old && now-old.tick<=12 && hp.currentValue>=old.hp-0.001){extraDamage(target,4,p);}
      recentRapidHits.set(key,{hp:target.getComponent("minecraft:health")?.currentValue??0,tick:now});
    }
  }else if(mode==="fire"){
    burn(target,5);
    particle(p.dimension,"minecraft:basic_flame_particle",add(target.location,{x:0,y:1,z:0}));
  }else if(mode==="ice"){
    slow(target,2,100); // 구속 III (0-based amplifier 2), 5 seconds
    extraDamage(target,3,p);
  }else if(mode==="lightning"){
    holdStill(target,20); // 1 second
    particle(p.dimension,VFX_HEAVEN,add(target.location,{x:0,y:1,z:0}));
  }else if(mode==="bomb"){
    arrowExplode(p,target,location??target.location);
  }
}

function rayShot(player,direction,options={}) {
  const dim=player.dimension, origin=headPos(player), dir=norm3(direction), seen=new Set();
  let reach=0;
  const handle=system.runInterval(()=>{
    try {
      for(let i=0;i<3;i++){
        reach+=1.1;
        if(reach>options.range){system.clearRun(handle);return;}
        const pos=add(origin,scale(dir,reach));
        if(isSolidAt(dim,pos)){particle(dim,VFX,pos);system.clearRun(handle);return;}
        particle(dim,options.vfx||VFX,pos);
        for(const t of getTargets(player,pos,options.radius||1.3,0.8)){
          if(seen.has(t.id)||!healthAlive(t))continue;
          seen.add(t.id);
          hurt(t,player,options.damage||0);
          particle(dim,VFX,add(t.location,{x:0,y:1,z:0}));
          if(options.onHit)options.onHit(t);
          if(!options.pierce){system.clearRun(handle);return;}
        }
      }
    }catch{system.clearRun(handle);}
  },1);
}

function seekEnemy(p,from,reach){
  let best,nearest=reach;
  try{
    for(const e of getTargets(p,from,reach,0)){
      const d=dist(from,add(e.location,{x:0,y:1.1,z:0}));
      if(d<nearest){nearest=d;best=e;}
    }
  }catch{}
  return best;
}

export const RUNNERS={
  archer_airwalk(p,job,def){
    const duration=job.id==="heavenly_archer"?300:job.id==="archer"?160:60;
    airwalkEnd.set(p.id,system.currentTick+duration);
    sound(p.dimension,"random.orb",p.location,{volume:0.8,pitch:1.6});
    try{p.onScreenDisplay.setActionBar(`§b에어워크 §f${duration/20}초`);}catch{}
  },
  archer_rapid(p,job,def){
    const count=job.id==="heavenly_archer"?5:job.id==="archer"?3:2;
    markNativeShot(p,"rapid");
    // A regular shot is generated by the custom bow's shooter component.
    fireAdditional(p,count-(getJobId(p)==='chameleon'?0:1),"rapid");
    sound(p.dimension,"random.bow",p.location,{volume:1,pitch:1.35});
  },
  archer_fire(p,job,def){
    markNativeShot(p,"fire");
    if (getJobId(p)==="chameleon") fireAdditional(p,1,"fire");
    sound(p.dimension,"fire.ignite",p.location,{volume:0.8,pitch:1.1});
  },
  archer_ice(p,job,def){
    markNativeShot(p,"ice");
    if (getJobId(p)==="chameleon") fireAdditional(p,1,"ice");
    sound(p.dimension,"random.glass",p.location,{volume:0.7,pitch:1.5});
  },
  archer_lightning(p,job,def){
    markNativeShot(p,"lightning");
    if (getJobId(p)==="chameleon") fireAdditional(p,1,"lightning");
    sound(p.dimension,"item.trident.thunder",p.location,{volume:0.6,pitch:1.5});
  },
  archer_homing(p,job,def){
    homingEnd.set(p.id,system.currentTick+2400); // 2 minutes
    sound(p.dimension,"random.levelup",p.location,{volume:0.8,pitch:1.65});
    try{p.onScreenDisplay.setActionBar("§e유도 화살 §f2분 활성화");}catch{}
  },
  archer_bomb(p,job,def){
    markNativeShot(p,"bomb");
    if (getJobId(p)==="chameleon") fireAdditional(p,1,"bomb");
    sound(p.dimension,"random.bow",p.location,{volume:1,pitch:0.85});
  },
  // Legacy v0.4.16 skills retained for backwards compatibility.
  archer_triple(p,job,def){
    const d=p.getViewDirection(),side=norm3({x:-d.z,y:0,z:d.x});
    for(const spread of [-def.spread,0,def.spread])rayShot(p,add(d,scale(side,spread)),{range:def.range,damage:def.damage,radius:1.25});
  },
  archer_pierce(p,job,def){
    rayShot(p,p.getViewDirection(),{range:def.range,damage:def.damage,radius:def.hitRadius,pierce:true});
    sound(p.dimension,"item.trident.throw",p.location,{volume:0.8,pitch:1.1});
  },
  archer_judgement(p,job,def){
    // The target is the LAST living entity this player damaged, not the one in view.
    const target=getLastHit(p);
    if(!validEnemy(p,target) || target.dimension.id!==p.dimension.id){
      try{p.sendMessage("§c심판: 마지막으로 피해를 준 살아 있는 대상이 없습니다.");}catch{}
      return false; // no MP spent, no cooldown
    }
    const dim=p.dimension;
    const origin=headPos(p);
    const targetCenter=add(target.location,{x:0,y:1,z:0});
    const firstDir=norm3({x:targetCenter.x-origin.x,y:targetCenter.y-origin.y,z:targetCenter.z-origin.z});
    const pos=add(origin,scale(firstDir,2.0));
    let arrow;
    try{arrow=dim.spawnEntity("rpg:judgement_arrow",pos);}catch{
      try{p.sendMessage("§c심판 화살 엔티티를 생성하지 못했습니다.");}catch{}
      return false;
    }
    const speed=def.speed||2.6, damage=def.damage||54, maxTicks=90;
    let ticks=0,finished=false;
    sound(dim,"item.trident.thunder",p.location,{volume:0.85,pitch:1.35});
    const finish=(hit=false)=>{
      if(finished)return;
      finished=true;
      try{arrow.remove();}catch{}
      if(hit){
        // Apply damage ONCE, not on every tick or with extra splash damage.
        if(healthAlive(target))hurt(target,p,damage);
        for(let j=0;j<20;j++){
          const angle=j*Math.PI/10;
          particle(dim,VFX_HEAVEN,{x:target.location.x+Math.cos(angle)*1.6,y:target.location.y+1.0,z:target.location.z+Math.sin(angle)*1.6});
        }
        sound(dim,"item.trident.thunder",target.location,{volume:1,pitch:1.7});
      }
      try{system.clearRun(handle);}catch{}
    };
    const handle=system.runInterval(()=>{
      try{
        if(++ticks>maxTicks || !healthAlive(target) || target.dimension.id!==dim.id){finish();return;}
        const cur=arrow.location, at=add(target.location,{x:0,y:1,z:0});
        const vector={x:at.x-cur.x,y:at.y-cur.y,z:at.z-cur.z};
        const remaining=Math.hypot(vector.x,vector.y,vector.z);
        if(remaining<=speed+0.85){finish(true);return;}
        const step=scale(norm3(vector),speed);
        const next=add(cur,step);
        // Do not pass the glowing projectile through walls.
        if(isSolidAt(dim,next)){finish();return;}
        arrow.teleport(next,{dimension:dim,facingLocation:at});
        if(ticks%2===0){
          particle(dim,VFX_HEAVEN,next);
          particle(dim,"minecraft:basic_crit_particle",add(next,{x:0,y:0.35,z:0}));
        }
      }catch{finish();}
    },1);
  },
  archer_heavenly(p,job,def){
    let burst=false;
    const explode=(e)=>{
      if(burst)return;burst=true;
      for(const t of getTargets(p,e.location,def.burstRadius,0)){
        if(t.id!==e.id)hurt(t,p,def.burstDamage);
      }
      for(let i=0;i<22;i++){
        const a=i*2*Math.PI/22;
        particle(p.dimension,VFX_HEAVEN,{x:e.location.x+Math.cos(a)*def.burstRadius,y:e.location.y+1,z:e.location.z+Math.sin(a)*def.burstRadius});
      }
    };
    rayShot(p,p.getViewDirection(),{range:def.range,damage:def.damage,radius:def.hitRadius,pierce:true,vfx:VFX_HEAVEN,onHit:explode});
    sound(p.dimension,"item.trident.thunder",p.location,{volume:0.8,pitch:1.1});
  },
};

export function registerArcher(){
  // Native custom-bow arrows are spawned by the engine, not by spawnArrow().
  // Defer one tick so minecraft:projectile.owner has been populated.
  world.afterEvents.entitySpawn.subscribe(e => {
    if (e.entity?.typeId !== "minecraft:arrow") return;
    system.runTimeout(() => trackNativeArrow(e.entity), 1);
  });
  // Infinite repeat air-jumps only while the selected skill's timed buff is active.
  world.afterEvents.playerButtonInput?.subscribe(e=>{
    if(e.button!==InputButton.Jump||e.newButtonState!==ButtonState.Pressed)return;
    const p=e.player;
    if(system.currentTick >= (airwalkEnd.get(p.id)||0))return;
    if(!["apprentice","archer","heavenly_archer","chameleon"].includes(getJobId(p)))return;
    try{
      if(p.isOnGround)return; // ordinary ground jump remains unchanged
      const v=p.getVelocity();
      p.clearVelocity();
      p.applyImpulse({x:v.x,y:0.49,z:v.z});
      particle(p.dimension,VFX,{x:p.location.x,y:p.location.y+0.2,z:p.location.z});
    }catch{}
  });

  world.afterEvents.projectileHitEntity?.subscribe(e=>{
    try{
      if(e.projectile?.typeId!=="minecraft:arrow")return;
      const victim=e.getEntityHit()?.entity;
      const info=arrowInfo.get(e.projectile.id);
      if(info?.hitHandled)return;
      const p=info?.player||e.source;
      if(p?.typeId!=="minecraft:player"||!["apprentice","archer","heavenly_archer","chameleon"].includes(getJobId(p)))return;
      if(!validEnemy(p,victim))return;
      const window=shotWindow.get(p.id);
      const mode=info?.mode||(window&&window.until>=system.currentTick?window.mode:null);
      if(mode)arrowHit(p,victim,mode,e.location);
      // A landed arrow must still be removed at launch + 100 ticks.
      if(info)info.hitHandled=true;
      else trackArrow(e.projectile,p,mode);
    }catch{}
  });
  world.afterEvents.projectileHitBlock?.subscribe(e=>{
    // Do not forget landed arrows; they are removed at launch + 100 ticks.
    try { trackNativeArrow(e.projectile); } catch {}
  });
  world.afterEvents.playerLeave.subscribe(e=>{
    airwalkEnd.delete(e.playerId);homingEnd.delete(e.playerId);shotWindow.delete(e.playerId);
    // Keep in-flight arrows tracked after their shooter disconnects so that
    // their 5-second cleanup still runs, even without a connected player.
  });

  system.runInterval(()=>{
    const now=system.currentTick;
    for(const [id,flight] of manaFlights){
      const {entity,player,dimension,mode}=flight;
      const finish=()=>{try{entity.remove();}catch{}manaFlights.delete(id);};
      try{
        if(!entity.isValid||!player.isValid||now>=flight.expires||player.dimension.id!==dimension.id){finish();continue;}
        let velocity=flight.velocity;
        if(now<(homingEnd.get(player.id)||0)){
          const target=seekEnemy(player,entity.location,24);
          if(target)velocity=scale(norm3({x:target.location.x-entity.location.x,y:target.location.y+1-entity.location.y,z:target.location.z-entity.location.z}),FULL_DRAW_ARROW_SPEED);
        }
        let current={...entity.location},done=false;
        for(let step=0;step<6;step++){
          const next=add(current,scale(velocity,1/6));
          if(isSolidAt(dimension,next)){done=true;break;}
          const target=getTargets(player,next,.85,.9).find(e=>validEnemy(player,e));
          if(target){hurt(target,player,6,'fixed');if(mode)arrowHit(player,target,mode,next);done=true;break;}
          current=next;
        }
        if(done){finish();continue;}
        entity.teleport(current,{dimension,facingLocation:add(current,velocity)});
        particle(dimension,VFX_HEAVEN,current);
        flight.velocity={x:velocity.x*.99,y:velocity.y*.99-.05,z:velocity.z*.99};
      }catch{finish();}
    }
    // Fallback for regular native bow arrows in runtimes where entitySpawn
    // arrives before the projectile owner is available. Also works on plain
    // shots without rapid/fire/ice skill mode or the homing buff.
    for(const p of world.getAllPlayers()){
      if(!archerJobs.has(getJobId(p)))continue;
      const recent=shotWindow.get(p.id);
      if(recent&&recent.until<now)shotWindow.delete(p.id);
      try{
        for(const arrow of p.dimension.getEntities({type:"minecraft:arrow",location:p.location,maxDistance:24})){
          if(arrowInfo.has(arrow.id))continue;
          if(arrow.getComponent("minecraft:projectile")?.owner?.id!==p.id)continue;
          trackNativeArrow(arrow);
        }
      }catch{}
    }
    // Always clean expired arrow entities, including arrows embedded in blocks.
    for(const [id,info] of arrowInfo){
      if(now>=info.expires){
        try{ if(info.entity?.isValid)info.entity.remove(); }catch{}
        arrowInfo.delete(id);
        continue;
      }
      if(!info.entity?.isValid){arrowInfo.delete(id);continue;}
      if(now>=(homingEnd.get(info.player?.id)||0))continue;
      try{
        const arrow=info.entity;
        if(!arrow){arrowInfo.delete(id);continue;}
        const target=seekEnemy(info.player,arrow.location,24);
        if(!target)continue;
        const to=add(target.location,{x:0,y:1.0,z:0});
        const speed=getJobId(info.player)==="heavenly_archer"?FULL_DRAW_ARROW_SPEED:2.1;
        const velocity=scale(norm3({x:to.x-arrow.location.x,y:to.y-arrow.location.y,z:to.z-arrow.location.z}),speed);
        arrow.getComponent("minecraft:projectile")?.shoot(velocity,{uncertainty:0});
        if(now%4===0)particle(info.player.dimension,VFX_HEAVEN,arrow.location);
      }catch{
        // A failed guidance update must never cancel the 5-second lifetime.
      }
    }
    for(const [id,s] of stunList){
      if(now>=s.until){stunList.delete(id);continue;}
      try{s.entity.teleport(s.position,{dimension:s.entity.dimension});}catch{stunList.delete(id);}
    }
    if(now%40===0){
      for(const [k,v] of recentRapidHits)if(now-v.tick>20)recentRapidHits.delete(k);
      for(const [pid,until] of airwalkEnd)if(until<=now)airwalkEnd.delete(pid);
      for(const [pid,until] of homingEnd)if(until<=now)homingEnd.delete(pid);
    }
  },1);
}
