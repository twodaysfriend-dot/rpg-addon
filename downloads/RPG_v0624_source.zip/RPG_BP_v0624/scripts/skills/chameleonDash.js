import {isBoundHeld} from '../core/weaponBinding.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import { world, system } from "@minecraft/server";
import { getJobId, startCooldown } from "../core/playerData.js";
import { getTargets, healthAlive, skillItemId as heldItemId, hurt, particle, sound } from "../core/util.js";
import { notify, refreshHud } from "../core/hud.js";

const SKILL = "chameleon_crimson_dash";
const WEAPON = "rpg:chameleon_flame_blade";
const SCYTHE = "rpg:chameleon_moon_scythe";
const TRAIL = "rpg:chameleon_crimson_trail";
const IMPACT = "rpg:chameleon_crimson_impact";
const GROUND = "rpg:chameleon_platinum_ground";
// A chain contains at most three casts. A cast without a kill breaks the chain.
const chainKills = new Map(); // player ID => successful earlier casts (0..2)
const active = new Map(); // player ID => current collision window
const recentHits = new Map(); // target ID => last successful skill collision
let nextToken = 1;
let subscribed = false;

function enemyFilter(player, entity) {
  try {
    return !!entity && entity.id !== player.id && healthAlive(entity);
  } catch { return false; }
}

function groundBurst(player, center, def) {
  const dim = player.dimension;
  const rings = [0, 1.15, 2.1, 3.05];
  for (let step = 0; step < (def.pulses ?? 7); step++) {
    system.runTimeout(() => {
      try {
        for (let rIndex = 0; rIndex < rings.length; rIndex++) {
          const r = rings[rIndex];
          const count = r === 0 ? 1 : 6 + rIndex * 2;
          for (let i = 0; i < count; i++) {
            const a = count === 1 ? 0 : (Math.PI * 2 * i / count) + step * 0.22 + rIndex * 0.17;
            const x = center.x + Math.cos(a) * r;
            const z = center.z + Math.sin(a) * r;
            const y = center.y + 0.1 + step * (def.pulseStep ?? 0.34);
            particle(dim, GROUND, { x, y, z });
          }
        }
      } catch {}
    }, step);
  }
}

function groundSlam(player, job, def) {
  if (getJobId(player) !== "chameleon" || (!isBoundHeld(player)&&heldItemId(player) !== SCYTHE)) {
    notify(player, "§c카멜레온 낫을 들고 사용할 수 있는 스킬입니다.");
    return false;
  }
  const dim = player.dimension;
  const loc = player.location;
  const center = { x: loc.x, y: loc.y, z: loc.z };
  const targets = getTargets(player, center, def.radius ?? 4.6, 0.9).filter(e => enemyFilter(player, e));
  for (const target of targets) {
    hurt(target, player, def.damage ?? 18, "magic");
    try { target.applyKnockback(0, 0, 0, 0.28*ccScale(target)); } catch {}
  }
  groundBurst(player, center, def);
  sound(dim, "mob.evocation_illager.cast_spell", center, { volume: 0.85, pitch: 0.7 });
  sound(dim, "random.anvil_land", center, { volume: 0.8, pitch: 1.3 });
  notify(player, "§f지면강타: §e백금 에너지가 바닥에서 솟구칩니다.");
  return true;
}


function finishSession(session) {
  if (active.get(session.player.id) !== session) return;
  active.delete(session.player.id);
  try { system.clearRun(session.task); } catch {}
  if (!session.killed) chainKills.delete(session.player.id);
}

function confirmKill(session, targetId) {
  if (active.get(session.player.id) !== session || session.killed || !session.targets.has(targetId)) return;
  session.killed = true;
  recentHits.delete(targetId);
  if (session.castNumber < session.maxChain) {
    chainKills.set(session.player.id, session.castNumber);
    startCooldown(session.player, SKILL, 0);
    notify(session.player, `§c적섬 돌진 §a처치 성공! §f재사용 가능 (§e${session.castNumber}/${session.maxChain}§f)`);
  } else {
    // On the third cast the full 20s cooldown always applies, even on a kill.
    chainKills.delete(session.player.id);
    notify(session.player, "§c적섬 돌진 §6연속 3회 완료! §f쿨타임 20초");
  }
  finishSession(session); // Speed V continues for the original five seconds.
  refreshHud(session.player, true);
}

function inspectCollision(session) {
  const p = session.player;
  try {
    if (!p.isValid || getJobId(p) !== "chameleon" || (!isBoundHeld(p)&&heldItemId(p) !== WEAPON) ||
        system.currentTick >= session.untilTick || p.dimension.id !== session.dimensionId) {
      finishSession(session);
      return;
    }
    const loc = p.location;
    // World entity queries are broad; refine to actual body-to-body contact.
    const center = { x: loc.x, y: loc.y + 0.9, z: loc.z };
    for (const enemy of getTargets(p, center, session.collisionRadius + 0.3, 0.9)) {
      if (!healthAlive(enemy) || session.targets.has(enemy.id)) continue;
      const pos = enemy.location;
      const dx = pos.x - loc.x, dz = pos.z - loc.z;
      if (dx*dx + dz*dz > session.collisionRadius*session.collisionRadius ||
          Math.abs(pos.y - loc.y) > 1.35) continue;
      session.targets.add(enemy.id); // one hit per enemy per use
      const targetId = enemy.id;
      const record = { session, targetId, tick: system.currentTick };
      recentHits.set(targetId, record); // mark BEFORE applying damage: death event may fire immediately
      if (!hurt(enemy, p, session.damage, "fixed")) {
        session.targets.delete(targetId);
        if (recentHits.get(targetId) === record) recentHits.delete(targetId);
        continue;
      }
      particle(p.dimension, IMPACT, { x: pos.x, y: pos.y + 1, z: pos.z });
      sound(p.dimension, "random.swish", pos, { volume: 0.8, pitch: 0.8 });
      // Compatibility fallback when entityDie is not delivered by a platform.
      try {
        if (enemy.getComponent("minecraft:health")?.currentValue <= 0) confirmKill(session, targetId);
      } catch {}
      system.runTimeout(() => {
        if (recentHits.get(targetId) === record) recentHits.delete(targetId);
      }, 3);
      if (session.killed) return;
    }
    if (system.currentTick % 3 === 0) {
      particle(p.dimension, TRAIL, { x: loc.x, y: loc.y + 0.9, z: loc.z });
    }
  } catch { finishSession(session); }
}

export const RUNNERS = {
  chameleon_ground_slam: groundSlam,
  [SKILL](player, job, def) {
    if (getJobId(player) !== "chameleon" || (!isBoundHeld(player)&&heldItemId(player) !== WEAPON)) {
      notify(player, "§c흑염 대검을 들고 사용할 수 있는 스킬입니다.");
      return false;
    }
    try {
      applyStatus(player,"speed", def.duration, { amplifier: def.speedAmplifier, showParticles: false });
    } catch {
      notify(player, "§c신속 효과를 적용하지 못했습니다.");
      return false;
    }
    // Cancel an old window when the next cast becomes available after a kill.
    const old = active.get(player.id);
    if (old) finishSession(old);
    const castNumber = Math.min(def.maxChain, (chainKills.get(player.id) ?? 0) + 1);
    if (castNumber === def.maxChain) chainKills.delete(player.id);
    const session = {
      player, token: nextToken++, dimensionId: player.dimension.id, castNumber,
      maxChain: def.maxChain, damage: def.damage, collisionRadius: def.collisionRadius,
      untilTick: system.currentTick + def.duration,
      killed: false, targets: new Set(), task: undefined,
    };
    active.set(player.id, session);
    session.task = system.runInterval(() => inspectCollision(session), 1);
    particle(player.dimension, TRAIL, { x: player.location.x, y: player.location.y + 1, z: player.location.z });
    sound(player.dimension, "random.swish", player.location, { volume: 0.85, pitch: 1.4 });
    notify(player, `§c적섬 돌진 §f신속 V 5초 · 접촉 피해 20 (§e${castNumber}/${def.maxChain}§f)`);
    return { cooldown: castNumber >= def.maxChain ? def.finishCooldown : def.cooldown };
  },
};

export function registerChameleonDash() {
  if (subscribed) return;
  subscribed = true;
  // Only a kill caused by this skill's most recent collision resets the cooldown.
  world.afterEvents.entityDie?.subscribe(ev => {
    try {
      const targetId = ev.deadEntity?.id;
      const record = recentHits.get(targetId);
      if (!record || system.currentTick - record.tick > 3) return;
      const killer = ev.damageSource?.damagingEntity;
      if (killer && killer.id !== record.session.player.id) return;
      confirmKill(record.session, targetId);
    } catch {}
  });
  world.afterEvents.playerLeave?.subscribe(ev => {
    const session = active.get(ev.playerId);
    if (session) finishSession(session);
    chainKills.delete(ev.playerId);
    for (const [id, rec] of recentHits) if (rec.session.player.id === ev.playerId) recentHits.delete(id);
  });
}
