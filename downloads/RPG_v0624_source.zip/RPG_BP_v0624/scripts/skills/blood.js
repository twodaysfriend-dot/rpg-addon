import {SKILLS} from '../data/skills.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import { areAllies } from "../core/social.js";
import { world, system, ItemStack, EquipmentSlot } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { getJobId, getSkills } from "../core/playerData.js";
import { getTargets, hurt as hurtBase, particle, sound, headPos, norm3, dist3, isSolidAt, firstTargetInView } from "../core/util.js";
import { notify } from "../core/hud.js";

const BLOOD = "rpg:blood_spark";
const SIGIL = "rpg:blood_sigil";
const BURST = "rpg:blood_burst";
const SPEAR = "rpg:blood_spear";
const bursts = new Map();
const spearNativeReplaced=new Map();
const spearKey=(p,t)=>p.id+":"+t.id;
export function isBloodSpearHit(ev){try{return ev.damageSource?.cause==='entityAttack' && ev.damageSource?.damagingEntity?.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand)?.typeId===SPEAR;}catch{return false;}}
export function replaceBloodSpearHit(ev){
 if(!isBloodSpearHit(ev))return false;const p=ev.damageSource.damagingEntity,t=ev.hurtEntity;
 const eq=p.getComponent('minecraft:equippable'),weapon=eq?.getEquipment(EquipmentSlot.Mainhand);
 if(Number(weapon?.getDynamicProperty('rpg:spear_hits')??0)>=SKILLS.blood_spear.durability){const h=t.getComponent('minecraft:health');if(h?.currentValue>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));eq?.setEquipment(EquipmentSlot.Mainhand,undefined);return true;}
 if(!enemy(p,t))return true;
 for(const [key,tick]of spearNativeReplaced)if(tick<system.currentTick-2)spearNativeReplaced.delete(key);
 spearNativeReplaced.set(spearKey(p,t),system.currentTick);
 const hp=t.getComponent('minecraft:health');if(hp?.currentValue>0)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+ev.damage));
 hurtBase(t,p,SKILLS.blood_spear.damage,'magic',{strengthIncluded:true,ignoreInvulnerability:true});return true;
}

const pinned = new Map();
let installed = false;

function valid(e) { try {return !!e?.isValid && (e.getComponent('minecraft:health')?.currentValue ?? 0)>0;}catch{return false;} }
function enemy(p,e){return valid(e) && e.id!==p.id && !areAllies(p,e) && (e.typeId!=="minecraft:player" || CONFIG.pvp);}
function pos(p,y=1){let a=p.location; return {x:a.x,y:a.y+y,z:a.z};}
function emit(dim,location,id=BLOOD,n=1){for(let i=0;i<n;i++)particle(dim,id,{x:location.x+(i%3-1)*0.10,y:location.y+((i*3)%5)*0.09,z:location.z+(i%5-2)*0.10});}
function trace(dim,a,b,id=BLOOD,step=.6){const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z; const total=Math.hypot(dx,dy,dz);for(let k=0;k<=Math.min(64,Math.ceil(total/step));k++){let t=k/Math.max(1,Math.ceil(total/step));particle(dim,id,{x:a.x+dx*t,y:a.y+dy*t,z:a.z+dz*t});}}
function shot(player,dir,range,velocity,hitRadius,onImpact,fx=BLOOD){
  const dim=player.dimension,source=headPos(player),from={x:source.x+dir.x*.75,y:source.y+dir.y*.75,z:source.z+dir.z*.75};
  let travel=0;
  const ticker=system.runInterval(()=>{
    try{
      if(!player.isValid || travel>=range){system.clearRun(ticker);return;}
      for(let sub=0;sub<3;sub++){
        travel+=velocity/3;
        const pt={x:from.x+dir.x*travel,y:from.y+dir.y*travel,z:from.z+dir.z*travel};
        if(isSolidAt(dim,pt)){emit(dim,pt,SIGIL,4);system.clearRun(ticker);return;}
        if(sub===0 || sub===2) particle(dim,fx,pt);
        const targets=getTargets(player,pt,hitRadius,.8).filter(e=>enemy(player,e));
        if(targets.length){onImpact(targets[0],pt);emit(dim,pt,SIGIL,8);system.clearRun(ticker);return;}
      }
    }catch{system.clearRun(ticker);}
  },1);
}

function spear(player,job,def){
  try{
    const item=new ItemStack(SPEAR,1);
    item.setDynamicProperty("rpg:spear_hits",0);
    item.setLore(["§c피의 창§r", "§7사용: 6칸 찌르기 · 마법 피해 14 · 시듦 I 3초", "§7남은 사용 횟수: 5/5"]);
    const container=player.getComponent('minecraft:inventory')?.container;
    if(!container)return false;
    const leftover=container.addItem(item);
    if(leftover)player.dimension.spawnItem(leftover,pos(player,.5));
    emit(player.dimension,pos(player,1),SIGIL,12);
    notify(player,"§c피의 창 생성! §7사용하면 6칸 찌르기 · 5회 공격 가능합니다.");
    sound(player.dimension,'mob.blaze.shoot',player.location,{volume:.65,pitch:.65});
    return true;
  }catch{return false;}
}
function orb(player,job,def){
  const d=norm3(player.getViewDirection());
  shot(player,d,def.range,def.speed,1.5,(target,point)=>{
    hurt(target,player,def.damage);
    const list=getTargets(player,point,def.burstRadius,.7).filter(e=>enemy(player,e)&&e.id!==target.id);
    for(const e of list)hurt(e,player,def.splashDamage);
    for(let j=0;j<12;j++){
      const a=j*Math.PI*2/12;
      particle(player.dimension,BURST,{x:point.x+Math.cos(a)*0.8,y:point.y+0.1,z:point.z+Math.sin(a)*0.8});
    }
    emit(player.dimension,point,SIGIL,4);
    sound(player.dimension,'random.explode',point,{volume:.8,pitch:.5});
  },SIGIL);
  emit(player.dimension,pos(player,1.2),BURST,3);
  sound(player.dimension,'mob.blaze.shoot',player.location,{volume:1,pitch:.45});return true;
}
function supernova(player,job,def){
 const dim=player.dimension,v=norm3(player.getViewDirection()),base=headPos(player);
 let center={...base};
 for(let t=.5;t<=def.forward;t+=.5){const point={x:base.x+v.x*t,y:base.y+v.y*t,z:base.z+v.z*t};if(isSolidAt(dim,point))break;center=point;}
 // A short-lived blood sphere detonates at its summoned position.
 let elapsed=0;const timer=system.runInterval(()=>{try{
  if(!valid(player)||player.dimension.id!==dim.id){system.clearRun(timer);return;}
  emit(dim,center,SIGIL,12);elapsed+=3;
  if(elapsed<def.detonateTicks)return;system.clearRun(timer);
  for(const e of getTargets(player,center,def.burstRadius).filter(e=>enemy(player,e)))hurt(e,player,def.damage);
  emit(dim,center,BURST,24);sound(dim,'random.explode',center,{volume:1,pitch:.6});
 }catch{system.clearRun(timer);}},3);return true;
}
function bloodMark(player,job,def){
  const target=firstTargetInView(player,def.range);
  if(target && enemy(player,target) && dist3(player.location,target.location)<=def.meleeRange){
    trace(player.dimension,pos(player,1.25),pos(target,1.0),SIGIL,.25);
    emit(player.dimension,pos(target,1.0),BURST,5);
    hurt(target,player,def.meleeDamage,"physical");
    sound(player.dimension,'random.anvil_land',target.location,{volume:.35,pitch:1.7});
    notify(player,'§c혈인: 근거리 혈검');return true;
  }
  const dir=norm3(player.getViewDirection());
  shot(player,dir,def.range,1.45,1.45,(e,hit)=>{
    hurt(e,player,def.rangedDamage);
    for(let j=0;j<16;j++){
      const a=j*Math.PI*2/16;
      particle(player.dimension,SIGIL,{x:hit.x+Math.cos(a)*1.25,y:hit.y+Math.sin(a)*0.15,z:hit.z+Math.sin(a)*0.15});
      if(j%2===0) particle(player.dimension,BURST,{x:hit.x+Math.cos(a)*0.9,y:hit.y,z:hit.z+Math.sin(a)*0.9});
    }
    emit(player.dimension,hit,BLOOD,6);
  },BURST);
  sound(player.dimension,'mob.blaze.shoot',player.location,{volume:.5,pitch:1.6});
  notify(player,'§c혈인: 원거리 혈원반');return true;
}
export function bloodAwakenIsActive(p){return bursts.has(p.id);}
export function bloodAwakenStop(p){
  if(!bursts.delete(p.id))return false;
  for(const effect of ['strength','resistance','hunger','wither'])try{p.removeEffect(effect);}catch{}
  notify(p,'§7혁린약동•재 해제');return true;
}
function awaken(player,job,def){
  if(bursts.has(player.id)){bloodAwakenStop(player);return false;}
  bursts.set(player.id,{start:system.currentTick,def});
  applyStatus(player,'regeneration',1200,{amplifier:1,showParticles:false});
  notify(player,'§c혁린약동•재 활성화! §7다시 사용하면 해제합니다.');
  return true;
}
function bloodBind(player,job,def){
  const dim=player.dimension, targets=getTargets(player,player.location,def.radius).filter(e=>enemy(player,e));
  let total=0,drained=0;
  for(const e of targets){
    const before=e.getComponent('minecraft:health')?.currentValue??0;
    hurt(e,player,def.damage);
    const after=e.getComponent('minecraft:health')?.currentValue??0;
    drained+=Math.min(before,Math.max(0,before-after));
    const anchor={...e.location};
    pinned.set(e.id,{entity:e,owner:player,anchor,until:system.currentTick+ccTicks(e,def.duration),dimensionId:dim.id});
    try{applyStatus(e,'slowness',def.duration,{amplifier:255,showParticles:true});}catch{}
    for(let j=0;j<14;j++){
      const angle=j*Math.PI*2/14;
      particle(dim,SIGIL,{x:anchor.x+Math.cos(angle)*.7,y:anchor.y+.5+(j%3)*.4,z:anchor.z+Math.sin(angle)*.7});
    }
    total++;
  }
  if(!total){notify(player,'§716블럭 안에 묶을 대상이 없습니다.');return false;}
  const hp=player.getComponent('minecraft:health');if(hp?.currentValue>0)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+Math.min(def.healCap,drained)));
  sound(dim,'mob.endermen.portal',player.location,{volume:.8,pitch:.6});
  notify(player,`§c적박: §f${total}마리 5초 결박 · 최대 6하트 흡혈`);return true;
}
// Blood whips sweep around the caster for three seconds. Each enemy is hit once.
const tentacles=new Map();
export function bloodTentacle(p,job,def){
 if(tentacles.has(p.id))return false;
 const session={player:p,dimension:p.dimension.id,start:system.currentTick,until:system.currentTick+def.duration,hit:new Set(),def};
 tentacles.set(p.id,session);sound(p.dimension,'mob.slime.attack',p.location,{volume:.9,pitch:.6});return true;
}
export function tickBloodTentacles(){
 for(const [id,s]of tentacles){
  const p=s.player;if(!valid(p)||p.dimension.id!==s.dimension||system.currentTick>=s.until||(getJobId(p)!=='blood_mage'&&!(getJobId(p)==='chameleon'&&getSkills(p).includes('blood_tentacle')))){tentacles.delete(id);continue;}
  const spin=(system.currentTick-s.start)/s.def.duration*Math.PI*2,origin={x:p.location.x,y:p.location.y+1,z:p.location.z};
  for(let arm=0;arm<4;arm++){
   const angle=spin+arm*Math.PI/2;
   for(let step=1;step<=12;step++){const radius=step*s.def.radius/12,curve=Math.sin(step*.65-spin*2)*.12,at={x:origin.x+Math.cos(angle+curve)*radius,y:origin.y+Math.sin(step*.55+spin)*.5,z:origin.z+Math.sin(angle+curve)*radius};if(isSolidAt(p.dimension,at))break;particle(p.dimension,'rpg:blood_tentacle_whip',at);}
  }
  for(const e of getTargets(p,p.location,s.def.radius).filter(e=>enemy(p,e))){
   if(s.hit.has(e.id))continue;
   const dx=e.location.x-p.location.x,dz=e.location.z-p.location.z,angle=Math.atan2(dz,dx);
   let touching=Math.hypot(dx,dz)<=2;
   for(let arm=0;arm<4&&!touching;arm++){const diff=angle-(spin+arm*Math.PI/2);touching=Math.abs(Math.atan2(Math.sin(diff),Math.cos(diff)))<.4;}
   if(!touching)continue;
   const target=pos(e,.8),distance=Math.hypot(target.x-origin.x,target.y-origin.y,target.z-origin.z);
   let blocked=false;for(let t=1;t<distance;t++){const scale=t/distance;if(isSolidAt(p.dimension,{x:origin.x+(target.x-origin.x)*scale,y:origin.y+(target.y-origin.y)*scale,z:origin.z+(target.z-origin.z)*scale})){blocked=true;break;}}
   if(blocked)continue;
   if(hurt(e,p,s.def.damage,'magic')){s.hit.add(e.id);emit(p.dimension,target,BURST,5);}
  }
 }
}
export const RUNNERS={
  blood_spear:spear,
  blood_tentacle:bloodTentacle,
  blood_orb:orb,
  blood_supernova:supernova,
  blood_mark:bloodMark,
  blood_awaken:awaken,
  blood_bind:bloodBind,
};

const reachTicks=new Map();
export function useBloodSpear(p){
 if((reachTicks.get(p.id)??-100)>system.currentTick-10)return;
 const eq=p.getComponent('minecraft:equippable'),weapon=eq?.getEquipment(EquipmentSlot.Mainhand);
 if(weapon?.typeId!==SPEAR)return;
 if(Number(weapon.getDynamicProperty('rpg:spear_hits')??0)>=SKILLS.blood_spear.durability){eq.setEquipment(EquipmentSlot.Mainhand,undefined);return;}
 const target=firstTargetInView(p,SKILLS.blood_spear.range);if(!target||!enemy(p,target))return;
 reachTicks.set(p.id,system.currentTick);
 if(!hurtBase(target,p,SKILLS.blood_spear.damage,'magic',{strengthIncluded:true,ignoreInvulnerability:true}))return;
 applyStatus(target,'wither',60,{amplifier:0,showParticles:true});trace(p.dimension,headPos(p),pos(target),SIGIL,.3);
 const hits=Number(weapon.getDynamicProperty('rpg:spear_hits')??0)+1;
 if(hits>=SKILLS.blood_spear.durability)eq.setEquipment(EquipmentSlot.Mainhand,undefined);
 else{weapon.setDynamicProperty('rpg:spear_hits',hits);const durability=weapon.getComponent('minecraft:durability');if(durability)durability.damage=Math.min(hits,4);weapon.setLore(['§c피의 창§r','§7사용: 6칸 찌르기 · 마법 피해 14',`§7남은 사용 횟수: ${Math.max(0,SKILLS.blood_spear.durability-hits)}/5`]);eq.setEquipment(EquipmentSlot.Mainhand,weapon);}
}
system.beforeEvents.startup.subscribe(e=>{try{e.itemComponentRegistry.registerCustomComponent('rpg:blood_spear_reach',{onUse(ev){system.run(()=>useBloodSpear(ev.source));}});}catch(error){console.warn('[RPG blood reach] '+error);}});
export function registerBloodMagic(){
  if(installed)return;installed=true;
  system.runInterval(tickBloodTentacles,3);
  world.afterEvents.entityHitEntity.subscribe(event=>{
    const p=event.damagingEntity;
    if(p?.typeId!=='minecraft:player'||!event.hitEntity)return;
    try{
      const eq=p.getComponent('minecraft:equippable');
      const weapon=eq?.getEquipment(EquipmentSlot.Mainhand);
      if(weapon?.typeId!==SPEAR)return;
 if(Number(weapon.getDynamicProperty('rpg:spear_hits')??0)>=SKILLS.blood_spear.durability){eq.setEquipment(EquipmentSlot.Mainhand,undefined);return;}
      if(enemy(p,event.hitEntity)){
        const key=spearKey(p,event.hitEntity),nativeTick=spearNativeReplaced.get(key);spearNativeReplaced.delete(key);
        // Rejected vanilla hits still emit entityHitEntity: explicitly bypass immunity.
        if(nativeTick!==system.currentTick)hurtBase(event.hitEntity,p,SKILLS.blood_spear.damage,'magic',{strengthIncluded:true,ignoreInvulnerability:true});
        applyStatus(event.hitEntity,'wither',60,{amplifier:0,showParticles:true});
      }
      const hits=Number(weapon.getDynamicProperty('rpg:spear_hits')??0)+1;
      if(hits>=SKILLS.blood_spear.durability){eq.setEquipment(EquipmentSlot.Mainhand,undefined);notify(p,'§7피의 창이 소멸했습니다.');}
      else{
        weapon.setDynamicProperty('rpg:spear_hits',hits);
        const d=weapon.getComponent('minecraft:durability');
        if(d)d.damage=Math.min(hits,4);
        weapon.setLore(['§c피의 창§r','§7기본 마법 피해 14 · 시듦 I 3초',`§7남은 사용 횟수: ${Math.max(0,SKILLS.blood_spear.durability-hits)}/5`]);
        eq.setEquipment(EquipmentSlot.Mainhand,weapon);
      }
    }catch{}
  });
  system.runInterval(()=>{
    const now=system.currentTick;
    for(const [id,s] of bursts){
      const p=world.getAllPlayers().find(x=>x.id===id);
      if(!p || (getJobId(p)!=='blood_mage' && !(getJobId(p)==='chameleon' && getSkills(p).includes('blood_awaken')))){bursts.delete(id);continue;}
      try{
        for(const [name,level] of [['strength',2],['resistance',2],['hunger',2]])applyStatus(p,name,35,{amplifier:level,showParticles:false});
        if(now-s.start>=s.def.warningTicks){applyStatus(p,'wither',35,{amplifier:4,showParticles:false});}
      }catch{bursts.delete(id);}
    }
    for(const [id,s] of pinned){
      if(now>=s.until || !valid(s.entity) || areAllies(s.owner,s.entity)){
        if(areAllies(s.owner,s.entity)) try{s.entity.removeEffect('slowness');}catch{}
        pinned.delete(id);continue;
      }
      try{
        if(s.entity.dimension.id!==s.dimensionId){pinned.delete(id);continue;}
        const here=s.entity.location;
        if(dist3(here,s.anchor)>.35)s.entity.teleport(s.anchor,{dimension:s.entity.dimension,keepVelocity:false});
        if(now%10===0)emit(s.entity.dimension,pos(s.entity,1),SIGIL,4);
      }catch{pinned.delete(id);}
    }
  },5);
  world.afterEvents.playerLeave.subscribe(ev=>{bursts.delete(ev.playerId);reachTicks.delete(ev.playerId);tentacles.delete(ev.playerId);});
  world.afterEvents.entityDie.subscribe(ev=>{if(ev.deadEntity?.typeId==='minecraft:player')bursts.delete(ev.deadEntity.id);});
}

// Borrowed spells use MAG just like their original spell class.
function hurt(target,source,amount,type="magic"){return hurtBase(target,source,amount,type);}
