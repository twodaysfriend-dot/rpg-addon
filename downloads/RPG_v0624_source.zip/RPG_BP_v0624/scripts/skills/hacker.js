import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import { areAllies } from "../core/social.js";
import { world, system } from '@minecraft/server';
import { CONFIG } from '../config.js';
import { getLastHit } from '../core/tracking.js';
import { getTargets, hurt as hurtBase, particle, sound, dist3 } from '../core/util.js';
import { notify } from '../core/hud.js';
import { getJobId, getSkills, resetNonUltimateCooldowns } from '../core/playerData.js';
import { SKILLS } from '../data/skills.js';
import { JOBS } from '../data/jobs.js';
import { RUNNERS as swordRunners } from './sword.js';
import { RUNNERS as fistRunners } from './fist.js';
import { RUNNERS as archerRunners } from './archer.js';
import { RUNNERS as mageRunners } from './mage.js';
import { RUNNERS as holyRunners } from './holy.js';
import { RUNNERS as berserkerRunners } from './berserker.js';
import { RUNNERS as bloodRunners } from './blood.js';
import {isUltimate} from '../core/chameleonProgress.js';
import {RUNNERS as harpoonRunners} from './harpoon.js';
import {RUNNERS as frostRunners} from './frost.js';
import {RUNNERS as fireRunners} from './fire.js';
import {RUNNERS as assassinRunners} from './assassin.js';
import {RUNNERS as technomancerRunners} from './technomancer.js';
import {RUNNERS as demonRunners} from './demon.js';
import {RUNNERS as celestialRunners} from './celestial.js';
import {RUNNERS as dragonRunners} from './dragon.js';
import {RUNNERS as necroRunners} from './necro.js';
import {RUNNERS as darkRunners} from './dark.js';
const copied={...swordRunners,...fistRunners,...archerRunners,...mageRunners,...holyRunners,...berserkerRunners,...bloodRunners,...harpoonRunners,...frostRunners,...fireRunners,...assassinRunners,...technomancerRunners,...demonRunners,...celestialRunners,...dragonRunners,...necroRunners,...darkRunners};
const stealth=new Map();
const allySaturation = new Map(); // ally id -> { entity, expires }
const FX_HEX='rpg:hacker_hex';
const FX_GLITCH='rpg:hacker_glitch';
const FX_EMP='rpg:hacker_emp_arc';
const FX_DATA='rpg:hacker_dummy_data';
function emit(dim,id,loc,n=1){ for(let i=0;i<n;i++) particle(dim,id,{x:loc.x+((i%3)-1)*0.14,y:loc.y+((i*2)%5)*0.10,z:loc.z+((i%5)-2)*0.14}); }
function line(dim,a,b,id,step=.6){ const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z; const total=Math.hypot(dx,dy,dz)||0.001; const n=Math.min(64,Math.max(1,Math.ceil(total/step))); for(let i=0;i<=n;i++){ const t=i/n; particle(dim,id,{x:a.x+dx*t,y:a.y+dy*t,z:a.z+dz*t}); } }
function ally(p,e){return areAllies(p,e);}
function valid(e){try{return e?.isValid && (e.getComponent('minecraft:health')?.currentValue??0)>0;}catch{return false;}}
function effect(e,name,ticks,amp){try{applyStatus(e,name,ticks,{amplifier:amp,showParticles:false});}catch{}}
function hacking(p,job,def,hitTarget){
  // 길드·파티·팀 아군을 직접 좌클릭하면 해킹 대신 지원 버프.
  if (hitTarget) {
    if (hitTarget.typeId !== "minecraft:player" || hitTarget.id === p.id ||
        !valid(hitTarget) || !ally(p,hitTarget) ||
        hitTarget.dimension.id !== p.dimension.id ||
        dist3(hitTarget.location,p.location) > 8) return false;
    effect(hitTarget,'resistance',400,2); // 저항 III / 20초
    effect(hitTarget,'regeneration',400,2); // 재생 III / 20초
    // 포화는 즉시형 효과여서 20초 동안 짧게 반복 적용합니다.
    effect(hitTarget,'saturation',20,0);
    allySaturation.set(hitTarget.id,{entity:hitTarget,expires:system.currentTick+400});
    const to={x:hitTarget.location.x,y:hitTarget.location.y+1.2,z:hitTarget.location.z};
    emit(p.dimension,FX_HEX,to,3);
    sound(p.dimension,'random.orb',hitTarget.location,{volume:.7,pitch:1.2});
    notify(p,`§b${hitTarget.name} 지원 해킹: §f저항 III · 포화 · 재생 III (20초)`);
    try {hitTarget.sendMessage(`§b${p.name}의 해킹 지원: §f저항 III · 포화 · 재생 III (20초)`);}catch{}
    return true;
  }
  const e=getLastHit(p);
  if(!valid(e)||ally(p,e)||e.dimension.id!==p.dimension.id||dist3(e.location,p.location)>def.range){notify(p,'§7최근 타격한 적이 사정거리 안에 없습니다.');return false;}
  effect(e,'weakness',60,3);effect(e,'slowness',60,2);effect(e,'blindness',60,0);
  const from={x:p.location.x,y:p.location.y+1.05,z:p.location.z};
  const to={x:e.location.x,y:e.location.y+1.0,z:e.location.z};
  line(p.dimension,from,to,FX_GLITCH,0.82);
  for(let i=0;i<10;i++){
    const a=i*Math.PI*2/10;
    particle(p.dimension,FX_HEX,{x:to.x+Math.cos(a)*0.8,y:to.y+Math.sin(a*2)*0.12,z:to.z+Math.sin(a)*0.8});
  }
  emit(p.dimension,FX_GLITCH,to,3);
  sound(p.dimension,'mob.endermen.portal',e.location,{volume:.6,pitch:1.2});
  notify(p,'§d해킹 성공');
  return true;
}
// 더미데이터: 목표를 탐색해 작은 데이터 패킷을 자동 유도한다.
// 시야 앞의 적을 우선하고, 없으면 가장 가까운 적을 추적한다.
// 광역 공격이 아닌 단일 타격이며 길드·파티·팀 아군은 항상 제외한다.
function dummyData(p,job,def){
  const origin={...p.location};
  const dim=p.dimension;
  const candidates=getTargets(p,origin,def.range).filter(e=>valid(e)&&!ally(p,e));
  if(!candidates.length){notify(p,'§7더미데이터: 추적할 적이 사거리 안에 없습니다.');return false;}
  const look=p.getViewDirection();
  let selected=null,score=-Infinity;
  for(const e of candidates){
    const loc=e.location;
    const dx=loc.x-origin.x, dy=loc.y+1-origin.y-1.4, dz=loc.z-origin.z;
    const distance=Math.hypot(dx,dy,dz)||0.001;
    const aim=(dx*look.x+dy*look.y+dz*look.z)/distance;
    const ranking=(aim>0.3?12+aim*4:0)-distance*0.2;
    if(ranking>score){score=ranking;selected=e;}
  }
  if(!selected)return false;
  let point={x:origin.x+look.x*0.6,y:origin.y+1.4+look.y*0.6,z:origin.z+look.z*0.6};
  let elapsed=0;
  sound(dim,'random.orb',point,{volume:0.65,pitch:1.6});
  particle(dim,FX_DATA,point);
  const handle=system.runInterval(()=>{
    try{
      if(!p.isValid||p.dimension.id!==dim.id||!valid(selected)||selected.dimension.id!==dim.id||
         ally(p,selected)||(!CONFIG.pvp&&selected.typeId==='minecraft:player')||++elapsed>def.lifetime){
        system.clearRun(handle);return;
      }
      const loc=selected.location;
      const to={x:loc.x,y:loc.y+1,z:loc.z};
      const dx=to.x-point.x,dy=to.y-point.y,dz=to.z-point.z;
      const distance=Math.hypot(dx,dy,dz);
      if(distance<=def.hitRadius){
        if(hurt(selected,p,def.damage,'magic')){
          emit(dim,FX_GLITCH,to,4);
          emit(dim,FX_DATA,to,2);
          sound(dim,'random.orb',to,{volume:.7,pitch:.8});
        }
        system.clearRun(handle);return;
      }
      const step=Math.min(distance,def.speed);
      point={x:point.x+dx/distance*step,y:point.y+dy/distance*step,z:point.z+dz/distance*step};
      particle(dim,FX_DATA,point);
      if(elapsed%3===0)particle(dim,FX_GLITCH,{x:point.x,y:point.y-.12,z:point.z});
      if(distance-step<=def.hitRadius){
        if(hurt(selected,p,def.damage,'magic')){
          emit(dim,FX_GLITCH,to,4);
          emit(dim,FX_DATA,to,2);
          sound(dim,'random.orb',to,{volume:.7,pitch:.8});
        }
        system.clearRun(handle);
      }
    }catch{system.clearRun(handle);}
  },1);
  return true;
}
function reboot(p,job,def){
  const candidates=world.getAllPlayers().filter(e=>e.dimension.id===p.dimension.id && dist3(e.location,p.location)<=def.radius && ally(p,e));
  for(const e of candidates)resetNonUltimateCooldowns(e);
  notify(p,`§d시스템 재부팅: §f${candidates.length}명 일반 스킬 쿨타임 초기화`);
  return true;
}
export function isHackerStealthActive(p){return stealth.has(p.id);}
export function stopHackerStealth(p){
  if(!stealth.delete(p.id))return false;
  for(const name of ['invisibility','speed','hunger'])try{p.removeEffect(name);}catch{}
  notify(p,'§7은신 해제');return true;
}
function cloak(p,job,def){
  if(stealth.has(p.id)){stopHackerStealth(p);return false;}
  stealth.set(p.id,true);notify(p,'§5은신 활성화');return true;
}
// Registered damage/control ultimates are discovered from live skill and job metadata.
// Pure self buffs are excluded; mixed damage + buff ultimates remain eligible.
export function copyUltimatePool(){
 return Object.values(SKILLS).filter(skill=>isUltimate(skill.id)&&!skill.buffOnlyUltimate).flatMap(skill=>{
   const owner=Object.values(JOBS).filter(j=>!j.placeholder&&j.id!=='chameleon'&&j.skills?.includes(skill.id)).sort((a,b)=>(b.tier??0)-(a.tier??0))[0];
   return owner&&(skill.id==='hacker_emp'||copied[skill.id])?[[skill.id,owner.id]]:[];
 });
}

function copy(p,job,def){
  // Fisher-Yates: 실제 실행 가능한 궁극기를 무작위 순서로 시도.
  const order=copyUltimatePool();
  for(let i=order.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [order[i],order[j]]=[order[j],order[i]];
  }
  for(const [skillId,jobId] of order){
    const runner=skillId==='hacker_emp'?emp:copied[skillId];
    const skill=SKILLS[skillId], targetJob=JOBS[jobId];
    if(!runner||!skill||!targetJob)continue;
    try{
      if(runner(p,targetJob,{...skill,copied:true})!==false){
        notify(p,`§d카피 발동: §f${targetJob.name} - ${skill.name}`);
        return true;
      }
    }catch{}
  }
  notify(p,'§7현재 복제할 수 있는 궁극기가 없습니다.');
  return false;
}
// 디도스: 캐릭터를 중심으로 반경 10블럭의 적만 타격한다.
// 길드·파티·팀 아군과 시전자 자신은 getTargets + hurt에서 이중으로 차단된다.
function ddos(p,job,def){
  const origin={...p.location};
  const targets=getTargets(p,origin,def.radius);
  let count=0;
  sound(p.dimension,'mob.endermen.portal',origin,{volume:.65,pitch:1.65});
  for(const e of targets){
    if(!valid(e)||ally(p,e))continue;
    if(!hurt(e,p,def.damage,'magic'))continue;
    count++;
    const pos={x:e.location.x,y:e.location.y+1,z:e.location.z};
    emit(p.dimension,FX_GLITCH,pos,2);
    emit(p.dimension,FX_HEX,pos,2);
    // 사슬 같은 작은 전기 신호가 해커와 목표 사이를 연결하는 효과.
    line(p.dimension,{x:origin.x,y:origin.y+1.3,z:origin.z},pos,FX_EMP,1.2);
  }
  emit(p.dimension,FX_HEX,{x:origin.x,y:origin.y+1.25,z:origin.z},4);
  notify(p,`§b디도스: §f주변 적 ${count}명 해킹 피해 ${def.damage}`);
  return true;
}
function emp(p,job,def){
  const origin={...p.location}, dim=p.dimension, expires=system.currentTick+def.duration;
  const blessed = new Set();
  sound(dim,'mob.endermen.portal',origin,{volume:1,pitch:.4});
  const ticker=system.runInterval(()=>{
    if(!p.isValid||system.currentTick>=expires){system.clearRun(ticker);return;}
    try{
      // EMP의 아군 효과: 길드·파티·기존 팀 태그를 공유하는 사람.
      // 원 안으로 새로 들어온 아군에게도 단 한 번 20초 강화 효과를 줍니다.
      for(const friend of world.getAllPlayers()){
        if(!friend.isValid || friend.dimension.id!==dim.id || blessed.has(friend.id)) continue;
        if(!ally(p,friend) || dist3(friend.location,origin)>def.radius) continue;
        blessed.add(friend.id);
        effect(friend,'regeneration',400,2); // 재생 III / 20초
        effect(friend,'resistance',400,2); // 저항 III / 20초
        emit(dim, FX_HEX, {x:friend.location.x,y:friend.location.y+1.1,z:friend.location.z}, 2);
      }
      for(const e of getTargets(p,origin,def.radius)){
        if(ally(p,e)||!valid(e))continue;
        effect(e,'weakness',35,3);effect(e,'slowness',35,2);effect(e,'blindness',35,0);
        if(system.currentTick%20===0) emit(dim, FX_GLITCH, {x:e.location.x,y:e.location.y+1.0,z:e.location.z}, 2);
      }
      for(let i=0;i<32;i++){
        const theta=i*Math.PI*2/32;
        const ring={x:origin.x+def.radius*Math.cos(theta),y:origin.y+1.0,z:origin.z+def.radius*Math.sin(theta)};
        particle(dim, i%2===0?FX_HEX:FX_EMP, ring);
      }
      for(let i=0;i<6;i++){
        const theta=(system.currentTick*0.12)+(i*Math.PI*2/6);
        particle(dim, FX_GLITCH, {x:origin.x+Math.cos(theta)*(def.radius*0.55),y:origin.y+1.2+(i%2)*0.4,z:origin.z+Math.sin(theta)*(def.radius*0.55)});
      }
    }catch{system.clearRun(ticker);}
  },10);
  notify(p,'§5EMP: §f적은 5초간 해킹, 아군은 재생 III·저항 III 20초');return true;
}
export const RUNNERS={hacker_hack:hacking,hacker_dummy_data:dummyData,hacker_reboot:reboot,hacker_stealth:cloak,hacker_copy:copy,hacker_ddos:ddos,hacker_emp:emp};
export function registerHacker(){
  system.runInterval(()=>{
    const now=system.currentTick;
    for(const [id,entry] of allySaturation){
      try {
        if(now>=entry.expires || !valid(entry.entity)) {allySaturation.delete(id);continue;}
        effect(entry.entity,'saturation',15,0);
      } catch { allySaturation.delete(id); }
    }
    for(const id of stealth.keys()){
      const p=world.getAllPlayers().find(e=>e.id===id);
      if(!p || (getJobId(p)!=='hacker' && !(getJobId(p)==='chameleon' && getSkills(p).includes('hacker_stealth')))){stealth.delete(id);continue;}
      try{
        const hunger=p.getComponent('minecraft:player.hunger')?.currentValue;
        if(typeof hunger==='number'&&hunger<=6){stopHackerStealth(p);continue;}
        effect(p,'invisibility',35,0);effect(p,'speed',35,3);effect(p,'hunger',35,1);
      }catch{stealth.delete(id);}
    }
  },10);
  world.afterEvents.playerLeave.subscribe(ev=>{stealth.delete(ev.playerId);allySaturation.delete(ev.playerId);});
}

// Borrowed spells use MAG just like their original spell class.
function hurt(target,source,amount,type="magic"){return hurtBase(target,source,amount,type);}
