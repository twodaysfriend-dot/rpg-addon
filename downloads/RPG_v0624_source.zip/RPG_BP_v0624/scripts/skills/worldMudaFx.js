import {flatDir,isSolidAt,particle} from '../core/util.js';
// Cosmetic only; the existing barrage owns timing, targets and damage.
export function worldMudaFx(p,def,index){
 const d=flatDir(p),side={x:-d.z,z:d.x},l=p.location;
 for(let n=0;n<6;n++){
  const lane=(n-2.5)*.43,forward=.9+((n+index)%4)*.68,height=.65+((n*3+index)%5)*.29;
  const at={x:l.x+d.x*forward+side.x*lane,y:l.y+height,z:l.z+d.z*forward+side.z*lane};
  // Do not draw fists through walls, including a wall between caster and particle.
  let blocked=false;
  for(let t=.25;t<=1;t+=.25)if(isSolidAt(p.dimension,{x:l.x+(at.x-l.x)*t,y:l.y+1+(height-1)*t,z:l.z+(at.z-l.z)*t})){blocked=true;break;}
  if(!blocked)particle(p.dimension,n%2?'rpg:world_muda_left':'rpg:world_muda_right',at);
 }
}
