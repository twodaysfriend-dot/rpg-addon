export const XP_POTION='rpg:xp_boost_potion';
export const XP_BOOST_KEY='rpg:xp_boost_until';
export const XP_BOOST_MS=10*60*1000;
export function xpBoostRemaining(p,now=Date.now()){
 const until=p.getDynamicProperty(XP_BOOST_KEY);
 return typeof until==='number'&&Number.isFinite(until)?Math.max(0,until-now):0;
}
export const BASE_XP_MULTIPLIER=2; // 기본 경험치 지급량 2배 (경험치 포션 ×2.5와 곱연산)
export function rpgXpMultiplier(p){return BASE_XP_MULTIPLIER*(xpBoostRemaining(p)>0?2.5:1);}
export function activateXpBoost(p){p.setDynamicProperty(XP_BOOST_KEY,Date.now()+XP_BOOST_MS);p.sendMessage('§b[RPG] 경험치 포션: 10분 동안 획득 RPG 경험치 ×2.5! 재사용 시 지속시간이 10분으로 갱신됩니다.');}
