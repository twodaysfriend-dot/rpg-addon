import { world, system, EquipmentSlot } from "@minecraft/server";

// The fist items use an invisible attachable in all perspectives.
// Only world-space black/red particles show to other players when equipped.
const FX_FOR = {
  "rpg:fighter_fist": "rpg:fist_black_aura",
  "rpg:fist_bone_fist": "rpg:fist_red_aura",
};
const fxCounter = new Map();
function heldId(player) {
  try {
    return player.getComponent("minecraft:equippable")?.getEquipment(EquipmentSlot.Mainhand)?.typeId;
  } catch { return undefined; }
}
export function getFistCoatingStatus(player) {
  const type = heldId(player);
  if (!type) return "§7주손 아이템을 확인할 수 없습니다.";
  const effect = FX_FOR[type];
  if (!effect) return `§e주손: ${type} §7(전용 오라 미적용)`;
  return `§a주손: ${type} §7/ 모델 숨김 / 오라: §f${effect}`;
}
export function registerFistCoating() {
  system.runInterval(() => {
    const active = new Set();
    for (const p of world.getAllPlayers()) {
      try {
        const id = heldId(p);
        const effect = FX_FOR[id];
        if (!effect) continue;
        active.add(p.id);
        const phase = (fxCounter.get(p.id) ?? 0) + 1;
        fxCounter.set(p.id, phase);
        const yaw = p.getRotation().y * Math.PI / 180;
        const sx = Math.cos(yaw), sz = Math.sin(yaw);
        const fx = -Math.sin(yaw), fz = Math.cos(yaw);
        const foot = p.location;
        for (const side of [-1, 1]) {
          // Wrist particles at either side of the body; slight movement gives flickering aura.
          const jitter = (phase % 3 - 1) * 0.045;
          const crouch = p.isSneaking ? -0.13 : 0;
          for (let n = 0; n < 2; n++) {
            const pos = {
              x: foot.x + sx * side * (0.32 + n*0.06) + fx * (0.10 + jitter),
              y: foot.y + 0.78 + n * 0.13 + crouch + (phase % 2) * 0.04,
              z: foot.z + sz * side * (0.32 + n*0.06) + fz * (0.10 + jitter),
            };
            p.dimension.spawnParticle(effect, pos);
          }
        }
      } catch { /* Chunk/teleport/unload: skip this frame. */ }
    }
    for (const id of fxCounter.keys()) if (!active.has(id)) fxCounter.delete(id);
  }, 6);
  world.afterEvents.playerLeave.subscribe((ev) => fxCounter.delete(ev.playerId));
}
