import {world} from '@minecraft/server';
import {TEMPLE_KEY,altarPosition,celestialPhase} from '../data/temple.js';
export function readTemple(){
 try{
  const raw=world.getDynamicProperty(TEMPLE_KEY);if(typeof raw!=='string')return undefined;
  const state=JSON.parse(raw);if(state.version!==1||!state.temple)return undefined;const t=state.temple;
  if(t.dimId!=='minecraft:overworld'||!['x','y','z'].every(k=>Number.isSafeInteger(t[k]))||!['scan','build','verify','ready','error'].includes(t.status))return undefined;
  return t;
 }catch{return undefined;}
}
export function saveTemple(t){world.setDynamicProperty(TEMPLE_KEY,t?JSON.stringify({version:1,temple:t}):undefined);}
export function templeRequirement(p,kind){
 const t=readTemple(),active=celestialPhase(world.getTimeOfDay()),label=kind==='sun'?'해의 신전':'달의 신전';
 if(!t||t.status!=='ready')return {met:false,label:`${label} 미생성 또는 공사 중 · 관리자 /rpg:templecreate`};
 const at=altarPosition(t,kind),near=p.dimension?.id===t.dimId&&Math.hypot(p.location.x-at.x,p.location.z-at.z)<=4&&Math.abs(p.location.y-at.y)<=4;
 let intact=!near;try{if(near){const dim=world.getDimension(t.dimId),base=dim.getBlock({x:at.x,y:at.y-1,z:at.z}),top=dim.getBlock(at);intact=base?.typeId===(kind==='sun'?'minecraft:gold_block':'minecraft:amethyst_block')&&[kind==='sun'?'minecraft:gold_block':'minecraft:amethyst_block','minecraft:sea_lantern'].includes(top?.typeId);}}catch{}
 return {met:near&&active===kind&&intact,label:`${label} 제단 ${at.x}, ${at.y}, ${at.z} · ${kind==='sun'?'낮':'밤'} 활성${!intact?' · 제단 블록 확인 필요':''}`,near,active,intact,position:at};
}
