import {DUNGEON,ceilingHeight} from '../data/dungeons.js';
import {dungeonRuns} from './dungeonState.js';
export function activeDungeonRun(player){return [...dungeonRuns.values()].find(r=>!r.finishing&&r.members.some(m=>m.id===player.id));}
export function insideDungeon(position,dimensionId,d){
 const radius=Math.hypot(position.x-d.x,position.z-d.z);
 return dimensionId===d.dimId&&radius<DUNGEON.radius-2&&position.y>d.y&&position.y<d.y+ceilingHeight(radius)-2;
}
export function teleportForSkill(player,position,options={}){
 const r=activeDungeonRun(player);
 if(r&&!insideDungeon(position,options.dimension?.id??player.dimension.id,r.d))throw Error('DungeonBoundary');
 player.teleport(position,r?{...options,checkForBlocks:true}:options);
}
