import {DUNGEON} from '../data/dungeons.js';
export function dungeonSitesOverlap(a,b){return a.dimId===b.dimId&&Math.abs(a.x-b.x)<DUNGEON.radius+(b.shape==='cave_v2'?32:21)+4&&Math.abs(a.z-b.z)<DUNGEON.radius+(b.shape==='cave_v2'?32:21)+4&&Math.abs(a.y-b.y)<DUNGEON.height+4;}
// Keep individual tier creation on the same grid as /dungeoncreate all.
// Earlier releases used slot 0 for EVERY single-tier request.
export function newDungeonSite(p,tier,registered){
 const existing=registered.filter(d=>d.dimId===p.dimension.id&&d.shape==='cave_v2'&&Number.isInteger(d.tier)).sort((a,b)=>a.tier-b.tier)[0];
 const spacing=DUNGEON.buildSpacing,first=existing?existing.tier-1:0;
 const origin=existing?{x:existing.x-first%5*spacing,y:existing.y,z:existing.z-Math.floor(first/5)*spacing}:{x:Math.floor(p.location.x),y:Math.min(276,Math.max(80,Math.floor(p.location.y)+64)),z:Math.floor(p.location.z)};
 for(let offset=0;offset<200;offset++){
  const slot=tier.tier-1+offset,site={id:tier.id,tier:tier.tier,shape:'cave_v2',dimId:p.dimension.id,x:origin.x+slot%5*spacing,y:origin.y,z:origin.z+Math.floor(slot/5)*spacing,status:'queued'};
  if(!registered.some(d=>dungeonSitesOverlap(site,d)))return site;
 }
 throw Error('던전이 겹치지 않는 빈 등록 위치를 찾지 못했습니다.');
}
