import { world, system } from "@minecraft/server";
import { notify } from "./hud.js";
import {awardPartyTrialKill} from './combatContribution.js';

// Entity training dummy: 3000 native HP. Every kind of entity damage counts.
// Players can spawn it with rpg:sandbag_spawner; old placed blocks are converted
// to entities when struck, so existing worlds are not silently damaged.
const DUMMY_ID="rpg:sandbag_entity";
const LEGACY_BLOCK="rpg:sandbag";
const lastDummyAttacker=new Map(); // dummyId -> player id (for projectile/script kills)
const lastHud=new Map();
export function registerSandbag(){
  world.afterEvents.entityHurt.subscribe(ev=>{
    try{
      const dummy=ev.hurtEntity;
      if(dummy.typeId!==DUMMY_ID)return;
      const damager=ev.damageSource?.damagingEntity;
      const projectile=ev.damageSource?.damagingProjectile;
      const player=damager?.typeId==="minecraft:player" ? damager : projectile?.getComponent("minecraft:projectile")?.owner;
      if(player?.typeId!=="minecraft:player")return;
      lastDummyAttacker.set(dummy.id,player.id);
      const hp=dummy.getComponent("minecraft:health")?.currentValue??0;
      const now=system.currentTick;
      if(now-(lastHud.get(player.id)||-100)>=15){
        lastHud.set(player.id,now);
        notify(player,`§e샌드백 §f${Math.ceil(hp)} / 3000 HP`);
      }
    }catch{}
  });
  world.afterEvents.entityDie.subscribe(ev=>{
    try{
      if(ev.deadEntity.typeId!==DUMMY_ID)return;
      const killer=ev.damageSource?.damagingEntity;
      const pid=killer?.typeId==="minecraft:player" ? killer.id : lastDummyAttacker.get(ev.deadEntity.id);
      lastDummyAttacker.delete(ev.deadEntity.id);
      const p=world.getAllPlayers().find(x=>x.id===pid);
      if(p){awardPartyTrialKill(p,ev.deadEntity);notify(p,'§a훈련용 샌드백 파괴! /rpg:jobs');}
    }catch{}
  });
  world.afterEvents.playerLeave.subscribe(ev=>lastHud.delete(ev.playerId));

  // The old sandbag BLOCK is still registered solely for backwards compatibility.
  // The first punch replaces it with the new damageable ENTITY.
  // Guard against builds where this before-event is unavailable.
  world.beforeEvents.playerBreakBlock?.subscribe(ev=>{
    try{if(ev.block?.typeId===LEGACY_BLOCK)ev.cancel=true;}catch{}
  });
  world.afterEvents.entityHitBlock.subscribe(ev=>{
    const block=ev.hitBlock;
    if(block?.typeId!==LEGACY_BLOCK || ev.damagingEntity?.typeId!=="minecraft:player")return;
    const dim=block.dimension,loc={...block.location};
    system.run(()=>{
      try{
        if(dim.getBlock(loc)?.typeId!==LEGACY_BLOCK)return;
        const spawn={x:loc.x+0.5,y:loc.y,z:loc.z+0.5};
        dim.getBlock(loc)?.setType("minecraft:air");
        try { dim.spawnEntity(DUMMY_ID,spawn); }
        catch (spawnError) {
          // Do not destroy legacy worlds' sandbags if the replacement fails.
          dim.getBlock(loc)?.setType(LEGACY_BLOCK);
          throw spawnError;
        }
      }catch(e){console.warn(`[rpg] 샌드백 블록 변환 실패: ${e}`);}
    });
  });
}
