import {upgradeLevel} from '../data/upgrades.js';
import {world,system,EquipmentSlot} from '@minecraft/server';
import {itemRarity,rarityBadge} from '../data/rarity.js';
const KEY='rpg:last_grade_label';let registered=false;
export function decorateRarity(item){
 const info=itemRarity(item);if(!info)return false;
 const level=upgradeLevel(item,info.kind),label=rarityBadge(info.rank)+' '+info.name+(level?' +'+level:''),line='§8등급: '+rarityBadge(info.rank);
 const old=item.getLore(),lore=[line,...old.filter(s=>!s.startsWith('§8등급:'))];let changed=JSON.stringify(lore)!==JSON.stringify(old);
 if(changed)item.setLore(lore);
 const managed=info.kind==='rune'?undefined:item.getDynamicProperty(KEY);
 if(!item.nameTag||item.nameTag===managed){if(item.nameTag!==label){item.nameTag=label;if(info.kind!=='rune')item.setDynamicProperty(KEY,label);changed=true;}}
 return changed;
}
export function refreshRarityLabels(p){
 try{const inv=p.getComponent('minecraft:inventory')?.container;if(inv)for(let i=0;i<inv.size;i++){const item=inv.getItem(i);if(item&&decorateRarity(item))inv.setItem(i,item);}
 const eq=p.getComponent('minecraft:equippable');if(eq)for(const slot of [EquipmentSlot.Mainhand,EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet]){const item=eq.getEquipment(slot);if(item&&decorateRarity(item))eq.setEquipment(slot,item);}}catch{}
}
export function registerRarityLabels(){if(registered)return;registered=true;system.runInterval(()=>{for(const p of world.getAllPlayers())refreshRarityLabels(p);},100);world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{if(ev.player?.isValid)refreshRarityLabels(ev.player);},20));}
