import { world, system, ItemStack } from "@minecraft/server";
import * as UI from "@minecraft/server-ui";
import { isRpgAdmin } from "./adminPermissions.js";
import { ADMIN_LEVEL_MAX, getLevel, forceSetLevel, statsSummary } from "./stats.js";
import { getMana, setMana, maxManaOf, forceSetManaMax } from "./playerData.js";
import { refreshHud } from "./hud.js";

export const ADMIN_TOOL_ID = "rpg:admin_settings";
const open = new Set();
const busy = UI.FormCancelationReason?.UserBusy ?? "UserBusy";

function warn(player, msg) { try { player.sendMessage(msg); } catch {} }
function allowed(player) {
  if (isRpgAdmin(player)) return true;
  warn(player, "§c[RPG] 운영자만 관리 도구를 사용할 수 있습니다.");
  return false;
}
async function show(player, form) {
  for (let i=0; i<12; i++) {
    if (!player.isValid) return undefined;
    const result = await form.show(player);
    if (!result.canceled || result.cancelationReason !== busy) return result;
    await new Promise(resolve => system.runTimeout(resolve, 10));
  }
  warn(player, "§c[RPG] 채팅창을 닫고 관리 도구를 다시 사용하세요.");
  return undefined;
}
function positive(raw) {
  const s = String(raw ?? "").trim();
  const n = /^\d+$/.test(s) ? Number(s) : NaN;
  return Number.isSafeInteger(n) && n > 0 ? n : undefined;
}
function signed(raw) {
  const s = String(raw ?? "").trim();
  const n = /^[+-]?\d+$/.test(s) ? Number(s) : NaN;
  return Number.isSafeInteger(n) && n !== 0 ? n : undefined;
}
async function askNumber(admin, title, label, initial="1") {
  const form = new UI.ModalFormData().title(title)
    .textField(label, "숫자를 입력하세요", { defaultValue: String(initial) })
    .submitButton("적용");
  const res = await show(admin,form);
  if (!res || res.canceled) return undefined;
  return String(res.formValues?.[0] ?? "").trim();
}

export function giveAdminTool(player) {
  if (!allowed(player)) return false;
  try {
    const bag = player.getComponent("minecraft:inventory")?.container;
    if (!bag) { warn(player, "§c[RPG] 인벤토리에 접근하지 못했습니다."); return false; }
    for (let i=0; i<bag.size; i++) {
      if (bag.getItem(i)?.typeId === ADMIN_TOOL_ID) {
        warn(player, "§e[RPG] 이미 운영자 관리 도구를 가지고 있습니다. 손에 들고 우클릭하세요.");
        return true;
      }
    }
    const remaining = bag.addItem(new ItemStack(ADMIN_TOOL_ID, 1));
    if (remaining) { warn(player, "§c[RPG] 빈 인벤토리 칸이 필요합니다."); return false; }
    warn(player, "§a[RPG] 운영자 관리 도구 지급 완료! 아이템을 들고 우클릭하세요.");
    return true;
  } catch(e) { warn(player, "§c[RPG] 관리 도구 지급 실패: " + String(e)); return false; }
}

export async function openAdminTool(player) {
  if (!player?.isValid || !allowed(player) || open.has(player.id)) return;
  open.add(player.id);
  let targetId = player.id;
  try {
    for (let iteration=0; iteration<100; iteration++) {
      if (!allowed(player)) return;
      const players = world.getAllPlayers();
      const target = players.find(p=>p.id === targetId && p.isValid) ?? player;
      targetId = target.id;
      const title = "RPG 운영자 설정";
      const summary = `§e대상: §f${target.name}\n§7레벨: §a${getLevel(target)} §7| 마나: §b${getMana(target)}/${maxManaOf(target)}`;
      const menu = new UI.ActionFormData().title(title).body(summary)
        .button("§e대상 플레이어 선택")
        .button("§a레벨 지정")
        .button("§a레벨 더하기 / 빼기")
        .button("§b최대 마나 추가")
        .button("§b최대 마나 지정")
        .button("§b현재 마나 전부 회복")
        .button("§7마나 강제 설정 해제")
        .button("§e스탯 현황 확인")
        .button("닫기");
      const res = await show(player, menu);
      if (!res || res.canceled || res.selection === 8) return;
      // Re-authorize after every asynchronous form response, before any mutation.
      if (!allowed(player)) return;
      if (res.selection === 0) {
        const online = world.getAllPlayers().filter(p=>p.isValid);
        const pick = new UI.ActionFormData().title("관리 대상 선택")
          .body("온라인 플레이어 중 변경할 대상을 고르세요.");
        for (const p of online) pick.button(p.name+(p.id===player.id?" §a(본인)":""));
        pick.button("취소");
        const chosen = await show(player,pick);
        if (!chosen || chosen.canceled || chosen.selection >= online.length) continue;
        targetId = online[chosen.selection].id;
        continue;
      }
      if (res.selection === 7) { warn(player, "§e["+target.name+"]\n"+statsSummary(target)); continue; }
      if (!target.isValid) { warn(player,"§c대상이 접속을 종료했습니다."); continue; }
      let result;
      if (res.selection === 1) {
        const value = await askNumber(player,"RPG 레벨 지정","레벨 1~100000",getLevel(target));
        if (value === undefined) continue;
        if (!allowed(player) || !target.isValid) return;
        result = forceSetLevel(target,value);
        if (result.ok) {
          refreshHud(target,true);
          warn(player,`§a[RPG] ${target.name} 레벨 ${result.old} → ${result.level}${result.resetStats?" §e(초과 배분 초기화)":""}`);
        }
      } else if (res.selection === 2) {
        const value = await askNumber(player,"레벨 더하기 / 빼기","예: +10 또는 -5","10");
        if (value === undefined) continue;
        if (!allowed(player) || !target.isValid) return;
        const delta=signed(value);
        result = delta === undefined ? {ok:false,reason:"0이 아닌 정수로 입력하세요."} : forceSetLevel(target,String(getLevel(target)+delta));
        if (result.ok) { refreshHud(target,true); warn(player,`§a[RPG] ${target.name} 레벨 ${result.old} → ${result.level}`); }
      } else if (res.selection === 3) {
        const value = await askNumber(player,"최대 마나 추가","추가할 마나 (1 이상)","1000");
        if (value === undefined) continue;
        if (!allowed(player) || !target.isValid) return;
        const amount = positive(value);
        result = amount === undefined ? {ok:false,reason:"1 이상의 정수를 입력하세요."} : forceSetManaMax(target,String(maxManaOf(target)+amount));
        if (result.ok) { refreshHud(target,true); warn(player,`§b[RPG] ${target.name} 최대 마나 ${result.max} (현재 마나도 회복)`); }
      } else if (res.selection === 4) {
        const value = await askNumber(player,"최대 마나 지정","마나 1~100000",maxManaOf(target));
        if (value === undefined) continue;
        if (!allowed(player) || !target.isValid) return;
        result = forceSetManaMax(target,value);
        if (result.ok) { refreshHud(target,true); warn(player,`§b[RPG] ${target.name} 마나 ${result.current}/${result.max}`); }
      } else if (res.selection === 5) {
        setMana(target,maxManaOf(target));
        refreshHud(target,true);
        warn(player,`§b[RPG] ${target.name} 현재 마나 회복: ${getMana(target)}/${maxManaOf(target)}`);
        continue;
      } else if (res.selection === 6) {
        const confirm = new UI.MessageFormData().title("강제 마나 해제")
          .body(`${target.name}의 최대 마나를 직업/책에 따른 기본 계산값으로 되돌릴까요?`)
          .button1("취소").button2("해제");
        const answer = await show(player, confirm);
        if (!answer || answer.canceled || answer.selection !== 1) continue;
        if (!allowed(player) || !target.isValid) return;
        result = forceSetManaMax(target,"reset");
        if (result.ok) { refreshHud(target,true); warn(player,`§a[RPG] ${target.name} 최대 마나 복원: ${result.max}`); }
      }
      if (result && !result.ok) warn(player,"§c[RPG] "+result.reason);
    }
  } catch(e) {
    warn(player,"§c[RPG] 운영자 메뉴 오류: "+String(e));
    console.warn("[rpg/admin] "+String(e));
  } finally { open.delete(player.id); }
}
