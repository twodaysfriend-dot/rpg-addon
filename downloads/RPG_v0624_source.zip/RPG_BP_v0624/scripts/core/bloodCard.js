import {EquipmentSlot} from '@minecraft/server';
export const BLOOD_CARD='rpg:blood_job_card';
export function hasBloodCard(p){try{return p.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand)?.typeId===BLOOD_CARD;}catch{return false;}}
export function bloodCardRequirement(p){const met=hasBloodCard(p);return {met,have:met?1:0,need:1,label:'혈술사 전직 카드를 손에 들기'};}
