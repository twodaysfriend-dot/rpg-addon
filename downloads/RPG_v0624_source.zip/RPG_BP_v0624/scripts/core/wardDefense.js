import {world,system} from '@minecraft/server';
import {equippedRunes} from './runeInventory.js';
import {RUNES} from '../data/equipment.js';
import {upgradedRune} from '../data/upgrades.js';
const APPLIED='rpg:ward_defense_applied_v1';let registered=false;
export const WARD_REDUCTION_PER_POINT=.0035;
export function wardDefenseValue(p){let value=0;for(const r of equippedRunes(p))if(r.id==='ward')value+=upgradedRune(RUNES.ward,r.level,r.grade).defense??0;return Number(value.toFixed(1));}
export function wardDamageReduction(p){return Math.min(.8,wardDefenseValue(p)*WARD_REDUCTION_PER_POINT);}
export function applyWardDefense(p,force=false){const value=wardDefenseValue(p),index=Math.round(value*10);if(!force&&p.getDynamicProperty(APPLIED)===index)return value;p.triggerEvent('rpg:ward_defense_'+index);p.setDynamicProperty(APPLIED,index);return value;}
export function registerWardDefense(){if(registered)return;registered=true;system.run(()=>{for(const p of world.getAllPlayers())try{applyWardDefense(p,true);}catch(error){console.warn('[RPG ward] '+error);}});world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{try{applyWardDefense(ev.player,true);}catch(error){console.warn('[RPG ward] '+error);}},2));system.runInterval(()=>{for(const p of world.getAllPlayers())try{applyWardDefense(p);}catch(error){console.warn('[RPG ward] '+error);}},20);}
