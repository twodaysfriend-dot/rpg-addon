import {EquipmentSlot} from '@minecraft/server';
import {RARITIES,RARITY_KEY} from '../data/grades.js';
import {itemRarity} from '../data/rarity.js';
import {decorateRarity} from './rarityLabels.js';
import {readRuneBag,writeRuneBag} from './runeInventory.js';
export function canSetGrade(p){
 try{if(p.playerPermissionLevel===2)return true;}catch{}
 try{if(typeof p.commandPermissionLevel==='number'&&p.commandPermissionLevel>=1)return true;}catch{}
 try{if(typeof p.isOp==='function'&&p.isOp())return true;}catch{}
 return false;
}
const english={common:0,rare:1,epic:2,ancient:3,hero:4,heroic:4,legendary:5,mythic:6};
export function parseGrade(value){const s=String(value??'').trim().toLowerCase();if(/^[0-6]$/.test(s))return Number(s);const index=RARITIES.indexOf(s);return index>=0?index:english[s];}
export const SET_GRADE_HELP='/rpg:setgrade <일반|레어|에픽|고대|영웅|전설|신화|0~6> [hand|head|chest|legs|feet|rune1~5|rune:보관번호]';
const aliases={hand:'hand',mainhand:'hand','손':'hand',head:'head','머리':'head',chest:'chest','가슴':'chest',legs:'legs','다리':'legs',feet:'feet','발':'feet'};
export function setEquipmentGrade(p,args){
 if(!canSetGrade(p))return {ok:false,reason:'관리자만 장비 등급을 지정할 수 있습니다.'};
 const tokens=String(args??'').trim().split(/\s+/),grade=parseGrade(tokens[0]),raw=(tokens[1]??'hand').toLowerCase();
 if(tokens.length>2||!Number.isInteger(grade))return {ok:false,reason:SET_GRADE_HELP};
 try{
  const runeSlot=/^(?:rune|룬)([1-5])$/.exec(raw),runeUid=/^rune:(r[1-9][0-9]*)$/.exec(raw);
  if(runeSlot||runeUid){
   const before=readRuneBag(p),index=runeSlot?Number(runeSlot[1])-1:-1;
   if(runeSlot&&index>=before.unlockedSlots)return {ok:false,reason:'아직 해금하지 않은 룬 슬롯입니다.'};
   const uid=runeUid?.[1]??before.equipped[index],next=JSON.parse(JSON.stringify(before)),r=next.runes.find(r=>r.uid===uid);
   if(!r)return {ok:false,reason:'지정한 룬이 없습니다. /rpg:runes에서 장착 상태·보관 번호를 확인하세요.'};
   const old=r.grade;r.grade=grade;
   try{writeRuneBag(p,next);}catch(error){try{writeRuneBag(p,before);}catch{throw Error('룬 등급 저장·복구 실패. 관리자에게 문의하세요.');}throw error;}
   return {ok:true,message:'보관 룬 #'+uid+' 등급 '+RARITIES[old]+' → '+RARITIES[grade]+' · +'+r.level+' 및 장착 상태 유지'};
  }
  const target=aliases[raw];if(!target)return {ok:false,reason:SET_GRADE_HELP};
  let read,write;
  if(target==='hand'){
   const inv=p.getComponent('minecraft:inventory')?.container,slot=p.selectedSlotIndex;
   if(!inv||!Number.isInteger(slot)||slot<0||slot>=inv.size)return {ok:false,reason:'손에 든 장비를 확인할 수 없습니다.'};
   read=()=>inv.getItem(slot);write=item=>inv.setItem(slot,item);
  }else{
   const eq=p.getComponent('minecraft:equippable'),slot={head:EquipmentSlot.Head,chest:EquipmentSlot.Chest,legs:EquipmentSlot.Legs,feet:EquipmentSlot.Feet}[target];
   if(!eq)return {ok:false,reason:'착용 장비를 확인할 수 없습니다.'};
   read=()=>eq.getEquipment(slot);write=item=>{if(!eq.setEquipment(slot,item))throw Error('착용 장비 저장 실패');};
  }
  const item=read(),info=itemRarity(item);
  if(!info)return {ok:false,reason:'손에 든 RPG 갑옷·공통 무기 또는 보관 룬만 등급을 설정할 수 있습니다. 직업 전용 무기는 기존처럼 강화만 지원합니다.'};
  if(info.kind==='rune')return {ok:false,reason:'가방의 룬은 /rpg:runes로 보관함에 넣은 뒤 /rpg:setgrade 신화 rune1 또는 rune:보관번호로 설정하세요.'};
  const original=item.clone(),next=item.clone();
  next.setDynamicProperty(RARITY_KEY,grade);
  decorateRarity(next);
  try{write(next);}catch(error){try{write(original);}catch{throw Error('장비 등급 저장·복구 실패. 관리자에게 문의하세요.');}throw error;}
  return {ok:true,message:info.name+' 등급 '+RARITIES[info.rank]+' → '+RARITIES[grade]+' · 강화·인챈트·내구도·기존 옵션 유지'};
 }catch(error){return {ok:false,reason:'등급 설정 실패: '+String(error.message??error)};}
}
