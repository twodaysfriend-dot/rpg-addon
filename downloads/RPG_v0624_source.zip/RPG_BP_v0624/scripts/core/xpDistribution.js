export function personalKillXp(base, inParty, multiplier = 0.75) {
  if (!Number.isFinite(base) || base <= 0) return 0;
  return base * (inParty ? multiplier : 1);
}

export function isXpRecipient(player, origin, dimensionId, level, levelMax, radius) {
  return level < levelMax && isActiveNearbyPlayer(player,origin,dimensionId,radius);
}

export function isActiveNearbyPlayer(player, origin, dimensionId, radius) {
  try {
    if (!player?.isValid || player.dimension.id !== dimensionId) return false;
    const mode = String(player.getGameMode()).toLowerCase();
    if (mode === 'creative' || mode === 'spectator') return false;
    if ((player.getComponent('minecraft:health')?.currentValue ?? 0) <= 0) return false;
    const p = player.location;
    return Math.hypot(p.x - origin.x, p.y - origin.y, p.z - origin.z) <= radius;
  } catch { return false; }
}
