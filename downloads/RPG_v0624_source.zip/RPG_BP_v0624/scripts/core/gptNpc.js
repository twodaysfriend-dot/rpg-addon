import {world,system} from '@minecraft/server';
import {askRpg} from './rpgAssistant.js';
import {healthAlive,isSolidAt} from './util.js';
export const GPT_NPC='rpg:gpt_guide';
const lastInteraction=new Map();let registered=false;
export function spawnGptNpc(player){
 const v=player.getViewDirection(),length=Math.hypot(v.x,v.z)||1,p=player.location;
 const at={x:p.x+v.x/length*2.5,y:p.y,z:p.z+v.z/length*2.5};
 if(isSolidAt(player.dimension,{...at,y:at.y+.2})||isSolidAt(player.dimension,{...at,y:at.y+1.5})){player.sendMessage('§7GPT NPC를 놓을 빈 공간이 필요합니다.');return false;}
 const npc=player.dimension.spawnEntity(GPT_NPC,at);npc.nameTag='§aGPT §fRPG 안내';
 player.sendMessage('§aGPT 안내 NPC를 만들었습니다. 우클릭 또는 모바일 질문 버튼으로 대화하세요.');return npc;
}
export function registerGptNpc(){
 if(registered)return;registered=true;
 world.afterEvents.playerInteractWithEntity.subscribe(ev=>{
  if(ev.target?.typeId!==GPT_NPC)return;
  const p=ev.player,npc=ev.target;
  if(p?.typeId!=='minecraft:player'||!p.isValid||!npc.isValid||!healthAlive(p)||p.dimension.id!==npc.dimension.id)return;
  if(Math.hypot(p.location.x-npc.location.x,p.location.y-npc.location.y,p.location.z-npc.location.z)>6)return;
  const now=system.currentTick;if(now-(lastInteraction.get(p.id)??-100)<8)return;lastInteraction.set(p.id,now);
  system.run(()=>{if(p.isValid)void askRpg(p);});
 });
 world.afterEvents.playerLeave.subscribe(ev=>lastInteraction.delete(ev.playerId));
}
