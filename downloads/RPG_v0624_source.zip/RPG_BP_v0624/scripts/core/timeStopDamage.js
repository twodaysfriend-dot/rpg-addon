// No world imports: existing attacks remain unchanged unless this specific target is frozen by their source.
const records=new Map();
export function registerStoppedTarget(target,source){const record={target,source,damage:0};records.set(target.id,record);return record;}
export function deferStoppedDamage(target,source,amount){const r=records.get(target?.id);if(!r||r.source.id!==source?.id||!Number.isFinite(amount)||amount<=0)return false;r.damage+=amount;return true;}
export function takeStoppedDamage(targetId){const record=records.get(targetId);records.delete(targetId);return record;}
export function isTimeFrozen(entity){return records.has(entity?.id);}
