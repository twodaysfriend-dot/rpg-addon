import {world,system} from '@minecraft/server';
export const SPAWN_REGION_KEY='rpg:spawn_town_region_v1';
const OWNED='rpg:spawn_effects_v1';
export const SPAWN_EFFECTS=[{id:'speed',amp:5,duration:40},{id:'night_vision',amp:0,duration:240},{id:'saturation',amp:0,duration:40}];
export function setSpawnRegion(s){world.setDynamicProperty(SPAWN_REGION_KEY,JSON.stringify({x:s.x,y:s.y,z:s.z,size:250,dimId:s.dimId??'minecraft:overworld'}));}
export function spawnRegion(){try{const s=JSON.parse(world.getDynamicProperty(SPAWN_REGION_KEY)??'null');return s&&[s.x,s.y,s.z].every(Number.isFinite)&&s.size===250?s:undefined;}catch{return undefined;}}
export function insideSpawn(p,s=spawnRegion()){return !!s&&p.dimension.id===s.dimId&&p.location.x>=s.x&&p.location.x<s.x+s.size&&p.location.z>=s.z&&p.location.z<s.z+s.size;}
function owned(p){try{return JSON.parse(p.getDynamicProperty(OWNED)??'null');}catch{return undefined;}}
export function clearSpawnEffects(p,restore=true){
 const saved=owned(p);if(!saved)return;
 for(const def of SPAWN_EFFECTS){const s=saved[def.id];if(!s)continue;try{
  const now=p.getEffect(def.id),ours=s.applied&&now?.amplifier===def.amp&&now.duration<=def.duration;
  if(ours)p.removeEffect(def.id);
  const old=s.previous,current=p.getEffect(def.id),left=old?Math.floor((old.until-Date.now())/50):0;
  if(restore&&left>0&&(!current||current.amplifier<old.amp))p.addEffect(def.id,left,{amplifier:old.amp,showParticles:false});
 }catch{}}
 p.setDynamicProperty(OWNED,undefined);
}
export function tickSpawnEffects(){
 const region=spawnRegion();
 for(const p of world.getAllPlayers())try{
  if(!insideSpawn(p,region)){clearSpawnEffects(p);continue;}
  let data=owned(p)??{},changed=false;
  for(const def of SPAWN_EFFECTS){
   let record=data[def.id],effect=p.getEffect(def.id);
   if(!record){record={previous:effect?{amp:effect.amplifier,until:Date.now()+effect.duration*50}:null,applied:false};data[def.id]=record;changed=true;}
   const isOurs=record.applied&&effect?.amplifier===def.amp&&effect.duration<=def.duration;
   if(effect&&!isOurs){const until=Date.now()+effect.duration*50;if(!record.previous||record.previous.amp!==effect.amplifier||Math.abs(record.previous.until-until)>150){record.previous={amp:effect.amplifier,until};changed=true;}}
   if(effect&&effect.amplifier>def.amp){if(record.applied){record.applied=false;changed=true;}continue;}
   if(!effect||effect.amplifier!==def.amp||effect.duration<def.duration-5){p.addEffect(def.id,def.duration,{amplifier:def.amp,showParticles:false});if(!record.applied){record.applied=true;changed=true;}}
  }
  if(changed)p.setDynamicProperty(OWNED,JSON.stringify(data));
 }catch(error){console.warn('[RPG spawn effects] '+error);}
}
let registered=false;
export function registerSpawnEffects(){if(registered)return;registered=true;system.runInterval(tickSpawnEffects,1);world.afterEvents.playerDimensionChange?.subscribe(()=>system.run(tickSpawnEffects));world.afterEvents.playerSpawn.subscribe(ev=>system.run(()=>{try{if(!ev.initialSpawn)clearSpawnEffects(ev.player,false);tickSpawnEffects();}catch{}}));}
