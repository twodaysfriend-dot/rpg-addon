import {ItemStack,ItemLockMode,system} from '@minecraft/server';
import {ActionFormData} from '@minecraft/server-ui';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {JOBS,STARTER_ITEMS,STARTER_BY_LINE} from '../data/jobs.js';
export const BINDING_KEY='rpg:weapon_binding',WEAPON_UID='rpg:bound_weapon_uid';
const common=new Set(COMMON_WEAPONS.map(w=>w.id));
const inventory=p=>p.getComponent('minecraft:inventory')?.container;
export function weaponBinding(p){try{const b=JSON.parse(p.getDynamicProperty(BINDING_KEY)??'null');return b&&typeof b.uid==='string'&&common.has(b.type)?b:undefined;}catch{return undefined;}}
export function isBoundHeld(p,id){const b=weaponBinding(p);if(!b||p.selectedSlotIndex!==0)return false;const item=inventory(p)?.getItem(0);return item?.typeId===b.type&&(!id||id===b.type)&&item.getDynamicProperty(WEAPON_UID)===b.uid;}
function originalFlags(item,b){item.lockMode=b?.oldLock??'none';item.keepOnDeath=b?.oldKeep??false;}
export function bindCommonWeapon(p,slot,expected){
 const inv=inventory(p);if(!inv||!Number.isInteger(slot)||slot<0||slot>=inv.size)return {ok:false,reason:'선택 슬롯이 잘못되었습니다.'};
 const selected=inv.getItem(slot),old=inv.getItem(0),previous=p.getDynamicProperty(BINDING_KEY),b=weaponBinding(p);
 if(!selected||!common.has(selected.typeId)||selected.amount!==1)return {ok:false,reason:'보유한 공통 무기 1개를 선택하세요.'};
 if(expected&&fingerprint(selected)!==expected)return {ok:false,reason:'선택한 무기가 변경되었습니다. 다시 선택하세요.'};
 if(slot===0&&b&&selected.getDynamicProperty(WEAPON_UID)===b.uid)return {ok:true};
 const beforeSelected=selected.clone(),beforeOld=old?.clone();
 try{
  const item=selected.clone(),uid=p.id+':'+Date.now()+':'+system.currentTick;
  const next={uid,type:item.typeId,line:b?.line??STARTER_ITEMS[old?.typeId]??'sword',oldLock:item.lockMode??'none',oldKeep:item.keepOnDeath??false};
  item.setDynamicProperty(WEAPON_UID,uid);item.lockMode=ItemLockMode?.slot??'slot';item.keepOnDeath=true;
  let displaced=old?.clone();if(displaced){if(b&&displaced.getDynamicProperty(WEAPON_UID)===b.uid){originalFlags(displaced,b);displaced.setDynamicProperty(WEAPON_UID,undefined);}else displaced.lockMode='none';}
  if(slot!==0)inv.setItem(slot,displaced);
  inv.setItem(0,item);p.setDynamicProperty(BINDING_KEY,JSON.stringify(next));return {ok:true};
 }catch(error){try{inv.setItem(slot,beforeSelected);if(slot!==0)inv.setItem(0,beforeOld);p.setDynamicProperty(BINDING_KEY,previous);}catch{}return {ok:false,reason:'무기 교체 실패. 기존 아이템을 복구했습니다.'};}
}
export function maintainWeaponBinding(p){
 const b=weaponBinding(p);if(!b)return false;
 const inv=inventory(p);if(!inv)return true;
 let found=-1;
 for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.getDynamicProperty(WEAPON_UID)===b.uid){found=i;break;}
 if(found<0){
  // Slot locked + keepOnDeath: normal gameplay cannot move/drop this item.
  // Recover moved copies first; only an absent bound instance ends the binding.
  p.setDynamicProperty(BINDING_KEY,undefined);restoreApprenticeFocus(p,b.line);return false;
 }
 const item=inv.getItem(found);if(item.typeId!==b.type){p.setDynamicProperty(BINDING_KEY,undefined);return false;}
 if(found!==0){const old=inv.getItem(0);inv.setItem(0,item);inv.setItem(found,old);}
 if(item.lockMode!==(ItemLockMode?.slot??'slot')||!item.keepOnDeath){item.lockMode=ItemLockMode?.slot??'slot';item.keepOnDeath=true;inv.setItem(0,item);}
 return true;
}
export function releaseWeaponBinding(p){
 const b=weaponBinding(p),inv=inventory(p);if(!b||!inv)return;
 for(let i=0;i<inv.size;i++){const item=inv.getItem(i);if(item?.getDynamicProperty(WEAPON_UID)===b.uid){originalFlags(item,b);item.setDynamicProperty(WEAPON_UID,undefined);inv.setItem(i,item);}}
 p.setDynamicProperty(BINDING_KEY,undefined);restoreApprenticeFocus(p,b.line);
}
function restoreApprenticeFocus(p,line){
 if((p.getDynamicProperty('rpg:job')??'apprentice')!=='apprentice')return;
 const inv=inventory(p),type=STARTER_BY_LINE[line];if(!inv||!type)return;
 let source=-1;for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId===type){source=i;break;}
 if(source===0)return;const old=inv.getItem(0),focus=source>=0?inv.getItem(source):new ItemStack(type,1);
 let dest=source;if(old&&dest<0){for(let i=1;i<inv.size;i++)if(!inv.getItem(i)){dest=i;break;}if(dest<0)return;}
 if(dest>=0)inv.setItem(dest,old);focus.lockMode=ItemLockMode?.slot??'slot';focus.keepOnDeath=true;inv.setItem(0,focus);
}
export function skillItemId(p,actual){
 if(!isBoundHeld(p,actual))return actual;
 const b=weaponBinding(p),job=JOBS[p.getDynamicProperty('rpg:job')??'apprentice'];
 return job?.weapon??Object.keys(STARTER_ITEMS).find(id=>STARTER_ITEMS[id]===b.line)??actual;
}
function fingerprint(item){return JSON.stringify([item.typeId,item.amount,item.getDynamicProperty(WEAPON_UID),item.getDynamicProperty('rpg:weapon_upgrade'),item.nameTag,item.getComponent('minecraft:durability')?.damage]);}
const menuOpen=new Set();
export async function openWeaponBinding(p){
 if(menuOpen.has(p.id))return;menuOpen.add(p.id);
 try{
  const inv=inventory(p);if(!inv)return;const choices=[];
  const form=new ActionFormData().title('공통 무기 · 직업 아이템 대체').body('보유한 공통 무기를 선택하면 단축바 1번 칸에 고정됩니다. 직업 기술 사용 가능 · 전직·강화·재접속 시 유지 · 파괴 시 현재 직업 아이템 복귀.');
  for(let i=0;i<inv.size;i++){const item=inv.getItem(i);if(!common.has(item?.typeId))continue;choices.push({slot:i,expected:fingerprint(item)});form.button((item.nameTag||COMMON_WEAPONS.find(w=>w.id===item.typeId).name)+' · '+(i+1)+'번 칸');}
  form.button('대체 해제 · 직업 아이템 복귀');form.button('닫기');
  const answer=await form.show(p);if(!answer||answer.canceled)return;
  if(answer.selection===choices.length){releaseWeaponBinding(p);p.sendMessage('§a공통 무기 대체를 해제했습니다. 직업 아이템을 복구합니다.');return;}
  const choice=choices[answer.selection];if(!choice)return;
  const result=bindCommonWeapon(p,choice.slot,choice.expected);p.sendMessage(result.ok?'§a공통 무기를 단축바 1번 칸에 배치했습니다.': '§e'+result.reason);
 }finally{menuOpen.delete(p.id);}
}
