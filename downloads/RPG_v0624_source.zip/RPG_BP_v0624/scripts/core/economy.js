import {HUNT_REWARDS} from '../data/dungeons.js';
import { CONFIG } from '../config.js';
import { isBeginnerTarget } from './beginnerData.js';
import { partyMembership } from './social.js';
import { isActiveNearbyPlayer } from './xpDistribution.js';
import { creditWallet, WALLET_KEY } from './wallet.js';

const BOSSES = new Set(['rpg:rock_golem_boss','rpg:cyclops_boss','rpg:hydra_boss','rpg:tech_block_golem_boss',
  'minecraft:wither','minecraft:ender_dragon','minecraft:warden']);

export function currencyReward(typeId, random=Math.random) {
  if(typeId==='minecraft:silverfish')return {gold:2,stone:0,dust:0};
  if (BOSSES.has(typeId)) return {...HUNT_REWARDS.boss};
  if (!isBeginnerTarget(typeId)) return undefined;
  if (typeId.startsWith('rpg:elite_')) return {...HUNT_REWARDS.elite};
  return {gold:HUNT_REWARDS.normal.gold,stone:HUNT_REWARDS.normal.stone,dust:random() < HUNT_REWARDS.normal.dustChance ? 1 : 0};
}

export function grantKillCurrencies(killer, entity, random=Math.random) {
  // A creative/spectator killer cannot mint money for survival party members.
  if (!isActiveNearbyPlayer(killer,killer.location,killer.dimension.id,CONFIG.partyXp.radius)) return [];
  const reward = currencyReward(entity?.typeId,random);
  if (!reward) return [];
  const recipients = partyMembership(killer).members.filter(p=>
    isActiveNearbyPlayer(p,killer.location,killer.dimension.id,CONFIG.partyXp.radius));
  const paid = [];
  for (const player of recipients) {
    try {
      const first = player.getDynamicProperty(WALLET_KEY)===undefined;
      creditWallet(player,reward);paid.push(player.id);
      if(first)try{player.sendMessage('§7재화는 자동 저장됩니다. /rpg:wallet · /rpg:upgrade');}catch{}
    }
    catch (error) {console.warn('[RPG economy] reward failed: '+String(error));}
  }
  return paid;
}
