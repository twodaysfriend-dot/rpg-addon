import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {getJobId,getSkills} from './playerData.js';
import {SKILLS} from '../data/skills.js';
import {readChameleonProgress} from './chameleonProgress.js';
import {hasDirectSkillPower} from '../data/skillPower.js';
import {showForm} from './skillMenu.js';
import {transcendQuote,purchaseTranscend,transcendMultiplier,TRANSCEND_MAX,TRANSCEND_UPGRADE_MAX} from './chameleonTranscend.js';
const open=new Set(),pct=level=>Math.round((transcendMultiplier(level)-1)*100);
export async function openTranscendMenu(p,mode='transcend'){
 if(open.has(p.id)||getJobId(p)!=='chameleon')return;open.add(p.id);
 try{
  for(let n=0;n<50&&p.isValid&&getJobId(p)==='chameleon';n++){
   const state=readChameleonProgress(p),ids=state.evolved.filter(id=>getSkills(p).includes(id)&&hasDirectSkillPower(SKILLS[id]));
   const form=new ActionFormData().title(mode==='transcend'?'진화 스킬 초월':'초월 스킬 강화').body('초월은 진화한 공격·직접 회복 기술의 위력을 높입니다.\n직접 피해·회복이 없는 지원·시간정지 기술은 대상에서 제외됩니다.\n시간·범위·탄 수·마나·쿨타임은 그대로입니다.\n초월 '+Object.keys(state.transcended).length+'/'+TRANSCEND_MAX+'개 · 기술당 초월강화 최대 '+TRANSCEND_UPGRADE_MAX+'회\n\n초월 비용: 1번째 20만 골드·강화석 800개\n2번째 50만 골드·강화석 2,000개\n3번째 75만 골드·강화석 3,000개\n매번 네더라이트 주괴 2개·다이아몬드 블록 9개 추가.\n초월강화는 매회 30,000골드·강화석 100개.\n분해하면 초월·초월강화도 사라지며 재료는 반환하지 않습니다.');
   for(const id of ids){const q=transcendQuote(p,id,mode),level=state.transcended[id];form.button(SKILLS[id].name+'\n'+(q?(mode==='transcend'?'초월 · 위력 +'+pct(0)+'%':'초월강화 +'+q.level+' · 위력 +'+pct(q.level)+'%'):level===undefined?'초월 필요 / 슬롯 또는 대상 확인':'초월 +'+level+' · 위력 +'+pct(level)+'% / '+(mode==='transcend'?'초월 완료':'최대 강화')));}
   form.button('뒤로');const pick=await showForm(form,p);if(!pick||pick.canceled||!Number.isInteger(pick.selection)||!ids[pick.selection])return;
   const id=ids[pick.selection],q=transcendQuote(p,id,mode);if(!q){p.sendMessage('§e이미 완료했거나 초월 슬롯·강화 횟수를 모두 사용했습니다.');continue;}
   const confirm=await showForm(new MessageFormData().title(mode==='transcend'?'스킬 초월 확인':'초월강화 확인').body(SKILLS[id].name+'\n'+(mode==='transcend'?q.order+'번째 초월':'초월강화 +'+q.level)+' · 위력 +'+pct(q.level)+'%\n골드 '+q.cost.gold.toLocaleString()+' / 강화석 '+q.cost.stone.toLocaleString()+'개'+(mode==='transcend'?'\n네더라이트 주괴 2개 / 다이아몬드 블록 9개':'')+'\n\n피해·직접 회복 수치만 강화합니다.\n분해 시 재료·재화는 반환하지 않습니다.').button1('취소').button2(mode==='transcend'?'초월':'초월강화'),p);
   if(!confirm||confirm.canceled||confirm.selection!==1)continue;
   const r=purchaseTranscend(p,id,mode,q.fingerprint);p.sendMessage((r.ok?'§d':'§e')+r.message);
  }
 }catch(error){try{p.sendMessage('§c초월 메뉴: '+String(error));}catch{}}
 finally{open.delete(p.id);}
}
