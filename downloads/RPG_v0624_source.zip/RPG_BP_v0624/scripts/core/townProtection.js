import {CITY_HOUSE_PLOTS} from '../data/fantasyCity.js';
import {spawnRegion} from './spawnEffects.js';
import {registerStructureProtection} from './structureProtection.js';
const dimensionId=id=>id?.replace('minecraft:','');
export function townProtected(block,region=spawnRegion()){
 if(!region||!block?.location||dimensionId(block.dimension?.id)!==dimensionId(region.dimId))return false;
 const x=Math.floor(block.location.x)-region.x,z=Math.floor(block.location.z)-region.z,y=Math.floor(block.location.y)-region.y;
 if(x<0||x>=region.size||z<0||z>=region.size)return false;
 // Gold remains protected even if a player moves it into a residential plot.
 let type=block.typeId;
 if(!type)try{type=block.dimension.getBlock(block.location)?.typeId;}catch{return true;}
 if(type==='minecraft:gold_block')return true;
 // Only the home's footprint (floor through roof height) may be remodeled.
 return !CITY_HOUSE_PLOTS.some(p=>x>=p.x&&x<p.x+p.w&&z>=p.z&&z<p.z+p.d&&y>=0&&y<=16);
}
let registered=false;
export function registerTownProtection(){if(registered)return;registered=true;registerStructureProtection('town',townProtected);}
