export const WORLD_MASTERY_KEY='rpg:world_stop_uses_v1';
export const WORLD_BLOOD_KEY='rpg:the_world_blood_until';
export const WORLD_MASTERY_MAX=50;
export function worldMastery(p){const value=p.getDynamicProperty(WORLD_MASTERY_KEY);return Number.isSafeInteger(value)?Math.max(0,Math.min(WORLD_MASTERY_MAX,value)):0;}
export function baseWorldTicks(p){return 20+worldMastery(p)*2;}
export function bloodWorldReady(p){return Number(p.getDynamicProperty(WORLD_BLOOD_KEY)??0)>Date.now();}
export function worldDurationTicks(p,enhanced=bloodWorldReady(p)){return Math.round(baseWorldTicks(p)*(enhanced?1.5:1));}
export function addWorldMastery(p){const next=Math.min(WORLD_MASTERY_MAX,worldMastery(p)+1);p.setDynamicProperty(WORLD_MASTERY_KEY,next);return next;}
export function worldMasteryText(p){return `시간 정지 숙련도 ${worldMastery(p)}/${WORLD_MASTERY_MAX} · 기본 ${baseWorldTicks(p)/20}초${bloodWorldReady(p)?' · 다음 흡혈 강화 '+worldDurationTicks(p)/20+'초':''}`;}
