import {world} from '@minecraft/server';
import {areAllies} from './social.js';
export function alliedOwner(entity){
 if(entity?.typeId==='minecraft:player')return entity;
 try{
  const projectileOwner=entity?.getComponent('minecraft:projectile')?.owner;
  if(projectileOwner?.typeId==='minecraft:player')return projectileOwner;
  const tame=entity?.getComponent('minecraft:tameable');
  const id=tame?.tamedToPlayerId??tame?.tamedToPlayer?.id??entity?.getDynamicProperty('rpg:necro_owner');
  return id?world.getAllPlayers().find(p=>p.id===id):undefined;
 }catch{return undefined;}
}
export function isHealingAlly(caster,target){
 if(!caster||!target)return false;
 if(caster.id===target.id)return true;
 const owner=alliedOwner(target);
 if(owner)return areAllies(caster,owner);
 try{return target.getTags().some(tag=>(tag.startsWith('rpg_team_')||tag.startsWith('rpg_party_')||tag.startsWith('rpg_guild_'))&&caster.hasTag(tag));}catch{return false;}
}
