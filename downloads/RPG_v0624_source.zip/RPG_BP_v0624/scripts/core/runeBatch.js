import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {RUNES} from '../data/equipment.js';
import {RARITIES} from '../data/grades.js';
import {readRuneBag,writeRuneBag} from './runeInventory.js';
import {enhancementQuote,enhanceEquipped} from './upgrades.js';
import {getWallet,setWallet,canAfford,walletText} from './wallet.js';
import {showForm} from './skillMenu.js';
export function runeBatchQuote(p,id,grade){
 if(!RUNES[id]||!Number.isInteger(grade)||grade<0||grade>6)return undefined;
 const bag=readRuneBag(p),runes=bag.runes.filter(r=>r.id===id&&r.grade===grade),entries=[],cost={gold:0,stone:0,dust:0};
 for(const r of runes)if(r.level<10){const q=enhancementQuote(p,'rune',r.uid);entries.push(q);for(const k of Object.keys(cost))cost[k]+=q.cost[k];}
 return {id,grade,entries,cost,count:entries.length,fingerprint:JSON.stringify({runes,equipped:bag.equipped}),total:runes.length};
}
export function executeRuneBatch(p,id,grade,expected,options={}){
 let bag,wallet,started=false;
 try{
  const q=runeBatchQuote(p,id,grade);
  if(!q?.count)return {ok:false,reason:'강화 가능한 룬이 없습니다. +10 룬은 제외됩니다.'};
  if(expected!==undefined&&q.fingerprint!==expected)return {ok:false,reason:'보관 룬이나 장착 상태가 변경됐습니다. 다시 선택하세요.'};
  wallet=getWallet(p);if(!canAfford(wallet,q.cost))return {ok:false,reason:'일괄 강화 전체 비용이 부족합니다. 룬과 재화는 그대로입니다.'};
  bag=readRuneBag(p);const results=[];
  for(const entry of q.entries){
   started=true;
   const r=enhanceEquipped(p,'rune',entry.slot,entry.fingerprint,{random:options.random});
   if(!r.ok)throw Error(r.reason);results.push(r);
  }
  const counts={success:0,fail:0,downgrade:0,destroy:0};
  for(const r of results)counts[r.outcome]++;
  return {ok:true,count:results.length,counts,cost:q.cost};
 }catch(error){
  let restored=true;
  if(started)for(const undo of [()=>writeRuneBag(p,bag),()=>setWallet(p,wallet)])try{undo();}catch{restored=false;}
  return {ok:false,reason:restored?'일괄 강화를 취소했습니다. '+String(error.message??error):'룬·재화 복구 실패. 관리자에게 문의하세요.'};
 }
}
export function runeGroups(p){const groups=new Map();for(const r of readRuneBag(p).runes){const key=r.id+':'+r.grade;if(!groups.has(key))groups.set(key,{id:r.id,grade:r.grade,count:0});groups.get(key).count++;}return [...groups.values()];}
const opened=new Set();
export async function openRuneBatch(p){
 if(opened.has(p.id))return;opened.add(p.id);
 try{
  for(let loop=0;loop<80&&p.isValid;loop++){
   const groups=runeGroups(p),f=new ActionFormData().title('같은 종류·등급 룬 일괄 강화').body(walletText(getWallet(p))+'\n\n종류·등급을 선택하면 해당 룬을 각각 한 번씩 강화합니다.\n기존 개별 강화 비용·확률 적용, 촉매 0개. +10 제외.\n일반 가방의 룬은 /rpg:runes에서 보관함에 먼저 넣어 주세요.');
   for(const g of groups)f.button(RUNES[g.id].name+' · '+RARITIES[g.grade]+' ×'+g.count);f.button('닫기');
   const pick=await showForm(f,p);if(!pick||pick.canceled||!groups[pick.selection])return;const g=groups[pick.selection],q=runeBatchQuote(p,g.id,g.grade);
   if(!q?.count){p.sendMessage('§e강화할 룬이 없습니다. +10 룬은 제외됩니다.');continue;}
   const detail=q.entries.map(e=>e.slot+' +'+e.level+' → 1회 시도').join('\n');
   const confirm=await showForm(new MessageFormData().title('룬 일괄 강화 확인').body(RUNES[g.id].name+' · '+RARITIES[g.grade]+'\n'+q.count+'개 각각 1회 강화\n총 비용: 골드 '+q.cost.gold+' / 룬 가루 '+q.cost.dust+'\n촉매 0개. 성공·유지·강등·파괴 확률은 개별 강화와 같습니다.\n장착 중인 룬도 포함하며, 파괴되면 해당 룬은 장착 해제됩니다.\n이번에 강화된 룬은 다시 시도하지 않습니다.\n\n'+detail).button1('취소').button2('일괄 강화'),p);
   if(!confirm||confirm.canceled||confirm.selection!==1)continue;
   const r=executeRuneBatch(p,g.id,g.grade,q.fingerprint);
   p.sendMessage(r.ok?'§a룬 일괄 강화 '+r.count+'개 완료 · 성공 '+r.counts.success+' / 유지 '+r.counts.fail+' / 강등 '+r.counts.downgrade+' / 파괴 '+r.counts.destroy:'§e'+r.reason);
  }
 }catch(error){try{p.sendMessage('§c룬 일괄 강화 오류: '+String(error));}catch{}}
 finally{opened.delete(p.id);}
}
