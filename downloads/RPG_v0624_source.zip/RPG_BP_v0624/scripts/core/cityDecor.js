import {makeFantasyCityPlan as oldPlan} from '../data/fantasyCityV1.js';
import {makeFantasyCityPlan as newPlan,tileOperations} from '../data/fantasyCity.js';
const old=oldPlan().operations,current=newPlan().operations;
const key=(x,y,z)=>[x,y,z].join(',');
function* blocks(plan,tile){
 for(const op of tileOperations(plan,tile))for(let y=op.y;y<=op.y2;y++)for(let z=op.z;z<=op.z2;z++)for(let x=op.x;x<=op.x2;x++)yield {x,y,z,type:op.type,states:op.states};
}
export function decorContext(tile){return {before:new Map(),after:new Map(),old:blocks(old,tile),next:blocks(current,tile),stage:0};}
export function prepareDecor(c,budget=256){
 for(let n=0;n<budget;n++){
  if(c.stage>=2){if(!c.iterator)c.iterator=decorChanges(c);return true;}
  const it=c.stage===0?c.old:c.next,map=c.stage===0?c.before:c.after,v=it.next();
  if(v.done){c.stage++;continue;}
  const p=v.value,k=key(p.x,p.y,p.z);if(!map.has(k))map.set(k,p);
 }return false;
}
function* decorChanges(c){
 for(const [key,old]of c.before){const target=c.after.get(key);if(old.type!==target?.type||JSON.stringify(old.states)!==JSON.stringify(target?.states))yield {old,target,location:old};}
 for(const [key,target]of c.after)if(!c.before.has(key))yield {target,location:target};
}
export function canDecorate(block,change){
 // Inventories and blocks edited to another material are never overwritten.
 if(block.getComponent('minecraft:inventory'))return false;
 if(change.old)return block.typeId===change.old.type;
 return block.isAir;
}
