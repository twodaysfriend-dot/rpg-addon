// Track pre-hit health from the stable health-change signal, including lethal hits.
import {world,system} from '@minecraft/server';
const changes=new Map();
export function noteHealthChange(ev){
 if(!ev.entity?.id||!(ev.oldValue>ev.newValue))return;
 const list=changes.get(ev.entity.id)??[];
 list.push({old:ev.oldValue,amount:ev.oldValue-ev.newValue,tick:system.currentTick});
 changes.set(ev.entity.id,list.filter(x=>x.tick>=system.currentTick-1).slice(-24));
}
export function actualHurtAmount(ev,hit){
 const raw=Math.max(0,ev.damage||0);
 const list=changes.get(ev.hurtEntity?.id),index=list?.findIndex(x=>x.tick===system.currentTick&&x.amount<=raw+.0001);
 const record=index>=0?list.splice(index,1)[0]:undefined;
 if(hit&&Number.isFinite(hit.before))return Math.min(raw,hit.before);
 if(record)return Math.min(raw,record.amount);
 // Engine hurt damage is normally health damage. Cap against pre-hit cached
 // changes when available; never use the post-hit remaining HP as a damage cap.
 const hp=ev.hurtEntity?.getComponent('minecraft:health');return Math.min(raw,hp?.effectiveMax??raw);
}
export function registerDamageAmounts(){
 world.afterEvents.entityHealthChanged?.subscribe(noteHealthChange);
 system.runInterval(()=>{for(const [id,list] of changes)if(!list.some(x=>x.tick>=system.currentTick-1))changes.delete(id);},20);
}
