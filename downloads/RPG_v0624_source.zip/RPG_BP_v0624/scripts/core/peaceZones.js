import {world,system} from '@minecraft/server';
const KEY='rpg:peace_zones_v1';export const PEACE_RADIUS=200;
let registered=false;
export function readPeaceZones(){try{const a=JSON.parse(world.getDynamicProperty(KEY)??'[]');return Array.isArray(a)?a.filter(z=>typeof z.dimension==='string'&&['x','y','z'].every(k=>Number.isFinite(z[k]))):[];}catch{return [];}}
export function isInsidePeace(entity,zones=readPeaceZones()){return zones.some(z=>entity.dimension.id===z.dimension&&Math.hypot(entity.location.x-z.x,entity.location.y-z.y,entity.location.z-z.z)<=PEACE_RADIUS);}
export function configurePeace(p,arg=''){
 const admin=p.playerPermissionLevel===2||(typeof p.commandPermissionLevel==='number'&&p.commandPermissionLevel>=1)||(typeof p.isOp==='function'&&p.isOp());
 if(!admin){p.sendMessage('§c평화구역 설정은 관리자만 가능합니다.');return;}
 const action=String(arg).trim().toLowerCase(),zones=readPeaceZones();
 if(['list','목록'].includes(action)){p.sendMessage('§b평화구역 '+zones.length+'곳\n'+zones.map((z,i)=>`${i+1}. ${z.dimension} ${Math.round(z.x)}, ${Math.round(z.y)}, ${Math.round(z.z)} · 반경 200`).join('\n'));return;}
 if(!['','set','설정','off','해제'].includes(action)){p.sendMessage('§e/peace [set|off|list] 또는 /rpg:peace [set|off|list]');return;}
 if(['off','해제'].includes(action)){
  const candidates=zones.map((z,i)=>({z,i,d:z.dimension===p.dimension.id?Math.hypot(p.location.x-z.x,p.location.y-z.y,p.location.z-z.z):Infinity})).filter(a=>a.d<=PEACE_RADIUS).sort((a,b)=>a.d-b.d);
  if(!candidates.length){p.sendMessage('§e현재 위치에 해제할 평화구역이 없습니다.');return;}
  zones.splice(candidates[0].i,1);world.setDynamicProperty(KEY,JSON.stringify(zones));p.sendMessage('§a가장 가까운 평화구역을 해제했습니다.');return;
 }
 if(zones.length>=64){p.sendMessage('§e최대 64곳입니다. 기존 구역을 먼저 해제하세요.');return;}
 if(zones.some(z=>z.dimension===p.dimension.id&&Math.hypot(p.location.x-z.x,p.location.y-z.y,p.location.z-z.z)<1)){p.sendMessage('§e이미 같은 위치에 설정되어 있습니다.');return;}
 zones.push({dimension:p.dimension.id,...p.location});world.setDynamicProperty(KEY,JSON.stringify(zones));p.sendMessage('§a현재 위치 중심 반경 200블록을 평화구역으로 설정했습니다. /peace off 로 해제합니다.');
}
function removeMonster(e,zones){try{if(e.typeId==='minecraft:player'||!isInsidePeace(e,zones))return;if(e.getComponent('minecraft:type_family')?.hasTypeFamily('monster'))e.remove();}catch{}}
export function tickPeaceZones(){
 const zones=readPeaceZones();
 for(const z of zones)try{for(const e of world.getDimension(z.dimension).getEntities({location:z,maxDistance:PEACE_RADIUS,families:['monster']}))removeMonster(e,zones);}catch{}

}
export function registerPeaceZones(){if(registered)return;registered=true;world.afterEvents.entitySpawn.subscribe(e=>removeMonster(e.entity,readPeaceZones()));system.runInterval(tickPeaceZones,20);}
