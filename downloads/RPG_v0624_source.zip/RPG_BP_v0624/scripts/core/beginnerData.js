export const INTRO_KEY = 'rpg:intro_v1';
export const INTRO_KILLS = 5;
export const INTRO_XP = 100;
export const BEGINNER_LINES = Object.freeze(['sword', 'mage', 'holy', 'fist', 'archer']);

export function getBeginnerState(player) {
  try {
    const raw = player.getDynamicProperty(INTRO_KEY);
    const value = typeof raw === 'string' ? JSON.parse(raw) : {};
    if (!value || typeof value !== 'object') return {};
    return {
      line: BEGINNER_LINES.includes(value.line) ? value.line : undefined,
      tried: [...new Set((Array.isArray(value.tried)?value.tried:[value.line]).filter(line=>BEGINNER_LINES.includes(line)))],
      trialArrowsGiven: value.trialArrowsGiven===true||value.line==='archer',
      kills: Math.max(0, Math.min(INTRO_KILLS, Math.floor(Number(value.kills) || 0))),
      rewarded: value.rewarded === true,
      offered: value.offered === true,
    };
  } catch { return {}; }
}

export function setBeginnerState(player, value) {
  player.setDynamicProperty(INTRO_KEY, JSON.stringify(value));
}

export function beginnerAdvanceUnlocked(player, target) {
  const state = getBeginnerState(player);
  return state.rewarded === true && state.kills >= INTRO_KILLS &&
    target?.tier === 2 && target.parent === 'apprentice' && target.line === state.line;
}

// Explicit combat targets: animals, villagers, players, NPCs, and dummies do not count.
const HOSTILES = new Set([
  'minecraft:zombie', 'minecraft:husk', 'minecraft:drowned', 'minecraft:skeleton',
  'minecraft:stray', 'minecraft:bogged', 'minecraft:spider', 'minecraft:cave_spider',
  'minecraft:creeper', 'minecraft:witch', 'minecraft:slime', 'minecraft:magma_cube',
  'minecraft:phantom', 'minecraft:silverfish', 'minecraft:endermite', 'minecraft:enderman',
  'minecraft:pillager', 'minecraft:vindicator', 'minecraft:evocation_illager',
  'minecraft:ravager', 'minecraft:blaze', 'minecraft:ghast', 'minecraft:wither_skeleton',
  ...['red_mushroom', 'blue_mushroom', 'green_goblin', 'red_goblin', 'gold_goblin',
    'goblin_captain', 'scorpion', 'mantis', 'deathworm'].flatMap(id => ['rpg:' + id, 'rpg:elite_' + id]),
  'rpg:rock_golem_boss', 'rpg:cyclops_boss', 'rpg:hydra_boss', 'rpg:tech_block_golem_boss',
]);
export function isBeginnerTarget(typeId) { return HOSTILES.has(typeId); }
