import {world} from '@minecraft/server';
import {makeFantasyCityPlan,cityTile,tileOperations} from '../data/fantasyCityLegacy.js';
export const OLD_CITY_KEY='rpg:fantasy_city_1000_archive';
const plan=makeFantasyCityPlan().operations;
export function oldTrimTileLimit(o){return ['done','npcs'].includes(o?.phase)?256:o?.phase==='build'&&Number.isInteger(o.tile)?Math.min(256,Math.max(0,o.tile)+(Number.isInteger(o.op)&&Number.isInteger(o.offset)&&(o.op>0||o.offset>0)?1:0)):0;}
export function previousCompletedCity(s){
 try{const o=JSON.parse(world.getDynamicProperty(OLD_CITY_KEY)??'null');return o&&o.version===1&&oldTrimTileLimit(o)>0&&!o.trimmed&&[o.x,o.y,o.z].every(Number.isSafeInteger)&&s.x+125>=o.x&&s.x+125<o.x+1000&&s.z+125>=o.z&&s.z+125<o.z+1000?o:undefined;}catch{return undefined;}
}
export function oldTile(o,index){const t=cityTile(index);return {x:o.x+t.x,z:o.z+t.z,x2:o.x+t.x2,z2:o.z+t.z2,y:o.y};}
export function trimContext(o,index,keep){const all=tileOperations(plan,cityTile(index)),partial=o.phase==='build'&&index===o.tile,ops=partial?all.slice(0,o.op+(o.offset>0?1:0)):all;return {old:o,index,keep,ops,partial,op:0,offset:0,expected:new Map(),iterator:undefined,cursor:0};}
// Prepare the expected final material, honoring the old air-only operation priority.
export function prepareTrim(c,budget){
 for(let n=0;n<budget&&c.op<c.ops.length;n++){
  const op=c.ops[c.op],w=op.x2-op.x+1,d=op.z2-op.z+1,i=c.offset,x=c.old.x+op.x+i%w,y=c.old.y+op.y+Math.floor(i/(w*d)),z=c.old.z+op.z+Math.floor(i/w)%d;
  if(!(x>=c.keep.x&&x<c.keep.x+250&&z>=c.keep.z&&z<c.keep.z+250)){const key=[x,y,z].join(',');if(!c.expected.has(key))c.expected.set(key,{x,y,z,type:op.type});}
  if(++c.offset>=(c.partial&&c.op===c.old.op?Math.min(c.old.offset,w*d*(op.y2-op.y+1)):w*d*(op.y2-op.y+1))){c.offset=0;c.op++;}
 }
 if(c.op>=c.ops.length){c.iterator??=c.expected.values();return true;}return false;
}
export function canRemoveOldBlock(block,expected){
 if(!block||block.typeId!==expected.type)return false;
 try{const inv=block.getComponent('minecraft:inventory')?.container;if(inv){for(let i=0;i<inv.size;i++)if(inv.getItem(i))return false;}}catch{return false;}
 return true;
}
export function markOldCityTrimmed(o){world.setDynamicProperty(OLD_CITY_KEY,JSON.stringify({...o,trimmed:true}));}
