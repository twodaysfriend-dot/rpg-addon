// Use world operator privileges, NOT possession of an item, to authorize admin controls.
export function isRpgAdmin(player) {
  if (!player || player.typeId !== "minecraft:player") return false;
  try { if (player.playerPermissionLevel === 2) return true; } catch {}
  try { if (typeof player.commandPermissionLevel === "number" && player.commandPermissionLevel >= 1) return true; } catch {}
  try { if (typeof player.isOp === "function" && player.isOp()) return true; } catch {}
  return false;
}
