const BOSSES=new Set(['rpg:rock_golem_boss','rpg:cyclops_boss','rpg:hydra_boss','rpg:tech_block_golem_boss','minecraft:ender_dragon','minecraft:wither','minecraft:warden']);
const CONTROL=new Set(['slowness','weakness','mining_fatigue','blindness','darkness','nausea','levitation']);
export function isBoss(entity){return BOSSES.has(entity?.typeId);}
export function ccScale(entity){return isBoss(entity)?0.5:1;}
export function ccTicks(entity,ticks){return Math.max(0,Math.ceil(ticks*ccScale(entity)));}
export function applyStatus(entity,id,ticks,options){
 const key=String(id).replace('minecraft:','');
 return entity.addEffect(id,CONTROL.has(key)?ccTicks(entity,ticks):ticks,options);
}
