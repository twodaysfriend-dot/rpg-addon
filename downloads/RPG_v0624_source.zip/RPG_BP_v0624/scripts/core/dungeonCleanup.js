import {DUNGEON,DUNGEON_TIERS,inCaveVolume} from '../data/dungeons.js';
const runTypes=new Set(DUNGEON_TIERS.flatMap(t=>[...t.normal,...t.elite,t.boss]).map(id=>'rpg:'+id));
const excluded=new Set(['minecraft:player','minecraft:armor_stand','minecraft:item','minecraft:xp_orb','rpg:gpt_guide']);
export function removableMob(e){
 if(!e?.typeId||excluded.has(e.typeId)||e.typeId.startsWith('rpg:hito_'))return false;
 return runTypes.has(e.typeId)||Boolean(e.getComponent?.('minecraft:health'));
}
export function inFootprint(e,d){
 if(e.dimension?.id!==d.dimId||!e.location)return false;
 const {x,y,z}=e.location;
 return d.shape==='cave_v2'?inCaveVolume(x-d.x,y-d.y,z-d.z):Math.abs(x-d.x)<=21&&Math.abs(z-d.z)<=21&&y>=d.y&&y<=d.y+18;
}
export function cleanDungeonMobs(dim,d,{allInside=false,tracked=[]}={}){
 const found=new Map();for(const e of tracked)if(e?.id)found.set(e.id,e);
 try{for(const e of dim.getEntities({tags:['rpg_dungeon_mob','rpg_dungeon_'+d.id]}))found.set(e.id,e);}catch{}
 if(allInside)try{
  const center={x:d.x,y:d.y+DUNGEON.height/2,z:d.z};
  for(const e of dim.getEntities({location:center,maxDistance:Math.hypot(DUNGEON.radius,DUNGEON.height/2)+2})){
   try{if(inFootprint(e,d)&&removableMob(e))found.set(e.id,e);}catch{}
  }
 }catch{}
 let removed=0;for(const e of found.values())try{
  if(excluded.has(e.typeId)||e.typeId?.startsWith('rpg:hito_'))continue;
  // Cleanup is despawn, so timeout cannot generate XP, loot or false kill credit.
  e.remove();removed++;
 }catch{}
 return removed;
}
