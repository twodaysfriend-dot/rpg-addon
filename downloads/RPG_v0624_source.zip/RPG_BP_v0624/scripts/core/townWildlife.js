import {world,system,EntityInitializationCause} from '@minecraft/server';
import {spawnRegion,insideSpawn} from './spawnEffects.js';
const MANUAL='rpg_town_manual_spawn';
const eggs=[];
function rememberEgg(ev){
 try{const item=ev.itemStack,p=ev.source??ev.player;if(!p||!item?.typeId.startsWith('minecraft:')||!item.typeId.endsWith('_spawn_egg'))return;
  const type=item.typeId.slice(0,-10);if(eggs.some(r=>r.player===p.id&&r.type===type&&r.tick===system.currentTick))return;eggs.push({type,player:p.id,dim:p.dimension.id,at:{...p.location},tick:system.currentTick});
  while(eggs.length>32)eggs.shift();
 }catch{}
}
function eggSpawn(e){
 const index=eggs.findIndex(r=>r.type===e.typeId&&r.dim===e.dimension.id&&system.currentTick-r.tick<=8&&Math.hypot(r.at.x-e.location.x,r.at.y-e.location.y,r.at.z-e.location.z)<=10);
 if(index<0)return false;eggs.splice(index,1);e.addTag(MANUAL);return true;
}
export function insideTownLife(e,s=spawnRegion()){return insideSpawn(e,s)&&e.location.y>=s.y-4&&e.location.y<=s.y+40;}
export function naturalTownSpawn(cause){return cause===(EntityInitializationCause?.Spawned??'Spawned');}
export function protectedTownEntity(e){
 return e.typeId==='minecraft:player'||e.typeId.startsWith('rpg:hito_')||e.typeId==='rpg:gpt_guide'||e.hasTag?.('rpg_dungeon_mob')||(e.hasTag?.(MANUAL)&&!e.hasTag?.('rpg_hunt_zoned'))||!!e.getDynamicProperty?.('rpg:necro_owner')||!!e.getComponent('minecraft:tameable')?.isTamed;
}
export function isTownMonster(e){return !!e.getComponent('minecraft:type_family')?.hasTypeFamily('monster')||e.typeId==='minecraft:bat';}
export function clearTownMonster(e,s=spawnRegion()){
 try{if(insideTownLife(e,s)&&isTownMonster(e)&&!protectedTownEntity(e)&&!eggSpawn(e)){e.remove();return true;}}catch{}return false;
}
export function tickTownWildlife(){
 const s=spawnRegion();if(!s)return;
 try{for(const e of world.getDimension(s.dimId).getEntities({location:{x:s.x,y:s.y-4,z:s.z},volume:{x:250,y:45,z:250}}))clearTownMonster(e,s);}catch{}
}
let registered=false;
export function registerTownWildlife(){
 if(registered)return;registered=true;
 world.beforeEvents?.itemUse?.subscribe(rememberEgg);
 world.beforeEvents?.playerInteractWithBlock?.subscribe(rememberEgg);
 world.afterEvents.itemUse.subscribe(rememberEgg);
 world.afterEvents.entitySpawn.subscribe(ev=>{try{
  const e=ev.entity;
  // Spawn eggs, commands and skills remain intentional. Defer natural spawns
  // until hunting-zone replacement and dungeon/summon ownership tags are set.
  if(ev.cause===(EntityInitializationCause?.Event??'Event')){if(isTownMonster(e))e.addTag(MANUAL);return;}
  system.runTimeout(()=>clearTownMonster(e),4);
 }catch{}});
 world.afterEvents.entityLoad?.subscribe(ev=>system.run(()=>clearTownMonster(ev.entity)));
 system.runInterval(tickTownWildlife,20);
}
