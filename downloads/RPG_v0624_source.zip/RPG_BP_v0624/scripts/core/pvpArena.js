import {world,system} from '@minecraft/server';
import {registerStructureProtection} from './structureProtection.js';
export const ARENA={x:1000,y:250,z:1000,radius:16,dimension:'minecraft:overworld'};
const KEY='rpg:pvp_arena_v1',RETURN='rpg:pvp_arena_return_v1';let building=false,occupants=new Set(),registered=false;
const wait=ticks=>new Promise(resolve=>system.runTimeout(resolve,ticks));
export function arenaReady(){try{return world.getDynamicProperty(KEY)===true;}catch{return false;}}
export function insidePvpArena(p){return p?.dimension?.id===ARENA.dimension&&Math.abs(p.location.x-1000)<16&&Math.abs(p.location.z-1000)<16&&p.location.y>=251&&p.location.y<259;}
export async function createPvpArena(p){
 const admin=p?.playerPermissionLevel===2||p?.commandPermissionLevel>=1||p?.isOp?.()===true;
 if(!admin){p.sendMessage('§cPvP장 생성은 관리자만 가능합니다.');return false;}
 if(building){p.sendMessage('§ePvP장을 생성 중입니다.');return false;}
 if(arenaReady()){p.sendMessage('§bPvP장이 이미 있습니다: 오버월드 1000 250 1000');return true;}
 building=true;let modified=false;
 try{
  p.sendMessage('§bPvP장 생성 준비 중 · 오버월드 1000 250 1000');const dim=world.getDimension('overworld');
  try{dim.runCommand('tickingarea add circle 1000 250 1000 2 rpg_pvp_arena true');}catch{}
  let loaded=false;
  for(let attempt=0;attempt<10;attempt++){try{loaded=Boolean(dim.getBlock({x:1000,y:250,z:1000}));}catch{}if(loaded)break;await wait(20);}
  if(!loaded)throw Error('생성 위치 청크를 불러오지 못했습니다. tickingarea 여유를 확인하거나 해당 위치를 불러온 뒤 다시 실행하세요.');
  // Inspect the full volume before replacing blocks. A failed scan leaves existing builds intact.
  let scanned=0;
  for(let y=250;y<=259;y++)for(let x=984;x<=1016;x++)for(let z=984;z<=1016;z++){
   const block=dim.getBlock({x,y,z});if(!block)throw Error('검사 도중 청크가 해제되었습니다. 다시 실행하세요.');
   const air=block.isAir??['minecraft:air','minecraft:cave_air','minecraft:void_air'].includes(block.typeId);
   if(!air)throw Error('PvP장 범위에 기존 블록이 있습니다. 984~1016 / 높이 250~259 구역을 비운 뒤 다시 실행하세요.');
   if(++scanned%1024===0)await wait(1);
  }
  modified=true;
  dim.runCommand('fill 984 250 984 1016 250 1016 minecraft:obsidian');
  dim.runCommand('fill 984 251 984 1016 255 984 minecraft:quartz_block');
  dim.runCommand('fill 984 251 1016 1016 255 1016 minecraft:quartz_block');
  dim.runCommand('fill 984 251 985 984 255 1015 minecraft:quartz_block');
  dim.runCommand('fill 1016 251 985 1016 255 1015 minecraft:quartz_block');
  dim.runCommand('fill 984 259 984 1016 259 1016 minecraft:glass');
  for(const x of [988,1012])for(const z of [988,1012])dim.runCommand(`setblock ${x} 250 ${z} minecraft:sea_lantern`);
  dim.runCommand('fill 998 250 998 1002 250 1002 minecraft:red_concrete');
  world.setDynamicProperty(KEY,true);p.sendMessage('§aPvP장 생성 완료! 결투 수락 시 자동 이동합니다.');return true;
 }catch(error){p.sendMessage('§c[PvP장] '+String(error.message??error)+(modified?' · 일부 블록이 생성되었을 수 있습니다.':''));return false;}
 finally{building=false;}
}
export function restoreArenaPlayer(p){
 const raw=p.getDynamicProperty(RETURN);if(raw===undefined)return false;
 // Dead players return after respawn; keep the saved destination until then.
 if((p.getComponent('minecraft:health')?.currentValue??0)<=0)return false;
 const saved=JSON.parse(raw);p.teleport(saved.location,{dimension:world.getDimension(saved.dimension),keepVelocity:false,...(saved.rotation?{rotation:saved.rotation}:{})});
 p.setDynamicProperty(RETURN,undefined);return true;
}
export function enterDuelArena(a,b){
 if(!arenaReady())throw Error('관리자가 /pvpcreate 또는 /rpg:pvpcreate로 PvP장을 먼저 생성해야 합니다.');
 if(occupants.size)throw Error('PvP장에서 다른 결투가 진행 중입니다. 잠시 후 다시 신청하세요.');
 for(const p of [a,b])if(p.getDynamicProperty(RETURN)!==undefined)throw Error(p.name+'님의 이전 PvP장 귀환이 대기 중입니다. 재접속 후 다시 신청하세요.');
 const players=[a,b],dim=world.getDimension('overworld');
 try{
  for(const p of players){p.setDynamicProperty(RETURN,JSON.stringify({dimension:p.dimension.id,location:p.location,rotation:p.getRotation?.()}));occupants.add(p.id);}
  for(let i=0;i<2;i++)players[i].teleport({x:1000.5,y:251,z:i?1008.5:992.5},{dimension:dim,keepVelocity:false,facingLocation:{x:1000.5,y:252,z:i?992.5:1008.5}});
 }catch(error){for(const p of players)try{restoreArenaPlayer(p);}catch{}occupants.clear();throw error;}
}
export function releaseDuelArena(ids){for(const id of ids){occupants.delete(id);const p=world.getAllPlayers().find(p=>p.id===id);if(p)try{restoreArenaPlayer(p);}catch(error){console.warn('[RPG PvP arena return] '+error);}}}
export function registerPvpArena(){
 if(registered)return;registered=true;
 registerStructureProtection('pvp_arena',block=>arenaReady()&&block.dimension.id===ARENA.dimension&&block.location.x>=984&&block.location.x<=1016&&block.location.z>=984&&block.location.z<=1016&&block.location.y>=250&&block.location.y<=259);
 system.run(()=>{if(arenaReady())try{world.getDimension('overworld').runCommand('tickingarea add circle 1000 250 1000 2 rpg_pvp_arena true');}catch{}});
}
