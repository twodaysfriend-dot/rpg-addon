import {equippedRunes} from './runeInventory.js';
import {RUNES} from '../data/equipment.js';
import {upgradedRune} from '../data/upgrades.js';
// Upgraded power and arcane rune bonuses add together for basic weapon hits.
export function runeMeleeModifiers(player){
 let bonus=0,physical=1,magicBonus=0;
 for(const stored of equippedRunes(player)){
  if(!['power','arcane'].includes(stored.id))continue;
  const rune=upgradedRune(RUNES[stored.id],stored.level,stored.grade);
  if(stored.id==='power')physical*=rune.physical??1;
  if(stored.level>0){const extra=Math.max(0,(rune.physical??rune.magic??1)-1);bonus+=extra;if(stored.id==='arcane')magicBonus+=extra;}
 }
 return {bonus,physical,magicBonus};
}
export function runeMeleeBonus(player){return runeMeleeModifiers(player).bonus;}
// The World's basic punch already goes through skillDamageFor('physical').
// Preserve that existing physical factor and add the arcane melee bonus once.
export function scriptedMeleeRuneFactor(player){const {physical,magicBonus}=runeMeleeModifiers(player);return (physical+magicBonus)/physical;}
