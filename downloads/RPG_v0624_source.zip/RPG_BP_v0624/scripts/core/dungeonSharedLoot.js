import {world,system} from '@minecraft/server';
import {dungeonRuns} from './dungeonState.js';
import {inFootprint} from './dungeonCleanup.js';
import {alliedOwner} from './supportAllies.js';

export const LOOT_CACHE='rpg:dungeon_loot_cache';
const META='rpg:loot_owner',XP='rpg:loot_xp';
const key=id=>'rpg:loot_mail_'+String(id).replace(/[^a-z0-9_]/gi,'_');
const read=id=>JSON.parse(world.getDynamicProperty(key(id))??'[]');
function save(id,refs){const text=JSON.stringify(refs);if(text.length>29000)throw Error('던전 보관함이 가득 찼습니다. /rpg:dungeonloot');world.setDynamicProperty(key(id),text);}
const pendingLoads=new Set();

export function contributionShares(r){
 const people=r.participants??r.members,weights=people.map(p=>({id:p.id,weight:Math.max(0,r.contribution?.get(p.id)??0)}));
 if(!weights.some(p=>p.weight>0))for(const p of weights)p.weight=1;
 return weights.filter(p=>p.weight>0).sort((a,b)=>a.id.localeCompare(b.id));
}
// Largest remainder allocation conserves every indivisible item and XP point.
export function splitContribution(total,shares,offset=0,carry){
 if(!Number.isSafeInteger(total)||total<0)throw Error('던전 분배 수량 오류');
 const sum=shares.reduce((n,p)=>n+p.weight,0);if(!(sum>0))return [];
 const out=shares.map((p,i)=>{const exact=total*p.weight/sum;return {id:p.id,amount:Math.floor(exact),fraction:exact-Math.floor(exact)+(carry?.get(p.id)??0),tie:(i-offset%shares.length+shares.length)%shares.length};});
 let left=total-out.reduce((n,p)=>n+p.amount,0);
 for(const p of [...out].sort((a,b)=>b.fraction-a.fraction||a.tie-b.tie)){if(left--<=0)break;p.amount++;p.fraction--;}
 if(carry)for(const p of out)carry.set(p.id,p.fraction);
 return out.map(({id,amount})=>({id,amount}));
}
export function recordDungeonDamage(source,target,damage){
 if(!(damage>0))return;
 const owner=alliedOwner(source);
 for(const r of dungeonRuns.values()){
  r.engaged??=new Set();r.contribution??=new Map();
  if(r.health?.has(source?.id)&&r.members.some(p=>p.id===target?.id))r.engaged.add(target.id);
  if(!owner||!r.health?.has(target?.id)||!r.members.some(p=>p.id===owner.id))continue;
  const previous=r.health.get(target.id);let current;
  try{current=target.getComponent('minecraft:health')?.currentValue;}catch{}
  const actual=Number.isFinite(current)?Math.max(0,Math.min(damage,previous-current)):Math.min(damage,previous);
  r.health.set(target.id,Number.isFinite(current)?current:Math.max(0,previous-actual));
  if(actual>0){r.engaged.add(owner.id);r.contribution.set(owner.id,(r.contribution.get(owner.id)??0)+actual);}
 }
}
export function recordDungeonHealing(caster,target,amount){
 if(!(amount>0)||caster?.id===target?.id)return;
 for(const r of dungeonRuns.values())if(r.members.some(p=>p.id===caster?.id)&&r.members.some(p=>p.id===target?.id)&&r.engaged?.has(target.id)){
  r.contribution??=new Map();r.contribution.set(caster.id,(r.contribution.get(caster.id)??0)+amount);
 }
}
function cacheContainer(e){const c=e.getComponent('minecraft:inventory')?.container;if(!c)throw Error('전리품 보관함을 열 수 없습니다.');return c;}
export function settleDungeonGroundLoot(r){
 const shares=contributionShares(r);if(!shares.length)return 0;
 const dim=world.getDimension(r.d.dimId),center={x:r.d.x,y:r.d.y+1,z:r.d.z};
 const entities=dim.getEntities({type:'minecraft:item',location:center,maxDistance:48}).filter(e=>e.typeId==='minecraft:item'&&inFootprint(e,r.d));
 const sources=[];for(const e of entities){const item=e.getComponent('minecraft:item')?.itemStack;if(item)sources.push({entity:e,item:item.clone()});}
 const xp=Math.max(0,Math.floor(r.vanillaXp??0));if(!sources.length&&!xp)return 0;
 const groups=[];for(const s of sources){const match=groups.find(g=>g.item.isStackableWith?.(s.item));if(match)match.count+=s.item.amount;else groups.push({item:s.item,count:s.item.amount});}
 const allocated=new Map(shares.map(p=>[p.id,[]]));let ordinal=r.lootOrdinal??0;
 const remainders=new Map(r.lootRemainders??[]);
 for(const g of groups){for(const part of splitContribution(g.count,shares,ordinal++,remainders)){
  let left=part.amount;while(left>0){const clone=g.item.clone(),take=Math.min(left,clone.maxAmount??64);clone.amount=take;allocated.get(part.id).push(clone);left-=take;}
 }}
 const xpShares=new Map(splitContribution(xp,shares).map(p=>[p.id,p.amount]));
 const created=[],oldRefs=new Map();
 try{
  for(const share of shares){
   const items=allocated.get(share.id),points=xpShares.get(share.id)??0,refs=read(share.id);oldRefs.set(share.id,refs);
   const added=[];let cursor=0,first=true;
   while(cursor<items.length||(first&&points)){
    const e=dim.spawnEntity(LOOT_CACHE,center);created.push(e);e.setDynamicProperty(META,share.id);e.setDynamicProperty(XP,first?points:0);
    const c=cacheContainer(e);if(c.size<1)throw Error('보관함 크기 오류');
    for(let slot=0;slot<c.size&&cursor<items.length;slot++)c.setItem(slot,items[cursor++]);
    added.push({id:e.id,dim:r.d.dimId,at:center});first=false;
   }
   save(share.id,[...refs,...added]);
  }
 }catch(error){for(const [id,refs]of oldRefs)try{save(id,refs);}catch{}for(const e of created)try{e.remove();}catch{}throw error;}
 // Metadata and item stacks are kept in native inventories, never reconstructed
 // from IDs. Remove originals only once the persistent destination exists.
 for(const s of sources)try{s.entity.remove();}catch{}
 r.vanillaXp=0;r.lootOrdinal=ordinal;r.lootRemainders=remainders;
 for(const share of shares){const p=world.getAllPlayers().find(p=>p.id===share.id);if(p)try{claimSharedDungeonLoot(p);}catch{}}
 return sources.reduce((n,s)=>n+s.item.amount,0);
}
function deliverCache(p,e){
 const source=cacheContainer(e),target=p.getComponent('minecraft:inventory')?.container;if(!target)throw Error('가방을 사용할 수 없습니다.');
 const before=Array.from({length:target.size},(_,i)=>target.getItem(i)?.clone()),next=before.map(i=>i?.clone());
 const cached=Array.from({length:source.size},(_,i)=>source.getItem(i)?.clone()),remaining=cached.map(i=>i?.clone());let delivered=0;
 for(let j=0;j<cached.length;j++)if(cached[j]){
  const item=cached[j];let left=item.amount;
  for(let i=1;i<next.length&&left;i++)if(next[i]?.isStackableWith?.(item)){const take=Math.min(left,(item.maxAmount??64)-next[i].amount);if(take>0){next[i].amount+=take;left-=take;}}
  for(let i=1;i<next.length&&left;i++)if(!next[i]){const copy=item.clone(),take=Math.min(left,item.maxAmount??64);copy.amount=take;next[i]=copy;left-=take;}
  delivered+=item.amount-left;if(left){remaining[j]=item.clone();remaining[j].amount=left;}else remaining[j]=undefined;
 }
 try{for(let i=1;i<next.length;i++)target.setItem(i,next[i]);for(let i=0;i<remaining.length;i++)source.setItem(i,remaining[i]);}
 catch(error){for(let i=1;i<before.length;i++)try{target.setItem(i,before[i]);}catch{}for(let i=0;i<cached.length;i++)try{source.setItem(i,cached[i]);}catch{}throw error;}
 const xp=e.getDynamicProperty(XP)??0;
 if(xp){
  const beforeXp=p.getTotalXp();
  try{p.addExperience(xp);e.setDynamicProperty(XP,0);}
  catch(error){try{p.addExperience(beforeXp-p.getTotalXp());e.setDynamicProperty(XP,xp);}catch{}throw error;}
 }
 const pending=remaining.reduce((n,i)=>n+(i?.amount??0),0);if(!pending)e.remove();return {delivered,xp,pending};
}
function warmMail(p,ref){
 if(pendingLoads.has(p.id))return;pendingLoads.add(p.id);
 const dim=world.getDimension(ref.dim),name='rpg_mail_'+String(p.id).replace(/[^a-z0-9]/gi,'').slice(-24);
 try{const {x,y,z}=ref.at;dim.runCommand(`tickingarea add circle ${Math.floor(x)} ${Math.floor(y)} ${Math.floor(z)} 1 ${name} true`);}
 catch{pendingLoads.delete(p.id);return;}
 system.runTimeout(()=>{try{claimSharedDungeonLoot(p,false);}catch{}finally{try{dim.runCommand('tickingarea remove '+name);}catch{}pendingLoads.delete(p.id);}},20);
}
export function claimSharedDungeonLoot(p,load=true){
 if((p.getComponent('minecraft:health')?.currentValue??0)<=0)return {delivered:0,xp:0,pending:read(p.id).length};
 const refs=read(p.id),keep=[];let delivered=0,xp=0;
 for(const ref of refs){
  let e;try{e=world.getEntity?.(ref.id);}catch{}
  if(!e){
   // After a forced chunk load, a missing entity is an already-collected cache.
   let loaded=false;if(!load)try{loaded=Boolean(world.getDimension(ref.dim).getBlock(ref.at));}catch{}
   if(!loaded){keep.push(ref);if(load)warmMail(p,ref);}continue;
  }
  if(e.getDynamicProperty(META)!==p.id)throw Error('전리품 소유자 오류');
  const result=deliverCache(p,e);delivered+=result.delivered;xp+=result.xp;if(result.pending)keep.push(ref);
 }
 save(p.id,keep);return {delivered,xp,pending:keep.length};
}
export function rememberLootCache(entity){
 if(entity?.typeId!==LOOT_CACHE)return;
 const owner=entity.getDynamicProperty(META);if(!owner)return;
 const refs=read(owner);if(!refs.some(r=>r.id===entity.id)){refs.push({id:entity.id,dim:entity.dimension.id,at:entity.location});save(owner,refs);}
}
