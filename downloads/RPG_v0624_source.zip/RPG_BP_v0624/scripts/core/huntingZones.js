import {VANILLA_HOSTILES} from '../data/mobXp.js';
import {world,system} from '@minecraft/server';
import {ZONED_MOBS,huntingZone,huntingNight,chooseZoneMob} from '../data/huntingZones.js';
const VANILLA_CAVE_MOBS=new Set([...VANILLA_HOSTILES,'silverfish','zombie_pigman','zombified_piglin'].map(id=>'minecraft:'+id));
const CAVE_ROOF=new Set(['minecraft:grass_block','minecraft:grass','minecraft:dirt','minecraft:coarse_dirt','minecraft:rooted_dirt','minecraft:stone','minecraft:deepslate','minecraft:tuff','minecraft:calcite','minecraft:dripstone_block','minecraft:granite','minecraft:diorite','minecraft:andesite','minecraft:sand','minecraft:red_sand','minecraft:sandstone','minecraft:red_sandstone','minecraft:gravel','minecraft:clay','minecraft:terracotta','minecraft:mycelium','minecraft:podzol','minecraft:moss_block','minecraft:snow','minecraft:snow_block']);
const PROCESSED='rpg_hunt_zoned';let registered=false;
const manual=[];
export function noteHuntingEggUse(event){
 const id=event.itemStack?.typeId;if(!id?.endsWith('_spawn_egg')||!event.block)return;
 const entityType=id.slice(0,-10);if(!ZONED_MOBS.has(entityType)&&!VANILLA_CAVE_MOBS.has(entityType))return;
 manual.push({type:entityType,dim:event.block.dimension.id,at:{...event.block.location},until:system.currentTick+4});
 while(manual.length>64)manual.shift();
}
function manuallyPlaced(entity){
 for(let i=manual.length-1;i>=0;i--)if(manual[i].until<system.currentTick)manual.splice(i,1);
 const index=manual.findIndex(m=>m.type===entity.typeId&&m.dim===entity.dimension.id&&Math.hypot(m.at.x-entity.location.x,m.at.y-entity.location.y,m.at.z-entity.location.z)<=3);
 if(index<0)return false;manual.splice(index,1);return true;
}
export function applyHuntingZone(entity,{time=world.getTimeOfDay(),random=Math.random}={}){
 if(!entity?.isValid||!ZONED_MOBS.has(entity.typeId)||entity.dimension.id!=='minecraft:overworld')return {action:'ignored'};
 if(entity.hasTag?.(PROCESSED)||entity.hasTag?.('rpg_dungeon_mob')||manuallyPlaced(entity))return {action:'ignored'};
 const zone=huntingZone(entity.location);
 if(!huntingNight(time)||!zone){entity.remove();return {action:'removed'};}
 if(zone.pool.some(m=>m.id===entity.typeId)){entity.addTag(PROCESSED);return {action:'kept',zone:zone.id};}
 const id=chooseZoneMob(zone,random),at={...entity.location};let replacement;
 try{
  replacement=entity.dimension.spawnEntity(id,at);replacement.addTag(PROCESSED);
  try{replacement.setRotation(entity.getRotation());}catch{}
  entity.remove();return {action:'replaced',id,zone:zone.id};
 }catch(error){try{replacement?.remove();}catch{}throw error;}
}
export function cavePosition(dimension,position){
 const x=Math.floor(position.x),z=Math.floor(position.z),lowest=Math.floor(position.y)+2;
 const top=dimension.getTopmostBlock({x,z});if(!top)return undefined;
 if(top.location.y<lowest)return false;
 for(let y=top.location.y;y>=Math.max(lowest,top.location.y-32);y--){
  const block=dimension.getBlock({x,y,z});if(!block)return undefined;
  if(CAVE_ROOF.has(block.typeId)||block.typeId?.endsWith('_ore'))return true;
 }
 return false;
}
export function enforceVanillaCaveSpawn(entity){
 if(!entity?.isValid||entity.dimension.id!=='minecraft:overworld'||!VANILLA_CAVE_MOBS.has(entity.typeId)||manuallyPlaced(entity))return {action:'ignored'};
 const cave=cavePosition(entity.dimension,entity.location);
 if(cave===false){entity.remove();return {action:'removed'};}return {action:cave?'kept':'unloaded'};
}
export function registerHuntingZones(){
 if(registered)return;registered=true;
 world.beforeEvents?.playerInteractWithBlock?.subscribe(noteHuntingEggUse);
 world.afterEvents.entitySpawn.subscribe(event=>{
  if(event.cause!=='Spawned'||(!ZONED_MOBS.has(event.entity?.typeId)&&!VANILLA_CAVE_MOBS.has(event.entity?.typeId)))return;
  // Native rules retain darkness, biome, surface and population checks. Deferral
  // lets dungeon/script spawners attach their exclusion tags before this check.
  system.run(()=>{try{if(VANILLA_CAVE_MOBS.has(event.entity?.typeId))enforceVanillaCaveSpawn(event.entity);else applyHuntingZone(event.entity);}catch(error){console.warn('[RPG hunt zone] '+String(error));}});
 });
}
