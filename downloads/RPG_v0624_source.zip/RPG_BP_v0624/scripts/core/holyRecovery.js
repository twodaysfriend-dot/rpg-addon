import {world,system} from '@minecraft/server';
import {healingFor} from './stats.js';
import {addProgress} from './playerData.js';
import {recordHealedPlayer} from './jobQuests.js';
import {recordCombatHealing} from './combatContribution.js';
import {recordAngelHealing} from './angelHealing.js';
import {isHealingAlly} from './supportAllies.js';
export function healHolyAlly(caster,target,amount,scaled=true){
 if(!caster||!isHealingAlly(caster,target)||!Number.isFinite(amount)||amount<=0)return 0;
 const hp=target?.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return 0;
 const before=hp.currentValue;hp.setCurrentValue(Math.min(hp.effectiveMax,before+(scaled?healingFor(caster,amount):amount)));
 const actual=Math.max(0,hp.currentValue-before);if(actual<=0)return 0;
 addProgress(caster,'job_healing',actual);recordHealedPlayer(caster,target,actual);recordCombatHealing(caster,target,actual);recordAngelHealing(caster,target,actual);return actual;
}
// Source-owned regeneration makes the healing amount attributable. Only the
// strongest holy regeneration heals; stronger external regeneration wins.
const regenerating=new Map(),suppressed=new Map();let registered=false;
function restoreExternal(id){
 const s=suppressed.get(id);suppressed.delete(id);if(!s||s.until<=system.currentTick||!s.target.isValid)return;
 try{const existing=s.target.getEffect('regeneration');if(!existing||existing.amplifier<s.amp)s.target.addEffect('regeneration',s.until-system.currentTick,{amplifier:s.amp,showParticles:false});}catch{}
}
export function applyHolyRegeneration(caster,target,duration,amplifier){
 if(!isHealingAlly(caster,target))return;
 const entries=regenerating.get(target.id)??new Map(),old=entries.get(caster.id);
 entries.set(caster.id,{caster,target,until:system.currentTick+duration,amp:amplifier,next:old?.amp===amplifier?old.next:system.currentTick+Math.max(1,Math.floor(50/2**amplifier))});regenerating.set(target.id,entries);
}
export function tickHolyRecovery(){
 for(const [id,entries]of regenerating){
  for(const [source,s]of entries)if(!s.caster.isValid||!s.target.isValid||s.until<=system.currentTick||s.caster.dimension.id!==s.target.dimension.id||!isHealingAlly(s.caster,s.target))entries.delete(source);
  if(!entries.size){regenerating.delete(id);restoreExternal(id);continue;}
  const s=[...entries.values()].sort((a,b)=>b.amp-a.amp||String(a.caster.id).localeCompare(String(b.caster.id)))[0];
  try{
   const hidden=suppressed.get(id);if(hidden&&hidden.until<=system.currentTick)suppressed.delete(id);
   if(hidden&&hidden.until>system.currentTick&&hidden.amp>=s.amp)restoreExternal(id);
   const external=s.target.getEffect('regeneration');
   if(external&&external.amplifier<s.amp){
    const prior=suppressed.get(id),next={target:s.target,amp:external.amplifier,until:system.currentTick+external.duration};
    if(!prior||next.amp>prior.amp||(next.amp===prior.amp&&next.until>prior.until))suppressed.set(id,next);
    s.target.removeEffect('regeneration');
   }
   if(system.currentTick<s.next)continue;s.next=system.currentTick+Math.max(1,Math.floor(50/2**s.amp));
   if(external&&external.amplifier>=s.amp)continue;
   healHolyAlly(s.caster,s.target,1,false);
  }catch(error){console.warn('[RPG holy recovery] '+String(error));}
 }
}
export function hasHolyRegeneration(target){return (regenerating.get(target.id)?.size??0)>0;}
export function registerHolyRecovery(){if(registered)return;registered=true;system.runInterval(tickHolyRecovery,1);}
