import {openXpShop} from './xpShop.js';
import { ActionFormData } from '@minecraft/server-ui';
import { showForm } from './skillMenu.js';

export const WALLET_KEY = 'rpg:wallet_v1';
export const BALANCE_MAX = 1000000000;
export const CURRENCIES = Object.freeze({gold:'골드', stone:'강화석', dust:'룬 가루'});

export function getWallet(player) {
  const raw = player.getDynamicProperty(WALLET_KEY);
  let saved = {};
  if (raw !== undefined) {
    if (typeof raw !== 'string') throw Error('지갑 데이터 형식 오류');
    saved = JSON.parse(raw);
    if (!saved || typeof saved !== 'object' || Array.isArray(saved)) throw Error('지갑 데이터 형식 오류');
  }
  const wallet = {};
  for (const key of Object.keys(CURRENCIES)) {
    const n = saved[key] ?? 0;
    if (!Number.isSafeInteger(n) || n < 0 || n > BALANCE_MAX) throw Error('지갑 잔액 오류: '+key);
    wallet[key] = n;
  }
  return wallet;
}

export function setWallet(player, wallet) {
  for (const key of Object.keys(CURRENCIES)) {
    if (!Number.isSafeInteger(wallet[key]) || wallet[key] < 0 || wallet[key] > BALANCE_MAX) throw Error('저장할 지갑 잔액 오류: '+key);
  }
  player.setDynamicProperty(WALLET_KEY, JSON.stringify({gold:wallet.gold,stone:wallet.stone,dust:wallet.dust}));
}

export function creditWallet(player, reward) {
  const before = getWallet(player);
  const next = {...before};
  for (const key of Object.keys(CURRENCIES)) {
    const amount = reward[key] ?? 0;
    if (!Number.isSafeInteger(amount) || amount < 0) throw Error('재화 지급량 오류');
    next[key] = Math.min(BALANCE_MAX, before[key] + amount);
  }
  setWallet(player,next);
  return next;
}

export function canAfford(wallet, cost) {
  return Object.keys(CURRENCIES).every(key => Number.isSafeInteger(cost[key]) && cost[key]>=0 && wallet[key]>=cost[key]);
}

export function walletText(wallet) {
  return `§6골드 ${wallet.gold.toLocaleString()} §r/ §b강화석 ${wallet.stone.toLocaleString()} §r/ §d룬 가루 ${wallet.dust.toLocaleString()}`;
}

const open = new Set();
export async function openWalletMenu(player) {
  if (open.has(player.id)) return;
  open.add(player.id);
  try {
    const choice=await showForm(new ActionFormData().title('RPG 재화 지갑').body(walletText(getWallet(player))+
      '\n\n골드: 갑옷·룬 강화 공통 비용\n강화석: 갑옷 강화 전용\n룬 가루: 룬 강화 전용'+
      '\n\n몬스터를 잡아 얻습니다. 엘리트·보스는 더 많이 줍니다.\n파티원도 같은 차원 32블록 안이면 보상을 받습니다.'+
      '\n\n/rpg:upgrade 로 강화 메뉴를 여세요.\n재화는 지갑에 저장되며 사망해도 떨어지지 않습니다.').button('기본 경험치 상점 · 소환알 / 포션 / 촉매').button('닫기'),player);
    if(choice&&!choice.canceled&&choice.selection===0)await openXpShop(player);
  } catch(error) {try {player.sendMessage('§c[RPG] 지갑을 열지 못했습니다: '+String(error));} catch {}}
  finally {open.delete(player.id);}
}
