import {EquipmentSlot} from '@minecraft/server';
export const CHAMELEON_CARD='rpg:chameleon_job_card';
export function hasChameleonCard(p){
 try{return p.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand)?.typeId===CHAMELEON_CARD;}catch{return false;}
}
export function chameleonCardRequirement(p){const met=hasChameleonCard(p);return {met,have:met?1:0,need:1,label:'카멜레온 전직 카드를 손에 들기'};}
