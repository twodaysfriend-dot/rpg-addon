import {world,system,ItemStack} from '@minecraft/server';
import {getJobId} from './playerData.js';
import {isHealingAlly} from './supportAllies.js';
export const ANGEL_HEAL_KEY='rpg:angel_heal_light_v1';
export function readAngelHealing(p){
 const raw=p.getDynamicProperty(ANGEL_HEAL_KEY);if(raw===undefined)return {remainder:0,pending:0};
 const s=JSON.parse(raw);if(!Number.isFinite(s.remainder)||s.remainder<0||s.remainder>=300||!Number.isSafeInteger(s.pending)||s.pending<0)throw Error('천사 회복 보상 데이터 오류');return s;
}
export function claimAngelLight(p){
 const state=readAngelHealing(p);if(!state.pending)return 0;
 const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return 0;
 const before=p.getDynamicProperty(ANGEL_HEAL_KEY),changes=[];let left=state.pending;
 for(let i=1;i<inv.size&&left;i++){
  const old=inv.getItem(i);if(old&&old.typeId!=='rpg:blessing_light')continue;
  const n=Math.min(left,64-(old?.amount??0));if(n<=0)continue;
  const item=old?.clone()??new ItemStack('rpg:blessing_light',1);item.amount=(old?.amount??0)+n;changes.push({i,old:old?.clone(),item});left-=n;
 }
 if(left===state.pending)return 0;
 try{for(const c of changes)inv.setItem(c.i,c.item);p.setDynamicProperty(ANGEL_HEAL_KEY,JSON.stringify({...state,pending:left}));}
 catch(error){for(const c of changes)inv.setItem(c.i,c.old);p.setDynamicProperty(ANGEL_HEAL_KEY,before);throw error;}
 return state.pending-left;
}
export function recordAngelHealing(p,target,amount){
 if(getJobId(p)!=='angel'||p.id===target?.id||!isHealingAlly(p,target)||!Number.isFinite(amount)||amount<=0||(p.getComponent('minecraft:health')?.currentValue??0)<=0||['creative','spectator'].includes(String(p.getGameMode?.()).toLowerCase()))return 0;
 const s=readAngelHealing(p),total=s.remainder+amount,earned=Math.floor((total+1e-8)/300);
 if(!Number.isSafeInteger(s.pending+earned))throw Error('천사 보상 수량 초과');
 p.setDynamicProperty(ANGEL_HEAL_KEY,JSON.stringify({remainder:Math.max(0,total-earned*300),pending:s.pending+earned}));
 try{claimAngelLight(p);}catch(error){console.warn('[RPG angel light] '+String(error));}return earned;
}
let registered=false;
export function registerAngelHealing(){
 if(registered)return;registered=true;
 system.runInterval(()=>{for(const p of world.getAllPlayers())try{claimAngelLight(p);}catch(error){console.warn('[RPG angel light] '+String(error));}},100);
}
