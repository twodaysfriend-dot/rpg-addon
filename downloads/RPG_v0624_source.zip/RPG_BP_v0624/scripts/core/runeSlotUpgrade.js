import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {RUNE_SLOT_UNLOCK_COSTS} from '../data/upgrades.js';
import {RUNE_BAG_KEY,RUNE_SLOTS,readRuneBag,writeRuneBag} from './runeInventory.js';
import {WALLET_KEY,getWallet,setWallet,canAfford,walletText} from './wallet.js';
import {showForm} from './skillMenu.js';

export function runeSlotQuote(player){
  const bag=readRuneBag(player),cost=RUNE_SLOT_UNLOCK_COSTS[bag.unlockedSlots];
  return {unlockedSlots:bag.unlockedSlots,nextSlot:cost?bag.unlockedSlots+1:undefined,cost};
}
export function upgradeRuneSlot(player,expectedSlots){
  try{
    const bag=readRuneBag(player),cost=RUNE_SLOT_UNLOCK_COSTS[bag.unlockedSlots];
    if(!cost)return {ok:false,reason:'이미 모든 룬 장착 슬롯을 해금했습니다.'};
    if(expectedSlots!==undefined&&expectedSlots!==bag.unlockedSlots)return {ok:false,reason:'장착 슬롯 수가 변경됐습니다. 다시 확인하세요.'};
    const wallet=getWallet(player);
    if(!canAfford(wallet,cost))return {ok:false,reason:'슬롯 해금에 필요한 골드 또는 룬 가루가 부족합니다.'};
    const originalBag=player.getDynamicProperty(RUNE_BAG_KEY),originalWallet=player.getDynamicProperty(WALLET_KEY);
    const nextWallet={gold:wallet.gold-cost.gold,stone:wallet.stone-cost.stone,dust:wallet.dust-cost.dust};
    bag.unlockedSlots++;
    try{setWallet(player,nextWallet);writeRuneBag(player,bag);}
    catch(error){
      let recovered=true;
      try{player.setDynamicProperty(RUNE_BAG_KEY,originalBag);}catch{recovered=false;}
      try{player.setDynamicProperty(WALLET_KEY,originalWallet);}catch{recovered=false;}
      if(!recovered)console.error('[RPG rune slots] rollback incomplete: '+String(error));
      return {ok:false,reason:recovered?'슬롯 저장에 실패해 해금을 취소하고 재화를 복구했습니다.':'슬롯 복구에 실패했습니다. 관리자에게 콘텐츠 로그 확인을 요청하세요.'};
    }
    return {ok:true,unlockedSlots:bag.unlockedSlots,cost};
  }catch(error){return {ok:false,reason:'슬롯 강화 오류: '+String(error)};}
}
const open=new Set();
export async function openRuneSlotUpgradeMenu(player){
  if(open.has(player.id))return;open.add(player.id);
  try{
    for(let i=0;i<20&&player.isValid;i++){
      const quote=runeSlotQuote(player);
      const form=new ActionFormData().title('룬 장착 슬롯 강화').body(walletText(getWallet(player))+
        `\n\n장착 가능: ${quote.unlockedSlots} / ${RUNE_SLOTS}개\n기본 3칸에서 순서대로 4·5번째 슬롯을 해금합니다.\n성공률 100% · 해금한 슬롯은 영구 유지됩니다.\n같은 종류의 룬은 하나만 장착할 수 있습니다.`+
        (quote.cost?`\n\n다음 해금: ${quote.nextSlot}번째 슬롯\n비용: 골드 ${quote.cost.gold.toLocaleString()} · 룬 가루 ${quote.cost.dust}개`:'\n\n모든 슬롯을 해금했습니다.'));
      if(quote.cost)form.button(`${quote.nextSlot}번째 슬롯 강화 해금\n성공률 100%`);
      form.button('뒤로');
      const choice=await showForm(form,player);
      if(!choice||choice.canceled||choice.selection!==0||!quote.cost)return;
      const confirm=await showForm(new MessageFormData().title('룬 슬롯 해금 확인')
        .body(`${quote.nextSlot}번째 장착 슬롯을 해금할까요?\n장착 가능 ${quote.unlockedSlots}개 → ${quote.nextSlot}개\n\n골드 ${quote.cost.gold.toLocaleString()} · 룬 가루 ${quote.cost.dust}개 소비\n성공률 100% · 기존 룬과 강화 단계는 유지됩니다.`)
        .button1('취소').button2('강화 해금'),player);
      if(!confirm||confirm.canceled||confirm.selection!==1)continue;
      const result=upgradeRuneSlot(player,quote.unlockedSlots);
      player.sendMessage(result.ok?`§a[RPG] ${result.unlockedSlots}번째 룬 장착 슬롯을 해금했습니다!`:'§c[RPG] '+result.reason);
    }
  }catch(error){try{player.sendMessage('§c[RPG] 슬롯 강화 메뉴 오류: '+String(error));}catch{}}
  finally{open.delete(player.id);}
}
