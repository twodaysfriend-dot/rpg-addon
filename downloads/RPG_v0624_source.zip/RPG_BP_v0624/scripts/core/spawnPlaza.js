// Place a 17 x 17 spawn plaza in an empty area 20 blocks south of the operator.
// Preflight the entire volume before mutation; rollback only blocks/NPCs placed here.
export function createSpawnPlaza(p){
 if(!['minecraft:overworld','overworld'].includes(p.dimension.id)){
  p.sendMessage('§e스폰 광장은 오버월드에서 생성하세요.');return false;
 }
 const dim=p.dimension,c={x:Math.floor(p.location.x),y:Math.floor(p.location.y),z:Math.floor(p.location.z)+20};
 const plan=new Map(),placed=[],npcs=[];
 const add=(x,y,z,type)=>plan.set(`${x},${y},${z}`,{at:{x:c.x+x,y:c.y+y,z:c.z+z},type});
 try{
  for(let x=-8;x<=8;x++)for(let z=-8;z<=8;z++)for(let y=0;y<=5;y++){
   const b=dim.getBlock({x:c.x+x,y:c.y+y,z:c.z+z});
   if(!b?.isAir)throw Error('남쪽 20칸 중심의 17×17×6 공간이 비어 있어야 합니다. 지형·건물·미로딩 청크는 변경하지 않습니다.');
  }
  if(dim.getEntities({location:{x:c.x,y:c.y+2,z:c.z},maxDistance:15}).some(e=>e.typeId!=='minecraft:item'&&e.typeId!=='minecraft:xp_orb'))throw Error('생성할 공간에 플레이어 또는 몹이 있습니다.');
  for(let x=-8;x<=8;x++)for(let z=-8;z<=8;z++)add(x,0,z,Math.abs(x)===8||Math.abs(z)===8?'minecraft:stone_bricks':'minecraft:smooth_quartz');
  for(let i=-7;i<=7;i++){add(i,0,0,'minecraft:polished_deepslate');add(0,0,i,'minecraft:polished_deepslate');}
  add(0,0,0,'minecraft:gold_block');
  for(const x of [-7,7])for(const z of [-7,7]){for(let y=1;y<=3;y++)add(x,y,z,'minecraft:stone_bricks');add(x,4,z,'minecraft:sea_lantern');}
  // Low walls leave the four entrances open.
  for(let n=-6;n<=6;n++)if(Math.abs(n)>1)for(const sign of [-1,1]){add(n,1,sign*8,'minecraft:stone_brick_wall');add(sign*8,1,n,'minecraft:stone_brick_wall');}
  for(const entry of plan.values()){
   const block=dim.getBlock(entry.at);if(!block?.isAir)throw Error('생성 공간이 변경되었습니다.');
   block.setType(entry.type);placed.push(entry.at);
  }
  for(const [type,x,z] of [['nen',-4,4],['the_world',0,4],['war_god',4,4],['archer',-5,-4],['holy',-2,-4],['sword',2,-4],['mage',5,-4],['fist',-5,0]])npcs.push(dim.spawnEntity('rpg:hito_'+type,{x:c.x+x+.5,y:c.y+1,z:c.z+z+.5}));
  p.sendMessage(`§a17×17 스폰 광장 생성 완료: ${c.x} ${c.y+1} ${c.z}\n§7궁수·성직자·검사·마법사·무투가·넨·더 월드·투신 전직관 배치. 경험치 상점: /rpg:wallet\n§e월드 스폰 지정: /setworldspawn ${c.x} ${c.y+1} ${c.z}`);
  return true;
 }catch(error){
  for(const npc of npcs)try{npc.remove();}catch{}
  let rollbackFailed=false;
  for(const at of placed.reverse())try{dim.getBlock(at).setType('minecraft:air');}catch{rollbackFailed=true;}
  p.sendMessage('§e스폰 광장 생성 실패: '+String(error.message??error)+(rollbackFailed?' 일부 블록 복구 실패: 관리자 확인 필요.':''));return false;
 }
}
