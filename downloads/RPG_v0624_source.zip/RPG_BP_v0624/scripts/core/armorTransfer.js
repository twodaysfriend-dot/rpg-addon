import {itemGrade} from '../data/grades.js';
import {decorateRarity} from './rarityLabels.js';
import {ItemStack,EquipmentSlot} from '@minecraft/server';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {armorInfo} from '../data/equipment.js';
import {ARMOR_LEVEL_KEY,ARMOR_MAX,upgradeLevel} from '../data/upgrades.js';
import {getWallet,setWallet} from './wallet.js';
import {showForm} from './skillMenu.js';
export const TRANSFER_SEAL='rpg:armor_transfer_seal';
const LEVEL='rpg:transfer_level',PART='rpg:transfer_part';
const PART_NAMES={helmet:'투구',chestplate:'흉갑',leggings:'각반',boots:'장화'};
const EQUIPPED=()=>[EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet];
function inventory(p){return p.getComponent('minecraft:inventory')?.container;}
function read(p,ref){return ref?.kind==='equipment'?p.getComponent('minecraft:equippable')?.getEquipment(ref.slot):ref?.kind==='inventory'&&Number.isInteger(ref.slot)&&ref.slot>=0&&ref.slot<(inventory(p)?.size??0)?inventory(p).getItem(ref.slot):undefined;}
function write(p,ref,item){if(ref.kind==='equipment'){if(!p.getComponent('minecraft:equippable')?.setEquipment(ref.slot,item))throw Error('장비 저장 실패');}else inventory(p).setItem(ref.slot,item);}
export function transferFingerprint(item){
 if(!item)return '';
 let durability,enchantments;try{durability=item.getComponent('minecraft:durability')?.damage;enchantments=item.getComponent('minecraft:enchantable')?.getEnchantments().map(e=>[e.type.id,e.level]).sort();}catch{}
 return JSON.stringify([item.typeId,itemGrade(item),item.amount,item.nameTag??'',item.getLore(),upgradeLevel(item,'armor'),item.getDynamicProperty(LEVEL),item.getDynamicProperty(PART),durability,enchantments]);
}
export function readTransferSeal(item){
 if(item?.typeId!==TRANSFER_SEAL||item.amount!==1)return undefined;
 const level=item.getDynamicProperty(LEVEL),part=item.getDynamicProperty(PART);
 return Number.isInteger(level)&&level>0&&level<=ARMOR_MAX&&Object.prototype.hasOwnProperty.call(PART_NAMES,part)?{level,part}:undefined;
}
function enhanced(item,level){
 const next=item.clone();next.setDynamicProperty(ARMOR_LEVEL_KEY,level);
 const lore=next.getLore().filter(s=>!s.startsWith('§7강화:'));if(level>0)lore.push(`§7강화: +${level} · 최대 HP +${level}`);next.setLore(lore);decorateRarity(next);return next;
}
export function extractArmorEnhancement(p,ref,expected){
 try{
  const item=read(p,ref),info=armorInfo(item?.typeId),level=upgradeLevel(item,'armor');
  if(!info||level<=0||item.amount!==1)return {ok:false,reason:'강화된 RPG 갑옷을 선택하세요.'};
  if(expected!==undefined&&expected!==transferFingerprint(item))return {ok:false,reason:'선택한 장비가 변경됐습니다.'};
  const inv=inventory(p);if(!inv)return {ok:false,reason:'인벤토리가 없습니다.'};let slot=-1;
  for(let i=1;i<inv.size;i++)if(!inv.getItem(i)){slot=i;break;}
  if(slot<0)return {ok:false,reason:'첫 무기 칸을 제외한 빈 인벤토리 칸이 필요합니다.'};
  const wallet=getWallet(p),cost=500*level;if(wallet.gold<cost)return {ok:false,reason:`추출 비용 골드 ${cost}가 필요합니다.`};
  const seal=new ItemStack(TRANSFER_SEAL,1);seal.setDynamicProperty(LEVEL,level);seal.setDynamicProperty(PART,info.part);
  seal.nameTag=`§b${PART_NAMES[info.part]} 강화 이전서 +${level}`;seal.setLore(['§7/rpg:transfer에서 같은 부위 RPG 갑옷에 적용',`§7강화 +${level} · 100% 이전 · 적용 시 이전서 소모`]);
  try{setWallet(p,{...wallet,gold:wallet.gold-cost});write(p,ref,enhanced(item,0));inv.setItem(slot,seal);}
  catch(error){let recovered=true;for(const undo of [()=>write(p,ref,item),()=>inv.setItem(slot,undefined),()=>setWallet(p,wallet)])try{undo();}catch{recovered=false;}return {ok:false,reason:recovered?'저장 실패로 추출을 취소하고 복구했습니다.':'추출 복구 실패. 관리자에게 문의하세요.'};}
  return {ok:true,level,part:info.part,slot,cost};
 }catch{return {ok:false,reason:'강화 추출을 처리하지 못했습니다.'};}
}
export function applyArmorEnhancement(p,sealSlot,targetRef,expectedSeal,expectedTarget){
 try{
  if(targetRef?.kind==='inventory'&&targetRef.slot===sealSlot)return {ok:false,reason:'이전서와 장비가 같은 칸입니다.'};
  const inv=inventory(p),seal=Number.isInteger(sealSlot)&&sealSlot>=0&&sealSlot<(inv?.size??0)?inv.getItem(sealSlot):undefined,record=readTransferSeal(seal),item=read(p,targetRef),info=armorInfo(item?.typeId);
  if(!record||!info||item.amount!==1)return {ok:false,reason:'유효한 이전서와 RPG 갑옷을 선택하세요.'};
  if(info.part!==record.part)return {ok:false,reason:'이전서는 같은 부위에만 적용할 수 있습니다.'};
  if(upgradeLevel(item,'armor')>=record.level)return {ok:false,reason:'대상 강화 단계가 같거나 높습니다.'};
  if((expectedSeal!==undefined&&expectedSeal!==transferFingerprint(seal))||(expectedTarget!==undefined&&expectedTarget!==transferFingerprint(item)))return {ok:false,reason:'이전서 또는 장비가 변경됐습니다.'};
  try{write(p,targetRef,enhanced(item,record.level));inv.setItem(sealSlot,undefined);}
  catch{let recovered=true;for(const undo of [()=>write(p,targetRef,item),()=>inv.setItem(sealSlot,seal)])try{undo();}catch{recovered=false;}return {ok:false,reason:recovered?'저장 실패로 이전을 취소하고 복구했습니다.':'강화 이전 복구 실패. 관리자에게 문의하세요.'};}
  return {ok:true,...record};
 }catch{return {ok:false,reason:'강화 이전을 처리하지 못했습니다.'};}
}
function armorOptions(p){
 const result=[];for(const slot of EQUIPPED()){const ref={kind:'equipment',slot},item=read(p,ref);if(armorInfo(item?.typeId))result.push({ref,item});}
 const inv=inventory(p);if(inv)for(let slot=0;slot<inv.size;slot++){const ref={kind:'inventory',slot},item=inv.getItem(slot);if(armorInfo(item?.typeId))result.push({ref,item});}return result;
}
const opened=new Set();
export async function openArmorTransfer(p){
 if(opened.has(p.id))return;opened.add(p.id);
 try{
  const options=armorOptions(p).filter(e=>upgradeLevel(e.item,'armor')>0).map(e=>({...e,mode:'extract'})),inv=inventory(p);
  if(inv)for(let slot=0;slot<inv.size;slot++){const item=inv.getItem(slot);if(readTransferSeal(item))options.push({mode:'apply',slot,item});}
  const form=new ActionFormData().title('갑옷 강화 이전').body('1. 제작 전 강화를 이전서로 추출합니다(단계당 골드 500). 원래 갑옷은 +0이 됩니다.\n2. 새 갑옷을 제작합니다.\n3. 같은 부위의 새 RPG 갑옷에 이전서를 적용합니다(성공 100%, 이전서 소모).\n인챈트·내구도·룬은 이전하지 않습니다.');
  for(const o of options){const info=armorInfo(o.item.typeId),r=readTransferSeal(o.item);form.button(o.mode==='extract'?`추출: ${info.name} ${PART_NAMES[info.part]} +${upgradeLevel(o.item,'armor')}`:`적용: ${PART_NAMES[r.part]} 이전서 +${r.level}`);}form.button('닫기');
  const pick=await showForm(form,p);if(!pick||pick.canceled||pick.selection==null||pick.selection>=options.length)return;
  const o=options[pick.selection],fingerprint=transferFingerprint(o.item);let result;
  if(o.mode==='extract'){
   const level=upgradeLevel(o.item,'armor'),confirm=await showForm(new MessageFormData().title('강화 추출 확인').body(`골드 ${500*level} 소비. 원래 갑옷 강화는 0이 되고 +${level} 이전서를 받습니다. 제작하기 전에 추출하세요.`).button1('취소').button2('추출'),p);
   if(!confirm||confirm.canceled||confirm.selection!==1)return;result=extractArmorEnhancement(p,o.ref,fingerprint);
  }else{
   const record=readTransferSeal(o.item),targets=armorOptions(p).filter(e=>armorInfo(e.item.typeId).part===record.part&&upgradeLevel(e.item,'armor')<record.level),f=new ActionFormData().title('강화를 받을 갑옷').body('기존보다 높은 단계로 교체하며 합산하지 않습니다. 대상 갑옷의 인챈트·내구도는 유지합니다.');
   for(const t of targets)f.button(`${armorInfo(t.item.typeId).name} ${PART_NAMES[record.part]} +${upgradeLevel(t.item,'armor')} → +${record.level}`);f.button('닫기');
   const choice=await showForm(f,p);if(!choice||choice.canceled||choice.selection==null||choice.selection>=targets.length)return;
   const t=targets[choice.selection],confirm=await showForm(new MessageFormData().title('강화 이전 확인').body(`대상을 +${record.level}로 변경하고 이전서 1개를 소모합니다. 성공률 100%.`).button1('취소').button2('이전'),p);
   if(!confirm||confirm.canceled||confirm.selection!==1)return;result=applyArmorEnhancement(p,o.slot,t.ref,fingerprint,transferFingerprint(t.item));
  }
  p.sendMessage(result.ok?`§a강화 ${o.mode==='extract'?'추출':'이전'} 완료: +${result.level}`:'§e'+result.reason);
 }catch{try{p.sendMessage('§e강화 이전 메뉴를 열지 못했습니다. 다시 시도하세요.');}catch{}}
 finally{opened.delete(p.id);}
}
