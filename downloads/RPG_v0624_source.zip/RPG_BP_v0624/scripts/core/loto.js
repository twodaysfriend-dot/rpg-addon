import {discoverJob} from './jobDiscovery.js';
import { world, system, ItemStack } from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { JOBS } from "../data/jobs.js";
import { applyAdvance } from "./advance.js";
import { getJobId } from "./playerData.js";

const TALKS_KEY = "rpg:loto_talk_count";
const REWARDED_KEY = "rpg:loto_rewarded";
const WORLD_WINNER_KEY = "rpg:loto_first_hacker";
const REQUIRED_TALKS = 23;
const busy = new Set();

async function safeShow(form, player) {
  for(let attempts=0; attempts<8; attempts++) {
    if(!player?.isValid) return undefined;
    const result = await form.show(player);
    if(!result?.canceled || String(result.cancelationReason) !== "UserBusy") return result;
    await new Promise(resolve=>system.runTimeout(resolve,8));
  }
  return undefined;
}

function getTalkCount(player) {
  const v = Number(player.getDynamicProperty(TALKS_KEY) ?? 0);
  return Number.isFinite(v) && v >= 0 ? Math.floor(v) : 0;
}

function giveEnchantedApple(player) {
  const inventory = player.getComponent("minecraft:inventory")?.container;
  const item = new ItemStack("minecraft:enchanted_golden_apple",1);
  if (inventory) {
    const leftover=inventory.addItem(item);
    if(leftover) player.dimension.spawnItem(leftover,player.location);
  } else {
    player.dimension.spawnItem(item,player.location);
  }
}

export async function openLotoDialogue(player) {
  if(!player?.isValid || busy.has(player.id)) return;
  discoverJob(player,'hacker');
  busy.add(player.id);
  try {
    // All NPCs share this counter for each player, including after rejoining the world.
    if(player.getDynamicProperty(REWARDED_KEY) === true) {
      await safeShow(new ActionFormData().title("로토")
        .body("로토: 너한테 줄 보상은 이미 줬잖아! 다음엔 코딩 연습도 해봐.")
        .button("알겠어"),player);
      return;
    }

    const count = getTalkCount(player)+1;
    player.setDynamicProperty(TALKS_KEY,count);
    if(count < REQUIRED_TALKS) {
      await safeShow(new ActionFormData().title("로토")
        .body("안녕 난 코딩 전문 로토야!")
        .button("대화 종료"),player);
      return;
    }

    // Type a C declaration. Multiple equivalent placements of whitespace are valid.
    const form = new ModalFormData().title("로토")
      .textField("너 되게 집요하구나 좋아 퀴즈를 줄게!\n다음 중 C언어에서 포인터 변수 x를 올바르게 선언한 것은 무엇일까?",
        "정답을 입력해 줘", {defaultValue:""})
      .submitButton("정답 제출");
    const result = await safeShow(form,player);
    if(!result || result.canceled) return;
    const answer = String(result.formValues?.[0] ?? "").trim();
    if(!/^int\s*\*\s*x\s*;$/.test(answer)) {
      await safeShow(new ActionFormData().title("로토")
        .body("오답이야! 다시 생각해 보고 말을 걸어봐.")
        .button("확인"),player);
      return;
    }
    if(player.getDynamicProperty(REWARDED_KEY) === true) return;

    const previousWinner = world.getDynamicProperty(WORLD_WINNER_KEY);
    if(previousWinner === player.id) {
      await safeShow(new ActionFormData().title("로토")
        .body("정답! 너는 이미 이 월드의 첫 번째 해커야. 보상은 한 번만 받을 수 있어!")
        .button("확인"),player);
      return;
    }
    if(previousWinner === undefined || previousWinner === null || previousWinner === "") {
      // Persist the first winner BEFORE giving the job; another completed quiz
      // cannot award a second hacker job in the same world.
      const oldJob = getJobId(player);
      if(oldJob === "hacker") {
        await safeShow(new ActionFormData().title("로토")
          .body("정답! 근데 너는 이미 해커잖아? 이 문제는 다른 사람에게 남겨둘게.")
          .button("확인"),player);
        return;
      }
      world.setDynamicProperty(WORLD_WINNER_KEY,player.id);
      try {
        applyAdvance(player,JOBS.hacker);
      } catch(error) {
        world.setDynamicProperty(WORLD_WINNER_KEY,undefined);
        throw error;
      }
      // The world-level winner is authoritative even if this player property fails.
      try { player.setDynamicProperty(REWARDED_KEY,true); } catch {}
      await safeShow(new ActionFormData().title("로토")
        .body("정답! 처음으로 문제를 맞혔구나. 상으로 너를 해커로 전직시켜 줄게!\n\n§a해커 전직 완료!")
        .button("고마워!"),player);
      return;
    }

    player.setDynamicProperty(REWARDED_KEY,true);
    try { giveEnchantedApple(player); }
    catch(error) {
      player.setDynamicProperty(REWARDED_KEY,undefined);
      throw error;
    }
    await safeShow(new ActionFormData().title("로토")
      .body("정답! 하지만 이미 최초의 해커가 탄생했어. 대신 인챈트된 황금사과 1개를 줄게!")
      .button("보상 받았어!"),player);
  } catch(error) {
    try {player.sendMessage("§c[로토] 대화 처리 오류: " + String(error).slice(0,230));} catch {}
  } finally {busy.delete(player.id);}
}

export function clearLotoRuntime(playerId){ busy.delete(playerId); }
