import {HITO_LINES} from './hito.js';
import { ItemStack, system } from "@minecraft/server";
import * as UI from "@minecraft/server-ui";

const GROUPS = [
  {name:"전직관",ids:HITO_LINES.map(line=>["rpg:hito_"+line.id,line.id==="hacker"?"로토":line.label+" 전직관"])},
  { name: "일반 몬스터", ids: [
    ["rpg:red_mushroom", "빨간 버섯"], ["rpg:blue_mushroom", "파란 버섯"],
    ["rpg:green_goblin", "초록 고블린"], ["rpg:red_goblin", "빨간 고블린"],
    ["rpg:gold_goblin", "황금 고블린"], ["rpg:goblin_captain", "대장 고블린"]
  ] },
  { name: "엘리트 몬스터 ✦", ids: [
    ["rpg:elite_red_mushroom", "엘리트 빨간 버섯"], ["rpg:elite_blue_mushroom", "엘리트 파란 버섯"],
    ["rpg:elite_green_goblin", "엘리트 초록 고블린"], ["rpg:elite_red_goblin", "엘리트 빨간 고블린"],
    ["rpg:elite_gold_goblin", "엘리트 황금 고블린"], ["rpg:elite_goblin_captain", "엘리트 대장 고블린"]
  ] },
  { name: "사막 대형 몬스터", ids: [
    ["rpg:scorpion", "사막 전갈"], ["rpg:mantis", "사막 사마귀"], ["rpg:deathworm", "사막 데스웜"]
  ] },
  { name: "사막 엘리트 · 필드보스", ids: [
    ["rpg:elite_scorpion", "엘리트 사막 전갈"], ["rpg:elite_mantis", "엘리트 사막 사마귀"],
    ["rpg:elite_deathworm", "엘리트 데스웜 (필드보스)"]
  ] },
  { name: "보스", ids: [
    ["rpg:rock_golem_boss", "바위 골렘"],
    ["rpg:cyclops_boss", "외눈박이 거인"],
    ["rpg:hydra_boss", "지옥의 히드라"],
    ["rpg:tech_block_golem_boss", "마공학 블럭 골렘"]
  ] },
  { name: "기타", ids: [
    ["rpg:sandbag_entity", "훈련 샌드백"]
  ] }
];

const TOTAL_EGGS = GROUPS.reduce((total, group) => total + group.ids.length, 0);
const active = new Set();
const busy = UI.FormCancelationReason?.UserBusy ?? "UserBusy";

async function display(form, player) {
  for (let tries = 0; tries < 10; tries++) {
    if (!player.isValid) return undefined;
    const result = await form.show(player);
    if (!result.canceled || result.cancelationReason !== busy) return result;
    await new Promise(resolve => system.runTimeout(resolve, 10));
  }
  player.sendMessage("§c[RPG] 채팅창을 닫고 /rpg:egg 명령어를 다시 입력하세요.");
  return undefined;
}

function give(player, id, name) {
  const eggId = id + "_spawn_egg";
  try {
    const inv = player.getComponent("minecraft:inventory")?.container;
    if (!inv) throw Error("인벤토리 접근 불가");
    const remain = inv.addItem(new ItemStack(eggId, 1));
    if (remain) {
      player.sendMessage("§c인벤토리 공간이 부족합니다. 빈칸을 만든 뒤 다시 시도하세요.");
      return false;
    }
    player.sendMessage("§a[RPG] §f" + name + "§a 소환 알을 받았습니다.");
    return true;
  } catch (error) {
    // Fallback for older runtimes which cannot create the generated egg through ItemStack.
    try {
      player.runCommand("give @s " + eggId + " 1");
      player.sendMessage("§a[RPG] §f" + name + "§a 소환 알을 받았습니다.");
      return true;
    } catch (second) {
      player.sendMessage("§c[RPG] " + name + " 소환 알 지급 실패: " + String(second).slice(0,100));
      return false;
    }
  }
}

export async function openEggMenu(player) {
  if (!player?.isValid || active.has(player.id)) return;
  active.add(player.id);
  try {
    for (;;) {
      const root = new UI.ActionFormData().title("RPG 몬스터·전직관 소환알")
        .body("원하는 종류를 선택하세요. 각 알은 1개씩 지급됩니다.");
      for (const group of GROUPS) root.button(group.name + " (" + group.ids.length + "종)");
      root.button("§a모든 소환 알 받기 (" + TOTAL_EGGS + "종)");
      root.button("닫기");
      const answer = await display(root, player);
      if (!answer || answer.canceled || answer.selection >= GROUPS.length + 1) return;
      if (answer.selection === GROUPS.length) {
        let count = 0;
        for (const group of GROUPS) for (const [id, name] of group.ids) {
          if (give(player, id, name)) count++;
        }
        player.sendMessage("§e[RPG] 소환 알 " + count + "/" + TOTAL_EGGS + "종 지급 완료");
        return;
      }
      const group = GROUPS[answer.selection];
      const pick = new UI.ActionFormData().title(group.name + " 소환 알").body("받을 몬스터를 고르세요.");
      for (const [id, name] of group.ids) pick.button(name);
      pick.button("§a이 그룹 모두 받기");
      pick.button("뒤로");
      const selection = await display(pick, player);
      if (!selection || selection.canceled) return;
      if (selection.selection === group.ids.length + 1) continue;
      if (selection.selection === group.ids.length) {
        for (const [id, name] of group.ids) give(player,id,name);
        return;
      }
      const entry = group.ids[selection.selection];
      if (entry) give(player,entry[0],entry[1]);
      return;
    }
  } catch (error) {
    try { player.sendMessage("§c[RPG] 소환 알 메뉴 오류: " + String(error)); } catch {}
  } finally { active.delete(player.id); }
}
