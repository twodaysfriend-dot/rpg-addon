import {world,system} from '@minecraft/server';
import {MONSTER_CONTEXT_KEY,MONSTER_LEVEL_KEY,MONSTER_LEVELS,wildMonsterLevel,levelRewardMultiplier} from '../data/monsterLevels.js';
import {LEVELED_MONSTERS,MONSTER_NAMES} from '../data/leveledMonsters.js';
export function applyMonsterLevel(entity,level,context){
 if(!LEVELED_MONSTERS.includes(entity?.typeId)||!MONSTER_LEVELS.includes(level)||typeof entity.setDynamicProperty!=='function')return false;
 if(entity.getDynamicProperty(MONSTER_LEVEL_KEY)!==undefined)return false;
 entity.triggerEvent(context?`rpg:dungeon_scaled_${context.tier}_${context.kind}_${context.kind==='normal'?context.index%3:0}`:'rpg:level_'+level);
 entity.setDynamicProperty(MONSTER_LEVEL_KEY,level);
 entity.setDynamicProperty(MONSTER_CONTEXT_KEY,context?JSON.stringify(context):undefined);
 entity.setDynamicProperty('rpg:monster_balance_revision',22);
 const original=entity.nameTag??'';entity.setDynamicProperty('rpg:monster_original_name',original);
 entity.nameTag=`§e[Lv.${level}]§r ${original||MONSTER_NAMES[entity.typeId]}`;
 return true;
}
// Refresh previously spawned wild monsters without healing them on reload.
export function refreshWildMonsterBalance(e){
 if(!LEVELED_MONSTERS.includes(e?.typeId)||e.getComponent('minecraft:tameable')?.isTamed||e.getDynamicProperty?.('rpg:necro_owner')||e.hasTag?.('rpg_dungeon_mob')||e.getDynamicProperty?.(MONSTER_CONTEXT_KEY)||e.getDynamicProperty?.('rpg:monster_balance_revision')===22)return false;
 const level=e.getDynamicProperty(MONSTER_LEVEL_KEY);if(!MONSTER_LEVELS.includes(level))return false;
 const hp=e.getComponent('minecraft:health'),before=hp?.currentValue,max=hp?.effectiveMax;
 e.triggerEvent('rpg:level_'+level);
 const updated=e.getComponent('minecraft:health');
 if(updated&&before>0&&max>0)updated.setCurrentValue(Math.min(updated.effectiveMax,before*updated.effectiveMax/max));
 e.setDynamicProperty('rpg:monster_balance_revision',22);return true;
}
export function registerMonsterLevels(){
 world.afterEvents.entitySpawn.subscribe(ev=>system.run(()=>{
  try{const e=ev.entity;if(!e?.isValid||!LEVELED_MONSTERS.includes(e.typeId)||e.hasTag?.('rpg_dungeon_mob')||e.getComponent('minecraft:tameable')?.isTamed||e.getDynamicProperty('rpg:necro_owner'))return;
   applyMonsterLevel(e,wildMonsterLevel(e.location));
  }catch(error){console.warn('[RPG monster level] '+error);}
 }));
 const refresh=e=>{try{if(e?.isValid)refreshWildMonsterBalance(e);}catch(error){console.warn('[RPG monster balance] '+error);}};
 world.afterEvents.entityLoad?.subscribe(ev=>system.run(()=>refresh(ev.entity)));
 system.run(()=>{for(const name of ['overworld','nether','the_end'])try{for(const e of world.getDimension(name).getEntities())refresh(e);}catch{}});
}
export {levelRewardMultiplier};
