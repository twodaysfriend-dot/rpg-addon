import { system } from '@minecraft/server';
// Sun Blessing: temporary attack state stored in memory only, never across world sessions.
const expiry = new Map();
export function grantPiercing(player, ticks){
  if(!player?.id) return;
  expiry.set(player.id, system.currentTick + Math.max(1,Math.trunc(ticks)));
}
export function hasPiercing(player){
  if(!player?.id) return false;
  const until=expiry.get(player.id);
  if(until===undefined) return false;
  if(until<=system.currentTick){ expiry.delete(player.id); return false; }
  return true;
}
export function clearPiercing(playerId){ expiry.delete(playerId); }
