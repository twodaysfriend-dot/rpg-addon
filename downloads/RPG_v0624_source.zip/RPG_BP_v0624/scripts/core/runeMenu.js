import {openRuneSlotUpgradeMenu} from './runeSlotUpgrade.js';
import {runeRarity,rarityBadge} from '../data/rarity.js';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { RUNES } from '../data/equipment.js';
import { readRuneBag,depositRune,equipRune,unequipRune,withdrawRune,removeRune,migrateChestRune,migrateRetiredRunes,RUNE_CAPACITY,RUNE_SLOTS } from './runeInventory.js';
import { describeRune,openRuneUpgradeMenu } from './upgrades.js';
import { showForm } from './skillMenu.js';
const open=new Set();
export async function openRuneMenu(p){
  if(open.has(p.id))return;open.add(p.id);
  try{
    migrateRetiredRunes(p);
    const migration=migrateChestRune(p);if(!migration.ok)p.sendMessage('§e'+migration.reason);
    for(let loop=0;loop<80&&p.isValid;loop++){
      const bag=readRuneBag(p);
      const slots=bag.equipped.map((uid,i)=>{const r=bag.runes.find(r=>r.uid===uid);return i>=bag.unlockedSlots?`§8${i+1}번: 잠김 (슬롯 강화로 해금)§r`:`${i+1}번: ${r?rarityBadge(runeRarity(r.grade))+' '+RUNES[r.id].name+' +'+r.level:'비어 있음'}`;}).join('\n');
      const form=new ActionFormData().title('룬 전용 보관함').body(`${bag.runes.length}/${RUNE_CAPACITY}칸\n${slots}\n\n${bag.unlockedSlots}/${RUNE_SLOTS}개 장착 가능·같은 종류 중복 불가. 갑옷과 독립적으로 효과를 받습니다.\n강화한 룬은 보관함에서 관리하며 일반 등급 +0 룬만 일반 가방으로 꺼낼 수 있습니다.`);
      form.button('일반 가방의 룬 넣기');form.button('룬 강화');form.button('장착 슬롯 강화 · 해금');
      for(const r of bag.runes)form.button(`${bag.equipped.includes(r.uid)?'§a[장착] ':''}${RUNES[r.id].name} +${r.level}\n${describeRune(r.id,r.level,r.grade)}`);
      form.button('닫기');const choice=await showForm(form,p);
      if(!choice||choice.canceled||choice.selection==null||choice.selection>=bag.runes.length+3)return;
      if(choice.selection===0){
        const inv=p.getComponent('minecraft:inventory')?.container,entries=[];
        const f=new ActionFormData().title('룬 넣기').body('한 번 선택하면 룬 1개를 보관합니다.');
        if(inv)for(let i=0;i<inv.size;i++){const t=inv.getItem(i),id=t?.typeId?.replace('rpg:rune_','');if(t?.typeId==='rpg:rune_'+id&&RUNES[id]){entries.push(i);f.button(RUNES[id].name+' ×'+t.amount);}}
        f.button('뒤로');const r=await showForm(f,p);if(r&&!r.canceled&&r.selection<entries.length){const result=depositRune(p,entries[r.selection]);if(!result.ok)p.sendMessage('§c'+result.reason);}continue;
      }
      if(choice.selection===1){await openRuneUpgradeMenu(p);continue;}
      if(choice.selection===2){await openRuneSlotUpgradeMenu(p);continue;}
      const rune=bag.runes[choice.selection-3];
      const f=new ActionFormData().title(RUNES[rune.id].name+' +'+rune.level).body(describeRune(rune.id,rune.level,rune.grade));
      for(let i=0;i<RUNE_SLOTS;i++)f.button(i<bag.unlockedSlots?`${i+1}번 칸 장착`:`§8${i+1}번 칸 잠김 · 슬롯 강화`);
      f.button('장착 해제').button('일반 가방으로 꺼내기 (일반 +0)').button('룬 삭제').button('뒤로');
      const r=await showForm(f,p);if(!r||r.canceled||r.selection==null)continue;
      if(r.selection<RUNE_SLOTS){if(r.selection>=bag.unlockedSlots){await openRuneSlotUpgradeMenu(p);continue;}const result=equipRune(p,rune.uid,r.selection);if(!result.ok)p.sendMessage('§c'+result.reason);}
      else if(r.selection===RUNE_SLOTS)unequipRune(p,rune.uid);
      else if(r.selection===RUNE_SLOTS+1){const result=withdrawRune(p,rune.uid);if(!result.ok)p.sendMessage('§c'+result.reason);}
      else if(r.selection===RUNE_SLOTS+2){const yes=await showForm(new MessageFormData().title('룬 삭제').body('이 룬과 강화 단계가 영구 삭제됩니다.').button1('취소').button2('삭제'),p);if(yes&&!yes.canceled&&yes.selection===1)removeRune(p,rune.uid);}
    }
  }catch(error){try{p.sendMessage('§c[RPG] '+String(error));}catch{}}
  finally{open.delete(p.id);}
}
