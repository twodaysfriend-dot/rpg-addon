import { world, system } from "@minecraft/server";

// 타락검성 '광분화' runtime: 20초 동안 플레이어가 직접 준 피해의 30%를 회복합니다.
const activeUntil = new Map();
const lastHealFx = new Map();

export function beginFrenzy(player, durationTicks = 400, lifesteal = 0.30) {
  const endTick = system.currentTick + durationTicks;
  activeUntil.set(player.id, { endTick, lifesteal });
  player.sendMessage("§c§l[광분화] §r§420초간 입힌 피해의 30%를 흡혈합니다!");
  try { player.dimension.playSound("mob.wither.spawn", player.location, { volume: 0.7, pitch: 1.2 }); } catch {}
  try { player.dimension.spawnParticle("minecraft:soul_particle", { x: player.location.x, y: player.location.y + 1.2, z: player.location.z }); } catch {}
}

export function isFrenzyActive(player) {
  const state = activeUntil.get(player.id);
  if (!state) return false;
  if (system.currentTick >= state.endTick) {
    activeUntil.delete(player.id);
    lastHealFx.delete(player.id);
    return false;
  }
  return true;
}

export function registerFrenzy() {
  world.afterEvents.entityHurt.subscribe((ev) => {
    try {
      const attacker = ev.damageSource?.damagingEntity;
      const target = ev.hurtEntity;
      if (!attacker || attacker.typeId !== "minecraft:player" || !target || target.id === attacker.id) return;
      const state = activeUntil.get(attacker.id);
      if (!state || system.currentTick >= state.endTick) return;
      const dealt = Math.max(0, Number(ev.damage) || 0);
      if (dealt <= 0) return;
      const hp = attacker.getComponent("minecraft:health");
      if (!hp || hp.currentValue <= 0 || hp.currentValue >= hp.effectiveMax) return;
      const healing = dealt * state.lifesteal;
      hp.setCurrentValue(Math.min(hp.effectiveMax, hp.currentValue + healing));
      // 연속 타격 시 과도하게 많은 파티클이 생성되지 않도록 시각 효과를 제한합니다.
      const last = lastHealFx.get(attacker.id) ?? -1000;
      if (system.currentTick - last >= 5) {
        lastHealFx.set(attacker.id, system.currentTick);
        try { attacker.dimension.spawnParticle("minecraft:heart_particle", { x: attacker.location.x, y: attacker.location.y + 1.6, z: attacker.location.z }); } catch {}
      }
    } catch {
      // 피해 이벤트 중 사라진 엔티티나 읽을 수 없는 상태는 무시합니다.
    }
  });

  system.runInterval(() => {
    for (const [playerId, state] of activeUntil.entries()) {
      if (system.currentTick < state.endTick) continue;
      activeUntil.delete(playerId);
      lastHealFx.delete(playerId);
      const p = world.getAllPlayers().find((candidate) => candidate.id === playerId);
      if (p) p.sendMessage("§7[광분화] 효과가 끝났습니다.");
    }
  }, 5);
  world.afterEvents.playerLeave.subscribe((ev) => {
    activeUntil.delete(ev.playerId);
    lastHealFx.delete(ev.playerId);
  });
}
