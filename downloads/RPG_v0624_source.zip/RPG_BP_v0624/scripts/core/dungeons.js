import {newDungeonSite} from './dungeonPlacement.js';
import {isRpgAdmin} from './adminPermissions.js';
import {duelOf} from './pvp.js';
import {dungeonEnrollmentGroup,enrollDungeonGroup} from './dungeonParty.js';
import {restoreFullHealth} from './healthRecovery.js';
import {applyVitality} from './stats.js';
import {registerStructureProtection} from './structureProtection.js';
import {cleanDungeonMobs,removableMob,inFootprint} from './dungeonCleanup.js';
import {insideDungeon,activeDungeonRun} from './dungeonMovement.js';
import {notify} from './hud.js';
import {world,system,ItemStack} from '@minecraft/server';
import {ActionFormData} from '@minecraft/server-ui';
import {DUNGEON,DUNGEON_TIERS,dungeonTier,dungeonBlock,inCaveVolume,ceilingHeight,clearRewardForTier,dungeonTimeLimit,rollDungeonEliteDiamonds,rollDungeonNetherite,rollDungeonAncientDebris,netheriteChanceForTier} from '../data/dungeons.js';
import {isActiveNearbyPlayer} from './xpDistribution.js';
import {healthAlive} from './util.js';
import {creditDungeonClear,claimDungeonLoot} from './dungeonRewards.js';
import {recordSoloDungeonClear} from './newTrials.js';
import {dungeonRuns as runs,dungeonLobbies as lobbies,dungeonHudText} from './dungeonState.js';
import {settleDungeonGroundLoot,rememberLootCache} from './dungeonSharedLoot.js';
import {DUNGEON_NATIVE_XP} from '../data/dungeonNativeXp.js';
import {applyMonsterLevel} from './monsterLevels.js';
import {dungeonMonsterLevel,levelRewardMultiplier} from '../data/monsterLevels.js';
export const DUNGEON_KEY='rpg:dungeons_v1',RETURN_KEY='rpg:dungeon_return_v1';
const builders=new Map(),MOB_TAG='rpg_dungeon_mob';let db,registered=false,maintenanceTick=-20;
const say=(p,s)=>{try{if(p){p.sendMessage(s);notify(p,s);}}catch{}};
export const DUNGEON_BUILD_REVISION=3;
const admin=isRpgAdmin;
function state(){
 if(!db){const raw=world.getDynamicProperty(DUNGEON_KEY);db=raw===undefined?{version:2,nextRun:1,dungeons:[],legacyDungeons:[],outbox:[]}:JSON.parse(raw);
  if(db.version===1){db.legacyDungeons=db.dungeons;db.dungeons=[];db.version=2;}
  if(db.version!==2||!Array.isArray(db.dungeons)||!Array.isArray(db.outbox)||!Number.isSafeInteger(db.nextRun))throw Error('던전 저장 데이터 오류');
  db.legacyDungeons??=[];
 }
 return db;
}
function save(){const raw=JSON.stringify(state());if(raw.length>29000)throw Error('던전 저장 공간 부족');world.setDynamicProperty(DUNGEON_KEY,raw);}
const find=id=>state().dungeons.find(d=>d.id===id);
const allRegistered=()=>[...state().dungeons,...state().legacyDungeons];
const runOf=id=>[...runs.values()].find(r=>r.members.some(m=>m.id===id));
const lobbyOf=id=>[...lobbies.values()].find(l=>l.members.some(m=>m.id===id));
const online=id=>world.getAllPlayers().find(p=>p.id===id);
const dimension=d=>world.getDimension(d.dimId);
const tagFor=d=>'rpg_dungeon_'+d.id;
function inside(p,d){return insideDungeon(p.location,p.dimension.id,d);}
function protectedBlock(b,dimId){return allRegistered().some(d=>{
 if(d.dimId!==dimId)return false;const x=b.location.x-d.x,y=b.location.y-d.y,z=b.location.z-d.z;
 return d.shape==='cave_v2'?inCaveVolume(x,y,z):Math.abs(x)<=21&&Math.abs(z)<=21&&y>=0&&y<=18;
});}
function* volume(d){for(let y=0;y<=DUNGEON.height;y++)for(let x=-DUNGEON.radius;x<=DUNGEON.radius;x++)for(let z=-DUNGEON.radius;z<=DUNGEON.radius;z++)if(inCaveVolume(x,y,z))yield {x:d.x+x,y:d.y+y,z:d.z+z,block:dungeonBlock(x,y,z)};}
function requireAdmin(p){if(!admin(p))throw Error('던전 생성·등록 해제는 관리자만 가능합니다.');}
function requireTier(value){const t=dungeonTier(value);if(!t)throw Error('난이도 1~10을 선택하세요. 예: /rpg:dungeon 1');return t;}
export function listDungeons(){return DUNGEON_TIERS.map(t=>({...t,...find(t.id),status:find(t.id)?.status??'unbuilt',busy:runs.has(t.id),waiting:lobbies.get(t.id)?.members.length??0}));}
function queueBuilder(d,p,repair=false){
 const resume=d.status==='building'||repair;
 builders.set(d.id,{d,p,phase:'load',resume,repair,iterator:volume(d),pending:null,readyTick:0,lastProgressTick:system.currentTick});
 d.status=resume?'building':'queued';delete d.buildError;
}
export function createDungeon(p,value){
 requireAdmin(p);if(p.dimension.id!=='minecraft:overworld')throw Error('던전은 오버월드에서 생성하세요.');
 const tiers=String(value)==='all'?DUNGEON_TIERS:[requireTier(value)],created=[];
 for(const tier of tiers){
  const old=find(tier.id);
  if(builders.has(tier.id)){
   if(tiers.length===1){const job=builders.get(tier.id);job.p=p;say(p,`§e던전 ${tier.tier} 생성 중 (${job.phase}) · ${job.d.x} ${job.d.y} ${job.d.z}. 완료 메시지가 나올 때까지 기다리세요.`);return {tiers:[tier.tier],alreadyBuilding:true};}continue;
  }
  if(runs.has(tier.id)||lobbies.has(tier.id)){if(tiers.length===1)throw Error('대기·전투 중인 던전입니다.');continue;}
  const d=old??newDungeonSite(p,tier,allRegistered());
  if(!old)state().dungeons.push(d);save();queueBuilder(d,p,old?.status==='ready');save();created.push(tier.tier);
 }
 say(p,`§e[던전] 난이도 ${created.join(', ')} 원형 동굴 생성·누락 복구 예약. 완성 검사 후 개방합니다.`);return {tiers:created};
}
function unloadBuildArea(d){
 if(!d.tempArea)return;
 try{dimension(d).runCommand('tickingarea remove '+d.tempArea);}catch{}
 delete d.tempArea;
}
function buildTick(job){
 const {d,p}=job;
 try{
  const dim=dimension(d);
  if(job.phase==='load'){
   d.tempArea='rpg_dng_build_'+d.tier+'_'+Date.now().toString(36);save();
   // A rectangular area covers every chunk touched by the 65-block footprint.
   const r=DUNGEON.radius,result=dim.runCommand(`tickingarea add ${d.x-r} ${d.y} ${d.z-r} ${d.x+r} ${d.y+DUNGEON.height} ${d.z+r} ${d.tempArea} true`);
   if(result?.successCount===0)throw Error('임시 청크 로드 영역을 만들 수 없습니다. 기존 tickingarea 여유를 확인하세요.');
   job.readyTick=system.currentTick+20;job.lastProgressTick=system.currentTick;
   job.phase=job.repair?'repair':'scan';d.status=job.resume?'building':'scanning';save();return;
  }
  if(system.currentTick<job.readyTick)return;
  for(let n=0;n<DUNGEON.buildBudget;n++){
   if(!job.pending){const next=job.iterator.next();if(next.done){
    if(job.phase==='scan'){job.phase='build';d.status='building';save();job.iterator=volume(d);return;}
    if(job.phase!=='verify'){job.phase='verify';job.iterator=volume(d);return;}
    d.buildRevision=DUNGEON_BUILD_REVISION;delete d.buildError;unloadBuildArea(d);d.status='ready';save();builders.delete(d.id);say(p,`§a던전 ${d.tier} 생성·완성 검사 완료 · ${d.x} ${d.y} ${d.z} · 입장: /rpg:dungeon ${d.tier}`);return;
   }job.pending=next.value;}
   const at=job.pending,pos={x:at.x,y:at.y,z:at.z},block=dim.getBlock(pos);
   if(!block){const error=Error('청크 대기');error.name='UnloadedChunkError';throw error;}
   if(job.phase==='scan'){
    if(!block.isAir&&!(job.resume&&at.block===block.typeId))throw Error('기존 블록이 있어 중단했습니다. 지형·건물을 보존합니다. 빈 지역에서 다시 생성하세요.');
   }else if(at.block){
    if(!block.isAir&&block.typeId!==at.block)throw Error('다른 블록을 보존하기 위해 생성·복구를 중단했습니다.');
    if(block.isAir)block.setType(at.block);
    if(job.phase==='verify'&&dim.getBlock(pos)?.typeId!==at.block)throw Error('블록 쓰기 검증에 실패했습니다.');
   }else if(!job.repair&&!block.isAir)throw Error('내부 공간에 다른 블록이 생겨 건설을 중단했습니다.');
   job.pending=null;job.lastProgressTick=system.currentTick;
  }
 }catch(error){
  // Keep the same coordinate when a chunk is temporarily unavailable. Advancing
  // the iterator here used to leave a visibly incomplete cave until manual retry.
  if(job.phase!=='load'&&/chunk|청크/i.test(String(error.name)+' '+String(error.message))&&system.currentTick-job.lastProgressTick<600){job.readyTick=system.currentTick+20;return;}
  builders.delete(d.id);unloadBuildArea(d);
  if(job.phase==='scan'&&!job.resume)state().dungeons=state().dungeons.filter(v=>v!==d);else if(job.phase==='load'&&!job.resume)state().dungeons=state().dungeons.filter(v=>v!==d);else{d.status='building';d.buildError=String(error.message??error).slice(0,180);}
  try{save();}catch{}say(p,'§c던전 생성·복구 대기: '+String(error.message??error));console.warn('[RPG dungeon build] '+String(error));
 }
}

function cleanMobs(d,options={}){try{return cleanDungeonMobs(dimension(d),d,options);}catch{return 0;}}
export function removeDungeon(p,value){
 requireAdmin(p);const tier=dungeonTier(value),d=tier?find(tier.id):state().legacyDungeons.find(d=>d.id===value);
 if(!d)throw Error('등록된 던전이 없습니다.');if(runs.has(d.id)||builders.has(d.id)||lobbies.has(d.id))throw Error('생성·대기·진행 중인 던전은 등록 해제할 수 없습니다.');
 cleanMobs(d);unloadBuildArea(d);state().dungeons=state().dungeons.filter(v=>v!==d);state().legacyDungeons=state().legacyDungeons.filter(v=>v!==d);save();say(p,'§7던전 등록을 해제했습니다. 건축물은 보존합니다.');
}
function returnPlayer(p){
 const raw=p.getDynamicProperty(RETURN_KEY);if(raw===undefined)return true;if(!healthAlive(p))return false;
 const back=JSON.parse(raw);p.teleport(back.location,{dimension:world.getDimension(back.dimId),keepVelocity:false});p.setDynamicProperty(RETURN_KEY,undefined);return true;
}
function finish(r,cleared,reason='탐험이 종료되었습니다.'){
 if(r.finishing)return;
 if(cleared)for(const m of r.members){const p=online(m.id);if(p&&healthAlive(p))enforceDungeonBounds(p,r);}
 r.finishing=true;
 try{settleDungeonGroundLoot(r);}catch(error){console.warn('[RPG shared dungeon loot] '+error);}
 // Native death drops may appear after entityDie. Sweep once more next tick.
 system.runTimeout(()=>{try{settleDungeonGroundLoot(r);}catch(error){console.warn('[RPG shared dungeon late loot] '+error);}},1);
 if(cleared){
  const recipients=r.members.map(m=>online(m.id)).filter(p=>p&&healthAlive(p)&&inside(p,r.d)&&isActiveNearbyPlayer(p,p.location,p.dimension.id,1)),before=state().outbox.length;
  // Persist each player's roll with the receipt before any payment or return.
  for(const p of recipients)state().outbox.push({playerId:p.id,runId:r.id,tier:r.d.tier,solo:r.initialPartySize===1,netherite:rollDungeonNetherite(r.d.tier),ancientDebris:rollDungeonAncientDebris(r.d.tier)});
  try{save();}catch(error){state().outbox.length=before;r.finishing=false;throw error;}
 }
 runs.delete(r.d.id);r.d.activeId=null;if(!cleared)r.d.cleanupPending=true;cleanMobs(r.d,{allInside:!cleared,tracked:[...r.live.values()].map(e=>e.mob)});r.live.clear();
 try{save();}catch(error){console.warn('[RPG dungeon finish save] '+String(error));}
 for(const m of r.members){const p=online(m.id);if(!p)continue;
  say(p,cleared?'§6[던전] 보스 처치 성공! 클리어 보상을 지급하고 귀환합니다.':'§c[던전] '+reason+' 입장 위치로 귀환합니다.');
  try{returnPlayer(p);}catch{say(p,'§c귀환 대기: /rpg:dungeonleave 로 재시도하세요.');}
 }
 flushRewards();
}
function expired(r,now=Date.now()){
 if(now<r.deadline)return false;finish(r,false,r.phase==='boss'?`보스 제한 시간 ${r.initialPartySize===1?'4분 30초':'3분'}을 초과했습니다.`:r.phase==='preparing'?'던전 입장 공간을 불러오지 못했습니다.':`일반·엘리트 제한 시간 ${r.initialPartySize===1?'7분 30초':'5분'}을 초과했습니다.`);return true;
}
function spawnMob(r,kind,index){
 const tier=DUNGEON_TIERS[r.d.tier-1],pool=kind==='normal'?tier.normal:tier.elite,type=kind==='boss'?tier.boss:pool[index%pool.length];
 const angle=(index*2.3999632297+(kind==='elite'?1.2:0)),radius=kind==='boss'?0:18;
 const location={x:r.d.x+Math.cos(angle)*radius,y:r.d.y+1,z:r.d.z+Math.sin(angle)*radius};
 const mob=dimension(r.d).spawnEntity('rpg:'+type,location);
 try{mob.addTag(MOB_TAG);mob.addTag(tagFor(r.d));mob.triggerEvent('rpg:dungeon_tier_'+tier.tier);applyMonsterLevel(mob,dungeonMonsterLevel(tier.tier,kind,index),{tier:tier.tier,kind,index});r.live.set(mob.id,{kind,index,mob});r.health??=new Map();r.health.set(mob.id,mob.getComponent?.('minecraft:health')?.currentValue??0);}
 catch(error){try{mob.remove();}catch{}throw error;}
 return mob;
}
function spawnBoss(r){
 if(r.phase!=='mobs'||r.normalSpawned!==50||r.eliteSpawned!==5||r.normalKilled!==50||r.eliteKilled!==5||r.live.size)return;
 const boss=spawnMob(r,'boss',0);r.bossId=boss.id;r.phase='boss';r.deadline=Date.now()+dungeonTimeLimit('boss',r.initialPartySize);
 for(const m of r.members)say(online(m.id),`§c[던전] 보스 등장! 지금부터 ${r.initialPartySize===1?'4분 30초':'3분'} 안에 처치하세요.`);
}
function spawnTick(r,now){
 if(r.phase!=='mobs'||r.live.size>=DUNGEON.maxAlive)return;
 if(r.live.size===0){
  if(r.normalSpawned<DUNGEON.normalCount&&(r.eliteSpawned>=DUNGEON.eliteCount||r.nextNormalAt<=r.nextEliteAt))r.nextNormalAt=now;
  else if(r.eliteSpawned<DUNGEON.eliteCount)r.nextEliteAt=now;
 }
 if(r.eliteSpawned<DUNGEON.eliteCount&&now>=r.nextEliteAt){spawnMob(r,'elite',r.eliteSpawned++);r.nextEliteAt=Math.max(r.startedAt+(r.eliteSpawned+1)*DUNGEON.eliteIntervalMs,now+DUNGEON.eliteMinGapMs);}
 if(r.normalSpawned<DUNGEON.normalCount&&now>=r.nextNormalAt){
  const count=Math.min(DUNGEON.normalBatch,DUNGEON.normalCount-r.normalSpawned,DUNGEON.maxAlive-r.live.size);
  for(let i=0;i<count;i++){spawnMob(r,'normal',r.normalSpawned);r.normalSpawned++;}r.nextNormalAt=now+DUNGEON.normalIntervalMs;
 }
 spawnBoss(r);
}
export function enterDungeon(p,value,{solo=false}={}){
 flushRewards();const tier=requireTier(value),d=find(tier.id);
 if(!d||d.status!=='ready')throw Error('아직 생성되지 않은 던전입니다. 관리자가 /rpg:dungeoncreate '+tier.tier+' 로 생성해야 합니다.');
 if(runs.has(d.id))throw Error('해당 던전은 진행 중입니다.');
 if(runOf(p.id)||p.getDynamicProperty(RETURN_KEY)!==undefined)throw Error('이미 진행·귀환 중입니다.');
 const lobby=lobbies.get(d.id)??{d,members:[]};
 const group=dungeonEnrollmentGroup(p,solo);
 enrollDungeonGroup(lobby,group,m=>{
  const previous=lobbyOf(m.id);
  if(previous&&previous.d.id!==d.id)throw Error(m.name+'님은 다른 던전 대기실에 참가 중입니다.');
  if(runOf(m.id)||m.getDynamicProperty(RETURN_KEY)!==undefined||duelOf(m))throw Error(m.name+'님은 던전·귀환·결투 진행 중입니다.');
  if(!isActiveNearbyPlayer(m,m.location,m.dimension.id,1))throw Error(m.name+'님은 생존·서바이벌 상태여야 합니다.');
  if(state().outbox.some(o=>o.playerId===m.id))throw Error(m.name+'님의 이전 보상을 먼저 수령하세요.');
 });
 lobbies.set(d.id,lobby);
 for(const m of lobby.members)say(online(m.id),`§e[던전 ${d.tier}] ${p.name} 참가 · ${lobby.members.length}/4명. 첫 참가자가 /rpg:dungeonstart 로 1~4명 출발.`);
 return lobby;
}
export function startDungeon(p){
 const lobby=lobbyOf(p.id);if(!lobby)throw Error('먼저 /rpg:dungeon <1~10> 으로 참가하세요.');if(lobby.members[0].id!==p.id)throw Error('대기실 첫 참가자만 시작할 수 있습니다.');
 const group=lobby.members.map(m=>online(m.id));
 if(!group.length||group.length>4||group.some(m=>!m||!isActiveNearbyPlayer(m,m.location,m.dimension.id,1)))throw Error('대기실 참가자 모두 접속·생존·서바이벌 상태여야 합니다.');
 for(const m of group)if(duelOf(m)||m.getDynamicProperty(RETURN_KEY)!==undefined||runOf(m.id)||state().outbox.some(o=>o.playerId===m.id))throw Error('참가자의 이전 던전 귀환·보상이 대기 중입니다.');
 const d=lobby.d;cleanMobs(d);const now=Date.now(),r={id:state().nextRun++,d,members:[...lobby.members],initialPartySize:group.length,phase:'preparing',live:new Map(),normalSpawned:0,eliteSpawned:0,normalKilled:0,eliteKilled:0,startedAt:now,deadline:now+10000,nextNormalAt:now+DUNGEON.normalIntervalMs,nextEliteAt:now+DUNGEON.eliteIntervalMs,finishing:false,anchors:new Map()};
 r.participants=[...r.members];r.contribution=new Map();r.engaged=new Set();r.health=new Map();r.vanillaXp=0;
 d.activeId=r.id;save();lobbies.delete(d.id);runs.set(d.id,r);
 try{
  for(let i=0;i<group.length;i++){const m=group[i];m.setDynamicProperty(RETURN_KEY,JSON.stringify({runId:r.id,dimId:m.dimension.id,location:m.location}));const at={x:d.x+(i%2)*2-1,y:d.y+1,z:d.z-8+Math.floor(i/2)*2};m.teleport(at,{dimension:dimension(d),keepVelocity:false});applyVitality(m);restoreFullHealth(m);r.anchors.set(m.id,at);}
  // Give the destination player chunks time to load before spawning entities.
  const begin=()=>{
   if(runs.get(d.id)!==r||r.finishing)return;
   try{
    if(expired(r))return;
    if(d.cleanupPending){cleanMobs(d,{allInside:true});d.cleanupPending=false;save();}
    for(let i=0;i<DUNGEON.initialNormals;i++){spawnMob(r,'normal',r.normalSpawned);r.normalSpawned++;}
    const start=Date.now();r.phase='mobs';r.startedAt=start;r.deadline=start+dungeonTimeLimit('mobs',r.initialPartySize);r.nextNormalAt=start+DUNGEON.normalIntervalMs;r.nextEliteAt=start+DUNGEON.eliteIntervalMs;
    for(const m of group)say(m,`§e[던전] 지금부터 일반 50마리·엘리트 5마리를 ${r.initialPartySize===1?'7분 30초':'5분'} 안에 처치하세요.`);
   }catch(error){
    for(const entry of r.live.values())try{entry.mob.remove();}catch{}r.live.clear();r.normalSpawned=0;
    if(String(error.name).includes('UnloadedChunk')&&Date.now()<r.deadline)system.runTimeout(begin,20);
    else finish(r,false,'몬스터 생성 오류로 중단했습니다.');
   }
  };
  system.runTimeout(begin,20);
 }catch(error){finish(r,false,'몬스터 생성 오류로 중단했습니다.');throw error;}
 return {runId:r.id,members:group.map(m=>m.id)};
}
export function soloDungeon(p,value){
 const tier=requireTier(value),lobby=lobbies.get(tier.id);
 if(lobby?.members.length&&!(lobby.members.length===1&&lobby.members[0].id===p.id))throw Error('이미 다른 플레이어가 대기 중입니다. 다른 난이도를 선택하거나 함께 참가하세요.');
 enterDungeon(p,value,{solo:true});return startDungeon(p);
}
function removeLobbyMember(id){const l=lobbyOf(id);if(!l)return false;l.members=l.members.filter(m=>m.id!==id);if(!l.members.length)lobbies.delete(l.d.id);else for(const m of l.members)say(online(m.id),`§7대기 인원 ${l.members.length}/4 · 시작 담당 ${l.members[0].name}`);return true;}
function removeDeadMember(p,r){
 if(r){r.members=r.members.filter(m=>m.id!==p.id);r.anchors?.delete(p.id);if(!r.members.length&&!r.finishing)finish(r,false);}
 removeLobbyMember(p.id);
}
export function leaveDungeon(p){
 const r=runOf(p.id);
 if(r&&healthAlive(p))return false; // Active participants cannot voluntarily escape.
 removeLobbyMember(p.id);if(r)removeDeadMember(p,r);
 const back=returnPlayer(p);say(p,back?'§7던전 대기를 종료했습니다.':'§7부활 후 원래 위치로 귀환합니다.');return back;
}
function clearBody(dim,at){
 try{for(const x of [-.3,.3])for(const z of [-.3,.3])for(const y of [.1,1.7]){const block=dim.getBlock({x:Math.floor(at.x+x),y:Math.floor(at.y+y),z:Math.floor(at.z+z)});if(!block)return false;const solid=typeof block.isSolid==='function'?block.isSolid():block.isSolid;if(solid)return false;}return true;}catch{return false;}
}
export function enforceDungeonBounds(p,r=activeDungeonRun(p)){
 if(!r||r.finishing||!healthAlive(p))return false;
 r.anchors??=new Map();const dim=dimension(r.d);
 if(inside(p,r.d)&&clearBody(dim,p.location)){r.anchors.set(p.id,{...p.location});return false;}
 const home={x:r.d.x,y:r.d.y+1,z:r.d.z-8},last=r.anchors.get(p.id);
 for(const at of [last,home]){
  if(!at||!insideDungeon(at,r.d.dimId,r.d))continue;
  try{p.teleport(at,{dimension:dim,keepVelocity:false,checkForBlocks:true});return true;}catch{}
 }
 return false;
}
function repairLiveMobs(r){
 for(const [id,entry]of [...r.live]){
  if(entry.mob.isValid===false){r.live.delete(id);const replacement=spawnMob(r,entry.kind,entry.index??0);if(entry.kind==='boss')r.bossId=replacement.id;continue;}
  try{if(!inside(entry.mob,r.d)&&typeof entry.mob.teleport==='function')entry.mob.teleport({x:r.d.x,y:r.d.y+1,z:r.d.z},{dimension:dimension(r.d),keepVelocity:false});}catch{}
 }
}

export function flushRewards(){
 for(const receipt of [...state().outbox]){const p=online(receipt.playerId);if(!p)continue;
  try{const credited=creditDungeonClear(p,receipt.runId,receipt.tier??1,receipt.solo===true,receipt.netherite??0,receipt.ancientDebris??0);if(!credited?.duplicate){try{recordSoloDungeonClear(p,receipt.tier??1,receipt.solo===true);}catch{}}state().outbox=state().outbox.filter(x=>x!==receipt);save();const result=claimDungeonLoot(p);if(result.pending)say(p,'§e가방 부족 보급품은 저장했습니다. /rpg:dungeonloot 로 받으세요.');}
  catch{say(p,'§c보상 저장·수령 대기 중입니다. /rpg:dungeonloot 로 재시도하세요.');}
 }
}
export function dungeonDeath(ev){
 const dead=ev.deadEntity;if(!dead)return;
 if(dead.typeId==='minecraft:player'){removeDeadMember(online(dead.id)??dead,runOf(dead.id));return;}
 for(const r of runs.values()){
  const entry=r.live.get(dead.id);if(!entry)continue;if(expired(r))return;r.live.delete(dead.id);
  r.vanillaXp=(r.vanillaXp??0)+Math.round((DUNGEON_NATIVE_XP[dead.typeId]??0)*levelRewardMultiplier(dead));
  if(entry.kind==='boss'){if(r.phase==='boss'&&dead.id===r.bossId)finish(r,true);return;}
  if(entry.kind==='normal')r.normalKilled++;else{
   r.eliteKilled++;
   // A single shared ground drop; duplicate deaths and cleanup are never rolled.
   try{const amount=rollDungeonEliteDiamonds();if(amount)dimension(r.d).spawnItem(new ItemStack('minecraft:diamond',amount),dead.location);}
   catch(error){console.warn('[RPG dungeon diamond drop] '+String(error));}
  }
  r.nextNormalAt=Math.min(r.nextNormalAt,Date.now()+DUNGEON.reinforceDelayMs);
  try{spawnBoss(r);if(!r.finishing)spawnTick(r,Date.now());}catch(error){finish(r,false,'몬스터 생성에 실패했습니다.');throw error;}return;
 }
}
export function dungeonTick(){
 const job=builders.values().next().value;if(job)buildTick(job);
 const now=Date.now(),maintenance=system.currentTick-maintenanceTick>=20;if(maintenance)maintenanceTick=system.currentTick;
 for(const r of [...runs.values()]){
  if(expired(r,now))continue;
  for(const m of [...r.members]){
   const p=online(m.id);if(!p)continue; // Rejoining during a live run restores confinement.
   if(!healthAlive(p)){removeDeadMember(p,r);continue;}
   enforceDungeonBounds(p,r);
  }
  if(!r.members.length&&!r.finishing)finish(r,false);
  if(r.finishing||!r.members.some(m=>online(m.id)))continue;
  try{if(maintenance&&r.phase!=='preparing')repairLiveMobs(r);spawnTick(r,now);}catch(error){finish(r,false,'몬스터 생성에 실패했습니다.');console.warn('[RPG dungeon] '+error);}
 }
}

export function recoverDungeons(){
 for(const r of runs.values())cleanMobs(r.d,{allInside:true,tracked:[...r.live.values()].map(e=>e.mob)});runs.clear();lobbies.clear();builders.clear();db=undefined;
 for(const d of allRegistered()){if(d.activeId){d.cleanupPending=true;cleanMobs(d,{allInside:true});}d.activeId=null;unloadBuildArea(d);}
 for(const d of state().dungeons){if(d.status!=='ready')queueBuilder(d,null,d.status==='building');else if(d.buildRevision!==DUNGEON_BUILD_REVISION)queueBuilder(d,null,true);}
 save();flushRewards();
}
export async function openDungeons(p){
 const current=runOf(p.id);if(current){await new ActionFormData().title('던전 진행').body(dungeonHudText(p)+'\n전투 중 자진 퇴장 불가 · 외부 이탈 시 자동 복귀\n클리어·사망·시간 초과 시 종료.').button('닫기').show(p);return;}
 const waiting=lobbyOf(p.id);
 if(waiting){const form=new ActionFormData().title('던전 대기실 · 난이도 '+waiting.d.tier).body(waiting.members.map((m,i)=>(i===0?'[시작 담당] ':'')+m.name).join('\n')+'\n원하는 인원 1~4명으로 출발할 수 있습니다.').button('출발').button('대기 취소').button('닫기');const reply=await form.show(p);try{if(!reply.canceled&&reply.selection===0)startDungeon(p);if(!reply.canceled&&reply.selection===1)leaveDungeon(p);}catch(error){say(p,'§c'+error.message);}return;}
 const list=listDungeons(),form=new ActionFormData().title('던전 · 난이도 1~10').body('각자 원하는 던전에 참가 · 최대 4명 · 혼자도 가능\n파티: 일반·엘리트 5분 / 보스 3분\n혼자 출발: 각각 7분 30초 / 4분 30초');
 for(const d of list)form.button(`${d.tier}. ${d.name} · ${d.status!=='ready'?'미생성/건설 중':d.busy?'전투 중':d.waiting+'/4 대기'}`);
 form.button('닫기');const selected=await form.show(p);if(selected.canceled||selected.selection==null||selected.selection>=10)return;
 const d=list[selected.selection],t=DUNGEON_TIERS[d.tier-1],reward=clearRewardForTier(d.tier);
 const choice=await new ActionFormData().title(`난이도 ${d.tier} · ${d.name}`).body(`일반 50마리 + 엘리트 5마리 → 보스 1마리\n파티: 일반·엘리트 5분 / 보스 3분\n솔로: 일반·엘리트 7분 30초 / 보스 4분 30초\n일반 Lv.${dungeonMonsterLevel(d.tier,'normal',0)}~${dungeonMonsterLevel(d.tier,'normal',2)} · 엘리트 Lv.${dungeonMonsterLevel(d.tier,'elite')} · 보스 Lv.${dungeonMonsterLevel(d.tier,'boss')}\n클리어 골드 ${reward.gold} · 강화석 ${reward.stone} · 룬 가루 ${reward.dust}\n촉매 ${reward.catalysts}개(매 3회 +1) · 룬 ${reward.runes}개\n엘리트 다이아: 1개 40% / 3개 10% / 없음 50%(공동 전리품).\n${netheriteChanceForTier(d.tier)?`클리어 시 각자 네더라이트 주괴 1개 ${Math.round(netheriteChanceForTier(d.tier)*100)}%.`:`고대 잔해 개인 보상: 1개 30% / 2개 10% / 없음 60%.`}\n혼자 출발 시 클리어 골드·강화석·룬 가루·촉매 1.5배(올림).\n${d.tier===2?'2단계 솔로 권장: 근력 40·레어 힘의 룬 +10·무기 +6 이상과 방어구/회복 준비. 입장 제한 없음.':d.tier===10?'10단계 권장: 무기·갑옷 4부위·장착 룬 모두 전설 +10 이상. 입장 제한 없음.':'후반일수록 강화·등급·룬 구성이 중요합니다.'}\n파티장이 참가하면 접속 중인 파티원도 자동 등록됩니다. 출발 시 함께 이동합니다.`).button('대기실 참가').button('혼자 바로 시작').button('닫기').show(p);
 try{if(!choice.canceled&&choice.selection===0)enterDungeon(p,d.tier);if(!choice.canceled&&choice.selection===1)soloDungeon(p,d.tier);}catch(error){say(p,'§c'+error.message);}
}
export function cleanupReloadedDungeonEntity(entity){
 try{if(!removableMob(entity))return;for(const d of allRegistered())if(d.cleanupPending&&!runs.has(d.id)&&inFootprint(entity,d)){entity.remove();return;}}catch{}
}
export function registerDungeons(){
 if(registered)return;registered=true;recoverDungeons();
 world.afterEvents.entityLoad?.subscribe(ev=>system.run(()=>{rememberLootCache(ev.entity);cleanupReloadedDungeonEntity(ev.entity);}));
 world.afterEvents.entityDie.subscribe(ev=>{try{dungeonDeath(ev);}catch(error){console.warn('[RPG dungeon death] '+error);}});
 world.afterEvents.playerLeave.subscribe(ev=>{removeLobbyMember(ev.playerId);});
 world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{try{const r=runOf(ev.player.id);if(r)enforceDungeonBounds(ev.player,r);else returnPlayer(ev.player);flushRewards();claimDungeonLoot(ev.player);}catch(error){say(ev.player,'§c던전 귀환 대기: '+error.message);}},20));
 world.afterEvents.playerDimensionChange?.subscribe(ev=>{try{enforceDungeonBounds(ev.player);}catch{}});
 registerStructureProtection('dungeons',block=>protectedBlock(block,block.dimension.id));
 system.runInterval(()=>{try{dungeonTick();}catch(error){console.warn('[RPG dungeon] '+error);}},1);
}
