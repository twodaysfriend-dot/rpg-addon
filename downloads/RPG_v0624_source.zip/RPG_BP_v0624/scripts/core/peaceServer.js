import {world} from '@minecraft/server';
import {CONFIG} from '../config.js';
let registered=false;
export function applyPeaceRules(){
 if(world.gameRules){world.gameRules.pvp=CONFIG.pvp===true;world.gameRules.doInsomnia=false;}
}
export function registerPeaceServer(){
 if(registered)return;registered=true;
 try{applyPeaceRules();}catch(error){console.warn('[RPG peace rules] '+String(error));}
 world.afterEvents.worldLoad?.subscribe(()=>{try{applyPeaceRules();}catch{}});
}
