import {world,system} from '@minecraft/server';
import {partyMembership} from './social.js';
import {isActiveNearbyPlayer} from './xpDistribution.js';
import {isTrialTarget,recordJobTrialKill} from './jobTrials.js';
import {alliedOwner,isHealingAlly} from './supportAllies.js';
import {setManualDamageObserver} from './combatContext.js';
import {getJobId,addProgress} from './playerData.js';
import {recordDungeonDamage,recordDungeonHealing} from './dungeonSharedLoot.js';
export const CONTRIBUTION_TICKS=600;
const fights=new Map(),awarded=new Map();let registered=false;
const villagers=new Set(['minecraft:villager','minecraft:villager_v2']);
const targetType=id=>isTrialTarget(id)||villagers.has(id)||id==='rpg:sandbag_entity';
function prune(){const now=system.currentTick;for(const [id,s]of fights)if(s.until<now)fights.delete(id);for(const [id,until]of awarded)if(until<now)awarded.delete(id);}
function mark(p,enemy){
 if(!p||!enemy?.id||!targetType(enemy.typeId)||!isActiveNearbyPlayer(p,p.location,p.dimension.id,1))return;
 prune();const s=fights.get(enemy.id)??{people:new Map(),until:0};s.people.set(p.id,system.currentTick);s.until=system.currentTick+CONTRIBUTION_TICKS;fights.set(enemy.id,s);
}
export function recordCombatDamage(source,target,damage){
 if(!(damage>0)||!source||!target)return;
 recordDungeonDamage(source,target,damage);
 const attacker=alliedOwner(source),defender=alliedOwner(target);
 if(attacker&&targetType(target.typeId))mark(attacker,target);
 if(defender&&isTrialTarget(source.typeId))mark(defender,source);
}
export function recordCombatHealing(caster,target,amount){
 if(!(amount>0)||caster?.id===target?.id||!isHealingAlly(caster,target))return;
 const patient=alliedOwner(target);if(!patient)return;
 recordDungeonHealing(caster,patient,amount);
 prune();for(const s of fights.values())if((s.people.get(patient.id)??-Infinity)>=system.currentTick-CONTRIBUTION_TICKS){s.people.set(caster.id,system.currentTick);s.until=system.currentTick+CONTRIBUTION_TICKS;}
}
export function awardPartyTrialKill(killer,entity){
 if(!targetType(entity?.typeId))return [];
 if(!isActiveNearbyPlayer(killer,killer.location,killer.dimension.id,1))return [];
 prune();if(entity.id&&awarded.has(entity.id))return [];
 const s=fights.get(entity.id),origin=(()=>{try{return entity.location??killer.location;}catch{return killer.location;}})();
 const dim=(()=>{try{return entity.dimension?.id??killer.dimension.id;}catch{return killer.dimension.id;}})();
 const recipients=new Map([[killer.id,killer]]);
 for(const p of partyMembership(killer).members)if(p.id!==killer.id&&(s?.people.get(p.id)??-Infinity)>=system.currentTick-CONTRIBUTION_TICKS&&isActiveNearbyPlayer(p,origin,dim,32))recipients.set(p.id,p);
 const paid=[];for(const p of recipients.values()){
  const job=getJobId(p);
  if(villagers.has(entity.typeId)){if(job==='sword_saint')addProgress(p,'villager_kills');}
  else if(entity.typeId==='rpg:sandbag_entity'){if(['apprentice','fighter'].includes(job))addProgress(p,job==='fighter'?'fighter_sandbags':'apprentice_sandbags');}
  else recordJobTrialKill(p,entity);
  paid.push(p.id);
 }
 if(entity.id){awarded.set(entity.id,system.currentTick+CONTRIBUTION_TICKS);fights.delete(entity.id);}return paid;
}
export function clearCombatContributions(id){for(const s of fights.values())s.people.delete(id);}
export function registerCombatContributions(){
 if(registered)return;registered=true;setManualDamageObserver(recordCombatDamage);
 world.afterEvents.entityHurt.subscribe(ev=>{try{let source=ev.damageSource?.damagingEntity;if(!source)source=ev.damageSource?.damagingProjectile?.getComponent('minecraft:projectile')?.owner;recordCombatDamage(source,ev.hurtEntity,ev.damage);}catch{}});
 world.afterEvents.playerLeave.subscribe(ev=>clearCombatContributions(ev.playerId));
 system.runInterval(prune,200);
}
