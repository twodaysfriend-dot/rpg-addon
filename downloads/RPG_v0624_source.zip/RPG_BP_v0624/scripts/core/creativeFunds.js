import {world,system} from '@minecraft/server';
import {BALANCE_MAX,getWallet,setWallet,walletText} from './wallet.js';
export const CREATIVE_FUNDS_ITEM='rpg:creative_funds';
export function grantCreativeFunds(p){
 try{
  if(p?.typeId!=='minecraft:player'||String(p.getGameMode()).toLowerCase()!=='creative')return {ok:false,message:'크리에이티브 모드에서만 무한 재화를 지급받을 수 있습니다.'};
  const before=getWallet(p),next={gold:BALANCE_MAX,stone:BALANCE_MAX,dust:BALANCE_MAX};
  try{setWallet(p,next);}catch(error){try{setWallet(p,before);}catch{}throw error;}
  return {ok:true,message:'무한 재화 충전 완료 · '+walletText(next)+'\n반복 사용으로 언제든 다시 충전할 수 있습니다.'};
 }catch(error){return {ok:false,message:'재화 충전 실패: '+String(error.message??error)};}
}
export function useCreativeFunds(p){const r=grantCreativeFunds(p);p.sendMessage((r.ok?'§a':'§e')+r.message);return r;}
let registered=false;const last=new Map();
function itemUse(p){const previous=last.get(p.id);if(previous!==undefined&&system.currentTick-previous<=1)return;last.set(p.id,system.currentTick);useCreativeFunds(p);}
export function registerCreativeFunds(){
 if(registered)return;registered=true;
 world.afterEvents.itemUse.subscribe(e=>{if(e.itemStack?.typeId===CREATIVE_FUNDS_ITEM)itemUse(e.source);});
 world.afterEvents.playerLeave.subscribe(e=>last.delete(e.playerId));
}
// Components must be registered at startup, before gameplay systems start.
system.beforeEvents.startup.subscribe(e=>{try{e.itemComponentRegistry?.registerCustomComponent('rpg:creative_funds',{onUse:ev=>system.run(()=>itemUse(ev.source))});}catch(error){console.warn('[RPG creative funds] '+error);}});
