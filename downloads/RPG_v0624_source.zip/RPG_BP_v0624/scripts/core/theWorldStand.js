import {world,system} from '@minecraft/server';
import {getJobId} from './playerData.js';
const stands=new Map(),OWNER='rpg:the_world_owner';let registered=false;
export function tickTheWorldStands(){
 const players=world.getAllPlayers();
 for(const [id,e]of stands){try{if(!e.isValid){stands.delete(id);continue;}}catch{stands.delete(id);continue;}const p=players.find(p=>p.id===id);if(!p||getJobId(p)!=='the_world'||(p.getComponent('minecraft:health')?.currentValue??0)<=0||p.dimension.id!==e.dimension.id){try{e.remove();}catch{}stands.delete(id);}}
 for(const p of players){if(getJobId(p)!=='the_world'||(p.getComponent('minecraft:health')?.currentValue??0)<=0)continue;
  try{const rot=p.getRotation(),yaw=rot.y*Math.PI/180,at={x:p.location.x+Math.sin(yaw)*1.05,y:p.location.y+.15,z:p.location.z-Math.cos(yaw)*1.05};let e=stands.get(p.id);if(!e?.isValid){e=p.dimension.spawnEntity('rpg:the_world_stand',at);e.setDynamicProperty(OWNER,p.id);stands.set(p.id,e);}e.teleport(at,{dimension:p.dimension,rotation:{x:0,y:rot.y},keepVelocity:false});}catch(error){console.warn('[The World stand] '+error);}
 }
}
export function cleanWorldStands(){for(const name of ['overworld','nether','the_end'])try{for(const e of world.getDimension(name).getEntities({type:'rpg:the_world_stand'}))if(stands.get(e.getDynamicProperty(OWNER))?.id!==e.id)e.remove();}catch{}}
export function registerTheWorldStand(){if(registered)return;registered=true;system.run(cleanWorldStands);system.runInterval(tickTheWorldStands,2);system.runInterval(cleanWorldStands,100);world.afterEvents.playerLeave.subscribe(ev=>{try{stands.get(ev.playerId)?.remove();}catch{}stands.delete(ev.playerId);});}
