import {partyMembership,partyLeaderName} from './social.js';
export function dungeonEnrollmentGroup(p,solo=false){
 if(solo||partyLeaderName(p).toLowerCase()!==p.name.toLowerCase())return [p];
 const party=partyMembership(p);if(!party.inParty)return [p];
 return [p,...party.members.filter(m=>m.id!==p.id)];
}
export function enrollDungeonGroup(lobby,group,validate){
 const add=group.filter(p=>!lobby.members.some(m=>m.id===p.id));
 if(lobby.members.length+add.length>4)throw Error('파티원 전체를 등록할 공간이 부족합니다. 던전 정원은 4명입니다.');
 for(const p of group)validate(p);
 for(const p of add)lobby.members.push({id:p.id,name:p.name});
 return add;
}
