// Regular worlds and Realms use the bundled catalog. The optional BDS build
// replaces only this adapter; no HTTP module or API secret is in the main addon.
export async function rankKnowledge(){return undefined;}
