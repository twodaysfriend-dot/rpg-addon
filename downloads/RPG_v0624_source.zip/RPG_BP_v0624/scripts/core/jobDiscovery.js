import {world,system} from '@minecraft/server';
import {JOBS} from '../data/jobs.js';
import {getJobId} from './playerData.js';
import {hasChameleonCard} from './chameleonCard.js';
import {hasBloodCard} from './bloodCard.js';
export const JOB_DISCOVERY_KEY='rpg:discovered_jobs_v1';
export function isHiddenPromotion(job){const seen=new Set();while(job&&!seen.has(job.id)){if(job.hidden)return true;seen.add(job.id);job=JOBS[job.parent];}return false;}
export const UNDISCOVERED_JOB_TEXT='아직 발견하지 못한 전직입니다. 세계를 탐험하며 단서를 찾아보세요.';
function records(p){try{const v=JSON.parse(p.getDynamicProperty(JOB_DISCOVERY_KEY)??'[]');return Array.isArray(v)?v.filter(id=>isHiddenPromotion(JOBS[id])):[];}catch{return [];}}
export function discoverJob(p,id){
 if(!JOBS[id]||!isHiddenPromotion(JOBS[id]))return false;
 const found=records(p);if(found.includes(id))return false;
 found.push(id);p.setDynamicProperty(JOB_DISCOVERY_KEY,JSON.stringify(found));return true;
}
function ownsCard(p,id){try{const inv=p.getComponent('minecraft:inventory')?.container;for(let i=0;i<(inv?.size??0);i++)if(inv.getItem(i)?.typeId===id)return true;}catch{}return false;}
export function isJobDiscovered(p,job){
 if(!isHiddenPromotion(job))return true;
 if(records(p).includes(job.id))return true;
 // Preserve knowledge of a current hidden class (including pre-update players).
 let current=JOBS[getJobId(p)];const seen=new Set();
 while(current&&!seen.has(current.id)){if(current.id===job.id){discoverJob(p,job.id);return true;}seen.add(current.id);current=JOBS[current.parent];}
 if((job.id==='chameleon'&&(hasChameleonCard(p)||ownsCard(p,'rpg:chameleon_job_card')))||(job.id==='blood_mage'&&(hasBloodCard(p)||ownsCard(p,'rpg:blood_job_card')))){discoverJob(p,job.id);return true;}
 return false;
}
export function visiblePromotionJobs(p){return Object.values(JOBS).filter(j=>!j.placeholder&&j.id!=='apprentice'&&isJobDiscovered(p,j));}

let registered=false;
export function registerJobDiscovery(){
 if(registered)return;registered=true;
 const remember=p=>{try{discoverJob(p,getJobId(p));isJobDiscovered(p,JOBS.chameleon);isJobDiscovered(p,JOBS.blood_mage);}catch(error){console.warn('[RPG discovery] '+error);}};
 world.afterEvents.playerInventoryItemChange?.subscribe(e=>remember(e.player));
 world.afterEvents.playerSpawn?.subscribe(e=>system.run(()=>remember(e.player)));
 system.runInterval(()=>{for(const p of world.getAllPlayers())remember(p);},20);
}
