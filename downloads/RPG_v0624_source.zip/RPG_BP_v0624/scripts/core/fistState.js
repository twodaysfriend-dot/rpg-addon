import { system } from "@minecraft/server";

// 무투가 계열이 쓰는 작은 상태 저장소 (메모리). hud.js 등에서 순환 참조 없이 읽을 수 있게 따로 뒀습니다.

// ---- 강펀치: 다음 N번 공격 데미지 2배 ----
const buffs = new Map(); // playerId -> { left, until }

export function giveDoubleBuff(player, hits, ticks) {
  buffs.set(player.id, { left: hits, until: system.currentTick + ticks });
}

// 남은 강펀치 횟수 (없으면 0)
export function doubleLeft(player) {
  const b = buffs.get(player.id);
  if (!b) return 0;
  if (b.left <= 0 || b.until <= system.currentTick) {
    buffs.delete(player.id);
    return 0;
  }
  return b.left;
}

// 공격 1회분을 소모하고 배율(1 또는 2)을 돌려줍니다.
export function takeDouble(player) {
  if (doubleLeft(player) <= 0) return 1;
  const b = buffs.get(player.id);
  b.left--;
  if (b.left <= 0) buffs.delete(player.id);
  return 2;
}

// ---- 스킬 피해 표시 ----
// 스킬이 준 피해가 '일반 공격'으로 오인되어 강펀치가 또 소모되지 않도록, 스킬이 때린 대상을 잠깐 표시합니다.
const marks = new Map(); // "공격자:대상" -> { n, until }

export function markSkillHit(victimId, attackerId) {
  const key = `${attackerId}:${victimId}`;
  const m = marks.get(key);
  const until = system.currentTick + 4;
  if (m && m.until >= system.currentTick) {
    m.n++;
    m.until = until;
  } else {
    marks.set(key, { n: 1, until });
  }
}

export function consumeSkillMark(victimId, attackerId) {
  const key = `${attackerId}:${victimId}`;
  const m = marks.get(key);
  if (!m) return false;
  if (m.until < system.currentTick || m.n <= 0) {
    marks.delete(key);
    return false;
  }
  m.n--;
  if (m.n <= 0) marks.delete(key);
  return true;
}

export function clearFistRuntime(playerId) {
  buffs.delete(playerId);
  for (const k of marks.keys()) if (k.startsWith(`${playerId}:`)) marks.delete(k);
}
