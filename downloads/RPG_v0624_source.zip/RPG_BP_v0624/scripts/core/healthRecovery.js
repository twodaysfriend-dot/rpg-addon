export function restoreFullHealth(p){
 const hp=p.getComponent('minecraft:health');
 if(hp&&hp.currentValue>0)hp.setCurrentValue(hp.effectiveMax??20);
}
