import {arenaReady,enterDuelArena,releaseDuelArena,restoreArenaPlayer,insidePvpArena} from './pvpArena.js';
import {world,system} from '@minecraft/server';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {getWallet,setWallet,BALANCE_MAX} from './wallet.js';
import {dungeonRuns} from './dungeonState.js';
import {showForm} from './skillMenu.js';
const STORE='rpg:pk_registry_v1',RECOVER='rpg:duel_recover',PK_GRACE='rpg:post_duel_pk_until';
const pkExempt=new Map(),repairing=new Set();
export function hasPostDuelPkGrace(p){return Math.max(pkExempt.get(p?.id)??0,Number(p?.getDynamicProperty?.(PK_GRACE)??0))>Date.now();}
const duels=new Map(),offers=new Map(),lastHits=new Map(),deaths=new Map();let registered=false;
const online=id=>world.getAllPlayers().find(p=>p.id===id);
const hp=p=>p?.getComponent('minecraft:health');
const tell=(p,s)=>{try{p?.sendMessage(s);}catch{}};
const active=p=>p?.isValid&&p.typeId==='minecraft:player'&&hp(p)?.currentValue>0&&!['creative','spectator'].includes(String(p.getGameMode()).toLowerCase());
const distance=(a,b)=>a.dimension.id===b.dimension.id?Math.hypot(a.location.x-b.location.x,a.location.y-b.location.y,a.location.z-b.location.z):Infinity;
const inDungeon=p=>[...dungeonRuns.values()].some(r=>r.members.some(m=>m.id===p.id));
export function pvpOwner(source){if(!source||source.typeId==='minecraft:player')return source;try{const owner=source.getComponent('minecraft:projectile')?.owner;if(owner?.typeId==='minecraft:player')return owner;const id=source.getComponent('minecraft:tameable')?.tamedToPlayerId??source.getDynamicProperty('rpg:necro_owner');return online(id)??source;}catch{return source;}}
export function notePvpAttack(source,target,damage){source=pvpOwner(source);if(damage>0&&source?.typeId==='minecraft:player'&&target?.typeId==='minecraft:player'&&source.id!==target.id&&!duelOf(target))lastHits.set(target.id,{id:source.id,name:source.name,until:Date.now()+10000});}
function registry(){return JSON.parse(world.getDynamicProperty(STORE)??'{"version":1,"pk":{}}');}
function save(s){const raw=JSON.stringify(s);if(raw.length>29000)throw Error('PK 저장 공간 부족');world.setDynamicProperty(STORE,raw);}
export function isPk(p){return Boolean(registry().pk[p?.id]);}
function refreshPk(p){if(!p)return;const marked=isPk(p);try{if(marked)p.addTag('rpg_pk');else p.removeTag('rpg_pk');}catch{}try{if(marked){if(p.getDynamicProperty('rpg:pk_name')===undefined)p.setDynamicProperty('rpg:pk_name',p.nameTag??p.name);p.nameTag='§c[PK] §r'+p.name;}else{const old=p.getDynamicProperty('rpg:pk_name');if(old!==undefined){p.nameTag=old;p.setDynamicProperty('rpg:pk_name',undefined);}}}catch{}}
export function markPk(p){if(hasPostDuelPkGrace(p))return;const s=registry(),old=s.pk[p.id];s.pk[p.id]={name:p.name,kills:(old?.kills??0)+1,since:old?.since??Date.now()};save(s);refreshPk(p);tell(p,'§c[PK] 합의된 결투 밖에서 플레이어를 살해했습니다. PK 표식·현상금 패널티가 적용됩니다.');}
export function transferBounty(killer,victim){const a=getWallet(killer),b=getWallet(victim),amount=Math.min(50000,b.gold,BALANCE_MAX-a.gold);try{setWallet(victim,{...b,gold:b.gold-amount});setWallet(killer,{...a,gold:a.gold+amount});}catch(error){try{setWallet(victim,b);setWallet(killer,a);}catch{}throw error;}return amount;}
export function duelOf(p){return duels.get(typeof p==='string'?p:p?.id);}
export function duelOpponents(a,b){const d=duelOf(a);return Boolean(d&&d===duelOf(b)&&a.id!==b.id);}
function fullHealth(p){const h=hp(p);if(h&&h.currentValue>0)h.setCurrentValue(h.effectiveMax??20);}
// Migration only: new duels never enable native health floors or damage immunity.
// Legacy recovery explicitly restores ordinary min-HP=0; new duels never add min-HP=1.
// A delayed native health reset must never heal the player during migration.
export function clearLegacyDuelProtection(p){
 const h=hp(p);
 if(!p?.isValid||!h||h.currentValue<=0||repairing.has(p.id))return false;
 if(!p.getDynamicProperty(RECOVER)&&!(h.effectiveMin>0))return false;
 const previousHealth=h.currentValue;
 p.setDynamicProperty(RECOVER,true);
 try{p.triggerEvent('rpg:duel_exit');}catch(error){console.warn('[RPG PvP legacy repair] '+error);return false;}
 repairing.add(p.id);
 system.runTimeout(()=>{
  repairing.delete(p.id);
  try{
   if(!p.isValid)return;const health=hp(p);if(!health||health.currentValue<=0)return;
   if(health.currentValue>previousHealth)health.setCurrentValue(Math.min(previousHealth,health.effectiveMax));
   if(health.effectiveMin===0){p.setDynamicProperty(RECOVER,undefined);}
  }catch(error){console.warn('[RPG PvP legacy repair] '+error);}
 },2);
 return true;
}
export function finishDuel(d,winner,reason='결투 종료'){
 if(!d||d.finished)return;d.finished=true;for(const id of d.ids)duels.delete(id);
 for(const id of d.ids){lastHits.delete(id);pkExempt.set(id,Date.now()+10000);}
 for(const id of d.ids){const p=online(id);if(p){try{p.setDynamicProperty(PK_GRACE,Date.now()+10000);}catch{}try{clearLegacyDuelProtection(p);}catch{}}tell(p,`§e[결투] ${reason}${winner?' · 승자 '+winner.name:''}. 결투 PK·현상금은 없습니다.`);}
 system.runTimeout(()=>releaseDuelArena(d.ids),2);
}
export function requestDuel(p,target){
 if(!active(p)||!active(target)||p.id===target.id)throw Error('생존한 다른 서바이벌 플레이어를 선택하세요.');
 if(!arenaReady())throw Error('관리자가 /pvpcreate 또는 /rpg:pvpcreate로 PvP장을 먼저 생성해야 합니다.');
 if(duelOf(p)||duelOf(target)||inDungeon(p)||inDungeon(target))throw Error('던전·결투 진행 중에는 신청할 수 없습니다.');
 const existing=offers.get(target.id);if(existing&&existing.until>Date.now()&&existing.from!==p.id)throw Error('상대가 다른 결투 신청에 응답 중입니다.');offers.set(target.id,{from:p.id,until:Date.now()+30000});tell(p,'§e[결투] '+target.name+'에게 신청했습니다.');tell(target,'§e[결투] '+p.name+'의 신청입니다. /rpg:pvp에서 30초 안에 수락하세요.');return true;
}
export function acceptDuel(p,expectedFrom){
 const offer=offers.get(p.id),other=online(offer?.from);if(!offer||offer.until<Date.now())throw Error('유효한 결투 신청이 없습니다.');if(expectedFrom&&offer.from!==expectedFrom)throw Error('신청자가 바뀌었습니다. 결투 메뉴를 다시 여세요.');
 if(!active(p)||!active(other)||duelOf(p)||duelOf(other)||inDungeon(p)||inDungeon(other))throw Error('결투 참가 상태·거리·던전 상태를 확인하세요.');
 // Ordinary combat is lethal: no native min-HP component, damage refund or shield.
 enterDuelArena(p,other);
 const d={ids:[p.id,other.id],phase:'countdown',until:Date.now()+303000,finished:false};duels.set(p.id,d);duels.set(other.id,d);offers.delete(p.id);offers.delete(other.id);for(const [id,o]of offers)if(o.from===p.id||o.from===other.id)offers.delete(id);
 try{for(const a of [p,other]){fullHealth(a);clearLegacyDuelProtection(a);tell(a,'§e[결투] 3초 후 시작합니다. 대기 중에도 피해를 받습니다.');}}
 catch(error){finishDuel(d,undefined,'결투 준비 실패');throw error;}
 system.runTimeout(()=>{if(d.finished)return;const a=online(d.ids[0]),b=online(d.ids[1]);if(!active(a)||!active(b)||!insidePvpArena(a)||!insidePvpArena(b)||distance(a,b)>48){finishDuel(d,undefined,'시작 조건 불충족');return;}d.phase='active';d.until=Date.now()+300000;for(const p of [a,b])tell(p,'§c[결투] 시작! 사망하면 패배합니다.');},60);return d;
}
export function observePvpHurt(ev){
 const target=ev.hurtEntity;if(target?.typeId!=='minecraft:player')return;
 const source=pvpOwner(ev.damageSource?.damagingEntity??ev.damageSource?.damagingProjectile?.getComponent('minecraft:projectile')?.owner);
 notePvpAttack(source,target,ev.damage);
}

export function recordPvpDeath(killer,victim){
 if(victim?.typeId!=='minecraft:player')return;
 const d=duelOf(victim);if(d){const opponent=online(d.ids.find(id=>id!==victim.id));finishDuel(d,active(opponent)?opponent:undefined,'결투 참가자 사망');return;}
 if(deaths.get(victim.id)===system.currentTick)return;deaths.set(victim.id,system.currentTick);
 if(killer?.typeId!=='minecraft:player'){const last=lastHits.get(victim.id);killer=last?.until>Date.now()?(online(last.id)??{id:last.id,name:last.name,typeId:'minecraft:player',isValid:false}):undefined;}
 lastHits.delete(victim.id);if(!killer||killer.id===victim.id)return;
 if(hasPostDuelPkGrace(killer)||hasPostDuelPkGrace(victim))return;
 if(isPk(victim)){
  let amount;const s=registry();if(killer.isValid===false){const before=getWallet(victim);s.credits??={};const owed=s.credits[killer.id]??0;amount=Math.min(50000,before.gold,BALANCE_MAX-owed);try{setWallet(victim,{...before,gold:before.gold-amount});s.credits[killer.id]=owed+amount;delete s.pk[victim.id];save(s);}catch(error){setWallet(victim,before);throw error;}}else{const ka=getWallet(killer),va=getWallet(victim);try{amount=transferBounty(killer,victim);delete s.pk[victim.id];save(s);}catch(error){setWallet(killer,ka);setWallet(victim,va);throw error;}}refreshPk(victim);tell(killer,'§6[현상금] PK 플레이어 지갑에서 '+amount.toLocaleString()+'골드를 받았습니다. 추가 PK 패널티는 없습니다.');tell(victim,'§c[PK] '+amount.toLocaleString()+'골드가 현상금으로 지급되었고 PK 표식이 해제됐습니다.');
 }else markPk(killer);
}
export function recoverPvpPlayer(p){if(!duelOf(p))try{restoreArenaPlayer(p);}catch(error){console.warn('[RPG arena recovery] '+error);}const state=registry(),owed=state.credits?.[p.id]??0;if(owed){const before=getWallet(p),amount=Math.min(owed,BALANCE_MAX-before.gold);try{setWallet(p,{...before,gold:before.gold+amount});state.credits[p.id]=owed-amount;save(state);}catch(error){setWallet(p,before);throw error;}}clearLegacyDuelProtection(p);refreshPk(p);}
export async function openPvp(p,arg=''){
 try{
  const text=String(arg).trim();if(text){if(['수락','accept'].includes(text))return acceptDuel(p);if(['거절','reject'].includes(text)){offers.delete(p.id);return;}if(['항복','surrender'].includes(text)){const d=duelOf(p);if(d)finishDuel(d,online(d.ids.find(id=>id!==p.id)),'항복');return;}const target=world.getAllPlayers().find(a=>a.name.toLowerCase()===text.toLowerCase());if(!target)throw Error('접속 중인 플레이어를 찾지 못했습니다.');return requestDuel(p,target);}
  const d=duelOf(p);if(d){const r=await showForm(new MessageFormData().title('진행 중인 결투').body('결투를 포기할까요?').button1('계속').button2('항복'),p);if(r&&!r.canceled&&r.selection===1)finishDuel(d,online(d.ids.find(id=>id!==p.id)),'항복');return;}
  const pending=offers.get(p.id);if(pending&&pending.until>Date.now()){const from=online(pending.from);const r=await showForm(new MessageFormData().title('결투 신청').body((from?.name??'상대')+'의 결투를 수락할까요? 두 사람 체력을 채운 뒤 시작합니다.').button1('거절').button2('수락'),p);if(r&&!r.canceled&&r.selection===1)return acceptDuel(p,pending.from);if(r&&!r.canceled&&offers.get(p.id)===pending)offers.delete(p.id);return;}
  const list=world.getAllPlayers().filter(a=>a.id!==p.id&&active(a)&&!duelOf(a)&&!inDungeon(a)).sort((a,b)=>a.name.localeCompare(b.name));
  const f=new ActionFormData().title('PvP · 상대 플레이어 선택').body((list.length?'결투할 플레이어를 선택하세요. 수락 시 두 사람이 PvP장으로 이동합니다.':'현재 신청 가능한 다른 플레이어가 없습니다. 상대가 서바이벌 상태로 접속했는지 확인하세요.')+'\n상대가 수락하면 체력을 회복하고 3초 후 시작합니다.\n내 PK 상태: '+(isPk(p)?'PK':'없음'));
  for(const a of list){const dist=distance(p,a);f.button(a.name+'\n'+(Number.isFinite(dist)?Math.ceil(dist)+'칸 거리':'다른 차원'));}
  f.button('닫기');const r=await showForm(f,p);
  if(!r||r.canceled||!Number.isInteger(r.selection)||r.selection<0||r.selection>=list.length)return;
  const target=list[r.selection];
  const confirm=await showForm(new MessageFormData().title('결투 신청 확인').body(target.name+'님에게 결투를 신청할까요? 상대가 수락해야 시작됩니다.').button1('취소').button2('신청'),p);
  if(confirm&&!confirm.canceled&&confirm.selection===1)requestDuel(p,target);
 }catch(error){tell(p,'§c[PvP] '+String(error.message??error));}
}
export function registerPvp(){
 if(registered)return;registered=true;
 world.afterEvents.entityHurt.subscribe(ev=>{try{observePvpHurt(ev);}catch(error){console.warn('[RPG PvP hurt] '+error);}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{try{recoverPvpPlayer(ev.player);}catch{}},20));
 world.afterEvents.playerLeave.subscribe(ev=>{const d=duelOf(ev.playerId);if(d)finishDuel(d,online(d.ids.find(id=>id!==ev.playerId)),'접속 종료로 패배');offers.delete(ev.playerId);});
 system.run(()=>{for(const p of world.getAllPlayers())try{recoverPvpPlayer(p);}catch{}});
 system.runInterval(()=>{for(const p of world.getAllPlayers()){try{clearLegacyDuelProtection(p);}catch{}}for(const [id,o]of offers)if(o.until<Date.now())offers.delete(id);for(const [id,h]of lastHits)if(h.until<Date.now())lastHits.delete(id);for(const d of new Set(duels.values())){const a=online(d.ids[0]),b=online(d.ids[1]);if(!active(a)||!active(b)||!insidePvpArena(a)||!insidePvpArena(b)||distance(a,b)>48||Date.now()>d.until)finishDuel(d,undefined,'시간 초과·범위 이탈·참가 상태 변경');}},20);
}

let reflectingPk=false;
export function reflectPkDamage(source,target,damage){
 source=pvpOwner(source);
 if(reflectingPk||source?.typeId!=='minecraft:player'||target?.typeId!=='minecraft:player'||source.id===target.id||!Number.isFinite(damage)||damage<=0||!isPk(source))return 0;
 const amount=damage*.7;reflectingPk=true;
 try{
  const h=hp(source);if(!h||h.currentValue<=0)return 0;const before=h.currentValue;
  source.applyDamage(amount,{cause:'override'});return Math.min(before,amount);
 }finally{reflectingPk=false;}
}

export function clearPkPenalty(admin,arg=''){
 const permitted=admin?.playerPermissionLevel===2||admin?.commandPermissionLevel>=1||admin?.isOp?.()===true;
 if(!permitted){tell(admin,'§c관리자만 PK 패널티를 해제할 수 있습니다.');return false;}
 const name=String(arg).trim().replace(/^"|"$/g,''),s=registry();
 const target=name?world.getAllPlayers().find(p=>p.name.toLowerCase()===name.toLowerCase()):admin;
 const id=target?.id??Object.keys(s.pk).find(id=>s.pk[id].name?.toLowerCase()===name.toLowerCase());
 if(!id){tell(admin,'§e해당 플레이어의 PK 기록을 찾지 못했습니다.');return false;}
 delete s.pk[id];save(s);lastHits.delete(id);if(target)refreshPk(target);
 tell(admin,'§a'+(target?.name??name)+' PK 패널티를 해제했습니다.');return true;
}
