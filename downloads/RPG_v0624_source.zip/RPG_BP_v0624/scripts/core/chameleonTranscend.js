import {getJobId,getSkills} from './playerData.js';
import {CHAMELEON_KEY,readChameleonProgress,saveChameleonProgress} from './chameleonProgress.js';
import {getWallet,setWallet,canAfford} from './wallet.js';
import {SKILLS} from '../data/skills.js';
import {hasDirectSkillPower,scaleSkillPower} from '../data/skillPower.js';
const has=(object,key)=>Object.prototype.hasOwnProperty.call(object,key);
export const TRANSCEND_MAX=3,TRANSCEND_UPGRADE_MAX=3;
export const TRANSCEND_COSTS=Object.freeze([{gold:200000,stone:800,dust:0},{gold:500000,stone:2000,dust:0},{gold:750000,stone:3000,dust:0}]);
export const TRANSCEND_MATERIALS=Object.freeze({'minecraft:netherite_ingot':2,'minecraft:diamond_block':9});
export const TRANSCEND_UPGRADE_COST=Object.freeze({gold:30000,stone:100,dust:0});
export const TRANSCEND_BASE_BONUS=.25,TRANSCEND_UPGRADE_BONUS=.10;
export function transcendMultiplier(level){return 1+TRANSCEND_BASE_BONUS+TRANSCEND_UPGRADE_BONUS*level;}
export function transcendLevel(p,id){if(getJobId(p)!=='chameleon'||!getSkills(p).includes(id))return undefined;const s=readChameleonProgress(p);return s.evolved.includes(id)&&has(s.transcended,id)?s.transcended[id]:undefined;}
export function transcendedSkillDefinition(p,def){const level=transcendLevel(p,def.id);return level===undefined?def:scaleSkillPower(def,transcendMultiplier(level));}
export function transcendQuote(p,id,mode='transcend'){
 if(getJobId(p)!=='chameleon'||!getSkills(p).includes(id)||!['transcend','upgrade'].includes(mode))return undefined;
 const s=readChameleonProgress(p);if(!s.evolved.includes(id)||!hasDirectSkillPower(SKILLS[id]))return undefined;
 const level=has(s.transcended,id)?s.transcended[id]:undefined,count=Object.keys(s.transcended).length;
 if(mode==='transcend'&&(level!==undefined||count>=TRANSCEND_MAX))return undefined;
 if(mode==='upgrade'&&(level===undefined||level>=TRANSCEND_UPGRADE_MAX))return undefined;
 const cost=mode==='transcend'?TRANSCEND_COSTS[count]:TRANSCEND_UPGRADE_COST;
 return {id,mode,cost:{...cost},materials:mode==='transcend'?{...TRANSCEND_MATERIALS}:{},order:count+1,level:mode==='transcend'?0:level+1,multiplier:transcendMultiplier(mode==='transcend'?0:level+1),fingerprint:JSON.stringify({evolved:s.evolved,transcended:s.transcended,skills:getSkills(p)})};
}
export function purchaseTranscend(p,id,mode='transcend',expected){
 let wallet,before,inv,entries=[],started=false;
 try{
  const q=transcendQuote(p,id,mode);if(!q)return {ok:false,message:'배운 진화 공격·직접 회복 기술만 초월할 수 있습니다. 초월은 최대 3개, 초월강화는 기술당 최대 3회입니다.'};
  if(expected!==undefined&&q.fingerprint!==expected)return {ok:false,message:'스킬·진화·초월 상태가 바뀌었습니다. 다시 선택하세요.'};
  wallet=getWallet(p);if(!canAfford(wallet,q.cost))return {ok:false,message:'골드 '+q.cost.gold.toLocaleString()+' / 강화석 '+q.cost.stone.toLocaleString()+'개가 필요합니다.'};
  inv=p.getComponent('minecraft:inventory')?.container;
  for(const [type,amount]of Object.entries(q.materials)){
   let need=amount;
   if(inv)for(let slot=0;slot<inv.size&&need>0;slot++){const item=inv.getItem(slot);if(item?.typeId!==type)continue;const take=Math.min(need,item.amount);entries.push({slot,old:item.clone(),take});need-=take;}
   if(need>0)return {ok:false,message:'초월 재료가 부족합니다. 네더라이트 주괴 2개와 다이아몬드 블록 9개가 필요합니다.'};
  }
  const state=readChameleonProgress(p);before=p.getDynamicProperty(CHAMELEON_KEY);state.transcended[id]=q.level;started=true;
  setWallet(p,{gold:wallet.gold-q.cost.gold,stone:wallet.stone-q.cost.stone,dust:wallet.dust});
  for(const entry of entries){if(entry.old.amount===entry.take)inv.setItem(entry.slot,undefined);else{const item=entry.old.clone();item.amount-=entry.take;inv.setItem(entry.slot,item);}}
  saveChameleonProgress(p,state);
  return {ok:true,level:q.level,multiplier:q.multiplier,message:SKILLS[id].name+' '+(mode==='transcend'?'초월':'초월강화 +'+q.level)+' 완료 · 피해·직접 회복량 +'+Math.round((q.multiplier-1)*100)+'%'};
 }catch(error){
  let recovered=true;if(started)for(const undo of [()=>setWallet(p,wallet),...entries.map(e=>()=>inv.setItem(e.slot,e.old)),()=>p.setDynamicProperty(CHAMELEON_KEY,before)])try{undo();}catch{recovered=false;}
  return {ok:false,message:recovered?'초월 저장 실패로 거래를 취소하고 재료·재화를 복구했습니다. '+String(error.message??error):'초월 거래 복구 실패. 관리자에게 문의하세요.'};
 }
}
