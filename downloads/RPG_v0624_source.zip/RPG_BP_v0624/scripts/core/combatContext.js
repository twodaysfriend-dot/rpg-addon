import {isTimeFrozen} from './timeStopDamage.js';
import {system} from '@minecraft/server';
import {notePvpAttack} from './pvp.js';
export function setCombatHealth(target,source,hp,next){if(isTimeFrozen(source))return;const amount=Math.max(0,hp.currentValue-next);notePvpAttack(source,target,amount);if(next<=0&&source)rememberScriptKiller(source,target);hp.setCurrentValue(next);}
export const BLACK_FLASH_KEY='rpg:black_flash_ready';
const hits=[],pending=[],credits=new Map();let onManual=()=>{},basicHandler=()=>{},manualObserver=()=>{},manualMultiplier=()=>1;
export function setManualDamageMultiplier(fn){manualMultiplier=fn;}
export function setManualDamageObserver(fn){manualObserver=fn;}
export function setUnreportedDamageHandler(fn){onManual=fn;}
export function setBasicHitHandler(fn){basicHandler=fn;}
export function handleBasicHit(ev,scripted){basicHandler(ev,scripted);}
const same=(h,s,t)=>h.source?.id===s?.id&&h.target?.id===t?.id;
export function currentScriptHit(source,target){return [...hits].reverse().find(h=>same(h,source,target));}
function prune(){for(let i=pending.length-1;i>=0;i--)if(pending[i].until<system.currentTick)pending.splice(i,1);}
export function markDamageReported(source,target){
 prune();const h=currentScriptHit(source,target)??pending.find(h=>same(h,source,target));if(h){h.reported=true;const i=pending.indexOf(h);if(i>=0)pending.splice(i,1);}return h;
}
export function noteManualDamage(source,target,damage,{incomingScaled=false}={}){
 if(!incomingScaled&&damage>0){try{const hp=target.getComponent('minecraft:health'),extra=Math.min(hp?.currentValue??0,damage*Math.max(0,manualMultiplier(target)-1));if(extra>0){if(extra>=hp.currentValue&&source)rememberScriptKiller(source,target);setCombatHealth(target,source,hp,Math.max(0,hp.currentValue-extra));damage+=extra;}}catch{}}
 const h=currentScriptHit(source,target);if(h)h.manualDamage=(h.manualDamage??0)+damage;try{manualObserver(source,target,damage);}catch{}
}

export function rememberScriptKiller(source,target){for(const [id,c]of credits)if(c.until<system.currentTick)credits.delete(id);credits.set(target.id,{source,until:system.currentTick+4});}
export function scriptKiller(target){const c=credits.get(target?.id);credits.delete(target?.id);return c&&c.until>=system.currentTick?c.source:undefined;}
export function scriptedHit(target,source,fn){
 if(isTimeFrozen(source))return false;
 let before;try{before=target.getComponent('minecraft:health')?.currentValue;}catch{}
 prune();const h={source,target,before,reported:false,until:system.currentTick+2};hits.push(h);pending.push(h);let result;
 try{result=fn();return result;}finally{
  hits.pop();if(h.manualDamage>0){try{onManual(source,target,h.manualDamage);}catch{}h.reported=true;}
  if(h.reported||result===false){const i=pending.indexOf(h);if(i>=0)pending.splice(i,1);}
 }
}
