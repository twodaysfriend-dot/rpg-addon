// Shared singleton for the custom-command startup module and RPG gameplay.
let handler = null;
let state = "loading";
let errors = [];
export function setCommandHandler(fn) { handler = typeof fn === "function" ? fn : null; }
export function getCommandHandler() { return handler; }
export function setGameplayStatus(nextState, details = []) {
  state = nextState;
  errors = Array.isArray(details) ? details.slice(0, 16) : [String(details)];
}
export function getGameplayStatus() { return { state, errors: errors.slice() }; }
