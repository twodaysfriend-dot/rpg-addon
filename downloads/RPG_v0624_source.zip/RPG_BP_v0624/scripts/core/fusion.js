import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {RARITY_KEY,PROMOTION_RATES} from '../data/grades.js';
import {itemRarity,rarityBadge} from '../data/rarity.js';
import {RUNES} from '../data/equipment.js';
import {upgradeLevel} from '../data/upgrades.js';
import {readRuneBag,writeRuneBag} from './runeInventory.js';
import {readGear,writeGear,gearFingerprint,setGearLevel,physicalGearOptions,gearLabel} from './gearState.js';
import {showForm} from './skillMenu.js';
const sameRef=(a,b)=>a?.kind===b?.kind&&a?.slot===b?.slot;
export const promotionBook=kind=>kind==='armor'?{id:'protection',level:4,name:'보호 IV'}:kind==='weapon'?{id:'sharpness',level:5,name:'날카로움 V'}:undefined;
function findPromotionBook(p,kind){
 const need=promotionBook(kind),inv=p.getComponent('minecraft:inventory')?.container;if(!need||!inv)return undefined;
 for(let slot=0;slot<inv.size;slot++){
  const item=inv.getItem(slot);if(item?.typeId!=='minecraft:enchanted_book'||item.amount<1)continue;
  const enchants=item.getComponent('minecraft:enchantable')?.getEnchantments()??[];
  if(enchants.some(e=>e.type.id.replace(/^minecraft:/,'')===need.id&&e.level===need.level))return {inv,slot,item:item.clone()};
 }
}
export function fusionQuote(p,mainRef,materialRef){
 if(sameRef(mainRef,materialRef))return undefined;
 let main,material,id,grade,kind,name,fingerprints,mainLevel,materialLevel;
 if(mainRef?.kind==='rune'&&materialRef?.kind==='rune'){
  const bag=readRuneBag(p);main=bag.runes.find(r=>r.uid===mainRef.slot);material=bag.runes.find(r=>r.uid===materialRef.slot);
  if(!main||!material||main.id!==material.id||main.grade!==material.grade||main.level<5||material.level<5)return undefined;
  mainLevel=main.level;materialLevel=material.level;id=main.id;grade=main.grade;kind='rune';name=RUNES[id].name;fingerprints=[JSON.stringify(main),JSON.stringify(material)];
 }else{
  main=readGear(p,mainRef);material=readGear(p,materialRef);const a=itemRarity(main),b=itemRarity(material);
  if(!a||!b||a.kind==='rune'||a.kind!==b.kind||main.typeId!==material.typeId||a.rank!==b.rank||main.amount!==1||material.amount!==1||upgradeLevel(main,a.kind)<5||upgradeLevel(material,b.kind)<5)return undefined;
  mainLevel=upgradeLevel(main,a.kind);materialLevel=upgradeLevel(material,b.kind);id=main.typeId;grade=a.rank;kind=a.kind;name=a.name;fingerprints=[gearFingerprint(main),gearFingerprint(material)];
 }
 if(PROMOTION_RATES[grade]===undefined)return undefined;
 const chance=mainLevel===10&&materialLevel===10?100:PROMOTION_RATES[grade];
 return {mainRef,materialRef,id,grade,kind,name,chance,mainLevel,materialLevel,fingerprint:JSON.stringify(fingerprints)};
}
export function fuseEquipment(p,mainRef,materialRef,expected,options={}){
 try{
  const q=fusionQuote(p,mainRef,materialRef);if(!q)return {ok:false,reason:'같은 종류·같은 등급의 +5 이상 장비 2개가 필요합니다. 신화는 승급할 수 없습니다.'};
  if(expected!==undefined&&expected!==q.fingerprint)return {ok:false,reason:'선택한 장비가 변경됐습니다. 다시 선택하세요.'};
  const requirement=promotionBook(q.kind),book=requirement?findPromotionBook(p,q.kind):undefined;
  if(requirement&&!book)return {ok:false,reason:requirement.name+' 효과부여 책 1권이 필요합니다.'};
  const draw=()=>{const n=(options.random??Math.random)();if(!Number.isFinite(n)||n<0||n>=1)throw Error('합성 난수 오류');return n;};
  const success=q.chance===100||draw()*100<q.chance;
  const downgraded=!success&&draw()<.5;
  if(q.kind==='rune'){
   const original=readRuneBag(p),next=JSON.parse(JSON.stringify(original));
   if(success){next.runes=next.runes.filter(r=>r.uid!==materialRef.slot);next.equipped=next.equipped.map(uid=>uid===materialRef.slot?null:uid);const target=next.runes.find(r=>r.uid===mainRef.slot);target.grade++;target.level=0;}
   else if(downgraded)next.runes.find(r=>r.uid===mainRef.slot).level--;
   try{writeRuneBag(p,next);}catch(error){try{writeRuneBag(p,original);}catch{console.error('[RPG fusion] rune rollback failed');}return {ok:false,reason:'저장 실패로 합성을 취소했습니다.'};}
  }else{
   const main=readGear(p,mainRef).clone(),material=readGear(p,materialRef).clone();let target;
   if(success){target=main.clone();target.setDynamicProperty(RARITY_KEY,q.grade+1);target=setGearLevel(target,q.kind,0);}
   else if(downgraded)target=setGearLevel(main,q.kind,q.mainLevel-1);
   try{
    // Failed promotions keep both equipment instances; only enhancement may fall.
    const remaining=book.item.amount>1?book.item.clone():undefined;if(remaining)remaining.amount--;book.inv.setItem(book.slot,remaining);
    if(success)writeGear(p,materialRef,undefined);if(target)writeGear(p,mainRef,target);
   }catch(error){
    let recovered=true;for(const undo of [()=>book.inv.setItem(book.slot,book.item),()=>writeGear(p,materialRef,material),()=>writeGear(p,mainRef,main)])try{undo();}catch{recovered=false;}
    if(!recovered)console.error('[RPG fusion] gear rollback failed: '+String(error));
    return {ok:false,reason:recovered?'저장 실패로 장비를 복구하고 합성을 취소했습니다.':'합성 복구 실패. 관리자에게 문의하세요.'};
   }
  }
  return {ok:true,success,grade:q.grade+(success?1:0),level:success?0:q.mainLevel-(downgraded?1:0),downgraded,chance:q.chance};
 }catch(error){return {ok:false,reason:'합성 오류: '+String(error)};}
}
function candidates(p){
 const out=physicalGearOptions(p).filter(e=>{const i=itemRarity(e.item);return i.rank<6&&upgradeLevel(e.item,i.kind)>=5;}).map(e=>({ref:e.ref,label:gearLabel(e.item)+' · '+(e.ref.kind==='equipment'?'착용 중':'가방 '+(e.ref.slot+1))}));
 for(const r of readRuneBag(p).runes)if(r.level>=5&&r.grade<6)out.push({ref:{kind:'rune',slot:r.uid},label:`${rarityBadge(r.grade)} ${RUNES[r.id].name} +${r.level} · ${r.uid}`});return out;
}
const opened=new Set();
export async function openFusionMenu(p){
 if(opened.has(p.id))return;opened.add(p.id);
 try{
  for(let loop=0;loop<40&&p.isValid;loop++){
   const list=candidates(p),f=new ActionFormData().title('장비 등급 합성').body('주장비를 선택하세요. 같은 종류·같은 등급 +5 이상 두 개로 합성합니다. 둘 다 +10이면 성공률 100%.\n성공: 다음 등급 +0 / 실패: 두 장비 보존, 50% 확률로 주장비 -1강.\n갑옷: 보호 IV 책 1권 / 공용 무기: 날카로움 V 책 1권 추가. 성공·실패 모두 책을 소모합니다. 룬은 책이 필요 없습니다.\n일반 → 레어 → 에픽 → 고대 → 영웅 → 전설 → 신화.');
   for(const e of list)f.button(e.label);f.button('닫기');
   const pick=await showForm(f,p);if(!pick||pick.canceled||pick.selection==null||pick.selection>=list.length)return;
   const main=list[pick.selection],materials=candidates(p).map(e=>({...e,q:fusionQuote(p,main.ref,e.ref)})).filter(e=>e.q);
   const m=new ActionFormData().title('소모할 재료 장비').body('선택한 재료는 성공할 때만 소멸합니다. 실패하면 두 장비가 남고 50% 확률로 주장비만 -1강됩니다. 재료의 인챈트·이름·내구도는 합쳐지지 않습니다.');
   for(const e of materials)m.button(e.label);m.button('뒤로');
   const selected=await showForm(m,p);if(!selected||selected.canceled||selected.selection==null||selected.selection>=materials.length)continue;
   const material=materials[selected.selection],q=material.q,book=promotionBook(q.kind);
   const confirm=await showForm(new MessageFormData().title('등급 합성 확인').body(`주장비: ${main.label}\n소모 재료: ${material.label}\n${book?book.name+' 책 1권도 성공·실패 모두 소모합니다.':'룬은 책을 소모하지 않습니다.'}\n\n성공률 ${q.chance}%\n성공: ${rarityBadge(q.grade+1)} +0\n실패: 두 장비 보존, 50% 확률로 주장비 -1강\n재료 장비는 성공 시에만 1개 소모됩니다.\n성공 시 강화 초기화로 당장 능력치가 낮아질 수 있습니다.`).button1('취소').button2('합성'),p);
   if(!confirm||confirm.canceled||confirm.selection!==1)continue;
   const result=fuseEquipment(p,main.ref,material.ref,q.fingerprint);
   p.sendMessage(result.ok?(result.success?'§a승급 성공! '+rarityBadge(result.grade)+' +0':(result.downgraded?'§e승급 실패. 두 장비 보존, 주장비 -1강.':'§e승급 실패. 두 장비와 강화 단계 유지.')):'§c'+result.reason);
  }
 }catch(error){try{p.sendMessage('§c합성 메뉴 오류: '+String(error));}catch{}}
 finally{opened.delete(p.id);}
}
