import * as mc from "@minecraft/server";
import { runRpgAction } from "./rpgActions.js";

// 슬래시 명령어 등록: /rpg:job 검성, /rpg:status 처럼 /scriptevent 없이 씁니다.
// (커스텀 명령어는 이름 앞에 네임스페이스 rpg: 가 반드시 붙습니다.)
// 없는 이름이 있어도 스크립트 전체가 죽지 않도록 모듈 전체(mc)를 통해 안전하게 꺼내고,
// 명령어마다 따로 등록해서 하나가 실패해도 나머지는 등록됩니다.
export function registerCommands() {
  const startup = mc.system.beforeEvents?.startup;
  if (!startup) return;

  startup.subscribe((init) => {
    console.warn("[rpg] v0.4.74 command registry startup...");
    const registry = init.customCommandRegistry;
    if (!registry) {
      console.warn("[rpg] 이 버전은 커스텀 명령어를 지원하지 않습니다. /scriptevent rpg:... 를 쓰세요.");
      return;
    }
    const perm = mc.CommandPermissionLevel ?? mc.CustomCommandPermissionLevel ?? {};
    const ANY = perm.Any ?? 0;
    const OP = perm.GameDirectors ?? 1; // 관리자(명령 블록 포함)
    const ok = mc.CustomCommandStatus?.Success ?? 0;
    const fail = mc.CustomCommandStatus?.Failure ?? 1;
    const STRING = mc.CustomCommandParamType?.String;

    // action: runRpgAction 의 동작 이름, param: 문자열 인자 이름(없으면 인자 없음)
    const add = (action, description, level, param) => {
      try {
        const def = { name: `rpg:${action}`, description, permissionLevel: level, cheatsRequired: false };
        if (param) {
          if (STRING === undefined) throw new Error("@minecraft/server CustomCommandParamType.String API missing");
          if (action === "wfly" || action === "citycreate") def.optionalParameters = [{ name: param, type: STRING }];
          else def.mandatoryParameters = [{ name: param, type: STRING }];
        }
        if(action==='setgrade')def.optionalParameters=[{name:'target',type:STRING}];
        registry.registerCommand(def, (origin, arg, target) => {
          const p = origin?.initiator ?? origin?.sourceEntity;
          if (p?.typeId !== "minecraft:player") {
            return { status: fail, message: "플레이어만 사용할 수 있습니다." };
          }
          // 명령어 콜백은 읽기 전용 구간이라, 아이템/창을 다루는 작업은 한 틱 뒤에 실행
          mc.system.run(() => {
            try {
              const value = action==='setgrade'?(Array.isArray(arg)?arg.slice(0,2):[arg,target]).filter(v=>v!==undefined).join(' '):(Array.isArray(arg) ? arg[0] : arg);
              runRpgAction(action, p, value);
            } catch (e) {
              console.warn(`[rpg] /rpg:${action} 실패: ${e}`);
            }
          });
          return { status: ok, message: `RPG ${action} 명령어 실행` };
        });
      } catch (e) {
        console.warn(`[rpg] /rpg:${action} 등록 실패: ${e}`);
      }
    };

    add("setgrade", "관리자: 장비 등급 직접 지정", OP, "grade");
    add("runebatch", "같은 종류·같은 등급 룬 일괄 강화", ANY);
    add("creativefunds", "크리에이티브 전용: 골드·강화석·룬 가루 무한 충전", ANY);
    add("citycreate", "관리자: 250×250 판타지 성곽 도시", OP, "height");
    add("citystop", "관리자: 성곽 도시 중지", OP);
    add("cityresume", "관리자: 성곽 마을 수동 재개", OP);
    add("citystatus", "관리자: 성곽 도시 진행도", OP);
    add("cityreset", "관리자: 건축 전 도시 검사 취소", OP);
    add("weapon", "공통 무기 대체 선택", ANY);
    add("rulebook", "책과 깃펜에 RPG 전체 명령어를 담아 지급합니다", ANY);
    add("ping", "RPG 명령어 등록 확인 (v0.4.74)", ANY);
    add("menu", "카멜레온 스킬 도감 열기", ANY);
    add("job", "조건을 지키며 전직합니다 (예: /rpg:job 마법사)", ANY, "job");
    add("help", "RPG 명령어 사용법을 확인합니다", ANY);
    add("status", "내 직업, 마나, 스탯을 봅니다", ANY);
    add("stats", "RPG 레벨과 스탯 자유 분배 메뉴", ANY);
    add("admin", "RPG 운영자 관리 도구 지급", OP);
    add("egg", "RPG 몬스터 소환 알 메뉴를 엽니다 (관리자)", OP);
    add("setlevel", "RPG 레벨을 1~100000 강제 설정합니다 (관리자)", OP, "amount");
    add("setmana", "최대 마나를 1~100000 강제 설정합니다 (관리자, reset 가능)", OP, "amount");
    add("skills", "책/지팡이의 스킬을 켜고 끄는 설정창을 엽니다", ANY);
    add("skillbook", "카멜레온의 모든 직업 스킬 습득 메뉴", ANY);
    add("learn", "카멜레온 스킬 습득 (예: /rpg:learn hacker_ddos)", ANY, "skill");
    add("swap", "카멜레온의 흑염 대검·백월의 낫 교체", ANY);
    add("book", "인벤토리의 인챈트 책을 바쳐 최대 마나를 늘립니다", ANY);
    add("sword", "다이아몬드 검을 바쳐 검성 전직 조건을 채웁니다", ANY);
    add("bless", "축복의 빛을 바쳐 천사/미카엘 전직 조건을 채웁니다", ANY);
    add("holywater", "물병 1개와 축복의 빛 1개로 성수를 만듭니다 (조합이 안 될 때)", ANY);
    add("force", "조건 무시하고 전직합니다 (관리자)", OP, "job");
    add("reset", "견습으로 초기화합니다 (관리자)", OP);
    add("starter", "견습 시작 아이템과 스킬을 받습니다 (관리자) - sword, mage, holy, fist, archer", OP, "line");
    add("charge", "마나를 가득 채우고 쿨타임을 초기화합니다 (관리자)", OP);
    add("items", "애드온 전용 아이템을 전부 받습니다 (관리자)", OP);
    add("wfly", "더 월드 비행 켜기 (/rpg:wfly off 로 끄기)", ANY, "mode");
    add("wings", "천사/미카엘/타락 계열의 날개를 켜거나 끕니다", ANY);
    add("wingcheck", "날개 아이템 보조손 장착 및 활성 상태 확인", ANY);
    add("wingrefresh", "보조손 날개 재장착으로 표시 갱신", ANY);
    add("guild", "길드 생성·초대·관리 메뉴를 엽니다", ANY);
    add("party", "파티 생성·초대·관리 메뉴를 엽니다", ANY);
    add("invites", "받은 길드·파티 초대를 확인합니다", ANY);
    add("boss", "바위 골렘을 앞에 소환합니다 (관리자)", OP);
    add("cyclops", "외눈박이 거인 보스를 앞에 소환합니다 (관리자)", OP);
    add("hydra", "지옥의 히드라 보스를 앞에 소환합니다 (관리자)", OP);
    add("techgolem", "마공학 블럭 골렘을 앞에 소환합니다 (관리자)", OP);
    add("fistcheck", "무투가·권골 무장색 장착 상태 확인", ANY);
    console.warn("[rpg] custom slash commands registration attempted");
  });
}

// Subscribe during module initialization, before main.js registers gameplay systems.
registerCommands();
