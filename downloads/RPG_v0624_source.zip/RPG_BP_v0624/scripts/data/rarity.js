import {ITEM_BASE_NAMES} from './itemBaseNames.js';
import {COMMON_WEAPONS} from './commonWeapons.js';
import {armorInfo,RUNES,PART_NAMES,ARMOR_PARTS} from './equipment.js';
import {RARITIES,gradeRank,itemGrade} from './grades.js';
export {RARITIES};
const COLORS=['§7','§9','§5','§3','§a','§6','§d'];
export function rarityBadge(rank){const n=gradeRank(rank);return COLORS[n]+'['+RARITIES[n]+']§r';}
export const runeRarity=(grade=0)=>gradeRank(grade);
export const armorRarity=(set,grade=0)=>gradeRank(grade);
export function itemRarity(item){
 const id=item?.typeId;if(!id)return undefined;
 let name,kind;const a=armorInfo(id),w=COMMON_WEAPONS.find(w=>w.id===id);
 if(a){name=a.name+' '+PART_NAMES[ARMOR_PARTS.indexOf(a.part)];kind='armor';}
 else if(id.startsWith('rpg:rune_')&&RUNES[id.slice(9)]){name=RUNES[id.slice(9)].name;kind='rune';}
 else if(w){name=w.name;kind='weapon';}else return undefined;
 return {rank:itemGrade(item),name:ITEM_BASE_NAMES[id]??name,kind};
}
