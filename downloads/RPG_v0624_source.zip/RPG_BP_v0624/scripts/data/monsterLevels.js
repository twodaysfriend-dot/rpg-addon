import {DUNGEON_TIERS} from './dungeons.js';
export const MONSTER_LEVELS=Object.freeze([1,5,10,15,20,30,40,55,70,90,115,145,180,220,260]);
export const DUNGEON_LEVEL_INDEX=Object.freeze([2,4,5,6,7,8,9,10,11,12]);
export const DUNGEON_HEALTH_PRESSURE=Object.freeze([1,1,1,1,1,1,1,1,1,1]);
export const MONSTER_LEVEL_KEY='rpg:monster_level';
export const levelHealthMultiplier=level=>1+Math.max(0,level-1)*.035;
export const levelAttackMultiplier=level=>1+Math.max(0,level-1)*.018;
export const MONSTER_CONTEXT_KEY='rpg:monster_context';
export const WILD_HEALTH_SCALE=.9,WILD_ATTACK_SCALE=.9;
export function monsterContext(entity){try{const raw=entity?.getDynamicProperty?.(MONSTER_CONTEXT_KEY);const c=typeof raw==='string'?JSON.parse(raw):undefined;return c&&Number.isInteger(c.tier)&&c.tier>=1&&c.tier<=10&&['normal','elite','boss'].includes(c.kind)?c:undefined;}catch{return undefined;}}
export function monsterDefenseFor(level,context){
 const slope=context?0.004:0.0036;
 const pressure=context&&context.tier>=2?1+(context.tier-2)*.04:1;
 return 1/(1+Math.max(0,level-1)*slope)/pressure;
}
export function monsterDefenseMultiplier(entity){let level;try{level=entity?.getDynamicProperty?.(MONSTER_LEVEL_KEY);}catch{}return Number.isFinite(level)?monsterDefenseFor(level,monsterContext(entity)):1;}
export function monsterCombatMultipliers(level,context){
 const tier=context?DUNGEON_TIERS[context.tier-1]:undefined;
 const kindHealth=tier&&tier.tier>=2?(context.kind==='boss'?2:context.kind==='elite'?1.35:1):1;
 return {
  health:levelHealthMultiplier(level)*(tier?tier.hpMultiplier*kindHealth:WILD_HEALTH_SCALE),
  attack:levelAttackMultiplier(level)*(tier?tier.attackMultiplier:WILD_ATTACK_SCALE),
  defense:monsterDefenseFor(level,context)
 };
}
export function monsterAttackMultiplier(entity){let level=1;try{level=entity?.getDynamicProperty?.(MONSTER_LEVEL_KEY)??1;}catch{}return monsterCombatMultipliers(level,monsterContext(entity)).attack;}
export const levelRewardMultiplier=entity=>{
 let level;try{level=entity?.getDynamicProperty?.(MONSTER_LEVEL_KEY);}catch{}
 return Number.isFinite(level)?Math.min(4,1+Math.max(0,level-1)*.01):1;
};
export function dungeonMonsterLevel(tier,kind,index=0){
 const base=DUNGEON_LEVEL_INDEX[Math.max(0,Math.min(9,tier-1))];
 const offset=kind==='boss'?2:kind==='elite'?1:[-1,0,1][index%3];
 return MONSTER_LEVELS[Math.max(0,Math.min(MONSTER_LEVELS.length-1,base+offset))];
}
export function wildMonsterLevel(location,random=Math.random){
 const distance=Math.max(Math.abs(location.x),Math.abs(location.z));
 const indices=distance<=1500?[0,1,2,3]:distance<=4000?[4,5,6,7]:[8,9,10,11];
 const n=random();if(!Number.isFinite(n)||n<0||n>=1)throw Error('몬스터 레벨 난수 오류');
 return MONSTER_LEVELS[indices[Math.floor(n*indices.length)]];
}
