export const TEMPLE_KEY='rpg:celestial_temple_v1';
export const TEMPLE_RADIUS=13,TEMPLE_HEIGHT=14,TEMPLE_BUDGET=128;
export function celestialPhase(time){const t=((Number(time)||0)%24000+24000)%24000;return t<12000?'sun':'moon';}
export function altarPosition(t,kind){return {x:t.x+(kind==='sun'?-7:7),y:t.y+2,z:t.z};}
const pillars=Array.from({length:8},(_,i)=>({x:Math.round(Math.cos(i*Math.PI/4)*10),z:Math.round(Math.sin(i*Math.PI/4)*10)}));
export function templeBlock(x,y,z){
 const r=Math.hypot(x,z),sun=x<0,base=sun?'minecraft:quartz_block':'minecraft:polished_blackstone',accent=sun?'minecraft:gold_block':'minecraft:amethyst_block';
 if(r>TEMPLE_RADIUS||y<0||y>TEMPLE_HEIGHT)return undefined;
 if(y===0){if(r>12)return 'minecraft:obsidian';if(Math.abs(x)<=1||Math.abs(z)<=1)return 'minecraft:quartz_block';return (x*x+z*z)%11===0?'minecraft:sea_lantern':base;}
 for(const a of [-7,7])if(Math.abs(x-a)<=1&&Math.abs(z)<=1&&y===1)return x===a&&z===0?(a<0?'minecraft:gold_block':'minecraft:amethyst_block'):(a<0?'minecraft:quartz_block':'minecraft:obsidian');
 if(y===2&&z===0&&(x===-7||x===7))return accent;
 if(y===1&&r>=12&&Math.abs(x)>2&&Math.abs(z)>2)return base;
 for(const p of pillars)if(x===p.x&&z===p.z&&y>=1&&y<=8)return y===1||y===8?accent:base;
 if((y===9&&r>=9&&r<=11)||(y===10&&r>=9&&r<=10))return (x+z)%4===0?accent:base;
 // Raised sun disk and crescent silhouette on opposite outer arches.
 if(x===-10&&y>=10&&y<=14&&Math.abs(z)<=2){const d=Math.hypot(z,y-12);if(d<=2)return d<.7?'minecraft:sea_lantern':'minecraft:gold_block';}
 if(x===10&&y>=10&&y<=14&&Math.abs(z)<=2){const d=Math.hypot(z,y-12);if(d<=2&&Math.hypot(z-1,y-12)>1.5)return 'minecraft:amethyst_block';}
 return undefined;
}
export const TEMPLE_VOLUME=(TEMPLE_RADIUS*2+1)**2*(TEMPLE_HEIGHT+1);
export function templeOffset(index){const size=TEMPLE_RADIUS*2+1;return {x:index%size-TEMPLE_RADIUS,z:Math.floor(index/size)%size-TEMPLE_RADIUS,y:Math.floor(index/(size*size))};}
