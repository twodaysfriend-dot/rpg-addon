// Pure deterministic plan. Local bounds are EXACTLY 0..999 on X and Z.
// Operations are priority ordered. The builder only fills air, so doors/windows,
// paths and furniture precede their lower-priority shells and ground.
export const CITY_SIZE=1000,CITY_TILE=64,CITY_TILES=16;
export function cityTile(index){const x=index%CITY_TILES*CITY_TILE,z=Math.floor(index/CITY_TILES)*CITY_TILE;return {x,z,x2:Math.min(999,x+63),z2:Math.min(999,z+63)};}
export function makeFantasyCityPlan(){
 const plan=[];let houses=0;
 const rect=(x,y,z,x2,y2,z2,type)=>{if(x>x2||y>y2||z>z2)return;plan.push({x,y,z,x2,y2,z2,type:'minecraft:'+type});};
 const wall=(x,z,w,d,h,mat='stone_bricks',door=true)=>{
  // Three-block door opening in the front wall; open arches need no fragile door block states.
  const mid=x+Math.floor(w/2);
  if(door){rect(x,1,z,mid-2,h,z,mat);rect(mid+2,1,z,x+w-1,h,z,mat);rect(mid-1,4,z,mid+1,h,z,mat);}
  else rect(x,1,z,x+w-1,h,z,mat);
  rect(x,1,z+d-1,x+w-1,h,z+d-1,mat);rect(x,1,z+1,x,h,z+d-2,mat);rect(x+w-1,1,z+1,x+w-1,h,z+d-2,mat);
 };
 const tower=(x,z,w,h)=>{
  rect(x+3,h+2,z+3,x+w-4,h+2,z+w-4,'blue_concrete');
  for(let i=0;i<w;i+=4){rect(x+i,h+1,z,x+Math.min(i+1,w-1),h+2,z,'stone_bricks');rect(x+i,h+1,z+w-1,x+Math.min(i+1,w-1),h+2,z+w-1,'stone_bricks');rect(x,h+1,z+i,x,h+2,z+Math.min(i+1,w-1),'stone_bricks');rect(x+w-1,h+1,z+i,x+w-1,h+2,z+Math.min(i+1,w-1),'stone_bricks');}
  rect(x,h,z,x+w-1,h,z+w-1,'stone_bricks');wall(x,z,w,w,h-1,'stone_bricks',true);rect(x,0,z,x+w-1,0,z+w-1,'stone_bricks');
 };
 const house=(x,z,w,d,theme=0)=>{
  houses++;
  const roof=['dark_oak_planks','spruce_planks','deepslate_tiles'][theme%3];
  // Interior furniture and lit windows, placed before walls.
  rect(x+2,1,z+d-3,x+2,1,z+d-3,'crafting_table');rect(x+w-3,1,z+d-3,x+w-3,1,z+d-3,'chest');
  rect(x+2,5,z+2,x+2,5,z+2,'sea_lantern');
  for(let n=3;n<w-2;n+=6){rect(x+n,3,z,x+n+1,4,z,'glass');rect(x+n,3,z+d-1,x+n+1,4,z+d-1,'glass');}
  for(let n=3;n<d-2;n+=6){rect(x,3,z+n,x,4,z+n+1,'glass');rect(x+w-1,3,z+n,x+w-1,4,z+n+1,'glass');}
  for(let step=0;step<Math.ceil(w/2);step++)rect(x+step,7+step,z-1,x+w-1-step,7+step,z+d,roof);
  for(const a of [x,x+w-1])for(const b of [z,z+d-1])rect(a,1,b,a,6,b,'oak_log');
  wall(x,z,w,d,6,theme%2?'stone_bricks':'white_terracotta');rect(x,0,z,x+w-1,0,z+d-1,'oak_planks');
  const mid=x+Math.floor(w/2);rect(mid-1,0,z-5,mid+1,0,z-1,'cobblestone');
 };
 // Royal keep and four spires; central plaza south of castle remains open.
 rect(492,0,602,507,0,617,'gold_block');
 rect(497,1,515,502,2,520,'gold_block');
 for(const x of [470,486,510,526]){rect(x,10,450,x+5,17,450,'blue_stained_glass');rect(x,10,529,x+5,17,529,'blue_stained_glass');}
 rect(458,0,450,541,0,529,'polished_blackstone_bricks');
 // Raise royal roof and main hall without overwriting interior openings.
 for(let i=0;i<12;i++)rect(458+i,26+i,448,541-i,26+i,531,'deepslate_tiles');
 wall(458,450,84,80,25,'polished_blackstone_bricks');
 for(const x of [423,553])for(const z of [423,553])tower(x,z,24,38);
 // Courtyard walls leave a grand south/north entrance.
 for(const [a,b]of [[420,485],[514,579]]){rect(a,1,420,b,12,423,'stone_bricks');rect(a,1,576,b,12,579,'stone_bricks');}
 rect(420,1,424,423,12,575,'stone_bricks');rect(576,1,424,579,12,575,'stone_bricks');
 rect(420,0,420,579,0,579,'stone_bricks');rect(450,0,585,549,0,654,'smooth_quartz');
 // Fountain pools: rim walls plus inset water, with independent solid bottom.
 for(const x of [468,524]){
  rect(x+2,1,623,x+9,1,630,'water');rect(x+5,2,626,x+6,5,627,'sea_lantern');
  rect(x,1,621,x+11,1,622,'stone_bricks');rect(x,1,631,x+11,1,632,'stone_bricks');rect(x,1,623,x+1,1,630,'stone_bricks');rect(x+10,1,623,x+11,1,630,'stone_bricks');rect(x,0,621,x+11,0,632,'stone_bricks');
 }
 // Temple, guild hall, market and residential districts.
 house(680,220,44,38,0);house(220,220,44,38,2);house(220,720,44,38,1);
 for(let gx=0;gx<10;gx++)for(let gz=0;gz<10;gz++){
  if(gx>=4&&gx<=5&&gz>=4&&gz<=6)continue;
  if((gx===2&&[2,7].includes(gz))||(gx===6&&gz===2))continue;
  const x=gx*100,z=gz*100;
  if(x+18>=40&&z+20>=40&&x+42<=960&&z+42<=960)house(x+18,z+20,24,22,(gx+gz)%3);
  if(x+61>=40&&z+59>=40&&x+79<=960&&z+75<=960)house(x+61,z+59,18,16,(gx+gz+1)%3);
 }
 // Outer curtain walls have four 28-block wide open gates.
 for(const [a,b]of [[0,485],[514,999]]){
  rect(a,1,0,b,12,4,'stone_bricks');rect(a,1,995,b,12,999,'stone_bricks');rect(0,1,a,4,12,b,'stone_bricks');rect(995,1,a,999,12,b,'stone_bricks');
 }
 for(let n=0;n<1000;n+=8)if(n<480||n>515)for(const edge of [0,998]){
  rect(n,13,edge,Math.min(n+3,999),14,edge+1,'stone_bricks');rect(edge,13,n,edge+1,14,Math.min(n+3,999),'stone_bricks');
 }
 for(const x of [6,966])for(const z of [6,966])tower(x,z,28,23);
 for(const a of [460,520]){tower(a,6,20,20);tower(a,974,20,20);tower(6,a,20,20);tower(974,a,20,20);}
 // Lit main avenues and secondary streets.
 for(let x=50;x<1000;x+=100)for(let z=50;z<1000;z+=100){
  if(x>=400&&x<=600&&z>=400&&z<=650)continue;
  rect(x,1,z,x,4,z,'oak_fence');rect(x,5,z,x,5,z,'sea_lantern');
 }
 rect(486,0,0,513,0,999,'polished_andesite');rect(0,0,486,999,0,513,'polished_andesite');
 for(let i=100;i<1000;i+=100){rect(i-3,0,6,i+3,0,993,'cobblestone');rect(6,0,i-3,993,0,i+3,'cobblestone');}
 // Last priority: gardens and continuous foundation, never clearing existing blocks.
 rect(0,0,0,999,0,999,'grass_block');rect(0,-1,0,999,-1,999,'stone_bricks');
 return {operations:plan,houses};
}
export function tileOperations(plan,tile){return plan.map(op=>({...op,x:Math.max(op.x,tile.x),x2:Math.min(op.x2,tile.x2),z:Math.max(op.z,tile.z),z2:Math.min(op.z2,tile.z2)})).filter(op=>op.x<=op.x2&&op.z<=op.z2).sort((a,b)=>(a.type==='minecraft:water')-(b.type==='minecraft:water'));}
export const CITY_TRAINERS=[['archer',482,609],['holy',488,609],['sword',494,609],['mage',500,609],['fist',506,609],['nen',512,609],['the_world',518,609],['war_god',524,609]];
