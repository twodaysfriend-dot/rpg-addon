// UI guidance only. These labels never change damage, healing, or stat allocation.
export const LINE_STAT_GUIDES=Object.freeze({
 sword:{label:'근력',note:'참격·검기 등 물리 공격 스킬 위주입니다.'},
 mage:{label:'마력',note:'마법 공격 피해를 높입니다.'},
 archer:{label:'근력',note:'궁수 공격 스킬 위주입니다. 기본 화살은 엔진 피해이며 천궁 마나 화살의 기본 피해는 고정입니다.'},
 holy:{label:'마력',note:'성직 공격과 직접 회복량을 높입니다.'},
 fist:{label:'근력 우선 · 풍압은 마력',note:'난타·스매쉬 등은 근력, 풍압은 마력을 사용합니다.'},
 berserker:{label:'근력',note:'근접 공격과 야수 공격 기술은 물리 스탯 보정을 받습니다.'},
 assassin:{label:'근력',note:'암살 공격 스킬 위주입니다.'},
 harpoon:{label:'근력',note:'현재 작살·돌진·출혈 공격은 근력 보정을 받습니다. 처형의 체력 비율 조건은 스탯과 별개입니다.'},
 blood:{label:'마력 우선 · 혈인 근접은 근력',note:'혈액 공격 대부분은 마력, 혈인의 근거리 타격은 근력을 사용합니다.'},
 hacker:{label:'마력',note:'직접 공격 기술의 마법 피해를 높입니다. 지원·재사용 효과는 기술 설명을 확인하세요.'},
 dragon:{label:'근력 우선 · 브레스는 마력',note:'삼조격·질주 등은 근력, 브레스는 마력을 사용합니다.'},
 frost:{label:'마력',note:'냉기 마법 공격 피해를 높입니다.'},
 fire:{label:'마력',note:'화염 마법 공격 피해를 높입니다.'},
 tech:{label:'마력',note:'구체·폭탄·폭풍 등 마법공학 공격 위주입니다.'},
 demon:{label:'마력',note:'악마 마법 공격 위주입니다.'},
 celestial_sun:{label:'마력 우선 · 메테오드라이브 충돌은 근력',note:'광선·마법 공격은 마력, 메테오드라이브의 돌진 충돌은 근력입니다. 일륜참은 다음 도끼 타격을 강화합니다.'},
 celestial_moon:{label:'근력',note:'달의 후예 공격 기술은 물리 스탯 보정을 받습니다.'},
 the_world:{label:'근력',note:'흡혈·무다·러시 등 직접 공격은 물리 스탯 보정을 받습니다. 시간 정지 길이는 사용 숙련도로 늘어납니다.'},
 war_god:{label:'근력',note:'투신 공격 기술은 물리 스탯 보정을 받습니다.'},
 nen:{label:'복합 (근력·마력)',note:'경·주·참격파는 근력, 발 구체·연탄·오라포·오라 폭주는 마력입니다. 주로 쓰는 기술에 맞춰 투자하세요.'},
 chameleon:{label:'복합',note:'근력·마력을 함께 고려하세요. 배우고 주로 사용하는 물리·마법 기술에 맞춰 투자합니다.'},
 all:{label:'복합 (체험 계열에 따라 선택)',note:'검사·궁수·무투가 체험은 근력, 마법사·성직자 체험은 마력이 중심입니다.'},
});
export function lineStatLabel(line){return LINE_STAT_GUIDES[line]?.label??'스킬 설명 확인';}
export function lineStatText(line){const g=LINE_STAT_GUIDES[line];return '§e추천 스탯: '+lineStatLabel(line)+'§r'+(g?'\n'+g.note:'');}
export function jobStatText(job,contextLine){return lineStatText(job?.id==='chameleon'?'chameleon':job?.id==='apprentice'?(contextLine??'all'):job?.line);}
