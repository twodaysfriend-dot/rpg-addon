import {COMMON_WEAPONS} from './commonWeapons.js';
export const ARMOR_SETS = {
  abyssal:{name:'심연 수호자',protection:[3,8,6,3],durability:[550,800,750,650],health:16,physical:1.08,magic:1.08,ward:true,description:'4세트: 최대 HP +16, 물리·마법 스킬 +8%, 저항 I 유지. 기본 방어 합계 20·내구도 네더라이트 이상'},
  adventurer: {name:'모험가', protection:[2,5,4,2], durability:[220,320,300,220], physical:1.08, description:'4세트: 물리 스킬 피해 +8%'},
  warden: {name:'숲 수호자', protection:[3,6,5,2], durability:[300,450,420,300], health:8, description:'4세트: 최대 HP +8'},
  astral: {name:'별빛 술사', protection:[2,5,4,2], durability:[260,400,375,260], magic:1.08, manaRegen:3, description:'4세트: 마법 스킬 피해 +8%, 초당 마나 +3'},
};
export const ARMOR_PARTS = ['helmet','chestplate','leggings','boots'];
export const PART_NAMES = ['투구','흉갑','각반','장화'];
export const RUNES = {
  power:{name:'힘의 룬', description:'물리 스킬 피해 +6.8%, 강화마다 +1.36%p. +1부터 공용·직업 무기 근접 평타에도 추가 피해. 영웅 이상: +8 물리 +1.2%p / +9 신속 I / +10 물리 +1.6%p (전설 ×1.5, 신화 ×2.25)', physical:1.17},
  ward:{name:'수호의 룬', description:'RPG 방어력 +4, 강화마다 +2 (일반 +10: +24). 방어력 1당 피해 감소 0.35%p. 저항 효과는 부여하지 않음. 영웅 이상: +8 최대 HP +6 / +9 재생 I / +10 최대 HP +10 (전설 ×1.5, 신화 ×2.25)', defense:4},
  mana:{name:'샘의 룬', description:'초당 최대 마나의 1% 추가 회복. 영웅 이상: +8 마나 회복 +0.3%p / +9 신속 I / +10 마나 회복 +0.5%p (전설 ×1.5, 신화 ×2.25)', manaRegenPercent:0.01},
  arcane:{name:'비전의 룬', description:'마법 스킬 피해 +6.8%, 강화마다 +1.36%p. +1부터 공용·직업 무기 근접 평타에도 추가 피해. 영웅 이상: +8 마법 +1.2%p / +9 마나 회복 +0.4%p / +10 마법 +1.6%p (전설 ×1.5, 신화 ×2.25)', magic:1.17},
  vitality:{name:'생명의 룬', description:'최대 HP +4, 강화마다 +2 (일반 +10: +24). 영웅 이상: +8 최대 HP +6 / +9 재생 I / +10 최대 HP +10 (전설 ×1.5, 신화 ×2.25)', health:4},
  absorption:{name:'흡수의 룬',description:'적에게 준 피해의 2.5%를 HP로 회복, 일반 최대 강화 6%. 영웅 이상: +8 흡혈 +0.5%p / +9 최대 HP +6 / +10 흡혈 +0.75%p (전설 ×1.5, 신화 ×2.25)',lifesteal:.05},
};
export const RUNE_KEY = 'rpg:chest_rune';
export const ALL_EQUIPMENT_IDS = [
  'rpg:armor_transfer_seal',...COMMON_WEAPONS.map(w=>w.id), 'rpg:enhancement_catalyst', 'rpg:random_skillbook', 'rpg:stat_reset_scroll', 'rpg:job_waiver',
  ...Object.keys(ARMOR_SETS).flatMap(set=>ARMOR_PARTS.map(part=>`rpg:${set}_${part}`)),
  ...Object.keys(RUNES).map(rune=>`rpg:rune_${rune}`),
];
export function armorInfo(typeId) {
  for (const [set, data] of Object.entries(ARMOR_SETS)) {
    for (let i=0;i<ARMOR_PARTS.length;i++) if (typeId === `rpg:${set}_${ARMOR_PARTS[i]}`) return {set, part:ARMOR_PARTS[i], ...data};
  }
  return undefined;
}
