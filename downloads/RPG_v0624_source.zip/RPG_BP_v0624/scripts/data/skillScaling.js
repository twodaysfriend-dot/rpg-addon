// Descriptive metadata only: changing this file never changes combat damage.
import {SKILLS} from './skills.js';
const MAGIC=new Set(['mage','holy','necro','fire','frost','tech','demon','blood','hacker','celestial_sun']);
const PHYSICAL=new Set(['sword','fist','archer','assassin','harpoon','berserker','war_god','nen','dragon','celestial_moon','chameleon']);
export function skillScalingInfo(id){
 const s=SKILLS[id];if(!s)return '미등록 기술';
 if(id==='hacker_copy')return '복제한 궁극기의 피해 방식에 따릅니다. 카피를 마력 피해 하나로 단정하지 않습니다.';
 if(id==='sun_meteor_drive')return '혼합: 광선은 마력(마법), 돌진 충격은 근력(물리) 보정입니다.';
 if(id==='blood_mark')return '혼합: 근거리는 근력(물리), 원거리 혈원반은 마력(마법) 보정입니다.';
 if(id==='fist_finale'||id==='chameleon_crimson_dash')return '고정 피해: 근력·마력·힘 버프·피해 룬으로 증폭하지 않습니다.';
 if(id==='demon_contract')return '적 대상 피해는 고정 피해입니다. 우클릭 자가 강화는 근력·마력으로 피해를 계산하는 공격이 아닙니다.';
 if(id==='revenant_execution')return '성공 시 HP 비율 조건에 따른 처형. 실패 피해는 근력(물리) 보정입니다.';
 if(id==='blood_spear')return '마력(마법) 보정. 힘 버프 보정은 제외하며 무적 시간을 무시합니다.';
 if(id==='fist_wind'||id==='dragon_breath')return '마력(마법) 보정. 직업 기본 근력 계열과 다른 예외 기술입니다.';
 if(id==='nen_renda'||id==='nen_ho'||id==='nen_boku')return '마력(마법) 보정: 방출 기술의 피해는 마력과 마법 장비·룬을 기준으로 계산합니다. 지능 효율은 소모량에만 적용됩니다.';
 if(id==='nen_zan')return '근력(물리) 보정: 근력과 물리 장비·룬을 기준으로 계산합니다. 경(硬) 추가 피해도 물리 피해입니다.';
 if(id==='nen_hatsu')return '마력(마법) 보정: 오라 구체의 폭발 피해는 마력과 마법 장비·룬을 기준으로 계산합니다. 넨 능력자의 지능 효율은 소모량에만 적용됩니다.';
 if(id==='war_god_black_flash')return '다음에 사용하는 투신 공격 스킬의 피해를 3배로 강화합니다. 평타는 강화되지 않습니다.';
 if(id==='sun_slash'||id==='fist_strong'||id==='berserker_execute'||id==='assassin_stealth'||id==='dragon_triple_strike')return '기본 근접 공격 또는 후속 물리 타격을 강화합니다. 자세한 적용 대상·횟수는 기술 효과를 확인하세요.';
 const dealsDamage=Object.keys(s).some(k=>/damage/i.test(k)&&typeof s[k]==='number'&&s[k]>0);
 if(!dealsDamage)return '직접 타격 피해가 없는 지원·회복·제어 기술입니다. 근력/마력 피해 배율로 분류하지 않습니다. 회복량 등은 기술별 규칙을 따릅니다.';
 if(id==='demon_reap'||PHYSICAL.has(s.line))return '근력(물리) 보정: 근력과 물리 장비·룬을 기준으로 계산합니다.';
 if(MAGIC.has(s.line))return '마력(마법) 보정: 마력과 마법 장비·룬을 기준으로 계산합니다.';
 return '세부 효과별 규칙을 따릅니다. 기술 설명을 확인하세요.';
}
