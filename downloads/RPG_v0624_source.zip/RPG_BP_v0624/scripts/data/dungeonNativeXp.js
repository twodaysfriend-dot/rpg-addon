// Original native orb XP; dungeon-only event suppresses orbs and pools these exact values.
export const DUNGEON_NATIVE_XP=Object.freeze({
  "rpg:gold_goblin": 22,
  "rpg:elite_scorpion": 40,
  "rpg:elite_gold_goblin": 44,
  "rpg:red_mushroom": 3,
  "rpg:elite_mantis": 48,
  "rpg:red_goblin": 12,
  "rpg:green_goblin": 6,
  "rpg:elite_red_mushroom": 6,
  "rpg:mantis": 18,
  "rpg:blue_mushroom": 5,
  "rpg:elite_green_goblin": 12,
  "rpg:elite_goblin_captain": 80,
  "rpg:scorpion": 15,
  "rpg:cyclops_boss": 600,
  "rpg:hydra_boss": 900,
  "rpg:tech_block_golem_boss": 850,
  "rpg:rock_golem_boss": 450,
  "rpg:elite_red_goblin": 24,
  "rpg:elite_blue_mushroom": 10
});
