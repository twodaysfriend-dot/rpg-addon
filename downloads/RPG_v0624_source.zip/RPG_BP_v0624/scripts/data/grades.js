// Rarity is instance data, independent of enhancement and item kind.
export const RARITY_KEY='rpg:rarity';
export const RARITIES=Object.freeze(['일반','레어','에픽','고대','영웅','전설','신화']);
export const GRADE_MULTIPLIERS=Object.freeze([1,1.10,1.20,1.35,1.50,1.75,2]);
export const ARMOR_GRADE_HP=Object.freeze([0,2,4,7,11,16,22]);
export const PROMOTION_RATES=Object.freeze([90,85,80,75,70,60]);
export const gradeRank=n=>Number.isInteger(n)?Math.max(0,Math.min(6,n)):0;
export function itemGrade(item){try{return gradeRank(item?.getDynamicProperty?.(RARITY_KEY));}catch{return 0;}}
