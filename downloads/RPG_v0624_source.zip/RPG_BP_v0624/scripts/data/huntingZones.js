export const HUNT_ZONE_SETTINGS={metric:'square',beyond:'late'};
export const HUNT_ZONE_TYPES=[
  {
    "id": "early",
    "name": "초반",
    "max": 1500,
    "pool": [
      {
        "id": "rpg:red_mushroom",
        "weight": 30
      },
      {
        "id": "rpg:blue_mushroom",
        "weight": 20
      },
      {
        "id": "rpg:green_goblin",
        "weight": 28
      }
    ]
  },
  {
    "id": "mid",
    "name": "중반",
    "max": 4000,
    "pool": [
      {
        "id": "rpg:red_goblin",
        "weight": 16
      },
      {
        "id": "rpg:gold_goblin",
        "weight": 7
      },
      {
        "id": "rpg:goblin_captain",
        "weight": 2
      }
    ]
  },
  {
    "id": "late",
    "name": "후반",
    "max": 10000,
    "pool": [
      {
        "id": "rpg:elite_red_mushroom",
        "weight": 2
      },
      {
        "id": "rpg:elite_blue_mushroom",
        "weight": 1
      },
      {
        "id": "rpg:elite_green_goblin",
        "weight": 7
      },
      {
        "id": "rpg:elite_red_goblin",
        "weight": 11
      },
      {
        "id": "rpg:elite_gold_goblin",
        "weight": 1
      },
      {
        "id": "rpg:elite_goblin_captain",
        "weight": 1
      }
    ]
  }
];
export const ZONED_MOBS=new Set(HUNT_ZONE_TYPES.flatMap(z=>z.pool.map(m=>m.id)));
export function huntingDistance(position,metric=HUNT_ZONE_SETTINGS.metric){return metric==='circle'?Math.hypot(position.x,position.z):Math.max(Math.abs(position.x),Math.abs(position.z));}
export function huntingZone(position,settings=HUNT_ZONE_SETTINGS){
 const distance=huntingDistance(position,settings.metric);if(!Number.isFinite(distance))return undefined;
 return HUNT_ZONE_TYPES.find(z=>distance<=z.max)??(settings.beyond==='late'?HUNT_ZONE_TYPES[2]:undefined);
}
export function huntingNight(time){const t=((time%24000)+24000)%24000;return t>=12000;}
export function chooseZoneMob(zone,random=Math.random){
 if(!zone)return undefined;const value=random();if(!Number.isFinite(value)||value<0||value>=1)throw Error('사냥 구역 난수 오류');
 let n=value*zone.pool.reduce((sum,m)=>sum+m.weight,0);for(const m of zone.pool){n-=m.weight;if(n<0)return m.id;}return zone.pool.at(-1).id;
}
