// Scale cast-local direct power values only. Never mutate the shared skill table
// or change projectile count, timing, crowd control, mana, or cooldowns.
export const POWER_FIELDS=new Set(['damage','damagePerHit','damagePerSecond','damagePerPulse','damagePerShot','damagePerSlash','extraDamage','smallDamage','damageByJob','bonusDamage','entryDamage','pulseDamage','splashDamage','burstDamage','zoneDamage','impactDamage','beamDamage','meleeDamage','rangedDamage','bleedDamage','failDamage','enemyDamage','heal','healByJob','healCap']);
export function hasDirectSkillPower(def){return Object.entries(def??{}).some(([key,value])=>POWER_FIELDS.has(key)&&(typeof value==='number'?value>0:value&&typeof value==='object'&&Object.values(value).some(n=>typeof n==='number'&&n>0)));}
export function scaleSkillPower(def,multiplier){
 if(multiplier===1)return def;
 const next={...def};
 for(const [key,value]of Object.entries(def))if(POWER_FIELDS.has(key)){
  if(typeof value==='number')next[key]=value*multiplier;
  else if(value&&typeof value==='object')next[key]=Object.fromEntries(Object.entries(value).map(([id,n])=>[id,typeof n==='number'?n*multiplier:n]));
 }
 return next;
}
