export const COMMON_WEAPONS = [
  {
    "id": "rpg:common_redmoon_blade",
    "key": "redmoon_blade",
    "name": "적월선",
    "damage": 11,
    "durability": 1600
  },
  {
    "id": "rpg:common_battle_sword",
    "key": "magitech_sword",
    "name": "마공학 검",
    "damage": 9,
    "durability": 1400
  },
  {
    "id": "rpg:common_magitech_greatsword",
    "key": "magitech_greatsword",
    "name": "마공학 대검",
    "damage": 12,
    "durability": 1800
  },
  {
    "id": "rpg:common_battle_spear",
    "key": "elite_knight_greatsword",
    "name": "정예기사의 대검",
    "damage": 12,
    "durability": 2000
  },
  {
    "id": "rpg:common_frost_greatsword",
    "key": "frost_greatsword",
    "name": "빙설의 대검",
    "damage": 13,
    "durability": 2000
  },
  {
    "id": "rpg:common_flame_greatsword",
    "key": "flame_greatsword",
    "name": "화염의 대검",
    "damage": 13,
    "durability": 2000
  },
  {
    "id": "rpg:common_beast_axe",
    "key": "beast_axe",
    "name": "마수의 도끼",
    "damage": 14,
    "durability": 2200
  }
];
