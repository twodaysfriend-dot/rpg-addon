// Conservative mobile book layout: preserve short lines as well as native limits.
function wrap(line,width){
 const out=[];let current='',used=0;
 for(const token of line.match(/§.|[^]/gu)??[]){
  const n=token.startsWith('§')?0:(token.codePointAt(0)>127?2:1);
  if(used+n>width){out.push(current);current='';used=0;}
  current+=token;used+=n;
 }
 out.push(current);return out;
}
export function layoutRulebook(sections,{width=22,maxLines=14,maxChars=256,maxPages=50}={}){
 const pages=[];let lines=[];
 const flush=()=>{while(lines.at(-1)==='')lines.pop();if(lines.length)pages.push(lines.join('\n'));lines=[];};
 for(const section of sections){
  if(lines.length>maxLines-4)flush();
  for(const raw of section.split('\n'))for(const line of wrap(raw,width)){
   if(lines.length>=maxLines||[...lines,line].join('\n').length>maxChars)flush();
   if(line.length>maxChars)throw Error('룰북 문장이 너무 깁니다.');
   if(line||lines.length)lines.push(line);
  }
  if(lines.length)lines.push('');
 }
 flush();if(pages.length>maxPages)throw Error('종합 룰북이 50쪽을 초과했습니다.');return Object.freeze(pages);
}
