# RPG v0.6.88 · 강제 전직과 투신 난식

- 운영자는 `/rpg:force 진홍의 군주` 또는 `/rpg:force crimson_lord`로 진홍의 군주에 강제 전직할 수 있습니다. 직업명에 큰따옴표를 붙여도 됩니다. 게임플레이 팩이 이 명령을 직접 실행합니다.
- 투신 난식은 시선 앞에서 청백색 충격파와 폭발음이 터진 뒤 32개의 파편과 짧은 잔광이 전방 120° 부채꼴 안으로 퍼집니다. 혈액 난사처럼 파편마다 방향이 달라 위아래로도 흩어지며 첫 적이나 벽에서 멈춥니다. 발당 기본 물리 피해 22.1, 사거리 25칸, 대상당 최대 10발입니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.88로 활성화하고 월드를 다시 여세요. 모의 테스트에서 관리자 명령 등록과 진홍의 군주 전직, 난식 파편 방향·벽 차단·개별 피해를 확인했습니다. 실제 Bedrock 월드의 명령 입력과 파티클 표시는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0688
```
