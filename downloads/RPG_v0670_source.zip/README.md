# RPG v0.6.70 · 블러드엣지 기술 개편

전환 순서는 혈사병 → 핏빛 사슬 → 롱기누스의 창 → 혈액 난사 → 수혈 → 블러드 배리어 → 진홍의 역류입니다. 기존 블러드엣지도 새 기술을 받습니다.

| 기술 | 효과 |
|---|---|
| 블러드 배리어 | 정면 방어 5초. 종료 시 반경 14칸에 기본 마법 피해 32와 밀치기. |
| 혈액 난사 | 마나 30 고정, 쿨타임 없음. 전방 120도에 투사체 24발을 동시에 발사합니다. 발당 기본 마법 피해 4, 대상 하나당 시전별 최대 10발. |
| 롱기누스의 창 | 2초 동안 머리 위에서 지름 8칸까지 커진 구체를 가장 가까운 적에게 발사합니다. 폭발 반경 10칸, 기본 마법 피해 60. |
| 핏빛 사슬 | 좌클릭으로 맞힌 적을 5초 속박합니다. 쿨타임 15초, 보스는 기존 제어 저항을 적용합니다. |
| 수혈 | 10칸 안에서 최대 HP가 가장 높은 적에게 기본 마법 피해 20을 주고 실피해의 30%를 즉시 회복합니다. 기본 마나 65, 쿨타임 9초. |
| 혈사병 | 반경 16칸의 적에게 10초 동안 받는 피해 +20%. 종료 시 감염 중 받은 실제 피해의 5%를 기본값으로 삼아 시전자의 마법 피해 보정을 적용합니다. 기본 마나 125, 쿨타임 24초. |
| 진홍의 역류 (궁극기) | 10초 동안 지름 12칸의 웅덩이가 움직임을 따라갑니다. 초당 기본 마법 피해 10이며, 지속 중 다른 스킬을 사용할 수 있습니다. 종료 시 웅덩이 실피해의 50%를 회복합니다. |

Bedrock 1.21.100 이상에서 세 팩을 v0.6.70으로 활성화하세요. 공식 패키지와 모의 전투를 검증했습니다. 실제 베드락 화면과 타격 반응은 별도 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0670
```
