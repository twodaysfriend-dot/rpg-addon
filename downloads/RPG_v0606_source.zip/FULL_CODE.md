# RPG v0.6.6 변경 파일 전체 코드

## RPG_BP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon BP v0.6.6",
    "description": "RPG v0.6.6 · 더 월드! 지속 중 자유 비행 · 종료 시 자동 해제",
    "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
    "version": [
      0,
      6,
      6
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "data",
      "uuid": "cc5d6e3c-5285-4787-8a59-a8e2856f2aec",
      "version": [
        0,
        6,
        6
      ]
    },
    {
      "type": "script",
      "language": "javascript",
      "uuid": "c41fa3d6-d82c-4a54-9783-68f92fe633a1",
      "entry": "scripts/gameplayEntry.js",
      "version": [
        0,
        6,
        6
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
      "version": [
        0,
        6,
        6
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    },
    {
      "module_name": "@minecraft/server-ui",
      "version": "2.0.0"
    }
  ]
}

```

## RPG_BP_v0603/scripts/data/skillGuide.js

```js
// Descriptions checked against the active runners, not unused historical skills.
export const LINE_NAMES={the_world:'더 월드',sword:'검사·검성·타락검성',mage:'마법사·현자',archer:'궁수·천궁',holy:'천사는 아군의 실제 HP 회복을 누적해 300마다 축복의 빛 1개를 받습니다. 자가 회복·초과 회복·자연 재생·외부 재생 포션은 제외하고 성직 재생 기술은 집계합니다. 길들인 아군 동물도 지원합니다. 성직자·천사·미카엘·타락천사',fist:'무투가·권골',berserker:'망나니·야수',assassin:'암살자·그림자 암살자',harpoon:'작살꾼·복수귀',blood:'혈술사',hacker:'해커',dragon:'용기사',frost:'냉기 능력자',fire:'화염술사',tech:'마법공학사',demon:'악마',celestial_sun:'해의 후예',celestial_moon:'달의 후예',chameleon:'카멜레온',war_god:'투신',nen:'넨 능력자'};
export const LINE_NOTES={the_world:'해금 조건 미정인 근접 격투 히든 직업. 관리자 /rpg:force the_world로 시험합니다. 황금 화살은 전용 건틀릿 매개이며 손에서는 숨겨집니다. 시간 정지 중 피해는 종료 시 적용합니다. 사망·접속 종료·차원 이동 취소 시 누적 피해는 취소됩니다.',
 nen:'오라 = 마나(HUD 표시만 오라). 지능은 소모 감소 최대 50%(일반 직업은 40%), 샘의 룬 회복은 1.5배. 무투가·성직자·마법사 계열에서 레벨 40·4단계 이상 던전 솔로 클리어로 전직합니다. 근접 후속 효과(경·주·은·원)는 일반 근접 공격에만 붙고 스킬 피해에는 붙지 않습니다.',
 war_god:'무투가와 별개인 독립 근력 기반 히든 직업. 무투가(권골 제외)에서 레벨 40·5단계 이상 던전 솔로 클리어 조건. 검붉은 건틀릿을 사용합니다. 천멸격은 다음에 사용하는 공격 스킬 한 번의 피해를 3배로 만듭니다. 대상이 없어 빗나가면 소모하지 않습니다.',
 sword:'검성·타락검성은 휘두르기 기본 참격을 사용합니다. 검성의 섬멸은 타락 전직 시 사라지고 광분화로 교체됩니다. 타락검성은 검성의 무조건 상위호환이 아닙니다.',
 mage:'고마나 계열: 기본 MP 200＋바친 인챈트 책 1권당 MP 20. 현자로 전직하면 견습 파이어볼·라이트닝은 사용 목록에서 빠집니다. 다단 피해는 전탄 명중 상한과 실제 피격 무적을 구분해야 합니다.',
 archer:'기본 화살은 엔진 투사체 피해입니다. 천궁은 차징 없이 발사하며 실물 화살이 없으면 발당 고정 MP 20으로 회수 불가 마나 화살(기본 피해 6)을 발사합니다. 연사 5발은 MP 100＋연사 스킬 비용. 마나 화살에는 지능 할인이 없으며 천궁 고유 패시브라 카멜레온이 기술을 배워도 얻지 않습니다.',
 holy:'천사 계열 날개와 미카엘 불사는 직업 고유 기능입니다. 불사는 생존 HP가 6 이하일 때 최대 HP 회복·저항 V 4초·재생 III/화염 저항 5초, 재사용 60초이며 이미 사망한 캐릭터를 부활시키지는 않습니다. 광역 회복·보호·힘 버프는 자신과 파티·길드·팀 아군에게만 적용됩니다.',
 fist:'강펀치는 평타와 일부 물리 격투 기술을 강화합니다. 풍압은 마력 판정이며 힘 버프 피해 증가도 받지만 강펀치 횟수는 소비하지 않습니다. 낙하 피해 방지 등 일부 방어 이벤트는 실행 중인 Bedrock API의 지원 여부에 영향을 받습니다.',
 berserker:'망나니·야수는 처치 시 신속 III·재생 III를 5초 얻습니다. 카멜레온도 배운 참수·3연베기·야수 화염방사·대폭발을 전용 무기로 사용합니다. 광분화 학습 카멜레온의 처치 버프는 기존 동작대로 유지합니다.',
 assassin:'그림자 은신의 3배 기습과 표식의 1.3배가 함께 작동하면 조건을 만족하는 한 번의 피해가 3.9배입니다. 현재 entityAttack 원인의 스킬도 기습으로 판정될 수 있습니다. 카멜레온은 배운 그림자 은신의 유지·기습을 사용할 수 있습니다.',
 harpoon:'복수귀 순서: 딥 피어스 → 찢어내기 → 작살 → 돌진 → 영혼작살 → 잠수 → 영혼분리 → 처형. 공격 기술을 앞에, 버프·유틸을 뒤에 두고 처형을 마지막에 배치합니다. 새 두 공격은 짧은 쿨타임·일반 3 SP 학습·사용 횟수 제한 없음. 처형은 반경 4칸 기준입니다.',
 blood:'혁린약동·재는 사용 시 재생 II 1분을 부여합니다. 적박만 자체 흡혈하며 시전당 최대 6하트를 회복합니다.',
 hacker:'전직은 로토와 23회 대화 후 퀴즈를 맞힌 월드 최초 1명에게만 허용됩니다. 이후 정답자는 인챈트된 황금사과 1개를 받습니다. 레벨·엘리트 처치 조건은 없습니다. 재부팅과 계약 관련 밸런스는 이번 요청에서 유지했습니다. 재부팅은 현재 제외 목록에 없는 일부 궁극기와 재부팅 자체도 초기화합니다. 카멜레온의 학습 사용 횟수는 초기화하지 않습니다. EMP는 기술 봉인·마나 삭제가 아닙니다.',
 dragon:'용기사는 근접 3타마다 추가 피해 10＋HP 6 회복을 얻습니다. 카멜레온도 배운 삼조격·질주·브레스를 사용하지만 용기사의 근접 3타 패시브는 얻지 않습니다. 일부 방어 효과는 before-hurt API가 필요합니다.',
 frost:'동결은 둔화·무력화와 위치 복귀로 대상을 묶습니다. 절대영도의 단순 둔화와 다르며, 현재 CC 점감·보스별 동결 내성은 따로 없습니다.',
 fire:'화염술사는 상시 화염 저항 I. 화상 추가 피해는 화염 면역 적에게 약하지만 직접 기술 피해까지 전부 화염 피해인 것은 아닙니다. 화갑 반격은 카멜레온 학습자도 유지합니다.',
 tech:'마공학 감옥이 표식을 공급하고 구체·폭탄이 표식 대상을 추적합니다. 폭풍은 표식 없이도 지정 위치에 생성됩니다. 보조 기계팔은 마법공학사 전용 장착물입니다.',
 demon:'악마는 적 처치 시 HP 6 즉시 회복＋재생 II 5초를 얻습니다. 이 영혼 수확 패시브는 카멜레온에게 자동 승계되지 않습니다. 자가 계약과 적 대상 계약의 효과가 다릅니다.',
 celestial_sun:'해의 후예 전직은 천체 신전의 해 제단 4칸 안에서 낮에만 가능합니다(레벨 20·낮 적 60). /rpg:temple로 위치를 확인하세요. 빛 최대 저장량 500. 오버월드 낮·하늘이 열린 장소에서는 해당 빛 비용을 면제하고, 그 외에는 저장 빛을 소비합니다. MP는 별도로 듭니다. 충전도 해당 환경에서만 가능합니다. 축복의 상태이상 면역은 위치 고정/강제 이동까지 모두 해제하는 완전 CC 면역이 아닙니다.',
 celestial_moon:'달의 후예의 공격 기술은 근력·물리 피해 보정을 받습니다. 달의 후예 전직은 천체 신전의 달 제단 4칸 안에서 밤에만 가능합니다(레벨 20·밤 적 60). /rpg:temple로 위치를 확인하세요. 달빛 최대 저장량 500. 오버월드 밤·하늘이 열린 장소에서는 일반 기술 빛 비용을 면제합니다. MP는 별도입니다. 카멜레온이 차크람 분열을 배우면 버프 중 해당 기술을 재사용하여 전용 무기로 투척합니다.',
 chameleon:'기본 기술 2개는 무료. 선택 학습은 일반 3 SP·중요 9 SP·궁극기/카피 15 SP. 중요 기술 10회, 궁극기/카피 3회이며 다이아 1개로 각각 +5/+1회 충전합니다. 실제 5레벨 상승마다 궁극기 제외 랜덤 책 1권. 스킬 분해 시 일반 3·중요 9·궁극기/카피 15 SP를 환급하며 스킬북 기술도 대상입니다. 재학습해도 남은 사용 횟수·쿨타임은 이어집니다. 다른 직업 고유 패시브는 자동 승계되지 않습니다.',
};
export const SKILL_NOTES={
 world_blood:'흡혈(첫 번째 스킬, 사용 버튼 또는 근접 타격으로 발동): 전방 5칸 가장 가까운 적을 물어 기본 12 피해를 주고 HP 8을 회복합니다. 사용 시 재생 II 10초·저항 II 30초(대상이 없어도 적용). 기존 더 월드 캐릭터도 자동 습득합니다. 보스·데스웜(샌드웜)·대장 고블린(대왕 고블린)을 흡혈하면 60초 안에 쓰는 다음 더 월드!가 6초 대신 9초로 늘어납니다. 보스 정지는 절반. MP 60·쿨 30초.',
 world_muda:'전방 4칸 부채꼴, 0.25초 간격 8회. 기본 물리 피해 6씩 최대 48. High한 기분 중 시전하면 16회 타격. 투신 근접 연타와 같은 공격 판정·근력·장비 보정을 사용합니다.',
 world_finish:'전방 4칸 기본 물리 피해 10(High한 기분 중 시전하면 20)과 강한 밀치기·1초 둔화. 기존 쿨 9초의 1/8을 틱 단위로 올림해 1.15초.',
 world_roller:'벽을 확인하며 전방 최대 3칸 이동한 뒤 기본 물리 피해 35. 블록을 파괴하지 않습니다.',
 world_high:'8초간 신속 II·힘 II. 무다×8은 16회, 단발 무다 강타 기본 피해는 10에서 20으로 증가합니다. 힘 보정은 별도 적용되며 더 강한 기존 힘 효과는 낮추지 않습니다. 전용 화살 평타의 최소 간격이 0.5초에서 0.25초로 줄어듭니다. 스킬 강화는 시전 시점 기준이며 쿨타임·연타 간격은 유지합니다.',
 world_stop:'더 월드!: 시전 순간 플레이어 중심 반경 20칸의 적·투사체 최대 60개를 6초 정지. 보스 3초. 정지된 적은 공격·아이템 사용·예약 스크립트 공격이 차단됩니다. 이동·시점 입력 차단과 위치 고정. 시전자 전용 공격의 피해는 정지 해제 순간에 적용합니다. 쿨 20초, 기본 MP 320·지능 보정 후에도 최소 300. 사망·접속 종료·차원 이동 시 즉시 해제하며 이때 누적 피해는 취소됩니다. 아군은 제외합니다. 정지 중 시전자는 자유 비행합니다. 이동키로 수평 이동, 점프로 상승, 웅크리기로 하강하며 입력을 놓으면 공중에 머뭅니다. 종료 시 비행이 해제됩니다. 정지 중 시전자는 모든 적의 공격을 받지 않습니다(저항 V). 종료 후 기존 저항 효과는 복원됩니다.',

 nen_ten:'20초간 저항 II(받는 피해 약 40% 감소). 재사용 대기시간 30초.',
 nen_in:'8초간 투명화. 첫 근접 공격은 피해 1.5배이고, 공격하거나 피격되면 은신이 풀립니다.',
 nen_ko:'10초 안의 다음 근접 공격에 추가 물리 피해 60. 근접 공격 한 번에 소모하며 방어력을 무시합니다.',
 nen_shu:'8초간 근접 공격마다 추가 물리 피해 10과 밀치기.',
 nen_hatsu:'30칸까지 날아가는 오라 구체. 벽이나 적에 닿으면 반경 4칸 폭발, 마력 피해 55와 밀치기. 블록과 바닥은 손상되지 않습니다.',
 nen_en:'15초간 반경 25칸의 적 머리 위에 표식. 신속 II. 영역 안 각 적에게 처음 가하는 근접 공격은 피해 1.5배. 궁극기.',
 war_god_punch:'청백색 부채꼴 충격파를 내뿜으며 전방 4칸·반폭 2칸에 기본 물리 피해 40. 밀치기와 짧은 둔화. 벽 너머 적은 제외합니다.',
 war_god_flurry:'부채꼴로 원거리 충격파 8발을 동시에 발사합니다. 사거리 25칸·기본 물리 피해 34. 같은 적은 한 시전에서 1회만 피해를 받아 근거리에서도 중첩 피해가 없습니다. 벽이나 처음 맞은 적에서 각 탄이 멈춥니다. MP 120·쿨 10초.',
 war_god_kick:'아래에서 위로 솟는 청백색 발차기 궤적. 전방 6칸·반폭 2.5칸에 기본 물리 피해 48. 강한 밀치기와 1초 둔화. 블록은 파괴하지 않습니다.',
 war_god_kick_flurry:'발차기 궤적과 청백색 폭발을 교차시키며 전방 5.5칸에 0.4초 간격으로 4회, 기본 물리 피해 18씩 합계 72. 마지막 발차기에 강한 밀치기와 1초 둔화.',
 war_god_black_flash:'다음에 사용하는 투신 공격 스킬(폭멸타·난식·폭열권·파황각) 한 번의 피해를 3배로 강화합니다. 연타 스킬은 모든 타격에 3배가 적용됩니다. 난식은 같은 적에게 최대 1회이며 명중 없이 끝나면 준비를 유지합니다. 평타는 강화되지 않으며, 대상이 없어 빗나간 스킬은 소비하지 않습니다. 이미 준비 중이면 다시 시전할 수 없습니다. 준비 상태와 쿨타임은 재접속해도 유지됩니다.',
 sword_spin:'시전자 주변 반경 4.5칸을 360도로 베어 기본 피해는 검사·타락검성·카멜레온 10, 검성 20(2배)과 밀치기. 광역 적에게 각각 한 번 피해를 줍니다.',
 sword_wave:'전방 사거리 18칸의 검기 투사체. 기본 피해는 검사·타락검성·카멜레온 14, 검성 21(1.5배). 폭 2.5칸으로 경로의 적을 공격하고 밀어냅니다.',
 sword_flame_spin:'약 1.4초 동안 회전하며 전진하는 불꽃 참격. 반경 3.4칸에 0.5초 간격으로 최대 3회 베기. 타격당 기본 피해 12.6(검성 18.9), 전부 맞으면 37.8(검성 56.7)과 4초 화상. 최대 돌진 거리 7칸. 점프 입력과 연동하는 공중 연출이 있습니다.',
 sword_kenho_rando:'큰 청록 초승달과 작은 보랏빛 참격이 겹치는 사거리 5.5칸의 세로 호 참격 3회. 각 기본 피해 12, 0.6초 간격이며 전부 맞으면 합계 36입니다.',
 sword_moon_dragon:'시전 시 바라본 방향의 전방 180도·반경 12칸에 0.6초 동안 큰 청록 초승달과 작은 보랏빛 달이 퍼집니다. 기본 물리 피해 28, 적마다 사용 1회당 한 번만 타격합니다. 높이 차 3칸·벽 가림을 검사하며 달의 개수로 피해가 중복되지 않습니다.',
 sword_annihilation:'전방 최대 15칸 이동하며 이동 경로 반경 4칸을 벱니다. 대상별 기본 피해 52를 한 번 적용하고 밀어냅니다. 검성 전용, 타락검성은 보유하지 않습니다.',
 sword_rush:'반경 10칸의 최근 타격 대상을 붙잡아 기본 피해는 검성 6씩 8회(합계 48), 타락검성·카멜레온은 4씩 8회(합계 32) 시도합니다. 연타 동안 저항 V를 얻어 공격과 방어를 함께 수행합니다.',
 fallen_sword_frenzy:'20초 동안 직접 준 피해의 30%를 흡혈합니다. 날개 강제 활성화는 원래 타락검성 직업에 제한되며 카멜레온에게 날개까지 자동 지급하지 않습니다.',
 mage_fireball:'사거리 40칸의 화염 투사체. 충돌 지점 반경 3칸에 기본 피해 6을 주는 견습·마법사 기술입니다.',
 mage_lightning:'시선 앞 사거리 24칸의 대상에 기본 피해 8. 현재 단일 번개 기술이며 유도탄 4발 기술은 봄바예입니다.',
 mage_flame_on:'시전자 주변 반경 15칸에 기본 피해 10과 화상 5초. 넓은 몰이용이며 직접 피해 효율은 낮습니다.',
 mage_thunder:'사거리 20칸 대상에게 번개를 3번, 0.4초 간격으로 시도합니다. 데이터 피해 25는 3회 합계입니다. 실제 벼락 소환 성공 시 벼락 추정 피해를 빼서 직접 피해를 계산합니다.',
 mage_ice_fire:'반경 10칸에 기본 피해 12와 둔화 VI를 4초 적용하는 광역 제어기입니다.',
 mage_gravity:'반경 10칸에 기본 피해 10과 둔화 IV를 5초 적용하고 아래 방향으로 계속 누릅니다. 중심으로 끌어모으는 블랙홀이나 위치 고정형 동결과는 다릅니다.',
 mage_bombaye:'주변 25칸에서 적을 탐색해 유도탄 4발을 발사합니다. 발당 14×0.3=4.2, 전탄 명목 합계 16.8. 비행 사거리 30칸이며 빗나가도 끝에서 작은 폭발을 만듭니다.',
 sage_meteor:'최근 마법 명중 대상이 60칸 안에 있으면 추적하고, 없으면 조준 지점에 낙하합니다. 준비 2초, 폭발 반경 8칸. 중심 기본 피해 58, 가장자리까지 선형으로 최대 50% 감소합니다.',
 sage_raiyoung:'사거리 35칸의 빠른 번개 구체. 기본 피해 28.8, 적중 위치의 폭발 연출과 번개 효과를 사용합니다.',
 sage_zero:'반경 20칸 적을 5초간 강한 둔화로 묶고, 시간이 끝나면 기본 피해 38.4. 위치 복귀로 강제 고정하는 냉기 직업의 동결과는 다릅니다.',
 sage_blackhole:'반경 12칸 블랙홀을 6초 유지해 적을 끌어당깁니다. 0.5초마다 기본 피해 약 4.1667, 전부 유지하면 합계 50.',
 sage_sphere:'사거리 32칸 큰 구체가 충돌하거나 사거리 끝에 도달하면 반경 7칸에 기본 피해 50와 밀치기.',
 sage_zoltraak:'전방 마법진에서 약 1초 준비 후 사거리 50칸·전체 명중 폭 10칸(중심에서 좌우 5칸)의 광선을 발사합니다. 기본 피해 96. 데이터 이름에 궁극기가 없지만 기존 궁극기로 분류하여 랜덤 책에서 제외합니다.',
 archer_airwalk:'지속 중 공중에서 점프 입력으로 다시 도약합니다. 견습 3초·궁수 8초·천궁 15초이며 비행을 무제한 상시 제공하지 않습니다.',
 archer_rapid:'일반 화살을 한 번에 견습 2발·궁수 3발·천궁 5발 발사합니다. 천궁의 마나 화살 모드에서는 5발 모두 발당 MP 20이 필요합니다. 실제 화살 사용 시 기존 한 묶음당 실물 1개 규칙을 유지합니다.',
 archer_fire:'이번 사격을 불 화살로 준비해 명중 대상에 5초 화상. 천궁 전직 시 폭탄 화살로 교체됩니다. 기본 화살 피해와 화상은 별도입니다.',
 archer_ice:'이번 사격 명중 대상에 둔화 III 5초와 추가 피해 3을 적용합니다.',
 archer_lightning:'이번 사격 명중 대상을 1초간 둔화·약화와 위치 복귀로 기절시킵니다.',
 archer_homing:'2분간 비행 중인 화살이 주변 24칸에서 적을 찾아 궤도를 수정합니다. 화살 자체 수명은 발사 후 5초입니다.',
 archer_bomb:'이번 사격 명중 대상에게 추가 피해 14. 폭발은 시각 효과이며 주변 전체 광역 피해나 블록 파괴는 없습니다.',
 archer_pierce:'사거리 38칸의 관통 궤적을 발사해 경로의 적에게 기본 피해 18. 실제 화살 아이템 대신 별도 광선 판정을 사용하는 기술입니다.',
 archer_judgement:'최근 피해를 준 살아 있는 적을 추적하는 전용 화살. 기본 피해 65를 한 번 주고 벽에 막히면 사라집니다. 표기 추적 사거리 96칸이며 최근 대상이 없으면 발동을 취소합니다.',
 archer_heavenly:'사거리 52칸의 관통 광선에 기본 피해 42. 첫 적중 위치에서 한 번만 반경 5칸 폭발을 만들고, 그 첫 대상 이외의 주변 적에게 추가 피해 18을 줍니다.',
 fist_strong:'30초 안의 다음 3회 공격을 2배로 강화합니다. 일부 물리 격투 기술도 횟수를 소비합니다. 풍압은 마법 기술로 변경되어 제외됩니다.',
 fist_flurry:'목표에게 접근하여 0.1초 간격으로 10회 공격합니다. 기본 피해 20은 10회 총합이며, 힘 효과와 강펀치는 별도로 반영합니다.',
 fist_smash:'1초 준비 후 전방 적에게 돌진해 기본 피해 28과 밀치기. 최대 탐색 사거리 32칸.',
 fist_wind:'전방 사거리 12칸·약 120도 부채꼴에 기본 마법 피해 20. 수평 밀치기 6.4·수직 1.8로 이전 값의 2배. 마력·마법 룬을 적용하고 힘 효과를 적용하지만 강펀치 횟수는 소비하지 않습니다.',
 fist_face:'반경 6칸 적을 시전자 정면으로 끌어오고 1초 기절시킵니다. 직접 피해는 0이며 지형·공간 검사 때문에 벽이나 낭떠러지를 강제로 관통해 끌지는 않습니다.',
 fist_stance:'자신에게 강한 둔화를 1초 적용하고 힘 II·저항 II를 15초 얻습니다. 준비 부담을 기존 3초에서 줄였습니다.',
 fist_finale:'반경 12칸 안의 최근 타격 대상을 고정해 상승·낙하 연출 후 고정 피해 60. 실제 대상을 높은 Y좌표로 옮기지는 않습니다. 근력·물리 룬에 따라 피해가 증가하지 않습니다.',
 holy_heal:'좌클릭한 생존 대상의 체력을 직업별 수치만큼 회복합니다. 힐은 예외적으로 적에게도 사용할 수 있지만, 적 회복은 아군 치유 기여·축복의 빛으로 계산하지 않습니다.',
 holy_shield:'반경 8칸에 흡수 V와 저항을 300초 부여합니다. 저항은 성직자 I·천사 II·미카엘 III. 자신과 같은 파티·길드·팀 아군에게만 적용합니다.',
 holy_sword:'반경 8칸 플레이어에게 성직자 힘 I·천사 II·미카엘 III를 300초 부여합니다. 자신과 같은 파티·길드·팀 아군에게만 적용합니다.',
 holy_orb:'아군 플레이어 한 명에게 부착해 재생·신속·흡수를 유지하고 시전자는 허기 II를 받습니다. 성직자 재생/신속 II·흡수 VIII, 천사 III/IX, 미카엘 IV/X. 거리 30칸·차원·생존·아군 조건을 벗어나면 해제됩니다. 카멜레온 학습자도 성직자 단계로 유지합니다.',
 holy_pray:'게임 시간 하루 한 번, 10초 실명·강한 둔화 후 축복의 빛을 성직자 1·천사 2·미카엘 3개 지급합니다. 전투 회복기가 아닌 제작 재료 획득기입니다.',
 angel_bless:'반경 12칸 플레이어 HP 20 회복, 재생 III·저항 II·신속 II 300초와 시듦·독·약화 제거. 자신과 같은 파티·길드·팀 아군만 지원합니다.',
 angel_zone:'반경 8칸에 15초 영역. 아군에게 1초마다 HP 2 회복, 최소 재생 V·저항 I 유지. 적에게 둔화 II. 쿨타임 150초. 적에게 지원 버프를 주지 않습니다.',
 fallen_sacrifice:'적을 좌클릭해 기본 피해 16을 줍니다. 추가 회복이나 흡혈 효과는 없습니다.',
 fallen_sword:'사거리 18칸 관통 검기로 기본 마법 피해 38, 시듦 II 5초와 밀치기.',
 fallen_shield:'5초 동안 저항 III. 받은 피해의 100%를 공격자에게 반사하고 시듦 I 3초.',
 fallen_curse:'시선 앞 사거리 30칸 적에게 기본 피해 10, 시듦 III·약화 II·둔화 II를 10초 적용합니다.',
 fallen_orb:'좌클릭으로 적에게 부착하거나 우클릭으로 구슬을 발사합니다. 기본 마법 피해 16, 최초 부착 시 시듦 III 10초. 부착 중 받는 피해 +35%. 시전자와 30칸 이상 떨어지거나 사망·차원 변경 시 해제. 시전자당 대상 하나, 중첩 불가.',
 fallen_zone:'시전 지점 반경 9칸에 15초 저주 영역. 1초마다 기본 피해 3과 시듦 I·둔화 II. 이론상 지속 피해 45이며 영역 체류와 피격 무적의 영향을 받습니다.',
 fallen_end:'4초 준비 중 시전자 저항 V, 주변 반경 25칸 적에게 둔화 I를 반복 적용합니다. 범위는 시전자를 따라 이동하고 마지막에 기본 피해 60·시듦 III 5초·밀치기. MP 800으로 조정했습니다.',
 berserker_charge:'전방 17칸에서 대상을 찾아 돌진·기본 피해 14. 벽 가까운 적에게 2초 기절과 추가 피해 배율 표식을 적용합니다.',
 berserker_slam:'반경 5칸에 기본 물리 폭발 피해 18을 먼저 주고 생존한 적을 위로 최대 10칸 띄웁니다. 천장을 통과하지 않으며 보스 띄우기는 절반.',
 berserker_execute:'다음 기본 근접 공격 ×4. 적의 타격 직전 체력이 최대 체력의 15% 미만이면 처형합니다. 정확히 15%는 즉사 조건이 아닙니다. 망나니·야수의 원래 무기와 학습한 카멜레온 무기로 사용.',
 beast_berserk:'20초 동안 허기 III·힘 IV·저항 II·신속 II. 야수는 추가 피해 흡수 IV와 흡혈 15%를 받습니다. 흡수의 룬과 흡혈 비율은 높은 값 하나를 사용합니다. 카멜레온은 기존 공통 버프를 받습니다.',
 berserker_triple_slash:'짧게 전진하며 기본 피해 12씩 3회, 0.5초 간격 참격. 명목 합계 36. 카멜레온 학습자도 3회의 후속 참격을 사용합니다.',
 beast_flame_burst:'전방으로 화염 구체 3발을 순차 발사. 발당 기본 물리 피해 15, 최대 합계 45와 3초 화상.',
 beast_grand_explosion:'약 1초 후 반경 15칸 폭발로 기본 피해 70. 블록을 파괴하는 실제 폭발이 아닌 스킬 피해·파티클입니다. 카멜레온 학습자도 발동합니다.',
 assassin_spin:'약 3칸 이동하며 반경 3칸에 기본 피해 24의 회전 참격. 벽 안으로 이동하지 않습니다.',
 assassin_dagger_wave:'사거리 22칸 단검 투사체. 기본 피해 25와 2초 둔화.',
 assassin_pierce:'전방 4.5칸 적에게 기본 피해 15와 10초 회복 봉쇄. 5틱마다 HP를 기록 상한 이하로 되돌리며 이후 피해를 받으면 상한도 내려갑니다.',
 assassin_stealth:'전방 12칸의 적 그림자로 이동하고 은신을 유지합니다. 다음 entityAttack 원인 피해를 3배로 증폭한 뒤 은신을 해제합니다. 적이 없으면 발동하지 않습니다.',
 assassin_mark:'전방 24칸 적에게 10초 동안 받는 피해 30% 증가 표식. 현재 추가 피해는 실제 받은 피해를 기준으로 HP를 직접 줄여 적용합니다.',
 shadow_assassinate:'25칸 안의 표식 대상이 필요합니다. 3초 동안 적을 따라가며 보호·은신 연출 후 기본 피해 38을 주고 안전한 주변 위치로 빠집니다.',
 revenant_deep_pierce:'전방 5.5칸·반폭 0.9칸을 찔러 기본 물리 피해 18. 벽에 가리지 않은 경로의 적을 관통하며 별도 대상 지정이 필요 없습니다. MP 18·쿨 2.5초.',
 revenant_rend:'전방 4.5칸·반폭 2.4칸을 베어 기본 물리 피해 16. 적중한 적에게 1초마다 3씩 세 번 추가해 명목 합계 25. 같은 시전자의 출혈은 중첩하지 않고 갱신합니다. MP 24·쿨 4초.',
 harpoon_throw:'사거리 30칸 작살 투사체에 기본 피해 12. 끌어오기 효과는 복수귀의 영혼작살에 있습니다.',
 harpoon_dive:'작살꾼은 5초 투명화·신속 III, 복수귀는 10초 투명화·신속 IV·재생 II를 얻습니다.',
 harpoon_charge:'전방 길이 5칸·폭 2.5칸의 직사각형 범위를 공격하며 5칸 이동합니다. 범위 안 적에게 기본 피해 28. 현재 지면·벽 검사가 부족해 이동 시 주의해야 합니다.',
 soul_harpoon:'사거리 34칸에 기본 마법 피해 32의 영혼 작살. 적중 대상을 시전자 쪽으로 끌어옵니다.',
 soul_separation:'바닥 조건 없이 전방 7칸으로 이동한 뒤 1초 후 귀환 경로를 따라 반경 3칸에 걸린 적을 3초 고정·기절시킵니다. 직접 피해보다 접근·광역 제어용입니다. 경로와 도착 위치의 벽은 통과하지 않습니다.',
 revenant_execution:'시전자 반경 4칸 안에서 HP 25% 이하 적들을 처형합니다. 성공하면 재생 III 5초·쿨 5초. 대상이 없으면 같은 반경의 최근 타격/조준 적에게 기본 피해 50, 쿨 60초. 직접 kill 처치의 보상 귀속은 실제 엔진 확인이 필요합니다.',
 blood_spear:'5회 공격 가능한 피의 창. 손에 들고 사용하면 6칸 찌르기. 기본 마법 피해 14·시듦 I 3초.',
 blood_tentacle:'3초간 시전자 주변 반경 20칸을 피의 채찍 네 갈래로 휘두릅니다. 적마다 한 시전에 기본 마법 피해 28을 1회 적용합니다. 벽 너머·아군 제외. MP 100·쿨 5초.',
 blood_orb:'쿨타임 5초. 사거리 30칸 구체. 직접 피해 18, 반경 2.5칸 파편 피해 8.',
 blood_supernova:'정면 최대 3칸 앞에 혈액 구체를 소환하고 0.75초 뒤 폭발시킵니다. 반경 5칸 기본 마법 피해 30, 쿨타임 15초.',
 blood_mark:'4칸 이내 근거리 기본 물리 피해 17, 원거리 사거리 27칸 기본 피해 15.',
 blood_awaken:'사용 시 재생 II 1분. 활성화 중 힘 III·저항 III·허기 III 유지. 1분 후 시듦 V. 다시 사용하면 해제합니다.',
 blood_bind:'반경 16칸 기본 마법 피해 10과 5초 속박. 실제로 준 피해만큼 시전당 최대 6하트 회복. 보스 속박은 기존 제어 저항을 따릅니다.',
 hacker_hack:'우클릭은 32칸 안 최근 타격 적에게 약화 IV·둔화 III·실명 3초. 아군을 8칸 안에서 좌클릭하면 재생 III·저항 III·포화를 20초 지원합니다. 자가 지원 해킹은 불가합니다.',
 hacker_dummy_data:'사거리 20칸 적을 자동 탐색하는 유도 패킷. 기본 마법 피해 26, 추적 수명 2.5초.',
 hacker_reboot:'반경 30칸의 자신·길드·파티·팀 아군 일반 기술 쿨타임을 초기화합니다. 기존 제외 목록에 없는 일부 궁극기와 재부팅 자체도 초기화합니다. 카멜레온 사용 횟수는 복구하지 않습니다.',
 hacker_stealth:'투명화·신속·허기 효과를 유지하는 토글 은신입니다. 그림자 암살자의 다음 공격 3배 기습 기능은 없습니다. 다시 사용하면 해제합니다.',
 hacker_copy:'현재 등록된 공격·제어 궁극기 중 실행 가능한 기술을 무작위로 발동합니다. 순수 버프 궁극기(다음 평타를 강화하는 천멸격 포함)는 제외합니다. 공격과 버프가 함께 있는 궁극기는 포함하며, 표식·대상·빛 등 원래 조건을 충족해야 합니다.',
 hacker_ddos:'시전자 반경 10칸 적들에게 기본 마법 피해 30. 마나를 삭제하거나 기술을 봉인하는 효과는 없습니다.',
 hacker_emp:'시전 지점 반경 30칸에 5초 영역. 적에게 약화 IV·둔화 III·실명을 갱신하고, 진입한 아군에 한 번씩 재생 III·저항 III 20초. 스킬 사용 금지 효과는 없습니다.',
 dragon_triple_strike:'10초 안의 다음 3타에 추가 피해 12씩, 세 번째에 1초 기절을 준비합니다. 카멜레온도 배운 기술의 후속 강화 3타를 사용할 수 있습니다.',
 dragon_gaze:'사거리 28칸 투사체로 기본 피해 20. 용기사 표식 후속 이벤트가 작동하면 10초 받는 피해 +30%; 해당 이벤트의 직업·API 제한을 확인해야 합니다.',
 dragon_charge:'사거리 26칸에 창을 던지고 닿은 엔티티 또는 벽 직전으로 이동합니다. 적에게 기본 물리 피해 18, 아군은 이동 목표로만 사용합니다. 음수 Y에서도 작동하며 바닥·안전 지형을 요구하지 않습니다.',
 dragon_sprint:'5초 동안 전방으로 초당 21칸 질주합니다. 서로 다른 적에게 최초 충돌 시 14×1.5^(누적 적 수−1) 기본 물리 피해. 적 수에 따른 상한은 없으며 카멜레온 학습자도 발동합니다. 음수 Y·공중에서도 작동하고 벽에서 정지합니다.',
 dragon_domain:'반경 7칸 수룡 영역을 10초 전개합니다. 진입 기본 피해 20과 주기 피해 8, 아군 저항 V. 카멜레온 학습자도 전개합니다. 외부 투사체 차단은 before-hurt API 지원 여부에 제한됩니다.',
 dragon_breath:'사거리 28칸의 용 브레스 투사체. 기본 피해 24·화상 4초. 카멜레온 학습자도 발사·후속 명중 효과를 사용합니다.',
 frost_shard:'사거리 32칸 서리 투사체. 기본 피해 14와 4초 둔화.',
 frost_grasp:'정면 7칸의 벽에 가리지 않은 적 한 명에게 기본 피해 12와 2초 동결. 시야 밖 또는 벽 뒤 적은 잡지 않습니다.',
 frost_barrage:'사거리 24칸 안의 적을 향해 얼음 유도탄 5발을 발사합니다. 날아가는 동안 이동 중인 적을 추적하고 여러 적이 있으면 분산합니다. 발당 기본 마법 피해 7·전탄 명목 합계 35와 둔화 II 2.5초. 벽에 닿거나 비행 거리가 끝나면 소멸합니다.',
 frost_step:'바닥·안전 지형 조건 없이 전방 6칸으로 이동하고 신속 III·저항 I를 5초 얻습니다.',
 frost_field:'시전 지점 반경 7칸에 5초 결계. 적에게 처음 닿을 때 기본 피해 10, 머무는 동안 둔화 III를 갱신합니다. 매번 10씩 반복 피해를 주지는 않습니다.',
 frost_great_release:'0.4초 준비 후 전방 10칸의 적에게 돌진해 기본 마법 피해 42와 3초 동결.',
 frost_absolute:'반경 12칸 적에게 기본 마법 피해 38과 5초 위치 고정형 동결. 보스 제어 시간은 절반.',
 fire_ignite:'시전자 주변 반경 7칸에 기본 피해 15와 5초 화상.',
 fire_pillar:'사거리 22칸의 조준 지점 반경 3칸에 기본 피해 22·위로 밀치기·3초 화상.',
 fire_wheel:'최대 8칸 전진하는 화염바퀴로 경로의 적에게 기본 피해 18과 4초 화상.',
 fire_armor:'10초 힘 II·저항 II. 3.2칸 안의 근접 공격자에게 3초 화상 반격. 상시 화염 저항은 실제 화염술사의 별도 패시브입니다.',
 fire_emperor:'반경 12칸에 기본 피해 36·5초 화상. 5초간 주변 영역이 매초 기본 피해 4를 시도하고, 자신은 힘 III·저항 II를 15초 얻습니다.',
 tech_ray:'사거리 26칸 관통 광선으로 대상별 기본 마법 피해 18과 10초 표식을 부착합니다. 지면에 4초 에너지 흔적을 남겨 주기적으로 기본 피해 4.',
 tech_prison:'사거리 16칸의 표식 적을 우선하고, 없으면 가장 가까운 적의 위치에 반경 4칸 감옥을 6초 설치합니다. 적이 없으면 발동하지 않습니다. 내부 적에게 둔화 IV와 10초 표식을 반복 갱신합니다.',
 tech_sphere:'36칸 안의 표식 적을 찾아 유도 구체로 기본 피해 22. 표식이 없으면 발동을 취소합니다.',
 tech_bomb:'32칸 안의 표식 대상에 폭탄을 부착합니다. 약 2초 뒤 대상에 기본 피해 30, 반경 2.6칸의 다른 적에 피해 9. 표식 없이 발동하지 않습니다.',
 tech_storm:'반경 5칸에 10초 폭풍을 생성해 0.5초마다 기본 피해 5를 시도합니다. 명목 합계 100. 36칸 안 표식 대상을 추적하고 표식이 끝나면 그 자리에 남습니다.',
 demon_fear:'사거리 26칸 공포 투사체로 기본 피해 16, 둔화 III·약화 II·실명 4초와 밀치기. 몬스터의 완전한 강제 도주와 같지는 않습니다.',
 demon_vampirism:'반경 10칸 안의 모든 적에게 빨대를 연결하는 영혼 궤적. 각각 기본 마법 피해 12, 적중 수만큼 재생 단계(최대 50)를 7초 얻습니다. 빨대는 최대 7초 표시되며 추가 지속 피해는 없습니다. 아군·사망·차원 변경·반경 이탈 시 해당 연결은 종료합니다.',
 demon_reap:'전방 사거리 4.6칸의 낫 참격으로 기본 물리 피해 36.',
 demon_contract:'우클릭 자신: HP 10을 내고 저항 III·흡수 X 120초. HP가 10 이하면 취소. 좌클릭 적: 고정 피해 14를 주지만 적도 힘 III를 5초 얻습니다. 이번 버전에서 수치·동작을 유지했습니다.',
 demon_storm:'자신의 디버프를 정화하고 반경 10칸 공포 폭풍을 10초 유지하며 초당 기본 피해 6을 시도합니다. 전부 적중할 때 명목 합계 60입니다.',
 demon_domain:'반경 7.5칸에서 시전자와 선택한 적 하나를 남겨 10초 격리합니다. 나머지 살아 있는 엔티티를 밖으로 밀고 재진입을 막으며 선택 적에 허기 V. 단순 광역 피해기가 아닙니다.',
 sun_charge:'오버월드 낮·열린 하늘에서 햇빛 35를 충전합니다. 최대 500. 자연 충전은 기존 초당 4 유지. 마나 충전과 별도입니다.',
 sun_slash:'7초 안의 다음 전용 도끼 기본 타격을 총 4배로 강화하고 둔화 III 1초. 저장 햇빛 비용 10, 적절한 환경에서는 빛 비용 면제.',
 sun_blessing:'20초 저항 II·흡수 IV, 최초 한 번 받은 공격의 100% 반사. 환경 비용 면제가 없으면 햇빛 15 소비.',
 sun_divine_blessing:'디버프 제거와 3분 부정 상태이상 면역, 처음 3초는 공격 피격 무적시간 우회. 저장 햇빛 비용 20. 위치 고정형 CC를 전부 해제하지는 않습니다.',
 sun_meteor_drive:'전방 22칸 적을 찾아 마법 광선 피해 14 후 짧게 돌진해 물리 피해 26. 명목 합계 40, 저장 햇빛 비용 15.',
 sun_radiant_beam:'1초 준비 후 바라보는 방향으로 10칸 레이저를 5초 발사합니다. 발사 중 시선을 돌리거나 위아래를 보면 광선과 타격 방향도 따라 바뀝니다. 매 틱(정상 20 TPS 기준 초당 20회) 기본 마법 피해 1·명목 합계 100, 피격 무적 시간 우회와 화상·약화 II. 저장 햇빛 비용 20.',
 sun_descent:'반경 12칸에 기본 마법 피해 20, 자신에게 힘 III·재생 II·포화·흡수 X를 15초. 저장 햇빛 비용 25.',
 moon_charge:'오버월드 밤·열린 하늘에서 달빛 35를 충전합니다. 최대 500. 자연 충전은 기존 초당 4 유지. 마나 충전과 별도입니다.',
 moon_slash:'전방 사거리 5.5칸 부채꼴에 기본 물리 피해 30. 근력·물리 장비와 힘 버프 보정. 저장 달빛 비용 10.',
 moon_moonlight:'최대 HP의 50%를 회복하고 보유 달빛의 30%를 소비합니다. 마력 배율로 늘리는 일반 힐과 별도 계산입니다. 야외 밤이 아니면 저장 달빛이 있어야 하며 최대 HP에서는 취소합니다.',
 moon_homing:'주변 10칸의 적을 유도 차크람으로 추적해 기본 물리 피해 28을 한 번 줍니다. 수명 약 2.25초. 저장 달빛 비용 12. 일반 무기 투척과 별도.',
 moon_chakram_split:'60초 동안 차크람 투척마다 소형 차크람 3개(각각 기본 물리 피해 4, 근력·물리 장비 보정)를 추가합니다. 카멜레온은 켜자마자 투척하고, 효과 중 같은 기술 재사용으로 반복 투척합니다. 투척 간격 0.75초이며 반복 투척은 추가 MP·학습 횟수를 쓰지 않습니다. 저장 달빛 비용 15.',
 moon_veil:'20초 투명화·신속 IV. 저장 달빛 비용 15. 그림자 은신의 3배 기습 효과는 없습니다.',
 moon_fullwave:'반경 11칸에 기본 물리 피해 50과 둔화 III 3초. 저장 달빛 비용 25.',
 chameleon_crimson_dash:'흑염 대검에서 5초 신속 V와 접촉 고정 피해 20. 이 기술로 처치하면 연속 재사용 기회를 얻고 최대 3연속, 마지막은 20초 쿨. 일반 쿨은 7초입니다.',
 chameleon_ground_slam:'백월의 낫에서 반경 4.6칸으로 지면 충격파. 기본 피해 18이며 시각 파동 7개를 피해 18×7로 계산하지 않습니다. MP 무료·쿨 7초.',
};

```

## RPG_BP_v0603/scripts/gameplayEntry.js

```js
// RPG gameplay module - independent from slash-command registration pack.
import * as mc from "@minecraft/server";
import { initializeGameplay } from "./main.js";
let started = false;
function safeStart() {
  if (started) return;
  started = true;
  try { initializeGameplay(); }
  catch (e) { console.error("[RPG v0.6.6 gameplay] initialization failed: " + String(e?.stack ?? e)); }
}
try { mc.system.run(safeStart); }
catch (e) { console.error("[RPG v0.6.6 gameplay] schedule failed: " + String(e)); }
try {
  mc.world.afterEvents.worldLoad.subscribe(() => {
    if (!started) mc.system.run(safeStart);
  });
} catch (e) { console.warn("[RPG v0.6.6 gameplay] worldLoad recovery unavailable: " + String(e)); }

// Hydra: guard against any existing burning visual effects after pack upgrade.
// Fire immunity is configured in entities/hydra_boss.json.
try {
  mc.system.runInterval(() => {
    for (const id of ["overworld", "nether", "the_end"]) {
      try {
        const dim = mc.world.getDimension(id);
        for (const hydra of dim.getEntities({ type: "rpg:hydra_boss" })) {
          try {
            if (hydra.getComponent("minecraft:onfire")) hydra.extinguishFire(false);
          } catch (_) { /* invalid or unloaded entity */ }
        }
      } catch (_) { /* unloaded or inaccessible dimension */ }
    }
  }, 10);
} catch (e) { console.warn("[RPG] hydra fire cleanup unavailable: " + String(e)); }

```

## RPG_BP_v0603/scripts/skills/theWorld.js

```js
import {scriptedMeleeRuneFactor} from '../core/runeMelee.js';
import {duelOf} from '../core/pvp.js';
import {world,system,InputPermissionCategory,EntityDamageCause,InputButton,ButtonState} from '@minecraft/server';
import {attack as martialAttack} from './warGod.js';
import {SKILLS} from '../data/skills.js';
import {getJobId} from '../core/playerData.js';
import {getTargets,flatDir,isSolidAt,knockback,heldItemId,hurt} from '../core/util.js';
import {areAllies} from '../core/social.js';
import {isBoss} from '../core/crowdControl.js';
import {scriptedHit,setCombatHealth,noteManualDamage} from '../core/combatContext.js';
import {registerStoppedTarget,takeStoppedDamage,isTimeFrozen} from '../core/timeStopDamage.js';
export {isTimeFrozen};
const MARK='rpg:the_world_freeze_v1',TAG='rpg_the_world_frozen',WEAK='rpg:the_world_native_guard',HIGH='rpg:the_world_high_until',BLOOD='rpg:the_world_blood_until';
const sessions=new Map(),frames=new Map(),basics=new Map();let registered=false;
const valid=e=>{try{return Boolean(e?.isValid);}catch{return false;}};
const living=e=>valid(e)&&(e.getComponent('minecraft:health')?.currentValue??0)>0;
const effectData=(e,name)=>{const f=e.getEffect(name);return f?{duration:f.duration,amplifier:f.amplifier}:null;};
function enemy(p,e){return valid(e)&&p.id!==e.id&&e.typeId!=='rpg:the_world_stand'&&!areAllies(p,e)&&!e.typeId.startsWith('rpg:hito_')&&e.typeId!=='rpg:gpt_guide'&&(e.typeId!=='minecraft:player'||!['creative','spectator'].includes(String(e.getGameMode?.()).toLowerCase()));}
export function restoreFrozenEntity(e){
 const raw=e.getDynamicProperty(MARK);if(raw===undefined){try{e.removeTag(TAG);}catch{}return true;}
 let saved;try{saved=JSON.parse(raw);}catch{console.warn('[The World] corrupt recovery marker');return false;}
 let okay=true;const elapsed=Math.max(0,Math.floor((Date.now()-saved.at)/50));
 for(const name of ['slowness','weakness'])try{e.removeEffect(name);const old=saved.effects[name];if(old&&old.duration>elapsed)e.addEffect(name,old.duration-elapsed,{amplifier:old.amplifier,showParticles:false});}catch{okay=false;}
 if(e.typeId==='minecraft:player')for(const [category,enabled]of saved.permissions??[])try{e.inputPermissions.setPermissionCategory(category,enabled);}catch{okay=false;}
 try{e.clearVelocity();const projectile=e.getComponent('minecraft:projectile');if(projectile)projectile.shoot(saved.velocity);else e.applyImpulse(saved.velocity);}catch{okay=false;}
 if(okay){e.setDynamicProperty(MARK,undefined);e.removeTag(TAG);}return okay;
}
function sharedGuild(a,b){try{return a?.typeId==='minecraft:player'&&b?.typeId==='minecraft:player'&&a.getTags().some(t=>t.startsWith('rpg_guild_')&&b.hasTag(t));}catch{return false;}}
function freeze(p,e,session){
 const base=session.duration??SKILLS.world_stop.duration;
 if(frames.has(e.id)||!enemy(p,e)||sharedGuild(p,e))return false;
 const projectile=e.getComponent('minecraft:projectile');
 if(projectile?.owner&&(projectile.owner.id===p.id||areAllies(p,projectile.owner)||sharedGuild(p,projectile.owner)))return false;
 if(!projectile&&!living(e))return false;
 if(e.getDynamicProperty(MARK)!==undefined&&!restoreFrozenEntity(e))return false;
 const saved={at:Date.now(),effects:{slowness:effectData(e,'slowness'),weakness:effectData(e,'weakness')},velocity:e.getVelocity(),permissions:[]};
 if(e.typeId==='minecraft:player')try{for(const category of [...new Set([InputPermissionCategory.Movement,InputPermissionCategory.Camera,...Object.values(InputPermissionCategory).filter(v=>typeof v==='number')])])saved.permissions.push([category,e.inputPermissions.isPermissionCategoryEnabled(category)]);}catch{saved.permissions=[];}
 e.setDynamicProperty(MARK,JSON.stringify(saved));e.addTag(TAG);e.clearVelocity();
 let mode='position';
 if(saved.permissions.length>=2)try{for(const category of [InputPermissionCategory.Movement,InputPermissionCategory.Camera])e.inputPermissions.setPermissionCategory(category,false);mode='inputPermissions';}catch{mode='position';}
 const duration=Math.ceil(base*(isBoss(e)?.5:1));
 if(!projectile){e.addEffect('slowness',duration,{amplifier:255,showParticles:false});e.addEffect('weakness',duration,{amplifier:255,showParticles:false});}
 frames.set(e.id,{entity:e,owner:p,location:{...e.location},rotation:e.getRotation(),dimension:e.dimension.id,until:system.currentTick+duration,duel:duelOf(p),mode});session.ids.add(e.id);registerStoppedTarget(e,p);return true;
}
function releaseFrame(id,applyDamage=true){
 const f=frames.get(id);frames.delete(id);const deferred=takeStoppedDamage(id);if(!f)return;
 try{if(valid(f.entity))restoreFrozenEntity(f.entity);}catch(error){console.warn('[The World restore] '+error);}
 if(!applyDamage||!deferred?.damage||!living(f.entity)||!living(f.owner)||areAllies(f.owner,f.entity)||(f.duel&&(f.duel.finished||duelOf(f.owner)!==f.duel||duelOf(f.entity)!==f.duel)))return;
 const target=f.entity,source=f.owner,amount=deferred.damage;
 scriptedHit(target,source,()=>{try{if(target.applyDamage(amount,{cause:EntityDamageCause.override,damagingEntity:source})!==false)return true;}catch{}
  const hp=target.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return false;const before=hp.currentValue;setCombatHealth(target,source,hp,Math.max(0,before-amount));noteManualDamage(source,target,Math.min(before,amount));return true;});
}
function restoreWorldGuard(id,session){
 try{const pl=world.getAllPlayers().find(x=>x.id===id);if(!pl||!valid(pl)||!session.guard)return;
  pl.removeEffect('resistance');const prev=session.guard.prev;
  if(prev){const left=prev.endTick-system.currentTick;if(left>0)pl.addEffect('resistance',left,{amplifier:prev.amplifier,showParticles:false});}
 }catch{}
}
// Stable 2.2.0 has no survival mayfly setter. Use ordinary collision-aware
// player physics; never change game mode, abilities, gravity or input permissions.
function tickWorldFlight(p,session){
 const mode=String(p.getGameMode()).toLowerCase();
 if(mode==='creative'||mode==='spectator'||isTimeFrozen(p)){session.flightControlled=false;return;}
 const input=p.inputInfo;
 const move=input.getMovementVector();
 const x=Number.isFinite(move.x)?move.x:0,y=Number.isFinite(move.y)?move.y:0;
 const length=Math.max(1,Math.hypot(x,y));
 const yaw=p.getRotation().y*Math.PI/180;
 // Movement vector: x is left-positive, y is forward-positive.
 const vx=(x*Math.cos(yaw)-y*Math.sin(yaw))/length*.42;
 const vz=(y*Math.cos(yaw)+x*Math.sin(yaw))/length*.42;
 const up=input.getButtonState(InputButton.Jump)===ButtonState.Pressed;
 // Touch sneak is a one-tick input pulse; isSneaking also covers its toggle state.
 const down=p.isSneaking||input.getButtonState(InputButton.Sneak)===ButtonState.Pressed;
 const vertical=Number(up)-Number(down);
 let vy;
 if(vertical){session.hoverY=undefined;vy=vertical*.32;}
 else {session.hoverY??=p.location.y;vy=Math.max(-.32,Math.min(.32,(session.hoverY-p.location.y)*.5));}
 p.clearVelocity();
 p.applyImpulse({x:vx,y:vy+.08,z:vz});
 session.flightControlled=true;
}
function stopWorldFlight(p,session){
 // No persistent flight state exists: reload/rejoin naturally returns to normal physics.
 if(session.flightControlled&&valid(p))try{p.clearVelocity();}catch{}
 session.flightControlled=false;
}
export function stopTheWorld(p,applyDamage=true){const session=sessions.get(p.id);if(!session)return false;sessions.delete(p.id);stopWorldFlight(p,session);restoreWorldGuard(p.id,session);for(const id of session.ids)releaseFrame(id,applyDamage);return true;}

export function startTheWorld(p){
 if(sessions.has(p.id))return false;
 let duration=SKILLS.world_stop.duration,extended=false;
 try{if(Number(p.getDynamicProperty(BLOOD)??0)>Date.now()){duration=SKILLS.world_stop.bloodDuration;extended=true;}p.setDynamicProperty(BLOOD,undefined);}catch{}
 const session={ids:new Set(),dimension:p.dimension.id,duration,until:system.currentTick+duration};sessions.set(p.id,session);
 // 시간 정지 중 시전자는 어떤 적의 공격도 받지 않음(저항 V = 피해 100% 감소). 기존 저항 효과는 종료 후 복원.
 try{const old=p.getEffect('resistance');session.guard={prev:old?{amplifier:old.amplifier,endTick:system.currentTick+old.duration}:null};p.addEffect('resistance',duration+10,{amplifier:4,showParticles:false});}catch(error){console.warn('[The World guard] '+error);}
 try{for(const e of p.dimension.getEntities({location:p.location,maxDistance:SKILLS.world_stop.radius})){if(session.ids.size>=60)break;try{freeze(p,e,session);}catch(error){try{restoreFrozenEntity(e);}catch{}console.warn('[The World freeze] '+error);}}}
 catch(error){stopTheWorld(p,false);throw error;}
 p.sendMessage(extended?'§6더 월드! §c흡혈의 힘으로 §e9초§7간 시간이 멈춥니다.':'§6더 월드! §7시간이 멈췄습니다.');return true;
}
export function tickTheWorld(){
 for(const [id,s]of sessions){const p=world.getAllPlayers().find(p=>p.id===id);if(!living(p)||p.dimension.id!==s.dimension||system.currentTick>=s.until||getJobId(p)!=='the_world'){stopTheWorld(p??{id},living(p)&&p.dimension.id===s.dimension&&getJobId(p)==='the_world');continue;}
  try{tickWorldFlight(p,s);}catch(error){stopTheWorld(p,false);console.warn('[The World flight] '+error);}
 }
 for(const [id,f]of frames){
  if(!valid(f.entity)||!living(f.owner)||f.entity.dimension.id!==f.dimension||system.currentTick>=f.until||areAllies(f.owner,f.entity)){releaseFrame(id);continue;}
  try{f.entity.teleport(f.location,{dimension:f.entity.dimension,rotation:f.rotation,keepVelocity:false});f.entity.clearVelocity();}catch{releaseFrame(id);}
 }
}
export function recoverStoppedEntities(){
 for(const name of ['overworld','nether','the_end'])try{for(const e of world.getDimension(name).getEntities({tags:[TAG]}))if(!frames.has(e.id))try{restoreFrozenEntity(e);}catch(error){console.warn('[The World recovery] '+error);}}catch{}
 for(const p of world.getAllPlayers())if(!frames.has(p.id)&&p.getDynamicProperty(MARK)!==undefined)try{restoreFrozenEntity(p);}catch{}
}
function saveNativeGuard(p){if(p.getDynamicProperty(WEAK)===undefined)p.setDynamicProperty(WEAK,JSON.stringify({at:Date.now(),effect:effectData(p,'weakness')}));p.addEffect('weakness',40,{amplifier:255,showParticles:false});}
function restoreNativeGuard(p){const raw=p.getDynamicProperty(WEAK);if(raw===undefined)return;const saved=JSON.parse(raw);p.removeEffect('weakness');const ticks=(Date.now()-saved.at)/50;if(saved.effect?.duration>ticks)p.addEffect('weakness',Math.ceil(saved.effect.duration-ticks),{amplifier:saved.effect.amplifier,showParticles:false});p.setDynamicProperty(WEAK,undefined);}
export function tickWorldGuards(){for(const p of world.getAllPlayers())try{if(isTimeFrozen(p))continue;if(getJobId(p)==='the_world'&&(heldItemId(p)==='rpg:the_world_arrow'||sessions.has(p.id))&&!isTimeFrozen(p))saveNativeGuard(p);else restoreNativeGuard(p);}catch(error){console.warn('[The World melee guard] '+error);}}
export function isWorldHighActive(p){return Number(p.getDynamicProperty(HIGH)??0)>Date.now();}
function punch(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,hits:d.hits*2}:d);}
function finisher(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,damagePerHit:d.damagePerHit*2}:d);}
function roller(p,job,d){const dir=flatDir(p),origin=p.location;let at=origin;for(let n=.5;n<=3;n+=.5){const q={x:origin.x+dir.x*n,y:origin.y,z:origin.z+dir.z*n};if(isSolidAt(p.dimension,q)||isSolidAt(p.dimension,{...q,y:q.y+1}))break;at=q;}p.teleport(at,{dimension:p.dimension,keepVelocity:false});return martialAttack(p,job,d);}
function high(p){p.setDynamicProperty(HIGH,Date.now()+8000);p.addEffect('speed',160,{amplifier:1,showParticles:false});const strength=p.getEffect('strength');if(!strength||strength.amplifier<1||(strength.amplifier===1&&strength.duration<160))p.addEffect('strength',160,{amplifier:1,showParticles:false});return true;}
// 흡혈: 전방 근접 대상을 물어 체력을 회복하고 재생 II 10초·저항 II 30초.
// 보스·데스웜(샌드웜)·대장 고블린(대왕 고블린)을 흡혈하면 60초 안에 쓰는 다음 더 월드가 9초로 증가.
const BLOOD_BIG=new Set(['rpg:deathworm','rpg:elite_deathworm','rpg:goblin_captain','rpg:elite_goblin_captain']);
function bloodTarget(p){
 const dir=p.getViewDirection(),origin={x:p.location.x,y:p.location.y+1,z:p.location.z};let best,bestD=Infinity;
 for(const e of getTargets(p,origin,5.5,0)){
  if(!enemy(p,e)||!living(e))continue;
  const dx=e.location.x-origin.x,dy=e.location.y+(e.getComponent('minecraft:health')?1:0)*.8-origin.y,dz=e.location.z-origin.z,d=Math.hypot(dx,dy,dz)||.01;
  if((dx*dir.x+dy*dir.y+dz*dir.z)/d<.35)continue;
  if(d<bestD){best=e;bestD=d;}
 }
 return best;
}
function blood(p,job,def,hitTarget){
 const target=hitTarget&&enemy(p,hitTarget)&&living(hitTarget)&&p.dimension.id===hitTarget.dimension.id&&Math.hypot(p.location.x-hitTarget.location.x,p.location.y-hitTarget.location.y,p.location.z-hitTarget.location.z)<=5.5?hitTarget:bloodTarget(p);
 p.addEffect('regeneration',200,{amplifier:1,showParticles:true});
 p.addEffect('resistance',600,{amplifier:1,showParticles:true});
 if(!target){p.sendMessage('§c흡혈! §7(대상 없음 · 재생 II 10초 / 저항 II 30초)');return true;}
 hurt(target,p,12,'physical',{ignoreInvulnerability:true});
 try{const hp=p.getComponent('minecraft:health');if(hp)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+8));}catch{}
 try{p.dimension.spawnParticle('minecraft:redstone_ore_dust_particle',{x:target.location.x,y:target.location.y+1,z:target.location.z});}catch{}
 if(isBoss(target)||BLOOD_BIG.has(target.typeId)){
  p.setDynamicProperty(BLOOD,Date.now()+60000);
  p.sendMessage('§4흡혈! §7강대한 피를 마셨습니다. §e60초 안의 더 월드가 9초로 증가합니다.');
 }else p.sendMessage('§c흡혈! §7재생 II 10초 / 저항 II 30초');
 return true;
}
export const RUNNERS={world_blood:blood,world_muda:punch,world_finish:finisher,world_roller:roller,world_high:high,world_stop:startTheWorld};
export function registerTheWorld(){
 if(registered)return;registered=true;
 world.beforeEvents.itemUse.subscribe(e=>{if(isTimeFrozen(e.source)||(sessions.has(e.source.id)&&e.itemStack?.typeId!=='rpg:the_world_arrow'))e.cancel=true;});
 system.runInterval(tickTheWorld,1);system.runInterval(tickWorldGuards,1);system.runInterval(recoverStoppedEntities,100);system.run(recoverStoppedEntities);
 world.afterEvents.entitySpawn.subscribe(ev=>system.run(()=>{try{const owner=ev.entity.getComponent('minecraft:projectile')?.owner;if(owner&&isTimeFrozen(owner))ev.entity.remove();}catch{}}));
 // Stable 2.2.0 has no before-hurt cancellation. Weakness/projectile suppression
 // prevent normal attacks; refund any surviving native damage that still reports.
 world.afterEvents.entityHurt.subscribe(ev=>{
  const src=ev.damageSource,projectile=src?.damagingProjectile;
  let attacker=src?.damagingEntity;
  try{attacker=attacker??projectile?.getComponent('minecraft:projectile')?.owner;}catch{}
  try{const victim=ev.hurtEntity;if(victim?.typeId==='minecraft:player'&&sessions.has(victim.id)&&ev.damage>0&&attacker?.id!==victim.id){const h=victim.getComponent('minecraft:health');if(h&&h.currentValue>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));}}catch{}
  if(!isTimeFrozen(attacker)&&!isTimeFrozen(projectile))return;
  try{const h=ev.hurtEntity.getComponent('minecraft:health');if(h?.currentValue>0&&ev.damage>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));}catch{}
 });
 world.afterEvents.entityLoad.subscribe(ev=>{if(!frames.has(ev.entity.id))try{restoreFrozenEntity(ev.entity);}catch{}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.run(()=>{try{if(!frames.has(ev.player.id))restoreFrozenEntity(ev.player);restoreNativeGuard(ev.player);}catch{}}));
 world.afterEvents.playerDimensionChange.subscribe(ev=>stopTheWorld(ev.player,false));
 world.afterEvents.playerLeave.subscribe(ev=>{stopTheWorld({id:ev.playerId},false);basics.delete(ev.playerId);});
 world.afterEvents.entityDie.subscribe(ev=>{stopTheWorld(ev.deadEntity,false);if(frames.has(ev.deadEntity.id))releaseFrame(ev.deadEntity.id,false);});
 world.afterEvents.entityHitEntity.subscribe(ev=>{const p=ev.damagingEntity,t=ev.hitEntity;if(p?.typeId!=='minecraft:player'||getJobId(p)!=='the_world'||heldItemId(p)!=='rpg:the_world_arrow'||isTimeFrozen(p)||!enemy(p,t))return;
  const gap=isWorldHighActive(p)?5:10;if((basics.get(p.id)??-100)>system.currentTick-gap)return;basics.set(p.id,system.currentTick);hurt(t,p,8*scriptedMeleeRuneFactor(p),'physical',{ignoreInvulnerability:true});});
}

```

## RPG_Commands_BP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Commands BP v0.6.6",
    "description": "RPG v0.6.6 · 더 월드! 지속 중 자유 비행 · 종료 시 자동 해제",
    "uuid": "533cff27-4591-48cb-85fb-540c8bcbcc72",
    "version": [
      0,
      6,
      6
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "script",
      "language": "javascript",
      "uuid": "9518dff9-cc69-4ea4-adb6-2762b6291c45",
      "entry": "scripts/commands.js",
      "version": [
        0,
        6,
        6
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
      "version": [
        0,
        6,
        6
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    }
  ]
}

```

## RPG_Commands_BP_v0603/scripts/commands.js

```js
// RPG command registry, isolated in a separate behavior pack.
// Even if complex RPG combat/skill imports fail, /rpg:ping can still register.
import * as mc from "@minecraft/server";
const VERSION = "0.6.6";
const commands = [
  ['tpa','플레이어 이동 요청 · 이동 성공 시 1000골드'],
  ['tpaaccept','받은 플레이어 이동 요청 수락·거절'],
  ['pvpcreate','관리자: 1000 250 1000에 PvP장 생성',null,true],
  ['pkclear','관리자: 플레이어 PK 패널티 해제','player',true],
  ['peace','관리자: 현재 위치 반경 200 평화구역 설정·해제','mode',true],
  ['pvp','결투 신청·수락·항복·PK 상태','player'],
  ['gptnpc','관리자: GPT RPG 질문 NPC 생성',null,true],
  ['temple','천체 신전 위치·활성 제단·후예 전직'],
  ['templecreate','관리자: 앞쪽 빈 지역에 천체 신전 생성',null,true],
  ['templeremove','관리자: 신전 등록 해제·건물 보존',null,true],
  ['fuse','RPG 장비 등급 합성'],
  ['transfer','RPG 갑옷 강화 추출·이전'],
  ['ask','이 애드온의 직업·스킬·제작·던전 정보 질문','question'],
  ['dungeoncreate','관리자: 난이도 1~10 또는 all 동굴 생성·누락 복구','difficulty',true],
  ['dungeonremove','관리자: 던전 등록 해제 (건축물 보존)','name',true],
  ['dungeon','난이도 목록·파티장 입장 시 파티원 자동 등록','difficulty'],
  ['dungeonstart','대기실 인원 1~4명 출발'],
  ['dungeonsolo','해당 난이도 혼자 바로 시작','difficulty'],
  ['dungeonleave','대기 취소·사망 후 귀환 (전투 중 불가)'],
  ['dungeonloot','보관된 던전 보급품 받기'],
  ['skillguide','모든 직업·스킬 상세 도감'],
  ['runes','룬 전용 보관함·장착'],
  ['jobs','직업별 전직 조건·시련'],
  ['craft', '갑옷·룬 제작법과 획득 도감'],
  ['upgrade', '갑옷·룬·공용 무기 강화'],
  ['wallet', '골드·강화석·룬 가루 지갑'],
  ['equipment', 'RPG 갑옷·룬 보관·장착'],
  ['guide', '모험 시작·견습 5계열 자유 체험'],
  ["rulebook", "RPG 서버 종합 룰북"],
  ["ping", "명령어 등록 진단"],
  ["diag", "명령어 및 스크립트 진단"],
  ["menu", "카멜레온 스킬 메뉴"],
  ["job", "전직", "job"],
  ["help", "명령어 도움말"],
  ["status", "캐릭터 상태"],
  ["stats", "레벨·스탯 분배"],
  ["admin", "운영자 설정 도구", null, true],
  ["setlevel", "관리자: 레벨 설정", "level", true],
  ["setmana", "관리자: 최대 마나 설정", "amount", true],
  ["skills", "스킬 켜기·끄기"],
  ["skillbook", "스킬 도감"],
  ["learn", "스킬 습득", "skill"],
  ["swap", "카멜레온 무기 전환"],
  ["offer", "검과 책을 바칩니다"],
  ["bless", "미카엘 전직: 축복의 빛 192개 공물"],
  ["holywater", "성수 제작"],
  ["force", "관리자: 강제 전직", "job", true],
  ["reset", "관리자: 초기화", null, true],
  ["starter", "관리자: 견습 장비", "line", true],
  ["charge", "관리자: 마나·쿨타임 회복", null, true],
  ["items", "관리자: 전용 아이템", null, true],
  ["egg", "관리자: 몬스터 스폰알", null, true],
  ["hito", "관리자: 전직관 소환알 지급", "line", true],
  ["wings", "날개 켜기·끄기"],
  ["wingcheck", "날개 상태"],
  ["wingrefresh", "날개 새로고침"],
  ["guild", "길드 메뉴"],
  ["party", "파티 메뉴"],
  ["invites", "초대 확인"],
  ["boss", "관리자: 바위 골렘", null, true],
  ["cyclops", "관리자: 외눈 거인", null, true],
  ["hydra", "관리자: 히드라", null, true],
  ["techgolem", "관리자: 마공학 골렘", null, true],
  ["fistcheck", "주먹 강화 상태"]
];
const registered = new Set();
let startupDone = false;
let failures = [];
function isPlayer(p) { return !!p && p.typeId === "minecraft:player"; }
function tell(p, msg) { try { p.sendMessage(msg); } catch (e) { console.warn("[RPG commands] message: " + e); } }
function handle(action, p, arg="") {
  if (!isPlayer(p)) return;
  if (action === "ping") {
    tell(p, "§a[RPG v"+VERSION+"] 명령어 스크립트 실행 정상. 등록 "+registered.size+"/"+commands.length);
    return;
  }
  if (action === "diag") {
    tell(p,"§e[RPG v"+VERSION+"] 명령어 팩 실행 정상 ("+registered.size+"/"+commands.length+"). RPG 본체 확인: /rpg:status");
    if(failures.length) failures.slice(0,4).forEach(x=>tell(p,"§c"+x));
    tell(p,"§7게임플레이 오류는 설정 → 제작자 → 콘텐츠 로그에서 확인 가능. /function rpg_hydra 로 히드라 소환 검사 가능");
    return;
  }
  // The RPG gameplay BP independently handles this script event. It is run as
  // the player so event.sourceEntity is the correct player object.
  const message = String(arg??"").replace(/[\r\n]/g," ").trim();
  try {
    p.runCommand("scriptevent rpg:"+action+(message?" "+message:""));
  } catch (e) {
    tell(p,"§c[RPG] 명령어 전달 실패: "+String(e));
  }
}
mc.system.beforeEvents.startup.subscribe(ev => {
  startupDone = true;
  const registry = ev.customCommandRegistry;
  if(!registry){ console.error("[RPG commands] customCommandRegistry unavailable"); return; }
  const levels = mc.CommandPermissionLevel ?? mc.CustomCommandPermissionLevel;
  const params = mc.CustomCommandParamType;
  const statuses = mc.CustomCommandStatus;
  if(!levels || !params || !statuses){ console.error("[RPG commands] Script API command enums unavailable"); return; }
  for(const [name, description, arg, admin] of commands){
    try{
      const def={name:"rpg:"+name,description,permissionLevel: admin?levels.GameDirectors:levels.Any,cheatsRequired:false};
      if(arg){
        const t = name === "setlevel" ? params.Integer : params.String;
        if(name === "hito" || name === "dungeon" || name === "ask" || name === "pvp" || name === "peace" || name === "pkclear") def.optionalParameters=[{name:arg,type:t}];
        else def.mandatoryParameters=[{name:arg,type:t}];
      }
      registry.registerCommand(def,(origin,...args)=>{
        const p=origin.sourceEntity??origin.initiator;
        if(!isPlayer(p)) return {status:statuses.Failure,message:"플레이어 전용 명령어"};
        const raw=Array.isArray(args[0])?args[0][0]:args[0];
        mc.system.run(()=>handle(name,p,raw==null?"":String(raw)));
        return {status:statuses.Success};
      });
      registered.add(name);
    }catch(e){
      const msg="/rpg:"+name+" 등록 실패: "+String(e);
      failures.push(msg);console.error("[RPG commands] "+msg);
    }
  }
  try{registry.registerCommand({name:'pvp',description:'결투 신청',permissionLevel:levels.Any,cheatsRequired:false,optionalParameters:[{name:'player',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvp',p,arg??''));return {status:statuses.Success};});}catch{ /* Namespace-free aliases are unsupported on some Bedrock versions. */ }
  try{registry.registerCommand({name:'peace',description:'관리자: 반경 200 평화구역',permissionLevel:levels.GameDirectors,cheatsRequired:false,optionalParameters:[{name:'mode',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('peace',p,arg??''));return {status:statuses.Success};});}catch{console.warn('[RPG] /peace 별칭 미지원: /rpg:peace 사용');}
  try{registry.registerCommand({name:'pvpcreate',description:'관리자: PvP장 생성',permissionLevel:levels.GameDirectors,cheatsRequired:false},origin=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvpcreate',p,''));return {status:statuses.Success};});}catch{console.warn('[RPG] /pvpcreate 별칭 미지원: /rpg:pvpcreate 사용');}
  console.warn("[RPG v"+VERSION+"] registered "+registered.size+"/"+commands.length+" commands");
});
// Allow commands even if a particular client doesn't display slash commands.
try {
  const chat=mc.world.beforeEvents?.chatSend;
  if(chat?.subscribe) chat.subscribe(ev=>{
    const msg=String(ev.message??"").trim();
    if(!/^!(?:rpg|rulebook|hito|pvp)(?:\s|$)/i.test(msg))return;
    ev.cancel=true;
    let action="help",arg="";
    if(/^!pvp(?:\s|$)/i.test(msg)){action='pvp';arg=msg.replace(/^!pvp\s*/i,'');}
    else if(/^!rulebook$/i.test(msg))action="rulebook";
    else if(/^!hito(?:\s|$)/i.test(msg)){action="hito";arg=msg.replace(/^!hito\s*/i,"");}
    else {const parts=msg.replace(/^!rpg\s*/i,"").trim().split(/\s+/);action=(parts.shift()||"help").toLowerCase();arg=parts.join(" ");}
    const p=ev.sender;
    mc.system.run(()=>handle(action,p,arg));
  });
}catch(e){console.warn("[RPG commands] chat fallback disabled: "+e);}
// Direct /scriptevent rpg:ping and rpg:diag allow diagnosing even if custom
// command registration is unsupported on the current Bedrock version.
try {
  mc.system.afterEvents.scriptEventReceive.subscribe(ev=>{
    if(ev.id!=="rpg:ping"&&ev.id!=="rpg:diag") return;
    if(isPlayer(ev.sourceEntity))mc.system.run(()=>handle(ev.id.slice(4),ev.sourceEntity));
  });
}catch(e){console.warn("[RPG commands] event diagnostic fallback disabled: "+e);}

```

## RPG_RP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon RP v0.6.6",
    "description": "RPG v0.6.6 · 더 월드! 지속 중 자유 비행 · 종료 시 자동 해제",
    "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
    "version": [
      0,
      6,
      6
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "resources",
      "uuid": "7ede5e36-9a5f-44d1-9aa0-9dc38822fa99",
      "version": [
        0,
        6,
        6
      ]
    }
  ]
}

```

