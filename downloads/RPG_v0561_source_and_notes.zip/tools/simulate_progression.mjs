import {enhancementRates,upgradeCost,catalystAllowed,rollEnhancement} from '../RPG_BP_v0561/scripts/data/upgrades.js';
import {HUNT_REWARDS,CLEAR_REWARD,DUNGEON} from '../RPG_BP_v0561/scripts/data/dungeons.js';
import fs from 'node:fs';
let seed=533;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
const SAMPLES=10000,results=[];
for(const strategy of [0,5]){
 const times=[];
 for(let sample=0;sample<SAMPLES;sample++){
  const total={gold:0,stone:0,dust:0,catalysts:0};
  for(const [kind,count,max]of [['armor',4,10],['rune',6,10]])for(let i=0;i<count;i++){
   let level=0;while(level<max){const cats=catalystAllowed(kind,level)?strategy:0,cost=upgradeCost(kind,level);for(const k of ['gold','stone','dust'])total[k]+=cost[k];total.catalysts+=cats;
    const result=rollEnhancement(enhancementRates(kind,level,cats),random);if(result==='success')level++;if(result==='downgrade')level=Math.max(0,level-1);if(result==='destroy')level=0;
   }
  }
  // No-catalyst hunt covers money and both materials. Dungeon catalyst route
  // conservatively ignores random boss catalysts; cash/materials are abundant.
  const hours=strategy===0?Math.max(total.gold/HUNT_REWARDS.normal.gold,total.stone/HUNT_REWARDS.normal.stone,total.dust/HUNT_REWARDS.normal.dustChance)*5/3600:Math.ceil(total.catalysts/(CLEAR_REWARD.catalysts+1/CLEAR_REWARD.bonusEvery))*DUNGEON.baselineMinutes/60;
  times.push(hours);
 }
 times.sort((a,b)=>a-b);results.push({strategy,samples:SAMPLES,seed:533,meanHours:times.reduce((a,b)=>a+b,0)/SAMPLES,medianHours:times[SAMPLES/2],p90Hours:times[Math.floor(SAMPLES*.9)]});
}
fs.writeFileSync('v0561_성장시간_모의실험.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
