import test from 'node:test';
import assert from 'node:assert/strict';
import {player,events,intervals,timeouts,ItemStack} from './minecraftMock.mjs';
import {RUNNERS as SWORD} from '../RPG_BP_v0561/scripts/skills/sword.js';
import {RUNNERS as FIST,registerFist} from '../RPG_BP_v0561/scripts/skills/fist.js';
import {RUNNERS as HOLY} from '../RPG_BP_v0561/scripts/skills/holy.js';
import {RUNNERS as BERSERKER} from '../RPG_BP_v0561/scripts/skills/berserker.js';
import {RUNNERS as WAR,armBlackFlash,registerWarGod} from '../RPG_BP_v0561/scripts/skills/warGod.js';
import {registerLifesteal} from '../RPG_BP_v0561/scripts/core/lifesteal.js';
import {SKILLS} from '../RPG_BP_v0561/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0561/scripts/data/jobs.js';
import {hurt} from '../RPG_BP_v0561/scripts/core/util.js';
import {giveDoubleBuff,doubleLeft} from '../RPG_BP_v0561/scripts/core/fistState.js';
import {addRuneRecord,readRuneBag,writeRuneBag,equipRune} from '../RPG_BP_v0561/scripts/core/runeInventory.js';
let serial=0;
function scene(job='swordsman'){
 const p=player('str-caster-'+serial++,40),t=player('str-target-'+serial++,1,{typeId:'minecraft:zombie',health:5000,maxHealth:5000,location:{x:0,y:64,z:2}}),hits=[];
 p.setDynamicProperty('rpg:job',job);
 const dim={id:'minecraft:overworld',getEntities:()=>[t],getPlayers:()=>[p],getBlock:()=>({isSolid:false,isAir:true,typeId:'minecraft:air'}),spawnParticle(){},playSound(){}};
 p.dimension=t.dimension=dim;p.getTags=t.getTags=()=>[];p.hasTag=t.hasTag=()=>false;
 p.getViewDirection=()=>({x:0,y:0,z:1});p.getRotation=()=>({x:0,y:0});p.teleport=at=>{p.location={...at};};t.applyKnockback=()=>{};
 t.applyDamage=(n,options)=>{hits.push({n,options});t.health-=n;return true;};return {p,t,dim,hits};
}
const close=(actual,expected)=>assert.ok(Math.abs(actual-expected)<1e-8,`${actual} != ${expected}`);
for(const [job,bonus]of [['cleric',3],['angel',6],['michael',9]]){
 test(job+' party Strength buff increases a teammate physical skill once',()=>{
  const {p,t,dim,hits}=scene(),support=player('support-'+serial++,40);support.dimension=dim;support.setDynamicProperty('rpg:job',job);
  support.getTags=()=>['rpg_team_strength'];p.hasTag=tag=>tag==='rpg_team_strength';
  HOLY.holy_sword(support,JOBS[job],SKILLS.holy_sword);
  assert.equal(p.getEffect('strength').amplifier,bonus/3-1);
  SWORD.sword_spin(p,JOBS.swordsman,SKILLS.sword_spin);
  assert.equal(hits.length,1);assert.equal(hits[0].n,SKILLS.sword_spin.damage*(1+bonus/3*.05));
  assert.equal(t.getEffect('strength'),undefined);
 });
}
test('borrowed stance and attack use one Strength multiplier before STR, armor and rune multipliers',()=>{
 const {p,hits}=scene('chameleon');p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:15,vit:5,int:5,mag:105}));
 for(const [slot,part]of [['Head','helmet'],['Chest','chestplate'],['Legs','leggings'],['Feet','boots']])p.equipment.set(slot,new ItemStack('rpg:adventurer_'+part));
 const bag=readRuneBag(p),r=addRuneRecord(bag,'power',0);writeRuneBag(p,bag);equipRune(p,r.uid,0);
 FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);SWORD.sword_spin(p,JOBS.swordsman,SKILLS.sword_spin);
 close(hits[0].n,10*1.1*1.07*1.08*1.10);
});
test('removing or replacing Strength changes the next skill without stale or stacked bonuses',()=>{
 const {p,hits}=scene();FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);
 for(const amp of [1,null,2,0,null]){
  if(amp===null)p.removeEffect('strength');else p.addEffect('strength',100,{amplifier:amp});
  SWORD.sword_spin(p,JOBS.swordsman,SKILLS.sword_spin);
 }
 assert.deepEqual(hits.map(h=>h.n),[11,10,11.5,10.5,10]);
});
test('berserk Strength IV applies to the direct physical damage route',()=>{
 const {p,hits}=scene('beast');BERSERKER.beast_berserk(p,JOBS.beast,SKILLS.beast_berserk);
 BERSERKER.berserker_charge(p,JOBS.beast,SKILLS.berserker_charge);
 assert.equal(hits.length,1);assert.equal(hits[0].n,SKILLS.berserker_charge.damage*1.2);
});
test('multi-hit War God skills read Strength at each impact and stop receiving it when removed',()=>{
 const {p,hits}=scene('war_god');FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);
 const before=timeouts.length;WAR.war_god_flurry(p,JOBS.war_god,SKILLS.war_god_flurry);
 assert.equal(hits[0].n,11);p.removeEffect('strength');for(const tick of timeouts.slice(before))tick();
 assert.deepEqual(hits.map(h=>h.n),[11,10,10,10,10,10]);
});
test('Strength also increases wind magic while preserving fixed and zero damage',()=>{
 const {p,t,hits}=scene('fist_bone');p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:205,vit:5,int:5,mag:105}));
 FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);FIST.fist_wind(p,JOBS.fist_bone,SKILLS.fist_wind);
 close(hits[0].n,20*1.1*1.7);hurt(t,p,60,'fixed');assert.equal(hits[1].n,60);hurt(t,p,0,'physical');assert.equal(hits[2].n,0);
});
test('fist smash retains Strength before strong-punch multiplication without adding it again',()=>{
 const {p,hits}=scene('fist_bone');FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);giveDoubleBuff(p,3,600);
 const before=intervals.length;FIST.fist_smash(p,JOBS.fist_bone,SKILLS.fist_smash);const charge=intervals[before];
 for(let i=0;i<SKILLS.fist_smash.charge;i++)charge();const dash=intervals.at(-1);dash();dash();
 assert.equal(hits.length,1);assert.equal(hits[0].n,28*1.1*2);assert.equal(doubleLeft(p),2);
});
for(const fallback of [false,true])test('fist flurry includes its existing bonus exactly once'+(fallback?' through damage fallback':''),()=>{
 const {p,t,hits}=scene('fist_bone');FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);giveDoubleBuff(p,3,600);
 if(fallback){const apply=t.applyDamage;t.applyDamage=(n,o)=>{if(o.cause==='override')throw Error('unsupported');return apply(n,o);};}
 const before=intervals.length;FIST.fist_flurry(p,JOBS.fist_bone,SKILLS.fist_flurry);const tick=intervals[before];
 for(let i=0;i<SKILLS.fist_flurry.hits*SKILLS.fist_flurry.stepTicks;i++)tick();
 assert.equal(hits.length,10);for(const hit of hits)close(hit.n,20*1.1*2/10);close(hits.reduce((s,h)=>s+h.n,0),44);
});
test('native melee damage already containing Strength is doubled without adding Strength again',()=>{
 registerFist();const {p,t,hits}=scene('fist_bone');FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);giveDoubleBuff(p,3,600);
 const nativeDamage=18;t.health-=nativeDamage;
 for(const fn of events.entityHurt.listeners)fn({hurtEntity:t,damage:nativeDamage,damageSource:{cause:'entityAttack',damagingEntity:p}});
 assert.equal(hits.length,1);assert.equal(hits[0].n,18);assert.equal(t.health,5000-36);
});
test('tenfold next-basic ultimate does not add Strength a second time',()=>{
 registerLifesteal();registerWarGod();const {p,t}=scene('war_god');FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);armBlackFlash(p);
 t.health-=18;for(const fn of events.entityHurt.listeners)fn({hurtEntity:t,damage:18,damageSource:{cause:'entityAttack',damagingEntity:p}});
 assert.equal(t.health,5000-180);
});

test('magic Strength bonus is multiplied by MAG and magic gear once, without consuming strong punch',()=>{
 const {p,t,hits}=scene('chameleon');p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:205,vit:5,int:5,mag:105}));
 for(const [slot,part]of [['Head','helmet'],['Chest','chestplate'],['Legs','leggings'],['Feet','boots']])p.equipment.set(slot,new ItemStack('rpg:astral_'+part));
 const bag=readRuneBag(p),r=addRuneRecord(bag,'arcane',0);writeRuneBag(p,bag);equipRune(p,r.uid,0);
 FIST.fist_stance(p,JOBS.fist_bone,SKILLS.fist_stance);giveDoubleBuff(p,3,600);hurt(t,p,20,'magic');
 close(hits[0].n,22*1.7*1.08*1.10);assert.equal(doubleLeft(p),3);p.removeEffect('strength');hurt(t,p,20,'magic');close(hits[1].n,20*1.7*1.08*1.10);
 hurt(t,p,60,'fixed');assert.equal(hits[2].n,60);hurt(t,p,0,'magic');assert.equal(hits[3].n,0);
});
