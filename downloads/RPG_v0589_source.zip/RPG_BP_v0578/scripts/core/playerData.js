import { system } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { JOBS } from "../data/jobs.js";

// 월드를 다시 열어도 유지되는 데이터는 플레이어 동적 속성에 저장합니다.
const KEY = {
  job: "rpg:job",
  skills: "rpg:skills", // 배운 스킬 id 배열(JSON)
  mana: "rpg:mana",
  forcedManaMax: "rpg:admin_mana_max",
  index: "rpg:skill_index",
  progress: "rpg:progress", // 전직 조건 진행도(JSON)
  disabled: "rpg:disabled_skills", // 사용자가 꺼 둔 스킬 id 배열(JSON)
};

export function getJobId(player) {
  const v = player.getDynamicProperty(KEY.job);
  // 과거 버전에서 미구현 반인반수 직업을 강제로 지정했던 저장값은 견습으로 취급.
  if (v === "beastkin") return "apprentice";
  return typeof v === "string" && JOBS[v] ? v : undefined;
}

export function setJobId(player, id) {
  player.setDynamicProperty(KEY.job, id);
}

export function getSkills(player) {
  try {
    const v = player.getDynamicProperty(KEY.skills);
    const arr = typeof v === "string" ? JSON.parse(v) : [];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

export function setSkills(player, arr) {
  player.setDynamicProperty(KEY.skills, JSON.stringify(arr));
}

// ---- 꺼 둔 스킬 (스킬 설정창에서 변경) ----
export function getDisabled(player) {
  try {
    const v = player.getDynamicProperty(KEY.disabled);
    const arr = typeof v === "string" ? JSON.parse(v) : [];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

export function setDisabled(player, arr) {
  player.setDynamicProperty(KEY.disabled, JSON.stringify(arr));
}

// ---- 전직 조건 진행도 ----
export function getProgress(player) {
  try {
    const v = player.getDynamicProperty(KEY.progress);
    const o = typeof v === "string" ? JSON.parse(v) : {};
    return o && typeof o === "object" ? o : {};
  } catch {
    return {};
  }
}

export function addProgress(player, key, n = 1) {
  const o = getProgress(player);
  o[key] = (o[key] ?? 0) + n;
  player.setDynamicProperty(KEY.progress, JSON.stringify(o));
  return o[key];
}

// ---- 마나 ----
// 최대 마나 = 기본 200 + (바친 책 수 x 권당 증가량), 직업별 상한 안에서.
// 책 수로 계산하기 때문에 견습 때 바친 책도 마법사로 전직하면 권당 20으로 다시 계산됩니다.
export function isHighMana(player) {
  return !!JOBS[getJobId(player)]?.highMana;
}

// 최대 마나
//  - 마법사/성직자 계열: 200 + 바친 책 수 x 20, 상한 없음 (책을 바치는 만큼 계속 늘어남)
//  - 그 외 직업: 항상 normalMax (1000)
export function maxManaOf(player) {
  // 관리자 전용 강제 마나 저장값은 모든 직업의 기본 최대 마나보다 우선한다.
  try {
    const forced=player.getDynamicProperty(KEY.forcedManaMax);
    if(Number.isSafeInteger(forced) && forced>=1 && forced<=100000)return forced;
  }catch{}
  if (!isHighMana(player)) return CONFIG.mana.normalMax;
  const books = getProgress(player).books ?? 0;
  return CONFIG.mana.base + books * CONFIG.mana.perBookHigh;
}

// 관리자 명령어는 현재 마나뿐 아니라 '최대 마나'를 저장하고 완전히 채운다.
// reset 인자는 강제 설정을 제거하고 원래 직업/책의 마나 공식으로 복원한다.
export function forceSetManaMax(player,input){
  const value=String(input??'').trim().toLowerCase();
  if(value==='reset'){
    try{
      player.setDynamicProperty(KEY.forcedManaMax,undefined);
      setMana(player,maxManaOf(player));
      const max=maxManaOf(player),current=getMana(player);
      if(current!==max)return {ok:false,reason:'마나 초기화 후 값 확인 실패'};
      return {ok:true,max,current,reset:true};
    }catch(error){return {ok:false,reason:'마나 설정 초기화 실패: '+String(error)};}
  }
  const amount=/^[0-9]+$/.test(value)?Number(value):NaN;
  if(!Number.isSafeInteger(amount)||amount<1||amount>100000)
    return {ok:false,reason:'강제 마나는 1~100,000 정수 또는 reset만 가능합니다.'};
  try{
    player.setDynamicProperty(KEY.forcedManaMax,amount);
    setMana(player,amount);
    const max=maxManaOf(player),current=getMana(player);
    if(max!==amount||current!==amount)return {ok:false,reason:`마나 저장 확인 실패 (현재 ${current}/${max})`};
    return {ok:true,max,current,reset:false};
  }catch(error){return {ok:false,reason:'마나 저장 실패: '+String(error)};}
}
// 1000 이상은 1k, 1.5k, 12k, 3.2M 처럼 줄여서 표시
export function formatMana(n) {
  n = Math.floor(n);
  const units = [[1e12, "T"], [1e9, "B"], [1e6, "M"], [1e3, "k"]];
  for (const [v, s] of units) {
    if (n >= v) {
      const x = n / v;
      const t = x >= 100 ? Math.floor(x).toString() : (Math.floor(x * 10) / 10).toString();
      return t + s;
    }
  }
  return String(n);
}
export function manaText(player) {
  return formatMana(getMana(player));
}
export function maxManaText(player) {
  return formatMana(maxManaOf(player));
}

export function getMana(player) {
  const v = player.getDynamicProperty(KEY.mana);
  const max = maxManaOf(player);
  return typeof v === "number" ? Math.min(v, max) : max;
}

export function setMana(player, value) {
  player.setDynamicProperty(KEY.mana, Math.max(0, Math.min(maxManaOf(player), value)));
}

// 스킬 사용 시 마나 소모. 마법사 상태에서 쓴 마나는 현자 전직 조건에 누적됩니다.
export function spendMana(player, amount) {
  setMana(player, getMana(player) - amount);
  if (["mage", "cleric"].includes(getJobId(player))) addProgress(player, "mana_spent", amount);
}

export function getIndex(player) {
  const v = player.getDynamicProperty(KEY.index);
  return typeof v === "number" ? v : 0;
}

export function setIndex(player, i) {
  player.setDynamicProperty(KEY.index, i);
}

// ---- 쿨타임: 온라인 틱 + 재접속/서버 재시작용 만료 시각 저장 ----
const cooldowns = new Map(); // playerId -> Map(skillId -> 끝나는 틱)
export const COOLDOWN_KEY='rpg:cooldowns_v1';
function cooldownMap(player){
  if(cooldowns.has(player.id))return cooldowns.get(player.id);
  const m=new Map(),raw=player.getDynamicProperty(COOLDOWN_KEY);
  if(raw!==undefined){
    const saved=JSON.parse(raw);if(saved.version!==1||!saved.until||typeof saved.until!=='object')throw Error('쿨타임 저장 데이터 오류');
    const now=Date.now();
    for(const [id,end]of Object.entries(saved.until)){
      if(!Number.isSafeInteger(end)||end<0)throw Error('쿨타임 저장 시각 오류');
      const left=Math.ceil((end-now)/50);if(left>0)m.set(id,system.currentTick+left);
    }
  }
  cooldowns.set(player.id,m);return m;
}
function saveCooldowns(player,m){
  const now=Date.now(),until={};
  for(const [id,tick]of m){const left=tick-system.currentTick;if(left>0)until[id]=now+Math.ceil(left*50);}
  player.setDynamicProperty(COOLDOWN_KEY,JSON.stringify({version:1,until}));
}

export function cooldownLeft(player, key) {
  const until = cooldownMap(player).get(key) ?? 0;
  return Math.max(0, until - system.currentTick);
}

export function startCooldown(player, key, ticks) {
  if(!Number.isFinite(ticks)||ticks<0)throw Error('잘못된 쿨타임');
  const m=cooldownMap(player);
  m.set(key, system.currentTick + ticks);
  saveCooldowns(player,m);
}

// 궁극기만 제외하고 스킬 쿨타임을 초기화 (해커 시스템 재부팅).
const ULTIMATE_IDS = new Set(["world_stop","war_god_black_flash","sword_rush","fist_finale","archer_heavenly","fallen_end","sage_zoltraak","blood_bind","hacker_emp","tech_storm","revenant_execution","frost_absolute","fire_emperor","shadow_assassinate","beast_grand_explosion"]);
export function resetNonUltimateCooldowns(player) {
  const m=cooldownMap(player);
  for (const id of [...m.keys()]) if (!ULTIMATE_IDS.has(id)) m.delete(id);
  saveCooldowns(player,m);
}

// 모든 스킬 쿨타임(기본 공격 포함) 초기화
export function resetCooldowns(player) {
  player.setDynamicProperty(COOLDOWN_KEY,undefined);
  cooldowns.delete(player.id);
}

export function clearPlayerRuntime(playerId) {
  cooldowns.delete(playerId);
}
