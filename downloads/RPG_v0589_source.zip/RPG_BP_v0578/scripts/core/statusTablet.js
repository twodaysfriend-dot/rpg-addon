import {world,system,ItemStack} from '@minecraft/server';
import {ActionFormData} from '@minecraft/server-ui';
import {getJobId,getMana,maxManaOf} from './playerData.js';
import {getLevel,getXp,xpForNext,getStats,LEVEL_MAX} from './stats.js';
import {JOBS} from '../data/jobs.js';
import {showForm} from './skillMenu.js';

export const STATUS_TABLET='rpg:status_tablet';
export const STATUS_TITLE='§bSTATUS §8| §f상태창';
const GIVEN='rpg:status_tablet_given_v1';
const open=new Set(),lastUse=new Map();
let actionHandler,registered=false;
export const STATUS_ACTIONS=Object.freeze([
 {action:'dungeon',text:'§b던전 입장\n§8던전 목록'},
 {action:'party',text:'§b파티\n§8생성 · 초대'},
 {action:'runes',text:'§b룬 장착\n§8보관 · 관리'},
 {action:'skillguide',text:'§b스킬 효과\n§8효과 · MP · 쿨'},
 {action:'craft',text:'§b아이템 조합법\n§8재료 · 배치'},
 {action:'guild',text:'§b길드 확인\n§8생성 · 멤버'},
 {action:'stats',text:'§b스탯 배분\n§8능력치 · SP'},
 {action:'equipment',text:'§b장비 정보\n§8갑옷 · 효과'},
 {action:'upgrade',text:'§b장비 강화\n§8강화 관리'},
 {action:'jobs',text:'§b전직 안내\n§8직업 · 조건'},
 {action:'pvp',text:'§bPvP 결투\n§8플레이어 선택'},
 {action:'wallet',text:'§b지갑 · XP 상점\n§8포션 · 촉매 구매'},
 {action:'invites',text:'§b받은 초대\n§8파티 · 길드'},
 {action:'transfer',text:'§b강화 이전\n§8추출 · 적용'},
 {action:'tpa',text:'§b이동 요청 TPA\n§8이동 시 1,000골드'},
 {action:'tpaaccept',text:'§b받은 이동 요청\n§8수락 · 거절'},
 {action:'refresh',text:'§a새로고침\n§8내 정보 갱신'},
 {action:'close',text:'§7닫기\n§8모험으로 돌아가기'}
]);
export function resourceBar(value,max,color='§b'){
 const ratio=Number.isFinite(value)&&Number.isFinite(max)&&max>0?Math.max(0,Math.min(1,value/max)):0;
 const n=Math.round(ratio*10);return color+'■'.repeat(n)+'§8'+'■'.repeat(10-n)+'§r';
}
const number=n=>String(Math.round(Number.isFinite(n)?n:0));
export function statusBody(p){
 const h=p.getComponent('minecraft:health'),mp=getMana(p),maxMp=maxManaOf(p);
 const level=getLevel(p),xp=getXp(p),next=xpForNext(level),s=getStats(p),capped=level>=LEVEL_MAX;
 const name=String(p.name).replace(/§./g,'').slice(0,22);
 return `§f${name}\n§b${JOBS[getJobId(p)]?.name??'견습'} §fLv.${level}\n\n`+
  `§fHP ${number(h?.currentValue??0)} / ${number(h?.effectiveMax??20)}\n${resourceBar(h?.currentValue??0,h?.effectiveMax??20)}\n`+
  `§fMP ${number(mp)} / ${number(maxMp)}\n${resourceBar(mp,maxMp)}\n`+
  `§fEXP ${capped?'MAX':number(xp)+' / '+number(next)}\n${resourceBar(capped?1:xp,capped?1:next,'§d')}\n\n`+
  `§7근력 §f${s.str}  §7마력 §f${s.mag}\n§7체력 §f${s.vit}  §7지능 §f${s.int}`;
}
export async function openStatusTablet(p){
 if(!p?.isValid||open.has(p.id)||!actionHandler)return;
 open.add(p.id);
 let next;
 try{
  while(p.isValid){
   const form=new ActionFormData().title(STATUS_TITLE).body(statusBody(p));
   for(const entry of STATUS_ACTIONS)form.button(entry.text);
   const res=await showForm(form,p);
   if(!res||res.canceled||!Number.isInteger(res.selection)||res.selection<0||res.selection>=STATUS_ACTIONS.length)return;
   const selected=STATUS_ACTIONS[res.selection].action;
   if(selected==='refresh')continue;
   if(selected!=='close')next=selected;
   break;
  }
 }catch(error){try{p.sendMessage('§c[상태창] '+String(error.message??error));}catch{}}
 finally{open.delete(p.id);}
 // Defer the next form so Bedrock can close this form first.
 if(next&&p.isValid)system.run(()=>{try{const result=actionHandler(next,p);Promise.resolve(result).catch(error=>{try{p.sendMessage('§c[상태창] '+String(error));}catch{}});}catch(error){try{p.sendMessage('§c[상태창] '+String(error));}catch{}}});
}
export function giveStatusTablet(p){
 if(!p?.isValid||p.getDynamicProperty(GIVEN))return;
 const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return;
 for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId===STATUS_TABLET){p.setDynamicProperty(GIVEN,true);return;}
 const remainder=inv.addItem(new ItemStack(STATUS_TABLET,1));
 if(remainder){p.sendMessage('§e[상태창] 인벤토리를 비운 후 재접속하면 지급됩니다. /rpg:menu로도 열 수 있습니다.');return;}
 p.setDynamicProperty(GIVEN,true);
 p.sendMessage('§b[상태창] 상태창 아이템을 지급했습니다. 손에 들고 사용해 모험 메뉴를 여세요.');
}
function useTablet(p){
 if(!p?.isValid||open.has(p.id)||(lastUse.get(p.id)??-100)>system.currentTick-5)return;
 lastUse.set(p.id,system.currentTick);system.run(()=>openStatusTablet(p));
}
// Register the component in startup, before item definitions are used.
system.beforeEvents.startup.subscribe(event=>{
 try{event.itemComponentRegistry.registerCustomComponent('rpg:status_tablet',{onUse(e){useTablet(e.source);}});}
 catch(error){console.warn('[RPG status tablet component] '+error);}
});
export function registerStatusTablet(handler){
 actionHandler=handler;if(registered)return;registered=true;
 world.afterEvents.itemUse.subscribe(e=>{if(e.itemStack?.typeId===STATUS_TABLET)useTablet(e.source);});
 world.afterEvents.playerSpawn.subscribe(e=>system.runTimeout(()=>{try{giveStatusTablet(e.player);}catch(error){console.warn('[RPG status tablet grant] '+error);}},40));
 world.afterEvents.playerLeave.subscribe(e=>{open.delete(e.playerId);lastUse.delete(e.playerId);});
 system.runTimeout(()=>{for(const p of world.getAllPlayers())try{giveStatusTablet(p);}catch(error){console.warn('[RPG status tablet grant] '+error);}},40);
}
