from pathlib import Path
import subprocess,tempfile,sys
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as temp:
 for source in sorted((root/'tests').glob('test_*.mjs')):
  text=source.read_text().replace('/workspace/status0589',root.as_posix())
  for name in ['skills.js','jobs.js']:
   text=text.replace('/workspace/status0588/RPG_BP_v0578/scripts/data/'+name,(root/'tests/baseline'/name).as_posix())
  test=Path(temp)/source.name;test.write_text(text)
  result=subprocess.run(['node',str(test)])
  if result.returncode:sys.exit(result.returncode)
print('All bundled mock tests passed. Bedrock in-game checks remain pending.')
