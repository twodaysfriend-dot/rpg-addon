import { world, system, EntityDamageCause } from '@minecraft/server';
import { getTargets, hurt, knockback, particle, sound, headPos, isSolidAt, healthAlive } from '../core/util.js';
import { notify } from '../core/hud.js';
import { getJobId } from '../core/playerData.js';
import { areAllies } from '../core/social.js';
import { SKILLS } from '../data/skills.js';

// 넨 능력자. 오라 = 마나 풀(HUD 에서만 이름이 오라). 지능(소모 감소 ×1.25)과 샘의 룬(회복 ×1.5)은 각각 stats.js / main.js 에서 처리합니다.
//  전(纏) 방어 / 은(隱) 은신 / 경(硬) 다음 근접 공격 추가 피해 / 주(周) 근접 공격 추가 피해 /
//  발(發) 오라 구체 / 원(円) 궁극기
// 스킬 피해는 모두 hurt(... ignoreInvulnerability) 로 cause "override" 라서, 근접 공격(entityAttack) 후속 효과와 섞이지 않습니다.

const AURA = 'rpg:nen_aura';
const SPARK = 'rpg:nen_spark';
const HIT = 'rpg:nen_impact';
const BOOM = 'rpg:nen_burst';

// playerId -> { ko: 끝나는 틱, shu: 끝나는 틱, hide: { until, used }, en: { until, hit:Set } }
const state = new Map();
function st(p) {
  let s = state.get(p.id);
  if (!s) {
    s = { ten:0, ko: 0, shu: 0, hide: undefined, en: undefined };
    state.set(p.id, s);
  }
  return s;
}
const now = () => system.currentTick;

function alive(e) {
  try {
    return !!e && e.isValid !== false && healthAlive(e);
  } catch {
    return false;
  }
}

function ring(dim, c, r, id, n = 20, y = 0.3) {
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    particle(dim, id, { x: c.x + Math.cos(a) * r, y: c.y + y, z: c.z + Math.sin(a) * r });
  }
}

function body(e) {
  const l = e.location;
  return { x: l.x, y: l.y + 1, z: l.z };
}

function effect(p, id, ticks, amp, show = true) {
  try {
    p.addEffect(id, ticks, { amplifier: amp, showParticles: show });
  } catch {
    // 효과를 걸 수 없는 상태
  }
}

function enemy(p, t) {
  return !!t && t.id !== p.id && !areAllies(p, t) && alive(t);
}

function endHide(p, reason) {
  const s = state.get(p.id);
  if (!s?.hide) return;
  s.hide = undefined;
  try {
    p.removeEffect('invisibility');
  } catch {
    // 이미 사라짐
  }
  if (reason) notify(p, reason);
}

// ---------------------------------------------------------------------------
// 스킬
// ---------------------------------------------------------------------------
function ten(p, job, def) {
  st(p).ten=now()+def.duration;
  effect(p, 'resistance', def.duration, def.resistAmp, true);
  const l = p.location;
  ring(p.dimension, l, 0.9, AURA, 18, 0.2);
  ring(p.dimension, l, 0.9, AURA, 18, 1.0);
  ring(p.dimension, l, 0.9, AURA, 18, 1.8);
  sound(p.dimension, 'random.levelup', l, { volume: 0.4, pitch: 0.6 });
  notify(p, `§3전(纏) §f${def.duration / 20}초간 오라로 몸을 감쌉니다`);
}

function inn(p, job, def) {
  const s = st(p);
  effect(p, 'invisibility', def.duration, 0, false);
  s.hide = { until: now() + def.duration };
  particle(p.dimension,'rpg:nen_veil',body(p));
  sound(p.dimension, 'mob.endermen.portal', p.location, { volume: 0.4, pitch: 1.6 });
  notify(p, `§3은(隱) §f${def.duration / 20}초 은신 · 첫 공격 피해 ${def.firstHitMult}배`);
  // 시간이 지나면 상태만 정리(투명화 효과는 스스로 끝남)
  system.runTimeout(() => {
    const cur = state.get(p.id);
    if (cur?.hide && cur.hide.until <= now()) cur.hide = undefined;
  }, def.duration + 2);
}

function ko(p, job, def) {
  st(p).ko = now() + def.window;
  const l = p.location;
  ring(p.dimension, l, 0.6, 'rpg:nen_focus', 10, 1.0);
  sound(p.dimension, 'random.anvil_land', l, { volume: 0.4, pitch: 1.8 });
  notify(p, `§3경(硬) §f다음 근접 공격에 추가 피해 ${def.damage}`);
}

function shu(p, job, def) {
  st(p).shu = now() + def.duration;
  const l = p.location;
  ring(p.dimension, l, 0.7, 'rpg:nen_wrap', 14, 1.2);
  sound(p.dimension, 'random.orb', l, { volume: 0.6, pitch: 0.7 });
  notify(p, `§3주(周) §f${def.duration / 20}초간 근접 공격에 오라 추가 피해`);
}

function explode(p, at, def) {
  const dim = p.dimension;
  particle(dim, BOOM, at);
  ring(dim, at, def.radius * 0.5, AURA, 18, 0.2);
  ring(dim, at, def.radius * 0.9, AURA, 24, 0.2);
  sound(dim, 'random.explode', at, { volume: 0.9, pitch: 1.3 });
  for (const t of getTargets(p, at, def.radius, 0.9)) {
    if (!enemy(p, t)) continue;
    hurt(t, p, def.damage, 'magic', { ignoreInvulnerability: true });
    const tl = t.location;
    knockback(t, tl.x - at.x, tl.z - at.z, def.knockback, 0.45);
    particle(dim, HIT, body(t));
  }
}

function dirOf(p) {
  const d = p.getViewDirection();
  const len = Math.hypot(d.x, d.y, d.z) || 1;
  return { x: d.x / len, y: d.y / len, z: d.z / len };
}

// 오라 구체 비행/폭발(발·연탄 공용). def: speed, range, hitRadius + explode() 가 쓰는 radius/damage/knockback
function fire(p, def, quiet = false) {
  const dim = p.dimension;
  const dir = dirOf(p);
  const h = headPos(p);
  let pos = { x: h.x + dir.x * 0.8, y: h.y - 0.2 + dir.y * 0.8, z: h.z + dir.z * 0.8 };
  let travelled = 0;
  if (!quiet) sound(dim, 'mob.blaze.shoot', pos, { volume: 0.5, pitch: 1.6 });
  particle(dim, SPARK, pos);

  const id = system.runInterval(() => {
    try {
      if (!alive(p) || p.dimension.id !== dim.id) {
        system.clearRun(id);
        return;
      }
      // 한 틱을 반으로 나눠 얇은 벽/대상을 건너뛰지 않게 확인
      for (let k = 0; k < 2; k++) {
        const stepLen = def.speed / 2;
        const next = { x: pos.x + dir.x * stepLen, y: pos.y + dir.y * stepLen, z: pos.z + dir.z * stepLen };
        travelled += stepLen;
        if (isSolidAt(dim, next)) {
          system.clearRun(id);
          explode(p, pos, def);
          return;
        }
        pos = next;
        particle(dim, AURA, pos);
        if (travelled > def.range) {
          system.clearRun(id);
          explode(p, pos, def);
          return;
        }
        const hit = getTargets(p, pos, def.hitRadius, 0.9).find((t) => enemy(p, t));
        if (hit) {
          system.clearRun(id);
          explode(p, pos, def);
          return;
        }
      }
      particle(dim, SPARK, pos);
    } catch {
      system.clearRun(id);
    }
  }, 1);
}

function hatsu(p, job, def) {
  fire(p, def);
}

// ---------------------------------------------------------------------------
// 방출(放出): 강화계가 오라를 몸 밖으로 내보내는 기술. 마나는 data/skills.js 에 ×1.25 가 반영돼 있습니다.
// ---------------------------------------------------------------------------
function renda(p, job, def) {
  notify(p, `§3방출 · 연탄 §f오라탄 ${def.shots}연사`);
  fire(p, def);
  for (let i = 1; i < def.shots; i++) {
    system.runTimeout(() => {
      try {
        if (alive(p)) fire(p, def, true);
      } catch {
        // 시전자 상태를 읽을 수 없음
      }
    }, i * def.gap);
  }
}

function beam(p, def) {
  const dim = p.dimension;
  const dir = dirOf(p);
  const h = headPos(p);
  let pos = { x: h.x + dir.x * 0.5, y: h.y - 0.2 + dir.y * 0.5, z: h.z + dir.z * 0.5 };
  const hit = new Set();
  sound(dim, 'random.explode', pos, { volume: 0.6, pitch: 1.7 });
  sound(dim, 'beacon.power_select', pos, { volume: 0.8, pitch: 1.5 });
  for (let d = 0; d < def.range; d++) {
    const next = { x: pos.x + dir.x, y: pos.y + dir.y, z: pos.z + dir.z };
    if (isSolidAt(dim, next)) break;
    pos = next;
    particle(dim, AURA, pos);
    particle(dim, SPARK, pos);
    for (const t of getTargets(p, pos, def.hitRadius, 0.9)) {
      if (!enemy(p, t) || hit.has(t.id)) continue;
      hit.add(t.id);
      hurt(t, p, def.damage, 'magic', { ignoreInvulnerability: true });
      knockback(t, dir.x, dir.z, def.knockback, 0.3);
      particle(dim, HIT, body(t));
    }
  }
  particle(dim, BOOM, pos);
  if (hit.size) notify(p, `§3오라포 §f${hit.size}체 관통`);
}

function ho(p, job, def) {
  const dim = p.dimension;
  effect(p, 'slowness', def.charge + 4, def.slowAmp, false);
  sound(dim, 'beacon.activate', p.location, { volume: 0.7, pitch: 1.8 });
  notify(p, `§3방출 · 오라포 §f${def.charge / 20}초 충전`);
  // 충전 연출: 오라가 몸으로 모입니다.
  let n = 0;
  const vis = system.runInterval(() => {
    try {
      if (!alive(p) || n >= 5) {
        system.clearRun(vis);
        return;
      }
      ring(dim, p.location, 1.8 - n * 0.3, AURA, 16, 1.0);
      n++;
    } catch {
      system.clearRun(vis);
    }
  }, 4);
  system.runTimeout(() => {
    try {
      if (!alive(p) || p.dimension.id !== dim.id) return;
      beam(p, def);
    } catch {
      // 시전자 상태를 읽을 수 없음
    }
  }, def.charge);
}

function zan(p, job, def) {
  const dim = p.dimension;
  const d = dirOf(p);
  const flat = Math.hypot(d.x, d.z) || 1;
  const fx = d.x / flat;
  const fz = d.z / flat;
  const o = p.location;
  const s = st(p);
  const kou = s.ko > now();
  const half = (def.halfAngle * Math.PI) / 180;
  const cos = Math.cos(half);
  const base = Math.atan2(fz, fx);
  for (let i = -6; i <= 6; i++) {
    const a = base + (i / 6) * half;
    for (const r of [def.range * 0.5, def.range * 0.8, def.range]) {
      particle(dim, AURA, { x: o.x + Math.cos(a) * r, y: o.y + 1, z: o.z + Math.sin(a) * r });
    }
  }
  sound(dim, 'mob.blaze.shoot', o, { volume: 0.6, pitch: 0.8 });
  let hits = 0;
  for (const t of getTargets(p, { x: o.x, y: o.y + 1, z: o.z }, def.range, 0.9)) {
    if (!enemy(p, t)) continue;
    const l = t.location;
    const dx = l.x - o.x;
    const dz = l.z - o.z;
    const dist = Math.hypot(dx, dz);
    if (dist > 0.01 && (dx * fx + dz * fz) / dist < cos) continue;
    hurt(t, p, def.damage + (kou ? defs.nen_ko.damage : 0), 'physical', { ignoreInvulnerability: true });
    knockback(t, dx, dz, def.knockback, 0.3);
    particle(dim, HIT, body(t));
    hits++;
  }
  if (kou && hits > 0) {
    s.ko = 0;
    notify(p, `§3참격파 §f경(硬) 소모 · ${hits}체 적중`);
  } else if (hits > 0) {
    notify(p, `§3참격파 §f${hits}체 적중`);
  }
}

function boku(p, job, def) {
  const dim = p.dimension;
  const c = p.location;
  particle(dim, BOOM, { x: c.x, y: c.y + 1, z: c.z });
  ring(dim, c, def.radius * 0.35, AURA, 24, 0.2);
  ring(dim, c, def.radius * 0.7, AURA, 36, 0.2);
  ring(dim, c, def.radius, AURA, 48, 0.2);
  sound(dim, 'random.explode', c, { volume: 1.2, pitch: 0.8 });
  let hits = 0;
  for (const t of getTargets(p, { x: c.x, y: c.y + 1, z: c.z }, def.radius, 0.9)) {
    if (!enemy(p, t)) continue;
    hurt(t, p, def.damage, 'magic', { ignoreInvulnerability: true });
    const l = t.location;
    knockback(t, l.x - c.x, l.z - c.z, def.knockback, 0.7);
    particle(dim, HIT, body(t));
    hits++;
  }
  effect(p, 'resistance', def.guard, def.resistAmp, true);
  notify(p, `§3방출 · 오라 폭주 §f${hits}체 적중 · ${def.guard / 20}초 저항`);
}

function en(p, job, def) {
  const s = st(p);
  s.en = { until: now() + def.duration, hit: new Set() };
  effect(p, 'speed', def.duration, def.speedAmp, true);
  const dim = p.dimension;
  const c = p.location;
  ring(dim, c, def.radius * 0.35, 'rpg:nen_ring', 24, 0.2);
  ring(dim, c, def.radius * 0.7, 'rpg:nen_ring', 36, 0.2);
  ring(dim, c, def.radius, 'rpg:nen_ring', 48, 0.2);
  sound(dim, 'beacon.activate', c, { volume: 0.8, pitch: 1.4 });
  notify(p, `§3원(円) §f${def.duration / 20}초간 반경 ${def.radius}칸 감지`);

  // 감지 중인 적 머리 위에 표식, 시전자 주변에 퍼지는 원
  let ticks = 0;
  const id = system.runInterval(() => {
    try {
      const cur = state.get(p.id)?.en;
      if (!alive(p) || !cur || cur !== s.en || cur.until <= now()) {
        system.clearRun(id);
        if (cur === s.en) s.en = undefined;
        return;
      }
      const l = p.location;
      ring(p.dimension, l, ((ticks * 0.8) % def.radius) + 1, 'rpg:nen_ring', 16, 0.2);
      ticks++;
      let shown = 0;
      for (const t of getTargets(p, { x: l.x, y: l.y + 1, z: l.z }, def.radius, 0)) {
        if (!enemy(p, t)) continue;
        const b = t.location;
        particle(p.dimension, 'rpg:nen_marker', { x: b.x, y: b.y + 2.4, z: b.z });
        if (++shown >= 40) break;
      }
    } catch {
      system.clearRun(id);
    }
  }, 10);
}

export const RUNNERS = {
  nen_ten: ten,
  nen_in: inn,
  nen_ko: ko,
  nen_shu: shu,
  nen_hatsu: hatsu,
  nen_renda: renda,
  nen_ho: ho,
  nen_zan: zan,
  nen_boku: boku,
  nen_en: en,
};

const defs = SKILLS;

// ---------------------------------------------------------------------------
// 근접 공격 후속 효과 / 정리
// ---------------------------------------------------------------------------
function onHurt(ev) {
  const victim = ev.hurtEntity;
  const src = ev.damageSource;

  // 맞으면 은신 해제
  if (victim?.typeId === 'minecraft:player' && state.get(victim.id)?.hide) {
    endHide(victim, '§7은(隱)이 풀렸습니다. (피격)');
  }

  const attacker = src?.damagingEntity;
  if (attacker?.typeId !== 'minecraft:player' || src.cause !== EntityDamageCause.entityAttack) return;
  if (getJobId(attacker) !== 'nen' || !defs) return;
  if (!victim || !enemy(attacker, victim)) return;

  const s = state.get(attacker.id);
  if (!s) return;
  const t = now();
  let phys = 0;
  let fixed = 0;
  const tags = [];

  if (s.ko > t) {
    phys += defs.nen_ko.damage;
    s.ko = 0;
    tags.push('경');
  }
  if (s.shu > t) {
    phys += defs.nen_shu.damage;
    tags.push('주');
  }
  if (s.hide) {
    fixed += ev.damage * (defs.nen_in.firstHitMult - 1);
    tags.push('은');
    endHide(attacker);
  }
  if (s.en && s.en.until > t && !s.en.hit.has(victim.id)) {
    const a = attacker.location;
    const v = victim.location;
    if (Math.hypot(a.x - v.x, a.z - v.z) <= defs.nen_en.radius) {
      s.en.hit.add(victim.id);
      fixed += ev.damage * (defs.nen_en.critMult - 1);
      tags.push('원');
    }
  }
  if (phys <= 0 && fixed <= 0) return;

  if (phys > 0) hurt(victim, attacker, phys, 'physical', { ignoreInvulnerability: true });
  if (fixed > 0) hurt(victim, attacker, fixed, 'fixed', { ignoreInvulnerability: true });
  if (s.shu > t && phys > 0) {
    const a = attacker.location;
    const v = victim.location;
    knockback(victim, v.x - a.x, v.z - a.z, defs.nen_shu.knock, 0.25);
  }
  const at = body(victim);
  particle(victim.dimension, HIT, at);
  particle(victim.dimension, AURA, at);
  sound(victim.dimension, 'random.anvil_land', victim.location, { volume: 0.3, pitch: 1.7 });
  notify(attacker, `§3${tags.join('·')} §f오라 타격`);
}

let registered=false;
export function nenAuraTick(){
 for(const p of world.getAllPlayers()){
  if(!alive(p)||getJobId(p)!=='nen')continue;
  const s=st(p);if((s.hide&&s.hide.until>now())||p.getEffect('invisibility'))continue;
  const base=p.location;particle(p.dimension,AURA,{x:base.x,y:base.y+.9,z:base.z});
  const t=now()*.12,l=p.location;
  if(s.ten>now())for(let i=0;i<4;i++){const a=t+i*Math.PI/2;particle(p.dimension,AURA,{x:l.x+Math.cos(a)*.65,y:l.y+.3+(i%3)*.55,z:l.z+Math.sin(a)*.65});}
  if(s.ko>now())particle(p.dimension,'rpg:nen_focus',{x:l.x+.35,y:l.y+1,z:l.z+.15});
  if(s.shu>now())for(const sign of [-1,1])particle(p.dimension,'rpg:nen_wrap',{x:l.x+sign*.45,y:l.y+1.1+Math.sin(t)*.15,z:l.z});
 }
}
export function registerNen() {
 if(registered)return;registered=true;
 system.runInterval(nenAuraTick,5);
  world.afterEvents.playerLeave.subscribe((ev) => state.delete(ev.playerId));
  world.afterEvents.entityDie.subscribe((ev) => {
    if (ev.deadEntity?.typeId === 'minecraft:player') state.delete(ev.deadEntity.id);
  });
  world.afterEvents.entityHurt.subscribe((ev) => {
    try {
      onHurt(ev);
    } catch {
      // 상태를 읽을 수 없는 경우
    }
  });
  // 직업이 바뀌면 남은 상태를 버립니다.
  system.runInterval(() => {
    for (const p of world.getAllPlayers()) {
      try {
        if (state.has(p.id) && getJobId(p) !== 'nen') state.delete(p.id);
      } catch {
        // 플레이어 상태를 읽을 수 없음
      }
    }
  }, 40);
}
