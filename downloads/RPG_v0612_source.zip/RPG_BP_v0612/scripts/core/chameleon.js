import {weaponBinding} from './weaponBinding.js';
import { ItemStack, ItemLockMode } from "@minecraft/server";
import {upgradeLevel} from '../data/upgrades.js';
import {setGearLevel} from './gearState.js';
import * as UI from "@minecraft/server-ui";
import { JOBS, APPRENTICE_SKILLS } from "../data/jobs.js";
import { SKILLS } from "../data/skills.js";
import { getJobId, getSkills, setSkills, getDisabled, setDisabled, getIndex, setIndex } from "./playerData.js";
import { showForm } from "./skillMenu.js";
import { refreshHud } from "./hud.js";
import {unspentPoints} from "./stats.js";
import {purchaseChameleonSkill,syncChameleonLoadout,learningRule,remainingSkillUses,rechargeSkill,useRandomSkillBook,deliverSkillBooks,readChameleonProgress,dismantleChameleonSkill,evolveChameleonSkill,evolvableSkills,evolveCost,isEvolved,EVOLVE_MAX} from "./chameleonProgress.js";

export const CHAMELEON_WEAPONS = ["rpg:chameleon_flame_blade", "rpg:chameleon_moon_scythe"];
const isChameleon = p => getJobId(p) === "chameleon";

// 배우는 대상은 게임에 등록된 실제 직업이 사용하는 액티브 스킬만.
// 제거된 네크로맨서/반물질 등 미구현 계열은 포함하지 않음.
const GROUPS = [
  ["sword", "검사·검성"], ["mage", "마법사·현자"], ["archer", "궁수·천궁"],
  ["holy", "성직자·천사"], ["fist", "무투가·권골"], ["war_god", "투신"], ["berserker", "망나니·야수"],
  ["assassin", "암살자·그림자 암살자"], ["harpoon", "작살꾼·복수귀"],
  ["hacker", "해커"], ["dragon", "용기사"], ["blood", "혈술사"], ["frost", "냉기 능력자"],
  ["fire", "화염술사"], ["tech", "마법공학사"], ["demon", "악마"],
  ["celestial_sun", "해의 후예"], ["celestial_moon", "달의 후예"],
];

const ALLOWED = new Set();
for (const j of Object.values(JOBS)) {
  if (j.placeholder || j.id === 'chameleon') continue;
  for (const id of j.skills ?? []) if (SKILLS[id]) ALLOWED.add(id);
}
for (const arr of Object.values(APPRENTICE_SKILLS)) for (const id of arr) if (SKILLS[id]) ALLOWED.add(id);
export const CHAMELEON_SKILLS = [...ALLOWED];
export const CHAMELEON_GROUPS = GROUPS.map(([line, name]) => ({
  line, name, ids: CHAMELEON_SKILLS.filter(id => SKILLS[id]?.line === line),
})).filter(g => g.ids.length);

export function learnChameleonSkill(p, query) {
  if (!isChameleon(p)) return {ok:false, message:'카멜레온 직업만 다른 직업 스킬을 배울 수 있습니다.'};
  const key=String(query??'').trim();
  if (!key) return {ok:false,message:'스킬 ID를 입력하거나 /rpg:skillbook 에서 선택하세요.'};
  const normalize=s=>String(s).replace(/\s+/g,'').toLowerCase();
  const wanted=normalize(key);
  let id=ALLOWED.has(key) ? key : CHAMELEON_SKILLS.find(x=>normalize(x)===wanted || normalize(SKILLS[x]?.name)===wanted);
  if(!id)return {ok:false,message:`'${key}'은(는) 배울 수 있는 스킬이 아닙니다. /rpg:skillbook`};
  const result=purchaseChameleonSkill(p,id);
  if(result.ok){const off=getDisabled(p);if(off.includes(id))setDisabled(p,off.filter(x=>x!==id));refreshHud(p,true);}
  return result;
}

export function swapChameleonWeapon(p) {
  if(weaponBinding(p))return {ok:false,message:"공통 무기 대체 중에는 무기 전환 대신 /rpg:weapon에서 대체를 해제하세요."};
  if (!isChameleon(p)) return {ok:false,message:'카멜레온 직업만 무기를 전환할 수 있습니다.'};
  try {
    const c=p.getComponent('minecraft:inventory')?.container;
    if(!c)return {ok:false,message:'인벤토리를 사용할 수 없습니다.'};
    const old=c.getItem(0)?.typeId;
    if(!CHAMELEON_WEAPONS.includes(old))return {ok:false,message:'1번 칸의 카멜레온 무기를 확인해 주세요.'};
    const next=old===CHAMELEON_WEAPONS[0]?CHAMELEON_WEAPONS[1]:CHAMELEON_WEAPONS[0];
    const weapon=setGearLevel(new ItemStack(next,1),'weapon',upgradeLevel(c.getItem(0),'weapon')); weapon.lockMode=ItemLockMode?.slot??'slot';weapon.keepOnDeath=true;
    c.setItem(0,weapon);refreshHud(p,true);
    try{p.dimension.playSound('random.click',p.location,{volume:.65,pitch:1.3});}catch{}
    return {ok:true,message:`§e카멜레온 무기 전환: §f${next===CHAMELEON_WEAPONS[0]?'흑염 대검':'백월의 낫'}`};
  }catch(e){return {ok:false,message:'무기를 교체하지 못했습니다: '+String(e)};}
}

// 카멜레온이 스킬을 사용할 때 일부 원본 스킬이 직업 id를 검사한다.
// 그 스킬의 원래 직업 컨텍스트를 전달하여 특수 효과를 최대한 유지한다.
const OVERRIDES={
  sword_annihilation:'sword_saint', fallen_sword_frenzy:'fallen_sword_saint',
  sword_rush:'sword_saint', harpoon_throw:'harpooner', revenant_execution:'revenant',
  fist_finale:'fist_bone', holy_heal:'cleric',
};
export function chameleonCastJob(skillId, ownJob){
  if(ownJob?.id!=='chameleon')return ownJob;
  const overridden=JOBS[OVERRIDES[skillId]];
  if(overridden)return overridden;
  const found=Object.values(JOBS).find(j => !j.placeholder && j.id!=='chameleon' && j.skills?.includes(skillId));
  return found??ownJob;
}

const menuOpen=new Set();
export async function openChameleonSkillbook(p){
  if(!isChameleon(p)){p.sendMessage('§c카멜레온 직업만 사용할 수 있습니다.');return;}
  if(menuOpen.has(p.id))return;menuOpen.add(p.id);
  try{
    syncChameleonLoadout(p);
    while(isChameleon(p)){
      const state=readChameleonProgress(p),learned=new Set(getSkills(p));
      const main=new UI.ActionFormData().title('카멜레온 · 스킬 학습')
        .body(`남은 레벨 SP ${unspentPoints(p)} / 누적 구매 SP ${state.spentSp} / 분해 환급 SP ${state.refundedSp}\n일반 3 SP · 중요 9 SP · 궁극기/카피 15 SP\n중요 기술은 횟수 제한과 다이아 충전이 있습니다.\n횟수 제한 스킬은 골드+강화석으로 최대 3개까지 진화(무제한)할 수 있습니다.\n카멜레온으로 실제 5레벨 상승마다 랜덤 책 1권. 다음 책까지 ${5-state.levelsToBook}레벨.\n대기 책 ${state.pendingBooks}권`)
        .button('랜덤 스킬북 1권 사용').button('가방 부족으로 대기 중인 책 받기').button('다이아몬드로 사용 횟수 충전').button('스킬 분해 · SP 환급').button(`스킬 진화 · 무제한 (${state.evolved.length}/${EVOLVE_MAX})`);
      for(const group of CHAMELEON_GROUPS)main.button(`${group.name} (${group.ids.filter(id=>learned.has(id)).length}/${group.ids.length})`);
      main.button('닫기');const response=await showForm(main,p);
      if(!response||response.canceled||response.selection==null||response.selection>=CHAMELEON_GROUPS.length+5)return;
      if(response.selection===0){const r=useRandomSkillBook(p);p.sendMessage(r.message);continue;}
      if(response.selection===1){p.sendMessage('§a스킬북 '+deliverSkillBooks(p)+'권 수령');continue;}
      if(response.selection===2){
        const ids=getSkills(p).filter(id=>SKILLS[id]&&learningRule(id).uses!==null&&!isEvolved(p,id)),form=new UI.ActionFormData().title('사용 횟수 충전');
        for(const id of ids)form.button(SKILLS[id].name+' · 남은 '+remainingSkillUses(p,id)+'회');form.button('뒤로');
        const picked=await showForm(form,p);if(!picked||picked.canceled||picked.selection==null||picked.selection>=ids.length)continue;
        const id=ids[picked.selection],rule=learningRule(id),numbers=[1,5,10];
        const amount=new UI.ActionFormData().title('다이아 사용량').body('다이아 1개당 '+rule.diamondUses+'회 충전. 취소하면 소비하지 않습니다.');
        for(const n of numbers)amount.button(`다이아 ${n}개 → +${n*rule.diamondUses}회`);amount.button('취소');
        const choice=await showForm(amount,p);if(choice&&!choice.canceled&&choice.selection<numbers.length){const r=rechargeSkill(p,id,numbers[choice.selection]);p.sendMessage(r.message);}continue;
      }
      if(response.selection===3){
        const ids=state.learned.filter(id=>SKILLS[id]),form=new UI.ActionFormData().title('스킬 분해 · SP 환급').body('일반 3 / 중요 9 / 궁극기·카피 15 SP. 스킬북 습득 기술도 환급합니다.\n기본 돌진·지면강타는 분해할 수 없습니다. 재학습해도 사용 횟수·쿨타임은 이어집니다.');
        for(const id of ids)form.button(`${SKILLS[id].name} → ${learningRule(id).cost} SP`);form.button('뒤로');
        const picked=await showForm(form,p);if(!picked||picked.canceled||picked.selection==null||picked.selection>=ids.length)continue;
        const id=ids[picked.selection],yes=await showForm(new UI.MessageFormData().title('스킬 분해 확인').body(`${SKILLS[id].name}을 잊고 ${learningRule(id).cost} SP를 받습니다. 다시 쓰려면 재학습해야 합니다.`).button1('취소').button2('분해'),p);
        if(yes&&!yes.canceled&&yes.selection===1){const r=dismantleChameleonSkill(p,id);p.sendMessage(r.message);refreshHud(p,true);}continue;
      }
      if(response.selection===4){
        const ids=evolvableSkills(p),form=new UI.ActionFormData().title('스킬 진화 · 무제한')
          .body(`횟수 제한 스킬을 최대 ${EVOLVE_MAX}개까지 횟수 무제한으로 진화시킵니다. (현재 ${state.evolved.length}/${EVOLVE_MAX})\n재료: 골드 + 강화석 (/rpg:wallet 재화)\n중요 스킬 골드 30,000 + 강화석 60\n궁극기·카피 골드 100,000 + 강화석 200\n진화한 스킬을 분해하면 진화 슬롯도 사라집니다.`);
        for(const id of ids){const c=evolveCost(id);form.button(`${isEvolved(p,id)?'§d[진화 완료]':'§e[진화]'} ${SKILLS[id].name}\n${isEvolved(p,id)?'횟수 무제한':'골드 '+c.gold.toLocaleString()+' / 강화석 '+c.stone}`);}
        form.button('뒤로');
        const picked=await showForm(form,p);if(!picked||picked.canceled||picked.selection==null||picked.selection>=ids.length)continue;
        const id=ids[picked.selection];
        if(isEvolved(p,id)){p.sendMessage('§d이미 진화한 스킬입니다.');continue;}
        const c=evolveCost(id),yes=await showForm(new UI.MessageFormData().title('스킬 진화 확인').body(`${SKILLS[id].name}을(를) 횟수 무제한으로 진화시킵니다.\n골드 ${c.gold.toLocaleString()} / 강화석 ${c.stone} 소비\n(진화 슬롯 ${state.evolved.length+1}/${EVOLVE_MAX})`).button1('취소').button2('진화'),p);
        if(yes&&!yes.canceled&&yes.selection===1){const r=evolveChameleonSkill(p,id);p.sendMessage((r.ok?'':'§c')+r.message);if(r.ok){try{p.dimension.playSound('random.levelup',p.location,{volume:.8,pitch:1.2});}catch{}refreshHud(p,true);}}
        continue;
      }
      const group=CHAMELEON_GROUPS[response.selection-5];
      const form=new UI.ActionFormData().title(group.name).body('미습득 스킬을 선택하면 표시된 레벨 SP를 소비해 배웁니다.');
      for(const id of group.ids){const rule=learningRule(id);form.button(`${learned.has(id)?'§a[습득]':'§e['+rule.cost+' SP]'} ${SKILLS[id].name}\n${rule.uses===null?'횟수 제한 없음':isEvolved(p,id)?'§d진화 · 횟수 무제한':'남은 '+remainingSkillUses(p,id)+'회 / 다이아당 +'+rule.diamondUses+'회'}`);}
      form.button('뒤로');const pick=await showForm(form,p);if(pick&&!pick.canceled&&pick.selection<group.ids.length){const r=learnChameleonSkill(p,group.ids[pick.selection]);p.sendMessage(r.message);}
    }
  }catch(error){try{p.sendMessage('§c'+String(error));}catch{}}
  finally{menuOpen.delete(p.id);}
}
