import {world,system} from '@minecraft/server';
import {MessageFormData} from '@minecraft/server-ui';
import {getJobId,getSkills,getMana,setMana,maxManaOf,getProgress} from './playerData.js';
import {getStats,STAT_BASE,resetAllocatedStats,applyVitality} from './stats.js';
import {resetToApprentice} from './advance.js';
import {CHAMELEON_KEY,readChameleonProgress,saveChameleonProgress,learningRule,CHAMELEON_ALLOWED} from './chameleonProgress.js';
import {showForm} from './skillMenu.js';
import {refreshHud} from './hud.js';
import {noteChameleonWaiver} from './newTrials.js';
export const STAT_RESET_ITEM='rpg:stat_reset_scroll',JOB_WAIVER_ITEM='rpg:job_waiver';
const busy=new Set(),usedTick=new Map(),allowed=new Set(CHAMELEON_ALLOWED);
const keys=['rpg:weapon_binding','rpg:mask_job','rpg:stat_values','rpg:job','rpg:skills','rpg:disabled_skills','rpg:skill_index','rpg:mana','rpg:wings_active','rpg:renounced_holy',CHAMELEON_KEY];
function unavailable(p,id){
 if(!p?.isValid||!['survival','adventure'].includes(String(p.getGameMode?.()).toLowerCase()))return '살아 있는 플레이 상태에서 사용하세요.';
 if((p.getComponent('minecraft:health')?.currentValue??0)<=0)return '사망 중에는 사용할 수 없습니다.';
 if(id===STAT_RESET_ITEM&&Object.values(getStats(p)).every(n=>n===STAT_BASE))return '초기화할 배분 스탯이 없습니다.';
 if(id===JOB_WAIVER_ITEM&&(!getJobId(p)||getJobId(p)==='apprentice'))return '이미 견습입니다.';
 return undefined;
}
export function applyProgressionItem(p,id){
 if(![STAT_RESET_ITEM,JOB_WAIVER_ITEM].includes(id))return {ok:false,reason:'지원하지 않는 아이템입니다.'};
 const reason=unavailable(p,id);if(reason)return {ok:false,reason};
 const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return {ok:false,reason:'인벤토리를 사용할 수 없습니다.'};
 let slot=-1;for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId===id){slot=i;break;}
 if(slot<0)return {ok:false,reason:'사용할 아이템이 없습니다.'};
 const before=Array.from({length:inv.size},(_,i)=>inv.getItem(i)?.clone()),props=new Map(keys.map(k=>[k,p.getDynamicProperty(k)]));
 try{
  const item=inv.getItem(slot).clone();if(item.amount<=1)inv.setItem(slot,undefined);else{item.amount--;inv.setItem(slot,item);}
  let refund=0;
  if(id===STAT_RESET_ITEM)refund=resetAllocatedStats(p);
  else{
   if(['cleric','angel','michael'].includes(getJobId(p))&&(getProgress(p).healed_deaths??0)>=5)p.setDynamicProperty('rpg:renounced_holy',true);
   if(getJobId(p)==='chameleon'){
    const s=readChameleonProgress(p),learned=[...new Set([...s.learned,...getSkills(p).filter(skill=>allowed.has(skill))])];
    refund=learned.reduce((sum,skill)=>sum+learningRule(skill).cost,0);if(!Number.isSafeInteger(s.refundedSp+refund))throw Error('SP 범위 초과');
    s.refundedSp+=refund;s.learned=[];s.evolved=[];saveChameleonProgress(p,s);
   }
   const mana=getMana(p);resetToApprentice(p);setMana(p,Math.min(mana,maxManaOf(p)));p.setDynamicProperty('rpg:wings_active',false);noteChameleonWaiver(p);
  }
  refreshHud(p,true);return {ok:true,refund};
 }catch(error){
  for(const [k,value]of props)try{p.setDynamicProperty(k,value);}catch{}
  for(let i=0;i<before.length;i++)try{inv.setItem(i,before[i]);}catch{}
  applyVitality(p);return {ok:false,reason:'저장 실패로 아이템과 캐릭터 상태를 복구했습니다: '+String(error)};
 }
}
export async function useProgressionItem(p,id){
 if(!p||busy.has(p.id)||(usedTick.get(p.id)??-100)>system.currentTick-3)return;
 if(![STAT_RESET_ITEM,JOB_WAIVER_ITEM].includes(id))return;
 busy.add(p.id);usedTick.set(p.id,system.currentTick);
 try{
  const reason=unavailable(p,id);if(reason){p.sendMessage('§e'+reason);return;}
  const title=id===STAT_RESET_ITEM?'스탯 초기화 주문서':'전직 포기각서';
  const body=id===STAT_RESET_ITEM?'배분한 근력·마력·체력·지능을 기본 5로 되돌리고 해당 SP를 돌려받습니다.\n레벨·직업·배운 기술은 유지합니다. 아이템 1개를 소비할까요?':'직업과 직업 기술을 포기하고 견습으로 돌아갑니다. 직업 무기는 회수됩니다.\n레벨·스탯·재화·갑옷·룬·전직 진행도와 쿨타임은 유지합니다.\n카멜레온 차용 기술은 분해하고 같은 등급 SP를 환급하며 남은 횟수 기록은 유지합니다.\n성직 계열에서 사망 목격 5회를 채운 경우 성직 포기 사실을 저장해 타락천사 전직을 이어갈 수 있습니다.\n월드 최초 해커 기록은 초기화되지 않습니다.\n아이템 1개를 소비할까요?';
  const reply=await showForm(new MessageFormData().title(title).body(body).button1('취소').button2('사용'),p);
  if(!reply||reply.canceled||reply.selection!==1)return;
  const r=applyProgressionItem(p,id);p.sendMessage(r.ok?'§a'+title+' 사용 완료'+(r.refund?' · '+r.refund+' SP 환급':''):'§e'+r.reason);
 }finally{busy.delete(p.id);}
}
let registered=false;
export function registerProgressionItems(){
 if(registered)return;registered=true;
 world.afterEvents.itemUse.subscribe(ev=>{if([STAT_RESET_ITEM,JOB_WAIVER_ITEM].includes(ev.itemStack?.typeId))system.run(()=>useProgressionItem(ev.source,ev.itemStack.typeId));});
 world.afterEvents.playerLeave.subscribe(ev=>{busy.delete(ev.playerId);usedTick.delete(ev.playerId);});
}
