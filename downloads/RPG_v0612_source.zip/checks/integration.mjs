import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0612');
const bp=path.join(root,'RPG_BP_v0612/scripts');
const signals=new Map();function signal(key){if(!signals.has(key))signals.set(key,{callbacks:[],subscribe(fn){this.callbacks.push(fn);},fire(e){for(const fn of this.callbacks)fn(e);}});return signals.get(key);}
const events=new Proxy({},{get:(o,k)=>signal(k)});let time=1000;
const world={afterEvents:events,beforeEvents:{},getTimeOfDay:()=>time,getAllPlayers:()=>[],getDay:()=>1,getDynamicProperty:()=>undefined};
const timers=[];const system={currentTick:10,beforeEvents:events,afterEvents:events,run:fn=>{timers.push(fn);return timers.length;},runTimeout:fn=>{timers.push(fn);return timers.length;},runInterval:()=>1,clearRun:()=>{}};
class ItemStack{
 constructor(id,amount=1){this.typeId=id;this.amount=amount;this.props=new Map();this.lore=[];this.lockMode='none';this.keepOnDeath=false;this.durability={damage:0,maxDurability:1600};}
 clone(){const n=new ItemStack(this.typeId,this.amount);n.props=new Map(this.props);n.lore=[...this.lore];n.nameTag=this.nameTag;n.lockMode=this.lockMode;n.keepOnDeath=this.keepOnDeath;n.durability={...this.durability};return n;}
 getDynamicProperty(k){return this.props.get(k);}setDynamicProperty(k,v){if(v===undefined)this.props.delete(k);else this.props.set(k,v);}getDynamicPropertyIds(){return [...this.props.keys()];}getLore(){return this.lore;}setLore(v){this.lore=v;}getComponent(id){if(id==='minecraft:durability')return this.durability;if(id==='minecraft:enchantable')return {getEnchantments:()=>[]};}
}
class Form{title(){return this;}body(){return this;}button(){return this;}button1(){return this;}button2(){return this;}show(){return Promise.resolve({canceled:true});}}
const server={world,system,ItemStack,ItemLockMode:{slot:'slot',none:'none'},EquipmentSlot:{Mainhand:'Mainhand',Offhand:'Offhand',Head:'Head',Chest:'Chest',Legs:'Legs',Feet:'Feet'},EntityDamageCause:{override:'override',entityAttack:'entityAttack'},CustomCommandStatus:{Success:0,Failure:1},CommandPermissionLevel:{Any:0,GameDirectors:1},CustomCommandParamType:{String:0},BlockTypes:{get:id=>({id})}};
const ui={ActionFormData:Form,MessageFormData:Form,ModalFormData:Form};
const context=vm.createContext({console});const modules=new Map(),externalNames=new Map();
function discover(file){file=path.resolve(file);if(modules.has(file))return;const source=fs.readFileSync(file,'utf8');const m=new vm.SourceTextModule(source,{context,identifier:file});modules.set(file,m);
 for(const hit of source.matchAll(/import\s+(?:\{([^}]+)\}|\*\s+as\s+\w+)\s*from\s*['"]([^'"]+)['"]/g)){
  const spec=hit[2];if(spec.startsWith('.'))discover(path.resolve(path.dirname(file),spec));else{const names=externalNames.get(spec)??new Set();for(const n of (hit[1]??'').split(',').filter(Boolean))names.add(n.trim().split(/\s+as\s+/)[0]);externalNames.set(spec,names);}
 }
}
discover(path.join(bp,'gameplayEntry.js'));discover(path.join(bp,'commandBootstrap.js'));
for(const [spec,names]of externalNames){const values=spec==='@minecraft/server'?server:ui;for(const n of Object.keys(values))names.add(n);const m=new vm.SyntheticModule([...names],function(){for(const n of names)this.setExport(n,values[n]??{});},{context,identifier:spec});modules.set(spec,m);}
const linker=(spec,parent)=>modules.get(spec.startsWith('.')?path.resolve(path.dirname(parent.identifier),spec):spec);
for(const m of modules.values())if(m.status==='unlinked')await m.link(linker);
for(const entry of ['gameplayEntry.js','commandBootstrap.js'])await modules.get(path.join(bp,entry)).evaluate();
const mod=file=>modules.get(path.join(bp,file)).namespace;
console.log('Complete active gameplay and command module graph linked/evaluated');
function player(job='swordsman'){
 const props=new Map([['rpg:job',job]]),items=Array(12),messages=[],tags=new Set();
 const inv={size:12,getItem:i=>items[i]?.clone(),setItem:(i,v)=>{items[i]=v?.clone();},addItem:item=>{const i=items.findIndex(x=>!x);if(i<0)return item;items[i]=item.clone();}};
 const health={currentValue:50,effectiveMax:100,setCurrentValue(v){const old=this.currentValue;this.currentValue=v;signal('entityHealthChanged').fire({entity:p,oldValue:old,newValue:v});}};
 const dim={id:'minecraft:overworld',getWeather:()=> 'Clear',getTopmostBlock:()=>({location:{y:63}}),spawnItem:()=>{throw Error('unexpected item drop');},playSound:()=>{}};
 const p={id:'player',name:'tester',typeId:'minecraft:player',isValid:true,selectedSlotIndex:0,location:{x:0,y:64,z:0},dimension:dim,onScreenDisplay:{setTitle:()=>{},setActionBar:()=>{}},getHeadLocation:()=>({x:0,y:65.6,z:0}),getGameMode:()=> 'survival',getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>{if(v===undefined)props.delete(k);else props.set(k,v);},getDynamicPropertyIds:()=>[...props.keys()],getComponent:id=>id==='minecraft:inventory'?{container:inv}:id==='minecraft:health'?health:id==='minecraft:equippable'?{getEquipment:()=>inv.getItem(p.selectedSlotIndex),setEquipment:(slot,item)=>{inv.setItem(p.selectedSlotIndex,item);return true;}}:undefined,hasTag:t=>tags.has(t),addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),getTags:()=>[...tags],sendMessage:s=>messages.push(s),getEffect:()=>undefined};
 return {p,props,items,inv,health,messages};
}
const races=mod('core/races.js'),data=mod('core/playerData.js'),jobs=mod('data/jobs.js').JOBS,binding=mod('core/weaponBinding.js'),advance=mod('core/advance.js');
{
 const {p,inv}=player();assert.equal(races.raceOf(p),'human');inv.setItem(0,new ItemStack('rpg:stone_mask',2));assert.equal(races.useStoneMask(p).ok,true);assert.equal(inv.getItem(0).amount,1);assert.equal(races.raceOf(p),'vampire');assert.equal(races.useStoneMask(p).ok,false);assert.equal(inv.getItem(0).amount,1);
 assert.equal(races.sunDamageMultiplier(p),1.5);p.dimension.getTopmostBlock=()=>({location:{y:70}});assert.equal(races.sunDamageMultiplier(p),1);p.dimension.getTopmostBlock=()=>({location:{y:63}});time=13000;assert.equal(races.sunDamageMultiplier(p),1);time=1000;
 data.setJobId(p,'mage');assert.equal(races.raceOf(p),'human');data.setJobId(p,'blood_mage');assert.equal(races.raceOf(p),'vampire');data.setJobId(p,'revenant');assert.equal(races.raceOf(p),'undead');
}
console.log('Races: mask consumption, redundant use, daylight/shade/night, job resets passed');
{
 const {p,inv}=player();inv.setItem(0,new ItemStack(jobs.swordsman.weapon));const w=new ItemStack('rpg:common_redmoon_blade');w.setDynamicProperty('rpg:weapon_upgrade',5);w.setDynamicProperty('rpg:rarity','epic');w.nameTag='chosen';w.durability.damage=123;inv.setItem(4,w);
 assert.equal(binding.bindCommonWeapon(p,4).ok,true);assert.equal(inv.getItem(0).nameTag,'chosen');assert.equal(inv.getItem(4).typeId,jobs.swordsman.weapon);const uid=inv.getItem(0).getDynamicProperty(binding.WEAPON_UID);
 advance.applyAdvance(p,jobs.sword_saint);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);assert.equal(inv.getItem(0).durability.damage,123);assert.equal(mod('core/context.js').getContext(p).substitute,true);assert.equal(mod('core/util.js').skillItemId(p),jobs.sword_saint.weapon);
 advance.applyAdvance(p,jobs.mage);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);assert.equal(mod('core/context.js').getContext(p).job.id,'mage');
 const upgraded=mod('core/gearState.js').setGearLevel(inv.getItem(0),'weapon',6);inv.setItem(0,upgraded);advance.ensureWeapon(p);assert.equal(inv.getItem(0).getDynamicProperty('rpg:weapon_upgrade'),6);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);
 const slot1=inv.getItem(0);inv.setItem(0,undefined);inv.setItem(8,slot1);advance.ensureWeapon(p);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);assert.equal(inv.getItem(8),undefined);
 inv.setItem(0,undefined);advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,jobs.mage.weapon);assert.equal(binding.weaponBinding(p),undefined);
}
console.log('Weapon binding: metadata/upgrade preservation, both advancements, job switch, moved-item recovery, break fallback passed');
{
 const {p,inv}=player();inv.setItem(0,new ItemStack(jobs.swordsman.weapon));inv.setItem(3,new ItemStack('rpg:common_redmoon_blade'));binding.bindCommonWeapon(p,3);data.setJobId(p,'the_world');data.setSkills(p,jobs.the_world.skills);assert.equal(mod('core/context.js').getContext(p).job.id,'the_world');
 binding.releaseWeaponBinding(p);advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,jobs.the_world.weapon);assert.equal(Array.from({length:inv.size},(_,i)=>inv.getItem(i)).filter(i=>i?.typeId==='rpg:common_redmoon_blade').length,1);
}
console.log('Weapon release preserves exactly one original common weapon');
{
 const {p,health}=player('the_world');const target={id:'enemy',typeId:'minecraft:zombie'};const life=mod('core/lifesteal.js');assert.equal(life.healLifesteal(p,target,20),2);health.currentValue=99;assert.equal(life.healLifesteal(p,target,20),1);data.setJobId(p,'swordsman');assert.equal(life.healLifesteal(p,target,20),0);
 const amounts=mod('core/damageAmounts.js');amounts.noteHealthChange({entity:target,oldValue:3,newValue:0});assert.equal(amounts.actualHurtAmount({hurtEntity:target,damage:100}),3);
}
console.log('Vampire 10% actual-damage lifesteal and overheal/overkill cap passed');
{
 const {p,messages}=player('mage');const trial=mod('core/jobTrials.js');for(let i=0;i<55;i++)trial.recordJobTrialKill(p,{typeId:'minecraft:stray'});assert.equal(messages.length,6);assert.equal(messages[0],'§r§l§b(???/50)');assert.equal(messages[5],'§r§l§b(50/50)');messages.length=0;for(let i=0;i<55;i++)trial.recordJobTrialKill(p,{typeId:'minecraft:blaze'});assert.equal(messages.length,6);assert.equal(messages[5],'§r§l§6(50/50)');
}
console.log('Stray/Blaze counters: exactly 1/10/20/30/40/50 announcements, colors and completion passed');
{
 const {p,inv}=player();mod('core/wallet.js').setWallet(p,{gold:10000000,stone:100000,dust:1000});inv.setItem(0,new ItemStack(jobs.swordsman.weapon));inv.setItem(5,new ItemStack('rpg:common_redmoon_blade'));binding.bindCommonWeapon(p,5);
 const uid=inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),upgrade=mod('core/upgrades.js');let quote=upgrade.enhancementQuote(p,'weapon','Mainhand');let result=upgrade.enhanceEquipped(p,'weapon','Mainhand',quote.fingerprint,{random:()=>0});assert.equal(result.ok,true);assert.equal(result.outcome,'success');assert.equal(inv.getItem(0).getDynamicProperty('rpg:weapon_upgrade'),1);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);
 inv.setItem(0,mod('core/gearState.js').setGearLevel(inv.getItem(0),'weapon',9));quote=upgrade.enhancementQuote(p,'weapon','Mainhand');result=upgrade.enhanceEquipped(p,'weapon','Mainhand',quote.fingerprint,{random:()=>.999});assert.equal(result.outcome,'destroy');advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,jobs.swordsman.weapon);assert.equal(binding.weaponBinding(p),undefined);
}
console.log('Actual upgrade transaction: success stays in slot 1, destruction restores class item passed');
{
 const {p,health}=player('cleric');health.currentValue=50;
 const target={id:'mob',typeId:'minecraft:zombie',isValid:true,location:{x:0,y:64,z:1},getTags:()=>[],getComponent:id=>id==='minecraft:health'?{currentValue:100}:undefined,applyDamage(amount){this.damage=amount;return true;}};
 const holy=mod('skills/holy.js');assert.equal(holy.holyMonsterDamage(p,target,20),true);assert.equal(target.damage,60);assert.equal(holy.holyMonsterDamage(p,p,20),false);
 const allyHeal=mod('core/holyRecovery.js').healHolyAlly(p,p,20);assert.equal(allyHeal,20);assert.equal(health.currentValue,70);
}
console.log('Holy healing: monster takes exactly healing x3, allied healing remains unchanged');
function filter(f,monster,sun){if(f.all_of)return f.all_of.every(x=>filter(x,monster,sun));if(f.any_of)return f.any_of.some(x=>filter(x,monster,sun));const val=f.test==='is_family'?monster:sun;return f.operator==='!='?!val:val;}
{
 const json=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0612/entities/player.json'),'utf8'))['minecraft:entity'];
 for(const [m,s,expected]of [[true,false,.7],[true,true,1.05],[false,true,1.5],[false,false,1]]){
  const hits=json.components['minecraft:damage_sensor'].triggers.filter(t=>filter(t.on_damage.filters,m,s));assert.equal(hits.length,1);assert.equal(hits[0].damage_multiplier,expected);
  for(const [id,g]of Object.entries(json.component_groups))if(id.startsWith('rpg:ward_defense_')){
   const hits=g['minecraft:damage_sensor'].triggers.filter(t=>filter(t.on_damage.filters,m,s));assert.equal(hits.length,1);const index=Number(id.split('_').at(-1));assert.ok(Math.abs(hits[0].damage_multiplier-(1-index/10*.0035)*expected)<1e-7);
  }
 }
 for(const [id,outer,center]of [['stone_mask_fragment','minecraft:stone','minecraft:gold_block'],['stone_mask','rpg:stone_mask_fragment','minecraft:netherite_ingot']]){
  const recipe=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0612/recipes/'+id+'.json'),'utf8'))['minecraft:recipe_shaped'];assert.deepEqual(recipe.pattern,['FFF','FCF','FFF']);assert.equal(recipe.key.F.item,outer);assert.equal(recipe.key.C.item,center);assert.equal(recipe.result.count,1);
 }
}
console.log('Damage sensor matrices: monster x0.7, vampire sun x1.5, existing ward multipliers; both exact recipes passed');
const componentHandlers=new Map(),commandDefs=new Map();
signal('startup').fire({itemComponentRegistry:{registerCustomComponent:(id,handler)=>componentHandlers.set(id,handler)},customCommandRegistry:{registerCommand:(d,fn)=>commandDefs.set(d.name,{d,fn})}});
assert.ok(componentHandlers.has('rpg:stone_mask'));assert.ok(componentHandlers.has('rpg:bound_common'));assert.ok(commandDefs.has('rpg:weapon'));assert.equal(commandDefs.get('rpg:weapon').d.permissionLevel,0);
console.log('Startup registration: mask/common item components and public /rpg:weapon passed');
{
 const {p,inv}=player('apprentice');inv.setItem(0,new ItemStack('rpg:apprentice_sword'));inv.setItem(4,new ItemStack('rpg:common_redmoon_blade'));binding.bindCommonWeapon(p,4);assert.equal(mod('core/context.js').getContext(p).substitute,true);inv.setItem(0,undefined);advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,'rpg:apprentice_sword');
}
console.log('Apprentice common-weapon break restores the selected starter line');
{
 const {p,inv}=player();for(let i=0;i<inv.size;i++)inv.setItem(i,new ItemStack(i===0?jobs.swordsman.weapon:i===4?'rpg:common_redmoon_blade':'minecraft:stone'));assert.equal(binding.bindCommonWeapon(p,4).ok,true);assert.equal(inv.getItem(4).typeId,jobs.swordsman.weapon);assert.equal(inv.getItem(0).typeId,'rpg:common_redmoon_blade');
 const uid=inv.getItem(0).getDynamicProperty(binding.WEAPON_UID);const props=p.getDynamicProperty(binding.BINDING_KEY);p.setDynamicProperty(binding.BINDING_KEY,props);advance.ensureWeapon(p);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);
 const before=inv.getItem(0);const result=binding.bindCommonWeapon(p,6);assert.equal(result.ok,false);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),before.getDynamicProperty(binding.WEAPON_UID));
}
console.log('Full-inventory replacement, persisted binding reuse and invalid selection preserve items');
{
 const {p,health}=player('the_world');const life=mod('core/lifesteal.js');life.registerLifesteal();
 const target={id:'lethal_enemy',typeId:'minecraft:zombie',getComponent:id=>id==='minecraft:health'?{currentValue:0,effectiveMax:20}:undefined};
 signal('entityHealthChanged').fire({entity:target,oldValue:3,newValue:0});signal('entityHurt').fire({hurtEntity:target,damage:100,damageSource:{cause:'entityAttack',damagingEntity:p}});
 assert.ok(Math.abs(health.currentValue-50.3)<1e-8);
}
console.log('Native hurt-event path: lethal overkill only heals 10% of remaining enemy HP');
