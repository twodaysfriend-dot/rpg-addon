# RPG v0.6.77 · 블라디미르 파티클과 피의 낫

- **블러드 배리어**에 카메라를 향하는 붉은 방어막, 가장자리 불꽃, 방어 순간의 섬광을 추가했습니다. 방어막 종료 시 붉은 충격파가 퍼집니다.
- **혈액 난사**는 바라보는 방향 기준 전방 **150°**로 파편 **24발**을 한꺼번에 발사합니다. 파편은 무작위로 위아래에도 퍼지며 밝은 붉은 궤적을 남깁니다. 마나 30, 발당 기본 마법 피해 4, 대상당 최대 10발입니다.
- **피의 낫**은 1인칭·3인칭에서 손에 들었을 때 기존의 **2배** 크기로 표시합니다. 인벤토리 아이콘은 기존 텍스처를 사용합니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.77로 활성화하고 월드를 다시 여세요. 모의 전투에서 파티클 생성, 시선에 따른 탄도, 공속 룬 가속, 벽 충돌, 피해 및 적중 상한을 확인했습니다. 실제 모바일 Bedrock 화면에서의 렌더링은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0677
```
