import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const root=process.argv[2]??'.';
const bp=root+'/RPG_BP_v0638';
const context=vm.createContext({console});
const callbacks=new Map(),ticks=new Map(),timeouts=[];
let next=0,entities=[],wall=false,locked,p;
const dimension={id:'overworld',getEntities:()=>entities};
const world={getAllPlayers:()=>[p],beforeEvents:{entityHurt:{subscribe:fn=>callbacks.set('beforeHurt',fn)}},
 afterEvents:new Proxy({},{get:(_t,key)=>({subscribe:fn=>callbacks.set(key,fn)})})};
const system={currentTick:0,run:()=>{},runInterval:fn=>{const id=++next;ticks.set(id,fn);return id;},
 clearRun:id=>ticks.delete(id),runTimeout:(fn,delay)=>timeouts.push({at:system.currentTick+delay,fn})};
const shots=[],particles=[],moves=[],events=[];
function actor(id,x,z,max=200,typeId='minecraft:zombie'){
 const tags=new Set(),props=new Map(),effects=new Map();
 const hp={currentValue:max,effectiveMax:max,setCurrentValue(n){this.currentValue=n;}};
 return {id,typeId,location:{x,y:0,z},dimension,hp,isValid:true,addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),hasTag:t=>tags.has(t),
  getViewDirection:()=>({x:0,y:0,z:1}),getComponent:()=>hp,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),
  triggerEvent:id=>events.push(id),getEffect:id=>effects.get(id),addEffect:(id,duration,o)=>effects.set(id,{duration,...o}),removeEffect:id=>effects.delete(id),
  teleport(at){moves.push(id);this.location={...at};},clearVelocity(){}};
}
const dist3=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
const bindings={world,system,getJobId:e=>e.job,isJailed:()=>false,isTimeFrozen:()=>false,
 areAllies:()=>false,ccTicks:(e,t)=>e.boss?t/2:t,dist3,healthAlive:e=>e.hp.currentValue>0,
 getTargets:(player,at,r,bodyOffset=0)=>entities.filter(e=>e!==player&&e.hp.currentValue>0&&dist3(e.location,{...at,y:at.y-bodyOffset})<=r),
 firstTargetInView:()=>locked,clearBlockPath:(_d,a,b)=>!wall||Math.max(a.z,b.z)<2,isSolidAt:(_d,at)=>wall&&at.z>=2,
 headPos:e=>({...e.location,y:e.location.y+0.9}),norm3:v=>{const n=Math.hypot(v.x,v.y,v.z)||1;return {x:v.x/n,y:v.y/n,z:v.z/n};},
 hurt:(e,_p,n,type)=>{shots.push({id:e.id,n,type});e.hp.setCurrentValue(Math.max(0,e.hp.currentValue-n));return true;},
 knockback:e=>moves.push(e.id),particle:(_d,id,pos)=>particles.push({id,pos}),sound:()=>{},notify:()=>{}};
const skills=await load('data/skills.js');
const blood=await load('skills/bloodedge.js');
async function load(path){
 const module=new vm.SourceTextModule(fs.readFileSync(bp+'/scripts/'+path,'utf8'),{context});
 await module.link(spec=>spec.endsWith('/bloodedgeState.js')?
  new vm.SourceTextModule(fs.readFileSync(bp+'/scripts/core/bloodedgeState.js','utf8'),{context}):
  new vm.SyntheticModule(Object.keys(bindings),function(){
   for(const [key,value] of Object.entries(bindings))this.setExport(key,value);
  },{context}));
 await module.evaluate();
 return module.namespace;
}
const {SKILLS}=skills;
let p2;
p=actor('bloodedge',0,0,200,'minecraft:player');p.job='bloodedge';
blood.registerBloodedge();
const front=actor('front',0,8),behind=actor('behind',0,-4),outside=actor('outside',0,14.1);
entities=[p,front,behind,outside];
const cast=id=>blood.RUNNERS['bloodedge_'+id](p,{},SKILLS['bloodedge_'+id]);
function advance(n){
 for(let i=0;i<n;i++){
  system.currentTick++;
  for(let j=timeouts.length-1;j>=0;j--)if(timeouts[j].at<=system.currentTick)timeouts.splice(j,1)[0].fn();
  for(const [,fn] of ticks)fn();
 }
}
assert.equal(cast('shield'),true);
assert.equal(p.hasTag('rpg_be_guard_0'),true);
assert.equal(front.hasTag('rpg_be_front_0'),true);
assert.equal(behind.hasTag('rpg_be_front_0'),false);
for(const [attacker,cancel] of [[front,true],[behind,false]]){
 const ev={hurtEntity:p,damageSource:{damagingEntity:attacker},cancel:false};
 callbacks.get('beforeHurt')(ev);assert.equal(ev.cancel,cancel);
}
p2=actor('second',0,10,100,'minecraft:player');p2.job='bloodedge';entities.push(p2);
assert.equal(blood.RUNNERS.bloodedge_shield(p2,{},SKILLS.bloodedge_shield),true);
assert.equal(front.hasTag('rpg_be_front_1'),false,'the same attacker is behind the other guard');
callbacks.get('playerLeave')({playerId:p2.id});entities.pop();
advance(99);assert.equal(shots.length,0);
advance(1);assert.deepEqual(shots.map(s=>s.id),['front','behind']);
assert.deepEqual(moves,['front','behind']);
assert.equal(front.hasTag('rpg_be_front_0'),false);
shots.length=0;moves.length=0;

const projectileTarget=actor('dummy',0,5,600);
entities=[p,projectileTarget];
assert.equal(cast('volley'),true);advance(40);
assert.equal(shots.length,6);assert.ok(shots.every(s=>s.n===6&&s.type==='magic'));
shots.length=0;
assert.equal(cast('lance'),true);advance(19);assert.equal(shots.length,0);
advance(10);assert.deepEqual(shots,[{id:'dummy',n:45,type:'magic'}]);
shots.length=0;
wall=true;cast('volley');advance(40);assert.equal(shots.length,0);
wall=false;

locked=projectileTarget;assert.equal(cast('bind'),true);
assert.equal(SKILLS.bloodedge_bind.cooldown,300);
projectileTarget.location.x=3;advance(1);assert.equal(projectileTarget.location.x,0);
advance(59);projectileTarget.location.x=3;advance(1);assert.equal(projectileTarget.location.x,3);

const low=actor('low',0,2,6),moved=actor('moved',17,0),edge=actor('edge',18.01,0);
entities=[p,low,moved,edge];
p.hp.currentValue=30;
assert.equal(cast('pool'),true);assert.equal(p.hasTag('rpg:bloodedge_pool'),true);
assert.equal(events.at(-1),'rpg:bloodedge_pool_on');
assert.equal(cast('volley'),false);
advance(20);assert.deepEqual(shots,[{id:'low',n:10,type:'fixed'}]);
p.location.x=12;advance(179);assert.equal(p.hp.currentValue,30);
advance(1);
assert.equal(shots.filter(s=>s.id==='moved').length,9);
assert.equal(shots.filter(s=>s.id==='edge').length,0);
assert.equal(p.hp.currentValue,78,'six actual HP from the first kill plus ninety actual HP, then heal half');
assert.equal(p.hasTag('rpg:bloodedge_pool'),false);
assert.equal(events.at(-1),'rpg:bloodedge_pool_off');
assert.ok(particles.some(s=>s.id==='rpg:bloodedge_pool'&&s.pos.x===12));
assert.equal(p.getEffect('invisibility'),undefined);
const def=JSON.parse(fs.readFileSync(bp+'/entities/player.json'))['minecraft:entity'];
assert.ok(def.component_groups['rpg:bloodedge_untargetable']['minecraft:cannot_be_attacked']);
assert.ok(def.component_groups['rpg:bloodedge_untargetable']['minecraft:is_hidden_when_invisible']);
for(const c of [def.components,...Object.values(def.component_groups)]){
 const sensor=c['minecraft:damage_sensor'];if(!sensor)continue;
 const guard=sensor.triggers[0];
 assert.equal(guard.deals_damage,false);
 assert.equal(guard.on_damage.filters.any_of.length,16);
}
console.log('Bloodedge: frontal guard, independent slots, timed burst and knockback; six shots, charged shot and walls; bind expiry; moving pool, capped actual damage and heal, native untargetable group');
