import {world,system} from '@minecraft/server';
import {areAllies} from '../core/social.js';
import {getJobId} from '../core/playerData.js';
import {isJailed} from '../core/prison.js';
import {isTimeFrozen} from '../core/timeStopDamage.js';
import {ccTicks} from '../core/crowdControl.js';
import {BLOODEDGE_POOL_TAG,blocksBloodedgeDamage,isBloodedgePool,isShieldFront,shieldSessions} from '../core/bloodedgeState.js';
import {clearBlockPath,dist3,firstTargetInView,getTargets,headPos,healthAlive,hurt,isSolidAt,knockback,norm3,particle,sound} from '../core/util.js';
import {notify} from '../core/hud.js';

const SPARK='rpg:blood_spark',BURST='rpg:blood_burst',SIGIL='rpg:blood_sigil';
const SLOTS=16;
const POOL_INVISIBILITY='rpg:bloodedge_pool_invisibility';
const guardTag=slot=>'rpg_be_guard_'+slot;
const frontTag=slot=>'rpg_be_front_'+slot;
const pools=new Map(),pins=new Map();
let registered=false;

const offset=(p,dy)=>({...p,y:p.y+dy});
function active(p,dimension) {
  try {
    return p.isValid!==false && p.dimension.id===dimension && healthAlive(p) &&
      getJobId(p)==='bloodedge' && !isJailed(p);
  } catch { return false; }
}
function usable(p,dimension) { return active(p,dimension) && !isTimeFrozen(p); }
function ring(dim,center,radius,count,fx=SIGIL) {
  for(let i=0;i<count;i++){
    const a=i*Math.PI*2/count;
    particle(dim,fx,{x:center.x+Math.cos(a)*radius,y:center.y,z:center.z+Math.sin(a)*radius});
  }
}
function enemies(p,loc,radius) {
  return getTargets(p,loc,radius).filter(target=>{
    if(dist3(loc,target.location)>radius)return false;
    const mode=target.getGameMode?.();
    return mode!=='creative' && mode!=='spectator';
  });
}

function clearShield(s) {
  shieldSessions.delete(s.player.id);
  try { s.player.removeTag(guardTag(s.slot)); } catch {}
  for(const entity of s.marked.values())try{entity.removeTag(frontTag(s.slot));}catch{}
}
function markShieldFront(s){
  const p=s.player,tag=frontTag(s.slot),next=new Map();
  for(const entity of p.dimension.getEntities({location:p.location,maxDistance:48,excludeTypes:['minecraft:item','minecraft:xp_orb']})){
    if(entity.id===p.id)continue;
    try{
      if(!isShieldFront(p,entity)){
        if(entity.hasTag(tag))entity.removeTag(tag);
        continue;
      }
      if(!entity.hasTag(tag))entity.addTag(tag);
      next.set(entity.id,entity);
    }catch{}
  }
  for(const [id,entity] of s.marked)if(!next.has(id))try{entity.removeTag(tag);}catch{}
  s.marked=next;
}
function shield(p,_job,def) {
  if(shieldSessions.has(p.id) || pools.has(p.id))return false;
  const taken=new Set(Array.from(shieldSessions.values(),state=>state.slot));
  const slot=Array.from({length:SLOTS},(_,index)=>index).find(index=>!taken.has(index));
  if(slot===undefined){notify(p,'§7지금은 핏빛 방패를 펼칠 수 없습니다.');return false;}
  const state={player:p,def,slot,dimension:p.dimension.id,until:system.currentTick+def.duration,marked:new Map()};
  try{
    markShieldFront(state);
    p.addTag(guardTag(slot));
  }catch{clearShield(state);return false;}
  shieldSessions.set(p.id,state);
  notify(p,'§c핏빛 방패 · 5초');
  return true;
}
function endShield(s,burst) {
  clearShield(s);
  if(!burst)return;
  const p=s.player,origin=p.location;
  ring(p.dimension,offset(origin,0.15),s.def.radius,36,BURST);
  sound(p.dimension,'random.explode',origin,{volume:0.75,pitch:0.6});
  for(const target of enemies(p,origin,s.def.radius)){
    if(!clearBlockPath(p.dimension,offset(origin,0.9),offset(target.location,0.9)))continue;
    if(!hurt(target,p,s.def.damage,'magic',{ignoreInvulnerability:true}))continue;
    knockback(target,target.location.x-origin.x,target.location.z-origin.z,s.def.knockback,0.35);
  }
}

function projectile(p,def,large) {
  const dim=p.dimension,direction=p.getViewDirection();
  let at=headPos(p),travel=0;
  const timer=system.runInterval(()=>{
    if(!usable(p,dim.id) || pools.has(p.id)){system.clearRun(timer);return;}
    for(let sub=0;sub<3;sub++){
      const step=Math.min(def.speed/3,def.range-travel);
      if(step<=0){system.clearRun(timer);return;}
      at={x:at.x+direction.x*step,y:at.y+direction.y*step,z:at.z+direction.z*step};
      travel+=step;
      if(isSolidAt(dim,at)){particle(dim,BURST,at);system.clearRun(timer);return;}
      const target=getTargets(p,at,def.radius,0.9)
        .filter(e=>e.getGameMode?.()!=='creative' && e.getGameMode?.()!=='spectator')
        .sort((a,b)=>dist3(at,offset(a.location,0.9))-dist3(at,offset(b.location,0.9)))
        .find(e=>dist3(at,offset(e.location,0.9))<=def.radius && clearBlockPath(dim,at,offset(e.location,0.9)));
      if(target){
        hurt(target,p,def.damage,'magic',{ignoreInvulnerability:true});
        particle(dim,BURST,at);system.clearRun(timer);return;
      }
    }
    particle(dim,large?'rpg:bloodedge_lance':SPARK,at);
  },1);
  sound(dim,'mob.blaze.shoot',at,{volume:0.7,pitch:large?0.55:1.6});
}
function volley(p,_job,def) {
  if(pools.has(p.id))return false;
  const dimension=p.dimension.id;
  for(let i=0;i<def.shots;i++)system.runTimeout(()=>{
    if(usable(p,dimension)&&!pools.has(p.id))projectile(p,def,false);
  },1+i*def.interval);
  return true;
}
function lance(p,_job,def) {
  if(pools.has(p.id))return false;
  const dimension=p.dimension.id,end=system.currentTick+def.charge;
  const timer=system.runInterval(()=>{
    if(!usable(p,dimension) || pools.has(p.id)){system.clearRun(timer);return;}
    if(system.currentTick>=end){system.clearRun(timer);projectile(p,def,true);return;}
    const head=headPos(p),aim=p.getViewDirection();
    ring(p.dimension,{x:head.x+aim.x,y:head.y+aim.y,z:head.z+aim.z},0.45,5,SPARK);
  },1);
  return true;
}
function bind(p,_job,def){
  if(pools.has(p.id))return false;
  const target=firstTargetInView(p,def.range);
  if(!target || dist3(p.location,target.location)>def.range ||
      !enemies(p,p.location,def.range).some(enemy=>enemy.id===target.id) ||
      !clearBlockPath(p.dimension,headPos(p),offset(target.location,0.9))){
    notify(p,'§7혈박으로 묶을 적을 바라보세요.');return false;
  }
  const duration=ccTicks(target,def.duration),anchor={...target.location};
  pins.set(target.id,{owner:p,target,anchor,dimension:target.dimension.id,until:system.currentTick+duration});
  ring(p.dimension,offset(anchor,0.5),0.8,12);
  return true;
}

function removePoolAppearance(p){
  if(!p.hasTag(BLOODEDGE_POOL_TAG))return;
  p.triggerEvent('rpg:bloodedge_pool_off');
  p.removeTag(BLOODEDGE_POOL_TAG);
  if(p.getDynamicProperty(POOL_INVISIBILITY)===true && p.getEffect?.('invisibility')?.amplifier===1)p.removeEffect('invisibility');
  p.setDynamicProperty(POOL_INVISIBILITY,undefined);
}
function endPool(s,heal){
  const p=s.player;
  pools.delete(p.id);
  try{removePoolAppearance(p);}catch{}
  if(!heal)return;
  const hp=p.getComponent('minecraft:health');
  if(hp?.currentValue>0)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+s.damage*s.def.healRatio));
}
function pool(p,_job,def){
  if(pools.has(p.id) || shieldSessions.has(p.id))return false;
  try{
    p.addTag(BLOODEDGE_POOL_TAG);
    p.triggerEvent('rpg:bloodedge_pool_on');
    if(!p.getEffect?.('invisibility')){
      p.addEffect('invisibility',def.duration,{amplifier:1,showParticles:false});
      p.setDynamicProperty(POOL_INVISIBILITY,true);
    }
  }catch{
    try{removePoolAppearance(p);}catch{}
    return false;
  }
  const start=system.currentTick;
  pools.set(p.id,{player:p,def,dimension:p.dimension.id,until:start+def.duration,next:start+20,damage:0});
  notify(p,'§c핏빛 웅덩이 · 10초');
  return true;
}
function pulsePool(s){
  const p=s.player,origin=p.location;
  for(const target of enemies(p,origin,s.def.radius+1)){
    const pos=target.location;
    if(Math.hypot(pos.x-origin.x,pos.z-origin.z)>s.def.radius || pos.y-origin.y<-.65 ||
       pos.y-origin.y>1.25 || !clearBlockPath(p.dimension,offset(origin,0.6),offset(pos,0.6)))continue;
    const health=target.getComponent('minecraft:health'),before=health?.currentValue??0;
    if(before<=0 || !hurt(target,p,s.def.damage,'fixed',{ignoreInvulnerability:true}))continue;
    let after=0;
    try { after=health.currentValue; } catch {}
    s.damage+=Math.max(0,before-after);
  }
}
function tick(){
  const now=system.currentTick;
  for(const s of shieldSessions.values()){
    try{
      if(!active(s.player,s.dimension) || now>=s.until){
        endShield(s,now>=s.until && usable(s.player,s.dimension));continue;
      }
      markShieldFront(s);
      if(now%4===0){
        const p=s.player,head=headPos(p),dir=p.getViewDirection();
        const front=norm3({x:dir.x,y:0,z:dir.z});
        for(let i=-2;i<=2;i++)for(let row=-1;row<=1;row++){
          particle(p.dimension,SIGIL,{x:head.x+front.x*1.1-front.z*i*0.43,y:head.y-0.45+row*0.38,z:head.z+front.z*1.1+front.x*i*0.43});
        }
      }
    }catch{clearShield(s);}
  }
  for(const [id,s] of pins){
    try{
      if(now>=s.until || !usable(s.owner,s.dimension) || !healthAlive(s.target) ||
        s.target.dimension.id!==s.dimension || areAllies(s.owner,s.target) || isBloodedgePool(s.target) ||
        dist3(s.target.location,s.anchor)>12){
        pins.delete(id);continue;
      }
      if(dist3(s.target.location,s.anchor)>.05)
        s.target.teleport(s.anchor,{dimension:s.target.dimension,keepVelocity:false,checkForBlocks:true});
      s.target.clearVelocity?.();
      if(now%6===0)ring(s.target.dimension,offset(s.anchor,0.3),0.65,8);
    }catch{pins.delete(id);}
  }
  for(const s of pools.values()){
    try{
      const p=s.player;
      if(!active(p,s.dimension)){endPool(s,false);continue;}
      if(!isTimeFrozen(p)){
        if(now%4===0){
          const center=offset(p.location,0.1);
          particle(p.dimension,'rpg:bloodedge_pool',center);
          ring(p.dimension,center,s.def.radius,24);
        }
        if(now>=s.next){pulsePool(s);s.next=now+20;}
      }else if(now>=s.next){s.next=now+20;}
      if(now>=s.until)endPool(s,true);
    }catch{endPool(s,false);}
  }
}
function resetPlayer(p){
  try{
    const s=shieldSessions.get(p.id);if(s)clearShield(s);
    const state=pools.get(p.id);if(state)endPool(state,false);
    for(let i=0;i<SLOTS;i++)if(p.hasTag(guardTag(i)))p.removeTag(guardTag(i));
    removePoolAppearance(p);
  }catch{}
}
export function registerBloodedge(){
  if(registered)return;registered=true;
  world.beforeEvents?.entityHurt?.subscribe(ev=>{
    const p=ev.hurtEntity,source=ev.damageSource;
    try{if(blocksBloodedgeDamage(p,source?.damagingProjectile??source?.damagingEntity))ev.cancel=true;}catch{}
  });
  world.afterEvents.entityHurt.subscribe(ev=>{
    const p=ev.hurtEntity,source=ev.damageSource;
    try{
      if(!blocksBloodedgeDamage(p,source?.damagingProjectile??source?.damagingEntity))return;
      const hp=p.getComponent('minecraft:health');
      if(hp?.currentValue>0 && ev.damage>0)hp.setCurrentValue(Math.min(hp.effectiveMax,hp.currentValue+ev.damage));
    }catch{}
  });
  world.afterEvents.entityLoad?.subscribe(({entity})=>{
    try{
      for(const tag of entity.getTags())if(tag.startsWith('rpg_be_front_'))entity.removeTag(tag);
    }catch{}
  });
  world.afterEvents.playerLeave.subscribe(({playerId})=>{
    const shield=shieldSessions.get(playerId);if(shield)clearShield(shield);
    pools.delete(playerId);
    for(const [id,s] of pins)if(id===playerId||s.owner.id===playerId)pins.delete(id);
  });
  world.afterEvents.playerSpawn.subscribe(({player})=>resetPlayer(player));
  world.afterEvents.entityDie.subscribe(({deadEntity})=>{
    pins.delete(deadEntity.id);
    if(deadEntity.typeId==='minecraft:player')resetPlayer(deadEntity);
  });
  system.run(()=>{for(const p of world.getAllPlayers())resetPlayer(p);});
  system.runInterval(tick,1);
}

export const RUNNERS={
  bloodedge_shield:shield,bloodedge_volley:volley,bloodedge_lance:lance,bloodedge_bind:bind,bloodedge_pool:pool,
};
