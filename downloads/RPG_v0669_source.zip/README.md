# RPG v0.6.69 · 블러드엣지

마법사 레벨 20부터 마법 전직관이나 `/rpg:job 블러드엣지` 명령에서 블러드엣지로 전직할 수 있습니다. 혈술사와 직업 및 기술 목록이 별개이며, 전직하면 붉은 피의 낫을 받습니다.

| 기술 | 효과 |
|---|---|
| 핏빛 방패 | 5초 동안 정면 공격을 방어합니다. 종료할 때 반경 14칸의 적에게 기본 마법 피해 18과 밀치기를 적용합니다. |
| 핏방울 연사 | 작은 투사체 6발을 연속 발사합니다. 발당 기본 마법 피해 6입니다. |
| 혈류포 | 1초 동안 피를 모은 뒤 큰 투사체 1발을 발사합니다. 기본 마법 피해 45입니다. |
| 혈박 | 바라보는 적 하나를 3초 포박합니다. 쿨타임은 15초이며, 보스는 기존 제어 저항을 적용합니다. |
| 핏빛 웅덩이 | 10초 동안 몬스터의 공격 대상에서 벗어납니다. 지름 12칸의 웅덩이가 시전자를 따라 이동하며 위에 있는 적에게 초당 고정 피해 10을 줍니다. 종료 시 실제로 준 피해의 50%를 회복합니다. |

Bedrock 1.21.100 이상에서 세 팩을 v0.6.69로 활성화하세요. 모의 게임에서 전직과 기술, 생성된 엔티티 필터를 확인했습니다. 실제 베드락에서의 피해 센서 동작, 몬스터 인식과 화면 렌더링은 별도 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0669
```
