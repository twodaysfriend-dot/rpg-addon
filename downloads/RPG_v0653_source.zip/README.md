# RPG v0.6.53 · 손 장비 등급 지정과 갑옷 승급

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.53으로 적용하고 월드를 다시 여세요.

- 관리자 명령 `/rpg:setgrade 신화 hand`는 주 손의 RPG 갑옷·공용 무기·직업 무기에 적용합니다. 강화, 인챈트, 내구도와 사용자 지정 이름을 보존하며 등급은 툴팁에 표시됩니다. 관리자가 직업 무기에 지정한 등급은 무기의 기본 근접 피해 배율에 반영됩니다.
- `/rpg:fuse`에서 가방이나 착용 슬롯의 +10 RPG 갑옷을 선택하고 확인하면 보호 IV 인챈트 책 한 권을 사용해 다음 등급으로 확정 승급합니다. 승급한 갑옷은 +0부터 다시 강화하며, 인챈트와 내구도를 보존합니다. 신화가 최종 등급입니다.
- 공용 무기와 룬은 같은 종류·등급의 +5 이상 두 개로 합성합니다.

## 검증

주 손 등급 지정, 직업 무기의 등급 표시와 근접 피해 배율, 갑옷 승급 메뉴, 보호 IV 책 확인 및 소모, 저장 실패 시 복구를 모의 API로 검사했습니다. 실제 Bedrock 월드의 명령과 메뉴 동작은 인게임 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0653
```
