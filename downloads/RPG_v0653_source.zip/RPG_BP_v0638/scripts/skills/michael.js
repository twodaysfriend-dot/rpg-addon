import {system,MolangVariableMap} from '@minecraft/server';
import {canUseSkill} from '../core/skillAccess.js';
import {markResurrection,registerResurrection} from '../core/resurrection.js';
import {getTargets,hurt,healthAlive,isSolidAt,headPos,norm3,dist3,particle,sound} from '../core/util.js';
import {areAllies} from '../core/social.js';
import {VANILLA_HOSTILES} from '../data/mobXp.js';
import {LEVELED_MONSTERS} from '../data/leveledMonsters.js';
const monster=e=>e.typeId!=='minecraft:player'&&(VANILLA_HOSTILES.has(e.typeId.replace('minecraft:',''))||LEVELED_MONSTERS.includes(e.typeId)||e.getComponent('minecraft:type_family')?.hasTypeFamily('monster'));
function hit(p,e,def){if(!healthAlive(e)||areAllies(p,e))return false;return hurt(e,p,def.damage*(monster(e)?def.monsterMultiplier:1),'magic');}
function spearImpact(dim,at){
 particle(dim,'rpg:holy_spear_impact',at);
 for(let i=0;i<12;i++){const a=i*Math.PI/6;particle(dim,'rpg:holy_spear_spark',{x:at.x+Math.cos(a)*.7,y:at.y,z:at.z+Math.sin(a)*.7});}
}
function spear(p,job,def,target){
 if(!canUseSkill(p,'michael_holy_spear',['michael']))return false;
 if(target){if(target.dimension.id!==p.dimension.id||dist3(p.location,target.location)>6)return false;const ok=hit(p,target,def);if(ok)spearImpact(p.dimension,{...target.location,y:target.location.y+1});return ok;}
 const dim=p.dimension,dimId=dim.id,origin=headPos(p),dir=norm3(p.getViewDirection());let travel=0;
 particle(dim,'rpg:holy_spear_impact',origin);
 let variables;try{variables=new MolangVariableMap();variables.setVector3('variable.spear_direction',dir);}catch{}
 const timer=system.runInterval(()=>{
  try{
   if(!p.isValid||!healthAlive(p)||p.dimension.id!==dimId){system.clearRun(timer);return;}
   for(let sub=0;sub<4;sub++){
    const next=Math.min(def.range,travel+def.speed/4);if(next<=travel){system.clearRun(timer);return;}travel=next;
    const at={x:origin.x+dir.x*travel,y:origin.y+dir.y*travel,z:origin.z+dir.z*travel};
    if(isSolidAt(dim,at)){spearImpact(dim,at);system.clearRun(timer);return;}
    if(sub===1)try{dim.spawnParticle('rpg:holy_spear',at,variables);}catch{}
    if(sub===1)particle(dim,'rpg:holy_spear_spark',at);
    const victim=getTargets(p,at,def.hitRadius,.9).find(e=>e.id!==p.id&&healthAlive(e)&&!areAllies(p,e)&&dist3(origin,{x:e.location.x,y:e.location.y+.9,z:e.location.z})<=def.range);
    if(victim){hit(p,victim,def);spearImpact(dim,at);system.clearRun(timer);return;}
    if(travel>=def.range){system.clearRun(timer);return;}
   }
  }catch{system.clearRun(timer);}
 },1);
 sound(dim,'mob.blaze.shoot',origin,{volume:.6,pitch:1.8});return true;
}
function resurrection(p,job,def,target){
 if(!canUseSkill(p,'michael_resurrection',['michael'])||!markResurrection(p,target)){try{p.sendMessage('§7리저렉션: 가까운 아군에게 사용하세요. 활성 표식은 최대 2명이며 PvP에서는 사용할 수 없습니다.');}catch{}return false;}
 particle(target.dimension,'rpg:resurrection_mark',{...target.location,y:target.location.y+2.5});sound(target.dimension,'random.orb',target.location,{volume:.8,pitch:1.5});return true;
}
export function registerMichael(){registerResurrection();}
export const RUNNERS={michael_holy_spear:spear,michael_resurrection:resurrection};
