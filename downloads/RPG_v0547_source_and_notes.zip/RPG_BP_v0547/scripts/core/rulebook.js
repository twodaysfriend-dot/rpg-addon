// 명령어 책 페이지는 v0.4.82의 실제 등록 명령어 목록을 기반으로 작성.
// ItemBookComponent는 @minecraft/server 2.2.0부터 지원.
import { ItemStack } from "@minecraft/server";

export const RULEBOOK_PAGES = [
  '§l§6작골염양·검호 난도§r\n\n작골염양: 0.5초 간격 3회 베기\n검성 18.9×3=56.7 / 나머지 12.6×3=37.8\n모든 타격 명중 시 기본 합계\n\n검호 난도: 큰 초승달과 작은 참격 추가\n기존 12×3 피해 유지',
  '§l§6힘 버프 피해 보정§r\n\n물리·마법 스킬 모두 적용\n힘 I +3 / II +6 / III +9\n기본 피해에 더한 뒤 스탯·장비 계산\n\n고정 피해는 기존 유지\n무투가·평타 배수 중복 계산 방지',

  "§l§6RPG 정보 질문§r\n\n/rpg:ask\n질문 입력창 열기\n\n/rpg:ask \"월룡륜미 범위\"\n본인에게만 도감 안내\n\n직업·스킬·룬·제작·던전 정보만 안내합니다. 모르는 내용은 추측하지 않습니다.",
  '§l§6v0.5.47 월룡·복수귀§r\n\n월룡륜미: 전방 180도·반경 12칸\n큰 초승달·작은 달이 퍼짐\n기본 피해 28 · 적마다 1회\n\n딥 피어스: 18 피해·쿨 2.5초\n찢어내기: 16+출혈9·쿨 4초\n\n복수귀 공격 먼저·버프 뒤\n처형은 마지막 슬롯',
  '§l§6v0.5.47 검성 피해 상향§r\n\n검성 직업으로 사용 시\n작골염양 12.6 / 검성 18.9\n검기 방출 14 → 21\n러쉬 4×8 → 6×8 (48)\n360도 휘두르기 10 → 20\n\n근력·장비 보정 전 기본 피해\n마나·쿨타임·타수는 유지',
  '§l§6v0.5.47 던전·화면 정리§r\n\n방어구 게이지·버프 아이콘 숨김\n실제 방어력·버프 효과 유지\n\n던전 전체 완성 검사·누락 복구\n/rpg:dungeoncreate all\n기존 던전도 같은 명령으로 검사\n\n전투 중 자진 퇴장 불가\n밖으로 나가면 조용히 복귀\n빈 전장은 다음 몹 즉시 증원',
  '§l§6v0.5.47 성장 보완§r\n\n파티 전직: 최근 30초 기여\n공격·탱킹·유효 회복 인정\n같은 차원·처치 위치 32칸\n\n천사: 아군 HP 300 회복당\n축복의 빛 1개 (잔량 저장)\n\n스탯 초기화 주문서\n전직 포기각서: 견습으로\n제작법 /rpg:craft',
  '§l§6v0.5.47 경험치·보상§r\n\n바닐라 일반 몹 XP 10\n적대 몹 대부분 XP 30\n좀벌레·좀비화 피글린 XP 5\n보스·RPG 몹 XP는 유지\n\n던전 10 클리어 보상\n골드 31,000 · 강화석 124\n룬 가루 31 · 촉매 20\n룬 3개 · 제작 재료 4배',
  '§l§6돌진·해커 복구§r\n\n돌진: 음수 Y·공중 허용\n안전한 바닥 요구 제거\n벽 충돌 검사는 유지\n\n투신 궁극기: 풍신열각\n다음 평타 한 번 ×10\n\n해커: 로토와 23회 대화\n퀴즈 최초 정답자 1명 전직\n이후 정답자: 마법 황금사과 1개',
  '§l§6흡수의 룬·투신§r\n\n흡수 룬: 준 피해 5~12% HP 회복\n6종 룬 · 장착은 기존 3개\n\n투신: 권골·레벨40\n무투 계열 처치150·보스5\n/rpg:job 투신\n\n풍신열각: 다음 평타 한 번 ×10',
  '§l§6v0.5.47 원형 동굴 던전§r\n\n관리자: /rpg:dungeoncreate all\n난이도 1~10 · 큰 원형 동굴\n/rpg:dungeon 1: 본인 대기 참가\n/rpg:dungeonstart: 1~4명 출발\n/rpg:dungeonsolo 1: 혼자 시작\n/rpg:dungeonleave: 대기 취소·사망 후 귀환\n/rpg:dungeonloot: 보급품 받기\n\n일반 50 + 엘리트 5: 5분\n모두 처치 후 보스 1: 3분',
  '§l§6v0.5.47 보상 상향§r\n\n일반 적: 골드 114·강화석 2\n정예: 골드 360·강화석 6·가루 1\n보스: 골드 3600·강화석 24·가루 6\n\n갑옷 4부위와 룬 5종 풀강\n평균 약 20시간 목표\n사냥 속도·강화 운에 따라 변동', 
  '§l§6v0.5.47 전직·룬 개편§r\n\n일반 직업은 5개, 모두 레벨 10\n검사: 다이아 검 5개 공물\n마법사: 효과부여 책 10권 공물\n궁수: 20칸 밖 과녁 명중\n무투가: 샌드백 2개 파괴\n성직자: 전직관과 대화·확인\n\n/rpg:jobs 조건 확인\n/rpg:skillbook 스킬 분해·SP 환급',
  '§l§6v0.5.47 전투 조정§r\n\n/rpg:skillguide\n19계열·136개 스킬 상세 도감\n\n종말 60 피해·MP 800\n메테오 58 피해·MP 700\n풍압 마법 피해 20·쿨 13초\n초신성 11발×5, 기본 최대 55\n처형 반경 4칸\n천궁 화살 없을 때 발당 MP 20',
  "§l§6v0.5.47 성장 개편§r\n\n/rpg:runes: 룬 보관·장착\n/rpg:jobs: 모든 전직 시련\n카멜레온 /rpg:skillbook\n\n선택 학습은 레벨 SP 소비\n카멜레온 실제 5레벨 상승마다\n궁극기 제외 랜덤 스킬북 1권\n중요 스킬 횟수는 다이아 충전",
  "§l§6제작과 룬 획득§r\n\n/rpg:craft\n갑옷·룬·촉매 실제 제작법 도감\n\n일반 적 룬 드롭: 1%\nRPG 엘리트: 3%\n보스: 30% 확률\n모두 6종 중 무작위 +0 룬\n\n원하는 룬은 작업대에서 제작!",
  "§l§6v0.5.47 강화 규칙§r\n\n강화 확인창의 4종 확률을 확인하세요.\n실패·강등·파괴에도 비용 소비\n갑옷 파괴: 룬 보관함 유지\n룬 파괴: 해당 보관 룬만 소멸\n\n촉매 사용: 갑옷 +5 / 룬 +2부터\n최대 5개: 1개당 성공 +5%p, 파괴 -3%p\n\n최대 HP 60 초과: 숫자 표시\n근력·체력·마력 상한 해제",
  "§l§6강화와 재화§r\n\n/rpg:wallet: 지갑 확인\n/rpg:upgrade: 강화 메뉴\n\n골드: 공통 강화 비용\n강화석: 갑옷 강화용\n룬 가루: 룬 강화용\n\n갑옷 최대 +10, 보관 룬 최대 +5\n단계별 실패·강등·파괴 확률 적용\n재화는 몬스터 사냥으로 획득",
  "§l§6갑옷과 룬§r\n\n작업대에서 RPG 갑옷과 룬을 제작합니다.\n/rpg:equipment 로 룬 전용 보관함에서 장착합니다.\n/rpg:runes: 30칸 보관·3개 장착\n\n파티 정원: 4명\n각자 원래 사냥 XP의 75% 획득\n예: 90 → 각자 67.5 XP",
  "§l§6처음 시작하기§r\n\n/rpg:guide 로 시작 계열 선택\n장비·빵을 한 번 지급합니다.\n몬스터 5마리 처치 후 안내창에서 보상 수령·첫 전직은 레벨 10＋직업별 시련!\n\n파티 XP: 32블록 안 같은 차원의 생존 파티원에게 각자 원래 XP의 75%를 받습니다.",
  "§l§6RPG 명령어 안내서§r\n§7v0.5.47 · 전체 명령어§r\n\n명령어 앞에 /rpg:를 붙여서 사용!\n예: /rpg:stats\n\n짧은 채팅 별칭:\n/rulebook\n\n뒤 페이지에서 기능 확인",
  "§l§91. 기본 1§r\n\n§l/rpg:rulebook§r\n명령어 안내 책 받기\n§l/rpg:help§r\n명령어 간단 도움말\n§l/rpg:ping§r\n스크립트 실행 확인",
  "§l§92. 기본 2§r\n\n§l/rpg:status§r\n직업/마나/성장 확인\n§l/rpg:stats§r\n레벨·스탯 분배창\n§l/rpg:skills§r\n장착 스킬 켜기/끄기",
  "§l§93. 직업 1§r\n\n§l/rpg:job <직업>§r\n전직 조건 확인·전직\n§l/rpg:force <직업>§r\n관리자 강제 전직\n§l/rpg:reset§r\n관리자: 견습 초기화",
  "§l§94. 직업 2§r\n\n§l/rpg:starter <계열>§r\n관리자 견습 장비 지급\n§l/rpg:book§r\n인챈트 책 바쳐 마나 상승\n§l/rpg:sword§r\n현재 전직 조건 안내",
  "§l§95. 직업 3§r\n\n§l/rpg:bless§r\n성직 계열 전직 조건 안내\n§l/rpg:holywater§r\n물병+빛으로 성수 제작\n§l/rpg:items§r\n관리자: 모든 아이템 지급",
  "§l§96. 캐릭터/관리§r\n\n§l/rpg:charge§r\n관리자: 마나·쿨 초기화\n§l/rpg:setlevel <수>§r\n관리자: 1~100000 레벨\n§l/rpg:setmana <수>§r\n관리자: 최대 마나 설정",
  "§l§97. 카멜레온 1§r\n\n§l/rpg:menu§r\n카멜레온 스킬 도감\n§l/rpg:skillbook§r\n스킬 습득 도감 열기\n§l/rpg:learn <스킬ID>§r\n카멜레온 스킬 배우기",
  "§l§98. 카멜레온 2§r\n\n§l/rpg:swap§r\n전용 무기 2종 교체",
  "§l§99. 길드·파티§r\n\n§l/rpg:guild§r\n길드 생성·초대·관리\n§l/rpg:party§r\n파티 생성·초대·관리\n§l/rpg:invites§r\n초대 수락·거절하기",
  "§l§910. 날개§r\n\n§l/rpg:wings§r\n천사 계열 날개 전환\n§l/rpg:wingcheck§r\n날개 장착 상태 확인\n§l/rpg:wingrefresh§r\n날개 보조손 재장착",
  "§l§911. 검사·보스§r\n\n§l/rpg:fistcheck§r\n무투가/권골 도색 상태\n§l/rpg:boss§r\n관리자: 바위 골렘 소환\n§l/rpg:cyclops§r\n관리자: 외눈 거인 소환",
  "§l§3추가 사용 예시§r\n\n/rpg:job 마법사\n/rpg:force 카멜레온\n/rpg:learn hacker_ddos\n/rpg:setlevel 100\n/rpg:setmana 100000\n/rpg:setmana reset\n\n§7일부는 관리자만 가능.§r",
  "§l§6명령어 문제 해결§r\n\n/function rulebook\n!rulebook\n!rpg ping\n\n또는:\n/scriptevent rpg:rulebook\n\n관리자 명령어는 OP만 가능.\n스킬ID는 도감에서 확인."
];

export function giveRulebook(player) {
  try {
    const book = new ItemStack("minecraft:writable_book", 1);
    const pages = book.getComponent("minecraft:book");
    if (!pages || typeof pages.setContents !== "function") {
      player.sendMessage("§c[RPG] 책 페이지 API가 없는 버전입니다. @minecraft/server 2.2.0 이상을 사용하세요.");
      return false;
    }
    pages.setContents(RULEBOOK_PAGES);
    // 책과 깃펜 상태를 유지해 내용 열람 및 편집이 가능하게 합니다.
    book.nameTag = "§6RPG 명령어 안내서";
    book.setLore(["§7RPG 전체 명령어 · " + RULEBOOK_PAGES.length + "쪽", "§7/rulebook 또는 /rpg:rulebook"]);
    const inventory = player.getComponent("minecraft:inventory")?.container;
    if (!inventory) {
      player.sendMessage("§c[RPG] 인벤토리를 찾지 못했습니다.");
      return false;
    }
    const leftover = inventory.addItem(book);
    if (leftover) {
      // 가방이 꽉 차도 책이 사라지지 않게 플레이어 발밑에 드롭합니다.
      const loc = player.location;
      player.dimension.spawnItem(leftover, { x: loc.x, y: loc.y + 0.5, z: loc.z });
      player.sendMessage("§e[RPG] 인벤토리가 가득 차서 명령어 책이 발밑에 떨어졌습니다.");
    } else {
      player.sendMessage("§a[RPG] 책과 깃펜 'RPG 명령어 안내서'를 받았습니다! (" + RULEBOOK_PAGES.length + "쪽)");
    }
    return true;
  } catch (error) {
    player.sendMessage("§c[RPG] 안내서 지급 실패: " + String(error));
    return false;
  }
}
