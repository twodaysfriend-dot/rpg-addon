// v0.5.47 실제 전직 시련은 data/jobTrials.js를 사용합니다. req는 이전 저장값과 일부 명중 안내용 메타데이터입니다.
// 직업 트리. 새 직업/4차 전직은 여기에 항목만 추가하면 됩니다.
//   tier     : 전직 차수 (1=견습, 2, 3 ...)
//   line     : 계열. 2차 전직 시 이 계열 밖의 스킬은 사라집니다.
//   parent   : 이 직업으로 전직하기 직전의 직업
//   weapon   : 전직 시 1번 칸에 고정되는 무기 아이템 (없으면 null)
//   skills   : 이 직업이 쓰는 스킬 id 목록 (웅크리기로 순서대로 전환)
//   basic    : 휘두르기로 푸른 에너지를 쏘는지
//   corrupt  : 타락 직업 여부
//   highMana : 마법사/성직자 계열 (마나 상한 2000, 책 1권당 +20)
//   theme    : 이펙트 색 (blue / red)
//   req      : 전직 조건 { key(진행도 이름), need(필요 수), label(설명) }
//   placeholder : true 면 아직 구현 전인 직업 (전직 불가)

// 견습이 계열별로 받는 시작 아이템. 든 아이템에 따라 쓸 수 있는 스킬 목록이 달라집니다.
export const STARTER_ITEMS = {
  "rpg:apprentice_sword": "sword",
  "rpg:apprentice_book": "mage",
  "rpg:apprentice_cross": "holy",
  "rpg:apprentice_fist": "fist",
  "rpg:apprentice_bow": "archer",
};
export const STARTER_BY_LINE = {
  sword: "rpg:apprentice_sword",
  mage: "rpg:apprentice_book",
  holy: "rpg:apprentice_cross",
  fist: "rpg:apprentice_fist",
  archer: "rpg:apprentice_bow",
};
// 견습이 시작 아이템과 함께 배우는 스킬
export const APPRENTICE_SKILLS = {
  sword: [],
  mage: ["mage_fireball", "mage_lightning"],
  holy: ["holy_heal"],
  fist: [],
  archer: ["archer_airwalk", "archer_rapid"],
};

const SWORD_SAINT_SKILLS = ["sword_spin", "sword_wave", "sword_flame_spin", "sword_kenho_rando", "sword_moon_dragon", "sword_annihilation", "sword_rush"];
// 타락검성은 섬멸을 사용할 수 없고 광분화를 배웁니다.
const FALLEN_SWORD_SKILLS = ["sword_spin", "sword_wave", "sword_flame_spin", "sword_kenho_rando", "sword_moon_dragon", "sword_rush", "fallen_sword_frenzy"];

const MAGE_2 = ["mage_flame_on", "mage_thunder", "mage_ice_fire", "mage_gravity", "mage_bombaye"];
const SAGE_3 = [
  "sage_meteor", "sage_raiyoung", "sage_zero", "sage_blackhole", "sage_sphere", "sage_zoltraak",
];

// 성직자 계열
const CLERIC_SKILLS = ["holy_heal", "holy_shield", "holy_sword", "holy_orb", "holy_pray"];
const ANGEL_SKILLS = [...CLERIC_SKILLS, "angel_bless", "angel_zone"];
const FALLEN_SKILLS = [
  "fallen_sacrifice", "fallen_sword", "fallen_shield", "fallen_curse",
  "fallen_orb", "fallen_zone", "fallen_end",
];

// 무투가 계열 (견습 → 무투가 → 권골)
const FIGHTER_SKILLS = ["fist_strong", "fist_flurry", "fist_smash"];
const FIST_BONE_SKILLS = [
  ...FIGHTER_SKILLS, "fist_wind", "fist_face", "fist_stance", "fist_finale",
];

function stub(id, name, tier, line, parent, extra = {}) {
  return {
    id, name, tier, line, parent,
    weapon: null, skills: [], basic: false, corrupt: false, highMana: false, theme: "blue",
    placeholder: true,
    ...extra,
  };
}

export const JOBS = {
  war_god:{id:'war_god',name:'투신',tier:4,line:'war_god',parent:'fist_bone',hidden:true,weapon:'rpg:war_god_gauntlets',skills:['war_god_punch','war_god_flurry','war_god_kick','war_god_kick_flurry','war_god_black_flash'],basic:false,corrupt:false,highMana:false,theme:'red'},
  apprentice: {
    id: "apprentice", name: "견습", tier: 1, line: "all", parent: null,
    weapon: null, skills: [], basic: false, corrupt: false, highMana: false, theme: "blue",
  },

  // ---- 검 계열 ----
  swordsman: {
    id: "swordsman", name: "검사", tier: 2, line: "sword", parent: "apprentice",
    weapon: "rpg:swordsman_sword", skills: ["sword_spin", "sword_wave", "sword_flame_spin"], basic: false, corrupt: false, highMana: false, theme: "blue",
    req: { key: "sword_kills", need: 100, label: "검으로 엔티티 처치" },
  },
  sword_saint: {
    id: "sword_saint", name: "검성", tier: 3, line: "sword", parent: "swordsman",
    weapon: "rpg:sword_saint_sword", skills: SWORD_SAINT_SKILLS, basic: true, corrupt: false, highMana: false, theme: "blue",
    req: { key: "diamond_swords", need: 100, label: "다이아몬드 검 바치기 (/rpg:sword)" },
  },
  // 타락검성은 검성의 스킬과 전용 액티브 '광분화'를 사용합니다.
  fallen_sword_saint: {
    id: "fallen_sword_saint", name: "타락검성", tier: 3, line: "sword", parent: "sword_saint",
    weapon: "rpg:fallen_sword_saint_sword", skills: FALLEN_SWORD_SKILLS, basic: true, corrupt: true, highMana: false, theme: "red",
    req: { key: "villager_kills", need: 100, label: "검성 상태에서 주민 처치" },
  },

  // ---- 마법 계열 ----
  mage: {
    id: "mage", name: "마법사", tier: 2, line: "mage", parent: "apprentice",
    weapon: "rpg:mage_book", skills: ["mage_fireball", "mage_lightning", ...MAGE_2],
    basic: false, corrupt: false, highMana: true, theme: "blue",
    req: { key: "books", need: 64, label: "인챈트 책 바치기 (/rpg:book)" },
  },
  sage: {
    id: "sage", name: "현자", tier: 3, line: "mage", parent: "mage",
    weapon: "rpg:sage_staff", skills: [...MAGE_2, ...SAGE_3],
    basic: false, corrupt: false, highMana: true, theme: "blue",
    req: { key: "mana_spent", need: 30000, label: "마법사 상태에서 마나 사용" },
  },

  // ---- 궁수 계열: 견습 궁수 → 궁수 → 천궁 ----
  archer: {
    id: "archer", name: "궁수", tier: 2, line: "archer", parent: "apprentice",
    weapon: "rpg:archer_bow", skills: ["archer_airwalk", "archer_rapid", "archer_fire", "archer_ice", "archer_lightning", "archer_pierce"],
    basic: false, corrupt: false, highMana: false, theme: "blue",
    req: { key: "apprentice_arrow_hits", need: 20, label: "견습 활 명중" },
  },
  heavenly_archer: {
    id: "heavenly_archer", name: "천궁", tier: 3, line: "archer", parent: "archer",
    weapon: "rpg:heavenly_bow", skills: ["archer_airwalk", "archer_rapid", "archer_ice", "archer_lightning", "archer_pierce", "archer_homing", "archer_bomb", "archer_judgement", "archer_heavenly"],
    basic: false, corrupt: false, highMana: false, theme: "blue",
    req: { key: "archer_arrow_hits", need: 80, label: "궁수 활 명중" },
  },


  // ---- 히든 망나니 -> 야수 (망나니 스킬 승계) ----
  mangnani: {
    id: "mangnani", name: "망나니", tier: 2, line: "berserker", parent: null,
    hidden: true, weapon: "rpg:mangnani_axe", skills: ["berserker_charge", "berserker_slam", "berserker_execute", "beast_berserk", "berserker_triple_slash"],
    passive: "berserker_kill",
    basic: false, corrupt: true, highMana: false, theme: "red",
  },
  beast: {
    id: "beast", name: "야수", tier: 3, line: "berserker", parent: "mangnani",
    weapon: "rpg:beast_axe", skills: ["berserker_charge", "berserker_slam", "berserker_execute", "beast_berserk", "berserker_triple_slash", "beast_flame_burst", "beast_grand_explosion"],
    passive: "berserker_kill",
    basic: false, corrupt: true, highMana: false, theme: "red",
  },

  // ---- 히든 직업 냉기 능력자 (해금 방법은 사용자가 나중에 지정) ----
  frost_controller: {
    id: "frost_controller", name: "냉기 능력자", tier: 2, line: "frost", parent: null,
    hidden: true, weapon: "rpg:frost_gauntlet",
    skills: ["frost_shard", "frost_grasp", "frost_barrage", "frost_step", "frost_field", "frost_great_release", "frost_absolute"],
    basic: false, corrupt: false, highMana: true, theme: "blue",
  },

  // ---- 히든 직업 화염술사 (해금 조건 추후 결정) ----
  fire_controller: {
    id: "fire_controller", name: "화염술사", tier: 2, line: "fire", parent: null,
    hidden: true, weapon: "rpg:fire_gauntlet",
    skills: ["fire_ignite", "fire_pillar", "fire_wheel", "fire_armor", "fire_emperor"],
    basic: false, corrupt: false, highMana: true, theme: "red",
  },


  // ---- 히든 직업 용기사 ----
  dragon_knight: {
    id: "dragon_knight", name: "용기사", tier: 2, line: "dragon", parent: null,
    hidden: true, weapon: "rpg:dragon_knight_lance",
    skills: ["dragon_triple_strike", "dragon_gaze", "dragon_charge", "dragon_sprint", "dragon_breath", "dragon_domain"],
    passive: "dragon_third_strike",
    basic: false, corrupt: false, highMana: false, theme: "blue",
  },

  // ---- 악마: 검붉은 낫과 영혼 수확 패시브 ----
  demon: {
    id: "demon", name: "악마", tier: 2, line: "demon", parent: null, hidden: true,
    weapon: "rpg:demon_scythe",
    skills: ["demon_fear", "demon_vampirism", "demon_reap", "demon_contract", "demon_storm", "demon_domain"],
    passive: "demon_soul_harvest", basic: false, corrupt: true, highMana: true, theme: "red",
  },

  // ---- 마법공학사: 등 뒤의 보조 기계팔 + 표식 기반 기계 마법 ----
  technomancer: {
    id: "technomancer", name: "마법공학사", tier: 2, line: "tech", parent: null, hidden: true,
    weapon: "rpg:tech_staff", skills: ["tech_ray","tech_prison","tech_sphere","tech_bomb","tech_storm"],
    basic: false, corrupt: false, highMana: true, theme: "blue",
  },

  // ---- 신규 직업: 해커 / 혈술사 / 암살자 -> 그림자 암살자 ----
  // 해금 조건과 전용 스킬은 사용자 설정을 위해 현재 미지정.
  hacker: {
    id: "hacker", name: "해커", tier: 2, line: "hacker", parent: null, hidden: true,
    weapon: "rpg:hacker_core", skills: ["hacker_hack", "hacker_dummy_data", "hacker_reboot", "hacker_stealth", "hacker_copy", "hacker_ddos", "hacker_emp"], basic: false, corrupt: false, highMana: true, theme: "blue",
  },
  blood_mage: {
    id: "blood_mage", name: "혈술사", tier: 2, line: "blood", parent: null, hidden: true,
    weapon: "rpg:blood_crystal", skills: ["blood_spear", "blood_orb", "blood_supernova", "blood_mark", "blood_awaken", "blood_bind"], basic: false, corrupt: false, highMana: true, theme: "red",
  },
  assassin: {
    id: "assassin", name: "암살자", tier: 2, line: "assassin", parent: null, hidden: true,
    weapon: "rpg:assassin_blade", skills: ["assassin_spin", "assassin_dagger_wave", "assassin_pierce"], basic: false, corrupt: false, highMana: false, theme: "blue",
  },
  shadow_assassin: {
    id: "shadow_assassin", name: "그림자 암살자", tier: 3, line: "assassin", parent: "assassin",
    weapon: "rpg:shadow_assassin_blade", skills: ["assassin_spin", "assassin_dagger_wave", "assassin_pierce", "assassin_stealth", "assassin_mark", "shadow_assassinate"], basic: false, corrupt: false, highMana: false, theme: "red",
  },

  // ---- 작살 계열: 작살꾼 → 복수귀 ----
  harpooner: {
    id: "harpooner", name: "작살꾼", tier: 2, line: "harpoon", parent: null, hidden: true,
    weapon: "rpg:harpooner_harpoon", skills: ["harpoon_throw", "harpoon_dive", "harpoon_charge"],
    basic: false, corrupt: false, highMana: false, theme: "blue",
  },
  revenant: {
    id: "revenant", name: "복수귀", tier: 3, line: "harpoon", parent: "harpooner",
    weapon: "rpg:revenant_harpoon", skills: ["revenant_deep_pierce", "revenant_rend", "harpoon_throw", "harpoon_charge", "soul_harpoon", "harpoon_dive", "soul_separation", "revenant_execution"],
    basic: false, corrupt: true, highMana: false, theme: "blue",
  },

  // ---- 해의 후예 / 달의 후예: 지상의 햇빛·달빛 충전 계열 ----
  sun_heir: {
    id:"sun_heir", name:"해의 후예", tier:2, line:"celestial_sun", parent:null,
    weapon:"rpg:sun_heir_axe", highMana:true, hidden:true, basic:false, corrupt:false, theme:"red",
    skills:["sun_charge","sun_slash","sun_blessing","sun_divine_blessing","sun_meteor_drive","sun_radiant_beam","sun_descent"],
  },
  moon_heir: {
    id:"moon_heir", name:"달의 후예", tier:2, line:"celestial_moon", parent:null,
    weapon:"rpg:moon_heir_blade", highMana:true, hidden:true, basic:false, corrupt:false, theme:"blue",
    skills:["moon_charge","moon_slash","moon_moonlight","moon_homing","moon_chakram_split","moon_veil","moon_fullwave"],
  },

  // ---- 카멜레온: 두 무기 전환 / 다른 직업의 모든 액티브 스킬 학습 ----
  chameleon: {
    id: "chameleon", name: "카멜레온", tier: 2, line: "chameleon", parent: null, hidden: true,
    weapon: "rpg:chameleon_flame_blade", altWeapon: "rpg:chameleon_moon_scythe",
    skills: ["chameleon_crimson_dash", "chameleon_ground_slam"], basic: false, corrupt: false, highMana: true, theme: "red",
  },

  // ---- 환수종 (미구현 자리 표시자, 전직 불가) ----
  // 삭제한 반인반수와의 전직 연결은 끊었습니다.
  beast_lord: stub("beast_lord", "환수종", 3, "beast", null),

  // ---- 무투가 계열 ----  (두 직업 모두 낙하 피해 없음)
  fighter: {
    id: "fighter", name: "무투가", tier: 2, line: "fist", parent: "apprentice",
    weapon: "rpg:fighter_fist", skills: FIGHTER_SKILLS, basic: false, corrupt: false, highMana: false, theme: "red",
    req: { key: "apprentice_sandbags", need: 1, label: "견습 상태에서 샌드백 파괴" },
  },
  fist_bone: {
    id: "fist_bone", name: "권골", tier: 3, line: "fist", parent: "fighter",
    weapon: "rpg:fist_bone_fist", skills: FIST_BONE_SKILLS, basic: false, corrupt: false, highMana: false, theme: "red",
    req: { key: "fighter_sandbags", need: 10, label: "무투가 상태에서 샌드백 10개 파괴" },
  },

  // ---- 성직자 계열 ----
  cleric: {
    id: "cleric", name: "성직자", tier: 2, line: "holy", parent: "apprentice",
    weapon: "rpg:cleric_cross", skills: CLERIC_SKILLS, basic: false, corrupt: false, highMana: true, theme: "blue",
  },
  angel: {
    id: "angel", name: "천사", tier: 3, line: "holy", parent: "cleric",
    weapon: "rpg:angel_hands", skills: ANGEL_SKILLS, basic: false, corrupt: false, highMana: true, theme: "blue",
    req: { key: "light_angel", need: 64, label: "축복의 빛 1세트 바치기 (/rpg:bless)" },
  },
  // 미카엘: 천사 스킬 + 패시브 '불사'
  michael: {
    id: "michael", name: "미카엘", tier: 4, line: "holy", parent: "angel",
    weapon: "rpg:michael_wings", skills: ANGEL_SKILLS, basic: false, corrupt: false, highMana: true, theme: "blue",
    passive: "undying",
    req: { key: "light_michael", need: 192, label: "축복의 빛 3세트 바치기 (/rpg:bless)" },
  },
  fallen_angel: {
    id: "fallen_angel", name: "타락천사", tier: 4, line: "holy", parent: "angel",
    weapon: "rpg:fallen_angel_wings", skills: FALLEN_SKILLS, basic: false, corrupt: true, highMana: true, theme: "red",
    req: { key: "angel_villager_kills", need: 100, label: "천사 상태에서 주민 처치" },
  },
};

export const BASIC_JOB_IDS=['swordsman','mage','archer','fighter','cleric'];
for(const job of Object.values(JOBS))if(job.id!=='apprentice'&&!job.placeholder)job.hidden=!BASIC_JOB_IDS.includes(job.id);

export const ALL_WEAPON_IDS = [
  ...Object.keys(STARTER_ITEMS),
  ...Object.values(JOBS).map((j) => j.weapon).filter(Boolean),
  ...Object.values(JOBS).map((j) => j.altWeapon).filter(Boolean),
];

// id("sword_saint") 또는 이름("검성")으로 직업 찾기
export function findJob(input) {
  if (input === undefined || input === null) return null;
  const s = String(input).trim();
  if (!s) return null;
  if (JOBS[s]) return JOBS[s];
  // 명령어에서 한글 직업명의 띄어쓰기를 생략해도 동일하게 인식합니다.
  // 예: /force 반물질의신, /rpg:force 반물질의 신
  const normalized = s.replace(/\s+/g, "");
  if (["타락검사", "타락 검사", "fallen_swordsman"].includes(normalized)) return JOBS.fallen_sword_saint;
  return Object.values(JOBS).find((j) => j.name.replace(/\s+/g, "") === normalized || j.id === normalized) ?? null;
}
