# RPG v0.6.98 · 히드라 강화, 직업 복귀, 스킬 마나 배율

| 던전 | 히드라 체력 | 히드라 기본 공격력 |
| --- | ---: | ---: |
| 9단계 | 66,000 | 138 |
| 10단계 | 72,000 | 172.5 |

두 단계 모두 이전 버전보다 체력이 2배, 기본 공격력과 꼬리 휩쓸기 피해가 1.5배입니다. 유도 화염구 브레스 3발의 피해는 이전과 같습니다.

- `/rpg:jobchange`에서 이전 직업으로 복귀에 성공하면 10분 동안 다시 복귀할 수 없습니다. 남은 시간이 메뉴에 표시되고 재접속 후에도 유지됩니다.
- 직업 무기를 든 상태에서 `/rpg:skills`로 스킬 설정을 열고 **마나 배율 설정**을 선택하세요. 직업 공통값과 개별 피해 스킬 배율을 따로 저장합니다. 특정 스킬만 강화하려면 공통을 1배로 두고 해당 스킬의 배율을 바꾸세요. 개별 1배는 공통 배율이 2배 이상이어도 기본 소모량을 사용합니다.
- 마나 1~10배 중에서 고를 수 있으며 기본값은 1배입니다. 마나 2배는 피해 1.1배, 3배는 1.2배, 10배는 1.9배입니다. 지능을 반영한 기존 소모량을 기준으로 배율을 곱합니다. 순수 보조·회복 스킬과 기본 공격은 기존 방식으로 사용합니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.98로 활성화한 뒤 월드를 다시 여세요. 자동 검사에서 히드라 수치와 화염구 및 꼬리 공격 피해, 직업 복귀 차단·만료·실패, 스킬 메뉴와 피해·마나 배율을 확인했습니다. 실제 Bedrock 월드에서의 동작은 확인하지 못했습니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
python3 tools/build_protected_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0698
```
