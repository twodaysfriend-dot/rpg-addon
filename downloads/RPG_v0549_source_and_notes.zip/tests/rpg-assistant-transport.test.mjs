import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {rankKnowledge} from '../optional_bds_api/assistantTransport.js';
import {rankKnowledge as local} from '../RPG_BP_v0549/scripts/core/assistantTransport.js';
import {requests,setHttpHandler} from './bedrockHttpMock.mjs';
const entries=[{id:'skill:sword_moon_dragon',title:'월룡륜미',body:'전방 180도',source:'data/skills.js',aliases:['월룡륜미']}];
test('normal addon remains compatible with clients and Realms, with no external HTTP dependency',async()=>{
 const manifest=JSON.parse(fs.readFileSync(new URL('../RPG_BP_v0549/manifest.json',import.meta.url)));
 assert.ok(!manifest.dependencies.some(d=>['@minecraft/server-net','@minecraft/server-admin'].includes(d.module_name)));
 setHttpHandler(async()=>{throw Error('Unexpected HTTP call');});assert.equal(await local('월룡륜미',entries),undefined);assert.equal(requests.length,0);
});
test('BDS adapter sends only the explicit question and source facts with a server-side secret header',async()=>{
 setHttpHandler(async()=>({status:200,body:'{"ids":["skill:sword_moon_dragon"]}'}));
 assert.deepEqual(await rankKnowledge('월룡륜미',entries),['skill:sword_moon_dragon']);const r=requests[0];
 assert.equal(r.uri,'http://127.0.0.1:8787/rpg/ask');assert.equal(r.timeout,8);assert.equal(r.method,'Post');assert.deepEqual(r.headers[1].value,{secretName:'rpg_assistant_token'});
 assert.deepEqual(JSON.parse(r.body),{question:'월룡륜미',entries:[{id:entries[0].id,title:entries[0].title,body:entries[0].body}]});
});
test('BDS network errors, error status and malformed responses fall back to the catalog',async()=>{
 for(const handler of [async()=>{throw Error('offline');},async()=>({status:502}),async()=>({status:200,body:'invalid'})]){setHttpHandler(handler);assert.equal(await rankKnowledge('월룡륜미',entries),undefined);}
});
test('BDS adapter bounds concurrent external calls and frees slots afterward',async()=>{
 const resolve=[];setHttpHandler(()=>new Promise(done=>resolve.push(done)));
 const pending=Array.from({length:4},()=>rankKnowledge('월룡륜미',entries));assert.equal(await rankKnowledge('월룡륜미',entries),undefined);assert.equal(requests.length,4);
 for(const done of resolve)done({status:200,body:'{"ids":[]}'});await Promise.all(pending);
 setHttpHandler(async()=>({status:200,body:'{"ids":[]}'}));assert.deepEqual(await rankKnowledge('월룡륜미',entries),[]);
});
