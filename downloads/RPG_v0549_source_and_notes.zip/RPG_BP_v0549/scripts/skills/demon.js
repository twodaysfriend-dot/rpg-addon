import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import { healingFor } from "../core/stats.js";
import { world, system } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { getJobId } from "../core/playerData.js";
import { areAllies } from "../core/social.js";
import { getTargets, healthAlive, headPos, flatDir, particle, sound, hurt as hurtBase, knockback, dist3, isSolidAt } from "../core/util.js";
import { notify } from "../core/hud.js";
import { SKILLS } from "../data/skills.js";

// 악마: 낫 5종 액티브 + 영혼 수확 처치 패시브.
// 모든 피해 스킬은 getTargets/hurt 및 areAllies를 통해 길드·파티 아군을 제외합니다.
const FEAR = "rpg:demon_fear";
const SOUL = "rpg:demon_soul";
const badEffects = new Set([
  "slowness", "weakness", "poison", "wither", "blindness", "darkness", "hunger",
  "nausea", "mining_fatigue", "levitation", "fatal_poison", "unluck",
  "bad_omen", "raid_omen", "trial_omen", "infested", "oozing", "weaving",
]);
let registered = false;
const domains = new Map(); // player.id -> {owner, target,dim,center,radius,until,exited}
const excludedFromDomain = new Set(["minecraft:item","minecraft:xp_orb","minecraft:armor_stand","rpg:tech_prison_dome","rpg:moon_chakram_projectile","rpg:moon_weapon_chakram"]);
const pos = (p, y=1) => ({ x:p.location.x, y:p.location.y+y, z:p.location.z });
const valid = e => { try { return e?.isValid && healthAlive(e); } catch { return false; } };
function applyEffect(entity, name, ticks, amplifier) {
  try { applyStatus(entity,name, ticks, { amplifier, showParticles:false }); return true; } catch { return false; }
}
function ring(dim, center, radius, count, effect, spin=0) {
  for (let i=0;i<count;i++) {
    const a=spin+i*Math.PI*2/count;
    particle(dim,effect,{x:center.x+Math.cos(a)*radius,y:center.y,z:center.z+Math.sin(a)*radius});
  }
}
function enemy(p,e) {
  return valid(e) && e.id!==p.id && !areAllies(p,e) && (CONFIG.pvp || e.typeId!=="minecraft:player");
}

// 공포: 작고 검붉은 감정 구체를 직선으로 발사. 명중 시 공포 디버프
// (시야 차단·둔화·약화)와 밀려남 효과를 부여합니다.
function fear(p,job,def) {
  const dim=p.dimension, start=headPos(p), f=p.getViewDirection();
  const origin={x:start.x,y:start.y-.13,z:start.z};
  let travel=0;
  sound(dim,"mob.ghast.charge",p.location,{volume:.65,pitch:.5});
  const id=system.runInterval(()=>{
    try {
      if (!p.isValid || p.dimension.id!==dim.id || travel>=def.range) {system.clearRun(id);return;}
      for(let sub=0;sub<2;sub++) {
        travel+=def.speed/2;
        const q={x:origin.x+f.x*travel,y:origin.y+f.y*travel,z:origin.z+f.z*travel};
        particle(dim,FEAR,q);
        if ((Math.ceil(travel*2))%3===0) particle(dim,SOUL,{x:q.x-.17,y:q.y+.07,z:q.z+.08});
        const target=getTargets(p,q,1.15,.8).find(e=>enemy(p,e));
        if (target) {
          hurt(target,p,def.damage);
          applyEffect(target,"slowness",def.fearTicks,2);
          applyEffect(target,"weakness",def.fearTicks,1);
          applyEffect(target,"blindness",def.fearTicks,0);
          const dx=target.location.x-p.location.x,dz=target.location.z-p.location.z;
          knockback(target,dx,dz,1.1,.14);
          ring(dim,pos(target,.9),.68,12,FEAR);
          sound(dim,"mob.endermen.scream",q,{volume:.5,pitch:1.3});
          system.clearRun(id);return;
        }
      }
    } catch {system.clearRun(id);}
  },1);
  return true;
}

// 흡혈: 반경 6 안의 유효한 적 수를 그대로 재생 단계로 사용 (최대 50).
// 예: 1명=재생 I, 5명=재생 V, 36명=재생 XXXVI. 유지 7초.
function vampirism(p,job,def) {
  const targets=getTargets(p,p.location,def.radius).filter(e=>enemy(p,e));
  if (!targets.length) {notify(p,"§7흡혈할 적이 없습니다.");return false;}
  for (const e of targets) {
    hurt(e,p,def.damage);
    particle(p.dimension,SOUL,pos(e,.85));
    // 빨간 영혼 입자가 자신의 몸으로 모이는 모습.
    const a=pos(e,1), b=pos(p,1.2);
    for (let i=1;i<=4;i++) {
      const t=i/5;
      particle(p.dimension,FEAR,{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t});
    }
  }
  const level=Math.min(def.maxLevel,targets.length);
  applyEffect(p,"regeneration",def.regenerationTicks,level-1);
  sound(p.dimension,"mob.evocation_illager.cast_spell",p.location,{volume:.8,pitch:.75});
  notify(p,`§c흡혈! §f${targets.length}명 적중 · 재생 ${level} (7초)`);
  return true;
}

// 수확: 전방 낫 모양 참격 (0.18~0.2블럭 파티클만 사용).
function reap(p,job,def) {
  const dim=p.dimension,f=flatDir(p),l=p.location;
  const targets=getTargets(p,l,def.range+0.3).filter(e=>{
    if (!enemy(p,e))return false;
    const dx=e.location.x-l.x,dz=e.location.z-l.z, d=Math.hypot(dx,dz);
    return d<=def.range && (d<.01 || (dx*f.x+dz*f.z)/d>=.24) && Math.abs(e.location.y-l.y)<3;
  });
  for(const e of targets) hurt(e,p,def.damage,"physical");
  // 낫 궤적: 플레이어 정면을 가로지르는 얇은 붉은 초승달
  const s={x:-f.z,z:f.x};
  for(let i=0;i<21;i++){
    const t=i/20,a=(t-.5)*2.25;
    const r=2.3+Math.sin(t*Math.PI)*.42;
    particle(dim,i%3?FEAR:SOUL,{
      x:l.x+f.x*r+ s.x*Math.sin(a)*2.25,
      y:l.y+.7+Math.cos(a)*.95,
      z:l.z+f.z*r+ s.z*Math.sin(a)*2.25,
    });
  }
  sound(dim,"random.anvil_use",l,{volume:.75,pitch:1.65});
  notify(p,`§c수확! §f${targets.length}명 적중`);
  return true;
}

// 계약은 입력 두 개를 동시에 지원한다.
// 우클릭=자신의 체력 5칸(HP 10) 소모 + 저항 III / 흡수 X 2분.
// 좌클릭=대상에게 HP 14 피해 + 힘 III 5초 (같은 길드/파티 아군 제외).
function contract(p,job,def,target) {
  if (target) {
    if (!enemy(p,target) || dist3(target.location,p.location)>5.5) return false;
    hurt(target,p,def.enemyDamage,"fixed");
    applyEffect(target,"strength",def.enemyStrengthTicks,2);
    particle(p.dimension,SOUL,pos(target,.95));
    ring(p.dimension,pos(target,.95),.7,12,FEAR);
    sound(p.dimension,"mob.enderdragon.growl",target.location,{volume:.55,pitch:1.6});
    notify(p,"§c계약: §f적에게 7칸 피해 / 힘 III 5초");
    return true;
  }
  const health=p.getComponent("minecraft:health");
  if (!health || health.currentValue<=def.healthCost) {
    notify(p,"§c계약에 필요한 체력이 부족합니다. (5칸 초과 필요)");
    return false;
  }
  try { health.setCurrentValue(Math.max(1,health.currentValue-def.healthCost)); }
  catch {notify(p,"§c체력을 소모할 수 없습니다.");return false;}
  applyEffect(p,"resistance",def.buffTicks,2);    // 저항 III
  applyEffect(p,"absorption",def.buffTicks,9);    // 흡수 X
  ring(p.dimension,pos(p,1),1.1,18,FEAR);
  sound(p.dimension,"mob.evocation_illager.prepare_summon",p.location,{volume:.8,pitch:.8});
  notify(p,"§4계약: §f체력 5칸 소모 / 저항 III + 흡수 X (2분)");
  return true;
}
function cleanse(p) {
  let cleared=0;
  try {
    for (const fx of p.getEffects()) {
      const name=String(fx.typeId ?? "").replace(/^minecraft:/,"");
      if (!badEffects.has(name)) continue;
      try {p.removeEffect(name);cleared++;} catch {}
    }
  } catch {}
  return cleared;
}

// 공포의 폭풍: 시전자 중심 반경 10, 10초, 1초마다 정확히 HP 6의 피해.
function storm(p,job,def) {
  const cured=cleanse(p),dim=p.dimension;
  sound(dim,"mob.wither.spawn",p.location,{volume:.9,pitch:1.65});
  let elapsed=0, hits=0;
  const id=system.runInterval(()=>{
    try{
      if(!p.isValid || p.dimension.id!==dim.id || elapsed>=def.duration){system.clearRun(id);return;}
      elapsed+=5;
      const q=pos(p,.65);
      const r=def.radius;
      // 얇은 검붉은 폭풍 띠. 파티클 자체는 0.18~0.2 블럭.
      ring(dim,q,r,18,FEAR,elapsed*.06);
      ring(dim,{x:q.x,y:q.y+1.3,z:q.z},r*.63,12,SOUL,-elapsed*.13);
      if(elapsed%20!==0)return;
      const targets=getTargets(p,p.location,r).filter(e=>enemy(p,e));
      for(const e of targets){if(hurt(e,p,def.damagePerSecond))hits++;}
    } catch {system.clearRun(id);}
  },5);
  notify(p,`§4공포의 폭풍! §f디버프 ${cured}개 해제 · 10초간 주위 적 공격`);
  return true;
}
// 악마의 영역전개: 반경 7.5 (지름 15) / 10초 / 시전자와 선택한 대상만 초기 내부 잔류.
// 바깥에 있었거나 밖으로 나간 모든 엔티티는 내부에 들어올 수 없다.
function domainInside(zone,loc){
  const dx=loc.x-zone.center.x,dz=loc.z-zone.center.z;
  const dy=loc.y-zone.center.y;
  if(dy < -2.4 || dy > zone.radius+.35)return false;
  // 반구형 돔 윗부분에 맞춘 3D 판정. 바닥보다 아래는 평면 반경으로 계산.
  return dx*dx+dz*dz+Math.max(0,dy)*Math.max(0,dy) <= zone.radius*zone.radius;
}
function domainEntity(e){
  try{return e?.isValid && !excludedFromDomain.has(e.typeId) && !!e.getComponent('minecraft:health') && healthAlive(e);}
  catch{return false;}
}
function safeOutside(zone,pos){
  const dim=zone.dim;
  const body={x:pos.x,y:pos.y+.12,z:pos.z};
  const head={x:pos.x,y:pos.y+1.5,z:pos.z};
  const ground={x:pos.x,y:pos.y-.8,z:pos.z};
  try{
    const a=dim.getBlock(body),b=dim.getBlock(head),g=dim.getBlock(ground);
    const danger = b => !!b && (b.typeId.includes('lava')||b.typeId.includes('fire')||b.typeId==='minecraft:cactus'||b.typeId==='minecraft:magma');
    return a && b && g && !danger(a) && !danger(b) && !danger(g) &&
      !isSolidAt(dim,body) && !isSolidAt(dim,head) && isSolidAt(dim,ground);
  }catch{return false;}
}
function pushOutOfDomain(zone,e){
  if(!domainEntity(e))return;
  const p=e.location, c=zone.center;
  const dx=p.x-c.x,dz=p.z-c.z;
  const direction=Math.atan2(dz,dx);
  const outward=zone.radius+1.6;
  // 지면이 안전한 지점을 여러 방향/높이에서 찾는다.
  for(const offset of [0,.25,-.25,.6,-.6,1.15,-1.15,Math.PI]){
    const ang=direction+offset;
    for(const distance of [outward,outward+2]){
      for(const dy of [0,1,-1,2,-2]){
        const to={x:c.x+Math.cos(ang)*distance,y:p.y+dy,z:c.z+Math.sin(ang)*distance};
        if(!safeOutside(zone,to))continue;
        try{e.teleport(to,{dimension:zone.dim,keepVelocity:false});return;}catch{}
      }
    }
  }
  // 안전한 발판이 없으면 외측으로 밀고, 다음 검사 틱에 다시 방출을 시도한다.
  try{
    const n=Math.hypot(dx,dz)||1;
    e.applyKnockback(dx/n,dz/n,2*ccScale(e),0.12*ccScale(e));
  }catch{}
}
function domainVisual(zone,now){
  const dim=zone.dim,r=zone.radius,c=zone.center;
  const count=34;
  for(let i=0;i<count;i++){
    const a=2*Math.PI*i/count + now*.011;
    particle(dim,FEAR,{x:c.x+Math.cos(a)*r,y:c.y+.18,z:c.z+Math.sin(a)*r});
  }
  for(let layer=1;layer<=3;layer++){
    const phi=layer*Math.PI/8,rr=r*Math.cos(phi),height=r*Math.sin(phi);
    const samples=layer===3?12:22;
    for(let j=0;j<samples;j++){
      const a=2*Math.PI*j/samples-now*.01;
      particle(dim,layer===2?SOUL:FEAR,{x:c.x+Math.cos(a)*rr,y:c.y+height,z:c.z+Math.sin(a)*rr});
    }
  }
  for(let i=0;i<6;i++){
    const a=2*Math.PI*i/6+now*.005;
    particle(dim,SOUL,{x:c.x+Math.cos(a)*(r*.58),y:c.y+.8+(i%3)*1.2,z:c.z+Math.sin(a)*(r*.58)});
  }
}
function chooseDomainTarget(p,radius){
  const center=p.location;
  const candidates=getTargets(p,center,radius,0).filter(e=>enemy(p,e) && domainEntity(e));
  if(!candidates.length)return null;
  const view=p.getViewDirection();
  // 정면에 있는 적을 우선, 없으면 근접한 적 1명.
  candidates.sort((a,b)=>{
    const score=e=>{
      const at=e.location,dx=at.x-center.x,dz=at.z-center.z,dy=at.y-center.y;
      const dist=Math.hypot(dx,dy,dz)||1;
      const aligned=(dx*view.x+dy*view.y+dz*view.z)/dist;
      return (aligned>=.72?100:0)+aligned*10-dist*.2;
    };
    return score(b)-score(a);
  });
  return candidates[0];
}
function domain(p,job,def){
  const target=chooseDomainTarget(p,def.radius);
  if(!target){notify(p,'§7영역전개: 지름 15블록 안에 격리할 적이 없습니다.');return false;}
  const now=system.currentTick;
  const zone={owner:p,target,dim:p.dimension,center:{...p.location},radius:def.radius,until:now+ccTicks(target,def.duration),exited:new Set()};
  domains.set(p.id,zone);
  // 시전자와 선택한 대상 이외의 모든 살아있는 엔티티를 내보냄.
  try{
    for(const e of zone.dim.getEntities({location:zone.center,maxDistance:def.radius+2})){
      if(!domainEntity(e)||e.id===p.id||e.id===target.id)continue;
      if(domainInside(zone,e.location))pushOutOfDomain(zone,e);
    }
  }catch{}
  try{applyStatus(target,'hunger',def.hungerRefresh,{amplifier:def.hungerAmplifier,showParticles:false});}catch{}
  sound(zone.dim,'mob.wither.spawn',zone.center,{volume:.9,pitch:.55});
  ring(zone.dim,{x:zone.center.x,y:zone.center.y+.3,z:zone.center.z},def.radius,44,FEAR);
  domainVisual(zone,now);
  notify(p,'§4영역전개: §f한 명을 남기고 격리 · 10초간 외부 진입 차단 · 허기 V');
  return true;
}
function updateDomains(now){
  for(const [ownerId,zone] of domains){
    if(now>=zone.until || !zone.owner?.isValid || zone.owner.dimension.id!==zone.dim.id){
      domains.delete(ownerId);continue;
    }
    if(now%10===0)domainVisual(zone,now);
    // 선택된 적은 내부에 있는 동안 허기 V(레벨 5) 재부여.
    try{
      if(now%20===0 && domainEntity(zone.target) && zone.target.dimension.id===zone.dim.id && domainInside(zone,zone.target.location)){
        applyStatus(zone.target,'hunger',SKILLS.demon_domain.hungerRefresh,{amplifier:4,showParticles:false});
      }
    }catch{}
    // 외부에서 들어온 모든 엔티티는 경계 밖으로 복귀시킨다. 최초의 두 대상도
    // 일단 빠져나가면 다시 들어올 수 없다.
    for(const accepted of [zone.owner,zone.target]){
      try{
        if(accepted?.isValid && accepted.dimension.id===zone.dim.id && !domainInside(zone,accepted.location))zone.exited.add(accepted.id);
      }catch{}
    }
    try{
      for(const e of zone.dim.getEntities({location:zone.center,maxDistance:zone.radius+2})){
        if(!domainEntity(e) || !domainInside(zone,e.location))continue;
        const initiallyAllowed=(e.id===zone.owner.id || e.id===zone.target.id) && !zone.exited.has(e.id);
        if(!initiallyAllowed)pushOutOfDomain(zone,e);
      }
    }catch{}
  }
}
export const RUNNERS={
  demon_fear:fear,
  demon_vampirism:vampirism,
  demon_reap:reap,
  demon_contract:contract,
  demon_storm:storm,
  demon_domain:domain,
};

// 패시브 '영혼 수확': 악마가 엔티티를 쓰러뜨릴 때 HP 6(체력 3칸) 즉시 회복
// + 재생 II 5초. 자신/아군 처치는 제외.
export function registerDemon() {
  if(registered)return;
  registered=true;
  system.runInterval(()=>updateDomains(system.currentTick),2);
  world.afterEvents.playerLeave.subscribe(ev=>domains.delete(ev.playerId));
  world.afterEvents.entityDie.subscribe(ev=>{
    try{
      let killer=ev.damageSource?.damagingEntity;
      if(killer?.typeId!=="minecraft:player") {
        killer=ev.damageSource?.damagingProjectile?.getComponent("minecraft:projectile")?.owner;
      }
      if(killer?.typeId!=="minecraft:player" || getJobId(killer)!=="demon") return;
      const dead=ev.deadEntity;
      if(!dead || dead.id===killer.id || areAllies(killer,dead))return;
      const hp=killer.getComponent("minecraft:health");
      if(!hp)return;
      const cap=hp.effectiveMax??hp.defaultValue??20;
      hp.setCurrentValue(Math.min(cap,hp.currentValue+healingFor(killer,6)));
      applyEffect(killer,"regeneration",100,1);
      particle(killer.dimension,SOUL,pos(killer,1.3));
      sound(killer.dimension,"random.orb",killer.location,{volume:.6,pitch:.7});
    }catch{}
  });
}

// Borrowed spells use MAG just like their original spell class.
function hurt(target,source,amount,type="magic"){return hurtBase(target,source,amount,type);}
