import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import { areAllies } from "../core/social.js";
import { world, system, EquipmentSlot, ItemStack } from '@minecraft/server';
import { CONFIG } from '../config.js';
import { getJobId } from '../core/playerData.js';
import { getTargets, healthAlive, hurt as hurtBase, particle, sound, norm3, flatDir, headPos, dist3, isSolidAt, aimPoint } from '../core/util.js';
import { notify } from '../core/hud.js';

// 마법공학사: 작은 청록색 기계 파티클. 아군은 기존 rpg_team_ 태그로 판단.
const RAY='rpg:tech_beam';
const ARC='rpg:tech_arc';
const MARK='rpg:tech_mark';
const DOME='rpg:tech_prison_glow';
const GLEAM='rpg:tech_prison_gleam';
const SHARD='rpg:tech_prison_shard';
const PRISON_VISUAL='rpg:tech_prison_dome';
const TEAM='rpg_team_';
const ARM='rpg:tech_aux_arm';
const markMap=new Map(); // entity id -> {entity, until}
const burned=[];         // {owner, dimension, point, until, next}
const cages=[];          // {owner,dimension,center,until, radius}
let started=false;

function alive(e){try{return !!e?.isValid && healthAlive(e);}catch{return false;}}
function ally(p,e){
  if(areAllies(p,e)) return true;
  if(p.id===e.id) return true;
  if(e.typeId!=='minecraft:player')return false;
  if(!CONFIG.pvp)return true;
  const t=p.getTags().find(x=>x.startsWith(TEAM));
  return !!t && e.getTags().includes(t);
}
function enemy(p,e){return alive(e)&&!ally(p,e);}
function center(e,height=1){const q=e.location;return {x:q.x,y:q.y+height,z:q.z};}
function fx(dim,id,p){particle(dim,id,p);}
function circle(dim,point,r,particleName,n=20,offset=0){
  for(let i=0;i<n;i++){
    const a=(i/n)*Math.PI*2+offset;
    fx(dim,particleName,{x:point.x+Math.cos(a)*r,y:point.y,z:point.z+Math.sin(a)*r});
  }
}
// 마공학 감옥: 반투명 보랏빛 돔 + 푸른 발광점 + 떠오르는 파편.
// 시각 이펙트는 별도 엔티티(투명 돔)와 파티클을 병행해 표시한다.
function prisonVisual(cage, now){
  const dim=cage.dim, p=cage.center, r=cage.radius;
  const cy=p.y+0.18;
  // 하단 굵은 링, 천장으로 올라가는 얇은 나선형 자오선.
  circle(dim,{x:p.x,y:cy,z:p.z},r,DOME,32,now*.015);
  circle(dim,{x:p.x,y:cy+.18,z:p.z},r-.14,GLEAM,20,-now*.009);
  for(let j=1;j<=3;j++){
    const phi=j*Math.PI/8;
    const ringR=r*Math.cos(phi);
    const h=r*.91*Math.sin(phi);
    circle(dim,{x:p.x,y:cy+h,z:p.z},ringR,j===2?DOME:GLEAM,Math.max(9,27-j*5),now*(j%2?.018:-.012));
  }
  // 구면을 감싸는 여섯 개의 빛줄기. 단순 평면 원이 아니라 3차원 돔 형태로 보이게 함.
  for(let strand=0;strand<6;strand++){
    const theta=strand*Math.PI/3+now*.007;
    for(let j=1;j<=5;j++){
      const phi=j*Math.PI/11;
      const a=theta+phi*.17;
      fx(dim,j%2?DOME:GLEAM,{
        x:p.x+Math.cos(a)*r*Math.cos(phi),
        y:cy+r*.91*Math.sin(phi),
        z:p.z+Math.sin(a)*r*Math.cos(phi)
      });
    }
  }
  // 보랏빛 내부 구름: 작은 반투명 원형 광원들.
  for(let i=0;i<6;i++){
    const a=i*2.399963+now*.004;
    const rr=r*(.18+.1*(i%5));
    fx(dim,DOME,{x:p.x+Math.cos(a)*rr,y:cy+.5+(i%3)*.75,z:p.z+Math.sin(a)*rr});
  }
  // 참고 이미지의 네 개 청록색 점광원과 부유하는 돌 파편.
  for(let i=0;i<4;i++){
    const a=(i/4)*Math.PI*2+Math.PI/4;
    const node={x:p.x+Math.cos(a)*(r-.13),y:cy+.5+(i%2)*.6,z:p.z+Math.sin(a)*(r-.13)};
    fx(dim,GLEAM,node);
    fx(dim,ARC,{x:node.x,y:node.y+.16,z:node.z});
  }
  for(let i=0;i<7;i++){
    const a=i*2.399963;
    const rr=r*(.2+.095*(i%5));
    const hover=.14*Math.sin(now*.08+i);
    fx(dim,SHARD,{x:p.x+Math.cos(a)*rr,y:cy+.7+.24*(i%5)+hover,z:p.z+Math.sin(a)*rr});
  }
}
function spawnPrisonVisual(cage){
  try{
    const v=cage.dim.spawnEntity(PRISON_VISUAL,{x:cage.center.x,y:cage.center.y,z:cage.center.z});
    cage.visualEntity=v;
  }catch{ /* 비지원 환경에서도 파티클 감옥은 작동한다. */ }
}
function removePrisonVisual(cage){
  try{if(cage.visualEntity?.isValid)cage.visualEntity.remove();}catch{}
}
function beamStart(p){
  const l=p.location,d=flatDir(p),right={x:-d.z,z:d.x};
  // 3인칭 기계팔의 끝부분에 맞춘 시점. 실제 모델은 body 기준으로 부착됨.
  return {x:l.x-d.x*.37+right.x*.65,y:l.y+2.2,z:l.z-d.z*.37+right.z*.65};
}
function nextMarkTarget(p,range){
  let target=null,best=Infinity;
  for(const [key,obj] of markMap){
    const t=obj.entity;
    if(system.currentTick>=obj.until||!alive(t)){markMap.delete(key);continue;}
    if(t.dimension.id!==p.dimension.id||!enemy(p,t))continue;
    const dist=dist3(t.location,p.location);
    if(dist<=range && dist<best){best=dist;target=t;}
  }
  return target;
}
function addMark(t,ticks){
  if(!alive(t))return;
  markMap.set(t.id,{entity:t,until:system.currentTick+ticks});
  circle(t.dimension,center(t,1.15),.52,MARK,8);
}
function ray(p,job,def){
  const dim=p.dimension,dir=norm3(p.getViewDirection()),origin=beamStart(p),hit=new Set(),marks=[];
  sound(dim,'mob.guardian.attack',p.location,{volume:.8,pitch:.95});
  circle(dim,origin,.38,ARC,10);
  let range=0;
  // 관통형 직선 광선. 스킬의 최대 길이만큼 기계팔 끝에서 생성한다.
  for(let d=.25;d<=def.range;d+=.35){
    const v={x:origin.x+dir.x*d,y:origin.y+dir.y*d,z:origin.z+dir.z*d};
    if(isSolidAt(dim,v)){break;}
    range=d;
    if(Math.round(d*100)%3!==0)fx(dim,RAY,v);
    if(Math.round(d*10)%7<3)fx(dim,ARC,{x:v.x,y:v.y+.12,z:v.z});
    for(const t of getTargets(p,v,1.25,.9)){
      if(!enemy(p,t)||hit.has(t.id))continue;
      hit.add(t.id);
      hurt(t,p,def.damage);
      fx(dim,ARC,center(t,1));
    }
    // 지면을 불태우는 표시 (실제 블록 교체 없이 피해 판정만 남김).
    if(Math.round(d*10)%16<4){
      for(let down=0;down<=3;down+=.5){
        const q={x:v.x,y:v.y-down,z:v.z};
        if(isSolidAt(dim,q)){
          marks.push({x:v.x,y:Math.floor(q.y)+1.05,z:v.z});
          break;
        }
      }
    }
  }
  // 시각적으로 작고 얇은 바닥 화상 궤적. 벽/블럭은 변경하지 않음.
  for(let i=0;i<marks.length;i+=2){
    burned.push({owner:p,dim,point:marks[i],until:system.currentTick+def.groundTicks,next:system.currentTick+10});
  }
  notify(p,`§b마공학 광선: §f${hit.size}명 관통 · 바닥 에너지 잔류`);
  return true;
}
function prison(p,job,def){
  const dim=p.dimension,at=aimPoint(p,def.castRange).point;
  // 허공 조준 시에도 바닥 근처로 위치 조정
  let cy=at.y;
  for(let n=0;n<6;n++){if(isSolidAt(dim,{x:at.x,y:cy-1,z:at.z}))break;cy-=1;}
  const cage={owner:p,dim,center:{x:at.x,y:cy,z:at.z},radius:def.radius,until:system.currentTick+def.duration};
  cages.push(cage);
  spawnPrisonVisual(cage);
  sound(dim,'beacon.activate',cage.center,{volume:.8,pitch:1.35});
  prisonVisual(cage,system.currentTick);
  notify(p,'§b마공학 감옥: §f감속 60% · 표식 10초');
  return true;
}
function sphere(p,job,def){
  const target=nextMarkTarget(p,def.range);
  if(!target){notify(p,'§7마공학 구체: 사거리 안에 표식이 붙은 적이 없습니다.');return false;}
  const dim=p.dimension; let point=beamStart(p);let passed=0;
  sound(dim,'mob.guardian.attack',p.location,{volume:.6,pitch:1.4});
  const ticker=system.runInterval(()=>{
    try{
      if(!p.isValid||!alive(target)||target.dimension.id!==dim.id){system.clearRun(ticker);return;}
      const t=center(target,1);
      const dx=t.x-point.x,dy=t.y-point.y,dz=t.z-point.z,d=Math.hypot(dx,dy,dz);
      const step=Math.min(d,def.speed);
      if(d>.001){point={x:point.x+dx/d*step,y:point.y+dy/d*step,z:point.z+dz/d*step};}
      fx(dim,ARC,point);fx(dim,RAY,{x:point.x+.11,y:point.y+.04,z:point.z});
      if(d<=1.2||++passed>=140){
        hurt(target,p,def.damage);
        circle(dim,t,.6,ARC,14);
        sound(dim,'random.explode',t,{volume:.4,pitch:1.4});
        system.clearRun(ticker);
      }
    }catch{system.clearRun(ticker);}
  },1);
  return true;
}
function bomb(p,job,def){
  const target=nextMarkTarget(p,def.range);
  if(!target){notify(p,'§7마공학 폭탄: 사거리 안에 표식이 붙은 적이 없습니다.');return false;}
  const dim=p.dimension;
  sound(dim,'random.click',target.location,{volume:.65,pitch:1.3});
  let counter=0;
  const ticker=system.runInterval(()=>{
    try{
      if(!p.isValid||!alive(target)||target.dimension.id!==dim.id){system.clearRun(ticker);return;}
      counter+=2;
      const at=center(target,1);
      if(counter%8===0) circle(dim,at,.5,MARK,10,counter*.12);
      if(counter<def.fuseTicks)return;
      hurt(target,p,def.damage);
      for(const e of getTargets(p,target.location,def.splashRadius)){
        if(enemy(p,e)&&e.id!==target.id)hurt(e,p,def.splashDamage);
      }
      circle(dim,at,def.splashRadius,ARC,18);
      sound(dim,'random.explode',target.location,{volume:.8,pitch:1});
      system.clearRun(ticker);
    }catch{system.clearRun(ticker);}
  },2);
  return true;
}
function storm(p,job,def){
  const dim=p.dimension,target=nextMarkTarget(p,def.followRange);
  let centerPos=target?{...target.location}:{...aimPoint(p,Math.min(def.followRange,18)).point};
  let ticks=0;
  sound(dim,'mob.guardian.attack',p.location,{volume:1,pitch:.55});
  const ticker=system.runInterval(()=>{
    try{
      if(!p.isValid||p.dimension.id!==dim.id||ticks>=def.duration){system.clearRun(ticker);return;}
      ticks+=5;
      // 추적 중 표식이 사라지면 현재 자리에 정지한다.
      const isMarked=target&&alive(target)&&target.dimension.id===dim.id&&markMap.has(target.id)&&markMap.get(target.id).until>system.currentTick;
      if(isMarked)centerPos={...target.location};
      const top={x:centerPos.x,y:centerPos.y+2,z:centerPos.z};
      circle(dim,{x:top.x,y:centerPos.y+.25,z:top.z},def.radius,RAY,24,ticks*.08);
      circle(dim,{x:top.x,y:centerPos.y+3.7,z:top.z},def.radius*.76,ARC,18,-ticks*.11);
      for(let i=0;i<20;i++){
        const a=i*2.39996+ticks*.17;
        const r=def.radius*Math.sqrt((i%8+.5)/9);
        fx(dim,i%3===0?MARK:ARC,{x:top.x+Math.cos(a)*r,y:centerPos.y+.5+(i*7%29)/8,z:top.z+Math.sin(a)*r});
      }
      if(ticks%10===0){
        for(const e of getTargets(p,centerPos,def.radius)){
          if(!enemy(p,e))continue;
          hurt(e,p,def.damagePerPulse);
        }
      }
    }catch{system.clearRun(ticker);}
  },5);
  notify(p,target?'§b마공학 폭풍: §f표식 대상 추적 시작':'§b마공학 폭풍: §f표식이 없어 제자리 유지');
  return true;
}

export const RUNNERS={tech_ray:ray,tech_prison:prison,tech_sphere:sphere,tech_bomb:bomb,tech_storm:storm};

export function registerTechnomancer(){
  if(started)return;started=true;
  // 기계팔을 보조손에 자동 장착. 다른 직업으로 변경하면 정리하되 다른 장비는 보존.
  system.runInterval(()=>{
    const now=system.currentTick;
    for(const p of world.getAllPlayers()){
      try{
        const eq=p.getComponent('minecraft:equippable');
        if(!eq)continue;
        const off=eq.getEquipment(EquipmentSlot.Offhand);
        if(getJobId(p)==='technomancer'){
          if(!off){eq.setEquipment(EquipmentSlot.Offhand,new ItemStack(ARM,1));}
        } else if(off?.typeId===ARM)eq.setEquipment(EquipmentSlot.Offhand,undefined);
      }catch{}
    }
    for(const [id,m] of markMap){if(now>=m.until||!alive(m.entity))markMap.delete(id);}
    for(let i=cages.length-1;i>=0;i--){
      const c=cages[i];
      if(now>=c.until||!c.owner.isValid){removePrisonVisual(c);cages.splice(i,1);continue;}
      if(now%10!==0)continue;
      prisonVisual(c,now);
      for(const e of getTargets(c.owner,c.center,c.radius)){
        if(!enemy(c.owner,e))continue;
        try{applyStatus(e,'slowness',30,{amplifier:3,showParticles:false});}catch{}
        addMark(e,200); // 10초 표식, 감옥 체류 중에는 갱신
      }
    }
    for(let i=burned.length-1;i>=0;i--){
      const b=burned[i];
      if(now>=b.until||!b.owner.isValid){burned.splice(i,1);continue;}
      if(now%10===0)fx(b.dim,RAY,b.point);
      if(now<b.next)continue;
      b.next=now+20;
      for(const e of getTargets(b.owner,b.point,1.2,.8)){
        if(enemy(b.owner,e))hurt(e,b.owner,4);
      }
    }
  },5);
  world.afterEvents.playerLeave.subscribe(e=>{
    for(let i=cages.length-1;i>=0;i--)if(cages[i].owner.id===e.playerId){removePrisonVisual(cages[i]);cages.splice(i,1);}
    for(let i=burned.length-1;i>=0;i--)if(burned[i].owner.id===e.playerId)burned.splice(i,1);
  });
}

function hurt(target,source,amount,type="magic"){return hurtBase(target,source,amount,type);}
