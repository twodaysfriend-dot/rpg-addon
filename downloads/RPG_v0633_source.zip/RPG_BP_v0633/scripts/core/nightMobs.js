import {keepTownZombie} from './townZombies.js';
import {world,system,EntityInitializationCause} from '@minecraft/server';
import {ZONED_MOBS} from '../data/huntingZones.js';

// 밤 몬스터 정리: 밤에 자연 스폰되는 바닐라 적대 몬스터의 절반만 남기고,
// 남은 몬스터는 표식을 달았다가 아침이 되면 전부 제거해 렉을 줄입니다.
// 사냥터의 밤 RPG 몬스터는 기존보다 절반인 유지율 25%를 적용합니다.
// 던전 몬스터·보스·알로 직접 소환한 몬스터·이름표가 붙은 몬스터는 건드리지 않습니다.
const TAG='rpg_night_spawn',ROLLED='rpg_night_rolled';
const SPAWN_KEEP_RATE=0.5; // 바닐라 유지
const RPG_SPAWN_KEEP_RATE=0.25; // 기존 RPG 유지율 0.5의 절반
const NIGHT_START=13000,NIGHT_END=23000;
const HOSTILE=new Set(['minecraft:zombie','minecraft:zombie_villager','minecraft:husk','minecraft:drowned','minecraft:skeleton','minecraft:stray','minecraft:bogged','minecraft:creeper','minecraft:spider','minecraft:witch','minecraft:phantom','minecraft:slime']);
let registered=false,wasNight=null;

const isNight=()=>{const t=world.getTimeOfDay();return t>=NIGHT_START&&t<NIGHT_END;};
const valid=e=>{try{return Boolean(e?.isValid);}catch{return false;}};
function naturalSpawn(cause){
  if(EntityInitializationCause&&EntityInitializationCause.Spawned!==undefined)return cause===EntityInitializationCause.Spawned;
  return String(cause)==='Spawned';
}
function purge(){
  for(const id of ['overworld']){
    try{for(const e of world.getDimension(id).getEntities({tags:[TAG]}))try{if(!keepTownZombie(e))e.remove();}catch{}}catch{}
  }
}
export function registerNightMobs(){
  if(registered)return;registered=true;
  world.afterEvents.entitySpawn.subscribe(ev=>{
    try{
      const e=ev.entity;
      if(keepTownZombie(e))return;
      if(valid(e)&&ZONED_MOBS.has(e.typeId)&&e.dimension.id==='minecraft:overworld'&&isNight()){
        // 사냥터 판정 및 교체 소환 뒤 1회 추첨. 알/던전은 PROCESSED 태그가 없어 제외.
        system.runTimeout(()=>{try{
          if(!valid(e)||e.hasTag(ROLLED)||e.hasTag('rpg_dungeon_mob')||!e.hasTag('rpg_hunt_zoned')||e.nameTag)return;
          e.addTag(ROLLED);
          if(!isNight()||Math.random()>=RPG_SPAWN_KEEP_RATE)e.remove();else e.addTag(TAG);
        }catch{}},3);
        return;
      }
      if(!valid(e)||!HOSTILE.has(e.typeId)||!naturalSpawn(ev.cause))return;
      if(e.dimension.id!=='minecraft:overworld'||!isNight())return;
      if(e.nameTag)return;
      if(Math.random()>=SPAWN_KEEP_RATE){system.run(()=>{try{if(valid(e)&&!keepTownZombie(e))e.remove();}catch{}});return;}
      e.addTag(TAG);
    }catch{}
  });
  // 아침이 되는 순간 표식이 붙은 몬스터를 모두 제거
  system.runInterval(()=>{
    try{
      const night=isNight();
      if(wasNight===true&&!night)purge();
      wasNight=night;
    }catch{}
  },20);
  // 로드되지 않았다가 아침에 불려온 몬스터와 남은 표식 몬스터 정리
  world.afterEvents.entityLoad.subscribe(ev=>{try{if(!isNight()&&valid(ev.entity)&&ev.entity.hasTag(TAG)&&!keepTownZombie(ev.entity))ev.entity.remove();}catch{}});
  system.runInterval(()=>{try{if(!isNight())purge();}catch{}},200);
}
