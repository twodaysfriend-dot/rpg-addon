import {world,system,EntityInitializationCause} from '@minecraft/server';
import {spawnRegion,insideSpawn} from './spawnEffects.js';
export const ZOMBIE_NATURAL='rpg_town_zombie_natural',ZOMBIE_KEPT='rpg_town_zombie_kept';
const eggs=[];let registered=false;
const inside=e=>insideSpawn(e,spawnRegion());
function noteEgg(ev){try{
 if(ev.itemStack?.typeId!=='minecraft:zombie_spawn_egg')return;
 const p=ev.source??ev.player;if(!p)return;
 const at=ev.block?.location??p.location;
 if(eggs.some(r=>r.player===p.id&&r.tick===system.currentTick))return;
 eggs.push({player:p.id,at:{...at},dim:p.dimension.id,tick:system.currentTick});while(eggs.length>32)eggs.shift();
}catch{}}
function eggMatches(e){
 const index=eggs.findIndex(r=>r.dim===e.dimension.id&&system.currentTick-r.tick>=0&&system.currentTick-r.tick<=8&&Math.hypot(e.location.x-r.at.x,e.location.y-r.at.y,e.location.z-r.at.z)<=10);
 if(index<0)return false;eggs.splice(index,1);return true;
}
export function keepTownZombie(e){
 if(e?.typeId!=='minecraft:zombie')return false;
 if(e.hasTag?.(ZOMBIE_KEPT))return true;
 if(!inside(e))return false;
 if((e.hasTag?.('rpg_town_manual_spawn')&&!e.hasTag?.('rpg_hunt_zoned'))||eggMatches(e)){e.removeTag?.(ZOMBIE_NATURAL);e.addTag(ZOMBIE_KEPT);return true;}
 if(e.hasTag?.(ZOMBIE_NATURAL))return false;
 // Unmarked existing/load/transported zombies are retained, never guessed natural.
 e.addTag(ZOMBIE_KEPT);e.removeTag?.('rpg_night_spawn');return true;
}
export function noteTownZombieSpawn(e,cause){
 if(e?.typeId!=='minecraft:zombie'||!inside(e))return;
 if(cause===(EntityInitializationCause?.Spawned??'Spawned')){
  e.addTag(ZOMBIE_NATURAL);
  if(eggMatches(e)){e.removeTag?.(ZOMBIE_NATURAL);e.addTag(ZOMBIE_KEPT);}
 }else if(!e.hasTag?.(ZOMBIE_NATURAL)){e.addTag(ZOMBIE_KEPT);}
}
export function registerTownZombies(){
 if(registered)return;registered=true;
 world.beforeEvents?.itemUse?.subscribe(noteEgg);world.beforeEvents?.playerInteractWithBlock?.subscribe(noteEgg);world.afterEvents.itemUse.subscribe(noteEgg);
 world.afterEvents.entitySpawn.subscribe(ev=>{try{noteTownZombieSpawn(ev.entity,ev.cause);if(ev.entity?.typeId==='minecraft:zombie'&&ev.entity.hasTag?.(ZOMBIE_NATURAL))system.runTimeout(()=>{try{if(!keepTownZombie(ev.entity))ev.entity.remove();}catch{}},4);}catch(error){console.warn('[RPG town zombie] '+error);}});
}
