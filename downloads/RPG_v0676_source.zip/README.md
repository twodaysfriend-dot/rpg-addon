# RPG v0.6.76 · 감옥 명령 수정

Bedrock 채팅에서 명령어 이름 앞에 `rpg:`를 붙여 사용하세요.

- `/rpg:jailcreate`는 오버월드의 빈 공간에 감옥 10칸을 생성합니다. 높이를 생략하면 서 있는 높이보다 한 칸 아래를 바닥으로 사용합니다. `/rpg:jailcreate 100`처럼 바닥 Y를 지정할 수도 있습니다.
- `/rpg:jailreset`은 실행한 관리자의 PK 스택과 수감 배율을 초기화합니다. 다른 사람의 기록은 `/rpg:jailreset "플레이어 이름"`으로 초기화할 수 있습니다. 초기화 시 수감 중인 플레이어의 남은 형기는 5분으로 재설정됩니다.
- 관리 명령은 운영자 권한이 필요합니다. 실행이 막히면 높이 오류, 공간 부족 또는 기록 없음의 원인을 채팅에 표시합니다. 감옥 명령은 게임플레이 팩에서 직접 처리합니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.76으로 활성화하고 월드를 다시 여세요. 모의 명령 등록과 실행으로 높이 생략, 감옥 10칸 생성, 본인·오프라인 플레이어 기록 초기화, 권한 검사와 실패 메시지를 확인했습니다. 실제 Bedrock 월드에서는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0676
```
