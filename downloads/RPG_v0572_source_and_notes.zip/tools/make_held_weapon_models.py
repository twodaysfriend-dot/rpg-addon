"""Create upright double-size item meshes in the native trident hand frame.

Read PNGs only. No resampling, recoloring, or per-pixel edge cubes. Match the
pinned vanilla trident skeleton and first/third-person wield animations.
"""
from pathlib import Path
import json,math
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];RP=ROOT/'RPG_RP_v0572';BP=ROOT/'RPG_BP_v0572'
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sprite_axes(image):
 points=[(x,y) for y in range(image.height) for x in range(image.width) if image.getpixel((x,y))[3]>=128]
 if not points:return image.width/2,image.height*.8,0
 cx=sum(x for x,y in points)/len(points);cy=sum(y for x,y in points)/len(points)
 xx=sum((x-cx)**2 for x,y in points);yy=sum((y-cy)**2 for x,y in points);xy=sum((x-cx)*(y-cy) for x,y in points)
 angle=.5*math.atan2(2*xy,xx-yy);ux,uy=math.cos(angle),math.sin(angle)
 if uy>0:ux,uy=-ux,-uy
 lo,hi=min((x-cx)*ux+(y-cy)*uy for x,y in points),max((x-cx)*ux+(y-cy)*uy for x,y in points)
 # Broad books/cores use their natural upright axis rather than a noisy diagonal.
 major=(xx+yy+math.hypot(xx-yy,2*xy))/2;minor=(xx+yy-math.hypot(xx-yy,2*xy))/2
 if major<minor*2:ux,uy=0,-1;lo,hi=min(-(y-cy) for x,y in points),max(-(y-cy) for x,y in points)
 p=lo+(hi-lo)*.12
 return cx+ux*p,cy+uy*p,math.degrees(math.atan2(ux,-uy))
def main():
 atlas=json.loads((RP/'textures/item_texture.json').read_text())['texture_data']
 raw=(BP/'scripts/data/classWeapons.js').read_text();classes=json.loads(raw.split('Object.freeze(',1)[1].split(');',1)[0])
 common=json.loads((BP/'scripts/data/commonWeapons.js').read_text().split('=',1)[1].strip().rstrip(';'))
 excluded={'rpg:war_god_gauntlets','rpg:fighter_fist','rpg:fist_bone_fist','rpg:apprentice_fist'}
 specs=[];geometries=[]
 for entry in common+classes:
  id=entry['id'];key=id[4:]
  if id in excluded:continue
  item=json.loads((BP/'items'/(key+'.json')).read_text())['minecraft:item'];texture=atlas[item['components']['minecraft:icon']]['textures']
  image=Image.open(RP/(texture+'.png')).convert('RGBA');gx,gy,turn=sprite_axes(image);unit=32/image.width
  bones=[{'name':'pole','binding':'q.item_slot_to_bone_name(c.item_slot)','pivot':[0,24,0]},
   {'name':'sprite','parent':'pole','pivot':[0,0,0],'rotation':[0,0,turn], 'cubes':[{'origin':[-gx*unit,(gy-image.height)*unit,-.075],
    'size':[32,image.height*unit,.15], 'uv':{'north':{'uv':[image.width,0],'uv_size':[-image.width,image.height]},'south':{'uv':[0,0],'uv_size':[image.width,image.height]}}}]}]
  gid='geometry.rpg.upright.'+key
  geometries.append({'description':{'identifier':gid,'texture_width':image.width,'texture_height':image.height,'visible_bounds_width':6,'visible_bounds_height':6,'visible_bounds_offset':[0,1.5,0]},'bones':bones})
  write(RP/'attachables'/(key+'.json'),{'format_version':'1.10.0','minecraft:attachable':{'description':{'identifier':id,'materials':{'default':'entity_alphatest','enchanted':'entity_alphatest_glint'},
   'textures':{'default':texture,'enchanted':'textures/misc/enchanted_item_glint'},'geometry':{'default':gid},'animations':{'first':'animation.rpg.upright.first','third':'animation.rpg.upright.third'},
   'scripts':{'animate':[{'first':'context.is_first_person'},{'third':'!context.is_first_person'}]},'render_controllers':['controller.render.item_default']}}})
  for base in [RP,BP]:
   f=base/'items'/(key+'.json')
   if f.exists():
    d=json.loads(f.read_text());d['minecraft:item']['components'].pop('minecraft:render_offsets',None);d['minecraft:item']['components']['minecraft:hand_equipped']=True;write(f,d)
  specs.append({'id':id,'texture':texture,'nativeSide':16,'heldSide':32,'gripPixel':[gx,gy],'normalizeZ':turn})
 write(RP/'models/entity/upright_weapons.geo.json',{'format_version':'1.16.0','minecraft:geometry':geometries})
 write(RP/'animations/upright_weapons.animation.json',{'format_version':'1.10.0','animations':{'animation.rpg.upright.first':{'loop':True,'bones':{'pole':{'rotation':[152,-9,25],'position':[-7,-3,-2]}}},'animation.rpg.upright.third':{'loop':True,'bones':{'pole':{'rotation':[97,-1.5,-49],'position':[1.5,-2.5,-10.5]}}}}})
 write(ROOT/'held_weapon_pose.json',{'frame':'vanilla trident v1.21.100.6','handPivot':[0,24,0],'items':specs})
 private=RP/'models/entity/war_god_private.geo.json'
 if private.exists():
  g=json.loads(private.read_text());cube=g['minecraft:geometry'][0]['bones'][0]['cubes'][0];cube['origin']=[-8,0,-.1];cube['size']=[16,16,.2];write(private,g)
 print('Built',len(specs),'upright double-size models without editing PNGs.')
if __name__=='__main__':main()
