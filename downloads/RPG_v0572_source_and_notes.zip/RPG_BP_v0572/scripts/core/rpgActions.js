import {openFusionMenu} from './fusion.js';
import {openPvp} from './pvp.js';
import {spawnGptNpc} from './gptNpc.js';
import {createTemple,removeTemple,openTemple} from './temples.js';
import {openArmorTransfer} from './armorTransfer.js';
import {askRpg} from './rpgAssistant.js';
import {createDungeon,enterDungeon,startDungeon,soloDungeon,leaveDungeon,openDungeons,removeDungeon,flushRewards} from './dungeons.js';
import {readAngelHealing} from './angelHealing.js';
import {claimDungeonLoot} from './dungeonRewards.js';
import { openRuneMenu } from './runeMenu.js';
import { openJobMenu } from './jobMenu.js';
import { openSkillGuide } from './skillGuide.js';
import { openEggMenu } from "./eggMenu.js";
import { openBeginnerGuide } from './beginner.js';
import { openEquipmentMenu } from './equipment.js';
import { openUpgradeMenu } from './upgrades.js';
import { openCraftingGuide } from './crafting.js';
import { openWalletMenu } from './wallet.js';
import { giveHitoEgg,openHitoEggMenu } from "./hito.js";
import { giveAdminTool } from "./adminTool.js";
import { CONFIG } from "../config.js";
import { giveRulebook } from "./rulebook.js";
import { openStatsMenu, statsSummary, forceSetLevel, getLevel } from "./stats.js";
import { openChameleonSkillbook, learnChameleonSkill, swapChameleonWeapon } from "./chameleon.js";
import { JOBS, findJob } from "../data/jobs.js";
import { SKILLS } from "../data/skills.js";
import {
  getJobId, getSkills, getMana, setMana, maxManaOf, manaText, maxManaText, getProgress, getDisabled, resetCooldowns, forceSetManaMax,
} from "./playerData.js";
import {
  requestAdvance, resetToApprentice, giveStarter, requirementStatus, giveAllItems,
} from "./advance.js";
import { offerItems, offerLight, craftHolyWater } from "./offer.js";
import { openSkillMenu } from "./skillMenu.js";
import { refreshHud } from "./hud.js";
import { toggleWings, inspectWings, refreshWings } from "./wings.js";
import { getFistCoatingStatus } from "./fistCoating.js";
import { openGuildMenu, openPartyMenu, openInvites } from "./social.js";

// 슬래시 명령어(/rpg:...)와 /scriptevent rpg:... 가 같은 동작을 하도록 한 곳에 모았습니다.
export const HELP =
  "§e사용법: /rpg:pvp [플레이어|accept|surrender] | /rpg:dungeon [1~10] | /rpg:dungeonstart | /rpg:dungeonsolo <1~10> | /rpg:dungeonleave | /rpg:dungeonloot | (관리자) /rpg:dungeoncreate <1~10|all> | /rpg:dungeonremove <이름> | /rpg:temple | (관리자) /rpg:templecreate | /rpg:templeremove | /rpg:transfer | /rpg:fuse | /rpg:ask [질문] | (관리자) /rpg:gptnpc | /rpg:skillguide | /rpg:runes | /rpg:jobs | /rpg:craft | /rpg:wallet | /rpg:upgrade | /rpg:equipment | /rpg:guide | /rpg:rulebook | /rpg:ping | /rpg:menu | /rpg:job <직업> | /rpg:status | /rpg:stats | /rpg:skills | /rpg:skillbook | /rpg:learn <ID> | /rpg:swap | /rpg:offer | /rpg:bless | /rpg:holywater | " +
  "/rpg:guild | /rpg:party | /rpg:invites | " +
  "(관리자) /rpg:admin (설정 도구) | /rpg:setlevel <1~100000> | /rpg:setmana <1~100000|reset> | /rpg:force <직업> | /rpg:reset | /rpg:starter <sword|mage|holy|fist|archer> | /rpg:items | /rpg:charge | /rpg:wings | /rpg:wingcheck | /rpg:wingrefresh | /rpg:fistcheck | /rpg:boss | /rpg:cyclops | /rpg:hydra | /rpg:techgolem";

// 공식 Player 권한 속성 사용. 2.0.0 환경에서 isOp() 메서드에 의존하지 않는다.
function isAdminPlayer(p){
  try { if (p.playerPermissionLevel === 2) return true; } catch {}
  try { if (typeof p.commandPermissionLevel === 'number' && p.commandPermissionLevel >= 1) return true; } catch {}
  try { if (typeof p.isOp === 'function' && p.isOp()) return true; } catch {}
  return false;
}

export function runRpgAction(action, p, arg = "") {
  const text = String(arg ?? "").trim();
  // /scriptevent / !rpg 경로에도 등록 명령어와 동일한 관리자 권한을 적용.
  const adminOnly = new Set(["gptnpc","force", "reset", "starter", "items", "egg", "charge", "boss", "cyclops", "hydra", "techgolem", "hito", "setlevel", "setmana", "admin", "dungeoncreate", "dungeonremove", "templecreate", "templeremove"]);
  if (adminOnly.has(action) && !isAdminPlayer(p)) {
    p.sendMessage("§c[RPG] 이 명령어는 관리자만 사용할 수 있습니다.");
    return;
  }
  switch (action) {
    case 'pvp':return openPvp(p,text);
    case 'gptnpc':return spawnGptNpc(p);
    case 'temple': return openTemple(p);
    case 'templecreate': try{return createTemple(p);}catch(error){p.sendMessage('§e'+String(error.message??error));return;}
    case 'templeremove': try{return removeTemple(p);}catch(error){p.sendMessage('§e'+String(error.message??error));return;}
    case 'fuse': return openFusionMenu(p);
    case 'transfer': return openArmorTransfer(p);
    case 'ask': return askRpg(p,text);
    case 'dungeon':
    case 'dungeonstart':
    case 'dungeonsolo':
    case 'dungeoncreate':
    case 'dungeonremove':
    case 'dungeonleave':
    case 'dungeonloot': {
      try {
        if(action==='dungeonstart')startDungeon(p);
        else if(action==='dungeonsolo')soloDungeon(p,text);
        else if(action==='dungeoncreate')createDungeon(p,text);
        else if(action==='dungeonremove')removeDungeon(p,text);
        else if(action==='dungeonleave')leaveDungeon(p);
        else if(action==='dungeonloot'){flushRewards();const r=claimDungeonLoot(p);p.sendMessage(`§a던전 보급품 ${r.delivered}개 수령 · 보관 중 ${r.pending}개`);}
        else if(text)enterDungeon(p,text);
        else openDungeons(p);
      }catch(error){p.sendMessage('§c[던전] '+String(error.message??error));}
      return;
    }
    case 'runes': openRuneMenu(p); return;
    case 'jobs': openJobMenu(p); return;
    case 'skillguide': openSkillGuide(p); return;
    case 'craft': openCraftingGuide(p); return;
    case 'upgrade': openUpgradeMenu(p); return;
    case 'wallet': openWalletMenu(p); return;
    case 'equipment': openEquipmentMenu(p); return;
    case 'guide': openBeginnerGuide(p); return;
    case "rulebook": giveRulebook(p); return;
    case "ping": p.sendMessage("§a[RPG] v0.5.72 스크립트 정상. 명령어가 목록에 안 보이면 !rpg help 를 사용하세요."); return;
    case "menu": openChameleonSkillbook(p); return;
    case "skillbook": openChameleonSkillbook(p); return;
    case "learn": { const r=learnChameleonSkill(p,text);p.sendMessage(r.ok?r.message:`§c${r.message}`);return; }
    case "swap": { const r=swapChameleonWeapon(p);p.sendMessage(r.ok?r.message:`§c${r.message}`);return; }
    case "stats": openStatsMenu(p); return;
    case "admin": giveAdminTool(p); return;
    case "setlevel": {
      // /scriptevent 경로에서도 관리자 이외의 강제 설정을 막는다.
      if(!isAdminPlayer(p)){
        p.sendMessage('§c[RPG] 관리자만 강제 레벨을 설정할 수 있습니다.');return;
      }
      const result=forceSetLevel(p,text);
      if(!result.ok)p.sendMessage('§c[RPG] '+result.reason);
      else {
        refreshHud(p, true);
        p.sendMessage(`§a[RPG] 레벨 변경 완료: ${result.old} → ${result.level}${result.resetStats?' §e(초과 스탯 초기화)':''} §7(/rpg:stats 에서 확인)`);
      }
      return;
    }
    case "setmana": {
      if(!isAdminPlayer(p)){
        p.sendMessage('§c[RPG] 관리자만 강제 마나를 설정할 수 있습니다.');return;
      }
      const result=forceSetManaMax(p,text);
      if(!result.ok)p.sendMessage('§c[RPG] '+result.reason);
      else {
        refreshHud(p,true);
        p.sendMessage(`§b[RPG] ${result.reset?'마나 강제 설정 해제':'마나 설정 완료'}: 현재 ${result.current} / 최대 ${result.max} §7(/rpg:status 에서 확인)`);
      }
      return;
    }
    case "techgolem": {
      if(!isAdminPlayer(p)){p.sendMessage("§c[RPG] 관리자만 보스를 소환할 수 있습니다.");return;}
      try{
        const loc=p.location,view=p.getViewDirection(),flat=Math.hypot(view.x,view.z)||1;
        p.dimension.spawnEntity("rpg:tech_block_golem_boss",{x:loc.x+view.x/flat*11,y:loc.y+0.2,z:loc.z+view.z/flat*11});
        p.sendMessage("§b마공학 블럭 골렘이 소환되었습니다! §a떠 있는 블럭 관절로 이루어진 거대 보스입니다.");
      }catch(e){p.sendMessage("§c마공학 블럭 골렘 소환 실패: "+String(e));}
      return;
    }
    case "hydra": {
      if(!isAdminPlayer(p)){p.sendMessage("§c[RPG] 관리자만 보스를 소환할 수 있습니다.");return;}
      try{
        const loc=p.location,view=p.getViewDirection(),flat=Math.hypot(view.x,view.z)||1;
        p.dimension.spawnEntity("rpg:hydra_boss",{x:loc.x+view.x/flat*10,y:loc.y+0.2,z:loc.z+view.z/flat*10});
        p.sendMessage("§6지옥의 히드라가 소환되었습니다! §c세 개의 머리와 거대한 날개를 가진 필드 보스입니다.");
      }catch(e){p.sendMessage("§c히드라 소환 실패: "+String(e));}
      return;
    }
    case "cyclops": {
      if(!isAdminPlayer(p)){p.sendMessage("§c[RPG] 관리자만 보스를 소환할 수 있습니다.");return;}
      try{
        const loc=p.location,view=p.getViewDirection(),flat=Math.hypot(view.x,view.z)||1;
        p.dimension.spawnEntity("rpg:cyclops_boss",{x:loc.x+view.x/flat*9,y:loc.y+0.2,z:loc.z+view.z/flat*9});
        p.sendMessage("§6외눈박이 거인이 소환되었습니다! §c눈 약점에 명중하면 피해 3배");
      }catch(e){p.sendMessage("§c거인 소환 실패: "+String(e));}
      return;
    }
    case "boss": {
      try {
        const loc = p.location;
        const view = p.getViewDirection();
        const flat = Math.hypot(view.x,view.z)||1;
        p.dimension.spawnEntity("rpg:rock_golem_boss",{x:loc.x+view.x/flat*7,y:loc.y+0.2,z:loc.z+view.z/flat*7});
        p.sendMessage("§b바위 골렘이 소환되었습니다! §7처치 경험치 450 XP");
      }catch(e){p.sendMessage("§c골렘 소환 실패: "+String(e));}
      return;
    }
    case "guild":
      openGuildMenu(p); return;
    case "party":
      openPartyMenu(p); return;
    case "invites":
      openInvites(p); return;
    case "job":
    case "force": {
      const target = findJob(text);
      if (!target) {
        const names = Object.values(JOBS).map((j) => j.name).join(", ");
        p.sendMessage(`§c알 수 없는 직업입니다: ${text}\n§7가능: ${names}`);
        return;
      }
      requestAdvance(p, target, action === "force");
      return;
    }
    case "reset":
      resetToApprentice(p);
      p.sendMessage("§7견습으로 초기화했습니다.");
      return;
    case "starter": {
      const r = giveStarter(p, text);
      p.sendMessage(r.ok ? "§a견습 시작 아이템과 스킬을 받았습니다." : `§c${r.reason}`);
      return;
    }
    case "hito": return text?giveHitoEgg(p,text):openHitoEggMenu(p);
    case "egg": openEggMenu(p); return;
    case "items": {
      const n = giveAllItems(p);
      p.sendMessage(n > 0 ? `§a애드온 전용 아이템 ${n}개를 받았습니다.` : "§7이미 모두 가지고 있습니다.");
      return;
    }
    case "charge":
      setMana(p, maxManaOf(p));
      resetCooldowns(p);
      refreshHud(p, true);
      p.sendMessage("§b마나를 가득 채우고 쿨타임을 초기화했습니다.");
      return;
    case "offer":
      offerItems(p);
      return;
    case "bless":
      offerLight(p);
      return;
    case "holywater":
      craftHolyWater(p);
      return;
    case "wings":
      toggleWings(p);
      return;
    case "fistcheck":
      p.sendMessage(getFistCoatingStatus(p));
      return;
    case "wingcheck":
      inspectWings(p);
      return;
    case "wingrefresh":
      refreshWings(p);
      return;
    case "skills":
      p.sendMessage("§7채팅창을 닫으면 스킬 설정창이 열립니다.");
      openSkillMenu(p);
      return;
    case "status": {
      const job = JOBS[getJobId(p)];
      const skills = getSkills(p).map((id) => SKILLS[id]?.name ?? id).join(", ") || "없음";
      const off = getDisabled(p).map((id) => SKILLS[id]?.name ?? id).join(", ");
      const prog = getProgress(p);
      let msg =
        `§e직업: ${job?.name ?? "없음"} §7/ 마나 ${manaText(p)}/${maxManaText(p)}` +
        ` §7/ 책 ${prog.books ?? 0}권\n§7스킬: ${skills}${off ? `\n§7꺼 둔 스킬: ${off}` : ""}`;
      // 지금 직업에서 갈 수 있는 전직과 조건 진행도
      if(job?.id==='angel'){const healing=readAngelHealing(p);msg+=`\n§e축복의 빛: 아군 회복 ${Number(healing.remainder.toFixed(1))}/300 HP · 보관 ${healing.pending}개`;}
      for (const t of Object.values(JOBS)) {
        if (t.parent !== job?.id || t.placeholder || t.hidden) continue;
        const st = requirementStatus(p, t);
        msg += `\n§7→ ${t.name}: ${st ? `${st.label} ${st.have}/${st.need}` : "조건 없음"}`;
      }
      p.sendMessage(msg + "\n" + statsSummary(p));
      return;
    }
    default:
      p.sendMessage(HELP);
  }
}
