import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve('.'),rp=path.join(root,'RPG_RP_v0572');const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const pose=read(path.join(root,'held_weapon_pose.json'));
test('all 39 visible weapons have a real hand skeleton, upright sprite, and twice native model dimensions',()=>{
 const models=read(path.join(rp,'models/entity/upright_weapons.geo.json'))['minecraft:geometry'];assert.equal(models.length,39);
 for(const spec of pose.items){const model=models.find(g=>g.description.identifier==='geometry.rpg.upright.'+spec.id.slice(4));assert.ok(model);assert.equal(model.bones[0].binding,'q.item_slot_to_bone_name(c.item_slot)');
  const weapon=model.bones[0];assert.equal(weapon.name,'pole');assert.deepEqual(weapon.pivot,[0,24,0]);assert.equal(model.bones[1].parent,'pole');
  const sprite=model.bones.find(b=>b.name==='sprite');assert.equal(sprite.cubes.length,1);assert.equal(sprite.cubes[0].size[0],spec.nativeSide*2);
  const a=read(path.join(rp,'attachables',spec.id.slice(4)+'.json'))['minecraft:attachable'].description;assert.equal(a.identifier,spec.id);assert.equal(a.geometry.default,model.description.identifier);
 }
});
test('original common weapon pixels remain exact and transparent geometry has no generated edge cubes',()=>{
 for(const r of read(path.join(root,'original_weapon_texture_mapping.json'))){assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(rp,'textures/items/common_weapons',r.target))).digest('hex'),r.sha256);}
 const a=read(path.join(rp,'animations/upright_weapons.animation.json')).animations;assert.ok(a['animation.rpg.upright.first']);assert.ok(a['animation.rpg.upright.third']);
});
test('private War God rendering stays owner-first-person only and keeps its separate 16-unit model',()=>{
 assert.match(JSON.stringify(read(path.join(rp,'attachables/war_god_gauntlets.json'))),/context.is_first_person/);
 assert.deepEqual(read(path.join(rp,'models/entity/war_god_private.geo.json'))['minecraft:geometry'][0].bones[0].cubes[0].size,[16,16,.2]);
});
test('first and third person use the pinned vanilla trident hand poses without inverse arm compensation',()=>{
 const a=read(path.join(rp,'animations/upright_weapons.animation.json')).animations;
 assert.deepEqual(a['animation.rpg.upright.first'].bones.pole,{rotation:[152,-9,25],position:[-7,-3,-2]});
 assert.deepEqual(a['animation.rpg.upright.third'].bones.pole,{rotation:[97,-1.5,-49],position:[1.5,-2.5,-10.5]});
 assert.equal(pose.frame,'vanilla trident v1.21.100.6');
});
