import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {world,system,player,players,events,ItemStack,replies,EquipmentSlot} from './minecraftMock.mjs';
import {mobXp} from '../RPG_BP_v0572/scripts/data/mobXp.js';
import {registerCombatContributions,recordCombatDamage,awardPartyTrialKill,CONTRIBUTION_TICKS} from '../RPG_BP_v0572/scripts/core/combatContribution.js';
import {registerRpgStats,getXp,getLevel,allocateStat,getStats,unspentPoints} from '../RPG_BP_v0572/scripts/core/stats.js';
import {getProgress,setSkills,getSkills,startCooldown,cooldownLeft,setMana,getMana} from '../RPG_BP_v0572/scripts/core/playerData.js';
import {scriptedHit,noteManualDamage} from '../RPG_BP_v0572/scripts/core/combatContext.js';
import {healHolyAlly,applyHolyRegeneration,tickHolyRecovery} from '../RPG_BP_v0572/scripts/core/holyRecovery.js';
import {readAngelHealing,claimAngelLight,ANGEL_HEAL_KEY} from '../RPG_BP_v0572/scripts/core/angelHealing.js';
import {clearRewardForTier} from '../RPG_BP_v0572/scripts/data/dungeons.js';
import {creditDungeonClear,readDungeonLoot} from '../RPG_BP_v0572/scripts/core/dungeonRewards.js';
import {getWallet,setWallet} from '../RPG_BP_v0572/scripts/core/wallet.js';
import {STAT_RESET_ITEM,JOB_WAIVER_ITEM,applyProgressionItem,useProgressionItem,registerProgressionItems} from '../RPG_BP_v0572/scripts/core/progressionItems.js';
import {registerInput} from '../RPG_BP_v0572/scripts/core/input.js';
import {registerJobQuests} from '../RPG_BP_v0572/scripts/core/jobQuests.js';
import {registerSandbag} from '../RPG_BP_v0572/scripts/core/sandbag.js';
import {checkAdvance,requestAdvance} from '../RPG_BP_v0572/scripts/core/advance.js';
import {JOBS} from '../RPG_BP_v0572/scripts/data/jobs.js';
import {purchaseChameleonSkill,remainingSkillUses,executeChameleonSkill} from '../RPG_BP_v0572/scripts/core/chameleonProgress.js';
const rosters=[['killer','dps','tank','healer'],['idle-lead','idle','far','expired'],['elig-lead','dead','otherdim','creative']];
world.setDynamicProperty('rpg:social_v1',JSON.stringify({version:1,nextId:4,parties:rosters.map((members,i)=>({id:i+1,leader:members[0],members})),guilds:[]}));
const dim={id:'minecraft:overworld',playSound(){},spawnParticle(){},getBlock:()=>({isSolid:false}),getEntities:()=>[]};
function make(id,job='swordsman',party=0){const p=player(id,40);p.dimension=dim;p.getTags=()=>party?['rpg_party_'+party]:[];p.hasTag=t=>p.getTags().includes(t);p.setDynamicProperty('rpg:job',job);players.push(p);return p;}
const teams=rosters.map((names,i)=>names.map(name=>make(name,name==='healer'?'angel':'swordsman',i+1)));
registerCombatContributions();registerRpgStats();registerJobQuests();registerSandbag();
let serial=0;
function mob(typeId='minecraft:zombie'){const p=player('mob'+serial++,1,{typeId,maxHealth:1000,health:1000});p.dimension=dim;return p;}
function hurt(source,target,damage){for(const fn of events.entityHurt.listeners)fn({hurtEntity:target,damage,damageSource:{damagingEntity:source,cause:'entityAttack'}});}
function die(killer,target){for(const fn of events.entityDie.listeners)fn({deadEntity:target,damageSource:{damagingEntity:killer}});}

test('native damage, tanking and effective healing all share a boss trial with the current four-player party',()=>{
 const [a,b,c,d]=teams[0],t=mob('rpg:rock_golem_boss');b.setDynamicProperty('rpg:job','mage');c.setDynamicProperty('rpg:job','fighter');
 hurt(a,t,10);hurt(b,t,3);hurt(t,c,7);c.health=10;assert.equal(healHolyAlly(d,c,5),5);die(a,t);
 for(const p of teams[0])assert.equal(getProgress(p).job_boss,1,p.id);
 assert.equal(getProgress(b).line_mage,1);assert.equal(getProgress(c).line_fist,1);assert.equal(getProgress(d).line_holy,1);
 die(a,t);for(const p of teams[0])assert.equal(getProgress(p).job_boss,1);
});
test('idle, distant, expired and nonparty damage never receive shared trial credit',()=>{
 const [a,idle,far,expired]=teams[1],stranger=make('stranger'),t=mob();
 recordCombatDamage(expired,t,1);system.currentTick+=CONTRIBUTION_TICKS+1;
 far.location={x:33,y:64,z:0};recordCombatDamage(far,t,1);recordCombatDamage(stranger,t,5);die(a,t);
 assert.equal(getProgress(a).job_kills,1);for(const p of [idle,far,expired,stranger])assert.equal(getProgress(p).job_kills,undefined,p.id);
});
test('dead, creative and different-dimension contributors are rejected at the time of death',()=>{
 const [a,dead,otherdim,creative]=teams[2],t=mob();for(const p of [dead,otherdim,creative])recordCombatDamage(p,t,1);
 dead.health=0;otherdim.dimension={id:'minecraft:nether'};creative.getGameMode=()=> 'creative';die(a,t);
 assert.equal(getProgress(a).job_kills,1);for(const p of [dead,otherdim,creative])assert.equal(getProgress(p).job_kills,undefined);
});
test('raw scripted damage fallback also records an assisting party member',()=>{
 const [a,b]=teams[0],t=mob();const before=getProgress(b).job_kills;
 scriptedHit(t,b,()=>{t.health-=10;noteManualDamage(b,t,10);return true;});die(a,t);assert.equal(getProgress(b).job_kills,before+1);
});
test('villager and sandbag special trials share contributions only for the required current class',()=>{
 const [a,b]=teams[0];a.setDynamicProperty('rpg:job','sword_saint');b.setDynamicProperty('rpg:job','sword_saint');
 const v=mob('minecraft:villager_v2');hurt(b,v,1);die(a,v);assert.equal(getProgress(a).villager_kills,1);assert.equal(getProgress(b).villager_kills,1);
 a.setDynamicProperty('rpg:job','fighter');b.setDynamicProperty('rpg:job','apprentice');const bag=mob('rpg:sandbag_entity');hurt(b,bag,1);die(a,bag);
 assert.equal(getProgress(a).fighter_sandbags,1);assert.equal(getProgress(b).apprentice_sandbags,1);
});
function healScene(id){const a=make('angel-'+id,'angel'),b=make('patient-'+id);a.getTags=b.getTags=()=>['rpg_team_heal_'+id];a.hasTag=b.hasTag=t=>t==='rpg_team_heal_'+id;b.maxHealth=1000;b.health=100;return {a,b};}
const lights=p=>p.slots.reduce((n,it)=>n+(it?.typeId==='rpg:blessing_light'?it.amount:0),0);
test('every 300 actual HP grants a light, carries the remainder, and excludes overheal',()=>{
 const {a,b}=healScene('actual');assert.equal(healHolyAlly(a,b,650),650);assert.equal(lights(a),2);assert.equal(readAngelHealing(a).remainder,50);
 b.health=990;assert.equal(healHolyAlly(a,b,100),10);assert.equal(readAngelHealing(a).remainder,60);
 const rejoin=make('angel-rejoin','angel');rejoin.setDynamicProperty(ANGEL_HEAL_KEY,a.getDynamicProperty(ANGEL_HEAL_KEY));assert.equal(readAngelHealing(rejoin).remainder,60);
});
test('self healing, enemies, dead targets and non-Angel jobs cannot farm lights',()=>{
 const {a,b}=healScene('reject');a.health=1;healHolyAlly(a,a,100);assert.equal(lights(a),0);
 const enemy=mob();enemy.health=1;assert.equal(healHolyAlly(a,enemy,100),0);b.health=0;assert.equal(healHolyAlly(a,b,300),0);
 for(const job of ['cleric','michael','chameleon']){a.setDynamicProperty('rpg:job',job);b.health=1;healHolyAlly(a,b,300);}assert.equal(lights(a),0);
});
test('owned tamed allies are eligible but unowned monsters are not',()=>{
 const {a}=healScene('pet'),pet=mob('minecraft:wolf'),get=pet.getComponent.bind(pet);pet.health=10;
 pet.getComponent=name=>name==='minecraft:tameable'?{tamedToPlayerId:a.id}:get(name);
 assert.equal(healHolyAlly(a,pet,300),300);assert.equal(lights(a),1);
});
test('a full inventory stores earned lights and a failed delivery restores slots without duplication',()=>{
 const {a,b}=healScene('bag');a.slots.fill(new ItemStack('minecraft:stone',64));healHolyAlly(a,b,600);assert.equal(readAngelHealing(a).pending,2);
 a.slots[5]=undefined;const save=a.setDynamicProperty.bind(a);let fail=true;a.setDynamicProperty=(key,value)=>{if(fail&&key===ANGEL_HEAL_KEY){fail=false;throw Error('storage');}save(key,value);};
 assert.throws(()=>claimAngelLight(a));assert.equal(a.slots[5],undefined);assert.equal(readAngelHealing(a).pending,2);
 assert.equal(claimAngelLight(a),2);assert.equal(claimAngelLight(a),0);assert.equal(lights(a),2);
});
test('holy regeneration credits its real ticks and does not stack multiple caster regeneration',()=>{
 const {a,b}=healScene('regen'),other=make('angel-regen2','angel');other.getTags=a.getTags;other.hasTag=a.hasTag;
 a.setDynamicProperty(ANGEL_HEAL_KEY,JSON.stringify({remainder:299,pending:0}));
 applyHolyRegeneration(a,b,100,2);applyHolyRegeneration(other,b,100,1);system.currentTick+=12;tickHolyRecovery();assert.equal(b.health,101);assert.equal(lights(a),1);assert.equal(lights(other),0);
 b.effects.set('regeneration',{amplifier:3,duration:100});system.currentTick+=12;tickHolyRecovery();assert.equal(b.health,101);
});
test('strong holy regeneration temporarily suppresses a weaker potion and restores its remaining duration',()=>{
 const {a,b}=healScene('weak-potion');const start=system.currentTick;
 b.effects.set('regeneration',{amplifier:0,duration:100});applyHolyRegeneration(a,b,30,2);
 tickHolyRecovery();assert.equal(b.effects.has('regeneration'),false);system.currentTick=start+12;tickHolyRecovery();assert.equal(b.health,101);
 system.currentTick=start+31;tickHolyRecovery();assert.equal(b.effects.get('regeneration').amplifier,0);assert.equal(b.effects.get('regeneration').duration,69);
});
test('higher dungeon tiers scale money, all enhancement currencies, catalysts, runes and supplies',()=>{
 assert.deepEqual([clearRewardForTier(1).gold,clearRewardForTier(1).catalysts],[2000,7]);
 const expected=[31000,124,31,26,3,4],r=clearRewardForTier(10);assert.deepEqual([r.gold,r.stone,r.dust,r.catalysts,r.runes,r.supplyMultiplier],expected);
 let previous=clearRewardForTier(1);for(let tier=2;tier<=10;tier++){const next=clearRewardForTier(tier);for(const key of ['gold','stone','dust','catalysts'])assert.ok(next[key]>previous[key]);previous=next;}
 const p=make('tier10-reward');creditDungeonClear(p,9000,10);creditDungeonClear(p,9000,10);assert.equal(getWallet(p).gold,31000);
 const s=readDungeonLoot(p);assert.equal(s.pending['rpg:enhancement_catalyst'],26);assert.equal(s.pending['minecraft:iron_ingot'],32);assert.equal(Object.keys(s.pending).filter(id=>id.startsWith('rpg:rune_')).length,3);assert.equal(s.clears,1);
});
test('vanilla XP classification includes hostile variants and farm exceptions without changing RPG bosses',()=>{
 for(const id of ['cow','chicken','sheep','pig','villager_v2'])assert.equal(mobXp('minecraft:'+id),10);
 for(const id of ['zombie','drowned','bogged','skeleton','endermite','evocation_illager','guardian','elder_guardian','ravager','breeze','creaking','piglin_brute','shulker'])assert.equal(mobXp('minecraft:'+id),30,id);
 for(const id of ['silverfish','zombie_pigman','zombified_piglin'])assert.equal(mobXp('minecraft:'+id),5);
 assert.equal(mobXp('rpg:hydra_boss'),900);assert.equal(mobXp('rpg:green_goblin'),20);assert.equal(mobXp('minecraft:wither'),500);
 for(const id of ['minecraft:player','minecraft:armor_stand','rpg:sandbag_entity'])assert.equal(mobXp(id),0);
});
test('actual vanilla death events pay 10, 30 and 5 XP and projectile owners are resolved',()=>{
 const p=make('vanilla-xp');die(p,mob('minecraft:chicken'));assert.equal(getXp(p),10);
 die(p,mob('minecraft:zombie'));assert.equal(getXp(p),40);
 for(const fn of events.entityDie.listeners)fn({deadEntity:mob('minecraft:silverfish'),damageSource:{damagingProjectile:{getComponent:()=>({owner:p})}}});assert.equal(getXp(p),45);
});
test('stat reset refunds allocated SP only and preserves level, skills and learned-skill SP',()=>{
 const p=make('stat-reset','chameleon');p.slots[8]=new ItemStack(STAT_RESET_ITEM,2);setSkills(p,[]);purchaseChameleonSkill(p,'sword_spin');allocateStat(p,'mag',10);allocateStat(p,'vit',5);const before=unspentPoints(p);const level=getLevel(p);
 assert.equal(applyProgressionItem(p,STAT_RESET_ITEM).refund,15);assert.equal(unspentPoints(p),before+15);assert.deepEqual(getStats(p),{str:5,vit:5,int:5,mag:5});assert.equal(getLevel(p),level);assert.ok(getSkills(p).includes('sword_spin'));assert.equal(p.slots[8].amount,1);
 assert.equal(applyProgressionItem(p,STAT_RESET_ITEM).ok,false);assert.equal(p.slots[8].amount,1);
});
test('job waiver returns to apprentice without deleting armor, runes, wallet, XP, stats, trials or cooldowns',()=>{
 const p=make('waiver','mage');p.slots[0]=new ItemStack('rpg:mage_book');p.slots[4]=new ItemStack(JOB_WAIVER_ITEM);p.equipment.set(EquipmentSlot.Chest,new ItemStack('rpg:adventurer_chestplate'));p.setDynamicProperty('rpg:rune_bag_v1','saved');
 setWallet(p,{gold:10,stone:20,dust:30});allocateStat(p,'mag',8);p.setDynamicProperty('rpg:rpg_xp',17);p.setDynamicProperty('rpg:progress',JSON.stringify({books:10}));startCooldown(p,'mage_fireball',200);setMana(p,50);
 assert.equal(applyProgressionItem(p,JOB_WAIVER_ITEM).ok,true);assert.equal(p.getDynamicProperty('rpg:job'),'apprentice');assert.deepEqual(getSkills(p),[]);assert.equal(p.slots[0],undefined);assert.equal(p.slots[4],undefined);
 assert.equal(getLevel(p),40);assert.equal(getXp(p),17);assert.equal(getStats(p).mag,13);assert.equal(getProgress(p).books,10);assert.equal(getWallet(p).gold,10);assert.equal(p.getDynamicProperty('rpg:rune_bag_v1'),'saved');assert.equal(p.equipment.get(EquipmentSlot.Chest).typeId,'rpg:adventurer_chestplate');assert.equal(cooldownLeft(p,'mage_fireball'),200);assert.equal(getMana(p),50);
});
test('abandoning Chameleon dismantles borrowed skills once and retains depleted charges',()=>{
 const p=make('cham-waiver','chameleon');setSkills(p,[]);purchaseChameleonSkill(p,'hacker_reboot');executeChameleonSkill(p,'hacker_reboot',()=>true);const before=unspentPoints(p);p.slots[3]=new ItemStack(JOB_WAIVER_ITEM);
 assert.equal(applyProgressionItem(p,JOB_WAIVER_ITEM).refund,9);assert.equal(unspentPoints(p),before+9);p.setDynamicProperty('rpg:job','chameleon');assert.equal(purchaseChameleonSkill(p,'hacker_reboot').ok,true);assert.equal(remainingSkillUses(p,'hacker_reboot'),9);
});
test('failed item transaction rolls back consumption and all character mutations',()=>{
 const p=make('reset-failure');p.slots[5]=new ItemStack(STAT_RESET_ITEM);allocateStat(p,'str',7);const save=p.setDynamicProperty.bind(p);let fail=true;
 p.setDynamicProperty=(key,value)=>{if(fail&&key==='rpg:stat_values'){fail=false;throw Error('persist');}save(key,value);};
 assert.equal(applyProgressionItem(p,STAT_RESET_ITEM).ok,false);assert.equal(getStats(p).str,12);assert.equal(p.slots[5].typeId,STAT_RESET_ITEM);
});
test('a qualified holy resignation can continue the Fallen Angel trial after returning to apprentice',async()=>{
 const p=make('holy-waiver','angel');p.setDynamicProperty('rpg:progress',JSON.stringify({healed_deaths:5}));p.slots[4]=new ItemStack(JOB_WAIVER_ITEM);
 assert.equal(applyProgressionItem(p,JOB_WAIVER_ITEM).ok,true);assert.equal(checkAdvance(p,JOBS.fallen_angel).ok,true);
 replies.push({canceled:false,selection:1});await requestAdvance(p,JOBS.fallen_angel);assert.equal(p.getDynamicProperty('rpg:job'),'fallen_angel');assert.equal(p.getDynamicProperty('rpg:renounced_holy'),undefined);
 const other=make('not-holy-waiver','mage');other.setDynamicProperty('rpg:progress',JSON.stringify({healed_deaths:5}));other.slots[4]=new ItemStack(JOB_WAIVER_ITEM);applyProgressionItem(other,JOB_WAIVER_ITEM);assert.equal(checkAdvance(other,JOBS.fallen_angel).ok,false);
});
test('cancel and duplicate use events never consume twice; real custom component path works',async()=>{
 registerInput();registerProgressionItems();const components=new Map();for(const fn of system.beforeEvents.startup.listeners)fn({itemComponentRegistry:{registerCustomComponent:(id,c)=>components.set(id,c)}});
 const p=make('item-confirm');p.slots[2]=new ItemStack(STAT_RESET_ITEM,2);allocateStat(p,'str',1);
 replies.push({canceled:false,selection:0});await useProgressionItem(p,STAT_RESET_ITEM);assert.equal(p.slots[2].amount,2);
 system.currentTick+=4;p.equipment.set(EquipmentSlot.Mainhand,new ItemStack(STAT_RESET_ITEM));replies.push({canceled:false,selection:1});components.get('rpg:progression_item').onUse({source:p});for(const fn of events.itemUse.listeners)fn({source:p,itemStack:p.slots[2]});await new Promise(r=>setImmediate(r));assert.equal(p.slots[2].amount,1);assert.equal(getStats(p).str,5);
});
test('both consumables have real recipes, 128px atlas icons and a usable custom item component',()=>{
 const root=new URL('../RPG_BP_v0572/',import.meta.url),atlas=JSON.parse(fs.readFileSync(new URL('../RPG_RP_v0572/textures/item_texture.json',import.meta.url))).texture_data;
 for(const id of ['stat_reset_scroll','job_waiver']){const item=JSON.parse(fs.readFileSync(new URL('items/'+id+'.json',root)))['minecraft:item'];assert.ok(item.components['rpg:progression_item']);assert.ok(atlas[item.components['minecraft:icon']]);const recipe=JSON.parse(fs.readFileSync(new URL('recipes/'+id+'.json',root)))['minecraft:recipe_shapeless'];assert.equal(recipe.result.item,'rpg:'+id);assert.ok(recipe.ingredients.length<=9);}
});
