import test from 'node:test';
import assert from 'node:assert/strict';
import {world,player,ItemStack,events,system} from './minecraftMock.mjs';
import {CONFIG} from '../RPG_BP_v0572/scripts/config.js';
import {RULEBOOK_PAGES,giveRulebook} from '../RPG_BP_v0572/scripts/core/rulebook.js';
import {applyPeaceRules} from '../RPG_BP_v0572/scripts/core/peaceServer.js';
import {getTargets,hurt} from '../RPG_BP_v0572/scripts/core/util.js';
import {registerInput} from '../RPG_BP_v0572/scripts/core/input.js';
import {JOBS} from '../RPG_BP_v0572/scripts/data/jobs.js';
import {setSkills,setIndex,setMana,getMana} from '../RPG_BP_v0572/scripts/core/playerData.js';
test('native PvP and hostile player targeting are enabled while mob combat stays usable',()=>{
 assert.equal(CONFIG.pvp,true);applyPeaceRules();assert.equal(world.gameRules.pvp,true);assert.equal(world.gameRules.doInsomnia,false);const p=player('peace'),other=player('visitor'),mob=player('zombie',1,{typeId:'minecraft:zombie'});p.dimension.getEntities=()=>[other,mob];assert.deepEqual(getTargets(p,p.location,10),[other,mob]);let hit=false;other.applyDamage=()=>{hit=true;return true;};assert.equal(hurt(other,p,100),true);assert.equal(hit,true);
});
test('book is mobile-sized, has survival guidance and zones, and omits old commands/admin/secret methods',()=>{
 assert.ok(RULEBOOK_PAGES.length<=50);for(const p of RULEBOOK_PAGES){assert.ok(p.length<=256);assert.ok(p.split('\n').length<=14);}
 const text=RULEBOOK_PAGES.join('\n').replace(/§./g,'').replace(/\s/g,'');
 for(const name of ['결투','사냥구역','1,500','4,000','10,000','사막','동굴','/rpg:offer','힘의룬','비전의룬','샘의룬','생명의룬','수호의룬','흡수의룬','/rpg:fuse'])assert.ok(text.includes(name.replace(/\s/g,'')),name);
 for(const forbidden of ['/rpg:book','/rpg:sword','/rpg:force','/rpg:setlevel','/rpg:admin','포션','물약','주민100','로토와23','총192'])assert.ok(!text.includes(forbidden),forbidden);
});
test('book delivery produces a signed book with actual pages, and a full inventory drops that same book',()=>{
 for(const full of [false,true]){const p=player('reader-'+full);let received,drop;const inv=p.getComponent('minecraft:inventory').container;inv.addItem=i=>{received=i;return full?i:undefined;};p.dimension.spawnItem=i=>{drop=i;};assert.equal(giveRulebook(p),true);assert.equal(received.typeId,'minecraft:written_book');assert.equal(received.bookData.title,'RPG 서버 종합 룰북');assert.deepEqual(received.bookData.pages,RULEBOOK_PAGES);assert.equal(drop,full?received:undefined);}
});
test('left-click party healing stays usable with PvP enabled and duplicate swing/hit observations cast once',()=>{
 registerInput();const p=player('cleric',30),ally=player('healed',1,{health:3});p.setDynamicProperty('rpg:job','cleric');setSkills(p,JOBS.cleric.skills);setIndex(p,0);setMana(p,1000);p.equipment.set('Mainhand',new ItemStack(JOBS.cleric.weapon));p.getEntitiesFromViewDirection=()=>[{entity:ally,distance:2}];p.dimension.getEntities=()=>[ally];p.getTags=()=>['rpg_party_heal'];p.hasTag=t=>t==='rpg_party_heal';ally.getTags=p.getTags;ally.hasTag=p.hasTag;const initial=ally.health;
 for(const fn of events.playerSwingStart.listeners)fn({player:p});assert.ok(ally.health>initial);const mana=getMana(p),healed=ally.health;for(const fn of events.entityHitEntity.listeners)fn({damagingEntity:p,hitEntity:ally});assert.equal(ally.health,healed);assert.equal(getMana(p),mana);
});
