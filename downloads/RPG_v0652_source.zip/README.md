# RPG v0.6.52 · 룬 제작 재료 블록화

Bedrock 1.21.100 이상. BP·Commands BP·RP 모두 v0.6.52로 활성화하고 월드를 다시 여세요. 팩 UUID·아이템 ID·기존 저장 데이터는 유지합니다.

룬 6종의 작업대 제작 재료를 자수정 조각 → 자수정 블록, 청금석 → 청금석 블록, 레드스톤 → 레드스톤 블록, 철 주괴 → 철 블록으로 변경했습니다. 기존 재료 한 개를 해당 블록 한 개로 치환했으며 수량과 결과 룬 1개는 유지합니다. `/rpg:craft` 도감도 같은 재료와 수량으로 갱신했습니다.

| 룬 | 제작 재료 |
| --- | --- |
| 힘 | 자수정 블록 3 + 레드스톤 블록 2 + 철 블록 1 |
| 비전 | 자수정 블록 3 + 레드스톤 블록 1 + 엔더 진주 1 + 청금석 블록 1 |
| 수호 | 자수정 블록 3 + 레드스톤 블록 1 + 철 블록 2 |
| 생명 | 자수정 블록 3 + 레드스톤 블록 1 + 황금사과 1 |
| 샘 | 자수정 블록 3 + 레드스톤 블록 1 + 청금석 블록 2 |
| 흡수 | 자수정 블록 3 + 철 블록 2 + 프리즈머린 수정 2 |

모두 작업대에 순서와 관계없이 넣어 제작합니다. 자수정 블록은 자수정 조각 4개로, 철·레드스톤·청금석 블록은 각 재료 9개로 먼저 제작하세요. 싹 틔우는 자수정은 재료가 아닙니다.

현재 룬 제작법에 다이아몬드와 네더라이트를 사용하는 항목은 없습니다. 다이아몬드 재료가 있는 다른 장비 제작법과 네더라이트 재료는 그대로 유지합니다. 엔더 진주·황금사과·프리즈머린 수정도 유지합니다. 기존 룬 강화/합성 비용·확률·자동 완성·장착 보호, 갑옷·수선·보스 AI와 이전 기능은 유지합니다.

## 검증

기존 전체 회귀 검사, JSON/JavaScript/import, 룬 제작법과 도감의 재료·수량 일치, 블록 ID 및 출력 수량, 세 팩 버전/의존성과 압축 무결성을 확인합니다. 모의 API·데이터 검사이며 실제 Minecraft 엔진의 제작 화면과 제작 동작은 별도 인게임 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0652
```
