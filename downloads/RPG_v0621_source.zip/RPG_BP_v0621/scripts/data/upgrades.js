import {gradeRank} from './grades.js';
export const ARMOR_LEVEL_KEY = 'rpg:armor_upgrade';
export const RUNE_LEVEL_KEY = 'rpg:rune_upgrade';
export const ARMOR_MAX = 10;
export const RUNE_MAX = 10;
export const WEAPON_MAX = 10;
export const WEAPON_LEVEL_KEY = 'rpg:weapon_upgrade';

export function upgradeLevel(item, kind) {
  const key = kind === 'armor' ? ARMOR_LEVEL_KEY : kind === 'weapon' ? WEAPON_LEVEL_KEY : RUNE_LEVEL_KEY;
  const max = kind === 'armor' ? ARMOR_MAX : RUNE_MAX;
  const value = item?.getDynamicProperty(key);
  return Number.isInteger(value) ? Math.max(0, Math.min(max, value)) : 0;
}

export const RUNE_DUST_COSTS=Object.freeze([1,1,2,3,5,5,5,6,6,7]);
// Costs refer to the NEXT level, and are consumed for all completed attempts.
export function upgradeCost(kind, current) {
  const max = ['armor','weapon','rune'].includes(kind) ? 10 : 0;
  if (!Number.isInteger(current) || current < 0 || current >= max) return undefined;
  const next = current + 1;
  return kind !== 'rune'
    ? {gold:200*next*next, stone:2*next, dust:0}
    : {gold:Math.round(2.5*next*next)*5, stone:0, dust:RUNE_DUST_COSTS[current]};
}

export const CATALYST_ID = 'rpg:enhancement_catalyst';
export const MAX_CATALYSTS = 5;
// Rows are success / unchanged failure / downgrade / destruction, in percent.
const ARMOR_RATES = [
  [95,5,0,0], [90,10,0,0], [80,18,2,0], [70,23,7,0], [60,28,10,2],
  [50,30,16,4], [40,32,22,6], [30,34,27,9], [22,35,30,13], [15,35,32,18],
];
// +10 rune curve follows the armor curve; catalysts remain available from +2.
const RUNE_RATES = [[95,5,0,0],[90,10,0,0],[70,28,2,0],[65,28,7,0],...ARMOR_RATES.slice(4)];
export function catalystAllowed(kind,current) {return kind==='armor'||kind==='weapon'?current>=5:kind==='rune'&&current>=2;}
export function enhancementRates(kind,current,catalystCount=0) {
  if (!Number.isInteger(catalystCount)||catalystCount<0||catalystCount>MAX_CATALYSTS) return undefined;
  const row = (kind==='armor'||kind==='weapon'?ARMOR_RATES:kind==='rune'?RUNE_RATES:[])[current];
  if (!row) return undefined;
  let [success,fail,downgrade,destroy] = row;
  if (catalystCount>0) {
    if (!catalystAllowed(kind,current)) return undefined;
    destroy = Math.max(0,destroy-3*catalystCount);
    success = Math.min(success+9*catalystCount,100-downgrade-destroy);
    fail = 100-success-downgrade-destroy;
  }
  if(kind==='rune'){const returned=downgrade/2;downgrade/=2;success+=returned/2;fail+=returned/2;}
  return {success,fail,downgrade,destroy};
}
export function rollEnhancement(rates,random=Math.random) {
  const value=random();
  if (!Number.isFinite(value)||value<0||value>=1) throw Error('강화 난수 범위 오류');
  const roll=value*100;
  if (roll<rates.success) return 'success';
  if (roll<rates.success+rates.fail) return 'fail';
  if (roll<rates.success+rates.fail+rates.downgrade) return 'downgrade';
  return 'destroy';
}

// ── 영웅·전설·신화 룬 +8/+9/+10 추가 능력 ─────────────────────────────
// 수치는 영웅 기준이며 전설 ×1.5, 신화 ×2.25 로 커집니다. 효과는 +8, +9, +10 에서 누적됩니다.
// aura 는 장착 중 계속 유지되는 상태 효과(증폭 0 = I단계)입니다.
export const EXTRA_MIN_GRADE = 4; // 영웅
export const EXTRA_SCALE = Object.freeze({ 4: 1, 5: 1.5, 6: 2.25 });
const AURA_NAMES = Object.freeze({ speed: '신속 I', fire_resistance: '화염 저항', regeneration: '재생 I' });
const RUNE_EXTRAS = Object.freeze({
  power:      { 8: { physical: 0.03 },          9: { aura: { speed: 0 } },            10: { physical: 0.04 } },
  arcane:     { 8: { magic: 0.03 },             9: { manaRegenPercent: 0.004 },        10: { magic: 0.04 } },
  ward:       { 8: { health: 6 },               9: { aura: { regeneration: 0 } },      10: { health: 10 } },
  mana:       { 8: { manaRegenPercent: 0.003 }, 9: { aura: { speed: 0 } },             10: { manaRegenPercent: 0.005 } },
  vitality:   { 8: { health: 6 },               9: { aura: { regeneration: 0 } },      10: { health: 10 } },
  absorption: { 8: { lifesteal: 0.01 },         9: { health: 6 },                      10: { lifesteal: 0.015 } },
});
function runeKind(rune) {
  if (rune.defense) return 'ward';
  if (rune.physical) return 'power';
  if (rune.magic) return 'arcane';
  if (rune.manaRegenPercent) return 'mana';
  if (rune.lifesteal) return 'absorption';
  if (rune.health) return 'vitality';
  return undefined;
}
function fmtExtra(key, v) {
  if (key === 'physical') return '물리 스킬 +' + Number((v * 100).toFixed(2)) + '%p';
  if (key === 'magic') return '마법 스킬 +' + Number((v * 100).toFixed(2)) + '%p';
  if (key === 'manaRegenPercent') return '초당 마나 +' + Number((v * 100).toFixed(2)) + '%p';
  if (key === 'lifesteal') return '흡혈 +' + Number((v * 100).toFixed(2)) + '%p';
  return '최대 HP +' + Number(v.toFixed(2));
}
function applyRuneExtras(result, kind, rank, gradeIdx) {
  const table = RUNE_EXTRAS[kind];
  const scale = EXTRA_SCALE[gradeIdx] ?? 1;
  if (!table) return;
  for (const lv of [8, 9, 10]) {
    if (rank < lv || !table[lv]) continue;
    for (const [key, base] of Object.entries(table[lv])) {
      if (key === 'aura') {
        for (const [eid, amp] of Object.entries(base)) {
          result.auras[eid] = Math.max(result.auras[eid] ?? -1, amp);
          result.extraText.push('[+' + lv + '] ' + (AURA_NAMES[eid] ?? eid) + ' 상시 유지');
        }
        continue;
      }
      const add = base * scale;
      result[key] = (result[key] ?? (key === 'physical' || key === 'magic' ? 1 : 0)) + add;
      result.extraText.push('[+' + lv + '] ' + fmtExtra(key, add));
    }
  }
}

export function upgradedRune(rune, level, grade=0) {
  if (!rune) return undefined;
  const rank = Math.max(0, Math.min(RUNE_MAX, Number.isInteger(level) ? level : 0));
  const result = {...rune, wardAmplifier:0, speedAmplifier:0};
  if (rune.physical) result.physical += rank*0.034;
  if (rune.magic) result.magic += rank*0.034;
  if (rune.manaRegenPercent) result.manaRegenPercent = (10+rank*2)/1000;
  if (rune.health) result.health = rune.health+rank*2;
  if (rune.lifesteal) result.lifesteal=(50+rank*7)/1000;
  if (rune.defense) {
    result.health=rank;
    result.defense=rune.defense+rank*2;
  }
  // Each rarity multiplies the complete damage factor by 1.5.
  const multiplier=1.5**gradeRank(grade);
  for(const key of ['physical','magic'])if(result[key])result[key]*=multiplier;
  for(const key of ['health','manaRegen','manaRegenPercent','lifesteal','defense'])if(result[key])result[key]*=multiplier;
  result.auras = {};
  result.extraText = [];
  const gradeIdx = gradeRank(grade);
  if (rank >= 8 && gradeIdx >= EXTRA_MIN_GRADE) { const kind = runeKind(rune); if (kind) applyRuneExtras(result, kind, rank, gradeIdx); }
  // Halve all absorption healing, including enhancement and rarity extras.
  if(result.lifesteal)result.lifesteal*=0.5;
  return result;
}

// Rune equipment slots unlock in order; unlike item enhancement, unlocks always succeed.
export const RUNE_SLOT_UNLOCK_COSTS = Object.freeze({
  3:Object.freeze({gold:10000,stone:0,dust:20}),
  4:Object.freeze({gold:30000,stone:0,dust:50}),
});
