import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0621';
const base=root+'/RPG_BP_v0621/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}

const city=await load('scripts/data/fantasyCity.js');
const region={x:-500,y:100,z:700,size:250,dimId:'minecraft:overworld'};
let provider;
const town=await load('scripts/core/townProtection.js',{CITY_HOUSE_PLOTS:city.CITY_HOUSE_PLOTS,spawnRegion:()=>region,registerStructureProtection:(id,fn)=>provider=fn});
town.registerTownProtection();town.registerTownProtection();assert.equal(typeof provider,'function');
const block=(x,y,z,typeId='minecraft:stone',dim='minecraft:overworld')=>({location:{x:region.x+x,y:region.y+y,z:region.z+z},dimension:{id:dim,getBlock:()=>({typeId})},typeId});
for(const p of city.CITY_HOUSE_PLOTS){
 for(const [x,z] of [[p.x,p.z],[p.x+p.w-1,p.z+p.d-1],[p.x+2,p.z+2]])for(const y of [0,1,6,16]){
  assert.equal(town.townProtected(block(x,y,z)),false);
  assert.equal(town.townProtected(block(x,y,z,'minecraft:gold_block')),true);
 }
 assert.equal(town.townProtected(block(p.x,-1,p.z)),true);
 assert.equal(town.townProtected(block(p.x,17,p.z)),true);
}
for(const [x,y,z] of [[125,0,125],[125,1,68],[101,8,35],[84,24,23],[0,1,50],[249,9,248],[125,200,125],[125,-100,125]])assert.equal(town.townProtected(block(x,y,z)),true);
for(const [x,z]of [[-1,125],[250,125],[125,-1],[125,250]])assert.equal(town.townProtected(block(x,0,z)),false);
assert.equal(town.townProtected(block(125,0,125,'minecraft:gold_block','minecraft:nether')),false);
assert.equal(town.townProtected(block(125,0,125),null),false);
// Exercise real shared hooks, including stable 2.2 block interactions.
const hooks={},events=new Proxy({},{get:(o,k)=>({subscribe:fn=>hooks[k]=fn})});
const structure=await load('scripts/core/structureProtection.js',{world:{beforeEvents:events},BlockTypes:{get:id=>id.startsWith('minecraft:')?{}:undefined}});
structure.registerStructureProtection('town',provider);
for(const event of ['playerBreakBlock','playerPlaceBlock']){
 let e={block:block(125,0,125)};hooks[event](e);assert.equal(e.cancel,true);
 e={block:block(33,2,33)};hooks[event](e);assert.equal(e.cancel,undefined);
 e={block:block(33,2,33,'minecraft:gold_block')};hooks[event](e);assert.equal(e.cancel,true);
}
for(const typeId of ['minecraft:stone','minecraft:water_bucket','minecraft:flint_and_steel']){
 const e={block:block(125,0,125),blockFace:'up',itemStack:{typeId}};hooks.playerInteractWithBlock(e);assert.equal(e.cancel,true);
}
const housePlace={block:block(33,1,33),blockFace:'up',itemStack:{typeId:'minecraft:stone'}};hooks.playerInteractWithBlock(housePlace);assert.equal(housePlace.cancel,undefined);
const chestOpen={block:block(125,1,125),blockFace:'up'};hooks.playerInteractWithBlock(chestOpen);assert.equal(chestOpen.cancel,undefined);
const piston={block:block(33,1,33),blockFace:'up',itemStack:{typeId:'minecraft:piston'}};hooks.playerInteractWithBlock(piston);assert.equal(piston.cancel,true);
let impacted;const house=block(33,2,33),outside=block(-1,0,0);hooks.explosion({getImpactedBlocks:()=>[block(125,0,125),block(0,5,10),block(33,2,33,'minecraft:gold_block'),house,outside],setImpactedBlocks:b=>impacted=b});assert.deepEqual(Array.from(impacted),[house,outside]);
console.log('Town protection: all 26 house footprints, gold/castle/walls/plaza, bounds/heights/dimensions, native break/place/interact, buckets/fire/pistons and explosion filtering passed');
let particles=[],blocked=false;
const fx=await load('scripts/skills/worldMudaFx.js',{flatDir:()=>({x:0,z:1}),isSolidAt:()=>blocked,particle:(dim,id,at)=>particles.push({id,at})});
const player={location:{x:0,y:0,z:0},dimension:{}};
const dispatch=await load('scripts/skills/warGodFx.js',{worldMudaFx:fx.worldMudaFx});
for(let i=0;i<8;i++)dispatch.warGodAttackFx(player,{id:'world_muda'},i);
assert.equal(particles.length,48);assert.equal(new Set(particles.map(p=>p.id)).size,2);assert.ok(particles.every(p=>p.at.z>0&&Math.abs(p.at.x)<2&&p.at.y>0));
blocked=true;particles=[];dispatch.warGodAttackFx(player,{id:'world_muda'},0);assert.equal(particles.length,0);
for(const name of ['left','right']){
 const particle=JSON.parse(fs.readFileSync(root+'/RPG_RP_v0621/particles/rpg_world_muda_'+name+'.json','utf8')).particle_effect;
 assert.equal(particle.description.identifier,'rpg:world_muda_'+name);
 const texture=fs.readFileSync(root+'/RPG_RP_v0621/'+particle.description.basic_render_parameters.texture+'.png');
 assert.equal(texture.readUInt32BE(16),64);assert.equal(texture.readUInt32BE(20),64);
}
const defs=(await load('scripts/data/skills.js')).SKILLS;assert.equal(defs.world_muda.hits,8);assert.equal(defs.world_muda.damagePerHit,6);assert.equal(defs.world_muda.interval,5);
console.log('Muda: actual FX dispatcher emits 48 gold fist sprites over 8 pulses, alternating hands, forward spread, wall clipping, valid 64px textures; 8x6 damage/5-tick timing unchanged');
