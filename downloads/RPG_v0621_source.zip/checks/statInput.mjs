import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0621';
const base=root+'/RPG_BP_v0621/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=spec==='@minecraft/server-ui'?['ActionFormData','ModalFormData']:[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}

async function submit(input,{selection=0,level=10,canceled=false}={}){
 const messages=[],props=new Map([['rpg:rpg_level',level]]);let forms=0;
 class Action{title(){return this;}body(){return this;}button(){return this;}show(){return Promise.resolve(forms++===0?{selection,canceled:false}:{canceled:true});}}
 class Modal{title(){return this;}textField(){return this;}submitButton(){return this;}show(){return Promise.resolve({canceled,formValues:[input]});}}
 const stats=await load('scripts/core/stats.js',{ActionFormData:Action,ModalFormData:Modal,wardDefenseValue:()=>0,wardDamageReduction:()=>0,learningSpent:()=>0,getEquipmentBonuses:()=>({health:0}),world:{},system:{}});
 const p={id:'p',isValid:true,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),getEffect:()=>undefined,removeEffect:()=>{},addEffect:()=>{},sendMessage:s=>messages.push(s)};
 await stats.openStatsMenu(p);
 return {stats:stats.getStats(p),remaining:stats.unspentPoints(p),messages};
}
for(const [input,points]of [['1',1],[' 12 ',12],['１２',12],[2,2]]){
 const r=await submit(input);assert.equal(r.stats.str,5+points);assert.equal(r.remaining,27-points);assert.equal(r.messages.length,1);assert.ok(r.messages[0].includes('근력 +'+points));
}
for(const input of ['',undefined,'0','-1','1.5','abc','999999999999999999999']){
 const r=await submit(input);assert.equal(r.stats.str,5);assert.equal(r.remaining,27);assert.equal(r.messages.length,0);
}
{const r=await submit('28');assert.equal(r.stats.str,5);assert.equal(r.remaining,27);assert.ok(r.messages[0].includes('포인트 부족'));}
{const r=await submit('3',{selection:3});assert.equal(r.stats.mag,8);assert.equal(r.remaining,24);}
{const r=await submit('3',{canceled:true});assert.equal(r.stats.str,5);assert.equal(r.messages.length,0);}
console.log('Stat form: warning removed; ordinary/whitespace/fullwidth/numeric input allocates correctly; empty/invalid/cancel spend nothing; insufficient balance remains protected; MAG allocation passed');
