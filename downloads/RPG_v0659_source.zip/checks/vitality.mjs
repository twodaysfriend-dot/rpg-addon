import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0638';
const base=root+'/RPG_BP_v0638/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}


let gear=0;
const stats=await load('scripts/core/stats.js',{getEquipmentBonuses:()=>({health:gear})});
const check=vit=>{
 const applied=[];let removed=0;
 const p={getDynamicProperty:k=>k==='rpg:stat_values'?JSON.stringify({str:5,mag:5,int:5,vit}):undefined,addEffect:(id,ticks,options)=>applied.push({id,ticks,...options}),getEffect:()=>({}),removeEffect:()=>removed++};
 stats.applyVitality(p);return {hp:20+(applied.length?4*(applied[0].amplifier+1):0),applied,removed};
};
assert.equal(check(5).hp,20);assert.equal(check(5).removed,1);
assert.equal(check(50).hp,120);assert.equal(check(50).applied[0].showParticles,false);
assert.equal(stats.VITALITY_HP_PER_POINT*45,100);
let previous=20;for(let vit=5;vit<=100;vit++){const n=check(vit).hp;assert.ok(n>=previous);previous=n;}
gear=20;assert.equal(check(50).hp,140);gear=0;assert.equal(check(50).hp,120);
console.log('Vitality: 5=20 HP, 50=120 HP without gear; monotonic growth, gear added separately, removing gear recomputes without stacking; passive health particles hidden');

const hud=await load('scripts/core/healthHud.js',{
 HudElement:{Health:'health',Armor:'armor',StatusEffects:'effects'},
 HudVisibility:{Hide:'hide'},
});
const hp={effectiveMax:148,currentValue:141};
const changes=[];
const player={id:'hud',getGameMode:()=> 'survival',getComponent:()=>hp,
 onScreenDisplay:{setHudVisibility:(...args)=>changes.push(args)}};
let rows=hud.updateHealthHud(player).text.split('\n');
assert.equal(rows.length,9);
assert.equal(rows[0],'§e\uE801\uE800\uE800\uE800§r');
assert.equal(rows.at(-1),'§cHP 141/148§r');
assert.equal(rows.at(-2),'§c'+'\uE802'.repeat(10)+'§r');
assert.equal(changes.length,1);
hud.updateHealthHud(player);
assert.equal(changes.length,1);
hp.effectiveMax=450;
hp.currentValue=420;
rows=hud.healthText(player).split('\n');
assert.equal(rows.length,22);
assert.deepEqual(rows.slice(0,21).map(row=>row[1]).reverse(),[...'ccc666eeeaaabbb999ddd']);
assert.equal(rows.at(-1),'§cHP 420/450§r');
player.getGameMode=()=> 'creative';
assert.equal(hud.healthText(player),'');
const rp=root+'/RPG_RP_v0638/';
const font=fs.readFileSync(rp+'font/glyph_E8.png');
assert.equal(font.readUInt32BE(16),256);
assert.equal(font.readUInt32BE(20),256);
const ui=JSON.parse(fs.readFileSync(rp+'ui/hud_screen.json'));
const clip=ui.item_name_text_root.controls[0].item_text_aligner.controls[0].item_text_control;
assert.equal(clip['$rpg_item_height|default'],10);
assert.equal(clip.clips_children,'$rpg_clip_item');
assert.equal(clip.controls[1].item_text_label.bindings[0].binding_name,'$text_binding');
console.log('Health HUD: half/empty/full hearts, all seven three-row color bands, row cap, numeric HP, creative mode and item-tooltip clipping configuration');
