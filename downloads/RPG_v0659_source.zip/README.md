# RPG v0.6.59 · 난식, 룬 인출, 하트 HUD

- 난식은 시선 기준 120도 부채꼴로 충격파 32발을 동시에 발사합니다. 각 탄의 기본 물리 피해는 8.5이고 사거리는 25칸입니다. 탄마다 첫 대상 또는 벽에서 멈춥니다.
- 투신의 후속 파동과 근접 연타는 타격 시점의 위치를 사용합니다. 난타와 러쉬는 처음에 접근하고 이후에는 현재 위치에서 근접 사거리를 확인합니다.
- 룬 보관함에서 모든 등급의 룬을 일반 인벤토리로 꺼낼 수 있습니다. 인출하면 장착이 해제되며 등급과 강화 단계는 유지됩니다.
- 핫바 아이템 팝업은 첫 줄 높이로 줄였습니다. 하트는 아래에서부터 세 줄마다 빨강, 주황, 노랑, 초록, 하늘, 파랑, 분홍으로 최대 21줄까지 표시합니다. 현재·최대 HP는 숫자로도 표시합니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.59로 활성화하세요. 클라우드에서는 모의 Script API와 리소스 구조까지 확인할 수 있으며, 실제 모바일 화면 렌더링 확인은 별도로 필요합니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0659
```
