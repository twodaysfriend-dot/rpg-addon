import { HudElement, HudVisibility } from '@minecraft/server';

const HEARTS_PER_ROW=10;
const MAX_ROWS=21;
const ROW_COLORS=['§c','§6','§e','§a','§b','§9','§d'];
const HEARTS=['\uE800','\uE801','\uE802'];
const quiet=new Set();

function quietHud(player){
  if(quiet.has(player.id))return;
  player.onScreenDisplay.setHudVisibility(HudVisibility.Hide,[HudElement.Health,HudElement.Armor,HudElement.StatusEffects]);
  quiet.add(player.id);
}

export function healthText(player) {
  const mode=String(player.getGameMode?.()).toLowerCase();
  if(mode==='creative'||mode==='spectator')return '';
  const hp=player.getComponent('minecraft:health');
  if(!hp||!Number.isFinite(hp.effectiveMax)||!Number.isFinite(hp.currentValue)||hp.effectiveMax<=0)return '';

  const current=Math.max(0,hp.currentValue);
  const hearts=Math.min(Math.ceil(hp.effectiveMax/2),MAX_ROWS*HEARTS_PER_ROW);
  const rows=[];
  for(let i=0;i<hearts;i+=HEARTS_PER_ROW){
    const row=i/HEARTS_PER_ROW;
    let text=ROW_COLORS[Math.floor(row/3)];
    for(let heart=i;heart<Math.min(i+HEARTS_PER_ROW,hearts);heart++){
      const health=current-heart*2;
      text+=HEARTS[health>=2?2:health>0?1:0];
    }
    rows.unshift(text+'§r');
  }
  const number=n=>String(Math.round(n*10)/10);
  rows.push('§cHP '+number(current)+'/'+number(hp.effectiveMax)+'§r');
  return rows.join('\n');
}

export function updateHealthHud(player) {
  quietHud(player);
  return {text:healthText(player)};
}
export function clearHealthHud(playerId) {quiet.delete(playerId);}
export function resetHealthHud(player) {
  quiet.delete(player.id);
  quietHud(player);
}
