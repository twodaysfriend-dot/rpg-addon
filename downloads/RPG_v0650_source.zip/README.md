# RPG v0.6.50 · 룬 선택 메뉴·용의 질주 자유 조향

Bedrock 1.21.100 이상. BP·Commands BP·RP 세 팩 모두 v0.6.50으로 활성화하고 월드를 다시 여세요. 기존 팩 UUID·아이템 ID·저장 데이터는 유지합니다.

## 룬 자동 완성: 직접 입력 제거

`/rpg:runeauto` 또는 `/rpg:runes` → 룬 자동 완성에서 네 항목을 드롭다운으로 고릅니다.

- 룬 종류: 힘·비전·수호·생명·샘·흡수, 총 6종.
- 목표 등급: 일반~신화, 총 7등급.
- 목표 강화: +0~+10.
- 시도당 촉매: 0~5개. 현재 +2부터 적용.

기본 선택은 힘·레어·+5·촉매 0개입니다. 최종 확인 후 시작하며, 취소하면 작업하지 않습니다. 기존 재귀 합성·강화 확률·비용·장착 보호·부족 시 중단·중간 결과 보존은 유지합니다.

## 용의 질주: 시선으로 커브·유턴

질주 중 카메라를 돌리면 매 틱 바라보는 수평 방향을 따라 움직입니다. 커브·원형 이동·180도 유턴이 가능하며, 수직을 바라보면 마지막 수평 방향을 유지합니다.

기존의 틱당 여러 차례 순간이동을 제거하고 Minecraft 속도/물리 이동으로 변경했습니다. 카메라 회전을 강제 설정하지 않습니다. 수평 속도 입력은 틱당 1.05칸(20TPS 기준 초당 21칸 목표)이며 실제 이동 거리는 엔진의 마찰·충돌·서버 TPS에 영향을 받습니다. 5초 지속, 벽에서 중단, 감옥·던전 경계 검사, 아군 제외 및 같은 적 한 번 타격 규칙을 유지합니다. 종료 시 질주 속도를 제거합니다.

## 검증 범위

Node.js 24·Python 3.12 기반 모의 Minecraft API 및 실제 모듈 회귀 검사를 사용합니다. 선택지 개수·기본값·직접 입력 금지·확인 후 실행, 두 바퀴 연속 커브·유턴·수평 속도 정규화·100틱 종료·질주 순간이동 금지·경계 거부를 검사합니다. 기존 룬 재화 보존·부족/오류 복구·장착 보호와 전체 회귀 검사도 실행합니다.

실제 Minecraft 엔진의 터치/마우스 조향, 마찰·경사·충돌 및 UI 렌더링은 이 클라우드에서 실행할 수 없어 별도 인게임 확인이 필요합니다.

## 개발·검증·패키징

Node.js 24와 Python 3.12를 사용합니다. 별도 패키지 설치나 서버는 필요하지 않습니다. 내부 v0638 폴더명은 호환용으로 유지합니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0650
```
