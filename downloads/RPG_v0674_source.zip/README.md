# RPG v0.6.74 · 공속·치명타·쿨타임 감소 룬

- **공속의 룬**은 활의 최대 위력에 필요한 당기는 시간, 즉발 활의 발사 간격, 달의 차크람 투척 간격을 줄입니다. 신화 +10 기준 간격은 기본의 3분의 1을 틱 단위로 올림하고 해당 투사체 속도는 최대 3배입니다. 기본 쇠뇌와 삼지창은 투사체 속도에 적용되고, 장전 시간은 Bedrock 기본 동작을 따릅니다.
- **치명타의 룬**은 기본 무기 공격과 물리·마법 스킬에 적용합니다. 100% 미만에서 발동 피해는 175%, 100%부터 확정 발동하며 초과 확률을 피해 배율에 가산합니다. 확률 150%는 피해 225%, 신화 +10의 250%는 피해 325%입니다.
- **쿨타임 감소의 룬**은 신화 +10에서 스킬 쿨타임을 60% 줄입니다. **더 월드!, 시스템 재부팅, 혈촉수**는 각각 20초, 40초, 5초 쿨타임을 사용합니다. 룬을 장착한 뒤 새로 사용한 스킬부터 계산합니다.
- 신규 룬은 일반·RPG 몬스터 룬 드롭 또는 작업대에서 얻으며, 룬 보관함에 넣어 장착하세요. 기본 재료는 각 자수정 블록 3개입니다. 공속은 금 블록 1개·깃털 2개, 치명타는 레드스톤 블록 2개·다이아몬드 1개, 쿨타임 감소는 시계 1개·네더 석영 2개를 추가합니다. 흡수의 룬은 석판 스타일 새 도트를 사용합니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.74로 활성화하고 월드를 다시 여세요. 모의 전투에서 장착·꺼내기, 치명타 확률·초과 피해, 스킬 쿨타임과 세 가지 예외, 투사체 가속을 확인했습니다. 실제 Bedrock 월드에서의 조작 및 렌더링은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0674
```
