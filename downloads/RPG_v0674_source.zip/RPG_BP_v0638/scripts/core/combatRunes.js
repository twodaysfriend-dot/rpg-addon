import { RUNES } from '../data/equipment.js';
import { upgradedRune } from '../data/upgrades.js';
import { equippedRunes } from './runeInventory.js';

function equippedValue(player,id,key){
  if(player?.typeId!=='minecraft:player')return 0;
  try{
    const rune=equippedRunes(player).find(entry=>entry.id===id);
    return rune ? upgradedRune(RUNES[id],rune.level,rune.grade)[key] : 0;
  }catch{return 0;}
}

export function criticalMultiplier(chance,random=Math.random){
  chance=Math.min(chance,2.5);
  if(chance<=0 || (chance<1 && random()>=chance))return 1;
  return 1.75+Math.max(0,chance-1);
}

export function criticalRuneMultiplier(player){
  return criticalMultiplier(equippedValue(player,'critical_hit','criticalChance'));
}

export function rangedRuneRate(player){
  return 1+equippedValue(player,'attack_speed','rangedHaste');
}

export function runeSkillCooldown(player,skill,ticks){
  if(!skill || skill.cooldownReduction===false || ticks<=0)return ticks;
  const reduction=equippedValue(player,'cooldown_reduction','cooldownReduction');
  return reduction>0 ? Math.max(1,Math.ceil(ticks*(1-reduction))) : ticks;
}
