import {MISSION_HYDRA,MISSION_HYDRA_LEVEL} from '../RPG_BP_v0638/scripts/data/chameleonMissions.js';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {DUNGEON_HEALTH_PRESSURE,MONSTER_LEVELS,dungeonMonsterLevel,monsterCombatMultipliers} from '../RPG_BP_v0638/scripts/data/monsterLevels.js';
import {DUNGEON_TIERS} from '../RPG_BP_v0638/scripts/data/dungeons.js';
import {MONSTER_BASE_STATS,MONSTER_STAT_MULTIPLIERS} from '../RPG_BP_v0638/scripts/data/dungeonBalance.js';
import {LEVELED_MONSTERS} from '../RPG_BP_v0638/scripts/data/leveledMonsters.js';
import {NIGHT_DIFFICULTIES,NIGHT_ROSTER,nightScaleEvent} from '../RPG_BP_v0638/scripts/data/nightDefense.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const check=process.argv.includes('--check'),round=(n,places=2)=>Number(n.toFixed(places));
let groups=0;
for(const id of LEVELED_MONSTERS){
 const name=id.split(':')[1];
 const file=path.join(root,'RPG_BP_v0638/entities',name+'.json'),original=fs.readFileSync(file,'utf8'),json=JSON.parse(original),entity=json['minecraft:entity'];
 const base=entity.components,buff=MONSTER_STAT_MULTIPLIERS[id];
 base['minecraft:loot']={table:'loot_tables/rpg_no_mob_drops.json'};
 if(buff){
  const profile=MONSTER_BASE_STATS[name];
  base['minecraft:health'].value=base['minecraft:health'].max=profile.health*buff.health;
  base['minecraft:attack'].damage=profile.attack*buff.attack;
 }
 const hp=base['minecraft:health'].max,attack=base['minecraft:attack'].damage;
 const scaledKeys=Object.keys(entity.component_groups).filter(k=>/^rpg:(?:level_|dungeon_scaled_|dungeon_tier_)/.test(k));
 if(id===MISSION_HYDRA&&!scaledKeys.includes('rpg:level_'+MISSION_HYDRA_LEVEL))scaledKeys.push('rpg:level_'+MISSION_HYDRA_LEVEL);
 const setGroup=(key,m,nightKeys)=>{
  const value=round(hp*m.health);
  entity.component_groups[key]={...entity.component_groups[key],
   'minecraft:health':{value,max:value},
   'minecraft:damage_sensor':{triggers:[{cause:'all',damage_multiplier:round(m.defense,6)}]},
   'minecraft:attack':{damage:round(attack*m.attack)}
  };
  entity.events[key]={
   remove:{component_groups:nightKeys?[...scaledKeys,...nightKeys]:scaledKeys},
   add:{component_groups:nightKeys?['rpg:dungeon_persistent','rpg:night_defense_assault',key]:[key]}
  };
  groups++;
 };
 for(const level of MONSTER_LEVELS)setGroup('rpg:level_'+level,monsterCombatMultipliers(level));
 if(id===MISSION_HYDRA)setGroup('rpg:level_'+MISSION_HYDRA_LEVEL,monsterCombatMultipliers(MISSION_HYDRA_LEVEL));
 for(const tier of DUNGEON_TIERS){
  // The scaled event immediately follows this compatibility event at spawn.
  const key='rpg:dungeon_tier_'+tier.tier,g=entity.component_groups[key];
  if(g){g['minecraft:health']={value:round(hp*tier.hpMultiplier*DUNGEON_HEALTH_PRESSURE[tier.tier-1]),max:round(hp*tier.hpMultiplier*DUNGEON_HEALTH_PRESSURE[tier.tier-1])};
  g['minecraft:attack']={damage:round(attack*tier.attackMultiplier)};}
  for(const kind of ['normal','elite','boss'])for(let index=0;index<(kind==='normal'?3:1);index++){
   const context={tier:tier.tier,kind,index},level=dungeonMonsterLevel(tier.tier,kind,index);
   setGroup(`rpg:dungeon_scaled_${tier.tier}_${kind}_${index}`,monsterCombatMultipliers(level,context,id));
  }
 }
 const nightContexts=NIGHT_DIFFICULTIES.flatMap(difficulty=>Object.entries(NIGHT_ROSTER).flatMap(([kind,roster])=>{
  if(!roster.includes(name))return [];
  return Array.from({length:kind==='normal'?3:kind==='boss'&&name==='hydra_boss'?2:1},
   (_,index)=>({tier:10,kind,index,nightDifficulty:difficulty.id,reinforced:kind==='boss'&&index===1}));
 }));
 if(nightContexts.length){
  entity.component_groups['rpg:night_defense_assault']={
   'minecraft:behavior.nearest_attackable_target':{priority:0,scan_interval:5,within_radius:56,reselect_targets:true,
    must_see:false,must_reach:false,entity_types:[{filters:{test:'is_family',subject:'other',value:'rpg_night_core'},max_dist:56}]},
   'minecraft:behavior.move_towards_target':{priority:4,speed_multiplier:1.1,within_radius:56},
  };
  const nightKeys=nightContexts.map(nightScaleEvent);
  for(const ctx of nightContexts)setGroup(nightScaleEvent(ctx),monsterCombatMultipliers(dungeonMonsterLevel(10,ctx.kind,ctx.index),ctx,id),nightKeys);
 }
 const output=JSON.stringify(json,null,2)+'\n';
 if(check){if(original!==output)throw Error('Stale generated balance: '+file);}else fs.writeFileSync(file,output);
}
console.log(`${check?'Verified':'Generated'} ${groups} wild/dungeon component groups across ${LEVELED_MONSTERS.length} entities`);
