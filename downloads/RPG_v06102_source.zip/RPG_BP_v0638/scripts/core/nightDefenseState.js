import { NIGHT } from '../data/nightDefense.js';

export const NIGHT_RETURN_KEY = 'rpg:night_defense_return';
export let activeNightDefense;
export function setActiveNightDefense(run) { activeNightDefense=run; }
export function nightRunFor(player) {
  const run=activeNightDefense;
  return run?.members.has(player?.id) ? run : undefined;
}
export function insideNightField(position,dimensionId,field) {
  return Boolean(position&&field&&dimensionId===field.dimId&&
    Math.abs(position.x-field.x)<NIGHT.radius&&Math.abs(position.z-field.z)<NIGHT.radius&&
    position.y>=field.y+1&&position.y<field.y+NIGHT.height+1);
}
export function nightHudText(player) {
  const run=nightRunFor(player);if(!run)return '';
  const phase=run.wave===0?'입장 준비':`세트 ${run.wave}/${NIGHT.waves} · 남은 적 ${run.live.size}`;
  return `§d종말의 밤 §f${phase} §c핵 ${Math.ceil(run.hp)}/${NIGHT.coreHealth}§r`;
}
