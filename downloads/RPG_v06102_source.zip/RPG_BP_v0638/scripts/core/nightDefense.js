import { system, world } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { NIGHT, NIGHT_CORE, NIGHT_DIFFICULTIES, NIGHT_MOB_TAG, nightBlock, nightEliteWave, nightWavePlan } from '../data/nightDefense.js';
import { MONSTER_BASE_STATS } from '../data/dungeonBalance.js';
import { dungeonMonsterLevel, monsterAttackMultiplier } from '../data/monsterLevels.js';
import { isRpgAdmin } from './adminPermissions.js';
import { dungeonEnrollmentGroup } from './dungeonParty.js';
import { dungeonLobbies } from './dungeonState.js';
import { activeDungeonRun } from './dungeonMovement.js';
import { duelOf } from './pvp.js';
import { hasBuilderTag, registerStructureProtection } from './structureProtection.js';
import { applyMonsterLevel } from './monsterLevels.js';
import { clearBlockPath, dist3, healthAlive, particle, sound } from './util.js';
import { isJailed } from './prison.js';
import { isTimeFrozen } from './timeStopDamage.js';
import { showForm } from './skillMenu.js';
import { activeNightDefense, insideNightField, nightHudText, nightRunFor, NIGHT_RETURN_KEY, setActiveNightDefense } from './nightDefenseState.js';

export const NIGHT_FIELD_KEY = 'rpg:night_defense_field';
const ENTITY_RUN_KEY = 'rpg:night_defense_run';
const BEST_KEY = 'rpg:night_defense_best';
const TICKING_AREA = 'rpg_night_defense';
const ENTRY_TIMEOUT = 240;
const BUILD_BUDGET = 768;
const WAVE_PAUSE = 60;
const CORE_ATTACK_DELAY = 36;
const ADVANCE_CHECK = 25;
let build, registered = false;
const menus = new Set();

const fieldData = () => JSON.parse(world.getDynamicProperty(NIGHT_FIELD_KEY) ?? 'null');
const saveField = field => world.setDynamicProperty(NIGHT_FIELD_KEY, field ? JSON.stringify(field) : undefined);
const online = id => world.getAllPlayers().find(p => p.id===id);
const dimOf = field => world.getDimension(field.dimId);
const atField = (field,x=0,y=1,z=0) => ({x:field.x+.5+x,y:field.y+y,z:field.z+.5+z});
const announce = (player,message) => {try{player?.sendMessage(message);}catch{}};
const tellRun = (run,message) => {for(const id of run.members.keys())announce(online(id),message);};
const canEnter = player => player.isValid!==false&&validMember(player)&&
  !['creative','spectator'].includes(String(player.getGameMode?.()).toLowerCase())&&
  !activeDungeonRun(player)&&!duelOf(player)&&!player.getDynamicProperty(NIGHT_RETURN_KEY)&&
  !player.getDynamicProperty('rpg:dungeon_return_v1')&&
  ![...dungeonLobbies.values()].some(lobby=>lobby.members.some(m=>m.id===player.id));

function* fieldBlocks(field) {
  for(let y=0;y<=NIGHT.height;y++)for(let x=-NIGHT.radius;x<=NIGHT.radius;x++)for(let z=-NIGHT.radius;z<=NIGHT.radius;z++){
    yield {pos:{x:field.x+x,y:field.y+y,z:field.z+z},type:nightBlock(x,y,z)};
  }
}

function loadField(field) {
  const result=dimOf(field).runCommand(`tickingarea add ${field.x-NIGHT.radius} ${field.y} ${field.z-NIGHT.radius} ${field.x+NIGHT.radius} ${field.y+NIGHT.height} ${field.z+NIGHT.radius} ${TICKING_AREA} true`);
  if(result?.successCount===0)throw Error('필드 청크를 불러오지 못했습니다. tickingarea 공간을 확인하세요.');
}

function unloadField(field) {
  try{dimOf(field).runCommand('tickingarea remove '+TICKING_AREA);}catch{}
}

export function createNightDefense(player) {
  if(!isRpgAdmin(player))throw Error('종말의 밤 필드 생성은 관리자만 가능합니다.');
  if(player.dimension.id!=='minecraft:overworld')throw Error('오버월드에서 생성하세요.');
  if(activeNightDefense)throw Error('종말의 밤 전투가 진행 중입니다.');
  if(build)throw Error('필드를 생성하는 중입니다.');
  const previous=fieldData(), field=previous??{
    x:Math.floor(player.location.x),y:NIGHT.floor,z:Math.floor(player.location.z),dimId:player.dimension.id,
  };
  loadField(field);
  try{
    saveField({...field,ready:false});
    build={field,previous,player,phase:'scan',blocks:fieldBlocks(field),resumeAt:system.currentTick+20,last:system.currentTick+20};
  }catch(error){unloadField(field);throw error;}
  announce(player,`§e종말의 밤 필드 검사 중 · ${field.x} ${field.y} ${field.z}`);
  return field;
}

function buildTick(job) {
  if(system.currentTick<job.resumeAt)return;
  try{
    const dim=dimOf(job.field);
    for(let step=0;step<BUILD_BUDGET;step++){
      if(!job.pending){
        const result=job.blocks.next();
        if(result.done){
          if(job.phase!=='verify'){
            job.phase=job.phase==='scan'?'build':'verify';
            job.blocks=fieldBlocks(job.field);
            return;
          }
          saveField({...job.field,ready:true});
          unloadField(job.field);build=undefined;
          announce(job.player,'§a종말의 밤 필드 완성 · /rpg:nightdefense');
          return;
        }
        job.pending=result.value;
      }
      const {pos,type}=job.pending,block=dim.getBlock(pos);
      if(!block)throw Error('청크 대기');
      const air=block.isAir||block.typeId==='minecraft:air', matches=block.typeId===type;
      if(job.phase==='verify'&&!(type?matches:air))throw Error(`필드 블록 검증에 실패했습니다 (${pos.x} ${pos.y} ${pos.z}).`);
      if(!air&&!(matches&&(job.previous||job.phase!=='scan'))){
        throw Error(`기존 블록과 겹칩니다 (${pos.x} ${pos.y} ${pos.z}).`);
      }
      if(job.phase==='build'&&type&&block.typeId!==type)block.setType(type);
      job.pending=undefined;job.last=system.currentTick;
    }
  }catch(error){
    if(/chunk|청크/i.test(String(error))&&system.currentTick-job.last<600){job.resumeAt=system.currentTick+20;return;}
    unloadField(job.field);build=undefined;
    if(job.phase==='scan')saveField(job.previous);
    announce(job.player,'§c종말의 밤 필드 생성 중단 · '+String(error.message??error));
  }
}

function returnPlayer(player) {
  const raw=player.getDynamicProperty(NIGHT_RETURN_KEY);
  if(!raw||!healthAlive(player))return false;
  if(!isJailed(player)){
    const back=JSON.parse(raw);
    player.teleport(back.location,{dimension:world.getDimension(back.dimId),keepVelocity:false});
  }
  player.setDynamicProperty(NIGHT_RETURN_KEY,undefined);
  return true;
}

function removeEntity(entity) {try{if(entity?.isValid!==false)entity?.remove();}catch{}}

function finish(run,victory,message) {
  if(activeNightDefense!==run)return;
  setActiveNightDefense(undefined);
  removeEntity(run.core);
  for(const {mob} of run.live.values())removeEntity(mob);
  run.live.clear();
  unloadField(run.field);
  for(const id of run.participants){
    const p=online(id);
    if(!p)continue;
    const won=victory&&run.members.has(id);
    if(won)try{p.setDynamicProperty(BEST_KEY,Math.max(Number(p.getDynamicProperty(BEST_KEY))||0,run.difficulty.id));}catch{}
    announce(p,won?`§6종말의 밤 승리! ${run.difficulty.name} · 핵 체력 ${Math.ceil(run.hp)}/${NIGHT.coreHealth}`:'§c종말의 밤 · '+(victory?'참가가 종료됐습니다.':message));
    try{returnPlayer(p);}catch{announce(p,'§e귀환 대기 중입니다. /rpg:nightdefense로 다시 시도하세요.');}
  }
}

function spawnEnemy(run,entry) {
  const slot=run.spawnIndex++, angle=(slot%4)*Math.PI/2+(Math.floor(slot/4)-1)*.24;
  const radius=entry.kind==='boss'?27:31;
  const mob=dimOf(run.field).spawnEntity('rpg:'+entry.type,atField(run.field,Math.cos(angle)*radius,1,Math.sin(angle)*radius));
  const context={tier:10,kind:entry.kind,index:entry.index,nightDifficulty:run.difficulty.id,reinforced:entry.reinforced===true};
  try{
    mob.addTag(NIGHT_MOB_TAG);
    mob.setDynamicProperty(ENTITY_RUN_KEY,run.id);
    if(!applyMonsterLevel(mob,dungeonMonsterLevel(10,entry.kind,entry.index),context))throw Error('공격대 몹 스펙 초기화 실패');
    if(entry.reinforced)mob.nameTag='§c[강화]§r '+mob.nameTag;
    const baseAttack=MONSTER_BASE_STATS[entry.type].attack;
    const attack=Math.max(1,Math.round(monsterAttackMultiplier(mob)*baseAttack*.23));
    run.live.set(mob.id,{mob,entry,attack,nextStrike:system.currentTick+CORE_ATTACK_DELAY+slot%8,
      lastPosition:mob.location,advanceAt:system.currentTick+ADVANCE_CHECK});
  }catch(error){removeEntity(mob);throw error;}
}

function nextWave(run) {
  run.wave++;
  run.spawnIndex=0;
  for(const entry of nightWavePlan(run.wave))spawnEnemy(run,entry);
  tellRun(run,`§d[종말의 밤] ${run.wave}/${NIGHT.waves}세트${nightEliteWave(run.wave)?' · 엘리트와 강화 히드라 출현':''}`);
}
function spawnCore(run) {
  const core=dimOf(run.field).spawnEntity(NIGHT_CORE,atField(run.field));
  run.core=core;
  core.setDynamicProperty(ENTITY_RUN_KEY,run.id);
  core.nameTag='§d방어 핵 §f5000 / 5000';
  nextWave(run);
}

export function startNightDefense(player,value,solo=true) {
  const difficulty=NIGHT_DIFFICULTIES.find(d=>String(d.id)===String(value));
  if(!difficulty)throw Error('난이도 1~4를 선택하세요.');
  if(activeNightDefense)throw Error('다른 팀이 종말의 밤에 도전 중입니다.');
  const field=fieldData();
  if(!field?.ready||build)throw Error('관리자가 /rpg:nightdefensecreate로 필드를 먼저 생성해야 합니다.');
  const group=dungeonEnrollmentGroup(player,solo);
  if(group.length>NIGHT.maxParty||!group.every(canEnter))throw Error('참가자 전원이 생존한 상태여야 하며 다른 전투나 귀환 진행 중에는 입장할 수 없습니다. 최대 4명입니다.');
  const members=new Map(group.map((p,i)=>[p.id,atField(field,(i%2)*2-1,1,-8+Math.floor(i/2)*2)]));
  const run={id:Date.now().toString(36)+'_'+system.currentTick,field,difficulty,members,participants:[...members.keys()],
    live:new Map(),hp:NIGHT.coreHealth,wave:0,spawnIndex:0,nextAt:system.currentTick+20,deadline:system.currentTick+ENTRY_TIMEOUT};
  loadField(field);
  setActiveNightDefense(run);
  try{
    for(const p of group){
      p.setDynamicProperty(NIGHT_RETURN_KEY,JSON.stringify({dimId:p.dimension.id,location:p.location}));
      p.teleport(members.get(p.id),{dimension:dimOf(field),keepVelocity:false});
    }
  }catch(error){finish(run,false,'입장에 실패해 귀환합니다.');throw error;}
  tellRun(run,`§d종말의 밤 · ${difficulty.name} · 핵을 ${NIGHT.waves}세트 동안 지키세요.`);
  return run;
}

function validMember(player) {
  return healthAlive(player)&&!isJailed(player);
}

function advanceStalledMob(unit,base,dim,now) {
  if(now<unit.advanceAt)return;
  const {mob,lastPosition}=unit,loc=mob.location;
  unit.lastPosition=loc;
  unit.advanceAt=now+ADVANCE_CHECK;
  const dx=base.x-loc.x,dz=base.z-loc.z,distance=Math.hypot(dx,dz);
  if(distance<2||dist3(loc,lastPosition)>.6||(mob.getEffect?.('slowness')?.amplifier??0)>=4)return;
  const step={x:dx/distance,z:dz/distance};
  const chest={...loc,y:loc.y+.75};
  if(clearBlockPath(dim,chest,{x:chest.x+step.x*1.4,y:chest.y,z:chest.z+step.z*1.4})){
    try{mob.applyImpulse({x:step.x*.4,y:0,z:step.z*.4});}catch{}
  }
}

function maintainRun(run) {
  for(const [id,entryPoint] of run.members){
    const p=online(id);
    if(!p||!validMember(p)){
      run.members.delete(id);
      if(p&&isJailed(p))try{returnPlayer(p);}catch{}
      continue;
    }
    if(!insideNightField(p.location,p.dimension.id,run.field))p.teleport(entryPoint,{dimension:dimOf(run.field),keepVelocity:false});
  }
  if(!run.members.size){finish(run,false,'참가자가 전투에서 이탈했습니다.');return;}
  const now=system.currentTick;
  if(!run.core){
    if(now<run.nextAt)return;
    try{spawnCore(run);}catch(error){
      const canRetry=run.live.size===0&&now<run.deadline&&/chunk|청크/i.test(String(error));
      if(canRetry){removeEntity(run.core);run.core=undefined;run.wave=0;run.nextAt=now+20;return;}
      throw error;
    }
    return;
  }
  if(run.core.isValid===false){finish(run,false,'핵을 잃었습니다.');return;}
  if(!run.live.size){
    if(run.wave===NIGHT.waves){finish(run,true,'방어 성공');return;}
    if(now>=run.nextAt)nextWave(run);
    return;
  }
  const base=atField(run.field,0,1.3,0),dim=dimOf(run.field);
  let received=0;
  for(const [id,unit] of [...run.live]){
    const {mob,entry}=unit;
    if(mob.isValid===false){
      run.live.delete(id);spawnEnemy(run,entry);continue;
    }
    if(!insideNightField(mob.location,mob.dimension.id,run.field)){
      mob.teleport(atField(run.field,0,1,22),{dimension:dim,keepVelocity:false});
      continue;
    }
    if(isTimeFrozen(mob)||!healthAlive(mob))continue;
    const attackPoint={...mob.location,y:mob.location.y+1};
    if(dist3(attackPoint,base)>(entry.kind==='boss'?7:3.6)){
      advanceStalledMob(unit,base,dim,now);
      continue;
    }
    if(now<unit.nextStrike||!clearBlockPath(dim,attackPoint,base))continue;
    unit.nextStrike=now+CORE_ATTACK_DELAY;
    received+=unit.attack;
  }
  if(!received)return;
  run.hp=Math.max(0,run.hp-received);
  if(run.hp<=0){finish(run,false,'핵이 파괴됐습니다.');return;}
  run.core.getComponent('minecraft:health')?.setCurrentValue(run.hp);
  run.core.nameTag=`§d방어 핵 §f${Math.ceil(run.hp)} / ${NIGHT.coreHealth}`;
  particle(dim,'minecraft:critical_hit_emitter',base);
  sound(dim,'random.glass',base,{volume:.55,pitch:.65});
}

export function nightDefenseTick() {
  if(build)buildTick(build);
  const run=activeNightDefense;
  if(!run)return;
  try{maintainRun(run);}catch(error){
    console.warn('[RPG night defense] '+error);
    finish(run,false,'전투 진행 오류로 종료됐습니다.');
  }
}

export function nightDefenseDeath(entity) {
  const run=activeNightDefense;
  if(!run||!entity)return;
  if(entity.id===run.core?.id){finish(run,false,'핵이 파괴됐습니다.');return;}
  if(run.members.delete(entity.id)){
    if(!run.members.size)finish(run,false,'참가자가 모두 쓰러졌습니다.');
    return;
  }
  if(!run.live.delete(entity.id)||run.live.size)return;
  if(run.wave===NIGHT.waves)finish(run,true,'방어 성공');
  else{
    run.nextAt=system.currentTick+WAVE_PAUSE;
    tellRun(run,'§a세트 방어 성공 · 3초 후 다음 세트');
  }
}

export async function openNightDefense(player) {
  if(menus.has(player.id))return;
  menus.add(player.id);
  try{
    if(nightRunFor(player)){
      await showForm(new ActionFormData().title('종말의 밤').body(nightHudText(player)).button('닫기'),player);
      return;
    }
    if(player.getDynamicProperty(NIGHT_RETURN_KEY)&&!returnPlayer(player))return;
    if(activeNightDefense)throw Error('다른 팀이 종말의 밤에 도전 중입니다.');
    if(!fieldData()?.ready)throw Error('종말의 밤 필드를 먼저 생성해야 합니다. /rpg:nightdefensecreate');
    const best=Number(player.getDynamicProperty(BEST_KEY))||0;
    const form=new ActionFormData().title('종말의 밤')
      .body(`핵 5,000 HP · 총 10세트 · 1~4명\n최고 클리어 ${NIGHT_DIFFICULTIES[best-1]?.name??'기록 없음'}`);
    for(const difficulty of NIGHT_DIFFICULTIES)form.button(difficulty.id+'. '+difficulty.name+(difficulty.id===1?' · 10단계 던전 솔로 기준':''));
    form.button('닫기');
    const pick=await showForm(form,player),difficulty=!pick?.canceled&&NIGHT_DIFFICULTIES[pick?.selection];
    if(!difficulty)return;
    const party=dungeonEnrollmentGroup(player).length>1;
    const modes=new ActionFormData().title(difficulty.name).button('혼자 시작');
    if(party)modes.button('파티 출발');
    modes.button('닫기');
    const mode=await showForm(modes,player);
    if(!mode?.canceled&&(mode?.selection===0||party&&mode?.selection===1))startNightDefense(player,difficulty.id,mode.selection===0);
  }catch(error){announce(player,'§c[종말의 밤] '+String(error.message??error));}
  finally{menus.delete(player.id);}
}

function cleanupStaleEntity(entity) {
  try{
    const isCore=entity.typeId===NIGHT_CORE;
    if(!isCore&&!entity.hasTag?.(NIGHT_MOB_TAG))return;
    const run=activeNightDefense;
    if(!run||entity.getDynamicProperty(ENTITY_RUN_KEY)!==run.id||
      (isCore?run.core?.id!==entity.id:!run.live.has(entity.id)))removeEntity(entity);
  }catch{}
}

export function registerNightDefense() {
  if(registered)return;registered=true;
  world.afterEvents.entityDie.subscribe(({deadEntity})=>nightDefenseDeath(deadEntity));
  world.afterEvents.entityLoad?.subscribe(({entity})=>system.run(()=>cleanupStaleEntity(entity)));
  world.afterEvents.playerSpawn.subscribe(({player})=>system.runTimeout(()=>{
    if(!nightRunFor(player))try{returnPlayer(player);}catch{}
  },20));
  registerStructureProtection('night_defense',(block,player)=>{
    if(hasBuilderTag(player)&&!activeNightDefense)return false;
    const field=activeNightDefense?.field??fieldData(), p=block.location;
    return field&&block.dimension.id===field.dimId&&Math.abs(p.x-field.x)<=NIGHT.radius&&
      Math.abs(p.z-field.z)<=NIGHT.radius&&p.y>=field.y&&p.y<=field.y+NIGHT.height;
  });
  system.run(()=>{
    const field=fieldData();if(!field)return;
    const dim=dimOf(field);
    if(!activeNightDefense&&!build)unloadField(field);
    try{
      for(const entity of dim.getEntities({type:NIGHT_CORE}))cleanupStaleEntity(entity);
      for(const entity of dim.getEntities({tags:[NIGHT_MOB_TAG]}))cleanupStaleEntity(entity);
    }catch{}
    for(const p of world.getAllPlayers())try{returnPlayer(p);}catch{}
  });
  system.runInterval(nightDefenseTick,5);
}
