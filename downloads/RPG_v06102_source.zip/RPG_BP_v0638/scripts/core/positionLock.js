import { world } from '@minecraft/server';
import {NIGHT_CORE} from '../data/nightDefense.js';

export const SANDBAG_ID = 'rpg:sandbag_entity';
export const SUPER_SANDBAG_ID = 'rpg:super_sandbag';
export const SUPER_SANDBAG_MK2_ID = 'rpg:super_sandbag_mk2';

export const isSuperSandbag = type => type === SUPER_SANDBAG_ID || type === SUPER_SANDBAG_MK2_ID;
export const isTrainingDummy = type => type === SANDBAG_ID || isSuperSandbag(type);
export const isPositionLocked = type => type===NIGHT_CORE || isTrainingDummy(type) || Boolean(type?.startsWith('rpg:hito_'));

export function maintainEntityPosition(entity, anchorKey) {
  if (entity.isValid === false) return;
  const { location, dimension } = entity;
  const saved = entity.getDynamicProperty(anchorKey);
  if (typeof saved !== 'string') {
    entity.setDynamicProperty(anchorKey, JSON.stringify({ location, dimension: dimension.id }));
    return;
  }
  const anchor = JSON.parse(saved);
  if (dimension.id === anchor.dimension &&
      Math.hypot(location.x - anchor.location.x, location.y - anchor.location.y, location.z - anchor.location.z) <= 0.01) return;
  const destination = dimension.id === anchor.dimension ? dimension : world.getDimension(anchor.dimension.replace(/^minecraft:/, ''));
  entity.teleport(anchor.location, { dimension: destination, keepVelocity: false });
}
