import {NIGHT_RETURN_KEY} from './nightDefenseState.js';
import * as mc from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { JOBS,isChameleonJob } from '../data/jobs.js';
import {
  getJobId, getMana, jobHistory, saveJobLoadout, setDisabled, setIndex, setJobId, setMana,
  setSkills, storedJobLoadout,
} from './playerData.js';
import { STORED_JOB_WEAPON } from './advance.js';
import { activeDungeonRun } from './dungeonMovement.js';
import { duelOf } from './pvp.js';
import { isJailed } from './prison.js';
import { isTimeFrozen } from './timeStopDamage.js';
import { bloodReserveOf, clearBloodReserve, gainBloodReserve } from './bloodedgeState.js';
import { syncChameleonLoadout } from './chameleonProgress.js';
import { applyVitality } from './stats.js';
import { refreshHud } from './hud.js';
import { showForm } from './skillMenu.js';
import { weaponBinding, WEAPON_UID } from './weaponBinding.js';

const { world, system, ItemStack, ItemLockMode } = mc;
const requestLifetime = 60 * 20;
const changeCooldownMs = 30 * 60 * 1000;
const changeCooldownKey = 'rpg:job_change_until';
const moonFocus = 'rpg:moon_heir_focus';
const requests = new Map();
const menus = new Set();

const jobName = id => JOBS[id]?.name ?? '견습';
const online = id => world.getAllPlayers().find(player => player.id === id);

function changeWait(player) {
  const oldUntil = Number(player.getDynamicProperty('rpg:job_return_until') ?? 0);
  const until = player.getDynamicProperty(changeCooldownKey) ?? (oldUntil + 20 * 60 * 1000);
  const seconds = Math.ceil((Number(until) - Date.now()) / 1000);
  return seconds > 0 ? `${Math.floor(seconds / 60)}분 ${seconds % 60}초` : '';
}

function tell(player, text) {
  try { player?.sendMessage(text); } catch {}
}

function available(player) {
  return player?.isValid && (player.getComponent('minecraft:health')?.currentValue ?? 0) > 0 &&
    !isJailed(player) && !player.getDynamicProperty(NIGHT_RETURN_KEY) && !activeDungeonRun(player) && !duelOf(player) && !isTimeFrozen(player);
}

function exchangeProblem(sender, recipient) {
  if (!available(sender) || !available(recipient)) return '두 플레이어 모두 접속 중이어야 하며 사망·수감·던전·결투·시간 정지 중에는 교환할 수 없습니다.';
  const wait = changeWait(sender) || changeWait(recipient);
  if (wait) return '직업 교체 대기시간이 남아 있어 교환할 수 없습니다. · ' + wait;
  const from = getJobId(sender), to = getJobId(recipient);
  if (!from || !to || from === 'apprentice' || to === 'apprentice' || JOBS[from].placeholder || JOBS[to].placeholder)
    return '두 플레이어 모두 전직을 마쳐야 교환할 수 있습니다.';
  if (from === 'hacker' || to === 'hacker') return '해커는 월드 최초 전직자 전용 직업이라 교환할 수 없습니다.';
  if (from === to) return '서로 다른 직업끼리 교환할 수 있습니다.';
}

function inventoryPlan(player, target) {
  const container = player.getComponent('minecraft:inventory')?.container;
  if (!container) throw Error(player.name + '의 인벤토리를 열 수 없습니다.');
  const before = Array.from({length: container.size}, (_, slot) => container.getItem(slot));
  const after = before.slice();
  const changes = new Set();
  const put = (slot, item) => { after[slot] = item; changes.add(slot); };
  const previous = JOBS[getJobId(player)];
  const priorWeapon = item => item && (item.typeId === previous?.weapon || item.typeId === previous?.altWeapon ||
    (previous?.id === 'moon_heir' && item.typeId === moonFocus));
  const store = item => {
    const saved = item.clone();
    saved.setDynamicProperty(STORED_JOB_WEAPON, true);
    saved.lockMode = ItemLockMode?.inventory ?? 'inventory';
    return saved;
  };
  const emptySlot = () => after.findIndex((item, slot) => slot > 0 && !item);
  const noSpace = () => Error(player.name + '의 인벤토리에 직업 장비를 보관할 빈칸이 필요합니다.');

  const binding = weaponBinding(player);
  const boundSlot = binding ? after.findIndex(item => item?.typeId === binding.type &&
    item.getDynamicProperty(WEAPON_UID) === binding.uid) : -1;
  const targetWeapon = item => item && (item.typeId === target.weapon || item.typeId === target.altWeapon);
  if (boundSlot >= 0) {
    if (boundSlot !== 0) {
      put(0, before[boundSlot]);
      put(boundSlot, before[0]);
    }
  } else {
    const source = after.findIndex(targetWeapon);
    const active = source >= 0 ? after[source].clone() : new ItemStack(target.weapon, 1);
    if (active.getDynamicProperty(STORED_JOB_WEAPON)) active.setDynamicProperty(STORED_JOB_WEAPON, undefined);
    active.lockMode = ItemLockMode?.slot ?? 'slot';
    active.keepOnDeath = true;
    if (source > 0) put(source, undefined);
    put(0, active);
    if (source !== 0 && before[0]) {
      const slot = source > 0 ? source : emptySlot();
      if (slot < 0) throw noSpace();
      put(slot, before[0]);
    }
  }
  for (let slot = 1; slot < after.length; slot++) {
    const item = after[slot];
    if (priorWeapon(item) && !targetWeapon(item) && !(target.id === 'moon_heir' && item.typeId === moonFocus))
      put(slot, store(item));
  }
  if (target.id === 'moon_heir') {
    const slot = after.findIndex(item => item?.typeId === moonFocus);
    if (slot < 0 && boundSlot < 0) {
      const destination = emptySlot();
      if (destination < 0) throw noSpace();
      const focus = new ItemStack(moonFocus, 1);
      focus.keepOnDeath = true;
      put(destination, focus);
    } else if (slot >= 0 && after[slot].getDynamicProperty(STORED_JOB_WEAPON)) {
      const focus = after[slot].clone();
      focus.setDynamicProperty(STORED_JOB_WEAPON, undefined);
      focus.lockMode = ItemLockMode?.none ?? 'none';
      put(slot, focus);
    }
  }
  return { container, before, after, changes };
}

function snapshot(player) {
  return {
    player,
    properties: new Map(player.getDynamicPropertyIds().map(key => [key, player.getDynamicProperty(key)])),
    undead: player.hasTag('rpg_undead'),
    blood: bloodReserveOf(player),
    written: [],
  };
}

function restore(state) {
  const { player, properties, undead, blood, inventory, written } = state;
  const attempt = fn => {
    try { fn(); } catch (error) { console.warn('[RPG job rollback] ' + String(error)); }
  };
  for (const slot of written) attempt(() => inventory.container.setItem(slot, inventory.before[slot]));
  const keys = new Set(properties.keys());
  attempt(() => {
    for (const key of player.getDynamicPropertyIds()) keys.add(key);
  });
  for (const key of keys) {
    attempt(() => {
      const value = properties.get(key);
      if (player.getDynamicProperty(key) !== value) player.setDynamicProperty(key, value);
    });
  }
  attempt(() => {
    if (undead !== player.hasTag('rpg_undead')) {
      if (undead) player.addTag('rpg_undead');
      else player.removeTag('rpg_undead');
    }
  });
  clearBloodReserve(player.id);
  gainBloodReserve(player, blood);
}

function changeJobs(assignments, byExchange = false) {
  const states = [];
  try {
    // Prepare both inventories before writing either player's job.
    for (const [player, id] of assignments) {
      const state = snapshot(player);
      states.push(state);
      state.target = JOBS[id];
      state.inventory = inventoryPlan(player, state.target);
      state.mana = getMana(player);
      state.loadout = storedJobLoadout(player, state.target);
    }
    for (const state of states) {
      const { player, target, mana, inventory, loadout } = state;
      if (isChameleonJob(getJobId(player))) syncChameleonLoadout(player);
      saveJobLoadout(player);
      setJobId(player, target.id, { byExchange });
      // Paid Chameleon skills are owned by its learning record. A waiver can
      // refund them while a previous loadout still contains their IDs.
      setSkills(player, isChameleonJob(target.id) ? target.skills : loadout.skills);
      setDisabled(player, loadout.disabled);
      setIndex(player, loadout.index);
      setMana(player, mana);
      if (isChameleonJob(target.id)) syncChameleonLoadout(player);
      for (const slot of inventory.changes) {
        state.written.push(slot);
        inventory.container.setItem(slot, inventory.after[slot]);
      }
      player.setDynamicProperty(changeCooldownKey, Date.now() + changeCooldownMs);
    }
  } catch (error) {
    for (const state of states.reverse()) restore(state);
    return error?.message ?? String(error);
  }
  for (const { player } of states) {
    applyVitality(player);
    try { refreshHud(player, true); } catch {}
  }
}

function pending(playerId) {
  const request = requests.get(playerId);
  if (request?.until > system.currentTick) return request;
  if (request) requests.delete(playerId);
}

async function returnToJob(player) {
  const wait = changeWait(player);
  if (wait) return tell(player, '§e직업 복귀까지 ' + wait + ' 남았습니다.');
  const current = getJobId(player);
  const choices = jobHistory(player).filter(id => id !== current);
  if (!choices.length) {
    tell(player, '§7복귀할 수 있는 이전 직업이 없습니다.');
    return;
  }
  const list = new ActionFormData().title('이전 직업으로 복귀').body('직접 전직해 해금한 직업으로 돌아갈 수 있습니다.');
  for (const id of choices) list.button(jobName(id));
  list.button('닫기');
  const picked = await showForm(list, player);
  const target = !picked?.canceled && choices[picked?.selection];
  if (!target) return;
  const answer = await showForm(new MessageFormData().title('직업 복귀 확인')
    .body(jobName(current) + ' → ' + jobName(target)).button1('복귀').button2('취소'), player);
  if (answer?.canceled || answer?.selection !== 0) return;
  if (!available(player) || getJobId(player) !== current || !jobHistory(player).includes(target)) {
    tell(player, '§c직업 또는 플레이어 상태가 바뀌어 복귀할 수 없습니다.');
    return;
  }
  const remaining = changeWait(player);
  if (remaining) return tell(player, '§e직업 복귀까지 ' + remaining + ' 남았습니다.');
  const error = changeJobs([[player, target]]);
  tell(player, error ? '§c직업 복귀 실패 · ' + error : '§a' + jobName(target) + ' 직업으로 복귀했습니다.');
}

async function proposeSwap(player) {
  const wait = changeWait(player);
  if (wait) return tell(player, '§e직업 교환까지 ' + wait + ' 남았습니다.');
  const from = getJobId(player);
  if (from === 'hacker') {
    tell(player, '§c해커는 월드 최초 전직자 전용 직업이라 교환할 수 없습니다.');
    return;
  }
  const choices = world.getAllPlayers().filter(other => other.id !== player.id && !exchangeProblem(player, other))
    .map(other => ({id: other.id, name: other.name, job: getJobId(other)}));
  if (!choices.length) {
    tell(player, '§7현재 직업을 교환할 수 있는 접속자가 없습니다.');
    return;
  }
  const list = new ActionFormData().title('직업 교환 신청').body('현재 직업을 맞바꿀 플레이어를 선택하세요.');
  for (const other of choices) list.button(other.name + ' · ' + jobName(other.job));
  list.button('닫기');
  const picked = await showForm(list, player);
  const choice = !picked?.canceled && choices[picked?.selection];
  if (!choice) return;
  const answer = await showForm(new MessageFormData().title('직업 교환 신청 확인')
    .body(choice.name + '님과 교환\n' + jobName(from) + ' → ' + jobName(choice.job))
    .button1('신청').button2('취소'), player);
  if (answer?.canceled || answer?.selection !== 0) return;
  const other = online(choice.id);
  const reason = exchangeProblem(player, other);
  if (reason || from !== getJobId(player) || choice.job !== getJobId(other)) {
    tell(player, '§c' + (reason ?? '직업이 변경되었습니다. 다시 신청하세요.'));
    return;
  }
  if (pending(other.id) || [...requests.values()].some(request =>
    request.sender === player.id && request.until > system.currentTick)) {
    tell(player, '§e처리 중인 직업 교환 요청이 있습니다.');
    return;
  }
  const request = {sender:player.id, name:player.name, from, to:choice.job, until:system.currentTick + requestLifetime};
  requests.set(other.id, request);
  system.runTimeout(() => {
    if (requests.get(choice.id) === request) requests.delete(choice.id);
  }, requestLifetime);
  tell(player, '§a' + other.name + '님에게 60초간 유효한 직업 교환 요청을 보냈습니다.');
  tell(other, '§e' + player.name + '님의 직업 교환 요청 · /rpg:jobchange → 받은 교환 요청');
}

async function reviewSwap(player) {
  const request = pending(player.id);
  if (!request) {
    tell(player, '§7받은 직업 교환 요청이 없습니다.');
    return;
  }
  const answer = await showForm(new MessageFormData().title('받은 직업 교환 요청')
    .body(request.name + '님의 요청\n' + jobName(request.to) + ' → ' + jobName(request.from))
    .button1('수락').button2('거절'), player);
  if (!answer || answer.canceled || ![0,1].includes(answer.selection)) return;
  if (pending(player.id) !== request) {
    tell(player, '§e교환 요청이 만료되었습니다.');
    return;
  }
  requests.delete(player.id);
  const sender = online(request.sender);
  if (answer.selection === 1) {
    tell(player, '§7직업 교환 요청을 거절했습니다.');
    tell(sender, '§e' + player.name + '님이 직업 교환 요청을 거절했습니다.');
    return;
  }
  const reason = exchangeProblem(sender, player);
  if (reason || getJobId(sender) !== request.from || getJobId(player) !== request.to) {
    const message = '§c' + (reason ?? '신청 후 직업이 변경되었습니다. 다시 신청하세요.');
    tell(player, message);
    tell(sender, message);
    return;
  }
  const error = changeJobs([[sender, request.to], [player, request.from]], true);
  tell(player, error ? '§c직업 교환 실패 · ' + error : '§a' + jobName(request.from) + ' 직업으로 교환했습니다.');
  tell(sender, error ? '§c직업 교환 실패 · ' + error : '§a' + jobName(request.to) + ' 직업으로 교환했습니다.');
}

export async function openJobChangeMenu(player) {
  if (menus.has(player.id)) return;
  menus.add(player.id);
  try {
    const incoming = pending(player.id);
    const wait = changeWait(player);
    const form = new ActionFormData().title('직업 교환 · 복귀')
      .body('현재 직업 · ' + jobName(getJobId(player)) + '\n교환과 복귀는 30분 대기시간을 함께 사용합니다.')
      .button(wait ? '이전 직업으로 복귀 · ' + wait : '이전 직업으로 복귀').button('직업 교환 신청')
      .button(incoming ? '받은 교환 요청 · ' + incoming.name : '받은 교환 요청').button('닫기');
    const answer = await showForm(form, player);
    if (!answer || answer.canceled) return;
    const action = [returnToJob, proposeSwap, reviewSwap][answer.selection];
    if (action) await action(player);
  } catch (error) {
    tell(player, '§c직업 메뉴를 이용할 수 없습니다. 잠시 후 다시 시도하세요.');
    console.warn('[RPG job change] ' + String(error));
  } finally {
    menus.delete(player.id);
  }
}

export function registerJobChangeCommand() {
  system.beforeEvents?.startup?.subscribe(({customCommandRegistry}) => {
    const permissionLevel = mc.CommandPermissionLevel?.Any ?? mc.CustomCommandPermissionLevel?.Any;
    const status = mc.CustomCommandStatus;
    if (!customCommandRegistry || permissionLevel === undefined || !status) return;
    try {
      customCommandRegistry.registerCommand({
        name:'rpg:jobchange', description:'직업 교환 및 복귀', permissionLevel, cheatsRequired:false,
      }, origin => {
        const player = origin.sourceEntity ?? origin.initiator;
        if (player?.typeId !== 'minecraft:player')
          return {status:status.Failure, message:'플레이어만 사용할 수 있습니다.'};
        system.run(() => openJobChangeMenu(player));
        return {status:status.Success};
      });
    } catch (error) {
      console.warn('[RPG job change command] ' + String(error));
    }
  });
  world.afterEvents?.playerLeave?.subscribe(({playerId}) => {
    requests.delete(playerId);
    for (const [id, request] of requests) if (request.sender === playerId) requests.delete(id);
  });
}
