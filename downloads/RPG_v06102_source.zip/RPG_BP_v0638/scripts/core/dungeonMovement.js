import {isJailed} from './prison.js';
import {DUNGEON,ceilingHeight} from '../data/dungeons.js';
import {dungeonRuns} from './dungeonState.js';
import {insideNightField,nightRunFor} from './nightDefenseState.js';
export function activeDungeonRun(player){return [...dungeonRuns.values()].find(r=>!r.finishing&&r.members.some(m=>m.id===player.id));}
export function insideDungeon(position,dimensionId,d){
 const radius=Math.hypot(position.x-d.x,position.z-d.z);
 return dimensionId===d.dimId&&radius<DUNGEON.radius-2&&position.y>d.y&&position.y<d.y+ceilingHeight(radius)-2;
}
export function checkSkillMovement(player,position,options={}){
 if(isJailed(player))throw Error('PrisonConfinement');
 const r=activeDungeonRun(player);
 const night=nightRunFor(player);
 if(night&&!insideNightField(position,options.dimension?.id??player.dimension.id,night.field))throw Error('NightDefenseBoundary');
 if(r&&!insideDungeon(position,options.dimension?.id??player.dimension.id,r.d))throw Error('DungeonBoundary');
 return r||night?{...options,checkForBlocks:true}:options;
}

export function teleportForSkill(player,position,options={}){
 player.teleport(position,checkSkillMovement(player,position,options));
}
