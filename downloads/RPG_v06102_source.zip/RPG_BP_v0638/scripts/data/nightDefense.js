import { DUNGEON_TIERS } from './dungeons.js';

export const NIGHT_CORE = 'rpg:night_defense_core';
export const NIGHT_MOB_TAG = 'rpg_night_defense_mob';
export const NIGHT = Object.freeze({radius:38, floor:307, height:7, coreHealth:5000, waves:10, normals:10, maxParty:4});
export const NIGHT_DIFFICULTIES = Object.freeze([
  {id:1, name:'황혼', health:1, attack:1},
  {id:2, name:'칠흑', health:1.25, attack:1.15},
  {id:3, name:'심연', health:1.55, attack:1.35},
  {id:4, name:'종말', health:1.9, attack:1.6},
]);
const finalDungeon = DUNGEON_TIERS[9];
export const NIGHT_ROSTER = {
  normal: finalDungeon.normal,
  elite: finalDungeon.elite,
  boss: ['rock_golem_boss','cyclops_boss','tech_block_golem_boss','hydra_boss'],
};
export const nightEliteWave = wave => wave===4 || wave===7 || wave===10;

export function nightWavePlan(wave) {
  if (!Number.isInteger(wave) || wave<1 || wave>NIGHT.waves) throw Error('종말의 밤 세트 범위 오류');
  const reinforced = nightEliteWave(wave);
  const normal = NIGHT_ROSTER.normal, elite = NIGHT_ROSTER.elite;
  const plan = Array.from({length:NIGHT.normals},(_,index)=>({kind:'normal',type:normal[(index+wave-1)%normal.length],index}));
  if(reinforced)plan.push({kind:'elite',type:elite[wave===7?1:0],index:0});
  plan.push({kind:'boss',type:reinforced?'hydra_boss':NIGHT_ROSTER.boss[(wave-1)%NIGHT_ROSTER.boss.length],index:0,reinforced});
  return plan;
}

export function nightScaleEvent(context) {
  if(!Number.isInteger(context?.nightDifficulty)||!NIGHT_DIFFICULTIES[context.nightDifficulty-1]||context.tier!==10)return undefined;
  const index=context.kind==='normal'?context.index%3:context.kind==='boss'&&context.reinforced?1:0;
  return `rpg:night_defense_${context.nightDifficulty}_${context.kind}_${index}`;
}

export function nightBlock(x,y,z) {
  if(y===0){
    if(Math.abs(x)<=3&&Math.abs(z)<=3)return Math.abs(x)===3||Math.abs(z)===3?'minecraft:crying_obsidian':'minecraft:polished_blackstone_bricks';
    if(x===0&&z%6===0||z===0&&x%6===0)return 'minecraft:shroomlight';
    if(Math.abs(x)<=1||Math.abs(z)<=1||Math.hypot(x,z)>31)return 'minecraft:polished_blackstone_bricks';
    return (x*31+z*17)%17===0?'minecraft:cracked_deepslate_tiles':'minecraft:deepslate_tiles';
  }
  if(Math.max(Math.abs(x),Math.abs(z))!==NIGHT.radius||y>5)return undefined;
  if(y===5)return 'minecraft:polished_blackstone_bricks';
  if((x%6===0||z%6===0)&&y===3)return 'minecraft:crying_obsidian';
  return 'minecraft:deepslate_bricks';
}
