# RPG v0.6.102 · 종말의 밤

- 관리자가 오버월드에서 `/rpg:nightdefensecreate`를 실행하면 그 X·Z 좌표 위 Y307에 77×77 방어 필드를 생성합니다. 기존 블록과 겹치면 검사 단계에서 중단합니다.
- `/rpg:nightdefense` 또는 상태 태블릿에서 **종말의 밤**을 선택하세요. 1~4명이 도전할 수 있으며, 파티 출발은 파티장이 선택합니다.
- **황혼 → 칠흑 → 심연 → 종말**의 네 난이도가 있습니다. 황혼은 10단계 던전 솔로의 전투 수치를 기준으로 합니다.
- 핵 체력은 5,000입니다. 플레이어의 공격으로는 줄어들지 않으며 적이 핵 근처에 접근하면 피해를 줍니다. 매 세트 일반 몬스터 10마리와 보스 1마리가 나오며, 4·7·10세트에는 엘리트 1마리와 강화 히드라가 나옵니다. 총 10세트를 막으면 승리하며 최고 클리어 난이도가 저장됩니다.
- 던전·야외 RPG 몬스터의 처치 아이템과 기본 적대 몬스터의 일반 전리품을 제거했습니다. 던전 클리어 보상, RPG 경험치와 지갑 재화는 유지됩니다. 기본 몬스터가 착용 중인 장비의 개별 드롭은 Bedrock 기본 동작이 적용됩니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.102로 활성화하세요. 스크립트와 데이터 자동 검사로 필드 생성·충돌 보호, 10세트 구성, 핵 피해·면역, 승패·귀환을 확인했습니다. 실제 Bedrock 월드의 AI 이동과 화면 표시는 확인하지 못했습니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
python3 tools/build_protected_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v06102
```
