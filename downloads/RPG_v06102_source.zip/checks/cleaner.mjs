import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {inFootprint} from '../RPG_BP_v0638/scripts/core/dungeonCleanup.js';
import {isRpgAdmin} from '../RPG_BP_v0638/scripts/core/adminPermissions.js';
import {MISSION_HYDRA_TAG} from '../RPG_BP_v0638/scripts/data/chameleonMissions.js';
import {NIGHT_CORE,NIGHT_MOB_TAG} from '../RPG_BP_v0638/scripts/data/nightDefense.js';

const root=path.resolve(process.argv[2]??'.');
const source=fs.readFileSync(path.join(root,'RPG_BP_v0638/scripts/core/cleaner.js'),'utf8');
async function setup(saved=new Map(),startTick=200){
 const registry=new Map(),broadcast=[],timers=[];
 const dims=new Map(['overworld','nether','the_end'].map(name=>[name,{
  id:'minecraft:'+name,entities:[],getEntities(){return this.entities;},
 }]));
 const areas=[
  {shape:'cave_v2',x:0,y:64,z:0,dimId:'minecraft:overworld'},
  {x:0,y:60,z:0,dimId:'minecraft:nether'},
 ];
 const world={
  getDimension:id=>dims.get(id),sendMessage:message=>broadcast.push(message),
  getDynamicProperty:key=>saved.get(key),
  setDynamicProperty:(key,value)=>value===undefined?saved.delete(key):saved.set(key,value),
 };
 let startup;
 const system={
  currentTick:startTick,
  beforeEvents:{startup:{subscribe:fn=>{startup=fn;}}},
  run:fn=>fn(),
  runInterval:(fn,period)=>{assert.equal(period,1);timers.push(fn);},
 };
 const server={world,system,CommandPermissionLevel:{GameDirectors:1},CustomCommandParamType:{String:0},CustomCommandStatus:{Success:0,Failure:1}};
 const imports={
  '@minecraft/server':server,'./adminPermissions.js':{isRpgAdmin},
  './dungeons.js':{registeredDungeonAreas:()=>areas},'./dungeonCleanup.js':{inFootprint},
  '../data/chameleonMissions.js':{MISSION_HYDRA_TAG},
  '../data/nightDefense.js':{NIGHT_CORE,NIGHT_MOB_TAG},
 };
 const context=vm.createContext({console});
 const module=new vm.SourceTextModule(source,{context});
 await module.link(spec=>new vm.SyntheticModule(Object.keys(imports[spec]),function(){
  for(const [name,value] of Object.entries(imports[spec]))this.setExport(name,value);
 },{context}));
 await module.evaluate();
 module.namespace.registerCleanerCommand();
 startup({customCommandRegistry:{registerCommand:(def,callback)=>registry.set(def.name,{def,callback})}});
 module.namespace.registerCleaner();

 function mob(type,opts={}){
  const dim=dims.get(opts.dim??'overworld');
  const e={
   typeId:type,isValid:opts.valid??true,dimension:dim,location:opts.at??{x:50,y:65,z:0},
   hasTag:tag=>opts.tags?.includes(tag)??false,
   getDynamicProperty:key=>key==='rpg:necro_owner'&&opts.owner,
   getComponent(id){
    if(id==='minecraft:health'&&opts.mob!==false)return {currentValue:20};
    if(id==='minecraft:tameable')return {isTamed:opts.tamed===true};
    if(id==='minecraft:type_family')return {hasTypeFamily:family=>opts.families?.includes(family)??false};
   },
   kill(){assert.fail('Cleaner must despawn rather than kill');},
   remove(){assert.equal(this.isValid,true);this.isValid=false;this.removed=true;},
  };
  dim.entities.push(e);
  return e;
 }
 const notices=[];
 const admin={typeId:'minecraft:player',playerPermissionLevel:2,sendMessage:message=>notices.push(message)};
 const {def,callback}=registry.get('rpg:cleaner');
 assert.equal(def.permissionLevel,1);
 assert.equal(def.cheatsRequired,false);
 const tickTo=end=>{
  while(system.currentTick<end){system.currentTick++;for(const fn of timers)fn();}
 };
 return {saved,startTick,system,admin,notices,callback,tickTo,broadcast,mob};
}

const env=await setup();
const {saved,startTick,callback,admin,tickTo,broadcast,mob}=env;
const protectedMobs=[
 'minecraft:player','minecraft:zombie','minecraft:husk','minecraft:drowned','minecraft:zombie_villager_v2',
 'minecraft:villager','minecraft:villager_v2','minecraft:cow','minecraft:pig','minecraft:sheep','minecraft:chicken',
 'minecraft:goat','minecraft:horse','minecraft:snow_golem','minecraft:iron_golem','minecraft:allay','minecraft:armor_stand',
 'minecraft:chest_minecart','minecraft:oak_chest_boat','minecraft:xp_orb','rpg:hito_bloodedge','rpg:sandbag_entity','rpg:super_sandbag','minecraft:endermite',
 'rpg:dungeon_loot_cache',NIGHT_CORE,
].map(type=>mob(type));
protectedMobs.push(
 mob('rpg:hydra_boss',{tags:[MISSION_HYDRA_TAG]}),
 mob('rpg:cyclops_boss',{tags:[NIGHT_MOB_TAG]}),
 mob('minecraft:wolf',{tamed:true}),
 mob('minecraft:cat',{tamed:true}),
 mob('minecraft:skeleton',{owner:'keeper'}),
 mob('rpg:elite_deathworm',{tags:['rpg_dungeon_mob']}),
 mob('rpg:rock_golem_boss',{at:{x:29,y:65,z:0}}),
 mob('minecraft:skeleton',{at:{x:21,y:61,z:21},dim:'nether'}),
 mob('minecraft:evocation_fang',{families:['inanimate']}),
 mob('test:zombie_variant',{families:['zombie']}),
);
const dead=mob('minecraft:phantom',{valid:false});
const ordinary=[
 mob('minecraft:creeper'),
 mob('minecraft:wolf'),
 mob('minecraft:blaze',{dim:'nether'}),
 mob('minecraft:shulker',{dim:'the_end',at:{x:0,y:65,z:0}}),
 mob('minecraft:skeleton',{at:{x:33,y:65,z:0}}),
];
const drops=[
 mob('minecraft:item',{mob:false}),
 mob('minecraft:item',{mob:false,at:{x:2,y:65,z:0}}),
 mob('minecraft:xp_bottle',{mob:false,dim:'the_end'}),
];
callback({sourceEntity:{...admin,playerPermissionLevel:0}});
assert.match(env.notices.at(-1),/운영자만/);
assert.equal(saved.size,0);
callback({sourceEntity:admin});
assert.ok([...saved.values()].includes(true));
tickTo(startTick+3499);
assert.deepEqual(broadcast,[]);
callback({sourceEntity:admin});
assert.match(env.notices.at(-1),/다음 청소까지 6초/);
tickTo(startTick+3599);
assert.deepEqual(broadcast.map(message=>Number(message.match(/(\d+)초/)[1])),[5,4,3,2,1]);
assert.ok(ordinary.every(e=>!e.removed));
tickTo(startTick+3600);
assert.ok(ordinary.every(e=>e.removed));
assert.ok(drops.every(e=>e.removed));
assert.ok(protectedMobs.every(e=>e.isValid&&!e.removed));
assert.equal(dead.removed,undefined);
assert.match(broadcast.at(-1),/몹 5마리, 드롭 아이템 2묶음, 날아가는 경험치 병 1개/);
const later=mob('minecraft:spider');
tickTo(startTick+7200);
assert.equal(later.removed,true);
assert.match(broadcast.at(-1),/몹 1마리/);

const restarted=await setup(saved,0);
const newMob=restarted.mob('minecraft:creeper');
restarted.tickTo(3500);
assert.match(restarted.broadcast.at(-1),/5초 남았습니다/);
restarted.tickTo(3600);
assert.equal(newMob.removed,true);
restarted.callback({sourceEntity:restarted.admin},['off']);
assert.equal(saved.size,0);
const remains=restarted.mob('minecraft:creeper');
const announcements=restarted.broadcast.length;
restarted.tickTo(7200);
assert.equal(restarted.broadcast.length,announcements);
assert.ok(!remains.removed);
console.log('Cleaner: direct operator command, exact 5–1 warnings every 3 minutes, protected mobs and dungeon boundaries, items and thrown bottles, no kill calls, repeat/stop/reload passed');
