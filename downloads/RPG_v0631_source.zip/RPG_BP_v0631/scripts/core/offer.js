import { ItemStack } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { JOBS } from "../data/jobs.js";
import {
  getJobId, getProgress, addProgress, maxManaOf, getMana, setMana, formatMana,
} from "./playerData.js";

// 인벤토리에서 itemId 를 최대 limit 개까지 꺼내서 실제로 꺼낸 개수를 돌려줍니다.
function takeItems(player, itemId, limit) {
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c || limit <= 0) return 0;
  let taken = 0;
  for (let i = 0; i < c.size && taken < limit; i++) {
    const it = c.getItem(i);
    if (!it || it.typeId !== itemId) continue;
    const take = Math.min(it.amount, limit - taken);
    if (take >= it.amount) {
      c.setItem(i, undefined);
    } else {
      it.amount -= take;
      c.setItem(i, it);
    }
    taken += take;
  }
  return taken;
}

function fixedManaActive(player){const n=player.getDynamicProperty('rpg:admin_mana_max');return Number.isSafeInteger(n)&&n>=1&&n<=100000;}

// Track only items actually consumed from v0.6.31 onward. Legacy mana stays intact.
function rewardOfferMana(progress,books,diamonds,legacyBooks){
 if(!books&&!diamonds)return;
 if(progress.mana_legacy_books===undefined)progress.mana_legacy_books=legacyBooks;
 for(const [key,n]of [['mana_offer_books',books],['mana_offer_diamonds',diamonds]]){
  const next=(progress[key]??0)+n;
  if(!Number.isSafeInteger(next)||next<0)throw Error('마나 공물 누적 수량 초과');
  progress[key]=next;
 }
}
// Donations consume only the outstanding objective, with inventory/data rollback.
export function donateTrialItems(player,itemId,key,limit,accept){
  if(itemId==='minecraft:enchanted_book'&&fixedManaActive(player))return {ok:false,message:'관리자 고정 최대 마나가 설정되어 있습니다. /rpg:setmana reset 후 바치세요. 아이템은 소비하지 않았습니다.'};
  const inv=player.getComponent('minecraft:inventory')?.container,progress=getProgress(player),remaining=Math.max(0,limit-(progress[key]??0));
  if(!inv||!remaining)return {ok:false,message:'이미 필요한 공물을 모두 바쳤습니다.'};
  const oldProgress=player.getDynamicProperty('rpg:progress'),oldMana=player.getDynamicProperty('rpg:mana'),mana=getMana(player),beforeMax=maxManaOf(player),entries=[];
  let needed=remaining;
  for(let i=0;i<inv.size&&needed>0;i++){const t=inv.getItem(i);if(t&&(accept?accept(t):t.typeId===itemId)){const take=Math.min(t.amount,needed);entries.push({slot:i,old:t.clone(),take});needed-=take;}}
  const taken=remaining-needed;if(!taken)return {ok:false,message:'바칠 아이템이 없습니다.'};
  try{
    for(const e of entries){const t=e.old.clone();if(t.amount===e.take)inv.setItem(e.slot,undefined);else{t.amount-=e.take;inv.setItem(e.slot,t);}}
    const legacyBooks=progress.books??0;progress[key]=(progress[key]??0)+taken;if(itemId==='minecraft:enchanted_book')rewardOfferMana(progress,taken,0,legacyBooks);player.setDynamicProperty('rpg:progress',JSON.stringify(progress));setMana(player,mana+maxManaOf(player)-beforeMax);
    return {ok:true,taken,have:progress[key],message:`공물 ${taken}개 제출 · ${progress[key]}/${limit} /rpg:jobs`};
  }catch(error){for(const e of entries)inv.setItem(e.slot,e.old);player.setDynamicProperty('rpg:progress',oldProgress);player.setDynamicProperty('rpg:mana',oldMana);return {ok:false,message:'공물 저장 실패: 아이템을 복구했습니다.'};}
}
export function offerBooks(player){
  const job=getJobId(player),have=getProgress(player).books??0,high=!!JOBS[job]?.highMana;
  const limit=job==='apprentice'?10:high?have+Math.min(2304,Number.MAX_SAFE_INTEGER-have):CONFIG.mana.maxBooks;
  const r=donateTrialItems(player,'minecraft:enchanted_book','books',limit);player.sendMessage(r.message);return r;
}
export function offerSwords(player){
  if(getJobId(player)!=='apprentice'){player.sendMessage('§e견습의 검사 전직 시련입니다. /rpg:jobs');return {ok:false};}
  const r=donateTrialItems(player,'minecraft:diamond_sword','diamond_swords',5);player.sendMessage(r.message);return r;
}
const POTION_IDS=['minecraft:potion','minecraft:splash_potion','minecraft:lingering_potion'];
function isRealPotion(item){
  if(!POTION_IDS.includes(item.typeId))return false;
  try{const id=String(item.getComponent('minecraft:potion')?.potionEffectType?.id??'').toLowerCase();return id!==''&&id!=='water';}catch{return false;}
}
// 마법공학사 시련: 마법사·현자 상태에서만 공물을 받습니다.
export function offerTechPotions(player){
  if(!['mage','sage'].includes(getJobId(player))){player.sendMessage('§e마법공학사 시련 공물은 마법사·현자 상태에서만 바칠 수 있습니다. /rpg:jobs');return {ok:false};}
  const r=donateTrialItems(player,null,'tech_potions',10,isRealPotion);player.sendMessage(r.message);return r;
}
export function offerTechBooks(player){
  if(!['mage','sage'].includes(getJobId(player))){player.sendMessage('§e마법공학사 시련 공물은 마법사·현자 상태에서만 바칠 수 있습니다. /rpg:jobs');return {ok:false};}
  const r=donateTrialItems(player,'minecraft:enchanted_book','tech_books',10);player.sendMessage(r.message);return r;
}
export function offerLight(player){
  if(getJobId(player)!=='angel'){player.sendMessage('§e천사가 미카엘이 되기 위한 빛 공물입니다. /rpg:jobs');return {ok:false};}
  const r=donateTrialItems(player,'rpg:blessing_light','light_michael',192);player.sendMessage(r.message);return r;
}

function isWaterBottle(item) {
  if (item.typeId !== "minecraft:potion") return false;
  try {
    const id = String(item.getComponent("minecraft:potion")?.potionEffectType?.id ?? "").toLowerCase();
    return id === "water";
  } catch {
    return false;
  }
}

// /rpg:holywater : 작업대 조합이 안 될 때 쓰는 대체 수단. 물병 1개 + 축복의 빛 1개 → 성수 1개
export function craftHolyWater(player) {
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c) return;
  let bottleSlot = -1;
  let lightSlot = -1;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (!it) continue;
    if (bottleSlot < 0 && isWaterBottle(it)) bottleSlot = i;
    if (lightSlot < 0 && it.typeId === "rpg:blessing_light") lightSlot = i;
  }
  if (bottleSlot < 0 || lightSlot < 0) {
    player.sendMessage("§7물병 1개와 축복의 빛 1개가 필요합니다.");
    return;
  }
  const dec = (slot) => {
    const it = c.getItem(slot);
    if (it.amount <= 1) c.setItem(slot, undefined);
    else {
      it.amount -= 1;
      c.setItem(slot, it);
    }
  };
  dec(bottleSlot);
  dec(lightSlot);
  const left = c.addItem(new ItemStack("rpg:holy_water", 1));
  if (left) player.dimension.spawnItem(left, player.location);
  player.sendMessage("§a성수를 만들었습니다.");
}

// One public donation command. Each physical item is consumed at most once.
// The additional trial resource is deliberately omitted from public descriptions.
export function offerItems(player){
 const tell=message=>{try{player.sendMessage(message);}catch{}};
 const inv=player.getComponent('minecraft:inventory')?.container;
 if(!inv)return {ok:false,message:'인벤토리를 확인할 수 없습니다.'};
 const originalProgress=player.getDynamicProperty('rpg:progress'),originalMana=player.getDynamicProperty('rpg:mana');
 const progress={...getProgress(player)},job=getJobId(player),high=!!JOBS[job]?.highMana,tech=['mage','sage'].includes(job);
 const originalBooks=progress.books??0,maxBooks=job==='apprentice'?10:high?originalBooks+Math.min(2304,Number.MAX_SAFE_INTEGER-originalBooks):CONFIG.mana.maxBooks;
 const remaining={swords:job==='apprentice'?Math.max(0,5-(progress.diamond_swords??0)):0,techBooks:tech?Math.max(0,10-(progress.tech_books??0)):0,books:Math.max(0,maxBooks-originalBooks),extra:tech?Math.max(0,10-(progress.tech_potions??0)):0};
 const plan=[],counts={swords:0,books:0,diamonds:0,extra:0};
 try{
  for(let slot=0;slot<inv.size;slot++){
   const item=inv.getItem(slot);if(!item)continue;let amount=item.amount,take=0;
   const consume=(key,progressKey)=>{const n=Math.min(amount,remaining[key]);amount-=n;take+=n;remaining[key]-=n;if(n)progress[progressKey]=(progress[progressKey]??0)+n;return n;};
   if(item.typeId==='minecraft:diamond_sword')counts.swords+=consume('swords','diamond_swords');
   else if(item.typeId==='minecraft:enchanted_book'){
    consume('techBooks','tech_books');consume('books','books');
    take+=amount;amount=0;counts.books+=item.amount;
   }else if(item.typeId==='minecraft:book'){take=item.amount;amount=0;counts.books+=take;}
   else if(item.typeId==='minecraft:diamond_block'){take=item.amount;amount=0;counts.diamonds+=take;}
   else if(remaining.extra>0&&isRealPotion(item))counts.extra+=consume('extra','tech_potions');
   if(take)plan.push({slot,old:item.clone(),take});
  }
  if(!plan.length){const message='바칠 책·다이아몬드 블록 또는 필요한 시련 공물이 없습니다.';tell('§e'+message);return {ok:false,message};}
  if((counts.books||counts.diamonds)&&fixedManaActive(player)){const message='관리자 고정 최대 마나가 설정되어 있습니다. /rpg:setmana reset 후 바치세요. 아이템은 소비하지 않았습니다.';tell('§e'+message);return {ok:false,message};}
  rewardOfferMana(progress,counts.books,counts.diamonds,originalBooks);
  const manaGain=counts.books*CONFIG.mana.offerBook+counts.diamonds*CONFIG.mana.offerDiamondBlock;
  const mana=getMana(player),beforeMax=maxManaOf(player);
  try{
   for(const e of plan){if(e.old.amount===e.take)inv.setItem(e.slot,undefined);else{const left=e.old.clone();left.amount-=e.take;inv.setItem(e.slot,left);}}
   player.setDynamicProperty('rpg:progress',JSON.stringify(progress));setMana(player,mana+maxManaOf(player)-beforeMax);
  }catch(error){
   let recovered=true;for(const undo of [...plan.map(e=>()=>inv.setItem(e.slot,e.old)),()=>player.setDynamicProperty('rpg:progress',originalProgress),()=>player.setDynamicProperty('rpg:mana',originalMana)])try{undo();}catch{recovered=false;}
   if(!recovered)console.error('[RPG offer] rollback incomplete: '+String(error));
   const message=recovered?'공물 저장 실패로 아이템과 진행도를 복구했습니다.':'공물 복구에 실패했습니다. 관리자에게 문의하세요.';tell('§c'+message);return {ok:false,message};
  }
  const named=[counts.swords?'검 '+counts.swords+'개':'',counts.books?'책 '+counts.books+'권':'',counts.diamonds?'다이아몬드 블록 '+counts.diamonds+'개':''].filter(Boolean),message=(named.length?named.join(' · ')+' 바쳤습니다.':'공물을 바쳤습니다.')+(manaGain?' 최대 마나 +'+manaGain+' (책 1권 +50 · 다이아몬드 블록 1개 +200)':'');
  tell('§a'+message);return {ok:true,counts,message};
 }catch(error){const message='공물을 확인하지 못했습니다. 아이템은 소비하지 않았습니다.';tell('§c'+message);return {ok:false,message};}
}
