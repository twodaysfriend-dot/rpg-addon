import {world,BlockTypes} from '@minecraft/server';
const providers=new Map(),subscribed=new Set();
const offsets={up:{x:0,y:1,z:0},down:{x:0,y:-1,z:0},north:{x:0,y:0,z:-1},south:{x:0,y:0,z:1},east:{x:1,y:0,z:0},west:{x:-1,y:0,z:0}};
export function structureProtected(block,player,operation){
 if(!block?.location||!block.dimension?.id)return false;
 for(const fn of providers.values())if(fn(block,player,operation))return true;return false;
}
function neighbor(block,face){const d=offsets[String(face).toLowerCase()];return d?{dimension:block.dimension,location:{x:block.location.x+d.x,y:block.location.y+d.y,z:block.location.z+d.z}}:undefined;}
export function structureChangingItem(item){
 const id=item?.typeId;if(!id)return false;
 if(id.endsWith('_spawn_egg'))return false;
 if(id.endsWith('bucket')||['minecraft:flint_and_steel','minecraft:fire_charge','minecraft:bone_meal','minecraft:shears'].includes(id)||/_(axe|shovel|hoe)$/.test(id))return true;
 try{return Boolean(BlockTypes.get(id));}catch{return true;}
}
export function protectStructureInteraction(ev){
 if(!ev.block||!structureChangingItem(ev.itemStack))return;
 let placing=false;try{placing=!!BlockTypes.get(ev.itemStack?.typeId);}catch{}
 if(structureProtected(ev.block,ev.player,placing?'support':'interact')||structureProtected(neighbor(ev.block,ev.blockFace),ev.player,'place'))ev.cancel=true;
 // Pistons can push or pull across a protected boundary from outside it.
 if(!ev.cancel&&['minecraft:piston','minecraft:sticky_piston'].includes(ev.itemStack?.typeId)){
  for(const face of Object.values(offsets))for(let n=1;n<=13;n++)if(structureProtected({dimension:ev.block.dimension,location:{x:ev.block.location.x+face.x*n,y:ev.block.location.y+face.y*n,z:ev.block.location.z+face.z*n}})){ev.cancel=true;return;}
 }
}
function subscribe(name,fn){const event=world.beforeEvents?.[name];if(!event?.subscribe||subscribed.has(name))return;event.subscribe(fn);subscribed.add(name);}
export function registerStructureProtection(id,protect){
 providers.set(id,protect);
 subscribe('playerBreakBlock',ev=>{if(structureProtected(ev.block,ev.player,'break'))ev.cancel=true;});
 // Some newer engines expose this; interaction protection also works on stable 2.2.
 subscribe('playerPlaceBlock',ev=>{if(structureProtected(ev.block,ev.player,'place'))ev.cancel=true;});
 subscribe('playerInteractWithBlock',protectStructureInteraction);
 subscribe('explosion',ev=>{
  try{const all=ev.getImpactedBlocks(),allowed=all.filter(b=>!structureProtected(b));if(allowed.length!==all.length)ev.setImpactedBlocks(allowed);}catch{ev.cancel=true;}
 });
}
