import {castMageBasic} from './mageBasic.js';
import {requestAdvance as requestItemAdvance} from './advance.js';
import {JOBS as PROMOTION_JOBS} from '../data/jobs.js';
import {transcendedSkillDefinition} from './chameleonTranscend.js';
import {isBoundHeld} from './weaponBinding.js';
import {handleStoneMask} from './races.js';
import {RUNNERS as WORLD_RUNNERS} from '../skills/theWorld.js';
import {isTimeFrozen} from './timeStopDamage.js';
import {useProgressionItem} from './progressionItems.js';
import {RUNNERS as WAR_GOD_RUNNERS} from '../skills/warGod.js';
import {RUNNERS as NEN_RUNNERS} from '../skills/nen.js';
import { executeChameleonSkill,skillBookItemUse,SKILLBOOK_ID } from './chameleonProgress.js';
import { world, system } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { areAllies } from "./social.js";
import { SKILLS } from "../data/skills.js";
import { RUNNERS as SWORD_RUNNERS, fireBasic } from "../skills/sword.js";
import { RUNNERS as FLAME_SPIN_RUNNERS } from "../skills/swordFlameSpin.js";
import { RUNNERS as MAGE_RUNNERS } from "../skills/mage.js";
import { RUNNERS as HOLY_RUNNERS } from "../skills/holy.js";
import { RUNNERS as FIST_RUNNERS } from "../skills/fist.js";
import { RUNNERS as ARCHER_RUNNERS, shootHeavenlyInstant, clearPreparedBowMode,heavenlyAmmoCost } from "../skills/archer.js";
import { RUNNERS as NECRO_RUNNERS } from "../skills/necro.js";
import { RUNNERS as DARK_RUNNERS } from "../skills/dark.js";
import { RUNNERS as BERSERKER_RUNNERS } from "../skills/berserker.js";
import { RUNNERS as BLOOD_RUNNERS, bloodAwakenIsActive, bloodAwakenStop } from "../skills/blood.js";
import { RUNNERS as HACKER_RUNNERS, isHackerStealthActive, stopHackerStealth } from "../skills/hacker.js";
import { RUNNERS as HARPOON_RUNNERS } from "../skills/harpoon.js";
import { RUNNERS as FROST_RUNNERS } from "../skills/frost.js";
import { RUNNERS as FIRE_RUNNERS } from "../skills/fire.js";
import { RUNNERS as ASSASSIN_RUNNERS, assassinStealthIsActive, stopAssassinStealth } from "../skills/assassin.js";
import { RUNNERS as TECH_RUNNERS } from "../skills/technomancer.js";
import { RUNNERS as DEMON_RUNNERS } from "../skills/demon.js";
import { RUNNERS as CELESTIAL_RUNNERS, throwMoonWeapon, tryBorrowedMoonThrow } from "../skills/celestial.js";
import { RUNNERS as DRAGON_RUNNERS } from "../skills/dragon.js";
import { chameleonCastJob, swapChameleonWeapon } from "./chameleon.js";
import { openAdminTool, ADMIN_TOOL_ID } from "./adminTool.js";
import { RUNNERS as CHAMELEON_RUNNERS, registerChameleonDash } from "../skills/chameleonDash.js";
import {
  getIndex, setIndex, getMana, spendMana, cooldownLeft, startCooldown,
} from "./playerData.js";
import { sound, particle, heldItemId } from "./util.js";
import { manaCostFor } from "./stats.js";
import { getContext } from "./context.js";
import { notify, refreshHud } from "./hud.js";
import { openSkillMenu } from "./skillMenu.js";

const RUNNERS = { ...WORLD_RUNNERS, ...WAR_GOD_RUNNERS, ...NEN_RUNNERS, ...SWORD_RUNNERS, ...FLAME_SPIN_RUNNERS, ...MAGE_RUNNERS, ...HOLY_RUNNERS, ...FIST_RUNNERS, ...ARCHER_RUNNERS, ...NECRO_RUNNERS, ...DARK_RUNNERS, ...BERSERKER_RUNNERS, ...BLOOD_RUNNERS, ...HACKER_RUNNERS, ...HARPOON_RUNNERS, ...FROST_RUNNERS, ...FIRE_RUNNERS, ...ASSASSIN_RUNNERS, ...TECH_RUNNERS, ...DEMON_RUNNERS, ...CELESTIAL_RUNNERS, ...DRAGON_RUNNERS, ...CHAMELEON_RUNNERS };
const isPlayer = (e) => e?.typeId === "minecraft:player";

const CHAMELEON_SWORD = "rpg:chameleon_flame_blade";
const CHAMELEON_SCYTHE = "rpg:chameleon_moon_scythe";
const CHAMELEON_SWING_CRIMSON = "rpg:chameleon_crimson_swing";
const CHAMELEON_SWING_PLATINUM = "rpg:chameleon_platinum_swing";
const swingFxTick = new Map();

function emitChameleonSwing(player) {
  try {
    if (!isPlayer(player)) return;
    const held = heldItemId(player);
    const fx = held === CHAMELEON_SWORD ? CHAMELEON_SWING_CRIMSON
      : held === CHAMELEON_SCYTHE ? CHAMELEON_SWING_PLATINUM : undefined;
    if (!fx) return;
    const now = system.currentTick;
    if (now - (swingFxTick.get(player.id) ?? -100) < 3) return;
    swingFxTick.set(player.id, now);
    // Three small, spinning slash billboards sweep in an arc in front of the hand.
    // Keep them visual-only: they do not alter melee damage or skill mechanics.
    const dim = player.dimension;
    for (let phase = 0; phase < 3; phase++) {
      system.runTimeout(() => {
        try {
          if (!player.isValid || player.dimension.id !== dim.id || heldItemId(player) !== held) return;
          const head = player.getHeadLocation();
          const view = player.getViewDirection();
          const length = Math.hypot(view.x, view.z) || 1;
          const front = { x: view.x / length, z: view.z / length };
          const right = { x: -front.z, z: front.x };
          const side = (phase - 1) * 0.42;
          const pos = {
            x: head.x + front.x * (0.95 + 0.08 * phase) + right.x * side,
            y: head.y - 0.42 + (phase - 1) * 0.22,
            z: head.z + front.z * (0.95 + 0.08 * phase) + right.z * side,
          };
          particle(dim, fx, pos);
        } catch { /* player unavailable */ }
      }, phase);
    }
  } catch {}
}

// 아군에게 발동 가능한 왼쪽 클릭 기술만 허용. 동일한 공격이
// beforeEvents.entityHurt + afterEvents.entityHitEntity 양쪽에서 관측되더라도
// 한 번만 발동하도록 2틱 중복 방지.
const friendlyHitTick = new Map();
export function handleFriendlyHit(player, target) {
  if (!isPlayer(player) || !isPlayer(target) || player.id === target.id ||
      (!areAllies(player,target)&&CONFIG.pvp)) return;
  const ctx = getContext(player);
  if (!ctx?.skills?.length) return;
  const def = SKILLS[ctx.skills[getIndex(player) % ctx.skills.length]];
  if (!def || !(def.id === "hacker_hack" || def.id === "holy_heal" || def.id === "holy_orb")) return;
  if(!areAllies(player,target)&&def.id!=="holy_heal")return;
  const key = `${player.id}:${target.id}`;
  const now = system.currentTick;
  if (now - (friendlyHitTick.get(key) ?? -100) < 3) return;
  friendlyHitTick.set(key, now);
  cast(player, ctx, target);
}

// 우클릭: 현재 선택된 스킬 발동
// 좌클릭으로 엔티티를 때려서 쓰는 스킬(trigger: "hit")은 때린 대상(target)이 있을 때만 발동합니다.
function cast(player, ctx, target) {
  if(isTimeFrozen(player))return;
  const list = ctx.skills;
  if (list.length === 0) return;

  const def = SKILLS[list[getIndex(player) % list.length]];
  const runner = RUNNERS[def.id];
  if (!runner) return;
  if(!CONFIG.pvp&&isPlayer(target)&&!(["holy_heal","holy_orb","hacker_hack"].includes(def.id)))return;

  const isHit = def.trigger === "hit";
  // 해킹: 적에게는 우클릭 해킹, 같은 길드/파티원에게는 좌클릭 지원.
  const allyHack = def.id === "hacker_hack" && isPlayer(target) &&
    target.id !== player.id && areAllies(player, target);
  if (isHit && !target) {
    notify(player, `§7${def.name}: 엔티티를 좌클릭해서 사용합니다.`);
    return;
  }
  // 계약은 우클릭 자가 강화와 좌클릭 적 대상 효과를 모두 사용합니다.
  if (!isHit && target && !allyHack && def.id !== "demon_contract" && def.id !== "fallen_orb" && def.id !== "world_blood") return;

  // 해제 입력은 쿨타임·마나를 쓰지 않고 바로 상태를 해제합니다.
  if (def.id === "blood_awaken" && bloodAwakenIsActive(player)) {
    bloodAwakenStop(player); refreshHud(player, true); return;
  }
  if (def.id === "hacker_stealth" && isHackerStealthActive(player)) {
    stopHackerStealth(player); refreshHud(player, true); return;
  }
  if (def.id === "assassin_stealth" && assassinStealthIsActive(player)) {
    stopAssassinStealth(player); refreshHud(player, true); return;
  }
  if(def.id === "moon_chakram_split" && tryBorrowedMoonThrow(player)){refreshHud(player,true);return;}
  const left = cooldownLeft(player, def.id);
  if (left > 0) {
    notify(player, `§c${def.name} 쿨타임 ${(left / 20).toFixed(1)}초`);
    return;
  }
  const adjustedMana = def.id==='world_stop'?Math.max(300,manaCostFor(player,def.mana)):manaCostFor(player, def.mana);
  if (getMana(player) < adjustedMana) {
    notify(player, ctx.job.id === "nen" ? "§c오라가 부족합니다." : "§c마나가 부족합니다.");
    return;
  }

  const charged=executeChameleonSkill(player,def.id,()=>runner(player,chameleonCastJob(def.id,ctx.job),transcendedSkillDefinition(player,def),target));
  if(!charged.ok){notify(player,'§c'+charged.message);return;}
  const castResult=charged.result;
  if (castResult === false) return;

  spendMana(player, adjustedMana);
  // 복수귀 처형은 성공과 실패의 재사용 대기시간이 다릅니다.
  startCooldown(player, def.id, castResult && typeof castResult.cooldown === "number" ? castResult.cooldown : def.cooldown);
  refreshHud(player, true);
}

// 휘두르기: 푸른 에너지 (3차 이상 검 계열)
function onSwing(player) {
  emitChameleonSwing(player);
  const ctx = getContext(player);
  if(ctx?.line==='mage'&&['mage','sage'].includes(ctx.job.id)){if(castMageBasic(player,ctx))refreshHud(player,true);return;}
  if (!ctx?.job.basic || ctx.job.id === "apprentice") return;
  if (cooldownLeft(player, "basic") > 0) return;
  startCooldown(player, "basic", CONFIG.basic.cooldown);
  fireBasic(player, ctx.job);
}

// 웅크리기: 스킬 전환 (설정창을 열려고 웅크린 경우를 되돌릴 수 있게 직전 번호를 기억)
const sneakLog = new Map(); // playerId -> { tick, prev }

function onSneakStart(player) {
  const ctx = getContext(player);
  if (!ctx || ctx.skills.length === 0) return;
  sneakLog.set(player.id, { tick: system.currentTick, prev: getIndex(player) });
  setIndex(player, (getIndex(player) + 1) % ctx.skills.length);
  sound(player.dimension, "random.click", player.location, { volume: 0.6, pitch: 1.3 });
  refreshHud(player, true);
}

// Instant heavenly bow shoots at fully charged velocity. Limit successful
// shots to one per 10 ticks (0.5 sec), also preventing duplicate item events.
const instantShotTick = new Map();
const gadgetCastTick = new Map();
function gadgetClick(p) {
  if (!isPlayer(p)) return;
  const ctx=getContext(p);
  if (!ctx || !['blood','hacker','harpoon','frost','fire','assassin','tech','demon','dragon','celestial_sun','celestial_moon','chameleon','war_god','nen','the_world'].includes(ctx.line)) return;
  const now=system.currentTick;
  if(now-(gadgetCastTick.get(p.id)??-100)<3)return;
  gadgetCastTick.set(p.id,now);
  try {
    // 카멜레온: 웅크리고 무기 우클릭하면 즉시 장비 전환.
    if (ctx.job.id === 'chameleon' && p.isSneaking) {
      const log=sneakLog.get(p.id);
      if(log && now-log.tick<=20)setIndex(p,log.prev);
      const result=swapChameleonWeapon(p);
      notify(p,result.message);
      return;
    }
    if(CONFIG.skillMenuOnSneakUse && p.isSneaking){
      const log=sneakLog.get(p.id);
      if(log && now-log.tick<=20)setIndex(p,log.prev);
      openSkillMenu(p);
      return;
    }
  } catch {}
  cast(p,ctx);
}
function heavenlyClick(p) {
  if (!isPlayer(p)) return;
  const ctx=getContext(p);
  if(!ctx||ctx.job.id!=="heavenly_archer"||ctx.held!=="rpg:heavenly_bow")return;
  const now=system.currentTick;
  if(now-(instantShotTick.get(p.id)??-100)<10)return;
  try{
    if(CONFIG.skillMenuOnSneakUse && p.isSneaking){
      const log=sneakLog.get(p.id);
      if(log&&now-log.tick<=20)setIndex(p,log.prev);
      openSkillMenu(p);
      return;
    }
  }catch{}
  const basicAmmo=heavenlyAmmoCost(p);
  if(getMana(p)<basicAmmo){notify(p,'§c화살이 없습니다. 마나 화살 1발에 MP 20이 필요합니다.');return;}
  const def=SKILLS[ctx.skills[getIndex(p)%ctx.skills.length]];
  // Reserve the entire volley and skill cost before the runner spawns extras.
  // With too little MP for the selected skill, a basic 20-MP shot still works.
  const volleyCost=heavenlyAmmoCost(p,def?.id==='archer_rapid'?5:1);
  const canCast=def&&getMana(p)>=volleyCost+manaCostFor(p,def.mana);
  clearPreparedBowMode(p);
  if(canCast)cast(p,ctx);
  if(shootHeavenlyInstant(p))instantShotTick.set(p.id,now);
  else notify(p,"§c화살을 발사하지 못했습니다.");
}

// Custom item components must be registered during startup. Each is isolated:
// an unsupported/duplicate item component must never interrupt RPG commands.
system.beforeEvents.startup.subscribe(e=>{
  const registry = e?.itemComponentRegistry;
  if (!registry || typeof registry.registerCustomComponent !== "function") {
    console.warn("[RPG] ItemComponentRegistry unavailable; command registration remains active");
    return;
  }
  const safe = (name, handler) => {
    try { registry.registerCustomComponent(name, handler); }
    catch (error) { console.warn("[RPG] item component " + name + ": " + String(error)); }
  };
  safe("rpg:bound_common",{onUse(e){system.run(()=>boundWeaponClick(e.source));}});
  safe("rpg:stone_mask",{onUse(e){system.run(()=>handleStoneMask(e.source));}});
  safe("rpg:stand_manifestation_arrow",{onUse(e){system.run(()=>requestItemAdvance(e.source,PROMOTION_JOBS.the_world));}});
  safe("rpg:dragon_choice",{onUse(e){system.run(()=>requestItemAdvance(e.source,PROMOTION_JOBS.dragon_knight));}});
  safe("rpg:progression_item",{onUse(e){system.run(()=>useProgressionItem(e.source,e.itemStack?.typeId??heldItemId(e.source)));}});
  safe("rpg:random_skillbook",{onUse(e){system.run(()=>skillBookItemUse(e.source,system.currentTick));}});
  safe("rpg:throw_moon_chakram", {
    onUse(e) { system.run(() => throwMoonWeapon(e.source)); },
  });
  safe("rpg:cast_item",{
    onUse(e){system.run(()=>gadgetClick(e.source));},
  });
  safe("rpg:admin_settings", {
    onUse(e) { system.run(() => openAdminTool(e.source)); },
  });
  safe("rpg:instant_bow",{
    onUse(e){system.run(()=>heavenlyClick(e.source));},
    onCompleteUse(e){system.run(()=>heavenlyClick(e.source));},
  });
});

export function registerInput() {
  registerChameleonDash();
  // 커스텀 활을 당겼다가 놓았을 때 일반 화살 사격 + 현재 궁수 스킬을 사용합니다.
  // shooter 발사와 별개로 스킬 코드는 같은 입력으로 한 번만 실행됩니다.
  world.afterEvents.itemReleaseUse?.subscribe((ev) => {
    const p = ev.source;
    if (!isPlayer(p)) return;
    const ctx = getContext(p);
    if (!ctx || ctx.line !== "archer" || ev.itemStack?.typeId !== ctx.held) return;
    if(ctx.job.id==="heavenly_archer")return; // instant bow is handled on use, not release
    try {
      if (p.isSneaking) { openSkillMenu(p); return; }
    } catch { /* 사용 가능 */ }
    cast(p, ctx);
  });

  world.afterEvents.itemUse.subscribe((ev) => {
    const p = ev.source;
    if (!isPlayer(p)) return;
    if(ev.itemStack?.typeId===SKILLBOOK_ID){system.run(()=>skillBookItemUse(p,system.currentTick));return;}
    if(isBoundHeld(p,ev.itemStack?.typeId)){boundWeaponClick(p);return;}
    if (ev.itemStack?.typeId === ADMIN_TOOL_ID) { openAdminTool(p); return; }
    const ctx = getContext(p);
    if (!ctx) return;
    if(ctx.line === 'blood' || ctx.line === 'hacker' || ctx.line === 'harpoon' || ctx.line === 'frost' || ctx.line === 'fire' || ctx.line === 'assassin' || ctx.line === 'demon' || ctx.line === 'dragon' || ctx.line === 'celestial_sun' || ctx.line === 'celestial_moon' || ctx.line === 'chameleon' || ctx.line === 'war_god' || ctx.line === 'nen' || ctx.line === 'the_world'){
      gadgetClick(p);return;
    }
    if (ctx.line === "archer") {
      // Item event fallback if the platform forwards item use but not custom onUse.
      if(ctx.job.id==="heavenly_archer"&&ev.itemStack?.typeId==="rpg:heavenly_bow")heavenlyClick(p);
      return;
    }

    // 웅크린 채로 우클릭: 스킬 설정창 (발동하지 않음)
    let sneaking = false;
    try {
      sneaking = p.isSneaking;
    } catch {
      // 상태를 읽을 수 없으면 일반 발동
    }
    if (CONFIG.skillMenuOnSneakUse && sneaking) {
      // 방금 웅크리면서 전환된 스킬 번호는 원래대로 돌려놓습니다.
      const log = sneakLog.get(p.id);
      if (log && system.currentTick - log.tick <= 20) setIndex(p, log.prev);
      openSkillMenu(p);
      return;
    }
    cast(p, ctx);
  });

  // 허공을 휘두르는 동작은 버전에 따라 이벤트 지원이 달라서, 있을 때만 구독합니다.
  world.afterEvents.playerLeave.subscribe((ev) => {
    sneakLog.delete(ev.playerId);instantShotTick.delete(ev.playerId);gadgetCastTick.delete(ev.playerId);swingFxTick.delete(ev.playerId);
    for (const key of friendlyHitTick.keys()) if (key.startsWith(`${ev.playerId}:`) || key.endsWith(`:${ev.playerId}`)) friendlyHitTick.delete(key);
  });

  world.afterEvents.playerSwingStart?.subscribe((ev) => {
    onSwing(ev.player);
    try{
      const hits=ev.player.getEntitiesFromViewDirection({maxDistance:4,ignoreBlockCollision:false}).sort((a,b)=>a.distance-b.distance);
      if(isPlayer(hits[0]?.entity)&&(areAllies(ev.player,hits[0].entity)||!CONFIG.pvp))handleFriendlyHit(ev.player,hits[0].entity);
    }catch{}
  });

  // 대상/블록을 맞춘 휘두르기는 항상 감지됩니다. (쿨타임으로 중복 발동 방지)
  world.afterEvents.entityHitEntity.subscribe((ev) => {
    const p = ev.damagingEntity;
    if (!isPlayer(p)) return;
    onSwing(p);
    // 좌클릭으로 때려서 쓰는 스킬 (힐 / 축복의 구슬 / Sacrifice)
    const ctx = getContext(p);
    if (ctx && ev.hitEntity) {
      if (isPlayer(ev.hitEntity) && (areAllies(p, ev.hitEntity)||!CONFIG.pvp)) handleFriendlyHit(p, ev.hitEntity);
      else cast(p, ctx, ev.hitEntity);
    }
  });
  world.afterEvents.entityHitBlock.subscribe((ev) => {
    if (isPlayer(ev.damagingEntity)) onSwing(ev.damagingEntity);
  });

  // 웅크리기 시작 순간 감지
  const wasSneaking = new Map();
  system.runInterval(() => {
    for (const p of world.getAllPlayers()) {
      let now = false;
      try {
        now = p.isSneaking;
      } catch {
        continue;
      }
      if (now && !wasSneaking.get(p.id)) onSneakStart(p);
      wasSneaking.set(p.id, now);
    }
  }, 1);
}

const boundClickTick=new Map();
function boundWeaponClick(p){
 if(!isPlayer(p)||!isBoundHeld(p))return;
 if((boundClickTick.get(p.id)??-100)>system.currentTick-3)return;
 boundClickTick.set(p.id,system.currentTick);
 const ctx=getContext(p);if(!ctx)return;
 if(p.isSneaking){const log=sneakLog.get(p.id);if(log&&system.currentTick-log.tick<=20)setIndex(p,log.prev);openSkillMenu(p);return;}
 if(ctx.job.id==='heavenly_archer'){heavenlyClick(p);return;}
 cast(p,ctx);
 if(ctx.line==='archer')shootHeavenlyInstant(p);
}
