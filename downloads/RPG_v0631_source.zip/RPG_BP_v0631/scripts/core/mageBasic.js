import {ActionFormData} from '@minecraft/server-ui';
import {SKILLS} from '../data/skills.js';
import {getJobId,getMana,spendMana,cooldownLeft,startCooldown} from './playerData.js';
import {manaCostFor} from './stats.js';
import {RUNNERS} from '../skills/mage.js';
import {showForm} from './skillMenu.js';
import {isTimeFrozen} from './timeStopDamage.js';
export const MAGE_BASIC_KEY='rpg:mage_basic_v1';
export const MAGE_BASIC_IDS=Object.freeze(['mage_fireball','mage_thunder','mage_gravity','mage_bombaye']);
const pending=new Set();
export function mageBasicId(p){if(!['mage','sage'].includes(getJobId(p)))return undefined;const id=p.getDynamicProperty(MAGE_BASIC_KEY);return MAGE_BASIC_IDS.includes(id)?id:'mage_fireball';}
export function setMageBasic(p,id){if(!mageBasicId(p)||!MAGE_BASIC_IDS.includes(id))return false;p.setDynamicProperty(MAGE_BASIC_KEY,id);return true;}
export function mageBasicDefinition(p){const id=mageBasicId(p);if(!id)return undefined;const def=SKILLS[id];return {...def,cooldown:20,damage:def.damage*0.8};}
export function castMageBasic(p,ctx,run){
 if(ctx?.line!=='mage'||!['mage','sage'].includes(ctx.job.id)||isTimeFrozen(p))return false;
 const def=mageBasicDefinition(p);if(!def||cooldownLeft(p,'mage_basic')>0)return false;
 const cost=manaCostFor(p,def.mana);if(getMana(p)<cost)return false;
 if((run??RUNNERS[def.id])(p,ctx.job,def)===false)return false;
 spendMana(p,cost);startCooldown(p,'mage_basic',20);return true;
}
export async function openMageBasicMenu(p){
 if(!mageBasicId(p)){p.sendMessage('§e마법사·현자의 평타 설정입니다.');return;}
 if(pending.has(p.id))return;pending.add(p.id);
 try{
  const form=new ActionFormData().title('마법사 평타 선택').body('선택한 1개만 좌클릭/휘두르기 평타로 사용합니다.\n공유 쿨타임 1초 · 원래 피해 ×0.8 · 마나 소모 절반 적용\n우클릭 일반 스킬은 기존 피해·쿨타임입니다.\n현재: '+SKILLS[mageBasicId(p)].name);
  for(const id of MAGE_BASIC_IDS)form.button((id===mageBasicId(p)?'§a[선택] ':'')+SKILLS[id].name);form.button('닫기');
  const result=await showForm(form,p);if(result&&!result.canceled&&Number.isInteger(result.selection)&&result.selection>=0&&result.selection<MAGE_BASIC_IDS.length){if(setMageBasic(p,MAGE_BASIC_IDS[result.selection]))p.sendMessage('§b평타: '+SKILLS[MAGE_BASIC_IDS[result.selection]].name+' · 1초 · 피해 0.8배');}
 }finally{pending.delete(p.id);}
}
