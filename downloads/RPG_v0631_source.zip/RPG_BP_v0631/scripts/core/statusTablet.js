import {worldMasteryText} from './worldMastery.js';
import {raceName} from './races.js';
import {world,system,ItemStack} from '@minecraft/server';
import {ActionFormData} from '@minecraft/server-ui';
import {getJobId,getSkills,getMana,maxManaOf} from './playerData.js';
import {getLevel,getXp,xpForNext,getStats,LEVEL_MAX} from './stats.js';
import {JOBS} from '../data/jobs.js';
import {showForm} from './skillMenu.js';

export const STATUS_TABLET='rpg:status_tablet';
export const STATUS_TITLE='§bSTATUS §8| §f상태창';
const GIVEN='rpg:status_tablet_given_v1';
const open=new Map(),lastUse=new Map();
const OPEN_STUCK_TICKS=600; // 열림 상태가 30초 넘게 남아 있으면 고장으로 보고 초기화
let actionHandler,registered=false;
export const STATUS_GROUPS=Object.freeze({
 character:{name:'내 캐릭터',items:[['stats','스탯 배분'],['jobs','전직 방법'],['skills','스킬 켜기 · 끄기'],['wingspeed','날개 비행속도'],['magebasic','마법사 평타 선택']]},
 social:{name:'파티 · 길드',items:[['party','파티'],['guild','길드 · 기지 이동'],['invites','받은 파티 · 길드 초대']]},
 combat:{name:'던전 · PvP',items:[['dungeon','던전 입장'],['pvp','PvP 결투']]},
 travel:{name:'이동 · TPA',items:[['spawn','스폰으로 이동'],['tpa','TPA 이동 요청'],['tpaaccept','TPA 요청 수락 · 거절']]},
 equipment:{name:'장비 · 강화',items:[['weapon','공통 무기 대체'],['equipment','장비 정보'],['runes','룬 장착 · 관리'],['upgrade','강화 메뉴'],['transfer','강화 이전']]},
 guide:{name:'스킬 · 제작 도감',items:[['skillguide','스킬 효과'],['craft','아이템 조합법']]},
 shop:{name:'지갑 · 상점 · 부동산',items:[['wallet','지갑 · 골드 상점'],['xpshop','경험치 상점 · 부동산 구매권']]}
});
export const STATUS_ACTIONS=Object.freeze([
 ...Object.entries(STATUS_GROUPS).map(([key,group])=>({action:'group:'+key,text:'§b'+group.name})),
 {action:'refresh',text:'§a새로고침'},{action:'close',text:'§7닫기'}
]);
export const ALL_STATUS_ACTIONS=Object.freeze(Object.values(STATUS_GROUPS).flatMap(g=>g.items.map(([action,text])=>({action,text}))));
export function resourceBar(value,max,color='§b'){
 const ratio=Number.isFinite(value)&&Number.isFinite(max)&&max>0?Math.max(0,Math.min(1,value/max)):0;
 const n=Math.round(ratio*10);return color+'■'.repeat(n)+'§8'+'■'.repeat(10-n)+'§r';
}
const number=n=>String(Math.round(Number.isFinite(n)?n:0));
export function statusBody(p){
 const h=p.getComponent('minecraft:health'),mp=getMana(p),maxMp=maxManaOf(p);
 const level=getLevel(p),xp=getXp(p),next=xpForNext(level),s=getStats(p),capped=level>=LEVEL_MAX;
 const name=String(p.name).replace(/§./g,'').slice(0,22);
 return `§f${name}\n§b${JOBS[getJobId(p)]?.name??'견습'} §fLv.${level}\n§7종족: §f${raceName(p)}\n${getJobId(p)==='the_world'||getSkills(p).includes('world_stop')?'§e'+worldMasteryText(p)+'\n':''}\n`+
  `§fHP ${number(h?.currentValue??0)} / ${number(h?.effectiveMax??20)}\n${resourceBar(h?.currentValue??0,h?.effectiveMax??20)}\n`+
  `§fMP ${number(mp)} / ${number(maxMp)}\n${resourceBar(mp,maxMp)}\n`+
  `§fEXP ${capped?'MAX':number(xp)+' / '+number(next)}\n${resourceBar(capped?1:xp,capped?1:next,'§d')}\n\n`+
  `§7근력 §f${s.str}  §7마력 §f${s.mag}\n§7체력 §f${s.vit}  §7지능 §f${s.int}`;
}
export async function openStatusTablet(p){
 if(!p?.isValid)return;
 if(open.has(p.id)){if(system.currentTick-open.get(p.id)<OPEN_STUCK_TICKS)return;open.delete(p.id);}
 open.set(p.id,system.currentTick);
 let next,group;
 try{
  while(p.isValid){
   const entries=group?[...STATUS_GROUPS[group].items.map(([action,text])=>({action,text})),{action:'back',text:'§7뒤로'}]:STATUS_ACTIONS;
   const form=new ActionFormData().title(group?STATUS_TITLE+' · '+STATUS_GROUPS[group].name:STATUS_TITLE).body(statusBody(p));
   for(const entry of entries)form.button(entry.text);
   const res=await showForm(form,p);
   if(!res||res.canceled||!Number.isInteger(res.selection)||res.selection<0||res.selection>=entries.length)return;
   const selected=entries[res.selection].action;
   if(selected.startsWith('group:')){group=selected.slice(6);continue;}
   if(selected==='back'){group=undefined;continue;}
   if(selected==='refresh')continue;
   if(selected!=='close')next=selected;
   break;
  }
 }catch(error){try{p.sendMessage('§c[상태창] '+String(error.message??error));}catch{}}
 finally{open.delete(p.id);}
 // Defer the next form so Bedrock can close this form first.
 if(next&&!actionHandler){try{p.sendMessage('§c[상태창] 아직 준비되지 않았습니다. 잠시 후 다시 시도하세요.');}catch{}return;}
 if(next&&p.isValid)system.run(()=>{try{const result=actionHandler(next,p);Promise.resolve(result).catch(error=>{try{p.sendMessage('§c[상태창] '+String(error));}catch{}});}catch(error){try{p.sendMessage('§c[상태창] '+String(error));}catch{}}});
}
export function giveStatusTablet(p){
 if(!p?.isValid)return;
 const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return;
 for(let i=0;i<inv.size;i++)if(inv.getItem(i)?.typeId===STATUS_TABLET){p.setDynamicProperty(GIVEN,true);return;}
 const first=!p.getDynamicProperty(GIVEN),item=new ItemStack(STATUS_TABLET,1);try{item.keepOnDeath=true;}catch{}
 const remainder=inv.addItem(item);
 if(remainder){p.sendMessage('§e[상태창] 인벤토리를 비운 후 재접속하면 지급됩니다. /rpg:menu로도 열 수 있습니다.');return;}
 p.setDynamicProperty(GIVEN,true);
 p.sendMessage(first?'§b[상태창] 상태창 아이템을 지급했습니다. 손에 들고 사용해 모험 메뉴를 여세요.':'§b[상태창] 상태창을 다시 지급했습니다. (/rpg:menu 로도 열 수 있습니다)');
}
function useTablet(p){
 if(!p?.isValid||(lastUse.get(p.id)??-100)>system.currentTick-5)return;
 lastUse.set(p.id,system.currentTick);system.runTimeout(()=>{try{openStatusTablet(p);}catch(error){try{p.sendMessage('§c[상태창] '+String(error));}catch{}}},2);
}
// Register the component in startup, before item definitions are used.
system.beforeEvents.startup.subscribe(event=>{
 try{event.itemComponentRegistry.registerCustomComponent('rpg:status_tablet',{onUse(e){useTablet(e.source);}});}
 catch(error){console.warn('[RPG status tablet component] '+error);}
});
export function registerStatusTablet(handler){
 actionHandler=handler;if(registered)return;registered=true;
 world.afterEvents.itemUse.subscribe(e=>{if(e.itemStack?.typeId===STATUS_TABLET)useTablet(e.source);});
 world.afterEvents.playerSpawn.subscribe(e=>system.runTimeout(()=>{try{giveStatusTablet(e.player);}catch(error){console.warn('[RPG status tablet grant] '+error);}},40));
 world.afterEvents.playerLeave.subscribe(e=>{open.delete(e.playerId);lastUse.delete(e.playerId);});
 system.runTimeout(()=>{for(const p of world.getAllPlayers())try{giveStatusTablet(p);}catch(error){console.warn('[RPG status tablet grant] '+error);}},40);
}
