import {ActionFormData} from '@minecraft/server-ui';
import {showForm} from './skillMenu.js';
import { world, system, ItemStack, EquipmentSlot, EntityDamageCause, InputButton, ButtonState } from "@minecraft/server";
import { getJobId } from "./playerData.js";
import { isFrenzyActive } from "./frenzy.js";

// The wing token occupies the offhand so chest armor remains available. Its attachable
// model is hidden in first person and only shown on the player's back in third person.
const WING_IDS = new Set(["rpg:angel_wing_toggle", "rpg:michael_wing_toggle", "rpg:fallen_wing_toggle"]);
const WING_BY_JOB = {
  angel: "rpg:angel_wing_toggle",
  michael: "rpg:michael_wing_toggle",
  fallen_angel: "rpg:fallen_wing_toggle",
  fallen_sword_saint: "rpg:fallen_wing_toggle",
};
const ACTIVE_PROP = "rpg:wings_active";
export const WING_SPEED_KEY = 'rpg:wing_speed_v1';
export function wingSpeedMultiplier(player) {
  if (!['angel','michael'].includes(getJobId(player))) return 1;
  return ({1:1,2:2,3:5})[player.getDynamicProperty(WING_SPEED_KEY)] ?? 1;
}
export function setWingSpeed(player, text) {
  if (!['angel','michael'].includes(getJobId(player))) {player.sendMessage('§c비행속도 설정은 천사·미카엘만 사용할 수 있습니다.');return false;}
  if (!/^[123]$/.test(String(text))) {player.sendMessage('§e/rpg:wings 1|2|3 · 1: 기본, 2: 2배, 3: 5배');return false;}
  player.setDynamicProperty(WING_SPEED_KEY,Number(text));
  player.sendMessage('§b[날개 v0.6.31] 비행속도: '+wingSpeedMultiplier(player)+'배');return true;
}
const speedMenus=new Set();
export async function openWingSpeedMenu(player){
 if(!['angel','michael'].includes(getJobId(player))){player.sendMessage('§c비행속도 설정은 천사·미카엘만 사용할 수 있습니다.');return;}
 if(speedMenus.has(player.id))return;
 speedMenus.add(player.id);
 try{
  const form=new ActionFormData().title('천사 · 미카엘 비행속도').body('현재 속도: '+wingSpeedMultiplier(player)+'배\n명령어: /rpg:wings 1 · 2 · 3\n인자 없이: /rpg:wings1 · wings2 · wings3\n날개를 장착하고 더블 점프로 비행하세요.');
  form.button('1 · 기본 속도').button('2 · 2배 속도').button('3 · 5배 속도').button('닫기');
  const picked=await showForm(form,player);
  if(picked&&!picked.canceled&&Number.isInteger(picked.selection)&&picked.selection>=0&&picked.selection<3)setWingSpeed(player,String(picked.selection+1));
 }finally{speedMenus.delete(player.id);}
}
const flightStates = new Map();
const MAX_DOUBLE_JUMP_WINDOW = 60; // 3 seconds at 20 ticks/sec
let tickNow = 0;

function stateFor(player) {
  let state = flightStates.get(player.id);
  if (!state) {
    state = { jumpStage: 0, firstJumpTick: 0, wasAirborne: false, gliding: false };
    flightStates.set(player.id, state);
  }
  return state;
}
function equippable(player) { try { return player.getComponent("minecraft:equippable"); } catch { return undefined; } }
function getEquipment(player, slot) { try { return equippable(player)?.getEquipment(slot); } catch { return undefined; } }
function setEquipment(player, slot, item) { try { equippable(player)?.setEquipment(slot, item); return true; } catch { return false; } }
function chestItem(player) { return getEquipment(player, EquipmentSlot.Chest); }
function offhandItem(player) { return getEquipment(player, EquipmentSlot.Offhand); }
function setChest(player, item) { return setEquipment(player, EquipmentSlot.Chest, item); }
function setOffhand(player, item) { return setEquipment(player, EquipmentSlot.Offhand, item); }
function inventory(player) { try { return player.getComponent("minecraft:inventory")?.container; } catch { return undefined; } }
function storeOrDrop(player, item) {
  if (!item) return;
  try { const rest = inventory(player)?.addItem(item); if (rest) player.dimension.spawnItem(rest, player.location); }
  catch { try { player.dimension.spawnItem(item, player.location); } catch {} }
}
function expectedWing(player) { return WING_BY_JOB[getJobId(player)]; }
function activeWingId(player) {
  const id = offhandItem(player)?.typeId;
  return id && WING_IDS.has(id) && expectedWing(player) === id ? id : undefined;
}
export function hasActiveWings(player) { return !!activeWingId(player); }

function takeWingFromInventory(player, wanted) {
  const c = inventory(player);
  if (!c) return undefined;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it?.typeId === wanted) {
      c.setItem(i, undefined);
      return it;
    }
  }
  return undefined;
}

export function forceWingsOn(player) {
  const wanted = expectedWing(player);
  if (!wanted) return false;
  const current = offhandItem(player);
  if (current?.typeId === wanted) return true;
  if (current) {
    if (!setOffhand(player, undefined)) return false;
    storeOrDrop(player, current);
  }
  let stack = takeWingFromInventory(player, wanted);
  if (!stack) stack = new ItemStack(wanted, 1);
  if (!setOffhand(player, stack)) {
    storeOrDrop(player, stack);
    return false;
  }
  try { player.setDynamicProperty(ACTIVE_PROP, false); } catch {}
  return true;
}

export function toggleWings(player) {
  const wanted = expectedWing(player);
  if (!wanted) { player.sendMessage("§c날개는 천사, 미카엘, 타락천사 또는 타락검성만 사용할 수 있습니다."); return; }
  const current = offhandItem(player);
  if (current && WING_IDS.has(current.typeId)) {
    if (!setOffhand(player, undefined)) { player.sendMessage("§c날개를 비활성화하지 못했습니다."); return; }
    storeOrDrop(player, current);
    try { player.setDynamicProperty(ACTIVE_PROP, false); } catch {}
    const state = stateFor(player); state.gliding = false; state.jumpStage = 0;
    player.sendMessage("§7날개를 비활성화했습니다.");
    try { player.playSound("random.click", { volume: 0.7, pitch: 0.8 }); } catch {}
    return;
  }
  if (!forceWingsOn(player)) { player.sendMessage("§c날개를 활성화하지 못했습니다."); return; }
  player.sendMessage("§b날개가 활성화되었습니다.");
}

// Double jump engages flight. Steering follows the full 3-D view vector:
// look up = climb, look forward = cruise, look down = descend.
// Small per-tick corrections avoid unbounded acceleration and very fast dives.
function glideTick(player) {
  try {
    if (player.isOnGround || !hasActiveWings(player) || isFrenzyActive(player)) return;
    const v = player.getVelocity();
    const look = player.getViewDirection();
    const multiplier = wingSpeedMultiplier(player);
    const forwardSpeed = 0.36 * multiplier; // moderate cruising speed; capped via steering
    const targetX = look.x * forwardSpeed;
    const targetZ = look.z * forwardSpeed;
    // With the camera pointed at the sky, the wings actively lift the player.
    const targetY = Math.max(-0.24, Math.min(0.34, look.y * 0.43 - 0.035)) * multiplier;
    const clamp = (a, min, max) => Math.max(min, Math.min(max, a));
    const impulse = {
      x: clamp((targetX - v.x) * 0.21, -0.12 * multiplier, 0.12 * multiplier),
      // Counter gravity and steer toward the desired vertical speed.
      y: clamp(0.079 + (targetY - v.y) * 0.25, -0.16 * multiplier, 0.19 * multiplier),
      z: clamp((targetZ - v.z) * 0.21, -0.12 * multiplier, 0.12 * multiplier),
    };
    player.applyImpulse(impulse);
  } catch { /* player may be changing dimension */ }
}

function handleJumpInput(ev) {
  try {
    if (ev.button !== InputButton.Jump || ev.newButtonState !== ButtonState.Pressed) return;
    const player = ev.player;
    if (!hasActiveWings(player) || isFrenzyActive(player)) return;
    const state = stateFor(player);
    const grounded = player.isOnGround;

    // A stale first jump does not leave an armed glide indefinitely.
    if (state.jumpStage === 1 && tickNow - state.firstJumpTick > MAX_DOUBLE_JUMP_WINDOW) {
      state.jumpStage = 0;
    }
    // Presses made on the ground are always treated as a new first jump.
    if (grounded && state.jumpStage !== 2) state.jumpStage = 0;

    // First press arms the double jump. If input was observed just after takeoff, it still
    // counts as the first jump rather than immediately triggering flight.
    if (state.jumpStage === 0) {
      state.jumpStage = 1;
      state.firstJumpTick = tickNow;
      state.gliding = false;
      return;
    }
    if (state.jumpStage === 1 && !grounded && tickNow - state.firstJumpTick >= 2) {
      state.jumpStage = 2;
      state.gliding = true;
      const look = player.getViewDirection();
      player.applyImpulse({
        x: look.x * 0.22,
        y: Math.max(0.24, 0.34 + look.y * 0.16),
        z: look.z * 0.22,
      });
      try {
        player.dimension.spawnParticle(
          getJobId(player) === "fallen_angel" || getJobId(player) === "fallen_sword_saint"
            ? "minecraft:soul_particle" : "minecraft:totem_particle",
          { x: player.location.x, y: player.location.y + 1.0, z: player.location.z }
        );
        player.playSound("random.orb", { volume: 0.75, pitch: 1.35 });
      } catch {}
    }
  } catch { /* unsupported input state / player left */ }
}

function onWingActivation(player) {
  const jobId = getJobId(player);
  if (jobId !== "angel") {
    try { player.applyDamage(10, { cause: EntityDamageCause.magic }); }
    catch { try { const hp = player.getComponent("minecraft:health"); if (hp) hp.setCurrentValue(Math.max(0, hp.currentValue - 10)); } catch {} }
    player.sendMessage("§c날개 활성화 대가: 체력 5칸을 잃었습니다.");
  } else player.sendMessage("§e천사의 날개가 활성화되었습니다. 활성화 피해가 없습니다.");
  try { player.dimension.spawnParticle(jobId === "fallen_angel" || jobId === "fallen_sword_saint" ? "minecraft:soul_particle" : "minecraft:totem_particle", { x: player.location.x, y: player.location.y + 1.1, z: player.location.z }); } catch {}
}

// Legacy migration: move old chest-slot wing items to inventory so chest armor can be worn.
function migrateLegacyChestWing(player) {
  const chest = chestItem(player);
  if (!chest || !WING_IDS.has(chest.typeId)) return;
  if (setChest(player, undefined)) {
    storeOrDrop(player, chest);
    try { player.setDynamicProperty(ACTIVE_PROP, false); } catch {}
    player.sendMessage("§e날개 아이템 위치가 변경되었습니다. /rpg:wings 로 활성화하세요. 가슴갑옷과 함께 착용할 수 있습니다.");
  }
}

function blockElytraDuringFrenzy(player) {
  if (!isFrenzyActive(player)) return;
  const chest = chestItem(player);
  if (chest?.typeId === "minecraft:elytra") {
    if (setChest(player, undefined)) {
      storeOrDrop(player, chest);
      player.sendMessage("§c광분화 중에는 겉날개 활공을 사용할 수 없습니다. 겉날개를 인벤토리로 옮겼습니다.");
    }
  }
}

export function registerWings() {
  // Clear local glide state on exit/respawn and on dimension transitions.
  world.afterEvents.playerLeave.subscribe((ev) => flightStates.delete(ev.playerId));
  world.afterEvents.playerSpawn.subscribe((ev) => flightStates.delete(ev.player.id));
  try {
    world.afterEvents.playerDimensionChange.subscribe((ev) => flightStates.delete(ev.player.id));
  } catch { /* dimension-change signal may not be present in older engine builds */ }
  try {
    world.afterEvents.playerButtonInput.subscribe(handleJumpInput);
  } catch (e) {
    console.warn(`[rpg] 더블 점프 입력 이벤트 등록 실패: ${e}`);
  }

  system.runInterval(() => {
    tickNow++;
    for (const p of world.getAllPlayers()) {
      try {
        migrateLegacyChestWing(p);
        blockElytraDuringFrenzy(p);
        const state = stateFor(p);
        const equippedWing = offhandItem(p)?.typeId;
        const wanted = expectedWing(p);
        const isValid = !!equippedWing && WING_IDS.has(equippedWing) && equippedWing === wanted;
        const wasActive = p.getDynamicProperty(ACTIVE_PROP) === true;

        if (equippedWing && WING_IDS.has(equippedWing) && !isValid) {
          const wrong = offhandItem(p);
          setOffhand(p, undefined); storeOrDrop(p, wrong);
          try { p.setDynamicProperty(ACTIVE_PROP, false); } catch {}
          state.gliding = false; state.jumpStage = 0;
          p.sendMessage("§c현재 직업에서는 이 날개를 사용할 수 없습니다.");
          continue;
        }
        if (isValid && !wasActive) {
          try { p.setDynamicProperty(ACTIVE_PROP, true); } catch {}
          onWingActivation(p);
        } else if (!isValid && wasActive) {
          try { p.setDynamicProperty(ACTIVE_PROP, false); } catch {}
          state.gliding = false; state.jumpStage = 0;
        }

        if (!isValid) continue;
        if (isFrenzyActive(p)) state.gliding = false;

        const grounded = p.isOnGround;
        if (grounded) {
          if (state.wasAirborne) {
            state.jumpStage = 0;
            state.gliding = false;
          }
          state.wasAirborne = false;
        } else {
          state.wasAirborne = true;
          if (state.gliding && !isFrenzyActive(p)) glideTick(p);
        }
      } catch { /* player is leaving/changing dimension */ }
    }
  }, 1);

  // Wings always suppress fall damage while active; glide itself only begins with the double jump.
  try {
    world.beforeEvents.entityHurt.subscribe((ev) => {
      try {
        const victim = ev.hurtEntity;
        if (victim?.typeId !== "minecraft:player") return;
        if (ev.damageSource?.cause !== "fall") return;
        if (hasActiveWings(victim)) ev.cancel = true;
      } catch {}
    });
  } catch (e) { console.warn(`[rpg] 날개 낙하 피해 방지 이벤트 등록 실패: ${e}`); }
}


// Command diagnostics for intermittent Bedrock attachable render issues.
export function inspectWings(player) {
  const wanted=expectedWing(player);
  const off=offhandItem(player)?.typeId ?? "없음";
  const valid=hasActiveWings(player);
  const active=player.getDynamicProperty(ACTIVE_PROP) === true;
  player.sendMessage(
    `§b[날개 진단 v0.6.31] §f속도: ${wingSpeedMultiplier(player)}배 §7/ 직업 날개: ${wanted ?? "사용 불가"} §7/ 보조손: ${off} §7/ 일치: ${valid ? "§a예" : "§c아니오"} §7/ 활성 상태: ${active ? "§aON" : "§cOFF"}`
  );
  if (valid) player.sendMessage("§7보조손 장착이 정상인데 날개가 보이지 않으면 리소스팩을 새로 적용한 뒤 /rpg:wingrefresh 를 사용하세요.");
  else if (wanted) player.sendMessage("§e/rpg:wings 로 날개를 활성화하세요.");
}
export function refreshWings(player) {
  const wanted=expectedWing(player);
  if (!wanted) { player.sendMessage("§c이 직업은 날개가 없습니다."); return; }
  const current=offhandItem(player);
  if (current?.typeId===wanted) {
    if (!setOffhand(player,undefined) || !setOffhand(player,current)) {
      player.sendMessage("§c날개 표시 초기화 실패: 보조손 장착 상태를 확인하세요.");
      return;
    }
  } else if (!forceWingsOn(player)) {
    player.sendMessage("§c날개 재장착에 실패했습니다."); return;
  }
  player.sendMessage("§b날개 아이템을 다시 장착했습니다. 3인칭에서 표시를 확인하세요.");
  inspectWings(player);
}
