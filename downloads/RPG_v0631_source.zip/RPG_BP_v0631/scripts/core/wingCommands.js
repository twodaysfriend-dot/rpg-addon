// The gameplay BP owns wing commands. Never depend on a separate command pack
// forwarding them, or register a competing no-argument definition elsewhere.
import * as mc from '@minecraft/server';
import {toggleWings,setWingSpeed,openWingSpeedMenu} from './wings.js';
let subscribed=false;
export function registerWingCommands(){
 if(subscribed)return;subscribed=true;
 mc.system.beforeEvents.startup.subscribe(event=>{
 const registry=event.customCommandRegistry;
 const levels=mc.CommandPermissionLevel??mc.CustomCommandPermissionLevel;
 const types=mc.CustomCommandParamType,status=mc.CustomCommandStatus;
 if(!registry||!levels||!types||!status){console.error('[RPG v0.6.31 wings] command API unavailable; use status speed menu');return;}
 for(const [name,fixed,menu]of [['wings'],['wingspeed',undefined,true],['wings1',1],['wings2',2],['wings3',3]]){
  const def={name:'rpg:'+name,description:'v0.6.31 천사·미카엘 비행속도 · 1=기본 2=2배 3=5배',permissionLevel:levels.Any,cheatsRequired:false};
  if(fixed===undefined)def.optionalParameters=[{name:'speed',type:types.Integer}];
  try{
   registry.registerCommand(def,(origin,...args)=>{
    const player=origin.sourceEntity??origin.initiator;
    if(player?.typeId!=='minecraft:player')return {status:status.Failure,message:'플레이어만 사용할 수 있습니다.'};
    const raw=Array.isArray(args[0])?args[0][0]:args[0];
    const speed=fixed??raw;
    mc.system.run(()=>{
     try{
      if(speed!==undefined)setWingSpeed(player,String(speed));
      else if(menu)Promise.resolve(openWingSpeedMenu(player)).catch(error=>player.sendMessage('§c[날개] '+String(error)));
      else toggleWings(player);
     }catch(error){player.sendMessage('§c[날개 v0.6.31] '+String(error));}
    });
    return {status:status.Success};
   });
  }catch(error){console.error('[RPG v0.6.31 wings] '+def.name+' registration failed: '+String(error));}
 }
});

}
