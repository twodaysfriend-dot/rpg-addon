import {system,world} from '@minecraft/server';
import {ActionFormData,ModalFormData,MessageFormData} from '@minecraft/server-ui';
import {RUNES} from '../data/equipment.js';
import {RARITIES,itemGrade} from '../data/grades.js';
import {upgradeLevel,catalystAllowed,CATALYST_ID} from '../data/upgrades.js';
import {readRuneBag,depositRune} from './runeInventory.js';
import {enhancementQuote,enhanceEquipped} from './upgrades.js';
import {fusionQuote,fuseEquipment} from './fusion.js';
import {getWallet,canAfford} from './wallet.js';
import {showForm} from './skillMenu.js';
const sessions=new Map(),menus=new Set();let registered=false;
const tell=(p,s)=>{try{p.sendMessage(s);}catch{}};
export function parseRuneAuto(id,grade,level,catalysts){
 const normalize=s=>String(s??'').trim().replace(/\s+/g,'');const raw=normalize(id),alias={근력:'power',힘:'power',마력:'arcane',마법:'arcane',비전:'arcane',방어:'ward',수호:'ward',생명:'vitality',체력:'vitality',샘:'mana',마나:'mana',흡수:'absorption',흡혈:'absorption',공속:'attack_speed',치명타:'critical_hit',쿨감:'cooldown_reduction',쿨타임감소:'cooldown_reduction'};
 const kind=Object.keys(RUNES).find(k=>raw===k||raw==='rpg:rune_'+k||raw===normalize(RUNES[k].name))??alias[raw.replace(/의?룬$/,'')];
 const g=RARITIES.indexOf(normalize(grade)),rank=g>=0?g:Number(grade),target=Number(level),cat=Number(catalysts);
 if(!kind||!RUNES[kind]||!String(grade).trim()||!Number.isInteger(rank)||rank<0||rank>6||!String(level).trim()||!Number.isInteger(target)||target<0||target>10||!String(catalysts).trim()||!Number.isInteger(cat)||cat<0||cat>5)throw Error('룬 종류, 등급(일반~신화/0~6), 목표 강화(0~10), 촉매(0~5)를 확인하세요.');
 return {id:kind,grade:rank,level:target,catalysts:cat};
}
export function planRuneAuto(p,spec,protectedUids=[]){
 const bag=readRuneBag(p),protectedSet=new Set([...protectedUids,...bag.equipped.filter(Boolean)]),inv=p.getComponent('minecraft:inventory')?.container;
 const goal=bag.runes.find(r=>r.id===spec.id&&r.grade===spec.grade&&r.level>=spec.level);if(goal)return {type:'done',rune:goal};
 function need(grade,count,level){
  const score=r=>r.level>=level?r.level-level:100+level-r.level;
  const candidates=bag.runes.filter(r=>r.id===spec.id&&r.grade===grade&&!protectedSet.has(r.uid)).sort((a,b)=>score(a)-score(b)),tokens=[];
  if(inv)for(let i=0;i<inv.size;i++){const item=inv.getItem(i);if(item?.typeId==='rpg:rune_'+spec.id&&itemGrade(item)===grade)tokens.push({slot:i,level:upgradeLevel(item,'rune')});}tokens.sort((a,b)=>score(a)-score(b));
  if(candidates.length>=count){const chosen=candidates.slice(0,count),next=chosen.find(r=>r.level<level);if(next&&tokens[0]&&score(tokens[0])<score(chosen.at(-1)))return {type:'deposit',slot:tokens[0].slot};return next?{type:'enhance',uid:next.uid}:{type:'ready',runes:chosen};}
  if(tokens.length)return {type:'deposit',slot:tokens[0].slot};
  if(grade===0)return {type:'stop',reason:'사용할 '+RUNES[spec.id].name+' 재료가 부족합니다. 장착 중인 룬은 사용하지 않습니다.'};
  const lower=need(grade-1,2,5);return lower.type==='ready'?{type:'fuse',main:lower.runes[0].uid,material:lower.runes[1].uid}:lower;
 }
 const next=need(spec.grade,1,spec.level);return next.type==='ready'?{type:'done',rune:next.runes[0]}:next;
}
export function runeAutoStep(p,spec,options={}){
 try{
  const parsed=parseRuneAuto(spec.id,spec.grade,spec.level,spec.catalysts),plan=planRuneAuto(p,parsed,options.protectedUids);
  if(plan.type==='done')return {ok:true,done:true,rune:plan.rune};if(plan.type==='stop')return {ok:false,reason:plan.reason};
  if(plan.type==='deposit'){const result=depositRune(p,plan.slot);return result.ok?{ok:true,action:'deposit',rune:result.rune}:result;}
  if(plan.type==='enhance'){
   const q=enhancementQuote(p,'rune',plan.uid);if(!q?.cost)return {ok:false,reason:'강화할 룬이 변경됐습니다.'};
   if(!canAfford(getWallet(p),q.cost))return {ok:false,reason:'골드 또는 룬 가루가 부족하여 자동 완성을 종료했습니다.'};
   const count=catalystAllowed('rune',q.level)?parsed.catalysts:0,inv=p.getComponent('minecraft:inventory')?.container;let owned=0;if(inv)for(let i=0;i<inv.size;i++){const item=inv.getItem(i);if(item?.typeId===CATALYST_ID)owned+=item.amount;}
   if(owned<count)return {ok:false,reason:'선택한 촉매 '+count+'개가 부족하여 자동 완성을 종료했습니다.'};
   const r=enhanceEquipped(p,'rune',plan.uid,q.fingerprint,{catalystCount:count,random:options.random});return r.ok?{...r,action:'enhance'}:r;
  }
  const a={kind:'rune',slot:plan.main},b={kind:'rune',slot:plan.material},q=fusionQuote(p,a,b);if(!q)return {ok:false,reason:'합성 재료가 변경됐습니다.'};
  const r=fuseEquipment(p,a,b,q.fingerprint,{random:options.random});return r.ok?{...r,action:'fuse'}:r;
 }catch(error){return {ok:false,reason:'룬 자동 완성 종료: '+String(error.message??error)};}
}
export function stopRuneAuto(p,reason='직접 중단했습니다.'){
 const s=sessions.get(p.id);if(!s)return false;sessions.delete(p.id);tell(p,'§e[룬 자동 완성] '+reason+' · 강화 '+s.enhances+'회 / 합성 '+s.fusions+'회. 완료된 시도와 중간 룬은 유지됩니다.');return true;
}
export function startRuneAuto(p,spec){
 if(sessions.has(p.id))return {ok:false,reason:'이미 룬 자동 완성이 진행 중입니다.'};
 try{const parsed=parseRuneAuto(spec.id,spec.grade,spec.level,spec.catalysts),bag=readRuneBag(p);sessions.set(p.id,{p,spec:parsed,protectedUids:bag.equipped.filter(Boolean),enhances:0,fusions:0,operations:0});return {ok:true};}catch(error){return {ok:false,reason:String(error.message??error)};}
}
export function tickRuneAuto(){
 for(const s of [...sessions.values()]){
  if(!s.p.isValid||(s.p.getComponent('minecraft:health')?.currentValue??0)<=0){stopRuneAuto(s.p,'접속/생존 상태 변경으로 중단했습니다.');continue;}
  const r=runeAutoStep(s.p,s.spec,{protectedUids:s.protectedUids});
  if(!r.ok){stopRuneAuto(s.p,r.reason);continue;}if(r.done){stopRuneAuto(s.p,`목표 완료: ${RUNES[r.rune.id].name} ${RARITIES[r.rune.grade]} +${r.rune.level}`);continue;}
  s.operations++;if(r.action==='enhance')s.enhances++;if(r.action==='fuse')s.fusions++;
  if(s.operations%10===0)try{s.p.onScreenDisplay?.setActionBar('§d룬 자동 완성 · 강화 '+s.enhances+' / 합성 '+s.fusions+' · /rpg:runeautostop 으로 중단');}catch{}
 }
}
export function registerRuneAuto(){if(registered)return;registered=true;system.runInterval(tickRuneAuto,2);world.afterEvents.playerLeave.subscribe(({playerId})=>{const s=sessions.get(playerId);if(s)stopRuneAuto(s.p,'접속 종료로 중단했습니다.');menus.delete(playerId);});}
export async function openRuneAuto(p){
 if(menus.has(p.id))return;menus.add(p.id);
 try{
  if(sessions.has(p.id)){const yes=await showForm(new MessageFormData().title('룬 자동 완성 진행 중').body('현재 작업을 중단할까요? 이미 완료된 강화·합성과 사용한 재료는 되돌리지 않습니다.').button1('계속 진행').button2('중단'),p);if(yes&&!yes.canceled&&yes.selection===1)stopRuneAuto(p);return;}
  const kinds=Object.keys(RUNES);
  const input=await showForm(new ModalFormData().title('룬 자동 완성')
   .dropdown('룬 종류',kinds.map(id=>RUNES[id].name),{defaultValueIndex:0})
   .dropdown('목표 등급',RARITIES,{defaultValueIndex:1})
   .dropdown('목표 강화',Array.from({length:11},(_,i)=>'+'+i),{defaultValueIndex:5})
   .dropdown('시도당 촉매 수량 (+2부터)',Array.from({length:6},(_,i)=>i+'개'),{defaultValueIndex:0}),p);if(!input||input.canceled)return;
  const values=input.formValues??[];
  if(values.length!==4||values.some((v,i)=>!Number.isInteger(v)||v<0||v>=[kinds.length,RARITIES.length,11,6][i]))throw Error('선택한 항목을 확인하세요.');
  const spec=parseRuneAuto(kinds[values[0]],...values.slice(1));
  const yes=await showForm(new MessageFormData().title('자동 완성 확인').body(`${RUNES[spec.id].name} · ${RARITIES[spec.grade]} +${spec.level}\n시도당 촉매 ${spec.catalysts}개 (+2부터).\n인벤토리와 룬 가방의 같은 종류 재료를 자동 사용합니다. 장착 중인 룬은 보호합니다.\n+5 이상 두 개로 기존 확률 합성 → 상위 등급 +0 → 목표 강화까지 반복합니다. 강화된 룬도 합성 재료로 소모될 수 있습니다.\n실패·강등·파괴와 비용은 기존 규칙 그대로입니다. 필요한 재료·골드·룬 가루·촉매 부족 시 종료하며, 완료된 시도는 되돌리지 않습니다.\n/rpg:runeautostop으로 언제든 중단할 수 있습니다.`).button1('취소').button2('시작'),p);if(!yes||yes.canceled||yes.selection!==1)return;
  const result=startRuneAuto(p,spec);tell(p,result.ok?'§a룬 자동 완성을 시작했습니다.':'§e'+result.reason);
 }catch(error){tell(p,'§e'+String(error.message??error));}finally{menus.delete(p.id);}
}
