import {runeMeleeBonus} from './runeMelee.js';
import {criticalRuneMultiplier} from './combatRunes.js';
import {setCombatHealth} from './combatContext.js';
import {EquipmentSlot,EntityDamageCause} from '@minecraft/server';
import {onWeaponStrike} from './weaponOptions.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {classWeapon} from '../data/classWeapons.js';
import {GRADE_MULTIPLIERS,itemGrade} from '../data/grades.js';
import {upgradeLevel} from '../data/upgrades.js';
import {currentScriptHit,scriptedHit,rememberScriptKiller,noteManualDamage} from './combatContext.js';
import {areAllies} from './social.js';
import {CONFIG} from '../config.js';
export function commonWeaponFactor(item){
 const c=classWeapon(item?.typeId),w=COMMON_WEAPONS.find(w=>w.id===item?.typeId)??c;if(!w)return 1;
 // minecraft:damage adds to the player's one point native unarmed damage.
 return (1+w.damage*GRADE_MULTIPLIERS[itemGrade(item)]+upgradeLevel(item,'weapon'))/(1+w.damage);
}
export function applyCommonWeaponBonus(ev,scripted=false,p=ev.damageSource?.damagingEntity){
 const t=ev.hurtEntity,cause=ev.damageSource?.cause;
 const projectile=Boolean(ev.damageSource?.damagingProjectile)||cause==='projectile';
 const melee=!projectile&&cause===EntityDamageCause.entityAttack;
 if(scripted||p?.typeId!=='minecraft:player'||!t||p.id===t.id||(!melee&&!projectile)||currentScriptHit(p,t)||!(ev.damage>0)||areAllies(p,t))return ev.damage;
 if(['rpg:gpt_guide','minecraft:armor_stand','minecraft:item','minecraft:xp_orb'].includes(t.typeId)||t.typeId.startsWith('rpg:hito_'))return ev.damage;
 if(t.typeId==='minecraft:player'&&(!CONFIG.pvp||['creative','spectator'].includes(String(t.getGameMode?.()).toLowerCase())))return ev.damage;
 const item=melee?p.getComponent('minecraft:equippable')?.getEquipment(EquipmentSlot.Mainhand):undefined;
 const gear=melee&&(classWeapon(item?.typeId)||COMMON_WEAPONS.some(w=>w.id===item?.typeId));
 const weaponFactor=gear?commonWeaponFactor(item)*(1+runeMeleeBonus(p)):1;
 const critical=criticalRuneMultiplier(p),factor=weaponFactor*critical;
 if(!gear&&factor===1)return ev.damage;

 const hp=t.getComponent('minecraft:health');if(!hp)return ev.damage;
 // Add the same-hit proportional bonus AFTER native mitigation, without a second
 // armor pass or a second hit lost to invulnerability.
 const bonus=ev.damage*(factor-1),before=hp.currentValue,actual=Math.min(before,bonus);
 if(actual>0){
  if(actual>=before)rememberScriptKiller(p,t);
  scriptedHit(t,p,()=>{
   // A critical scales the native hit after mitigation and vulnerability.
   const applied=critical>1?{armorIncluded:true,raceIncluded:true,plagueIncluded:true}:undefined;
   setCombatHealth(t,p,hp,Math.max(0,before-actual),applied);
   noteManualDamage(p,t,Math.max(0,before-hp.currentValue),{incomingScaled:true});
   return true;
  });
 }
 if(gear)onWeaponStrike(p,t,item,ev.damage+bonus,Math.min(hp.effectiveMax,before+ev.damage));
 return ev.damage+bonus;
}
