import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0638'),base=root+'/RPG_BP_v0638/scripts/';
async function load(file,bindings={},basePath=base){const context=vm.createContext({console}),source=fs.readFileSync(basePath+file,'utf8'),m=new vm.SourceTextModule(source,{context});await m.link(async spec=>{const names=[];for(const hit of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(hit[2]===spec)names.push(...hit[1].split(',').map(n=>n.trim().split(/\s+as\s+/)[0]));return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(n==='projectileMotion'?(_p,speed,steps=1)=>({speed,steps,step:speed/steps}):()=>{}));},{context});});await m.evaluate();return m.namespace;}
const skills=(await load('data/skills.js')).SKILLS;
assert.equal(skills.war_god_flurry.projectiles,16);assert.equal(skills.war_god_flurry.damage,17);assert.equal(skills.nen_ho.cooldown,900);
async function waves({blocked=false,nativeFail=false,boost=false,distance=0,allied=false,move=false,skill=skills.war_god_flurry}={}){
 const intervals=new Map(),flags=new Map(),hits=[],manual=[],hitTicks=[],fx=[];let next=0;const system={currentTick:0,runInterval:fn=>{const id=++next;intervals.set(id,fn);return id;},clearRun:id=>intervals.delete(id)};const dim={id:'overworld'},hp={currentValue:3000,setCurrentValue(n){this.currentValue=n;}};
 const t={id:'enemy',typeId:'minecraft:zombie',location:{x:0,y:0,z:distance},getComponent:()=>hp,applyDamage:n=>{hits.push(n);hitTicks.push(system.currentTick);if(nativeFail)return false;hp.currentValue-=n;return true;}};
 const p={id:'p',typeId:'minecraft:player',isValid:true,location:{x:0,y:0,z:0},dimension:dim,getViewDirection:()=>move&&system.currentTick>=4?({x:1,y:0,z:0}):({x:0,y:0,z:1}),getComponent:()=>({currentValue:100}),getDynamicProperty:k=>flags.get(k),setDynamicProperty:(k,v)=>v===undefined?flags.delete(k):flags.set(k,v)};
 const mod=await load('skills/warGod.js',{world:{},system,strikeAxis:(x,y,z)=>[x,y,z],particle:(dim,id,at,axis)=>fx.push({id,at,axis}),EntityDamageCause:{override:'override'},getTargets:(p,point,radius)=>Math.hypot(point.x,point.z-distance)<=radius?[t]:[],headPos:p=>({...p.location,y:1.6}),norm3:v=>{const n=Math.hypot(v.x,v.y,v.z)||1;return {x:v.x/n,y:v.y/n,z:v.z/n};},isSolidAt:()=>blocked,areAllies:()=>allied,CONFIG:{pvp:false},skillDamageFor:(p,n)=>n,scriptedHit:(t,p,fn)=>fn(),deferStoppedDamage:()=>false,isTimeFrozen:()=>false,setCombatHealth:(t,p,hp,n)=>hp.setCurrentValue(n),noteManualDamage:(p,t,n)=>manual.push(n),BLACK_FLASH_KEY:'flash'});
 if(boost)flags.set('flash',true);assert.equal(mod.fanAttack(p,null,skill),true);let ticks=0;while(intervals.size&&ticks++<100){system.currentTick++;if(move&&system.currentTick===4)p.location={x:40,y:0,z:10};for(const fn of [...intervals.values()])fn();}assert.equal(intervals.size,0);return {hits,manual,hp,flags,ticks,hitTicks,fx};
}
{const t=await waves();assert.equal(t.hits.length,64);assert.ok(t.hits.every(n=>n===17));assert.equal(t.hp.currentValue,1912);}
{const t=await waves({nativeFail:true});assert.equal(t.hits.length,64);assert.equal(t.manual.reduce((a,b)=>a+b,0),1088);assert.equal(t.hp.currentValue,1912);}
{const t=await waves({boost:true});assert.equal(t.hits.length,64);assert.ok(t.hits.every(n=>n===34));assert.equal(t.flags.has('flash'),false);}
for(const option of [{blocked:true,boost:true},{allied:true,boost:true},{distance:100,boost:true}]){const t=await waves(option);assert.equal(t.hits.length,0);assert.equal(t.flags.get('flash'),true);}
{const t=await waves({distance:12});assert.ok(t.hits.length>0);assert.ok(t.ticks>1);const axes=t.fx.filter(f=>f.id==='rpg:war_god_fan_wave').map(f=>f.axis);assert.equal(new Set(axes.map(v=>v.join(','))).size,16);}
{const t=await waves({distance:-12});assert.equal(t.hits.length,4,'Backward rays hit once in each of four rings');}
{const t=await waves({skill:skills.war_god_eight_punch});assert.equal(t.hits.length,8);assert.ok(t.hits.every(n=>n===36));const flashes=t.fx.filter(x=>x.id==='rpg:war_god_burst');assert.equal(flashes.length,8);flashes.forEach((f,i)=>assert.equal(f.at.x,i%2?-.45:.45));assert.equal(new Set(t.hitTicks).size,8);}
{const t=await waves({skill:skills.war_god_eight_punch,boost:true});assert.equal(t.hits.length,8);assert.ok(t.hits.every(n=>n===72));}
{const t=await waves({skill:skills.war_god_eight_punch,move:true});const starts=t.fx.filter(f=>f.id==='rpg:war_god_burst');assert.equal(starts.length,8);assert.equal(starts[0].at.x,.45);assert.equal(starts[1].at.x,40);assert.equal(starts[1].at.z,10.45);assert.ok(t.fx.some(f=>f.axis?.[0]===1&&f.at.x>40));}
{
 const result=await waves({move:true});
 const launches=result.fx.filter(effect=>effect.id==='rpg:war_god_burst');
 assert.equal(launches.length,4);
 assert.deepEqual(launches.map(effect=>effect.at.x),[0,40,40,40]);
}
console.log('War God: four 360-degree 16-ray volleys, backward hits, eight alternating fists, per-cast x2 across delayed waves, walls/allies/range and misses preserve charge');
// Freeze the previous release curve here so source archives remain reproducible.
const armor=[[95,5,0,0],[90,10,0,0],[80,18,2,0],[70,23,7,0],[60,28,10,2],[50,30,16,4],[40,32,22,6],[30,34,27,9],[22,35,30,13],[15,35,32,18]],rune=[[95,5,0,0],[90,10,0,0],[70,28,2,0],[65,28,7,0],...armor.slice(4)];
const rates=(await load('data/upgrades.js')).enhancementRates;
for(const kind of ['rune','armor','weapon'])for(let level=0;level<10;level++)for(let c=0;c<=5;c++){
 const allowed=kind==='rune'?level>=2:kind==='weapon'?level>=3:level>=5,actual=rates(kind,level,c);if(c&&!allowed){assert.equal(actual,undefined);continue;}
 let [s,f,d,x]=(kind==='rune'?rune:armor)[level];if(c){x=Math.max(0,x-3*c);s=Math.min(s+9*c,100-d-x);f=100-s-d-x;}
 const expected=kind==='rune'?[s+d/4,f+d/4,d/2,x]:[s,f,d,x];assert.deepEqual(Array.from(Object.values(actual)),expected);assert.equal(expected.reduce((a,b)=>a+b),100);
}
assert.equal(rates('rune',2,5).success,98.5);assert.equal(rates('rune',2,5).fail,.5);assert.equal(rates('rune',2,5).downgrade,1);
console.log('Rune rates: every level and valid catalyst count halves downgrade, splits released chance equally, unchanged destruction; armor/weapons unchanged; totals exactly 100%');
console.log('Nen cannon cooldown: exactly 900 ticks / 45 seconds');

const grades=await load('data/grades.js');
const up=await load('data/upgrades.js',{gradeRank:grades.gradeRank,GRADE_MULTIPLIERS:grades.GRADE_MULTIPLIERS});
const runes=(await load('data/equipment.js',{COMMON_WEAPONS:[]})).RUNES;
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-9,`${a} != ${b}`);
for(const key of ['power','arcane'])for(let level=0;level<=10;level++){
 const field=key==='power'?'physical':'magic';
 for(let grade=1;grade<=6;grade++){
  const prev=up.upgradedRune(runes[key],level,grade-1)[field];
  const now=up.upgradedRune(runes[key],level,grade)[field];
  // Hero unlocks additional enhancement perks; all other grade steps are exactly x1.5.
  if(grade===4&&level>=8)assert.ok(now-1>=(prev-1)*1.5-1e-9);else close(now-1,(prev-1)*1.5);
 }
}
for(let level=0;level<=10;level++)for(let grade=0;grade<=6;grade++){
 const extras=grade>=4?(level>=8?.01:0)+(level>=10?.015:0):0;
 close(up.upgradedRune(runes.absorption,level,grade).lifesteal,((.05+level*.007)*1.5**grade+extras*(up.EXTRA_SCALE[grade]??1))*.5);
}
const stats=await load('core/stats.js',{criticalRuneMultiplier:()=>1,world:{},system:{},EquipmentSlot:{Mainhand:'Mainhand'},CONFIG:{skillDamage:{strengthPerLevel:.05}},getEquipmentBonuses:()=>({physical:1,magic:1}),classWeapon:()=>undefined});
const player=n=>({typeId:'minecraft:player',getDynamicProperty:k=>k==='rpg:stat_values'?JSON.stringify({str:n,mag:n,vit:5,int:5}):undefined,getComponent:()=>undefined,getEffect:()=>undefined});
for(const type of ['physical','magic']){close(stats.skillDamageFor(player(6),10,type)-stats.skillDamageFor(player(5),10,type),type==='physical'?.2352:.588);assert.equal(stats.skillDamageFor(player(100),10,'fixed'),10);}
const weapons=(await load('data/commonWeapons.js')).COMMON_WEAPONS;
let manual=0;
const damage=await load('core/commonWeaponDamage.js',{criticalRuneMultiplier:()=>1,COMMON_WEAPONS:weapons,classWeapon:()=>undefined,GRADE_MULTIPLIERS:grades.GRADE_MULTIPLIERS,itemGrade:i=>i.grade,upgradeLevel:i=>i.level,runeMeleeBonus:()=>0,EquipmentSlot:{Mainhand:'Mainhand'},EntityDamageCause:{entityAttack:'entityAttack'},currentScriptHit:()=>false,areAllies:()=>false,CONFIG:{pvp:false},scriptedHit:(t,p,fn)=>fn(),setCombatHealth:(t,p,hp,n)=>hp.currentValue=n,noteManualDamage:(p,t,n)=>manual+=n});
for(const w of weapons)for(let grade=0;grade<=6;grade++)for(let level=0;level<=10;level++){
 const item={typeId:w.id,grade,level},native=1+w.damage,expected=1+w.damage*grades.GRADE_MULTIPLIERS[grade]+level;
 const p={id:'p',typeId:'minecraft:player',getComponent:()=>({getEquipment:()=>item})},hp={currentValue:1000},t={id:'t',typeId:'minecraft:zombie',getComponent:()=>hp};
 close(damage.applyCommonWeaponBonus({damage:native,damageSource:{damagingEntity:p,cause:'entityAttack'},hurtEntity:t}),expected);
 close(hp.currentValue,1000-(expected-native));
 close(damage.applyCommonWeaponBonus({damage:native,damageSource:{damagingEntity:p,cause:'entityAttack'},hurtEntity:t},true),native);
}
console.log('v0.6.38: all rune grades/enhancements, halved absorption incl extras, STR +0.2352 / MAG +0.588 per base 10, all 7 common weapons x 7 grades x 11 upgrades through real melee hook; scripted hits excluded');

{
 const definitions=await load('data/commonWeapons.js');
 const weapon={typeId:'rpg:common_battle_sword',props:new Map(),lore:[],getDynamicProperty(k){return this.props.get(k);},setDynamicProperty(k,v){this.props.set(k,v);},getLore(){return this.lore;},setLore(v){this.lore=v;}};
 assert.equal(definitions.weaponOptionChance(weapon),0);
 const hit=[],timers=[],hooks={},dim={id:'overworld'};
 function actor(id,x) {
  const hp={currentValue:90,effectiveMax:100,setCurrentValue(n){this.currentValue=n;}};
  return {id,isValid:true,typeId:'minecraft:zombie',location:{x,y:0,z:0},dimension:dim,getComponent:()=>hp};
 }
 const caster=actor('player',0),a=actor('a',1),b=actor('b',4),c=actor('c',7);
 const bindings={weaponOptionChance:definitions.weaponOptionChance,CONFIG:{pvp:false},areAllies:()=>false,
  world:{beforeEvents:{entityHurt:{subscribe(fn){hooks.guard=fn;}}},afterEvents:{entityDie:{subscribe(fn){hooks.death=fn;}}}},
  getTargets:(p,at,r)=>[a,b,c].filter(e=>Math.abs(e.location.x-at.x)<=r),
  hurt:(t,p,n)=>{hit.push([t.id,n]);return true;},applyStatus:()=>{},particle:()=>{},
  system:{runTimeout:(fn,ticks)=>timers.push({fn,ticks}),run:fn=>fn()}};
 const effects=await load('core/weaponOptions.js',bindings);
 effects.registerWeaponOptions();
 for(const rate of [15,18,21,24,27,30,30]){
  definitions.advanceWeaponOption(weapon);
  assert.equal(definitions.weaponOptionChance(weapon),rate);
  assert.equal(weapon.lore.length,1);
  effects.onWeaponStrike(caster,a,weapon,100,95,()=>rate/100);
  assert.equal(hit.length,0);
  effects.onWeaponStrike(caster,a,weapon,100,95,()=>(rate-.1)/100);
  assert.deepEqual(hit.splice(0),[['b',80],['c',50]]);
 }
 const strike=(id,roll=0)=>{weapon.typeId='rpg:common_'+id;effects.onWeaponStrike(caster,a,weapon,100,25,()=>roll);};
 strike('redmoon_blade');strike('redmoon_blade',1);assert.deepEqual(hit.splice(0),[['a',60]]);
 strike('beast_axe');assert.deepEqual(hit.splice(0),[['a',75]]);assert.equal(caster.getComponent().currentValue,92);
 strike('battle_spear');const incoming={hurtEntity:caster,damageSource:{damagingEntity:b},damage:100};
 hooks.guard(incoming);assert.equal(incoming.damage,65);assert.deepEqual(hit.splice(0),[['b',35]]);
 strike('magitech_greatsword');timers.find(t=>t.ticks===16).fn();assert.deepEqual(hit.splice(0),[['a',65]]);
 b.location.x=2;strike('frost_greatsword');strike('frost_greatsword',1);assert.deepEqual(hit.splice(0),[['b',35]]);
 strike('flame_greatsword');timers.find(t=>t.ticks===20).fn();assert.deepEqual(hit.splice(0),[['a',15]]);
 hooks.death({deadEntity:a});timers.filter(t=>t.ticks===20).at(-1).fn();assert.deepEqual(hit.splice(0),[['b',15]]);
}
