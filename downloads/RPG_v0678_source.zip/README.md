# RPG v0.6.78 · 블라디미르 핏빛 계약과 적린약동

- **핏빛 계약**은 배분한 체력 1당 마력 0.5를 더합니다. 이 보너스를 포함한 마력 1당 RPG 최대 HP가 0.5 증가합니다. 상태창에서 소수점까지 볼 수 있습니다.
- **적린약동**은 힘 III·저항 II·야간 투시·성급함 III를 부여합니다. 쿨타임은 0초이며, 유지 중 초당 MP 10을 소모합니다. 재사용 또는 마나 부족 시 해제됩니다. 60초 연속 사용하면 시듦 V와 함께 초당 최대 HP의 5%를 추가로 소모하고 `1분간 적린약동을 사용하여 서서히 죽어간다!`를 채팅에 표시합니다.
- **혈액 난사**의 발당 기본 마법 피해를 4에서 5.2로 높였습니다.
- `/rpg:skillguide` 또는 상태창의 스킬 효과에서 블라디미르의 기술과 패시브를 확인할 수 있습니다. 카멜레온은 블라디미르 기술의 학습·랜덤 스킬북·사용에서 제외됩니다. 기존에 배운 기술은 주력 목록과 진화 슬롯에서 빠지고 일반 분해 기준으로 SP를 환급합니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.78로 활성화하고 월드를 다시 여세요. 모의 테스트에서 스탯과 소수점 HP, 적린약동의 마나·60초 경고·효과 해제, 스킬 도감 및 카멜레온 데이터 이전을 확인했습니다. 실제 Bedrock 월드에서는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0678
```
