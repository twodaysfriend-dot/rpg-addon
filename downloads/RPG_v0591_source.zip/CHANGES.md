# 변경 파일 목록

v0.5.88 기준 신규/수정 파일 35개. 각 텍스트 파일은 FULL_CODE.md 및 동일 경로에 전체 코드가 있습니다.

- RPG_BP_v0578/entities/the_world_stand.json — 충돌·중력·공격 판정이 없는 장식 스탠드 엔티티
- RPG_BP_v0578/items/the_world_arrow.json — BP: 전용 아이템 1종. RP attachable: 손에 든 모델 숨김
- RPG_BP_v0578/manifest.json — 기존 UUID를 유지하고 세 팩/의존 버전을 모두 0.5.91로 갱신
- RPG_BP_v0578/scripts/core/advance.js — 해금 미정 직업의 일반 전직 차단과 조건 안내; 관리자 force 경로 유지
- RPG_BP_v0578/scripts/core/combatContext.js — 새 시간 정지 상태인 시전자의 예약 스크립트 피해 차단
- RPG_BP_v0578/scripts/core/cyclopsBoss.js — 시간 정지 중 외눈박이의 예약 타격·패턴 차단
- RPG_BP_v0578/scripts/core/golemBoss.js — 시간 정지 중 골렘 패턴·피해 차단
- RPG_BP_v0578/scripts/core/input.js — 5개 스킬 runner 연결·아이템 입력 계열 등록·정지 중 시전 차단·궁극기 최소 MP 300
- RPG_BP_v0578/scripts/core/playerData.js — world_stop을 ULTIMATE_IDS에 추가
- RPG_BP_v0578/scripts/core/rpgActions.js — TPA 요청/수락 메뉴 명령어 연결
- RPG_BP_v0578/scripts/core/statusTablet.js — TPA 요청·받은 요청 버튼 2개 추가
- RPG_BP_v0578/scripts/core/theWorldStand.js — 등 뒤 외형 추적·중복 제거·차원 이동/직업 변경/종료 정리
- RPG_BP_v0578/scripts/core/timeStopDamage.js — 정지 대상별 시전자와 누적 피해를 저장하는 world 비의존 모듈
- RPG_BP_v0578/scripts/core/tpa.js — 30초 이동 요청·상대 수락·안전 착지·이동 후 1000골드 결제·실패 복구
- RPG_BP_v0578/scripts/core/util.js — 새 시간 정지 대상에 대한 기존 스킬 피해 지연 hook. 평상시 경로 유지
- RPG_BP_v0578/scripts/data/classWeapons.js — 전용 화살 직업 무기 강화와 스킬 보정 등록
- RPG_BP_v0578/scripts/data/hudNames.js — 전용 아이템 한국어 HUD 이름
- RPG_BP_v0578/scripts/data/jobs.js — 더 월드 히든 직업·전용 화살 1종·5개 스킬·unlockPending 등록
- RPG_BP_v0578/scripts/data/skillGuide.js — 직업 계열·5개 스킬 효과/MP/쿨·제한 사항 안내
- RPG_BP_v0578/scripts/data/skills.js — 5개 스킬 기본 수치와 궁극기 설정
- RPG_BP_v0578/scripts/main.js — 더 월드·스탠드·TPA register 호출
- RPG_BP_v0578/scripts/skills/theWorld.js — 5개 스킬·몹/플레이어/투사체 정지·보스 절반 시간·피해 누적·권한/효과/속도 복원·재로드 복구·전용 평타
- RPG_BP_v0578/scripts/skills/warGod.js — 기존 attack 함수 export와 새 정지 대상에만 동작하는 누적 피해 hook
- RPG_Commands_BP_v0578/manifest.json — 기존 UUID를 유지하고 세 팩/의존 버전을 모두 0.5.91로 갱신
- RPG_Commands_BP_v0578/scripts/commands.js — rpg:tpa와 rpg:tpaaccept 등록
- RPG_RP_v0578/animations/the_world_hidden.animation.json — 손 모델 스케일 0 애니메이션
- RPG_RP_v0578/attachables/the_world_arrow.json — BP: 전용 아이템 1종. RP attachable: 손에 든 모델 숨김
- RPG_RP_v0578/entity/the_world_stand.entity.json — 스탠드 클라이언트 외형·텍스처·렌더 연결
- RPG_RP_v0578/manifest.json — 기존 UUID를 유지하고 세 팩/의존 버전을 모두 0.5.91로 갱신
- RPG_RP_v0578/models/entity/the_world_hidden.geo.json — 손 모델 숨김용 geometry
- RPG_RP_v0578/models/entity/the_world_stand.geo.json — 6개 파츠 humanoid geometry 및 UV
- RPG_RP_v0578/textures/entity/the_world_stand.png — 참고 이미지 기반으로 재제작한 스탠드 스킨 PNG
- RPG_RP_v0578/textures/item_texture.json — 황금 화살 인벤토리 아이콘 등록
- RPG_RP_v0578/textures/items/the_world_arrow.png — 참고 이미지 기반으로 재제작한 황금 화살 PNG
- RPG_RP_v0578/ui/server_form.json — 상태창 18개 버튼을 위한 4열 5행 배치
