import {duelOf} from '../core/pvp.js';
import {world,system,InputPermissionCategory,EntityDamageCause} from '@minecraft/server';
import {attack as martialAttack} from './warGod.js';
import {SKILLS} from '../data/skills.js';
import {getJobId} from '../core/playerData.js';
import {getTargets,flatDir,isSolidAt,knockback,heldItemId,hurt} from '../core/util.js';
import {areAllies} from '../core/social.js';
import {isBoss} from '../core/crowdControl.js';
import {scriptedHit,setCombatHealth,noteManualDamage} from '../core/combatContext.js';
import {registerStoppedTarget,takeStoppedDamage,isTimeFrozen} from '../core/timeStopDamage.js';
export {isTimeFrozen};
const MARK='rpg:the_world_freeze_v1',TAG='rpg_the_world_frozen',WEAK='rpg:the_world_native_guard',HIGH='rpg:the_world_high_until';
const sessions=new Map(),frames=new Map(),basics=new Map();let registered=false;
const valid=e=>{try{return Boolean(e?.isValid);}catch{return false;}};
const living=e=>valid(e)&&(e.getComponent('minecraft:health')?.currentValue??0)>0;
const effectData=(e,name)=>{const f=e.getEffect(name);return f?{duration:f.duration,amplifier:f.amplifier}:null;};
function enemy(p,e){return valid(e)&&p.id!==e.id&&e.typeId!=='rpg:the_world_stand'&&!areAllies(p,e)&&!e.typeId.startsWith('rpg:hito_')&&e.typeId!=='rpg:gpt_guide'&&(e.typeId!=='minecraft:player'||!['creative','spectator'].includes(String(e.getGameMode?.()).toLowerCase()));}
export function restoreFrozenEntity(e){
 const raw=e.getDynamicProperty(MARK);if(raw===undefined){try{e.removeTag(TAG);}catch{}return true;}
 let saved;try{saved=JSON.parse(raw);}catch{console.warn('[The World] corrupt recovery marker');return false;}
 let okay=true;const elapsed=Math.max(0,Math.floor((Date.now()-saved.at)/50));
 for(const name of ['slowness','weakness'])try{e.removeEffect(name);const old=saved.effects[name];if(old&&old.duration>elapsed)e.addEffect(name,old.duration-elapsed,{amplifier:old.amplifier,showParticles:false});}catch{okay=false;}
 if(e.typeId==='minecraft:player')for(const [category,enabled]of saved.permissions??[])try{e.inputPermissions.setPermissionCategory(category,enabled);}catch{okay=false;}
 try{e.clearVelocity();const projectile=e.getComponent('minecraft:projectile');if(projectile)projectile.shoot(saved.velocity);else e.applyImpulse(saved.velocity);}catch{okay=false;}
 if(okay){e.setDynamicProperty(MARK,undefined);e.removeTag(TAG);}return okay;
}
function sharedGuild(a,b){try{return a?.typeId==='minecraft:player'&&b?.typeId==='minecraft:player'&&a.getTags().some(t=>t.startsWith('rpg_guild_')&&b.hasTag(t));}catch{return false;}}
function freeze(p,e,session){
 if(frames.has(e.id)||!enemy(p,e)||sharedGuild(p,e))return false;
 const projectile=e.getComponent('minecraft:projectile');
 if(projectile?.owner&&(projectile.owner.id===p.id||areAllies(p,projectile.owner)||sharedGuild(p,projectile.owner)))return false;
 if(!projectile&&!living(e))return false;
 if(e.getDynamicProperty(MARK)!==undefined&&!restoreFrozenEntity(e))return false;
 const saved={at:Date.now(),effects:{slowness:effectData(e,'slowness'),weakness:effectData(e,'weakness')},velocity:e.getVelocity(),permissions:[]};
 if(e.typeId==='minecraft:player')try{for(const category of [...new Set([InputPermissionCategory.Movement,InputPermissionCategory.Camera,...Object.values(InputPermissionCategory).filter(v=>typeof v==='number')])])saved.permissions.push([category,e.inputPermissions.isPermissionCategoryEnabled(category)]);}catch{saved.permissions=[];}
 e.setDynamicProperty(MARK,JSON.stringify(saved));e.addTag(TAG);e.clearVelocity();
 let mode='position';
 if(saved.permissions.length>=2)try{for(const category of [InputPermissionCategory.Movement,InputPermissionCategory.Camera])e.inputPermissions.setPermissionCategory(category,false);mode='inputPermissions';}catch{mode='position';}
 const duration=Math.ceil(SKILLS.world_stop.duration*(isBoss(e)?.5:1));
 if(!projectile){e.addEffect('slowness',duration,{amplifier:255,showParticles:false});e.addEffect('weakness',duration,{amplifier:255,showParticles:false});}
 frames.set(e.id,{entity:e,owner:p,location:{...e.location},rotation:e.getRotation(),dimension:e.dimension.id,until:system.currentTick+duration,duel:duelOf(p),mode});session.ids.add(e.id);registerStoppedTarget(e,p);return true;
}
function releaseFrame(id,applyDamage=true){
 const f=frames.get(id);frames.delete(id);const deferred=takeStoppedDamage(id);if(!f)return;
 try{if(valid(f.entity))restoreFrozenEntity(f.entity);}catch(error){console.warn('[The World restore] '+error);}
 if(!applyDamage||!deferred?.damage||!living(f.entity)||!living(f.owner)||areAllies(f.owner,f.entity)||(f.duel&&(f.duel.finished||duelOf(f.owner)!==f.duel||duelOf(f.entity)!==f.duel)))return;
 const target=f.entity,source=f.owner,amount=deferred.damage;
 scriptedHit(target,source,()=>{try{if(target.applyDamage(amount,{cause:EntityDamageCause.override,damagingEntity:source})!==false)return true;}catch{}
  const hp=target.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return false;const before=hp.currentValue;setCombatHealth(target,source,hp,Math.max(0,before-amount));noteManualDamage(source,target,Math.min(before,amount));return true;});
}
export function stopTheWorld(p,applyDamage=true){const session=sessions.get(p.id);if(!session)return false;sessions.delete(p.id);for(const id of session.ids)releaseFrame(id,applyDamage);return true;}
export function startTheWorld(p){
 if(sessions.has(p.id))return false;
 const session={ids:new Set(),dimension:p.dimension.id,until:system.currentTick+SKILLS.world_stop.duration};sessions.set(p.id,session);
 try{for(const e of p.dimension.getEntities({location:p.location,maxDistance:SKILLS.world_stop.radius})){if(session.ids.size>=60)break;try{freeze(p,e,session);}catch(error){try{restoreFrozenEntity(e);}catch{}console.warn('[The World freeze] '+error);}}}
 catch(error){stopTheWorld(p,false);throw error;}
 p.sendMessage('§6더 월드! §7시간이 멈췄습니다.');return true;
}
export function tickTheWorld(){
 for(const [id,s]of sessions){const p=world.getAllPlayers().find(p=>p.id===id);if(!living(p)||p.dimension.id!==s.dimension||system.currentTick>=s.until||getJobId(p)!=='the_world'){stopTheWorld(p??{id},living(p)&&p.dimension.id===s.dimension&&getJobId(p)==='the_world');continue;}}
 for(const [id,f]of frames){
  if(!valid(f.entity)||!living(f.owner)||f.entity.dimension.id!==f.dimension||system.currentTick>=f.until||areAllies(f.owner,f.entity)){releaseFrame(id);continue;}
  try{f.entity.teleport(f.location,{dimension:f.entity.dimension,rotation:f.rotation,keepVelocity:false});f.entity.clearVelocity();}catch{releaseFrame(id);}
 }
}
export function recoverStoppedEntities(){
 for(const name of ['overworld','nether','the_end'])try{for(const e of world.getDimension(name).getEntities({tags:[TAG]}))if(!frames.has(e.id))try{restoreFrozenEntity(e);}catch(error){console.warn('[The World recovery] '+error);}}catch{}
 for(const p of world.getAllPlayers())if(!frames.has(p.id)&&p.getDynamicProperty(MARK)!==undefined)try{restoreFrozenEntity(p);}catch{}
}
function saveNativeGuard(p){if(p.getDynamicProperty(WEAK)===undefined)p.setDynamicProperty(WEAK,JSON.stringify({at:Date.now(),effect:effectData(p,'weakness')}));p.addEffect('weakness',40,{amplifier:255,showParticles:false});}
function restoreNativeGuard(p){const raw=p.getDynamicProperty(WEAK);if(raw===undefined)return;const saved=JSON.parse(raw);p.removeEffect('weakness');const ticks=(Date.now()-saved.at)/50;if(saved.effect?.duration>ticks)p.addEffect('weakness',Math.ceil(saved.effect.duration-ticks),{amplifier:saved.effect.amplifier,showParticles:false});p.setDynamicProperty(WEAK,undefined);}
export function tickWorldGuards(){for(const p of world.getAllPlayers())try{if(isTimeFrozen(p))continue;if(getJobId(p)==='the_world'&&(heldItemId(p)==='rpg:the_world_arrow'||sessions.has(p.id))&&!isTimeFrozen(p))saveNativeGuard(p);else restoreNativeGuard(p);}catch(error){console.warn('[The World melee guard] '+error);}}
export function isWorldHighActive(p){return Number(p.getDynamicProperty(HIGH)??0)>Date.now();}
function punch(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,hits:d.hits*2}:d);}
function finisher(p,job,d){return martialAttack(p,job,isWorldHighActive(p)?{...d,damagePerHit:d.damagePerHit*2}:d);}
function roller(p,job,d){const dir=flatDir(p),origin=p.location;let at=origin;for(let n=.5;n<=3;n+=.5){const q={x:origin.x+dir.x*n,y:origin.y,z:origin.z+dir.z*n};if(isSolidAt(p.dimension,q)||isSolidAt(p.dimension,{...q,y:q.y+1}))break;at=q;}p.teleport(at,{dimension:p.dimension,keepVelocity:false});return martialAttack(p,job,d);}
function high(p){p.setDynamicProperty(HIGH,Date.now()+8000);p.addEffect('speed',160,{amplifier:1,showParticles:false});const strength=p.getEffect('strength');if(!strength||strength.amplifier<1||(strength.amplifier===1&&strength.duration<160))p.addEffect('strength',160,{amplifier:1,showParticles:false});return true;}
export const RUNNERS={world_muda:punch,world_finish:finisher,world_roller:roller,world_high:high,world_stop:startTheWorld};
export function registerTheWorld(){
 if(registered)return;registered=true;
 world.beforeEvents.itemUse.subscribe(e=>{if(isTimeFrozen(e.source)||(sessions.has(e.source.id)&&e.itemStack?.typeId!=='rpg:the_world_arrow'))e.cancel=true;});
 system.runInterval(tickTheWorld,1);system.runInterval(tickWorldGuards,1);system.runInterval(recoverStoppedEntities,100);system.run(recoverStoppedEntities);
 world.afterEvents.entitySpawn.subscribe(ev=>system.run(()=>{try{const owner=ev.entity.getComponent('minecraft:projectile')?.owner;if(owner&&isTimeFrozen(owner))ev.entity.remove();}catch{}}));
 // Stable 2.2.0 has no before-hurt cancellation. Weakness/projectile suppression
 // prevent normal attacks; refund any surviving native damage that still reports.
 world.afterEvents.entityHurt.subscribe(ev=>{
  const src=ev.damageSource,projectile=src?.damagingProjectile;
  let attacker=src?.damagingEntity;
  try{attacker=attacker??projectile?.getComponent('minecraft:projectile')?.owner;}catch{}
  if(!isTimeFrozen(attacker)&&!isTimeFrozen(projectile))return;
  try{const h=ev.hurtEntity.getComponent('minecraft:health');if(h?.currentValue>0&&ev.damage>0)h.setCurrentValue(Math.min(h.effectiveMax,h.currentValue+ev.damage));}catch{}
 });
 world.afterEvents.entityLoad.subscribe(ev=>{if(!frames.has(ev.entity.id))try{restoreFrozenEntity(ev.entity);}catch{}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.run(()=>{try{if(!frames.has(ev.player.id))restoreFrozenEntity(ev.player);restoreNativeGuard(ev.player);}catch{}}));
 world.afterEvents.playerDimensionChange.subscribe(ev=>stopTheWorld(ev.player,false));
 world.afterEvents.playerLeave.subscribe(ev=>{stopTheWorld({id:ev.playerId},false);basics.delete(ev.playerId);});
 world.afterEvents.entityDie.subscribe(ev=>{stopTheWorld(ev.deadEntity,false);if(frames.has(ev.deadEntity.id))releaseFrame(ev.deadEntity.id,false);});
 world.afterEvents.entityHitEntity.subscribe(ev=>{const p=ev.damagingEntity,t=ev.hitEntity;if(p?.typeId!=='minecraft:player'||getJobId(p)!=='the_world'||heldItemId(p)!=='rpg:the_world_arrow'||isTimeFrozen(p)||!enemy(p,t))return;
  const gap=isWorldHighActive(p)?5:10;if((basics.get(p.id)??-100)>system.currentTick-gap)return;basics.set(p.id,system.currentTick);hurt(t,p,8,'physical',{ignoreInvulnerability:true});});
}
