# RPG v0.6.86 · 던전과 전투 밸런스

## 던전

- 5~10단계 일반·엘리트 편성에서 버섯과 붉은 고블린을 제거했습니다.
- 8단계에 일반 데스웜 13마리, 9·10단계에 각각 일반 데스웜 10마리와 대장 고블린 10마리를 배치했습니다.
- 10단계 정예 5마리 중 2마리는 엘리트 데스웜입니다. 10단계 마공학 블록 골렘의 기본 수치는 체력 40,000 → 52,000, 공격력 180 → 225입니다. 공격력 상승은 보스 기믹에도 적용됩니다.

## 전투

- 히드라 브레스의 유도 화염구 3발은 폭발당 기본 피해 13 → 6.5입니다. 적중 시 화상은 3초입니다.
- 혈술사의 혈촉수는 기본 마법 피해 28 → 22.4, 적박은 10 → 20입니다. 피의 창은 근접 타격과 찌르기 합계 6회까지 쓸 수 있습니다.
- 투신 공격 스킬 6개의 기본 피해를 30% 높였습니다. 천멸격을 쓰면 다음 공격 스킬에 2배가 적용됩니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.86으로 활성화하고 월드를 다시 여세요. 모의 테스트에서 상위 던전 몹 수와 보스 전환, 화염구 3발 피해, 장비·룬이 적용된 스킬 피해, 피의 창 6회 소모를 확인했습니다. 실제 Bedrock 월드에서는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0686
```
