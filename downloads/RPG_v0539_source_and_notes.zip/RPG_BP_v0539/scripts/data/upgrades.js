export const ARMOR_LEVEL_KEY = 'rpg:armor_upgrade';
export const RUNE_LEVEL_KEY = 'rpg:rune_upgrade';
export const ARMOR_MAX = 10;
export const RUNE_MAX = 5;

export function upgradeLevel(item, kind) {
  const key = kind === 'armor' ? ARMOR_LEVEL_KEY : RUNE_LEVEL_KEY;
  const max = kind === 'armor' ? ARMOR_MAX : RUNE_MAX;
  const value = item?.getDynamicProperty(key);
  return Number.isInteger(value) ? Math.max(0, Math.min(max, value)) : 0;
}

// Costs refer to the NEXT level, and are consumed for all completed attempts.
export function upgradeCost(kind, current) {
  const max = kind === 'armor' ? ARMOR_MAX : kind === 'rune' ? RUNE_MAX : 0;
  if (!Number.isInteger(current) || current < 0 || current >= max) return undefined;
  const next = current + 1;
  return kind === 'armor'
    ? {gold:40*next*next, stone:2*next, dust:0}
    : {gold:60*next*next, stone:0, dust:2*next};
}

export const CATALYST_ID = 'rpg:enhancement_catalyst';
export const MAX_CATALYSTS = 5;
// Rows are success / unchanged failure / downgrade / destruction, in percent.
const ARMOR_RATES = [
  [95,5,0,0], [90,10,0,0], [80,18,2,0], [70,23,7,0], [60,28,10,2],
  [50,30,16,4], [40,32,22,6], [30,34,27,9], [22,35,30,13], [15,35,32,18],
];
const RUNE_RATES = [[90,10,0,0], [75,20,5,0], [55,25,16,4], [35,30,25,10], [20,32,30,18]];
export function catalystAllowed(kind,current) {return kind==='armor'?current>=5:kind==='rune'&&current>=2;}
export function enhancementRates(kind,current,catalystCount=0) {
  if (!Number.isInteger(catalystCount)||catalystCount<0||catalystCount>MAX_CATALYSTS) return undefined;
  const row = (kind==='armor'?ARMOR_RATES:kind==='rune'?RUNE_RATES:[])[current];
  if (!row) return undefined;
  let [success,fail,downgrade,destroy] = row;
  if (catalystCount>0) {
    if (!catalystAllowed(kind,current)) return undefined;
    destroy = Math.max(0,destroy-3*catalystCount);
    success = Math.min(success+5*catalystCount,100-downgrade-destroy);
    fail = 100-success-downgrade-destroy;
  }
  return {success,fail,downgrade,destroy};
}
export function rollEnhancement(rates,random=Math.random) {
  const value=random();
  if (!Number.isFinite(value)||value<0||value>=1) throw Error('강화 난수 범위 오류');
  const roll=value*100;
  if (roll<rates.success) return 'success';
  if (roll<rates.success+rates.fail) return 'fail';
  if (roll<rates.success+rates.fail+rates.downgrade) return 'downgrade';
  return 'destroy';
}

export function upgradedRune(rune, level) {
  if (!rune) return undefined;
  const rank = Math.max(0, Math.min(RUNE_MAX, Number.isInteger(level) ? level : 0));
  const result = {...rune, wardAmplifier:0, speedAmplifier:0};
  if (rune.physical) result.physical += rank*0.04;
  if (rune.magic) result.magic += rank*0.04;
  if (rune.manaRegenPercent) result.manaRegenPercent = (10+rank*4)/1000;
  if (rune.health) result.health = rune.health+rank*4;
  if (rune.lifesteal) result.lifesteal=(50+rank*14)/1000;
  if (rune.ward) {
    result.health = rank*2;
    result.wardAmplifier = rank === RUNE_MAX ? 1 : 0;
  }
  return result;
}
