import { HudElement, HudVisibility } from '@minecraft/server';

const numeric = new Set();
export function healthText(player) {
  const hp=player.getComponent('minecraft:health');
  if (!hp || !Number.isFinite(hp.effectiveMax) || hp.effectiveMax<=60) return '';
  const number=n=>String(Math.round(n*10)/10);
  return `§cHP ${number(Math.max(0,hp.currentValue))}/${number(hp.effectiveMax)}§r`;
}
export function updateHealthHud(player) {
  const text=healthText(player);
  const wasNumeric=numeric.has(player.id);
  const changed=Boolean(text)!==wasNumeric;
  if (changed) {
    player.onScreenDisplay.setHudVisibility(text?HudVisibility.Hide:HudVisibility.Reset,[HudElement.Health]);
    if (text) numeric.add(player.id); else numeric.delete(player.id);
  }
  return {text,changed};
}
export function clearHealthHud(playerId) {numeric.delete(playerId);}
export function resetHealthHud(player) {
  if (numeric.has(player.id)) player.onScreenDisplay.setHudVisibility(HudVisibility.Reset,[HudElement.Health]);
  numeric.delete(player.id);
}
