import {world} from '@minecraft/server';
import {readRuneBag} from './runeInventory.js';
import {RUNES} from '../data/equipment.js';
import {upgradedRune} from '../data/upgrades.js';
import {areAllies} from './social.js';
import {CONFIG} from '../config.js';
import {markDamageReported,setUnreportedDamageHandler,handleBasicHit} from './combatContext.js';
export function runeLifestealRate(p){
 const b=readRuneBag(p);for(const uid of b.equipped){const r=b.runes.find(r=>r.uid===uid);if(r?.id==='absorption')return upgradedRune(RUNES.absorption,r.level).lifesteal;}return 0;
}
export function healLifesteal(source,target,damage){
 if(source?.typeId!=='minecraft:player'||!target||source.id===target.id||areAllies(source,target)||(!CONFIG.pvp&&target.typeId==='minecraft:player')||['minecraft:armor_stand','rpg:sandbag_entity','minecraft:item','minecraft:xp_orb'].includes(target.typeId))return 0;
 if(target.typeId.startsWith('rpg:hito_'))return 0;
 if(!Number.isFinite(damage)||damage<=0)return 0;
 const h=source.getComponent('minecraft:health'),rate=runeLifestealRate(source);if(!h||h.currentValue<=0||rate<=0)return 0;
 const before=h.currentValue,after=Math.min(h.effectiveMax,before+damage*rate);if(after>before)h.setCurrentValue(after);return after-before;
}
let registered=false;
export function registerLifesteal(){
 if(registered)return;registered=true;setUnreportedDamageHandler(healLifesteal);
 world.afterEvents.entityHurt.subscribe(ev=>{try{let source=ev.damageSource?.damagingEntity;if(source?.typeId!=='minecraft:player')source=ev.damageSource?.damagingProjectile?.getComponent('minecraft:projectile')?.owner;const h=markDamageReported(source,ev.hurtEntity);const amount=h&&Number.isFinite(h.before)?Math.min(h.before,ev.damage):ev.damage;healLifesteal(source,ev.hurtEntity,amount);handleBasicHit(ev,Boolean(h));}catch{}});
}
