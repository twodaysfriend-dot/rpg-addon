import { ItemStack } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { JOBS } from "../data/jobs.js";
import {
  getJobId, getProgress, addProgress, maxManaOf, getMana, setMana, formatMana,
} from "./playerData.js";

// 인벤토리에서 itemId 를 최대 limit 개까지 꺼내서 실제로 꺼낸 개수를 돌려줍니다.
function takeItems(player, itemId, limit) {
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c || limit <= 0) return 0;
  let taken = 0;
  for (let i = 0; i < c.size && taken < limit; i++) {
    const it = c.getItem(i);
    if (!it || it.typeId !== itemId) continue;
    const take = Math.min(it.amount, limit - taken);
    if (take >= it.amount) {
      c.setItem(i, undefined);
    } else {
      it.amount -= take;
      c.setItem(i, it);
    }
    taken += take;
  }
  return taken;
}

// Donations consume only the outstanding objective, with inventory/data rollback.
export function donateTrialItems(player,itemId,key,limit){
  const inv=player.getComponent('minecraft:inventory')?.container,progress=getProgress(player),remaining=Math.max(0,limit-(progress[key]??0));
  if(!inv||!remaining)return {ok:false,message:'이미 필요한 공물을 모두 바쳤습니다.'};
  const oldProgress=player.getDynamicProperty('rpg:progress'),oldMana=player.getDynamicProperty('rpg:mana'),mana=getMana(player),beforeMax=maxManaOf(player),entries=[];
  let needed=remaining;
  for(let i=0;i<inv.size&&needed>0;i++){const t=inv.getItem(i);if(t?.typeId===itemId){const take=Math.min(t.amount,needed);entries.push({slot:i,old:t.clone(),take});needed-=take;}}
  const taken=remaining-needed;if(!taken)return {ok:false,message:'바칠 아이템이 없습니다.'};
  try{
    for(const e of entries){const t=e.old.clone();if(t.amount===e.take)inv.setItem(e.slot,undefined);else{t.amount-=e.take;inv.setItem(e.slot,t);}}
    progress[key]=(progress[key]??0)+taken;player.setDynamicProperty('rpg:progress',JSON.stringify(progress));setMana(player,mana+maxManaOf(player)-beforeMax);
    return {ok:true,taken,have:progress[key],message:`공물 ${taken}개 제출 · ${progress[key]}/${limit} /rpg:jobs`};
  }catch(error){for(const e of entries)inv.setItem(e.slot,e.old);player.setDynamicProperty('rpg:progress',oldProgress);player.setDynamicProperty('rpg:mana',oldMana);return {ok:false,message:'공물 저장 실패: 아이템을 복구했습니다.'};}
}
export function offerBooks(player){
  const job=getJobId(player),have=getProgress(player).books??0,high=!!JOBS[job]?.highMana;
  const limit=job==='apprentice'?10:high?have+Math.min(2304,Number.MAX_SAFE_INTEGER-have):CONFIG.mana.maxBooks;
  const r=donateTrialItems(player,'minecraft:enchanted_book','books',limit);player.sendMessage(r.message);return r;
}
export function offerSwords(player){
  if(getJobId(player)!=='apprentice'){player.sendMessage('§e견습의 검사 전직 시련입니다. /rpg:jobs');return {ok:false};}
  const r=donateTrialItems(player,'minecraft:diamond_sword','diamond_swords',5);player.sendMessage(r.message);return r;
}
export function offerLight(player){
  if(getJobId(player)!=='angel'){player.sendMessage('§e천사가 미카엘이 되기 위한 빛 공물입니다. /rpg:jobs');return {ok:false};}
  const r=donateTrialItems(player,'rpg:blessing_light','light_michael',192);player.sendMessage(r.message);return r;
}

function isWaterBottle(item) {
  if (item.typeId !== "minecraft:potion") return false;
  try {
    const id = String(item.getComponent("minecraft:potion")?.potionEffectType?.id ?? "").toLowerCase();
    return id === "water";
  } catch {
    return false;
  }
}

// /rpg:holywater : 작업대 조합이 안 될 때 쓰는 대체 수단. 물병 1개 + 축복의 빛 1개 → 성수 1개
export function craftHolyWater(player) {
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c) return;
  let bottleSlot = -1;
  let lightSlot = -1;
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (!it) continue;
    if (bottleSlot < 0 && isWaterBottle(it)) bottleSlot = i;
    if (lightSlot < 0 && it.typeId === "rpg:blessing_light") lightSlot = i;
  }
  if (bottleSlot < 0 || lightSlot < 0) {
    player.sendMessage("§7물병 1개와 축복의 빛 1개가 필요합니다.");
    return;
  }
  const dec = (slot) => {
    const it = c.getItem(slot);
    if (it.amount <= 1) c.setItem(slot, undefined);
    else {
      it.amount -= 1;
      c.setItem(slot, it);
    }
  };
  dec(bottleSlot);
  dec(lightSlot);
  const left = c.addItem(new ItemStack("rpg:holy_water", 1));
  if (left) player.dimension.spawnItem(left, player.location);
  player.sendMessage("§a성수를 만들었습니다.");
}
