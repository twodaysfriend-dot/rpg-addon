import { world, system, EntityDamageCause } from "@minecraft/server";
import { areAllies } from "./social.js";

let registered = false;

// 최종 피해 판정에서 같은 길드/파티/팀의 플레이어를 보호합니다.
// minecraft:projectile 컴포넌트의 owner도 추적하여 일반 화살을 포함합니다.
export function registerFriendlyFire(onAllyMeleeHit) {
  if (registered) return;
  registered = true;
  try {
    world.beforeEvents.entityHurt?.subscribe(event => {
      try {
        const victim = event.hurtEntity;
        if (victim?.typeId !== "minecraft:player") return;
        const src = event.damageSource;
        let attacker = src?.damagingEntity;
        if (!attacker || attacker.typeId !== "minecraft:player") {
          const projectile = src?.damagingProjectile;
          attacker = projectile?.getComponent("minecraft:projectile")?.owner ?? attacker;
        }
        if (attacker?.typeId === "minecraft:player" && areAllies(attacker, victim)) {
          event.cancel = true;
          // Canceling damage can also suppress afterEvents.entityHitEntity on some
          // Bedrock versions. Still allow *support* skills to target guild/party allies.
          if (typeof onAllyMeleeHit === "function" &&
              src?.cause === EntityDamageCause.entityAttack &&
              src?.damagingEntity?.id === attacker.id) {
            system.run(() => {
              try { if (attacker.isValid && victim.isValid) onAllyMeleeHit(attacker, victim); }
              catch {}
            });
          }
        }
      } catch { /* 접근할 수 없는 엔티티는 무시 */ }
    });
  } catch(error) {
    console.warn(`[RPG] 아군 피해 취소 이벤트를 연결하지 못했습니다: ${error}`);
  }
}
