import { EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { armorInfo, RUNES, RUNE_KEY } from '../data/equipment.js';
import { ARMOR_LEVEL_KEY, RUNE_LEVEL_KEY, upgradeLevel, upgradeCost, upgradedRune, enhancementRates, rollEnhancement, catalystAllowed, CATALYST_ID, MAX_CATALYSTS } from '../data/upgrades.js';
import { getWallet, setWallet, canAfford, walletText } from './wallet.js';
import { showForm } from './skillMenu.js';
import { readRuneBag, writeRuneBag, migrateChestRune } from './runeInventory.js';

const SLOTS = () => [
  {slot:EquipmentSlot.Head, part:'helmet', name:'투구'},
  {slot:EquipmentSlot.Chest, part:'chestplate', name:'흉갑'},
  {slot:EquipmentSlot.Legs, part:'leggings', name:'각반'},
  {slot:EquipmentSlot.Feet, part:'boots', name:'장화'},
];
export function describeRune(id, rank) {
  const r = upgradedRune(RUNES[id],rank);
  if (!r) return '없음';
  const values = [];
  if (r.physical && r.physical>1) values.push(`물리 스킬 +${Math.round((r.physical-1)*100)}%`);
  if (r.magic && r.magic>1) values.push(`마법 스킬 +${Math.round((r.magic-1)*100)}%`);
  if (r.health) values.push(`최대 HP +${r.health}`);
  if (r.manaRegenPercent) values.push(`초당 최대 마나의 +${Number((r.manaRegenPercent*100).toFixed(1))}% 회복`);
  if (r.lifesteal) values.push('준 피해의 '+Number((r.lifesteal*100).toFixed(1))+'% 흡혈');
  if (r.ward) values.push('저항 '+(r.wardAmplifier+1));
  if (r.speed) values.push('신속 '+(r.speedAmplifier+1));
  return values.join(', ');
}

function fingerprint(item) {return JSON.stringify([item.typeId,upgradeLevel(item,'armor')]);}
export function enhancementQuote(player,kind,slot) {
  if(kind==='rune') {
    const rune=readRuneBag(player).runes.find(r=>r.uid===slot);if(!rune)return undefined;
    return {kind,slot,level:rune.level,runeId:rune.id,fingerprint:JSON.stringify(rune),cost:upgradeCost(kind,rune.level),name:RUNES[rune.id].name,
      effect:describeRune(rune.id,rune.level)+'\n→ '+describeRune(rune.id,rune.level+1)};
  }
  if(kind!=='armor')return undefined;
  const definition=SLOTS().find(s=>s.slot===slot),item=player.getComponent('minecraft:equippable')?.getEquipment(slot);
  const info=armorInfo(item?.typeId);if(!definition||info?.part!==definition.part)return undefined;
  const level=upgradeLevel(item,'armor');return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:info.name+' '+definition.name,effect:`부위 강화 HP +${level} → +${level+1}`};
}

export function enhanceEquipped(player,kind,slot,expectedFingerprint,options={}) {
  try {
    const quote=enhancementQuote(player,kind,slot);
    if (!quote) return {ok:false,reason:'강화할 RPG 갑옷 또는 보관 룬이 없습니다.'};
    if (!quote.cost) return {ok:false,reason:'이미 최대 강화 단계입니다.'};
    if (expectedFingerprint!==undefined&&quote.fingerprint!==expectedFingerprint) return {ok:false,reason:'장비 또는 강화 단계가 변경됐습니다. 다시 선택하세요.'};
    const catalystCount=options.catalystCount??0;
    const rates=enhancementRates(kind,quote.level,catalystCount);
    if (!rates) return {ok:false,reason:'촉매 수량은 0~5개이며, 갑옷 +5·룬 +2부터 사용할 수 있습니다.'};
    const wallet=getWallet(player);
    if (!canAfford(wallet,quote.cost)) return {ok:false,reason:'강화에 필요한 재화가 부족합니다.'};
    const eq=player.getComponent('minecraft:equippable');
    const inventory=player.getComponent('minecraft:inventory')?.container;
    const catalysts=[];
    let needed=catalystCount;
    if(needed>0&&inventory)for(let i=0;i<inventory.size&&needed>0;i++) {
      const token=inventory.getItem(i);
      if(token?.typeId!==CATALYST_ID||token.amount<1)continue;
      const take=Math.min(needed,token.amount);
      catalysts.push({slot:i,original:token.clone(),take});needed-=take;
    }
    if(needed>0)return {ok:false,reason:`강화 촉매 ${catalystCount}개가 필요합니다.`};
    const original=kind==='armor'?eq.getEquipment(slot).clone():readRuneBag(player);
    const outcome=rollEnhancement(rates,options.random??Math.random);
    let level=quote.level,target;
    if(outcome==='success')level++;
    if(outcome==='downgrade')level=Math.max(0,level-1);
    if(kind==='armor') {
      target=original.clone();
      if(outcome==='destroy'){target=undefined;level=0;}
      else {target.setDynamicProperty(ARMOR_LEVEL_KEY,level);const lore=target.getLore().filter(line=>!line.startsWith('§7강화:'));if(level>0)lore.push(`§7강화: +${level} · 최대 HP +${level}`);target.setLore(lore);}
    }else{
      target=JSON.parse(JSON.stringify(original));
      if(outcome==='destroy'){level=0;target.runes=target.runes.filter(r=>r.uid!==slot);target.equipped=target.equipped.map(uid=>uid===slot?null:uid);}
      else target.runes.find(r=>r.uid===slot).level=level;
    }
    const next=Object.fromEntries(Object.entries(wallet).map(([k,v])=>[k,v-quote.cost[k]]));
    let debited=false,catalystTouched=false;
    try {
      setWallet(player,next);debited=true;
      if(catalysts.length) {
        catalystTouched=true;
        for(const entry of catalysts) {
          if(entry.original.amount===entry.take)inventory.setItem(entry.slot,undefined);
          else {const remaining=entry.original.clone();remaining.amount-=entry.take;inventory.setItem(entry.slot,remaining);}
        }
      }
      if(kind==='armor'){if(!eq.setEquipment(slot,target))throw Error('장비 저장 실패');}else writeRuneBag(player,target);
    } catch(error) {
      let recovered=true;
      try {if(kind==='armor'){if(!eq.setEquipment(slot,original))recovered=false;}else writeRuneBag(player,original);}catch{recovered=false;}
      if(catalystTouched)for(const entry of catalysts)try{inventory.setItem(entry.slot,entry.original);}catch{recovered=false;}
      if(debited)try{setWallet(player,wallet);}catch{recovered=false;}
      if(!recovered)console.error('[RPG upgrade] rollback incomplete: '+String(error));
      return {ok:false,reason:recovered?'강화를 저장하지 못해 취소하고 재화를 복구했습니다.':'강화 복구에 실패했습니다. 관리자에게 콘텐츠 로그 확인을 요청하세요.'};
    }
    return {ok:true,outcome,level,cost:quote.cost,rates,catalystCount};
  }catch(error){return {ok:false,reason:'강화 오류: '+String(error)};}
}

const menus = new Set();
export async function openUpgradeMenu(player) {
  if (menus.has(player.id)) return;
  menus.add(player.id);
  try {
    const migration=migrateChestRune(player);if(!migration.ok)player.sendMessage('§e'+migration.reason);
    for (let count=0;count<40&&player.isValid;count++) {
      const options = SLOTS().map(s=>enhancementQuote(player,'armor',s.slot)).filter(Boolean);
      for(const rune of readRuneBag(player).runes)options.push(enhancementQuote(player,'rune',rune.uid));
      const form = new ActionFormData().title('RPG 갑옷 · 룬 강화').body(walletText(getWallet(player))+
        '\n\n단계가 높아질수록 실패·강등·파괴 위험 증가\n갑옷 최대 +10: 부위당 단계별 최대 HP +1\n룬 최대 +5: 종류별 효과 성장'+
        '\nHP는 게임 효과 특성상 총합을 4 HP 단위로 근사합니다.\n착용 중인 장비를 선택하세요. 룬은 전용 보관함에 넣은 뒤 강화합니다.\n촉매: 갑옷 +5 / 룬 +2부터 최대 5개. 1개당 성공률 +5%p, 파괴확률 -3%p.');
      for (const q of options) form.button(`${q.kind==='armor'?'갑옷':'룬'}: ${q.name} +${q.level}\n`+(q.cost?`다음 단계: 골드 ${q.cost.gold} / ${q.cost.stone?'강화석 '+q.cost.stone:'룬 가루 '+q.cost.dust}`:'최대 단계'));
      form.button('닫기');
      const result = await showForm(form,player);
      if (!result || result.canceled || result.selection==null || result.selection>=options.length) return;
      const quote = options[result.selection];
      if (!quote.cost) {player.sendMessage('§e[RPG] 이미 최대 강화 단계입니다.');continue;}
      let catalystCount=0;
      if(catalystAllowed(quote.kind,quote.level)) {
        const inventory=player.getComponent('minecraft:inventory')?.container;
        let owned=0;
        if(inventory)for(let i=0;i<inventory.size;i++){const token=inventory.getItem(i);if(token?.typeId===CATALYST_ID)owned+=token.amount;}
        const maximum=Math.min(MAX_CATALYSTS,owned);
        const form=new ActionFormData().title('강화 촉매 수량')
          .body(`보유 촉매 ${owned}개. 한 번에 최대 5개 사용.\n1개당 성공률 +5%p, 파괴확률 -3%p (최소 0%).\n완료된 모든 결과에서 선택 수량을 소비합니다.`);
        for(let count=0;count<=maximum;count++) {
          const preview=enhancementRates(quote.kind,quote.level,count);
          form.button(`${count===0?'촉매 사용 안 함':count+'개 사용'}\n성공 ${preview.success}% / 파괴 ${preview.destroy}%`);
        }
        form.button('취소');
        const choice=await showForm(form,player);
        if(!choice||choice.canceled||choice.selection==null||choice.selection>maximum)continue;
        catalystCount=choice.selection;
      }
      const rates=enhancementRates(quote.kind,quote.level,catalystCount);
      const percentages=`성공 ${rates.success}% / 유지 실패 ${rates.fail}%\n1단계 강등 ${rates.downgrade}% / 파괴 ${rates.destroy}%`;
      const destruction=quote.kind==='armor'?'갑옷 파괴 시 갑옷만 소멸하고 전용 보관함 룬은 유지됩니다.':'룬 파괴 시 해당 보관 룬만 소멸하며 장착도 해제됩니다.';
      const confirm=await showForm(new MessageFormData().title('위험 강화 확인')
        .body(`${quote.name} +${quote.level} → +${quote.level+1}\n${quote.effect}\n\n${percentages}\n${destruction}\n\n비용: 골드 ${quote.cost.gold}, 강화석 ${quote.cost.stone}, 룬 가루 ${quote.cost.dust}\n${catalystCount?'강화 촉매 '+catalystCount+'개 사용\n':''}모든 결과에서 비용이 소비됩니다.`)
        .button1('취소').button2('강화'),player);
      if(!confirm||confirm.canceled||confirm.selection!==1)continue;
      const attempt=enhanceEquipped(player,quote.kind,quote.slot,quote.fingerprint,{catalystCount});
      if(!attempt.ok)player.sendMessage('§c[RPG] '+attempt.reason);
      else {
        const messages={success:`§a강화 성공! +${attempt.level}`,fail:'§e강화 실패: 단계 유지',downgrade:`§6강등: +${attempt.level}`,destroy:quote.kind==='armor'?'§c갑옷 파괴: 갑옷만 소멸':'§c룬 파괴: 해당 보관 룬 소멸'};
        player.sendMessage('[RPG] '+quote.name+' · '+messages[attempt.outcome]);
      }
    }
  } catch(error) {try {player.sendMessage('§c[RPG] 강화 메뉴 오류: '+String(error));} catch {}}
  finally {menus.delete(player.id);}
}
