import { world,system } from '@minecraft/server';
import { getJobId,getProgress,addProgress } from './playerData.js';
export const HEALED_KEY='rpg:healed_patients_v1';
const holy=new Set(['cleric','angel','michael']);
const launches=new Map();
const active=p=>p&& !['creative','spectator'].includes(String(p.getGameMode?.()).toLowerCase());
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
export function recordHealedPlayer(caster,target,amount){
  if(amount<=0||target?.typeId!=='minecraft:player'||caster?.id===target.id||!holy.has(getJobId(caster))||!active(caster)||!active(target))return;
  const patients=JSON.parse(caster.getDynamicProperty(HEALED_KEY)??'[]').filter(p=>p.id!==target.id&&p.name!==target.name);
  patients.push({id:target.id,name:target.name});caster.setDynamicProperty(HEALED_KEY,JSON.stringify(patients.slice(-128)));
}
export function witnessHealedDeath(caster,dead){
  const patients=JSON.parse(caster.getDynamicProperty(HEALED_KEY)??'[]');
  if(!patients.some(p=>p.id===dead.id||p.name===dead.name))return false;
  caster.setDynamicProperty(HEALED_KEY,JSON.stringify(patients.filter(p=>p.id!==dead.id&&p.name!==dead.name)));
  if(!holy.has(getJobId(caster))||!active(caster)||!active(dead)||caster.dimension.id!==dead.dimension.id||distance(caster.location,dead.location)>32||(caster.getComponent('minecraft:health')?.currentValue??0)<=0)return false;
  const from={...caster.location,y:caster.location.y+1.6},to={...dead.location,y:dead.location.y+1},length=distance(from,to);
  for(let n=.5;n<length;n+=.5){const t=n/length;try{if(caster.dimension.getBlock({x:from.x+(to.x-from.x)*t,y:from.y+(to.y-from.y)*t,z:from.z+(to.z-from.z)*t})?.isSolid)return false;}catch{return false;}}
  const n=addProgress(caster,'healed_deaths');caster.sendMessage(`§5[성직 시련] 치유한 플레이어 사망 목격 ${Math.min(n,5)}/5`);return true;
}
export function recordVillagerTrialKill(p,dead){
  if(getJobId(p)==='sword_saint'&&active(p)&&['minecraft:villager','minecraft:villager_v2'].includes(dead?.typeId))addProgress(p,'villager_kills');
}
export function rememberQuestArrow(arrow){
  if(arrow?.typeId!=='minecraft:arrow')return;
  const owner=arrow.getComponent('minecraft:projectile')?.owner;
  launches.set(arrow.id,{origin:{...(owner?.location??arrow.location)},ownerId:owner?.id,dimension:arrow.dimension.id,at:system.currentTick});
}
export function recordTargetHit(ev){
  const arrow=ev.projectile,launch=launches.get(arrow?.id);if(!launch)return false;launches.delete(arrow.id);
  const p=ev.source??arrow.getComponent('minecraft:projectile')?.owner,block=ev.getBlockHit?.()?.block;
  if(!p||getJobId(p)!=='apprentice'||!active(p)||block?.typeId!=='minecraft:target'||p.dimension.id!==launch.dimension||(launch.ownerId&&launch.ownerId!==p.id))return false;
  const center={x:block.location.x+.5,y:block.location.y+.5,z:block.location.z+.5};
  if(distance(launch.origin,center)<=20)return false;
  if(!getProgress(p).archer_target20)addProgress(p,'archer_target20');p.sendMessage('§a[궁수 시련] 발사 지점에서 20칸 밖 과녁 명중 완료!');return true;
}
export function registerJobQuests(){
  world.afterEvents.entitySpawn.subscribe(ev=>{try{rememberQuestArrow(ev.entity);}catch{}});
  world.afterEvents.projectileHitBlock.subscribe(ev=>{try{recordTargetHit(ev);}catch{}});
  world.afterEvents.entityDie.subscribe(ev=>{
    let killer=ev.damageSource?.damagingEntity;if(killer?.typeId!=='minecraft:player')killer=ev.damageSource?.damagingProjectile?.getComponent('minecraft:projectile')?.owner;
    try{if(killer?.typeId==='minecraft:player')recordVillagerTrialKill(killer,ev.deadEntity);}catch{}
    if(ev.deadEntity?.typeId==='minecraft:player')for(const p of world.getAllPlayers())try{if(p.id!==ev.deadEntity.id)witnessHealedDeath(p,ev.deadEntity);}catch(error){console.warn('[RPG witness] '+String(error));}
  });
  system.runInterval(()=>{for(const [id,a] of launches)if(system.currentTick-a.at>1200)launches.delete(id);},200);
}
