import {world,system} from '@minecraft/server';
import {ActionFormData} from '@minecraft/server-ui';
import {DUNGEON,DUNGEON_TIERS,dungeonTier,dungeonBlock,inCaveVolume,ceilingHeight,clearRewardForTier} from '../data/dungeons.js';
import {isActiveNearbyPlayer} from './xpDistribution.js';
import {healthAlive} from './util.js';
import {creditDungeonClear,claimDungeonLoot} from './dungeonRewards.js';
import {dungeonRuns as runs,dungeonLobbies as lobbies,dungeonHudText} from './dungeonState.js';
export const DUNGEON_KEY='rpg:dungeons_v1',RETURN_KEY='rpg:dungeon_return_v1';
const builders=new Map(),MOB_TAG='rpg_dungeon_mob';let db,registered=false,maintenanceTick=-20;
const say=(p,s)=>{try{p?.sendMessage(s);}catch{}};
const admin=p=>p?.playerPermissionLevel===2||p?.commandPermissionLevel>=1||p?.isOp?.()===true;
function state(){
 if(!db){const raw=world.getDynamicProperty(DUNGEON_KEY);db=raw===undefined?{version:2,nextRun:1,dungeons:[],legacyDungeons:[],outbox:[]}:JSON.parse(raw);
  if(db.version===1){db.legacyDungeons=db.dungeons;db.dungeons=[];db.version=2;}
  if(db.version!==2||!Array.isArray(db.dungeons)||!Array.isArray(db.outbox)||!Number.isSafeInteger(db.nextRun))throw Error('던전 저장 데이터 오류');
  db.legacyDungeons??=[];
 }
 return db;
}
function save(){const raw=JSON.stringify(state());if(raw.length>29000)throw Error('던전 저장 공간 부족');world.setDynamicProperty(DUNGEON_KEY,raw);}
const find=id=>state().dungeons.find(d=>d.id===id);
const allRegistered=()=>[...state().dungeons,...state().legacyDungeons];
const runOf=id=>[...runs.values()].find(r=>r.members.some(m=>m.id===id));
const lobbyOf=id=>[...lobbies.values()].find(l=>l.members.some(m=>m.id===id));
const online=id=>world.getAllPlayers().find(p=>p.id===id);
const dimension=d=>world.getDimension(d.dimId);
const tagFor=d=>'rpg_dungeon_'+d.id;
function inside(p,d){const r=Math.hypot(p.location.x-d.x,p.location.z-d.z);return p.dimension.id===d.dimId&&r<DUNGEON.radius-2&&p.location.y>d.y&&p.location.y<d.y+ceilingHeight(r)-2;}
function protectedBlock(b,dimId){return allRegistered().some(d=>{
 if(d.dimId!==dimId)return false;const x=b.location.x-d.x,y=b.location.y-d.y,z=b.location.z-d.z;
 return d.shape==='cave_v2'?inCaveVolume(x,y,z):Math.abs(x)<=21&&Math.abs(z)<=21&&y>=0&&y<=18;
});}
function* volume(d){for(let y=0;y<=DUNGEON.height;y++)for(let x=-DUNGEON.radius;x<=DUNGEON.radius;x++)for(let z=-DUNGEON.radius;z<=DUNGEON.radius;z++)if(inCaveVolume(x,y,z))yield {x:d.x+x,y:d.y+y,z:d.z+z,block:dungeonBlock(x,y,z)};}
function requireAdmin(p){if(!admin(p))throw Error('던전 생성·등록 해제는 관리자만 가능합니다.');}
function requireTier(value){const t=dungeonTier(value);if(!t)throw Error('난이도 1~10을 선택하세요. 예: /rpg:dungeon 1');return t;}
export function listDungeons(){return DUNGEON_TIERS.map(t=>({...t,...find(t.id),status:find(t.id)?.status??'unbuilt',busy:runs.has(t.id),waiting:lobbies.get(t.id)?.members.length??0}));}
function queueBuilder(d,p){builders.set(d.id,{d,p,phase:'load',resume:d.status==='building',iterator:volume(d),readyTick:0});}
export function createDungeon(p,value){
 requireAdmin(p);if(p.dimension.id!=='minecraft:overworld')throw Error('던전은 오버월드에서 생성하세요.');
 const tiers=String(value)==='all'?DUNGEON_TIERS:[requireTier(value)],created=[];
 for(const tier of tiers){
  const old=find(tier.id);if(old?.status==='ready'||builders.has(tier.id)){if(tiers.length===1)throw Error('이미 있거나 생성 중인 던전입니다.');continue;}
  const index=tiers.length===1?0:tier.tier-1;
  const d=old??{id:tier.id,tier:tier.tier,shape:'cave_v2',dimId:p.dimension.id,x:Math.floor(p.location.x)+(index%5)*DUNGEON.buildSpacing,y:Math.min(276,Math.max(80,Math.floor(p.location.y)+64)),z:Math.floor(p.location.z)+Math.floor(index/5)*DUNGEON.buildSpacing,status:'queued'};
  if(!old&&allRegistered().some(v=>Math.abs(d.x-v.x)<DUNGEON.radius+(v.shape==='cave_v2'?32:21)+4&&Math.abs(d.z-v.z)<DUNGEON.radius+(v.shape==='cave_v2'?32:21)+4&&Math.abs(d.y-v.y)<DUNGEON.height+4))throw Error('다른 던전과 겹칩니다. 80칸 이상 이동하세요.');
  if(!old)state().dungeons.push(d);save();queueBuilder(d,p);created.push(tier.tier);
 }
 say(p,`§e[던전] 난이도 ${created.join(', ')} 원형 동굴 생성 예약. 차례로 빈 공간을 검사해 건설합니다.`);return {tiers:created};
}
function unloadBuildArea(d){
 if(!d.tempArea)return;
 try{dimension(d).runCommand('tickingarea remove '+d.tempArea);}catch{}
 delete d.tempArea;
}
function buildTick(job){
 const {d,p}=job;
 try{
  const dim=dimension(d);
  if(job.phase==='load'){
   d.tempArea='rpg_dng_build_'+d.tier+'_'+Date.now().toString(36);save();
   const result=dim.runCommand(`tickingarea add circle ${d.x} ${d.y} ${d.z} 3 ${d.tempArea} true`);
   if(result?.successCount===0)throw Error('임시 청크 로드 영역을 만들 수 없습니다. 기존 tickingarea 여유를 확인하세요.');
   job.readyTick=system.currentTick+20;job.phase='scan';d.status=job.resume?'building':'scanning';save();return;
  }
  if(system.currentTick<job.readyTick)return;
  for(let n=0;n<DUNGEON.buildBudget;n++){
   const next=job.iterator.next();
   if(next.done){
    if(job.phase==='scan'){job.phase='build';d.status='building';save();job.iterator=volume(d);return;}
    unloadBuildArea(d);d.status='ready';save();builders.delete(d.id);say(p,`§a[던전] 난이도 ${d.tier} ${DUNGEON_TIERS[d.tier-1].name} 생성 완료! /rpg:dungeon ${d.tier}`);return;
   }
   const at=next.value,b=dim.getBlock(at);if(!b)throw Error('청크를 불러오지 못했습니다. 같은 생성 명령어로 재시도하세요.');
   if(job.phase==='scan'){
    if(!b.isAir&&!(job.resume&&at.block===b.typeId))throw Error('기존 블록이 있어 중단했습니다. 다른 빈 지역에서 생성하세요.');
   }else if(at.block){
    if(!b.isAir&&b.typeId!==at.block)throw Error('생성 중 다른 블록을 발견했습니다. 해당 블록은 보존합니다.');
    if(b.isAir)b.setType(at.block);
   }else if(!b.isAir)throw Error('내부 공간에 다른 블록이 생겨 건설을 중단했습니다.');
  }
 }catch(error){
  builders.delete(d.id);unloadBuildArea(d);
  if(job.phase!=='build'&&!job.resume)state().dungeons=state().dungeons.filter(v=>v!==d);else d.status='building';
  try{save();}catch{}say(p,'§c[던전 '+d.tier+'] '+String(error.message??error));
 }
}
function cleanMobs(d){try{for(const e of dimension(d).getEntities({tags:[MOB_TAG,tagFor(d)]}))if(e.typeId!=='minecraft:player')e.remove();}catch{}}
export function removeDungeon(p,value){
 requireAdmin(p);const tier=dungeonTier(value),d=tier?find(tier.id):state().legacyDungeons.find(d=>d.id===value);
 if(!d)throw Error('등록된 던전이 없습니다.');if(runs.has(d.id)||builders.has(d.id)||lobbies.has(d.id))throw Error('생성·대기·진행 중인 던전은 등록 해제할 수 없습니다.');
 cleanMobs(d);unloadBuildArea(d);state().dungeons=state().dungeons.filter(v=>v!==d);state().legacyDungeons=state().legacyDungeons.filter(v=>v!==d);save();say(p,'§7던전 등록을 해제했습니다. 건축물은 보존합니다.');
}
function returnPlayer(p){
 const raw=p.getDynamicProperty(RETURN_KEY);if(raw===undefined)return true;if(!healthAlive(p))return false;
 const back=JSON.parse(raw);p.teleport(back.location,{dimension:world.getDimension(back.dimId),keepVelocity:false});p.setDynamicProperty(RETURN_KEY,undefined);return true;
}
function finish(r,cleared,reason='탐험이 종료되었습니다.'){
 if(r.finishing)return;r.finishing=true;
 if(cleared){
  const recipients=r.members.map(m=>online(m.id)).filter(p=>p&&healthAlive(p)&&inside(p,r.d)&&isActiveNearbyPlayer(p,p.location,p.dimension.id,1)),before=state().outbox.length;
  for(const p of recipients)state().outbox.push({playerId:p.id,runId:r.id,tier:r.d.tier});
  try{save();}catch(error){state().outbox.length=before;r.finishing=false;throw error;}
 }
 runs.delete(r.d.id);r.d.activeId=null;save();cleanMobs(r.d);
 for(const m of r.members){const p=online(m.id);if(!p)continue;
  say(p,cleared?'§6[던전] 보스 처치 성공! 클리어 보상을 지급하고 귀환합니다.':'§c[던전] '+reason+' 입장 위치로 귀환합니다.');
  try{returnPlayer(p);}catch{say(p,'§c귀환 대기: /rpg:dungeonleave 로 재시도하세요.');}
 }
 flushRewards();
}
function expired(r,now=Date.now()){
 if(now<r.deadline)return false;finish(r,false,r.phase==='boss'?'보스 제한 시간 3분을 초과했습니다.':r.phase==='preparing'?'던전 입장 공간을 불러오지 못했습니다.':'일반·엘리트 제한 시간 5분을 초과했습니다.');return true;
}
function spawnMob(r,kind,index){
 const tier=DUNGEON_TIERS[r.d.tier-1],pool=kind==='normal'?tier.normal:tier.elite,type=kind==='boss'?tier.boss:pool[index%pool.length];
 const angle=(index*2.3999632297+(kind==='elite'?1.2:0)),radius=kind==='boss'?0:18;
 const location={x:r.d.x+Math.cos(angle)*radius,y:r.d.y+1,z:r.d.z+Math.sin(angle)*radius};
 const mob=dimension(r.d).spawnEntity('rpg:'+type,location);
 try{mob.addTag(MOB_TAG);mob.addTag(tagFor(r.d));mob.triggerEvent('rpg:dungeon_tier_'+tier.tier);r.live.set(mob.id,{kind,mob});}
 catch(error){try{mob.remove();}catch{}throw error;}
 return mob;
}
function spawnBoss(r){
 if(r.phase!=='mobs'||r.normalSpawned!==50||r.eliteSpawned!==5||r.normalKilled!==50||r.eliteKilled!==5||r.live.size)return;
 const boss=spawnMob(r,'boss',0);r.bossId=boss.id;r.phase='boss';r.deadline=Date.now()+DUNGEON.bossLimitMs;
 for(const m of r.members)say(online(m.id),'§c[던전] 보스 등장! 지금부터 3분 안에 처치하세요.');
}
function spawnTick(r,now){
 if(r.phase!=='mobs'||r.live.size>=DUNGEON.maxAlive)return;
 if(r.eliteSpawned<DUNGEON.eliteCount&&now>=r.nextEliteAt){spawnMob(r,'elite',r.eliteSpawned++);r.nextEliteAt=Math.max(r.startedAt+(r.eliteSpawned+1)*DUNGEON.eliteIntervalMs,now+DUNGEON.eliteMinGapMs);}
 if(r.normalSpawned<DUNGEON.normalCount&&now>=r.nextNormalAt){
  const count=Math.min(DUNGEON.normalBatch,DUNGEON.normalCount-r.normalSpawned,DUNGEON.maxAlive-r.live.size);
  for(let i=0;i<count;i++){spawnMob(r,'normal',r.normalSpawned);r.normalSpawned++;}r.nextNormalAt=now+DUNGEON.normalIntervalMs;
 }
 spawnBoss(r);
}
export function enterDungeon(p,value){
 flushRewards();const tier=requireTier(value),d=find(tier.id);
 if(!d||d.status!=='ready')throw Error('아직 생성되지 않은 던전입니다. 관리자가 /rpg:dungeoncreate '+tier.tier+' 로 생성해야 합니다.');
 if(runs.has(d.id))throw Error('해당 던전은 진행 중입니다.');
 if(runOf(p.id)||p.getDynamicProperty(RETURN_KEY)!==undefined)throw Error('이미 진행·귀환 중입니다.');
 const previous=lobbyOf(p.id);if(previous){if(previous.d.id===d.id)return previous;throw Error('다른 대기실에 참가 중입니다. 먼저 /rpg:dungeonleave 를 사용하세요.');}
 if(!isActiveNearbyPlayer(p,p.location,p.dimension.id,1))throw Error('생존·서바이벌 상태에서 참가하세요.');
 if(state().outbox.some(o=>o.playerId===p.id))throw Error('이전 보상 저장을 완료한 뒤 참가하세요.');
 const lobby=lobbies.get(d.id)??{d,members:[]};if(lobby.members.length>=4)throw Error('이 던전의 정원 4명이 찼습니다.');
 lobby.members.push({id:p.id,name:p.name});lobbies.set(d.id,lobby);
 for(const m of lobby.members)say(online(m.id),`§e[던전 ${d.tier}] ${p.name} 참가 · ${lobby.members.length}/4명. 첫 참가자가 /rpg:dungeonstart 로 1~4명 출발.`);
 return lobby;
}
export function startDungeon(p){
 const lobby=lobbyOf(p.id);if(!lobby)throw Error('먼저 /rpg:dungeon <1~10> 으로 참가하세요.');if(lobby.members[0].id!==p.id)throw Error('대기실 첫 참가자만 시작할 수 있습니다.');
 const group=lobby.members.map(m=>online(m.id));
 if(!group.length||group.length>4||group.some(m=>!m||!isActiveNearbyPlayer(m,m.location,m.dimension.id,1)))throw Error('대기실 참가자 모두 접속·생존·서바이벌 상태여야 합니다.');
 for(const m of group)if(m.getDynamicProperty(RETURN_KEY)!==undefined||runOf(m.id)||state().outbox.some(o=>o.playerId===m.id))throw Error('참가자의 이전 던전 귀환·보상이 대기 중입니다.');
 const d=lobby.d;cleanMobs(d);const now=Date.now(),r={id:state().nextRun++,d,members:[...lobby.members],phase:'preparing',live:new Map(),normalSpawned:0,eliteSpawned:0,normalKilled:0,eliteKilled:0,startedAt:now,deadline:now+10000,nextNormalAt:now+DUNGEON.normalIntervalMs,nextEliteAt:now+DUNGEON.eliteIntervalMs,finishing:false};
 d.activeId=r.id;save();lobbies.delete(d.id);runs.set(d.id,r);
 try{
  for(let i=0;i<group.length;i++){const m=group[i];m.setDynamicProperty(RETURN_KEY,JSON.stringify({runId:r.id,dimId:m.dimension.id,location:m.location}));m.teleport({x:d.x+(i%2)*2-1,y:d.y+1,z:d.z-8+Math.floor(i/2)*2},{dimension:dimension(d),keepVelocity:false});}
  // Give the destination player chunks time to load before spawning entities.
  const begin=()=>{
   if(runs.get(d.id)!==r||r.finishing)return;
   try{
    if(expired(r))return;
    for(let i=0;i<DUNGEON.initialNormals;i++){spawnMob(r,'normal',r.normalSpawned);r.normalSpawned++;}
    const start=Date.now();r.phase='mobs';r.startedAt=start;r.deadline=start+DUNGEON.mobLimitMs;r.nextNormalAt=start+DUNGEON.normalIntervalMs;r.nextEliteAt=start+DUNGEON.eliteIntervalMs;
    for(const m of group)say(m,'§e[던전] 지금부터 일반 50마리·엘리트 5마리를 5분 안에 처치하세요.');
   }catch(error){
    for(const entry of r.live.values())try{entry.mob.remove();}catch{}r.live.clear();r.normalSpawned=0;
    if(String(error.name).includes('UnloadedChunk')&&Date.now()<r.deadline)system.runTimeout(begin,20);
    else finish(r,false,'몬스터 생성 오류로 중단했습니다.');
   }
  };
  system.runTimeout(begin,20);
 }catch(error){finish(r,false,'몬스터 생성 오류로 중단했습니다.');throw error;}
 return {runId:r.id,members:group.map(m=>m.id)};
}
export function soloDungeon(p,value){
 const tier=requireTier(value),lobby=lobbies.get(tier.id);
 if(lobby?.members.length&&!(lobby.members.length===1&&lobby.members[0].id===p.id))throw Error('이미 다른 플레이어가 대기 중입니다. 다른 난이도를 선택하거나 함께 참가하세요.');
 enterDungeon(p,value);return startDungeon(p);
}
function removeLobbyMember(id){const l=lobbyOf(id);if(!l)return false;l.members=l.members.filter(m=>m.id!==id);if(!l.members.length)lobbies.delete(l.d.id);else for(const m of l.members)say(online(m.id),`§7대기 인원 ${l.members.length}/4 · 시작 담당 ${l.members[0].name}`);return true;}
export function leaveDungeon(p){
 removeLobbyMember(p.id);const r=runOf(p.id);if(r){r.members=r.members.filter(m=>m.id!==p.id);if(!r.members.length)finish(r,false);}
 const back=returnPlayer(p);say(p,back?'§7던전 대기·진행을 종료했습니다.':'§7부활 후 원래 위치로 귀환합니다.');return back;
}
export function flushRewards(){
 for(const receipt of [...state().outbox]){const p=online(receipt.playerId);if(!p)continue;
  try{creditDungeonClear(p,receipt.runId,receipt.tier??1);state().outbox=state().outbox.filter(x=>x!==receipt);save();const result=claimDungeonLoot(p);if(result.pending)say(p,'§e가방 부족 보급품은 저장했습니다. /rpg:dungeonloot 로 받으세요.');}
  catch{say(p,'§c보상 저장·수령 대기 중입니다. /rpg:dungeonloot 로 재시도하세요.');}
 }
}
export function dungeonDeath(ev){
 const dead=ev.deadEntity;if(!dead)return;
 if(dead.typeId==='minecraft:player'){const p=online(dead.id);if(p&&(runOf(p.id)||lobbyOf(p.id)))leaveDungeon(p);return;}
 for(const r of runs.values()){
  const entry=r.live.get(dead.id);if(!entry)continue;if(expired(r))return;r.live.delete(dead.id);
  if(entry.kind==='boss'){if(r.phase==='boss'&&dead.id===r.bossId)finish(r,true);return;}
  if(entry.kind==='normal')r.normalKilled++;else r.eliteKilled++;
  r.nextNormalAt=Math.min(r.nextNormalAt,Date.now()+DUNGEON.reinforceDelayMs);
  try{spawnBoss(r);}catch(error){finish(r,false,'보스 생성에 실패했습니다.');throw error;}return;
 }
}
export function dungeonTick(){
 const job=builders.values().next().value;if(job)buildTick(job);
 const now=Date.now(),maintenance=system.currentTick-maintenanceTick>=20;if(maintenance)maintenanceTick=system.currentTick;
 for(const r of [...runs.values()]){
  if(expired(r,now))continue;
  if(maintenance){for(const m of [...r.members]){const p=online(m.id);if(!p){r.members=r.members.filter(x=>x!==m);continue;}if(!inside(p,r.d)||!isActiveNearbyPlayer(p,p.location,p.dimension.id,1))leaveDungeon(p);}
   if(!r.members.length&&!r.finishing)finish(r,false);}
  if(!r.finishing)try{spawnTick(r,now);}catch(error){finish(r,false,'몬스터 생성에 실패했습니다.');console.warn('[RPG dungeon] '+error);}
 }
}
export function recoverDungeons(){
 for(const r of runs.values())cleanMobs(r.d);runs.clear();lobbies.clear();builders.clear();db=undefined;
 for(const d of allRegistered()){if(d.activeId)cleanMobs(d);d.activeId=null;unloadBuildArea(d);}
 for(const d of state().dungeons)if(d.status!=='ready')queueBuilder(d,null);
 save();flushRewards();
}
export async function openDungeons(p){
 const current=runOf(p.id);if(current){await new ActionFormData().title('던전 진행').body(dungeonHudText(p)+'\n제한 초과 시 퇴장·클리어 보상 없음.').button('닫기').show(p);return;}
 const waiting=lobbyOf(p.id);
 if(waiting){const form=new ActionFormData().title('던전 대기실 · 난이도 '+waiting.d.tier).body(waiting.members.map((m,i)=>(i===0?'[시작 담당] ':'')+m.name).join('\n')+'\n원하는 인원 1~4명으로 출발할 수 있습니다.').button('출발').button('대기 취소').button('닫기');const reply=await form.show(p);try{if(!reply.canceled&&reply.selection===0)startDungeon(p);if(!reply.canceled&&reply.selection===1)leaveDungeon(p);}catch(error){say(p,'§c'+error.message);}return;}
 const list=listDungeons(),form=new ActionFormData().title('던전 · 난이도 1~10').body('각자 원하는 던전에 참가 · 최대 4명 · 혼자도 가능\n일반 50 + 엘리트 5: 5분\n모두 처치하면 보스 1: 등장부터 3분');
 for(const d of list)form.button(`${d.tier}. ${d.name} · ${d.status!=='ready'?'미생성/건설 중':d.busy?'전투 중':d.waiting+'/4 대기'}`);
 form.button('닫기');const selected=await form.show(p);if(selected.canceled||selected.selection==null||selected.selection>=10)return;
 const d=list[selected.selection],t=DUNGEON_TIERS[d.tier-1],reward=clearRewardForTier(d.tier);
 const choice=await new ActionFormData().title(`난이도 ${d.tier} · ${d.name}`).body(`일반 50마리 + 엘리트 5마리 → 보스 1마리\n일반·엘리트 5분 / 보스 3분\n적 HP ×${t.hpMultiplier} · 기본 근접 피해 ×${t.attackMultiplier.toFixed(2)}\n클리어 골드 ${reward.gold} · 촉매 4개(매 3회 +1)\n참가 버튼은 본인만 등록하며 파티원을 자동 이동시키지 않습니다.`).button('대기실 참가').button('혼자 바로 시작').button('닫기').show(p);
 try{if(!choice.canceled&&choice.selection===0)enterDungeon(p,d.tier);if(!choice.canceled&&choice.selection===1)soloDungeon(p,d.tier);}catch(error){say(p,'§c'+error.message);}
}
export function registerDungeons(){
 if(registered)return;registered=true;recoverDungeons();
 world.afterEvents.entityDie.subscribe(ev=>{try{dungeonDeath(ev);}catch(error){console.warn('[RPG dungeon death] '+error);}});
 world.afterEvents.playerLeave.subscribe(ev=>{removeLobbyMember(ev.playerId);const r=runOf(ev.playerId);if(r){r.members=r.members.filter(m=>m.id!==ev.playerId);if(!r.members.length)finish(r,false);}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{try{if(!runOf(ev.player.id))returnPlayer(ev.player);flushRewards();}catch(error){say(ev.player,'§c던전 귀환 대기: '+error.message);}},20));
 world.beforeEvents.explosion?.subscribe(ev=>ev.setImpactedBlocks(ev.getImpactedBlocks().filter(b=>!protectedBlock(b,b.dimension.id))));
 for(const name of ['playerBreakBlock','playerPlaceBlock'])world.beforeEvents[name]?.subscribe(ev=>{if(ev.block&&protectedBlock(ev.block,ev.block.dimension?.id??ev.player.dimension.id))ev.cancel=true;});
 system.runInterval(()=>{try{dungeonTick();}catch(error){console.warn('[RPG dungeon] '+error);}},1);
}
