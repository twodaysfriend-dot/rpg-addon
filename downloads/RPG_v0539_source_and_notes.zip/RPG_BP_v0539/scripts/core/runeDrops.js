import { world,ItemStack } from '@minecraft/server';
import { RUNES } from '../data/equipment.js';
import { isTrialTarget,TRIAL_BOSSES } from './jobTrials.js';
const ids=Object.keys(RUNES);
// RPG entities already use an exact weighted loot pool. Only vanilla enemies
// are handled here, leaving their original loot tables intact.
export function vanillaRuneChance(id){return id?.startsWith('minecraft:')&&isTrialTarget(id)?(TRIAL_BOSSES.has(id) ? 0.30 : 0.01):0;}
export function rollVanillaRune(id,random=Math.random){
  const chance=vanillaRuneChance(id);if(!chance)return undefined;
  const roll=random();if(!Number.isFinite(roll)||roll<0||roll>=1)throw Error('룬 드롭 난수 오류');
  if(roll>=chance)return undefined;
  const choice=random();if(!Number.isFinite(choice)||choice<0||choice>=1)throw Error('룬 종류 난수 오류');
  return 'rpg:rune_'+ids[Math.floor(choice*ids.length)];
}
export function registerRuneDrops(){
  world.afterEvents.entityDie.subscribe(ev=>{
    try{const e=ev.deadEntity,id=rollVanillaRune(e?.typeId);if(id)e.dimension.spawnItem(new ItemStack(id,1),e.location);}
    catch(error){console.warn('[RPG rune drop] '+String(error));}
  });
}
