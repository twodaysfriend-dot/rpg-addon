import { canUseSkill } from "../core/skillAccess.js";
import { world, system, EntityDamageCause } from "@minecraft/server";
import { SKILLS } from "../data/skills.js";
import { getJobId } from "../core/playerData.js";
import { areAllies } from "../core/social.js";
import { notify } from "../core/hud.js";
import { getTargets, headPos, norm3, dist3, isSolidAt, particle, sound, hurt, healthAlive } from "../core/util.js";
import { skillDamageFor } from "../core/stats.js";

const passiveHits = new Map();
const tripleBuff = new Map();
const marks = new Map();
const zones = new Map();
let started = false;
// v0.5.11 visual effects: all visual particles are separate from combat hit logic.
const FX = {
  slash: "rpg:dragon_crescent_slash",
  spark: "rpg:dragon_arcane_spark",
  rune: "rpg:dragon_domain_rune",
  impact: "rpg:dragon_crystal_impact",
  breath: "rpg:dragon_giant_breath",
};
function sparkle(dim, at, count=5, spread=0.7){
  const n=Math.max(1,count);
  for(let i=0;i<n;i++){
    const angle=i*2.39996323+system.currentTick*0.17;
    const r=spread*(0.35+(i%3)*0.32);
    particle(dim,FX.spark,{x:at.x+Math.cos(angle)*r,y:at.y+(i%4)*0.28,z:at.z+Math.sin(angle)*r});
  }
}
function dragonImpact(dim, at){
  particle(dim,FX.impact,at);
  sparkle(dim,at,7,1.2);
}
function dragonAura(dim, at, radius=1.6){
  particle(dim,FX.rune,{x:at.x,y:at.y+1,z:at.z});
  for(let i=0;i<10;i++){
    const a=i*2*Math.PI/10;
    particle(dim,FX.spark,{x:at.x+Math.cos(a)*radius,y:at.y+0.4+(i%4)*0.37,z:at.z+Math.sin(a)*radius});
  }
}

function isDragonKnight(player){
  return player?.typeId === "minecraft:player" && getJobId(player) === "dragon_knight";
}
function clearRuntime(playerId){
  passiveHits.delete(playerId);
  tripleBuff.delete(playerId);
  const running = activeSprints.get(playerId);
  if(running?.finish) running.finish();
}
function enemy(owner, target){
  return !!owner && !!target && target.id !== owner.id && healthAlive(target) && !areAllies(owner, target);
}
function nearbyUnits(source, center, radius){
  const out = [];
  try {
    for(const e of source.dimension.getEntities({ location: center, maxDistance: radius, excludeTypes:["minecraft:item","minecraft:xp_orb","minecraft:armor_stand"] })) {
      if (e.id === source.id || !healthAlive(e)) continue;
      out.push(e);
    }
  } catch {}
  return out;
}
function heal(entity, amount){
  try{
    const hp = entity.getComponent("minecraft:health");
    if(!hp || hp.currentValue <= 0) return;
    hp.setCurrentValue(Math.min(hp.effectiveMax, hp.currentValue + amount));
  }catch{}
}
function trueDamage(victim, attacker, amount){
  try{
    const hp = victim.getComponent("minecraft:health");
    if(!hp || hp.currentValue <= 0) return;
    hp.setCurrentValue(Math.max(0, hp.currentValue - skillDamageFor(attacker, amount, "physical")));
  }catch{}
}
function stun(entity, ticks){
  try{ entity.addEffect("slowness", ticks, { amplifier:255, showParticles:false }); }catch{}
  try{ entity.addEffect("weakness", ticks, { amplifier:255, showParticles:false }); }catch{}
  try{ entity.addEffect("mining_fatigue", ticks, { amplifier:255, showParticles:false }); }catch{}
}
function pullToward(entity, center, power=0.35){
  try{
    const dx = center.x - entity.location.x;
    const dz = center.z - entity.location.z;
    const len = Math.hypot(dx,dz) || 1;
    entity.applyImpulse({ x: dx/len * power, y: 0.08, z: dz/len * power });
  } catch {
    try {
      const dx = center.x - entity.location.x;
      const dz = center.z - entity.location.z;
      const len = Math.hypot(dx,dz) || 1;
      entity.applyKnockback(dx/len, dz/len, power, 0.08);
    } catch {}
  }
}
function throwLine(player, range, step, onPoint){
  const dim = player.dimension;
  const dir = norm3(player.getViewDirection());
  const eye = headPos(player);
  let prev = { x: eye.x + dir.x*0.3, y: eye.y + dir.y*0.3, z: eye.z + dir.z*0.3 };
  for(let t = 0.4; t <= range; t += step){
    const at = { x: eye.x + dir.x*t, y: eye.y + dir.y*t, z: eye.z + dir.z*t };
    const stop = onPoint(at, prev, dim, dir);
    if (stop) return stop;
    prev = at;
  }
  return undefined;
}
function dragonTripleStrike(player, job, def){
  tripleBuff.set(player.id, { left:3, until: system.currentTick + def.duration });
  sound(player.dimension, "random.orb", player.location, { volume: 0.8, pitch: 0.9 });
  dragonAura(player.dimension,player.location,1.45);
  particle(player.dimension,FX.slash,{x:player.location.x,y:player.location.y+1.15,z:player.location.z});
  notify(player, "§5삼조격: §f다음 3번의 기본 공격 강화 · 3타째 1초 기절");
  return true;
}
function dragonGaze(player, job, def){
  const dim = player.dimension;
  const hit = throwLine(player, def.range, 0.65, (at, prev) => {
    particle(dim, FX.spark, at);
    if(Math.floor((at.x+at.z)*3)%3===0) particle(dim,FX.slash,at);
    for(const e of getTargets(player, at, 1.3, 0.9)){
      if(!enemy(player,e)) continue;
      hurt(e, player, def.damage, "physical");
      marks.set(e.id, { until: system.currentTick + def.markDuration, ownerId: player.id });
      dragonImpact(dim,{x:e.location.x,y:e.location.y+1.15,z:e.location.z});
      sound(dim, "mob.enderdragon.shoot", e.location, { volume: 0.6, pitch: 1.1 });
      notify(player, "§d용의 시선: §f표식을 부여했습니다. 10초간 받는 피해 30% 증가");
      return { hit:true };
    }
    if (isSolidAt(dim, at)) return { hit:false };
    return undefined;
  });
  if(!hit) notify(player, "§7용의 시선: 적에게 맞지 않았습니다.");
  return true;
}
function dragonCharge(player, job, def){
  const dim = player.dimension;
  let landed = false;
  const result = throwLine(player, def.range, 0.55, (at, prev) => {
    particle(dim, FX.spark, at);
    if(Math.floor((at.x-at.z)*4)%5===0) particle(dim,FX.slash,at);
    // entity first: allies or enemies both trigger dash
    for(const e of nearbyUnits(player, at, 1.25)){
      if (e.id === player.id) continue;
      if (e.typeId === "minecraft:item" || e.typeId === "minecraft:xp_orb" || e.typeId === "minecraft:armor_stand") continue;
      if (!healthAlive(e)) continue;
      const tp = { x:e.location.x, y:e.location.y, z:e.location.z };
      try{ player.teleport(tp, { dimension: dim, facingLocation: { x:e.location.x, y:e.location.y + 1, z:e.location.z } }); }catch{}
      if (enemy(player,e)) hurt(e, player, def.damage, "physical");
      dragonImpact(dim,{x:e.location.x,y:e.location.y+1,z:e.location.z});
      sound(dim, "mob.endermen.portal", tp, { volume: 0.85, pitch: 1.1 });
      landed = true;
      return { stop:true };
    }
    if (isSolidAt(dim, at)) {
      try { player.teleport(prev, { dimension: dim, facingLocation: at }); } catch {}
      sound(dim, "mob.endermen.portal", prev, { volume: 0.85, pitch: 1.1 });
      dragonImpact(dim,{x:prev.x,y:prev.y+1,z:prev.z});
      landed = true;
      return { stop:true };
    }
    return undefined;
  });
  if(!landed) notify(player, "§7무쌍돌격: 닿은 대상이나 지점이 없어 돌진하지 않았습니다.");
  return true;
}
function dragonDomain(player, job, def){
  const center = { x:player.location.x, y:player.location.y, z:player.location.z };
  const zoneId = `${player.id}:${system.currentTick}`;
  zones.set(zoneId, { ownerId:player.id, center, radius:def.radius, until:system.currentTick + def.duration, dimId:player.dimension.id, buffed:new Set() });
  sound(player.dimension, "mob.enderdragon.growl", center, { volume: 0.65, pitch: 0.9 });
  dragonAura(player.dimension,center,2.5);
  particle(player.dimension,FX.impact,{x:center.x,y:center.y+1.2,z:center.z});
  for(let i=0;i<28;i++){
    const a=i*Math.PI*2/28;
    const r=def.radius;
    particle(player.dimension,i%4===0?FX.rune:FX.spark,{x:center.x+Math.cos(a)*r,y:center.y+0.2+(i%4)*0.23,z:center.z+Math.sin(a)*r});
  }
  for(const e of getTargets(player, { x:center.x, y:center.y + 1, z:center.z }, def.radius + 1, 0.9)){
    if(!enemy(player,e)) continue;
    hurt(e, player, def.entryDamage, "physical");
    pullToward(e, center, 0.45);
  }
  notify(player, "§5현월수룡: §f10초 영역 전개 · 외부 원거리 무효 · 자동 요격 시작");
  return true;
}

// 용의 질주: 조준 중인 수평 방향으로 5초 동안 매 틱 강제 전진한다.
// 21블록/초 = 1.05블록/틱 (20TPS). 같은 대상을 한 번만 타격하고,
// n번째로 충돌한 적은 14 * (1.5 ** (n-1)) 기본 물리 피해를 받는다.
const activeSprints = new Map();
const SPRINT_PARTICLE = "rpg:dragon_arcane_spark";

function dragonSprint(player, job, def){
  if(!canUseSkill(player,"dragon_sprint",["dragon_knight"])) return false;
  if(activeSprints.has(player.id)){
    notify(player, "§7이미 용의 질주를 사용하고 있습니다.");
    return false;
  }
  const view = player.getViewDirection();
  const horizontal = Math.hypot(view.x, view.z);
  if(horizontal < 0.001){
    notify(player, "§7질주 방향을 확인할 수 없습니다.");
    return false;
  }
  const dir = { x:view.x / horizontal, z:view.z / horizontal };
  const dimension = player.dimension;
  const heading = player.getRotation();
  const stepDistance = (def.speed ?? 21) / 20;
  const duration = def.duration ?? 100;
  const touched = new Set();
  const state = { task:undefined, started:system.currentTick, dimensionId:dimension.id, touched, position:{...player.location} };
  activeSprints.set(player.id, state);
  sound(dimension, "mob.enderdragon.growl", player.location, { volume:0.55, pitch:1.25 });
  dragonAura(dimension,player.location,1.8);
  notify(player, "§5용의 질주! §f5초 동안 전방 21블록/초 · 새 적마다 피해 1.5배");

  const finish = (reason) => {
    if(activeSprints.get(player.id) !== state) return;
    activeSprints.delete(player.id);
    if(state.task !== undefined) system.clearRun(state.task);
    try{
      if(reason === "blocked") notify(player, "§7용의 질주: 전방 장애물에서 정지했습니다.");
      else if(reason === "complete") notify(player, `§5용의 질주 종료 §7(적 ${touched.size}명 타격)`);
    }catch{}
  };
  state.finish = finish;

  // 1틱 이동을 0.35블록 정도의 짧은 구간으로 나눠 얇은 벽/작은 적을 놓치지 않는다.
  const substeps = Math.ceil(stepDistance / 0.35);
  const oneStep = stepDistance / substeps;
  state.task = system.runInterval(() => {
    try {
      if(activeSprints.get(player.id) !== state) { system.clearRun(state.task); return; }
      if(!player.isValid || !canUseSkill(player,"dragon_sprint",["dragon_knight"]) || player.dimension.id !== state.dimensionId){finish();return;}
      if(system.currentTick - state.started > duration){finish("complete");return;}
      for(let i=0; i<substeps; i++){
        // Maintain an anchored path so normal player input cannot alter the 21-block/s speed.
        const old = state.position;
        const next = { x:old.x + dir.x*oneStep, y:old.y, z:old.z + dir.z*oneStep };
        // 바닥·지형 종류·절대 Y 제한 없이 이동하고 벽 충돌만 검사합니다.
        if(isSolidAt(dimension, {x:next.x,y:next.y+0.18,z:next.z}) ||
           isSolidAt(dimension, {x:next.x,y:next.y+1.65,z:next.z})){
          finish("blocked");return;
        }
        // 1.05 blocks/tick is implemented without giving a Speed status effect.
        // This avoids unnecessary FOV changes and preserves camera control.
        try{
          player.teleport(next, {dimension, rotation:heading, keepVelocity:false, checkForBlocks:true});
          state.position = next;
        }catch{
          finish("blocked");return;
        }
        // Detect collision along the swept path and hit each enemy once per use.
        const collisions = getTargets(player,
          {x:next.x,y:next.y+0.9,z:next.z}, def.hitRadius ?? 1.35, 0.9)
          .filter(e => !touched.has(e.id) && enemy(player,e));
        collisions.sort((a,b) => {
          const aa=a.location, bb=b.location;
          const da=(aa.x-old.x)*dir.x + (aa.z-old.z)*dir.z;
          const db=(bb.x-old.x)*dir.x + (bb.z-old.z)*dir.z;
          return da-db;
        });
        for(const target of collisions){
          if(touched.has(target.id)) continue;
          touched.add(target.id);
          const nth=touched.size;
          const damage=(def.damage ?? 14) * Math.pow(def.multiplier ?? 1.5, nth-1);
          // Override damage cause avoids incorrectly counting this skill as a basic attack.
          try{
            target.applyDamage(skillDamageFor(player, damage, "physical"), {
              cause:EntityDamageCause.override, damagingEntity:player,
            });
          }catch{}
          dragonImpact(dimension,{
            x:target.location.x,y:target.location.y+1,z:target.location.z
          });
          sound(dimension, "random.anvil_land", target.location, {volume:0.4,pitch:1.35});
        }
        if(i === substeps-1){
          particle(dimension,SPRINT_PARTICLE, {x:next.x,y:next.y+0.9,z:next.z});
           particle(dimension,FX.slash,{x:next.x-dir.x*0.4,y:next.y+1.0,z:next.z-dir.z*0.4});
           if((system.currentTick%3)===0) sparkle(dimension,{x:next.x,y:next.y+0.5,z:next.z},3,0.65);
        }
      }
      if(system.currentTick - state.started >= duration){finish("complete");}
    }catch{finish("blocked");}
  },1);
  return true;
}


// 용의 브레스: 실제 충돌 판정을 가진 플레이어 키 크기의 거대한 용염탄.
// 기존 5개 용기사 스킬은 그대로 유지하며 별도 6번째 스킬로 배운다.
function dragonBreath(player, job, def){
  if(!canUseSkill(player,"dragon_breath",["dragon_knight"])) return false;
  const dim=player.dimension, dimId=dim.id;
  const dir=norm3(player.getViewDirection()), eye=headPos(player);
  const origin={x:eye.x+dir.x*1.05,y:eye.y+dir.y*1.05,z:eye.z+dir.z*1.05};
  const speed=def.speed??1.45, range=def.range??28;
  let traveled=0;
  sound(dim,"mob.enderdragon.shoot",player.location,{volume:0.85,pitch:0.8});
  dragonAura(dim,player.location,1.8);
  const timer=system.runInterval(()=>{
    try{
      if(!player.isValid || player.dimension.id!==dimId || !canUseSkill(player,"dragon_breath",["dragon_knight"])){
        system.clearRun(timer);return;
      }
      let last=null;
      for(let sub=0;sub<4;sub++){
        traveled+=speed/4;
        if(traveled>range){system.clearRun(timer);return;}
        const at={x:origin.x+dir.x*traveled,y:origin.y+dir.y*traveled,z:origin.z+dir.z*traveled};
        last=at;
        if(isSolidAt(dim,at)){
          dragonImpact(dim,at);
          sound(dim,"random.explode",at,{volume:0.5,pitch:1.15});
          system.clearRun(timer);return;
        }
        const targets=getTargets(player,at,def.hitRadius??1.3,0.9);
        const victim=targets.find(t=>enemy(player,t));
        if(victim){
          hurt(victim,player,def.damage??24,"magic");
          try{victim.setOnFire(def.burnSeconds??4,true);}catch{}
          dragonImpact(dim,{x:victim.location.x,y:victim.location.y+1.0,z:victim.location.z});
          sound(dim,"random.explode",at,{volume:0.65,pitch:1.0});
          system.clearRun(timer);return;
        }
      }
      if(last){
        particle(dim,FX.breath,last);
        particle(dim,FX.spark,{x:last.x-dir.x*0.55,y:last.y-dir.y*0.55,z:last.z-dir.z*0.55});
        if(system.currentTick%2===0) sparkle(dim,last,3,0.95);
      }
    }catch{system.clearRun(timer);}
  },1);
  return true;
}

export const RUNNERS = {
  dragon_breath: dragonBreath,
  dragon_sprint: dragonSprint,
  dragon_triple_strike: dragonTripleStrike,
  dragon_gaze: dragonGaze,
  dragon_charge: dragonCharge,
  dragon_domain: dragonDomain,
};

export function registerDragon(){
  if(started) return;
  started = true;
  world.afterEvents.playerLeave.subscribe(ev => clearRuntime(ev.playerId));

  // mark amplification + domain projectile immunity
  try{
    world.beforeEvents.entityHurt?.subscribe(ev => {
      try{
        const victim = ev.hurtEntity;
        const now = system.currentTick;
        const mark = marks.get(victim.id);
        if(mark){
          if(now >= mark.until) marks.delete(victim.id);
          else ev.damage *= 1.3;
        }

        if(victim?.typeId === "minecraft:player"){
          for(const [zoneId, zone] of zones){
            if(now >= zone.until) { zones.delete(zoneId); continue; }
            if(victim.dimension.id !== zone.dimId) continue;
            const inside = dist3(victim.location, zone.center) <= zone.radius + 0.1;
            if(!inside) continue;
            const owner = world.getAllPlayers().find(p => p.id === zone.ownerId);
            if(!owner || (!areAllies(owner, victim) && owner.id !== victim.id)) continue;
            const src = ev.damageSource;
            let attacker = src?.damagingEntity;
            if(!attacker || attacker.typeId !== "minecraft:player") attacker = src?.damagingProjectile?.getComponent("minecraft:projectile")?.owner ?? attacker;
            const projectile = src?.cause === EntityDamageCause.projectile || !!src?.damagingProjectile;
            if(!projectile || !attacker || attacker.dimension?.id !== zone.dimId || areAllies(attacker, victim)) continue;
            if(dist3(attacker.location, zone.center) > zone.radius + 0.2){
              ev.cancel = true;
              particle(victim.dimension, "minecraft:crit_particle", { x:victim.location.x, y:victim.location.y + 1.2, z:victim.location.z });
              sound(victim.dimension, "random.shield.block", victim.location, { volume: 0.6, pitch: 1.2 });
              break;
            }
          }
        }
      }catch{}
    });
  }catch{}

  // passive and triple-strike follow-up
  world.afterEvents.entityHurt.subscribe(ev => {
    try{
      const attacker = ev.damageSource?.damagingEntity;
      const victim = ev.hurtEntity;
      if(!canUseSkill(attacker,"dragon_triple_strike",["dragon_knight"]) || !victim || !enemy(attacker, victim)) return;
      if(ev.damageSource?.cause !== EntityDamageCause.entityAttack) return;
      const now = system.currentTick;
      const triple = tripleBuff.get(attacker.id);
      if(triple){
        if(now >= triple.until) tripleBuff.delete(attacker.id);
        else {
          trueDamage(victim, attacker, SKILLS.dragon_triple_strike.bonusDamage);
          triple.left -= 1;
           dragonImpact(victim.dimension,{x:victim.location.x,y:victim.location.y+1,z:victim.location.z});
          if(triple.left <= 0){
            stun(victim, SKILLS.dragon_triple_strike.thirdStun);
            tripleBuff.delete(attacker.id);
            notify(attacker, "§5삼조격: §f3타 적중 · 대상 1초 기절");
          } else {
            tripleBuff.set(attacker.id, triple);
            notify(attacker, `§5삼조격: §f강화 타격 ${4 - triple.left}/3`);
          }
        }
      }
      if(!isDragonKnight(attacker)) return;
      let count = (passiveHits.get(attacker.id) ?? 0) + 1;
      if(count >= 3){
        count = 0;
        trueDamage(victim, attacker, 10);
        heal(attacker, 6);
        particle(attacker.dimension, "minecraft:heart_particle", { x:attacker.location.x, y:attacker.location.y + 1.4, z:attacker.location.z });
        sparkle(attacker.dimension,{x:attacker.location.x,y:attacker.location.y+0.9,z:attacker.location.z},8,1.0);
        sound(attacker.dimension, "random.orb", attacker.location, { volume: 0.6, pitch: 1.35 });
        notify(attacker, "§d용기사 패시브: §f3타 추가 물리 피해 + 체력 3칸 회복");
      }
      passiveHits.set(attacker.id, count);
    }catch{}
  });

  // zone ally buff + visuals
  system.runInterval(() => {
    const now = system.currentTick;
    for(const [id, zone] of zones){
      if(now >= zone.until){ zones.delete(id); continue; }
      const owner = world.getAllPlayers().find(p => p.id === zone.ownerId);
      if(!owner || owner.dimension.id !== zone.dimId){ zones.delete(id); continue; }
      const dim = owner.dimension;
      for(let i=0;i<12;i++){
        const a = (Math.PI * 2 * i) / 12 + now * 0.08;
        particle(dim,(i%3===0?FX.rune:FX.spark), {
          x: zone.center.x + Math.cos(a) * zone.radius,
          y: zone.center.y + 0.35 + ((i % 3) * 0.35),
          z: zone.center.z + Math.sin(a) * zone.radius,
        });
        if(i%4===0)particle(dim,FX.spark,{
          x:zone.center.x+Math.cos(a)*zone.radius,y:zone.center.y+2.3,z:zone.center.z+Math.sin(a)*zone.radius
        });
      }
      for(const p of world.getAllPlayers()){
        try{
          if(p.dimension.id !== zone.dimId) continue;
          const allied = p.id === owner.id || areAllies(owner, p);
          if(!allied) continue;
          if(dist3(p.location, zone.center) > zone.radius + 0.1) continue;
          if(zone.buffed.has(p.id)) continue;
          zone.buffed.add(p.id);
          p.addEffect("resistance", SKILLS.dragon_domain.allyBuffTicks, { amplifier: 4, showParticles:false });
          sound(dim, "random.levelup", p.location, { volume: 0.45, pitch: 1.4 });
        }catch{}
      }
    }
  }, 5);

  // zone auto interception every second
  system.runInterval(() => {
    const now = system.currentTick;
    for(const [id, zone] of zones){
      if(now >= zone.until) { zones.delete(id); continue; }
      const owner = world.getAllPlayers().find(p => p.id === zone.ownerId);
      if(!owner || owner.dimension.id !== zone.dimId) continue;
      const center = { x:zone.center.x, y:zone.center.y + 1, z:zone.center.z };
      for(const target of getTargets(owner, center, zone.radius, 0.9)){
        if(!enemy(owner,target)) continue;
        hurt(target, owner, SKILLS.dragon_domain.pulseDamage, "physical");
        pullToward(target, zone.center, 0.18);
        particle(owner.dimension,FX.slash,{x:target.location.x,y:target.location.y+1,z:target.location.z});
        sparkle(owner.dimension,{x:target.location.x,y:target.location.y+1,z:target.location.z},4,0.75);
      }
    }
  }, 20);
}
