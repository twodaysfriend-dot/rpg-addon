import { areAllies } from "../core/social.js";
import { world, system, EntityDamageCause } from "@minecraft/server";
import { CONFIG } from "../config.js";
import { getJobId, getSkills } from "../core/playerData.js";
import { getLastHit } from "../core/tracking.js";
import { getTargets, healthAlive, flatDir, firstTargetInView, headPos, isSolidAt, particle, sound, hurt, dist3, norm3 } from "../core/util.js";
import { notify } from "../core/hud.js";

// Assassin and Shadow Assassin. Damage values and durations live in data/skills.js.
const SLASH = "rpg:assassin_slash";
const SHADOW = "rpg:shadow_trace";
const stealth = new Map();          // playerId -> active until the next successful melee hit
const marked = new Map();           // entityId -> { entity, until }
const healLocked = new Map();       // entityId -> { entity, until, cap } (no healing for Pierce)
const assassinating = new Set();    // playerId -> shadow assassination active
let started = false;

function alive(e) { try { return !!e?.isValid && healthAlive(e); } catch { return false; } }
function ally(p, e) {
  if (areAllies(p,e)) return true;
  if (e?.id === p.id) return true;
  if (e?.typeId !== "minecraft:player") return false;
  if (!CONFIG.pvp) return true;
  const tag = p.getTags().find(t => t.startsWith("rpg_team_"));
  return !!tag && e.getTags().includes(tag);
}
function enemy(p, e) { return alive(e) && !ally(p, e); }
function safe(dim, p) {
  return !isSolidAt(dim, {x:p.x,y:p.y+0.1,z:p.z}) &&
    !isSolidAt(dim, {x:p.x,y:p.y+1.45,z:p.z});
}
function spot(dim, p) {
  for (const dy of [0,1,-1,2,-2]) {
    const at={x:p.x,y:p.y+dy,z:p.z};
    if (safe(dim,at)) return at;
  }
  return null;
}
function line(dim, a, b, fx, step=.45) {
  const length=dist3(a,b);
  const n=Math.min(36,Math.max(1,Math.ceil(length/step)));
  for(let i=0;i<=n;i++) {
    const t=i/n;
    particle(dim,fx,{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t});
  }
}
function circle(dim, c, radius, count, fx) {
  for(let i=0;i<count;i++){
    const a=Math.PI*2*i/count;
    particle(dim,fx,{x:c.x+Math.cos(a)*radius,y:c.y,z:c.z+Math.sin(a)*radius});
  }
}
function viewEnemy(p, range) {
  const first=firstTargetInView(p,range);
  if (enemy(p,first)) return first;
  const last=getLastHit(p);
  if (!enemy(p,last)) return null;
  try {
    if(last.dimension.id!==p.dimension.id || dist3(last.location,p.location)>range) return null;
    const dir=flatDir(p),dx=last.location.x-p.location.x,dz=last.location.z-p.location.z;
    const len=Math.hypot(dx,dz)||1;
    return (dx*dir.x+dz*dir.z)/len > .3 ? last : null;
  }catch {return null;}
}
function effect(e,id,ticks,amp=0) {
  try { e.addEffect(id,ticks,{amplifier:amp,showParticles:false}); } catch {}
}
function clearEffect(e,id) {try{e.removeEffect(id);}catch{}}

// 도착 지점의 몸 공간만 확인하며 바닥이나 안전 지형은 요구하지 않습니다.
function spin(p, job, def) {
  const dim=p.dimension, origin={...p.location}, dir=flatDir(p);
  const destination={x:origin.x+dir.x*def.teleport, y:origin.y, z:origin.z+dir.z*def.teleport};
  const landing=spot(dim,destination);
  if(!landing){notify(p,"§7회전베기: 도착 위치가 블록으로 막혀 있습니다.");return false;}
  try{p.teleport(landing,{dimension:dim,keepVelocity:false});}
  catch {notify(p,"§7회전베기 순간이동에 실패했습니다.");return false;}
  line(dim,{x:origin.x,y:origin.y+1,z:origin.z},{x:landing.x,y:landing.y+1,z:landing.z},SHADOW,.55);
  const at={x:landing.x,y:landing.y+1,z:landing.z};
  circle(dim,at,def.radius,18,SLASH);
  const victims=getTargets(p,landing,def.radius).filter(e=>enemy(p,e));
  for(const e of victims){
    hurt(e,p,def.damage);
    particle(dim,SLASH,{x:e.location.x,y:e.location.y+1,z:e.location.z});
  }
  sound(dim,"mob.player.attack.sweep",landing,{volume:1,pitch:1.1});
  return true;
}

// Sharp violet slash: travels through air, stops on blocks or the first enemy.
function daggerWave(p,job,def) {
  const dim=p.dimension, from=headPos(p), dir=norm3(p.getViewDirection());
  let traveled=0;
  const interval=system.runInterval(()=>{
    try{
      if(!p.isValid || traveled>=def.range){system.clearRun(interval);return;}
      for(let k=0;k<3;k++){
        traveled+=def.speed/3;
        const at={x:from.x+dir.x*traveled,y:from.y+dir.y*traveled,z:from.z+dir.z*traveled};
        if(isSolidAt(dim,at)){system.clearRun(interval);return;}
        particle(dim,SLASH,at);
        if(k===0)particle(dim,SHADOW,{x:at.x,y:at.y+.12,z:at.z});
        const victim=getTargets(p,at,def.hitRadius,.9).find(e=>enemy(p,e));
        if(!victim)continue;
        hurt(victim,p,def.damage);
        effect(victim,"slowness",def.slowTicks,2); // 구속 III
        circle(dim,{x:victim.location.x,y:victim.location.y+1,z:victim.location.z},.6,10,SLASH);
        sound(dim,"random.anvil_land",victim.location,{volume:.5,pitch:1.8});
        system.clearRun(interval);return;
      }
    }catch{system.clearRun(interval);}
  },1);
  sound(dim,"mob.player.attack.sweep",p.location,{volume:.65,pitch:1.6});
  return true;
}

function pierce(p,job,def) {
  const victim=viewEnemy(p,def.range);
  if(!victim){notify(p,"§7피어스: 전방에 찌를 적이 없습니다.");return false;}
  const from=headPos(p);
  hurt(victim,p,def.damage);
  const health=victim.getComponent("minecraft:health");
  if(health && health.currentValue>0){
    healLocked.set(victim.id,{
      entity:victim, owner:p, until:system.currentTick+def.noHealTicks,
      cap:health.currentValue,
    });
  }
  effect(victim,"weakness",20,0);
  line(p.dimension,from,{x:victim.location.x,y:victim.location.y+1,z:victim.location.z},SLASH,.32);
  sound(p.dimension,"mob.player.attack.strong",victim.location,{volume:.8,pitch:1.4});
  notify(p,"§5피어스: §f10초간 회복 차단");
  return true;
}

export function assassinStealthIsActive(p){return stealth.has(p.id);}
export function stopAssassinStealth(p) {
  if(!stealth.delete(p.id))return false;
  clearEffect(p,"invisibility");
  notify(p,"§7그림자 은신 해제");
  return true;
}
function shadowStealth(p,job,def) {
  const target=viewEnemy(p,def.range);
  if(!target){notify(p,"§7은신: 그림자에 숨을 적이 전방에 없습니다.");return false;}
  // Step into the target's shadow if there is a safe spot behind it.
  const dim=p.dimension, dir=flatDir(p), from={...p.location};
  const dest={x:target.location.x-dir.x*1.25,y:target.location.y,z:target.location.z-dir.z*1.25};
  const landing=spot(dim,dest);
  if(landing){try{p.teleport(landing,{dimension:dim,keepVelocity:false});}catch{}}
  stealth.set(p.id,true);
  effect(p,"invisibility",35,0);
  line(dim,{x:from.x,y:from.y+1,z:from.z},{x:p.location.x,y:p.location.y+1,z:p.location.z},SHADOW,.55);
  notify(p,"§8그림자 은신: §f다음 근접 공격 피해 3배");
  return true;
}
function mark(p,job,def) {
  const target=viewEnemy(p,def.range);
  if(!target){notify(p,"§7표식: 전방에 표식을 남길 적이 없습니다.");return false;}
  marked.set(target.id,{entity:target,owner:p,until:system.currentTick+def.duration});
  circle(p.dimension,{x:target.location.x,y:target.location.y+1,z:target.location.z},.75,12,SHADOW);
  sound(p.dimension,"mob.endermen.portal",target.location,{volume:.5,pitch:1.5});
  notify(p,"§5표식: §f10초간 받는 피해 +30%");
  return true;
}

// The target must still have a mark when the ultimate is cast.
function assassinate(p,job,def) {
  if(assassinating.has(p.id))return false;
  const candidates=[];
  for(const s of marked.values()){
    try{
      if(system.currentTick<s.until && enemy(p,s.entity) && s.entity.dimension.id===p.dimension.id && dist3(s.entity.location,p.location)<=def.range)
        candidates.push(s.entity);
    }catch{}
  }
  if(!candidates.length){notify(p,"§7그림자 암살: 사거리 안에 표식이 붙은 적이 없습니다.");return false;}
  const last=getLastHit(p);
  const victim=candidates.find(e=>e.id===last?.id)??candidates.sort((a,b)=>dist3(a.location,p.location)-dist3(b.location,p.location))[0];
  const dim=p.dimension, origin={...p.location};
  assassinating.add(p.id);
  stealth.delete(p.id);
  effect(p,"invisibility",def.delay+15);
  effect(p,"resistance",def.delay+15,255);
  effect(p,"slowness",def.delay+15,255);
  sound(dim,"mob.endermen.portal",victim.location,{volume:.8,pitch:.5});
  let elapsed=0;
  const finish=(success)=>{
    system.clearRun(interval);
    assassinating.delete(p.id);
    clearEffect(p,"invisibility");
    clearEffect(p,"slowness");
    clearEffect(p,"resistance");
    try{
      if(p.isValid && p.dimension.id===dim.id){
        const dir=flatDir(p),vl=victim?.location??origin;
        const escape={x:vl.x-dir.x*2,y:vl.y,z:vl.z-dir.z*2};
        const safeEscape=spot(dim,escape)??spot(dim,origin);
        if(safeEscape)p.teleport(safeEscape,{dimension:dim,keepVelocity:false});
      }
    }catch{}
    if(success)notify(p,"§5그림자 암살 적중!");
  };
  const interval=system.runInterval(()=>{
    try{
      if(!p.isValid || !enemy(p,victim) || victim.dimension.id!==dim.id){finish(false);return;}
      if(elapsed<def.delay){
        p.teleport({...victim.location},{dimension:dim,keepVelocity:false});
        if(elapsed%8===0)particle(dim,SHADOW,{x:victim.location.x,y:victim.location.y+1,z:victim.location.z});
        elapsed+=2;
        return;
      }
      hurt(victim,p,def.damage);
      circle(dim,{x:victim.location.x,y:victim.location.y+1,z:victim.location.z},1.1,18,SLASH);
      sound(dim,"random.explode",victim.location,{volume:.6,pitch:.9});
      finish(true);
    }catch{finish(false);}
  },2);
  return true;
}

export const RUNNERS={
  assassin_spin:spin,
  assassin_dagger_wave:daggerWave,
  assassin_pierce:pierce,
  assassin_stealth:shadowStealth,
  assassin_mark:mark,
  shadow_assassinate:assassinate,
};

export function registerAssassin(){
  if(started)return;
  started=true;
  // Extra damage is calculated from the actual received damage. Health is adjusted
  // directly to avoid recursively triggering entityHurt when both buffs apply.
  world.afterEvents.entityHurt.subscribe(ev=>{
    try{
      const e=ev.hurtEntity;
      if(!e?.isValid)return;
      const markState=marked.get(e.id);
      const markedNow=!!markState && system.currentTick<markState.until && !areAllies(markState.owner,e);
      const attacker=ev.damageSource?.damagingEntity;
      const melee=ev.damageSource?.cause===EntityDamageCause.entityAttack;
      const stealthNow=attacker?.typeId==="minecraft:player" &&
        (getJobId(attacker)==="shadow_assassin" || (getJobId(attacker)==="chameleon" && getSkills(attacker).includes("assassin_stealth"))) && stealth.has(attacker.id) &&
        melee && enemy(attacker,e);
      const factor=(markedNow?1.3:1)*(stealthNow?3:1);
      if(stealthNow){
        stealth.delete(attacker.id);
        clearEffect(attacker,"invisibility");
        notify(attacker,"§5기습 성공! §f이번 근접 피해 3배");
      }
      if(factor>1 && typeof ev.damage==="number" && ev.damage>0){
        const health=e.getComponent("minecraft:health");
        if(health && health.currentValue>0){
          health.setCurrentValue(Math.max(0,health.currentValue-ev.damage*(factor-1)));
        }
      }
      // Damage lowers the cap while Pierce's anti-healing state is active.
      const lock=healLocked.get(e.id);
      if(lock && system.currentTick<lock.until && !areAllies(lock.owner,e)){
        const hp=e.getComponent("minecraft:health")?.currentValue;
        if(typeof hp==="number" && hp>0)lock.cap=Math.min(lock.cap,hp);
      }
    }catch{}
  });
  system.runInterval(()=>{
    const now=system.currentTick;
    for(const [id,s] of marked){
      if(now>=s.until || !alive(s.entity) || areAllies(s.owner,s.entity)){marked.delete(id);continue;}
      if(now%20===0){
        const at=s.entity.location;
        particle(s.entity.dimension,SHADOW,{x:at.x,y:at.y+1.5,z:at.z});
      }
    }
    for(const [id,s] of healLocked){
      if(now>=s.until || !alive(s.entity) || areAllies(s.owner,s.entity)){healLocked.delete(id);continue;}
      try{
        const hp=s.entity.getComponent("minecraft:health");
        if(!hp)continue;
        if(hp.currentValue>s.cap+0.001)hp.setCurrentValue(s.cap);
        else s.cap=Math.min(s.cap,hp.currentValue);
      }catch{healLocked.delete(id);}
    }
    for(const id of stealth.keys()){
      const p=world.getAllPlayers().find(e=>e.id===id);
      if(!p || (getJobId(p)!=="shadow_assassin" && !(getJobId(p)==="chameleon" && getSkills(p).includes("assassin_stealth"))) || !alive(p)){stealth.delete(id);continue;}
      effect(p,"invisibility",35);
    }
  },1);
  world.afterEvents.playerLeave.subscribe(ev=>{stealth.delete(ev.playerId);assassinating.delete(ev.playerId);});
}
