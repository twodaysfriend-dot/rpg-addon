import { system } from "@minecraft/server";
import { areAllies } from "../core/social.js";
import { CONFIG } from "../config.js";
import {
  getTargets, hurt as hurtBase, knockback, burn, slow, push, particle, sound, dist3, norm3, headPos,
  aimPoint, firstTargetInView, isSolidAt, healthAlive,
} from "../core/util.js";
import { notify } from "../core/hud.js";

// 마법으로 가장 최근에 맞춘 대상 (메테오가 이 대상에게 날아갑니다)
const lastMagicHit = new Map(); // playerId -> 대상 엔티티

function hurt(target, source, amount) {
  const ok = hurtBase(target, source, amount, "magic");
  if (ok && source?.id) lastMagicHit.set(source.id, target);
  return ok;
}

// 가장 최근에 마법으로 맞춘 대상. 죽었거나 다른 차원이거나 maxDist 보다 멀면 없는 것으로 봅니다.
function lastMagicTarget(player, maxDist) {
  const t = lastMagicHit.get(player.id);
  if (!t) return undefined;
  try {
    if (!healthAlive(t) || areAllies(player, t) || t.dimension.id !== player.dimension.id) return undefined;
    if (dist3(t.location, player.location) > maxDist) return undefined;
    return t;
  } catch {
    return undefined;
  }
}

// 모든 불 이펙트는 '파티클'일 뿐이라 바닥/블록에는 절대 불이 붙지 않습니다.
// (createExplosion 도 쓰지 않고, 피해는 스킬 데이터의 수치만큼만 직접 줍니다.)
const FX = {
  fire: ["rpg:mage_flame"],
  ghast: ["rpg:mage_fireball", "rpg:mage_flame"],
  thunder: ["rpg:mage_lightning"],
  ice: ["rpg:mage_ice"],
  dark: ["rpg:mage_gravity"],
  blue: ["rpg:sage_sphere"],
};

function fx(dim, ids, pos) {
  for (const id of ids) particle(dim, id, pos);
}

function ringFx(dim, center, r, ids, dy = 0.2, n = 24) {
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    fx(dim, ids, { x: center.x + Math.cos(a) * r, y: center.y + dy, z: center.z + Math.sin(a) * r });
  }
}

// 졸트라크 소환 마법진과 동일한 4.4×4.4 크기의 대상 표식.
// 기존 rpg:zoltraak_circle 텍스처/스케일을 재사용하고, 지면에는 반지름 2.2칸의 원형 표식을 그립니다.
const ZOLTRAAK_CIRCLE_DIAMETER = 4.4;
function targetRangeCircleFx(dim, feet, accentIds = ["rpg:magic_spark"]) {
  particle(dim, "rpg:zoltraak_circle", { x: feet.x, y: feet.y + 1.0, z: feet.z });
  ringFx(dim, feet, ZOLTRAAK_CIRCLE_DIAMETER / 2, accentIds, 0.12, 40);
}

function boomFx(dim, pos, big = false) {
  particle(dim, "rpg:magic_impact", { x: pos.x, y: pos.y + 0.35, z: pos.z });
  particle(dim, "minecraft:huge_explosion_emitter", pos);
  if (big) {
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      particle(dim, "minecraft:large_explosion", {
        x: pos.x + Math.cos(a) * 3, y: pos.y + 0.5, z: pos.z + Math.sin(a) * 3,
      });
    }
  }
  sound(dim, "random.explode", pos, { volume: big ? 1.4 : 0.8, pitch: big ? 0.8 : 1.1 });
}

// 진짜 벼락(minecraft:lightning_bolt)을 칩니다. 벼락 주변의 플레이어(시전자 포함)는
// 벼락 피해/화상을 안 받도록 잠깐 보호합니다. (PvP 가 켜져 있으면 시전자만 보호)
function spawnRealBolt(player, pos) {
  const dim = player.dimension;
  try {
    const near = new Map();
    near.set(player.id, player);
    // 실제 벼락은 독립 엔티티로 발생하므로 근처 길드·파티 아군에게
    // 번개 피해/화상이 전달되지 않도록 PvP가 켜져도 보호 효과를 적용합니다.
    for (const p of dim.getPlayers({
      location: pos, maxDistance: CONFIG.lightning.protectRadius,
    })) {
      if (!CONFIG.pvp || areAllies(player, p)) near.set(p.id, p);
    }
    for (const p of near.values()) {
      try {
        p.addEffect("resistance", 30, { amplifier: 4, showParticles: false });
        p.addEffect("fire_resistance", 120, { amplifier: 0, showParticles: false });
      } catch {
        // 효과를 줄 수 없는 경우는 무시
      }
    }
    dim.spawnEntity("minecraft:lightning_bolt", pos);
    return true;
  } catch {
    return false; // 소환 실패 시 파티클 연출로 대체
  }
}

// 반환값: 진짜 벼락을 쳤는지
function lightningFx(player, pos) {
  const dim = player.dimension;
  // 전용 세로 번개 텍스처와 잔광을 항상 표시합니다.
  particle(dim, "rpg:mage_lightning", { x: pos.x, y: pos.y + 2.0, z: pos.z });
  for (let h = 0; h <= 5; h += 1) {
    particle(dim, "rpg:magic_spark", { x: pos.x + (h % 2 ? 0.18 : -0.18), y: pos.y + h, z: pos.z });
  }
  if (CONFIG.lightning.real && spawnRealBolt(player, pos)) return true;
  for (let h = 0; h <= 8; h += 3) {
    particle(dim, "rpg:mage_lightning", { x: pos.x, y: pos.y + h, z: pos.z });
  }
  sound(dim, "ambient.weather.thunder", pos, { volume: 1.2, pitch: 1.3 });
  return false;
}

// 중심 주변 전체에 피해. falloff 가 있으면 가장자리에서 그만큼 약해집니다.
function blast(player, center, radius, damage, opt = {}) {
  const hits = getTargets(player, center, radius, opt.bodyOffset ?? 0);
  for (const t of hits) {
    const tl = t.location;
    const factor = opt.falloff ? 1 - opt.falloff * Math.min(1, dist3(tl, center) / radius) : 1;
    hurt(t, player, damage * factor);
    knockback(t, tl.x - center.x, tl.z - center.z, opt.knock ?? 0.8, 0.35);
  }
  return hits;
}

function strike(player, target, damage) {
  const tl = target.location;
  // 진짜 벼락은 대상에게 기본 피해를 주므로, 그만큼 빼서 스킬 피해 합계를 맞춥니다.
  const real = lightningFx(player, tl);
  hurt(target, player, real ? Math.max(0, damage - CONFIG.lightning.boltDamage) : damage);
}

function nearestTarget(player, from, radius) {
  const list = getTargets(player, from, radius);
  if (list.length === 0) return undefined;
  list.sort((a, b) => dist3(a.location, from) - dist3(b.location, from));
  return list[0];
}

// 공중 지점에서 아래로 내려가 바닥 바로 위 높이를 찾습니다.
function dropToGround(dim, p) {
  let q = { ...p };
  for (let i = 0; i < 48; i++) {
    const below = { x: q.x, y: q.y - 1, z: q.z };
    if (isSolidAt(dim, below)) break;
    q = below;
  }
  // 1칸 단위로 찾은 높이를 0.1칸 단위로 더 내려서 바닥에 맞춥니다.
  for (let i = 0; i < 10; i++) {
    const below = { x: q.x, y: q.y - 0.1, z: q.z };
    if (isSolidAt(dim, below)) break;
    q = below;
  }
  return q;
}

// 날아가는 투사체. 적/벽에 닿거나 사거리를 다 쓰면 onImpact 호출.
//   seek    : { target, radius, turn }  유도
//   trail   : 파티클 id 목록, trailFn : 직접 그리는 함수(dim, pos)
//   explodeAtEnd : 사거리 끝에서도 터지는지
function fly(player, o) {
  const dim = player.dimension;
  let pos = { ...o.origin };
  let dir = norm3(o.dir);
  let dist = 0;
  let target = o.seek?.target;

  const id = system.runInterval(() => {
    try {
      if (o.seek) {
        if (!target || !healthAlive(target)) target = nearestTarget(player, pos, o.seek.radius);
        if (target) {
          const tl = target.location;
          const to = norm3({ x: tl.x - pos.x, y: tl.y + 1 - pos.y, z: tl.z - pos.z });
          dir = norm3({
            x: dir.x + (to.x - dir.x) * o.seek.turn,
            y: dir.y + (to.y - dir.y) * o.seek.turn,
            z: dir.z + (to.z - dir.z) * o.seek.turn,
          });
        }
      }
      const next = {
        x: pos.x + dir.x * o.speed,
        y: pos.y + dir.y * o.speed,
        z: pos.z + dir.z * o.speed,
      };
      dist += o.speed;

      if (isSolidAt(dim, next)) {
        system.clearRun(id);
        o.onImpact(pos);
        return;
      }
      pos = next;
      if (o.trailFn) o.trailFn(dim, pos);
      else fx(dim, o.trail, pos);

      const hits = getTargets(player, pos, o.hitRadius, 0.9);
      if (hits.length > 0) {
        system.clearRun(id);
        o.onImpact(pos, hits[0]);
        return;
      }
      if (dist >= o.range) {
        system.clearRun(id);
        if (o.explodeAtEnd) o.onImpact(pos);
      }
    } catch {
      system.clearRun(id);
    }
  }, 1);
}

function viewShot(player) {
  const d = norm3(player.getViewDirection());
  const h = headPos(player);
  return { d, origin: { x: h.x + d.x, y: h.y - 0.2 + d.y, z: h.z + d.z } };
}

export const RUNNERS = {
  // ---------- 견습 ----------
  // 직선으로 날아가 폭발
  mage_fireball(player, job, def) {
    const dim = player.dimension;
    const { d, origin } = viewShot(player);
    particle(dim, "rpg:magic_spark", origin);
    sound(dim, "mob.blaze.shoot", player.location, { volume: 0.7, pitch: 1.2 });
    fly(player, {
      origin, dir: d, speed: def.speed, range: def.range, hitRadius: def.hitRadius,
      trail: FX.ghast, explodeAtEnd: true,
      onImpact(pos) {
        boomFx(dim, pos);
        blast(player, pos, def.radius, def.damage, { knock: 0.8, bodyOffset: 0.9 });
      },
    });
  },

  // 전방 엔티티에게 벼락
  mage_lightning(player, job, def) {
    const t = firstTargetInView(player, def.range);
    if (!t) {
      notify(player, "§7시선 앞에 대상이 없습니다.");
      return false;
    }
    strike(player, t, def.damage);
  },

  // ---------- 2차 ----------
  // 주변 엔티티 전체 발화 (엔티티에만 불이 붙고 바닥은 안 탐)
  mage_flame_on(player, job, def) {
    const dim = player.dimension;
    const c = player.location;
    particle(dim, "rpg:mage_flame", { x: c.x, y: c.y + 1, z: c.z });
    for (const t of getTargets(player, c, def.radius)) {
      hurt(t, player, def.damage);
      burn(t, def.burn);
      const tl = t.location;
      fx(dim, FX.fire, { x: tl.x, y: tl.y + 1, z: tl.z });
    }
    sound(dim, "mob.blaze.shoot", c, { volume: 1, pitch: 0.7 });
    let step = 0;
    const id = system.runInterval(() => {
      try {
        step++;
        ringFx(dim, player.location, (def.radius * step) / 10, FX.fire, 0.3, 36);
      } catch {
        system.clearRun(id);
        return;
      }
      if (step >= 10) system.clearRun(id);
    }, 1);
  },

  // 벼락 3번을 나눠서 떨굼 (피해는 3번 합계)
  mage_thunder(player, job, def) {
    const list = getTargets(player, player.location, def.range);
    if (list.length === 0) {
      notify(player, "§7주변에 대상이 없습니다.");
      return false;
    }
    list.sort((a, b) => dist3(a.location, player.location) - dist3(b.location, player.location));
    const each = def.damage / def.strikes;
    for (let i = 0; i < def.strikes; i++) {
      system.runTimeout(() => {
        try {
          const t = list[i % list.length];
          if (healthAlive(t)) strike(player, t, each);
        } catch {
          // 대상이 사라짐
        }
      }, Math.max(1, i * def.interval));
    }
  },

  // 주변 적을 얼려 구속하고 피해
  mage_ice_fire(player, job, def) {
    const dim = player.dimension;
    const c = player.location;
    particle(dim, "rpg:mage_ice", { x: c.x, y: c.y + 0.8, z: c.z });
    for (const t of getTargets(player, c, def.radius)) {
      hurt(t, player, def.damage);
      slow(t, def.slowAmp, def.duration);
      const tl = t.location;
      for (let k = 0; k < 6; k++) {
        fx(dim, FX.ice, { x: tl.x + (k % 3) * 0.3 - 0.3, y: tl.y + k * 0.35, z: tl.z + (k % 2) * 0.4 - 0.2 });
      }
    }
    sound(dim, "random.glass", c, { volume: 1, pitch: 0.8 });
    let step = 0;
    const id = system.runInterval(() => {
      try {
        step++;
        ringFx(dim, player.location, (def.radius * step) / 8, FX.ice, 0.3, 32);
      } catch {
        system.clearRun(id);
        return;
      }
      if (step >= 8) system.clearRun(id);
    }, 1);
  },

  // 중력을 강하게: 구속 4단계 + 아래로 눌러 내림 + 피해
  mage_gravity(player, job, def) {
    const dim = player.dimension;
    const targets = getTargets(player, player.location, def.radius);
    particle(dim, "rpg:mage_gravity", { x: player.location.x, y: player.location.y + 1, z: player.location.z });
    for (const t of targets) {
      hurt(t, player, def.damage);
      slow(t, def.slowAmp, def.duration);
    }
    sound(dim, "mob.evocation_illager.cast_spell", player.location, { volume: 1, pitch: 0.6 });
    let elapsed = 0;
    const id = system.runInterval(() => {
      elapsed += 2;
      for (const t of targets) {
        try {
          if (!healthAlive(t)) continue;
          push(t, 0, -0.6, 0);
          const tl = t.location;
          fx(dim, FX.dark, { x: tl.x, y: tl.y + 2, z: tl.z });
        } catch {
          // 대상이 사라짐
        }
      }
      if (elapsed >= def.duration) system.clearRun(id);
    }, 2);
  },

  // 봄바예: 네 발의 유도 투사체를 한꺼번에 부채꼴로 발사합니다.
  // 각 투사체는 기존 피해의 30%만 줍니다.
  mage_bombaye(player, job, def) {
    const dim = player.dimension;
    const { d, origin } = viewShot(player);
    const first = nearestTarget(player, headPos(player), def.seekRadius);
    const shots = Math.max(1, Math.floor(def.shots ?? 4));
    const perShotDamage = def.damage * (def.damageMultiplier ?? 0.3);
    const sideLen = Math.hypot(d.x, d.z) || 1;
    const side = { x: d.z / sideLen, z: -d.x / sideLen };
    sound(dim, "mob.evocation_illager.cast_spell", player.location, { volume: 0.95, pitch: 1.35 });
    for (let i = 0; i < shots; i++) {
      const spread = shots === 1 ? 0 : ((i / (shots - 1)) * 2 - 1) * 0.18;
      const shotDir = norm3({ x: d.x + side.x * spread, y: d.y, z: d.z + side.z * spread });
      const shotOrigin = {
        x: origin.x + side.x * spread * 1.6,
        y: origin.y + Math.abs(spread) * 0.12,
        z: origin.z + side.z * spread * 1.6,
      };
      fly(player, {
        origin: shotOrigin, dir: shotDir, speed: def.speed, range: def.range, hitRadius: def.hitRadius,
        seek: { target: first, radius: def.seekRadius, turn: def.turn },
        explodeAtEnd: true,
        trailFn(dm, pos) {
          particle(dm, "rpg:mage_bombaye", pos);
          particle(dm, "rpg:mage_gravity", { x: pos.x, y: pos.y + 0.2, z: pos.z });
        },
        onImpact(pos, hit) {
          boomFx(dim, pos);
          if (hit) {
            hurt(hit, player, perShotDamage);
            const hl = hit.location;
            knockback(hit, hl.x - pos.x, hl.z - pos.z, 0.8, 0.3);
          } else {
            blast(player, pos, 2.5, perShotDamage, { knock: 0.6, bodyOffset: 0.9 });
          }
        },
      });
    }
  },

  // ---------- 3차 ----------
  // 마지막으로 마법을 맞춘 대상 위치에 범위 마법진을 소환하고, 2초 뒤 운석을 낙하시킵니다.
  // 마법진 크기는 졸트라크와 동일한 4.4×4.4이며, 대상이 움직이면 위치를 따라갑니다.
  sage_meteor(player, job, def) {
    const dim = player.dimension;
    const target = lastMagicTarget(player, def.homingRange);
    const ground = target
      ? { ...target.location }
      : dropToGround(dim, aimPoint(player, def.range).point);
    targetRangeCircleFx(dim, ground, FX.fire);
    sound(dim, "mob.enderdragon.growl", ground, { volume: 1, pitch: 1.4 });
    let tick = 0;
    const id = system.runInterval(() => {
      try {
        tick++;
        if (target && healthAlive(target) && target.dimension.id === dim.id) {
          const l = target.location;
          ground.x = l.x;
          ground.y = l.y;
          ground.z = l.z;
        }
        // 표식을 재생성해 운석이 내려오는 동안 대상 위치에 마법진이 유지되게 합니다.
        if (tick % 14 === 0) targetRangeCircleFx(dim, ground, FX.fire);
        const y = ground.y + 30 * (1 - tick / def.delay);
        particle(dim, "rpg:sage_meteor", { x: ground.x, y, z: ground.z });
        for (let k = 0; k < 5; k++) {
          particle(dim, "rpg:mage_flame", {
            x: ground.x + (k - 2) * 0.35, y: y - k * 0.35, z: ground.z + ((k * 7) % 3 - 1) * 0.3,
          });
        }
        if (tick >= def.delay) {
          system.clearRun(id);
          // 커스텀 메테오 폭발: 밝은 화염 구체와 주변 불꽃 파편
          particle(dim, "rpg:sage_meteor_blast", { x: ground.x, y: ground.y + 0.65, z: ground.z });
          for (let k = 0; k < 14; k++) {
            const a = (k / 14) * Math.PI * 2;
            const r = 1.1 + (k % 3) * 0.55;
            particle(dim, "rpg:mage_flame", {
              x: ground.x + Math.cos(a) * r,
              y: ground.y + 0.25 + (k % 4) * 0.22,
              z: ground.z + Math.sin(a) * r,
            });
          }
          boomFx(dim, ground, true);
          blast(player, ground, def.radius, def.damage, { falloff: 0.5, knock: 1.4 });
        }
      } catch {
        system.clearRun(id);
      }
    }, 1);
  },

  // 뇌영: 번개 투사체를 발사. 맞으면 벼락과 함께 범위 피해
  sage_raiyoung(player, job, def) {
    const dim = player.dimension;
    const { d, origin } = viewShot(player);
    sound(dim, "ambient.weather.thunder", player.location, { volume: 0.7, pitch: 1.6 });
    fly(player, {
      origin, dir: d, speed: def.speed, range: def.range, hitRadius: def.hitRadius,
      explodeAtEnd: false,
      trailFn(dm, pos) {
        particle(dm, "rpg:sage_raiyoung", pos);
        particle(dm, "rpg:mage_lightning", { x: pos.x, y: pos.y + 0.2, z: pos.z });
      },
      onImpact(pos) {
        particle(dim, "rpg:magic_impact", pos);
        lightningFx(player, pos);
        blast(player, pos, def.burst, def.damage, { knock: 1.0, bodyOffset: 0.9 });
      },
    });
  },

  // 주변 적을 완전히 정지시킨 뒤 깨뜨림
  sage_zero(player, job, def) {
    const dim = player.dimension;
    const targets = getTargets(player, player.location, def.radius);
    if (targets.length === 0) {
      notify(player, "§7주변에 대상이 없습니다.");
      return false;
    }
    for (const t of targets) slow(t, 255, def.freeze);
    particle(dim, "rpg:sage_zero", { x: player.location.x, y: player.location.y + 0.5, z: player.location.z });
    sound(dim, "random.glass", player.location, { volume: 1.2, pitch: 0.5 });
    ringFx(dim, player.location, def.radius, FX.ice, 0.3, 48);

    let elapsed = 0;
    const id = system.runInterval(() => {
      elapsed += 5;
      for (const t of targets) {
        try {
          if (!healthAlive(t)) continue;
          const tl = t.location;
          fx(dim, FX.ice, { x: tl.x, y: tl.y + 1, z: tl.z });
          particle(dim, "rpg:sage_zero", { x: tl.x, y: tl.y + 1, z: tl.z });
        } catch {
          // 대상이 사라짐
        }
      }
      if (elapsed >= def.freeze) {
        system.clearRun(id);
        for (const t of targets) {
          try {
            if (!healthAlive(t)) continue;
            hurt(t, player, def.damage);
            const tl = t.location;
            for (let k = 0; k < 8; k++) {
              fx(dim, FX.ice, { x: tl.x + (k % 4) * 0.25 - 0.4, y: tl.y + k * 0.25, z: tl.z });
            }
            particle(dim, "rpg:magic_impact", { x: tl.x, y: tl.y + 0.8, z: tl.z });
            sound(dim, "random.glass", tl, { volume: 0.8, pitch: 1.2 });
          } catch {
            // 대상이 사라짐
          }
        }
      }
    }, 5);
  },

  // 마지막으로 마법을 맞춘 대상 위치에 블랙홀 생성: 끌어당기며 지속 피해.
  // 대상이 없거나 범위를 벗어난 경우에만 조준 지점을 사용합니다.
  sage_blackhole(player, job, def) {
    const dim = player.dimension;
    const target = lastMagicTarget(player, def.homingRange ?? 60);
    const anchor = target ? { ...target.location } : aimPoint(player, def.range).point;
    const center = { x: anchor.x, y: anchor.y + (target ? 1.0 : 0.5), z: anchor.z };
    targetRangeCircleFx(dim, anchor, ["rpg:magic_spark", "rpg:mage_gravity"]);
    const perHit = def.damage / (def.duration / 10);
    particle(dim, "rpg:sage_blackhole", center);
    sound(dim, "mob.enderdragon.growl", center, { volume: 1, pitch: 0.5 });
    let tick = 0;
    const id = system.runInterval(() => {
      try {
        tick++;
        // 블랙홀 지속 중 마법진/범위 표식을 유지합니다.
        if (tick % 18 === 0) targetRangeCircleFx(dim, anchor, ["rpg:magic_spark", "rpg:mage_gravity"]);
        if (tick % 5 === 0) particle(dim, "rpg:sage_blackhole", center);
        for (let k = 0; k < 6; k++) {
          const a = tick * 0.4 + (k * Math.PI * 2) / 6;
          const r = 2.5 - ((tick % 20) / 20) * 2;
          fx(dim, FX.dark, {
            x: center.x + Math.cos(a) * r, y: center.y + Math.sin(a * 0.5) * 0.8, z: center.z + Math.sin(a) * r,
          });
        }
        for (const t of getTargets(player, center, def.radius)) {
          const tl = t.location;
          const dx = center.x - tl.x;
          const dy = center.y - tl.y;
          const dz = center.z - tl.z;
          const l = Math.hypot(dx, dy, dz) || 1;
          // 블랙홀 중심으로 강하게 빨아들이며, 가까워질수록 흡인력이 증가합니다.
          const pull = l < 3 ? 0.23 : l < 7 ? 0.18 : 0.14;
          push(t, (dx / l) * pull, (dy / l) * (pull * 0.65) + 0.025, (dz / l) * pull);
          if (tick % 10 === 0) hurt(t, player, perHit);
        }
        if (tick >= def.duration) {
          system.clearRun(id);
          boomFx(dim, center);
        }
      } catch {
        system.clearRun(id);
      }
    }, 1);
  },

  // 느리게 날아가는 큰 구체. 충돌하면 크게 폭발
  sage_sphere(player, job, def) {
    const dim = player.dimension;
    const { d, origin } = viewShot(player);
    particle(dim, "rpg:sage_sphere", origin);
    sound(dim, "beacon.activate", player.location, { volume: 1, pitch: 0.7 });
    fly(player, {
      origin, dir: d, speed: def.speed, range: def.range, hitRadius: def.hitRadius,
      explodeAtEnd: true,
      trailFn(dm, pos) {
        fx(dm, FX.blue, pos);
        for (let k = 0; k < 8; k++) {
          const a = (k / 8) * Math.PI * 2;
          fx(dm, FX.blue, {
            x: pos.x + Math.cos(a) * 1.5, y: pos.y + Math.sin(a * 2) * 0.8, z: pos.z + Math.sin(a) * 1.5,
          });
        }
      },
      onImpact(pos) {
        boomFx(dim, pos, true);
        blast(player, pos, def.radius, def.damage, { knock: 1.2, bodyOffset: 0.9 });
      },
    });
  },

  // 졸트라크: 마법진을 1초간 소환한 뒤 직선 광선을 발사합니다.
  sage_zoltraak(player, job, def) {
    const dim = player.dimension;
    const { d, origin } = viewShot(player);
    // 시전자 앞에 마법진을 띄우고, 광선이 이 지점에서 뻗어나가게 합니다.
    const circlePos = {
      x: origin.x + d.x * 1.25,
      y: origin.y + d.y * 1.25,
      z: origin.z + d.z * 1.25,
    };
    particle(dim, "rpg:zoltraak_circle", circlePos);
    sound(dim, "beacon.activate", circlePos, { volume: 0.8, pitch: 1.45 });

    // 마법진 면을 따라 빛 파편이 순환하는 준비 연출.
    const right = Math.hypot(d.x, d.z) > 0.01
      ? norm3({ x: d.z, y: 0, z: -d.x })
      : { x: 1, y: 0, z: 0 };
    const up = norm3({
      x: d.y * right.z - d.z * right.y,
      y: d.z * right.x - d.x * right.z,
      z: d.x * right.y - d.y * right.x,
    });
    let chargeStep = 0;
    const chargeId = system.runInterval(() => {
      try {
        for (let i = 0; i < 6; i++) {
          const a = ((i + chargeStep * 0.35) / 6) * Math.PI * 2;
          const r = 1.7;
          const sparkPos = {
            x: circlePos.x + right.x * Math.cos(a) * r + up.x * Math.sin(a) * r,
            y: circlePos.y + right.y * Math.cos(a) * r + up.y * Math.sin(a) * r,
            z: circlePos.z + right.z * Math.cos(a) * r + up.z * Math.sin(a) * r,
          };
          particle(dim, "rpg:magic_spark", sparkPos);
        }
      } catch {
        system.clearRun(chargeId);
        return;
      }
      if (++chargeStep >= 5) system.clearRun(chargeId);
    }, 4);

    // 20 ticks = 1 second. Damage and beam are both delayed until the charge completes.
    system.runTimeout(() => {
      try {
        const pts = [];
        for (let t = 0; t <= def.range; t += 1) {
          const p = {
            x: circlePos.x + d.x * t,
            y: circlePos.y + d.y * t,
            z: circlePos.z + d.z * t,
          };
          if (isSolidAt(dim, p)) break;
          pts.push(p);
        }
        if (pts.length === 0) return;

        sound(dim, "mob.warden.sonic_boom", circlePos, { volume: 1.2, pitch: 0.9 });
        const hit = new Set();
        for (const p of pts) {
          for (const e of getTargets(player, p, def.width, 0.9)) {
            if (hit.has(e.id)) continue;
            hit.add(e.id);
            hurt(e, player, def.damage);
            knockback(e, d.x, d.z, 1.2, 0.4);
            const el = e.location;
            particle(dim, "rpg:zoltraak_impact", { x: el.x, y: el.y + 1, z: el.z });
            particle(dim, "minecraft:large_explosion", { x: el.x, y: el.y + 1, z: el.z });
          }
        }

        // Draw the beam for 8 ticks so it remains visible briefly after firing.
        let n = 0;
        const beamId = system.runInterval(() => {
          try {
            for (const p of pts) {
              particle(dim, "rpg:zoltraak_beam", p);
              if ((n + Math.floor(p.x + p.z)) % 3 === 0) {
                particle(dim, "minecraft:electric_spark_particle", {
                  x: p.x + (Math.random() - 0.5) * 0.3,
                  y: p.y + (Math.random() - 0.5) * 0.3,
                  z: p.z + (Math.random() - 0.5) * 0.3,
                });
              }
            }
          } catch {
            system.clearRun(beamId);
            return;
          }
          if (++n >= 8) system.clearRun(beamId);
        }, 1);

        particle(dim, "rpg:zoltraak_impact", pts[pts.length - 1]);
        particle(dim, "rpg:zoltraak_impact", circlePos);
      } catch {
        // 플레이어 또는 대상이 사라진 경우 지연된 연출을 안전하게 종료합니다.
      }
    }, 20);
  },
};
