import { areAllies } from "../core/social.js";
import { world, system } from '@minecraft/server';
import { CONFIG } from '../config.js';
import { getJobId, getSkills } from '../core/playerData.js';
import { getTargets, hurt as hurtBase, flatDir, dist3, isSolidAt, particle, sound, knockback, aimPoint, healthAlive } from '../core/util.js';
import { notify } from '../core/hud.js';

// 화염술사: 화염 저항 상시 패시브 + 다섯 개 액티브 스킬.
// 작은 픽셀 파티클을 사용하며 세계 블록에 불을 배치하거나 파괴하지 않습니다.
const EMBER = 'rpg:fire_ember';
const STREAK = 'rpg:fire_streak';
const RING = 'rpg:fire_ring';
const TEAM = 'rpg_team_';
const armor = new Map(); // casterId -> { until }
let installed = false;

function valid(e) {
  try { return !!e?.isValid && healthAlive(e); }
  catch { return false; }
}
function enemy(p, e) {
  if (!valid(e) || e.id === p.id || areAllies(p,e)) return false;
  if (e.typeId === 'minecraft:player') {
    if (!CONFIG.pvp) return false;
    const team = p.getTags().find(t => t.startsWith(TEAM));
    if (team && e.hasTag(team)) return false;
  }
  return true;
}
function center(e, dy = 1) {
  const q = e.location;
  return { x:q.x, y:q.y + dy, z:q.z };
}
function dot(dim, id, q) { particle(dim, id, q); }
function circle(dim, c, r, id, n = 18, dy = 0) {
  for (let i = 0; i < n; i++) {
    const a = i * Math.PI * 2 / n;
    dot(dim, id, { x:c.x + r * Math.cos(a), y:c.y + dy, z:c.z + r * Math.sin(a) });
  }
}
function ignite(target, seconds) {
  if (!CONFIG.igniteEntities) return;
  try { target.setOnFire(seconds, true); } catch {}
}
function strike(caster, target, damage, burnSeconds = 0) {
  if (!enemy(caster, target)) return false;
  if (!hurt(target, caster, damage)) return false;
  if (burnSeconds > 0) ignite(target, burnSeconds);
  dot(caster.dimension, EMBER, center(target));
  return true;
}
// 자연발화: 시전자 주위의 모든 적에게 직접 화염을 붙이고 피해를 줍니다.
function naturalIgnition(p, job, def) {
  const dim = p.dimension;
  const origin = { ...p.location };
  const targets = getTargets(p, origin, def.radius).filter(e => enemy(p, e));
  for (const e of targets) {
    strike(p, e, def.damage, def.burnSeconds);
    for (let i = 0; i < 8; i++) {
      const a = i * Math.PI * 2 / 8;
      dot(dim, i % 2 ? STREAK : EMBER, {
        x:e.location.x + Math.cos(a) * .55,
        y:e.location.y + .35 + (i % 3) * .36,
        z:e.location.z + Math.sin(a) * .55,
      });
    }
  }
  circle(dim, center(p, .3), def.radius, EMBER, 20);
  sound(dim, 'fire.ignite', origin, { volume:.7, pitch:.95 });
  notify(p, `§6자연발화! §f주변 ${targets.length}명에게 화상 발생`);
  return true;
}
function firePillar(p, job, def) {
  const dim = p.dimension, point = aimPoint(p, def.range).point;
  let base = { x:point.x, y:Math.floor(point.y), z:point.z };
  for (let d = 0; d < 5; d++) {
    if (isSolidAt(dim, { x:base.x, y:base.y - 1, z:base.z })) break;
    base.y--;
  }
  const victims = getTargets(p, base, def.radius).filter(e => enemy(p, e));
  for (const e of victims) {
    strike(p, e, def.damage, def.burnSeconds);
    try { e.applyImpulse({ x:0, y:def.launch, z:0 }); }
    catch { knockback(e, .1, .1, .1, def.launch); }
  }
  for (let h = 0; h < 5; h++) {
    circle(dim, { x:base.x, y:base.y + h * .75, z:base.z }, def.radius * (1 - h * .10), h % 2 ? EMBER : STREAK, 20);
  }
  sound(dim, 'random.explode', base, { volume:.85, pitch:.8 });
  notify(p, `§6불기둥: §f${victims.length}명 적중`);
  return true;
}
// 화염바퀴: 기존 원거리 발사형에서 자신이 불꽃 바퀴가 되어 전방으로 돌진하는 기술로 변경.
// 바닥·벽의 안전지역 조건 없이 시전한 높이(Y)를 유지하면서 전방으로 돌진합니다.
function fireWheel(p, job, def) {
  const dim = p.dimension;
  const f = flatDir(p);
  const side = { x:-f.z, z:f.x };
  const hit = new Set();
  let moved = 0;
  let elapsed = 0;
  const dashY = p.location.y;
  sound(dim, 'mob.blaze.shoot', p.location, { volume:.8, pitch:.7 });
  const task = system.runInterval(() => {
    try {
      if (!p.isValid || p.dimension.id !== dim.id || moved >= def.range || elapsed >= 20) {
        system.clearRun(task);
        return;
      }
      elapsed++;
      const current = p.location;
      const advanced = Math.min(def.speed, def.range - moved);
      if (advanced <= .001) { system.clearRun(task); return; }
      const next = { x:current.x + f.x * advanced, y:dashY, z:current.z + f.z * advanced };
      p.teleport(next, { dimension:dim, keepVelocity:false });
      moved += advanced;
      const q = center(p, 1);
      // 주위를 도는 가늘고 작은 화염 링: 투사체가 아니라 플레이어 자체를 둘러쌈.
      for (let i = 0; i < 14; i++) {
        const a = i * Math.PI * 2 / 14 + elapsed * .65;
        dot(dim, i%3 === 0 ? STREAK : EMBER, {
          x:q.x + side.x * Math.cos(a) * def.wheelRadius,
          y:q.y + Math.sin(a) * def.wheelRadius,
          z:q.z + side.z * Math.cos(a) * def.wheelRadius,
        });
      }
      if(elapsed%2===0) dot(dim, RING, q);
      for (const e of getTargets(p, next, def.hitRadius)) {
        if (!enemy(p, e) || hit.has(e.id)) continue;
        hit.add(e.id);
        strike(p, e, def.damage, def.burnSeconds);
        circle(dim, center(e), .65, STREAK, 9);
      }
    } catch { system.clearRun(task); }
  }, 1);
  notify(p, '§6화염바퀴! §f불꽃을 두르고 전방으로 돌진합니다.');
  return true;
}
function fireArmor(p, job, def) {
  armor.set(p.id, system.currentTick + def.duration);
  for (const [name, amplifier] of [['strength', 1], ['resistance', 1]]) {
    try { p.addEffect(name, def.duration, { amplifier, showParticles:false }); } catch {}
  }
  // 화갑은 힘 II·저항 II 및 근접 반격, 화염 저항은 상시 패시브에서 처리합니다.
  circle(p.dimension, center(p, .85), 1.0, EMBER, 12);
  sound(p.dimension, 'fire.ignite', p.location, { volume:.6, pitch:.9 });
  notify(p, '§6화갑: §f10초간 힘 II / 저항 II (근접 공격자 화상)');
  return true;
}
function fireEmperor(p, job, def) {
  const dim = p.dimension;
  const origin = { ...p.location };
  const expires = system.currentTick + def.zoneTicks;
  for (const [name, amp] of [['strength', 2], ['resistance', 1]]) {
    try { p.addEffect(name, def.buffTicks, { amplifier:amp, showParticles:false }); } catch {}
  }
  for (const e of getTargets(p, origin, def.radius)) {
    if (enemy(p, e)) strike(p, e, def.damage, def.burnSeconds);
  }
  circle(dim, { x:origin.x, y:origin.y + .35, z:origin.z }, def.radius, STREAK, 36);
  circle(dim, { x:origin.x, y:origin.y + .8, z:origin.z }, def.radius * .65, EMBER, 24);
  sound(dim, 'random.explode', origin, { volume:1, pitch:.5 });
  let ticks = 0;
  const task = system.runInterval(() => {
    try {
      if (!p.isValid || p.dimension.id !== dim.id || system.currentTick >= expires) {
        system.clearRun(task);
        return;
      }
      ticks += 10;
      // 5초간 화염 영역의 회전 궤적과 1초당 지속 피해.
      for (let i = 0; i < 20; i++) {
        const a = i * Math.PI * 2 / 20 + ticks * .055;
        dot(dim, i % 2 ? EMBER : STREAK, {
          x:origin.x + Math.cos(a) * def.radius * .85,
          y:origin.y + .25 + (i % 3) * .3,
          z:origin.z + Math.sin(a) * def.radius * .85,
        });
      }
      if (ticks % 20 === 0) {
        for (const e of getTargets(p, origin, def.radius)) {
          if (enemy(p, e)) strike(p, e, def.zoneDamage, 2);
        }
      }
    } catch { system.clearRun(task); }
  }, 10);
  notify(p, '§6염제! §f15초간 화염의 힘, 5초간 주변 화염 영역 전개');
  return true;
}
export const RUNNERS = {
  fire_ignite: naturalIgnition,
  fire_pillar: firePillar,
  fire_wheel: fireWheel,
  fire_armor: fireArmor,
  fire_emperor: fireEmperor,
};
export function registerFire() {
  if (installed) return;
  installed = true;
  // 잔화 패시브는 제거. 기본 패시브는 화염 저항이며 화갑의 근거리 반격만 추가됩니다.
  world.afterEvents.entityHurt.subscribe(ev => {
    try {
      const victim = ev.hurtEntity;
      const attacker = ev.damageSource?.damagingEntity;
      if (!victim || !attacker || victim.typeId !== 'minecraft:player') return;
      if ((getJobId(victim) !== 'fire_controller' && !(getJobId(victim)==='chameleon' && getSkills(victim).includes('fire_armor'))) || (armor.get(victim.id) ?? 0) <= system.currentTick) return;
      if (!enemy(victim, attacker) || dist3(victim.location, attacker.location) > 3.2) return;
      ignite(attacker, 3);
      dot(victim.dimension, EMBER, center(attacker));
    } catch {}
  });
  world.afterEvents.entityDie.subscribe(ev => {
    try { armor.delete(ev.deadEntity.id); } catch {}
  });
  world.afterEvents.playerLeave.subscribe(ev => armor.delete(ev.playerId));
  // 화염술사에게 상시 화염 저항 I 부여. 타 직업 변경 시 5초 내 자연 만료됩니다.
  // showParticles:false 로 전용 시각 효과 없이 패시브만 유지합니다.
  system.runInterval(() => {
    for (const p of world.getAllPlayers()) {
      try {
        if (getJobId(p) === 'fire_controller')
          p.addEffect('fire_resistance', 100, { amplifier:0, showParticles:false });
      } catch {}
    }
    for (const [id, until] of armor) if (until <= system.currentTick) armor.delete(id);
  }, 40);
}

// Borrowed spells use MAG just like their original spell class.
function hurt(target,source,amount,type="magic"){return hurtBase(target,source,amount,type);}
