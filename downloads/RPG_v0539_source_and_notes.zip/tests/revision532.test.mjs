import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,ItemStack,EquipmentSlot,system,world,players,events,intervals,timeouts} from './minecraftMock.mjs';
import {getContext} from '../RPG_BP_v0539/scripts/core/context.js';
import {registerInput} from '../RPG_BP_v0539/scripts/core/input.js';
import {getMana,setMana,setIndex} from '../RPG_BP_v0539/scripts/core/playerData.js';
import {getXp,registerRpgStats,manaCostFor,allocateStat,applyVitality} from '../RPG_BP_v0539/scripts/core/stats.js';
import {startCooldown,cooldownLeft,clearPlayerRuntime,resetCooldowns,resetNonUltimateCooldowns,COOLDOWN_KEY,setSkills} from '../RPG_BP_v0539/scripts/core/playerData.js';
import {addRuneRecord,readRuneBag,writeRuneBag,equipRune} from '../RPG_BP_v0539/scripts/core/runeInventory.js';
import {RUNNERS as HOLY} from '../RPG_BP_v0539/scripts/skills/holy.js';
import {RUNNERS as SWORD} from '../RPG_BP_v0539/scripts/skills/sword.js';
import {RUNNERS as SPIN} from '../RPG_BP_v0539/scripts/skills/swordFlameSpin.js';
import {RUNNERS as DRAGON,registerDragon} from '../RPG_BP_v0539/scripts/skills/dragon.js';
import {RUNNERS as BEAST,registerBerserker} from '../RPG_BP_v0539/scripts/skills/berserker.js';
import {RUNNERS as FIST,registerFist} from '../RPG_BP_v0539/scripts/skills/fist.js';
import {RUNNERS as MOON,tryBorrowedMoonThrow} from '../RPG_BP_v0539/scripts/skills/celestial.js';
import {RUNNERS as MAGE} from '../RPG_BP_v0539/scripts/skills/mage.js';
import {RUNNERS as TECH} from '../RPG_BP_v0539/scripts/skills/technomancer.js';
import {SKILLS} from '../RPG_BP_v0539/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0539/scripts/data/jobs.js';
import {chameleonCastJob} from '../RPG_BP_v0539/scripts/core/chameleon.js';
import {purchaseChameleonSkill,dismantleChameleonSkill} from '../RPG_BP_v0539/scripts/core/chameleonProgress.js';
import {isFrenzyActive} from '../RPG_BP_v0539/scripts/core/frenzy.js';

function scene(id,skills=[],job='chameleon'){
 const p=player(id,80);p.setDynamicProperty('rpg:job',job);setSkills(p,skills);
 p.equipment.set(EquipmentSlot.Mainhand,new ItemStack(JOBS[job].weapon));
 const enemy=player(id+'-enemy',1,{typeId:'minecraft:zombie',health:1000,location:{x:0,y:64,z:2}}),hits=[],spawns=[];
 const dim={id:'minecraft:overworld',spawnParticle(){},playSound(){},getPlayers:()=>[p],getEntities:()=>[enemy],
  getBlock:q=>({typeId:q.y<64?'minecraft:stone':'minecraft:air',isSolid:q.y<64,isAir:q.y>=64}),
  spawnEntity(typeId,at){spawns.push(typeId);return {isValid:true,location:at,addTag(){},teleport(){},remove(){}};}};
 for(const entity of [p,enemy]){entity.dimension=dim;entity.getViewDirection=()=>({x:0,y:0,z:1});entity.getHeadLocation=()=>({...entity.location,y:65.6});entity.getRotation=()=>({x:0,y:0});entity.teleport=at=>{entity.location={...at};};entity.applyKnockback=()=>{};entity.setOnFire=()=>{};entity.applyDamage=(amount,options)=>{hits.push({amount,options});entity.health-=amount;return true;};}
 return {p,enemy,hits,spawns,dim};
}
function run(runners,p,id,target){return runners[id](p,chameleonCastJob(id,JOBS[p.getDynamicProperty('rpg:job')]),SKILLS[id],target);}
function intervalAfter(action){const n=intervals.length;action();assert.ok(intervals.length>n);return intervals.at(-1);}

// Fixed clock verifies offline time, tick reset on server restart and persistence isolation.
test('reconnect retains outstanding skill and basic cooldowns, including after server tick resets',()=>{
 const real=Date.now;let now=1000000;Date.now=()=>now;
 try{const p=player('cd');system.currentTick=100;startCooldown(p,'sword_rush',1200);startCooldown(p,'basic',40);
  system.currentTick=110;now+=500;assert.equal(cooldownLeft(p,'sword_rush'),1190);
  clearPlayerRuntime(p.id);const reconnect=player(p.id);reconnect.setDynamicProperty(COOLDOWN_KEY,p.getDynamicProperty(COOLDOWN_KEY));system.currentTick=0;now+=1000;
  assert.equal(cooldownLeft(reconnect,'sword_rush'),1170);assert.equal(cooldownLeft(reconnect,'basic'),10);assert.equal(cooldownLeft(player('other'),'sword_rush'),0);
 }finally{Date.now=real;}
});
test('expired cooldown stays expired on rejoin, reboot and admin reset save their cleared state',()=>{
 const real=Date.now;let now=2000000;Date.now=()=>now;
 try{const p=player('expiry');startCooldown(p,'sword_rush',1200);startCooldown(p,'mage_fireball',100);resetNonUltimateCooldowns(p);clearPlayerRuntime(p.id);
  assert.equal(cooldownLeft(p,'mage_fireball'),0);assert.equal(cooldownLeft(p,'sword_rush'),1200);
  now+=60001;clearPlayerRuntime(p.id);assert.equal(cooldownLeft(p,'sword_rush'),0);
  startCooldown(p,'sword_rush',1200);resetCooldowns(p);assert.equal(p.getDynamicProperty(COOLDOWN_KEY),undefined);clearPlayerRuntime(p.id);assert.equal(cooldownLeft(p,'sword_rush'),0);
 }finally{Date.now=real;}
});
test('Hydra and tech golem actual death events award 900 and 850 RPG XP',()=>{
 registerRpgStats();const emit=events.entityDie.listeners.at(-1);
 for(const [typeId,amount]of [['rpg:hydra_boss',900],['rpg:tech_block_golem_boss',850]]){
  const p=player('xp'+typeId,80);emit({deadEntity:{typeId},damageSource:{damagingEntity:p}});assert.equal(getXp(p),amount);
 }
});
test('sandbag table recipe consumes nine hay blocks and produces exactly one spawner',()=>{
 const r=JSON.parse(fs.readFileSync(new URL('../RPG_BP_v0539/recipes/sandbag_spawner.json',import.meta.url)))['minecraft:recipe_shaped'];
 assert.deepEqual(r.tags,['crafting_table']);assert.deepEqual(r.pattern,['HHH','HHH','HHH']);assert.deepEqual(r.key,{H:{item:'minecraft:hay_block'}});assert.deepEqual(r.result,{item:'rpg:sandbag_spawner',count:1});
});
test('INT caps skill mana discount at 40%, with proportional intermediate values and upward rounding',()=>{
 const p=player('int',80);assert.equal(manaCostFor(p,700),700);assert.equal(allocateStat(p,'int',15).ok,true);assert.equal(manaCostFor(p,900),780);
 assert.equal(allocateStat(p,'int',30).ok,true);assert.equal(manaCostFor(p,700),420);assert.equal(manaCostFor(p,40),24);assert.equal(manaCostFor(p,1),1);assert.equal(manaCostFor(p,0),0);
});
test('vitality rune increases real health by four at every grade, across VIT rounding boundaries',()=>{
 for(const vit of [0,1,9,10,41]){
  const results=[];
  for(let level=0;level<=5;level++){
   const p=player('hp'+vit+'-'+level,80);if(vit)allocateStat(p,'vit',vit);
   const bag=readRuneBag(p),r=addRuneRecord(bag,'vitality',level);writeRuneBag(p,bag);equipRune(p,r.uid,0);applyVitality(p);
   results.push(p.getComponent('minecraft:health').effectiveMax);
  }
  for(let i=1;i<results.length;i++)assert.equal(results[i]-results[i-1],4);
  assert.equal(results[5]-results[0],20);
 }
});
test('cleric AOE shield, sword, blessing and zone never heal or buff hostile players',()=>{
 const {p,dim}=scene('holy',[],'michael'),ally=player('friendly'),enemy=player('hostile');
 p.getTags=ally.getTags=()=>['rpg_team_test'];p.hasTag=ally.hasTag=tag=>tag==='rpg_team_test';enemy.getTags=()=>[];enemy.hasTag=()=>false;for(const a of [ally,enemy]){a.dimension=dim;a.health=4;}
 dim.getPlayers=()=>[p,ally,enemy];dim.getEntities=()=>[ally,enemy];
 for(const id of ['holy_shield','holy_sword','angel_bless'])run(HOLY,p,id);
 assert.ok(ally.effects.has('absorption'));assert.ok(ally.effects.has('strength'));assert.ok(ally.effects.has('regeneration'));assert.equal(ally.health,20);assert.equal(enemy.health,4);assert.equal(enemy.effects.size,0);
 const tick=intervalAfter(()=>run(HOLY,p,'angel_zone'));tick();assert.equal(enemy.health,4);assert.equal(enemy.effects.has('regeneration'),false);assert.equal(enemy.effects.has('resistance'),false);
});
test('borrowed flame spin continues and hits; unlearned Chameleon remains ineligible',()=>{
 const {p,hits}=scene('spin',['sword_flame_spin']);const tick=intervalAfter(()=>assert.equal(run(SPIN,p,'sword_flame_spin'),true));tick();assert.equal(hits.length,1);
 const other=scene('no-spin');assert.equal(run(SPIN,other.p,'sword_flame_spin'),false);
});
test('borrowed kenho completes all three strikes with the Chameleon weapon equipped',()=>{
 const {p,hits}=scene('kenho',['sword_kenho_rando']);const n=timeouts.length;assert.equal(run(SWORD,p,'sword_kenho_rando'),true);for(const fn of timeouts.slice(n))fn();assert.equal(hits.length,3);
});
test('borrowed frenzy works without native wings and existing buff survives dismantling',()=>{
 const {p}=scene('frenzy');assert.equal(purchaseChameleonSkill(p,'fallen_sword_frenzy').ok,true);assert.equal(run(SWORD,p,'fallen_sword_frenzy'),true);assert.equal(isFrenzyActive(p),true);assert.equal(dismantleChameleonSkill(p,'fallen_sword_frenzy').ok,true);assert.equal(isFrenzyActive(p),true);
});
test('borrowed dragon sprint moves and hits, breath launches and hits after its cast',()=>{
 const {p,hits}=scene('sprint',['dragon_sprint']);const tick=intervalAfter(()=>assert.equal(run(DRAGON,p,'dragon_sprint'),true));tick();assert.ok(p.location.z>0);assert.ok(hits.length>0);
 const b=scene('breath',['dragon_breath']);const fly=intervalAfter(()=>assert.equal(run(DRAGON,b.p,'dragon_breath'),true));for(let i=0;i<4;i++)fly();assert.ok(b.hits.length>0);
});
test('borrowed triple-strike gets three active bonuses without gaining the dragon heal passive',()=>{
 registerDragon();const handler=events.entityHurt.listeners.at(-1);const {p,enemy}=scene('triple',['dragon_triple_strike']);p.health=8;run(DRAGON,p,'dragon_triple_strike');const initial=enemy.health;
 for(let i=0;i<3;i++)handler({hurtEntity:enemy,damage:2,damageSource:{damagingEntity:p,cause:'entityAttack'}});
 assert.ok(enemy.health<initial);assert.equal(p.health,8);assert.ok(enemy.effects.has('slowness'));
});
test('borrowed berserker triple slash completes three damage passes',()=>{
 const {p,enemy,hits}=scene('trislash',['berserker_triple_slash']);const tick=intervalAfter(()=>assert.equal(run(BEAST,p,'berserker_triple_slash'),true));for(let i=0;i<3;i++){enemy.location.z=p.location.z+2;tick();}assert.equal(hits.length,3);
});
test('borrowed flame burst launches three projectiles and grand explosion deals delayed damage',()=>{
 const {p,hits}=scene('flame',['beast_flame_burst']);const n=timeouts.length;assert.equal(run(BEAST,p,'beast_flame_burst'),true);const fly=[];for(const shot of timeouts.slice(n))fly.push(intervalAfter(shot));for(const fn of fly)fn();assert.equal(hits.length,3);
 const b=scene('explode',['beast_grand_explosion']);const m=timeouts.length;assert.equal(run(BEAST,b.p,'beast_grand_explosion'),true);for(const fn of timeouts.slice(m))fn();assert.equal(b.hits.length,1);
});
test('borrowed execution x4 uses Chameleon weapon and consumes empowerment once',()=>{
 registerBerserker();const handler=events.entityHurt.listeners.at(-1);const {p,enemy}=scene('execute',['berserker_execute']);run(BEAST,p,'berserker_execute');enemy.health=100;
 handler({hurtEntity:enemy,damage:5,damageSource:{damagingEntity:p,cause:'entityAttack'}});assert.equal(enemy.health,85);
 handler({hurtEntity:enemy,damage:5,damageSource:{damagingEntity:p,cause:'entityAttack'}});assert.equal(enemy.health,85);
});
test('borrowed strong punch doubles a basic hit without granting fist fall passive',()=>{
 registerFist();const handler=events.entityHurt.listeners.at(-1);const {p,enemy,hits}=scene('strong',['fist_strong']);run(FIST,p,'fist_strong');handler({hurtEntity:enemy,damage:6,damageSource:{damagingEntity:p,cause:'entityAttack'}});assert.ok(hits.length>0||enemy.health<1000);p.health=7;handler({hurtEntity:p,damage:5,damageSource:{cause:'fall'}});assert.equal(p.health,7);
});
test('borrowed holy orb survives its scheduled class check and refreshes allied regeneration',()=>{
 const {p,dim}=scene('orb',['holy_orb']),ally=player('orb-ally');p.getTags=ally.getTags=()=>['rpg_team_orb'];p.hasTag=ally.hasTag=tag=>tag==='rpg_team_orb';ally.dimension=dim;ally.location={x:0,y:64,z:1};
 const tick=intervalAfter(()=>assert.notEqual(run(HOLY,p,'holy_orb',ally),false));for(let i=0;i<12;i++)tick();assert.ok(ally.effects.has('regeneration'));assert.ok(ally.effects.has('absorption'));assert.ok(p.effects.has('hunger'));
});
test('borrowed moon split immediately throws and permits repeated throws only during buff',()=>{
 const {p,spawns}=scene('moon',['moon_chakram_split']);p.setDynamicProperty('rpg:moon_light',100);assert.equal(tryBorrowedMoonThrow(p),false);assert.equal(run(MOON,p,'moon_chakram_split'),true);assert.ok(spawns.includes('rpg:moon_weapon_chakram'));const n=spawns.length;
 system.currentTick+=15;assert.equal(tryBorrowedMoonThrow(p),true);assert.ok(spawns.length>n);system.currentTick+=SKILLS.moon_chakram_split.duration;assert.equal(tryBorrowedMoonThrow(p),false);
});
test('borrowed spells scale with MAG, while physical sword strikes scale with STR',()=>{
 const a=scene('magic',['mage_fireball']);allocateStat(a.p,'str',100);allocateStat(a.p,'mag',10);const tick=intervalAfter(()=>run(MAGE,a.p,'mage_fireball'));for(let i=0;i<4;i++)tick();assert.ok(a.hits.length>0);assert.ok(Math.abs(a.hits[0].amount-SKILLS.mage_fireball.damage*1.07)<1e-8);
 const b=scene('physical',['sword_spin']);allocateStat(b.p,'str',10);allocateStat(b.p,'mag',100);run(SWORD,b.p,'sword_spin');assert.ok(Math.abs(b.hits[0].amount-SKILLS.sword_spin.damage*1.07)<1e-8);
});

test('actual item input pays moon split once and repeat throws preserve MP and skill cooldown',()=>{
 registerInput();const {p,spawns}=scene('input-moon');purchaseChameleonSkill(p,'moon_chakram_split');p.setDynamicProperty('rpg:moon_light',100);setMana(p,1000);const initialMana=getMana(p);setIndex(p,getContext(p).skills.indexOf('moon_chakram_split'));
 const use=()=>{for(const fn of events.itemUse.listeners)fn({source:p,itemStack:new ItemStack(JOBS.chameleon.weapon)});};
 system.currentTick+=10;use();assert.equal(getMana(p),initialMana-90);assert.ok(cooldownLeft(p,'moon_chakram_split')>0);const count=spawns.length;
 system.currentTick+=15;const left=cooldownLeft(p,'moon_chakram_split');use();assert.equal(getMana(p),initialMana-90);assert.equal(cooldownLeft(p,'moon_chakram_split'),left);assert.ok(spawns.length>count);
});
test('actual item input is blocked by cooldown restored after reconnect',()=>{
 const {p}=scene('input-cd');purchaseChameleonSkill(p,'mage_fireball');setMana(p,1000);setIndex(p,getContext(p).skills.indexOf('mage_fireball'));
 const use=()=>{for(const fn of events.itemUse.listeners)fn({source:p,itemStack:new ItemStack(JOBS.chameleon.weapon)});};
 system.currentTick+=10;use();const mana=getMana(p);assert.ok(mana<1000);clearPlayerRuntime(p.id);system.currentTick+=10;use();assert.equal(getMana(p),mana);assert.ok(cooldownLeft(p,'mage_fireball')>0);
});
