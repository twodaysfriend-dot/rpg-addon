# RPG v0.6.91 · 성직 파티 지원과 난식

- 청소기는 엔더마이트와 일반·슈퍼 샌드백을 보호합니다.
- 불굴의 검과 불굴의 방패는 시전자와 접속 중인 생존 파티원 전원에게 적용됩니다. 받거나 효과가 끝나면 개인 채팅에 표시됩니다.
- 축복의 구슬은 우클릭으로 같은 차원 30칸 안에서 현재 HP가 가장 낮은 부상 파티원에게 붙습니다. 대상이 최대 HP에 도달하면 다음 부상 파티원에게 옮겨가고, 대상이 모두 회복되면 끝납니다.
- 힐은 우클릭으로 현재 HP가 가장 낮은 부상 파티원에게 시전할 수 있습니다. 좌클릭으로 대상을 지정하는 사용법도 쓸 수 있습니다.
- 투신 난식은 쿨타임 0초, 파편당 기본 피해 8입니다. MP 120이 필요하고 대상당 최대 10발까지 적중합니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.91로 활성화하세요. 모의 테스트에서 청소기 제외 대상, 파티 버프와 종료 안내, 구슬의 대상 이동, 우클릭 힐과 난식 연속 시전을 확인했습니다. 실제 Bedrock 월드에서는 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0691
```
