import {projectileMotion} from '../core/combatRunes.js';
import {deferStoppedDamage,isTimeFrozen} from '../core/timeStopDamage.js';
import {setCombatHealth} from '../core/combatContext.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import {strikeAxis,warGodAttackFx,warGodImpactFx,warGodFinaleFx} from './warGodFx.js';
import {world,system,EntityDamageCause} from '@minecraft/server';
import {getTargets,flatDir,headPos,norm3,isSolidAt,clearBlockPath,knockback,particle,sound,skillItemId as heldItemId} from '../core/util.js';
import {shotgunDirections} from '../core/shotgun.js';
import {catchCrimsonHit} from '../core/bloodedgeState.js';
import {skillDamageFor} from '../core/stats.js';
import {scriptedHit,currentScriptHit,rememberScriptKiller,noteManualDamage,setBasicHitHandler,BLACK_FLASH_KEY} from '../core/combatContext.js';
import {healLifesteal} from '../core/lifesteal.js';
import {areAllies} from '../core/social.js';
import {CONFIG} from '../config.js';
import {notify} from '../core/hud.js';
export {BLACK_FLASH_KEY};
const fanBoostReservations=new Map();
const FLURRY_SHARD='rpg:war_god_flurry_shard', FLURRY_SPARK='rpg:war_god_flurry_spark';
function valid(p,t){return t&&t.id!==p.id&&!areAllies(p,t)&&!['minecraft:armor_stand','minecraft:item','minecraft:xp_orb'].includes(t.typeId)&&(!t.typeId.startsWith('rpg:hito_'))&&(t.typeId!=='minecraft:player'||(CONFIG.pvp&&!['creative','spectator'].includes(String(t.getGameMode?.()).toLowerCase())));}
function cone(p,def){
 const origin=p.location,dir=flatDir(p);return getTargets(p,{x:origin.x,y:origin.y+1,z:origin.z},def.range+1,.9).filter(t=>{
  if(!valid(p,t))return false;const dx=t.location.x-origin.x,dz=t.location.z-origin.z,along=dx*dir.x+dz*dir.z,side=Math.abs(dx*dir.z-dz*dir.x);
  if(along<0||along>def.range||side>def.width||Math.abs(t.location.y-origin.y)>3)return false;
  for(let step=.5;step<Math.hypot(dx,dz);step+=.5){const distance=Math.hypot(dx,dz)||1;if(isSolidAt(p.dimension,{x:origin.x+dx/distance*step,y:origin.y+1,z:origin.z+dz/distance*step}))return false;}
  return true;
 }).slice(0,8);
}
function hit(p,t,damage){
 return scriptedHit(t,p,()=>{
  const amount=skillDamageFor(p,damage,'physical');
  if(deferStoppedDamage(t,p,amount))return true;
  if(catchCrimsonHit(t,p,amount))return false;
  try{if(t.applyDamage(amount,{cause:EntityDamageCause.override,damagingEntity:p})!==false)return true;}catch{}
  const hp=t.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return false;
  if(amount>=hp.currentValue)rememberScriptKiller(p,t);const before=hp.currentValue;setCombatHealth(t,p,hp,Math.max(0,before-amount));noteManualDamage(p,t,Math.min(before,amount));return true;
 });
}
function impact(p,t,kick){
 const at={x:t.location.x,y:t.location.y+1,z:t.location.z};particle(p.dimension,'minecraft:critical_hit_emitter',at);warGodImpactFx(p,t);sound(p.dimension,'mob.irongolem.hit',at,{volume:.6,pitch:kick ? 0.7 : 1.1});
}
export function attack(p,j,d){
 const targets=cone(p,d);if(!targets.length){notify(p,'§7전방에 공격할 적이 없습니다.');return false;}
 const boosted=p.getDynamicProperty(BLACK_FLASH_KEY)===true&&!fanBoostReservations.has(p.id);let mult=1;if(boosted){p.setDynamicProperty(BLACK_FLASH_KEY,undefined);mult=2;notify(p,'§4천멸격! §f스킬 피해 ×2');sound(p.dimension,'mob.wither.spawn',p.location,{volume:.4,pitch:1.6});}
 const originDimension=p.dimension.id;let i=0;
 const pulse=()=>{
  if(!p.isValid||p.dimension.id!==originDimension||!(p.getComponent('minecraft:health')?.currentValue>0))return;
  warGodAttackFx(p,d,i);
  for(const t of cone(p,d)){if(hit(p,t,d.damagePerHit*mult)){impact(p,t,d.kick);if(i===d.hits-1){const direction=flatDir(p);knockback(t,direction.x,direction.z,d.kick?2.1:1.1,.2);try{applyStatus(t,'slowness',d.kick?20:10,{amplifier:1,showParticles:false});}catch{}}}}
  i++;
 };
 pulse();for(let n=1;n<d.hits;n++)system.runTimeout(pulse,n*d.interval);return true;
}
// All waves of one cast share one boost reservation and one lifecycle.
export function fanAttack(p,job,d){
 const dim=p.dimension;
 const motion=projectileMotion(p,d.speed,3);
 const rays=[],waves=d.waves??1;let launched=0,age=0;
 const hitsByTarget=new Map();
 const launch=()=>{
  const origin={...headPos(p)},aim=norm3(p.getViewDirection());
  const right=Math.hypot(aim.x,aim.z)<.001?{x:1,y:0,z:0}:norm3({x:-aim.z,y:0,z:aim.x});
  const hand=launched%2?1:-1;
  let start=origin, reach=d.range;
  if(d.alternatingArms)start={x:origin.x+right.x*hand*.45,y:origin.y-.25,z:origin.z+right.z*hand*.45};
  if(d.shotgun){
   // Put the burst in view, keeping the original origin when a nearby foe
   // or a wall would otherwise sit between the player and the launch point.
   const lead=.65;
   const forward={x:origin.x+aim.x*lead,y:origin.y+aim.y*lead,z:origin.z+aim.z*lead};
   if(clearBlockPath(dim,origin,forward)&&!getTargets(p,origin,lead+d.hitRadius,.9).some(t=>valid(p,t))){
    start=forward;
    reach-=lead;
   }
   particle(dim,'rpg:war_god_shockwave',start,strikeAxis(aim.x,aim.y,aim.z));
   sound(dim,'random.explode',start,{volume:.64,pitch:1.45});
  }
  const directions=d.shotgun?shotgunDirections(aim,flatDir(p),d.projectiles,d.spread):[aim];
  for(const dir of directions){
   rays.push({dir,aim,axis:strikeAxis(dir.x,dir.y,dir.z),origin:start,reach,travel:0,active:true});
  }
  particle(dim,'rpg:war_god_burst',start);
  sound(dim,'mob.blaze.shoot',start,{volume:.65,pitch:d.alternatingArms?1.1:1.5});launched++;
 };
 const reservation={},boosted=p.getDynamicProperty(BLACK_FLASH_KEY)===true&&!fanBoostReservations.has(p.id);
 if(boosted)fanBoostReservations.set(p.id,reservation);
 let consumed=false;
 const finish=()=>{if(fanBoostReservations.get(p.id)===reservation)fanBoostReservations.delete(p.id);system.clearRun(timer);};
 launch();
 const timer=system.runInterval(()=>{
  try{
   if(!p.isValid||p.dimension.id!==dim.id||!(p.getComponent('minecraft:health')?.currentValue>0)){finish();return;}
   if(isTimeFrozen(p))return;
   age++;if(launched<waves&&age>=launched*(d.waveInterval??1))launch();
   for(const ray of rays){
    if(!ray.active)continue;
    let trail, end;
    for(let sub=0;sub<motion.steps&&ray.active;sub++){
     const remaining=ray.reach-ray.travel;if(remaining<=0){ray.active=false;break;}
     ray.travel+=Math.min(motion.step,remaining);
     const point={x:ray.origin.x+ray.dir.x*ray.travel,y:ray.origin.y+ray.dir.y*ray.travel,z:ray.origin.z+ray.dir.z*ray.travel};
     if(isSolidAt(dim,point)){
      ray.active=false;
      if(d.shotgun)particle(dim,FLURRY_SPARK,end??ray.origin);
      else particle(dim,'rpg:war_god_burst',point);
      break;
     }
     end=point;
     if(sub===Math.floor(motion.steps/2)||ray.travel>=ray.reach){
      if(d.shotgun)trail=point;
      else particle(dim,'rpg:war_god_fan_wave',point,ray.axis);
     }
     const targets=getTargets(p,point,d.hitRadius,.9).filter(t=>{
      if(!valid(p,t))return false;
      const body={...t.location,y:t.location.y+.9},dx=body.x-ray.origin.x,dz=body.z-ray.origin.z;
      if(Math.hypot(dx,dz)>d.range+.001)return false;
      return !d.shotgun||((dx*ray.aim.x+(body.y-ray.origin.y)*ray.aim.y+dz*ray.aim.z)>=0&&clearBlockPath(dim,point,body));
     });
     targets.sort((a,b)=>Math.hypot(a.location.x-point.x,a.location.z-point.z)-Math.hypot(b.location.x-point.x,b.location.z-point.z));
     const target=targets[0];
     if(target){
      ray.active=false;
      if(d.shotgun)particle(dim,FLURRY_SPARK,point);
      const count=hitsByTarget.get(target.id)??0;
      if((d.maxHits===undefined||count<d.maxHits)&&hit(p,target,d.damage*(boosted?2:1))){
       if(d.maxHits!==undefined)hitsByTarget.set(target.id,count+1);
       if(!d.shotgun)impact(p,target,false);
       if(boosted&&!consumed){consumed=true;if(p.getDynamicProperty(BLACK_FLASH_KEY)===true)p.setDynamicProperty(BLACK_FLASH_KEY,undefined);notify(p,'§4천멸격! §f'+d.name+' 피해 ×2');}
      }
     }
     if(ray.travel>=ray.reach)ray.active=false;
    }
    if(d.shotgun&&end){
     if(trail&&trail!==end)particle(dim,FLURRY_SPARK,trail);
     particle(dim,FLURRY_SHARD,end,ray.axis);
    }
   }
   if(launched===waves&&rays.every(ray=>!ray.active))finish();
  }catch{finish();}
 },1);return true;
}
export function armBlackFlash(p){
 if(p.getDynamicProperty(BLACK_FLASH_KEY)===true||fanBoostReservations.has(p.id)){notify(p,'§7이미 천멸격이 준비되어 있습니다.');return false;}
 p.setDynamicProperty(BLACK_FLASH_KEY,true);particle(p.dimension,'rpg:war_god_finale',headPos(p));notify(p,'§c천멸격 준비 · 다음 스킬 ×2');sound(p.dimension,'mob.wither.spawn',p.location,{volume:.5,pitch:1.8});return true;
}
export function applyBlackFlash(){}
export const RUNNERS={war_god_punch:attack,war_god_slash:attack,war_god_flurry:fanAttack,war_god_eight_punch:fanAttack,war_god_kick:attack,war_god_kick_flurry:attack,war_god_black_flash:armBlackFlash};
let registered=false;export function registerWarGod(){if(registered)return;registered=true;}
