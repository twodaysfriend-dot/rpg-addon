import {deferStoppedDamage,isTimeFrozen} from '../core/timeStopDamage.js';
import {setCombatHealth} from '../core/combatContext.js';
import {applyStatus,ccTicks,ccScale} from '../core/crowdControl.js';
import {warGodAttackFx,warGodImpactFx,warGodFinaleFx} from './warGodFx.js';
import {world,system,EntityDamageCause} from '@minecraft/server';
import {getTargets,flatDir,headPos,norm3,isSolidAt,knockback,particle,sound,heldItemId} from '../core/util.js';
import {skillDamageFor} from '../core/stats.js';
import {scriptedHit,currentScriptHit,rememberScriptKiller,noteManualDamage,setBasicHitHandler,BLACK_FLASH_KEY} from '../core/combatContext.js';
import {healLifesteal} from '../core/lifesteal.js';
import {areAllies} from '../core/social.js';
import {CONFIG} from '../config.js';
import {notify} from '../core/hud.js';
export {BLACK_FLASH_KEY};
const fanBoostReservations=new Map();
function valid(p,t){return t&&t.id!==p.id&&!areAllies(p,t)&&!['minecraft:armor_stand','minecraft:item','minecraft:xp_orb'].includes(t.typeId)&&(!t.typeId.startsWith('rpg:hito_'))&&(t.typeId!=='minecraft:player'||(CONFIG.pvp&&!['creative','spectator'].includes(String(t.getGameMode?.()).toLowerCase())));}
function cone(p,def){
 const origin=p.location,dir=flatDir(p);return getTargets(p,{x:origin.x,y:origin.y+1,z:origin.z},def.range+1,.9).filter(t=>{
  if(!valid(p,t))return false;const dx=t.location.x-origin.x,dz=t.location.z-origin.z,along=dx*dir.x+dz*dir.z,side=Math.abs(dx*dir.z-dz*dir.x);
  if(along<0||along>def.range||side>def.width||Math.abs(t.location.y-origin.y)>3)return false;
  for(let step=.5;step<Math.hypot(dx,dz);step+=.5){const distance=Math.hypot(dx,dz)||1;if(isSolidAt(p.dimension,{x:origin.x+dx/distance*step,y:origin.y+1,z:origin.z+dz/distance*step}))return false;}
  return true;
 }).slice(0,8);
}
function hit(p,t,damage){
 return scriptedHit(t,p,()=>{
  const amount=skillDamageFor(p,damage,'physical');
  if(deferStoppedDamage(t,p,amount))return true;
  try{if(t.applyDamage(amount,{cause:EntityDamageCause.override,damagingEntity:p})!==false)return true;}catch{}
  const hp=t.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return false;
  if(amount>=hp.currentValue)rememberScriptKiller(p,t);const before=hp.currentValue;setCombatHealth(t,p,hp,Math.max(0,before-amount));noteManualDamage(p,t,Math.min(before,amount));return true;
 });
}
function impact(p,t,kick){
 const at={x:t.location.x,y:t.location.y+1,z:t.location.z};particle(p.dimension,'minecraft:critical_hit_emitter',at);warGodImpactFx(p,t);sound(p.dimension,'mob.irongolem.hit',at,{volume:.6,pitch:kick ? 0.7 : 1.1});
}
export function attack(p,j,d){
 const targets=cone(p,d);if(!targets.length){notify(p,'§7전방에 공격할 적이 없습니다.');return false;}
 const boosted=p.getDynamicProperty(BLACK_FLASH_KEY)===true&&!fanBoostReservations.has(p.id);let mult=1;if(boosted){p.setDynamicProperty(BLACK_FLASH_KEY,undefined);mult=3;notify(p,'§4천멸격! §f스킬 피해 ×3');sound(p.dimension,'mob.wither.spawn',p.location,{volume:.4,pitch:1.6});}
 const originDimension=p.dimension.id;let i=0;
 const pulse=()=>{
  if(!p.isValid||p.dimension.id!==originDimension||!(p.getComponent('minecraft:health')?.currentValue>0))return;
  warGodAttackFx(p,d,i);
  for(const t of cone(p,d)){if(hit(p,t,d.damagePerHit*mult)){impact(p,t,d.kick);if(i===d.hits-1){const direction=flatDir(p);knockback(t,direction.x,direction.z,d.kick?2.1:1.1,.2);try{applyStatus(t,'slowness',d.kick?20:10,{amplifier:1,showParticles:false});}catch{}}}}
  i++;
 };
 pulse();for(let n=1;n<d.hits;n++)system.runTimeout(pulse,n*d.interval);return true;
}
// Eight visible travelling waves share one hit ledger: no shotgun stacking.
export function fanAttack(p,job,d){
 const dim=p.dimension,origin={...headPos(p)},aim=norm3(p.getViewDirection());
 let right=norm3({x:-aim.z,y:0,z:aim.x});if(Math.hypot(aim.x,aim.z)<.001)right={x:1,y:0,z:0};
 const rays=Array.from({length:d.projectiles},(_,i)=>{const a=(i/(d.projectiles-1)-.5)*d.spread;return {dir:norm3({x:aim.x*Math.cos(a)+right.x*Math.sin(a),y:aim.y*Math.cos(a),z:aim.z*Math.cos(a)+right.z*Math.sin(a)}),travel:0,active:true};});
 const hitIds=new Set(),reservation={},boosted=p.getDynamicProperty(BLACK_FLASH_KEY)===true&&!fanBoostReservations.has(p.id);
 if(boosted)fanBoostReservations.set(p.id,reservation);
 let consumed=false;
 const finish=()=>{if(fanBoostReservations.get(p.id)===reservation)fanBoostReservations.delete(p.id);system.clearRun(timer);};
 sound(dim,'mob.blaze.shoot',origin,{volume:.9,pitch:1.2});
 const timer=system.runInterval(()=>{
  try{
   if(!p.isValid||p.dimension.id!==dim.id||!(p.getComponent('minecraft:health')?.currentValue>0)){finish();return;}
   if(isTimeFrozen(p))return;
   for(const ray of rays){
    if(!ray.active)continue;
    for(let sub=0;sub<3&&ray.active;sub++){
     const remaining=d.range-ray.travel;if(remaining<=0){ray.active=false;break;}
     ray.travel+=Math.min(d.speed/3,remaining);
     const point={x:origin.x+ray.dir.x*ray.travel,y:origin.y+ray.dir.y*ray.travel,z:origin.z+ray.dir.z*ray.travel};
     if(isSolidAt(dim,point)){ray.active=false;particle(dim,'rpg:war_god_burst',point);break;}
     if(sub===1||ray.travel>=d.range)particle(dim,'rpg:war_god_fan_wave',point);
     const targets=getTargets(p,point,d.hitRadius,.9).filter(t=>valid(p,t)&&Math.hypot(t.location.x-origin.x,t.location.z-origin.z)<=d.range+.001);
     targets.sort((a,b)=>Math.hypot(a.location.x-point.x,a.location.z-point.z)-Math.hypot(b.location.x-point.x,b.location.z-point.z));
     const target=targets[0];
     if(target){
      ray.active=false;
      if(!hitIds.has(target.id)){
       hitIds.add(target.id);
       if(hit(p,target,d.damage*(boosted?3:1))){impact(p,target,false);
        if(boosted&&!consumed){consumed=true;p.setDynamicProperty(BLACK_FLASH_KEY,undefined);if(fanBoostReservations.get(p.id)===reservation)fanBoostReservations.delete(p.id);notify(p,'§4천멸격! §f난식 피해 ×3');}
       }
      }
     }
     if(ray.travel>=d.range)ray.active=false;
    }
   }
   if(rays.every(ray=>!ray.active))finish();
  }catch{finish();}
 },1);return true;
}
export function armBlackFlash(p){
 if(p.getDynamicProperty(BLACK_FLASH_KEY)===true||fanBoostReservations.has(p.id)){notify(p,'§7이미 천멸격이 준비되어 있습니다.');return false;}
 p.setDynamicProperty(BLACK_FLASH_KEY,true);notify(p,'§c천멸격 준비 · 다음 스킬 ×3');sound(p.dimension,'mob.wither.spawn',p.location,{volume:.5,pitch:1.8});return true;
}
export function applyBlackFlash(){}
export const RUNNERS={war_god_punch:attack,war_god_flurry:fanAttack,war_god_kick:attack,war_god_kick_flurry:attack,war_god_black_flash:armBlackFlash};
let registered=false;export function registerWarGod(){if(registered)return;registered=true;}
