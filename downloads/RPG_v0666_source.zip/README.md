# RPG v0.6.66 · RPG 갑옷 내구도 및 수선 상향

모험가, 숲 수호자, 별빛 술사, 심연 수호자 갑옷의 모든 부위가 이전 최대 내구도의 4배를 가집니다. 심연 수호자 흉갑은 800에서 3,200으로 증가합니다.

RPG 갑옷의 수선 회복량은 베드락 기본값의 4배입니다. 기본 수선으로 내구도 2를 회복하면 애드온이 6을 추가합니다. 회복량은 최대 내구도까지 적용됩니다.

Bedrock 1.21.100 이상에서 세 팩을 v0.6.66으로 활성화하세요.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0666
```
