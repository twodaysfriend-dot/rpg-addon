import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0632');
const bp=path.join(root,'RPG_BP_v0632/scripts');
const signals=new Map();function signal(key){if(!signals.has(key))signals.set(key,{callbacks:[],subscribe(fn){this.callbacks.push(fn);},fire(e){for(const fn of this.callbacks)fn(e);}});return signals.get(key);}
const events=new Proxy({},{get:(o,k)=>signal(k)});let time=1000;
const world={afterEvents:events,beforeEvents:{},getTimeOfDay:()=>time,getAllPlayers:()=>[],getDay:()=>1,getDynamicProperty:()=>undefined};
const timers=[];const system={currentTick:10,beforeEvents:events,afterEvents:events,run:fn=>{timers.push(fn);return timers.length;},runTimeout:fn=>{timers.push(fn);return timers.length;},runInterval:()=>1,clearRun:()=>{}};
class ItemStack{
 constructor(id,amount=1){this.typeId=id;this.amount=amount;this.props=new Map();this.lore=[];this.lockMode='none';this.keepOnDeath=false;this.durability={damage:0,maxDurability:1600};}
 clone(){const n=new ItemStack(this.typeId,this.amount);n.props=new Map(this.props);n.lore=[...this.lore];n.nameTag=this.nameTag;n.lockMode=this.lockMode;n.keepOnDeath=this.keepOnDeath;n.durability={...this.durability};return n;}
 get amount(){return this._amount;}set amount(n){if(!Number.isInteger(n)||n<1||n>64)throw Error('Native ItemStack amount must stay in 1..64');this._amount=n;}
 getDynamicProperty(k){return this.props.get(k);}setDynamicProperty(k,v){if(v===undefined)this.props.delete(k);else this.props.set(k,v);}getDynamicPropertyIds(){return [...this.props.keys()];}getLore(){return this.lore;}setLore(v){this.lore=v;}getComponent(id){if(id==='minecraft:durability')return this.durability;if(id==='minecraft:enchantable')return {getEnchantments:()=>[]};}
}
class Form{title(){return this;}body(){return this;}button(){return this;}button1(){return this;}button2(){return this;}show(){return Promise.resolve({canceled:true});}}
const server={world,system,ItemStack,ItemLockMode:{slot:'slot',none:'none'},EquipmentSlot:{Mainhand:'Mainhand',Offhand:'Offhand',Head:'Head',Chest:'Chest',Legs:'Legs',Feet:'Feet'},EntityDamageCause:{override:'override',entityAttack:'entityAttack'},CustomCommandStatus:{Success:0,Failure:1},CommandPermissionLevel:{Any:0,GameDirectors:1},CustomCommandParamType:{String:0,Integer:1},BlockTypes:{get:id=>({id})}};
const ui={ActionFormData:Form,MessageFormData:Form,ModalFormData:Form};
const context=vm.createContext({console});const modules=new Map(),externalNames=new Map();
function discover(file){file=path.resolve(file);if(modules.has(file))return;const source=fs.readFileSync(file,'utf8');const m=new vm.SourceTextModule(source,{context,identifier:file});modules.set(file,m);
 for(const hit of source.matchAll(/import\s+(?:\{([^}]+)\}|\*\s+as\s+\w+)\s*from\s*['"]([^'"]+)['"]/g)){
  const spec=hit[2];if(spec.startsWith('.'))discover(path.resolve(path.dirname(file),spec));else{const names=externalNames.get(spec)??new Set();for(const n of (hit[1]??'').split(',').filter(Boolean))names.add(n.trim().split(/\s+as\s+/)[0]);externalNames.set(spec,names);}
 }
}
const wingsOnly=process.argv.includes('--gameplay-only-wings');
const commandPack=path.join(root,'RPG_Commands_BP_v0632/scripts/commands.js');
discover(path.join(bp,'gameplayEntry.js'));if(!wingsOnly){discover(path.join(bp,'commandBootstrap.js'));discover(commandPack);}
for(const [spec,names]of externalNames){const values=spec==='@minecraft/server'?server:ui;for(const n of Object.keys(values))names.add(n);const m=new vm.SyntheticModule([...names],function(){for(const n of names)this.setExport(n,values[n]??{});},{context,identifier:spec});modules.set(spec,m);}
const linker=(spec,parent)=>modules.get(spec.startsWith('.')?path.resolve(path.dirname(parent.identifier),spec):spec);
for(const m of modules.values())if(m.status==='unlinked')await m.link(linker);
for(const entry of (wingsOnly?['gameplayEntry.js']:['gameplayEntry.js','commandBootstrap.js']))await modules.get(path.join(bp,entry)).evaluate();
if(!wingsOnly)await modules.get(commandPack).evaluate();
const mod=file=>modules.get(path.join(bp,file)).namespace;
console.log('Complete active gameplay and command module graph linked/evaluated');
function player(job='swordsman'){
 const props=new Map([['rpg:job',job]]),items=Array(12),messages=[],tags=new Set();
 const inv={size:12,getItem:i=>items[i]?.clone(),setItem:(i,v)=>{items[i]=v?.clone();},addItem:item=>{const i=items.findIndex(x=>!x);if(i<0)return item;items[i]=item.clone();}};
 const health={currentValue:50,effectiveMax:100,setCurrentValue(v){const old=this.currentValue;this.currentValue=v;signal('entityHealthChanged').fire({entity:p,oldValue:old,newValue:v});}};
 const dim={id:'minecraft:overworld',getWeather:()=> 'Clear',getTopmostBlock:()=>({location:{y:63}}),spawnItem:()=>{throw Error('unexpected item drop');},playSound:()=>{}};
 const p={id:'player',name:'tester',typeId:'minecraft:player',isValid:true,selectedSlotIndex:0,location:{x:0,y:64,z:0},dimension:dim,onScreenDisplay:{setTitle:()=>{},setActionBar:()=>{}},getHeadLocation:()=>({x:0,y:65.6,z:0}),getGameMode:()=> 'survival',getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>{if(v===undefined)props.delete(k);else props.set(k,v);},getDynamicPropertyIds:()=>[...props.keys()],getComponent:id=>id==='minecraft:inventory'?{container:inv}:id==='minecraft:health'?health:id==='minecraft:equippable'?{getEquipment:()=>inv.getItem(p.selectedSlotIndex),setEquipment:(slot,item)=>{inv.setItem(p.selectedSlotIndex,item);return true;}}:undefined,hasTag:t=>tags.has(t),addTag:t=>tags.add(t),removeTag:t=>tags.delete(t),getTags:()=>[...tags],sendMessage:s=>messages.push(s),getEffect:()=>undefined};
 return {p,props,items,inv,health,messages};
}
if(wingsOnly){
 const registry=new Map();
 signal('startup').fire({itemComponentRegistry:{registerCustomComponent:()=>{}},customCommandRegistry:{registerCommand:(d,fn)=>{assert.ok(d.name.includes(':'));assert.ok(!registry.has(d.name));registry.set(d.name,{d,fn});}}});
 const wings=mod('core/wings.js');
 for(const job of ['angel','michael']){
  const {p}=player(job);p.id='standalone-'+job;
  p.runCommand=()=>{throw Error('Commands BP is absent and no relay is allowed');};
  for(const [mode,multiplier]of [[1,1],[2,2],[3,5]]){
   const parsed=registry.get('rpg:wings');assert.equal(parsed.d.optionalParameters[0].type,server.CustomCommandParamType.Integer);
   parsed.fn({sourceEntity:p},mode);timers.at(-1)();assert.equal(wings.wingSpeedMultiplier(p),multiplier);
   const fixed=registry.get('rpg:wings'+mode);assert.equal(fixed.d.optionalParameters,undefined);
   fixed.fn({sourceEntity:p});timers.at(-1)();assert.equal(wings.wingSpeedMultiplier(p),multiplier);
  }
 }
 assert.equal(registry.size,5);
 console.log('Standalone gameplay BP manifest entry registers all five wing commands, integer and argument-free modes work without Commands BP or legacy bootstrap');
 process.exit(0);
}
{
 const social=mod('core/social.js'),oldRead=world.getDynamicProperty,oldOnline=world.getAllPlayers;
 const owner=player().p,editor=player().p;owner.id='shared-owner';owner.name='Owner';editor.id='shared-editor';editor.name='Editor';
 const outsider=player().p;outsider.id='outsider-id';outsider.name='SharedGuest';
 const partyEditor=player().p;partyEditor.id='party-editor';partyEditor.name='PartyEditor';
 const saved={version:1,nextId:4,guilds:[{id:1,name:'Guild',leader:'Owner',members:['Owner','Editor']},{id:2,name:'OtherGuild',leader:'SharedGuest',members:['SharedGuest']}],parties:[{id:3,leader:'Owner',members:['Owner','PartyEditor']}]};
 world.getDynamicProperty=key=>key==='rpg:social_v1'?JSON.stringify(saved):oldRead(key);world.getAllPlayers=()=>[];
 // This is the first social state load: it must use the persisted roster even offline.
 assert.equal(social.sharesBuildingGroup(editor,{id:owner.id,name:owner.name}),true);
 assert.equal(social.sharesBuildingGroup(outsider,{id:owner.id,name:owner.name}),false);
 const estate=mod('core/realEstate.js'),town=mod('core/townProtection.js'),region={x:0,y:64,z:0,size:250,dimId:owner.dimension.id};
 const block={dimension:owner.dimension,location:{x:32,y:70,z:32}};
 const selection=estate.landSelection({dimension:block.dimension,location:block.location},region);
 const oldProps=world.getDynamicProperty,land=JSON.stringify({[selection.key]:{id:owner.id,name:owner.name}});
 world.getDynamicProperty=key=>key===estate.LAND_KEY?land:oldProps(key);
 assert.equal(estate.canEditTownChunk(partyEditor,block,region),true);
 outsider.addTag('rpg_guild_1');outsider.addTag('rpg_team_test');assert.equal(estate.canEditTownChunk(outsider,block,region),false);
 assert.equal(estate.canEditTownChunk(editor,block,region),true);assert.equal(estate.ownsTownChunk(editor,block,region),false);
 assert.equal(town.townProtected(block,region,editor),false);assert.equal(town.townProtected(block,region,outsider),true);
 for(const y of [64,63,-64])assert.equal(town.townProtected({...block,location:{...block.location,y}},region,editor),true);
 assert.equal(town.townProtected({...block,location:{...block.location,y:64}},region,editor,'support'),false);
 // Exercise real leave-group UI. Mutate serializes and replaces cached social state.
 const oldShow=Form.prototype.show,oldWrite=world.setDynamicProperty;let serialized;
 world.setDynamicProperty=(key,value)=>{if(key==='rpg:social_v1')serialized=value;};
 try{
  const replies=[{selection:2},{selection:1},{canceled:true}]; // member's guild page: members, base travel, leave
  Form.prototype.show=()=>Promise.resolve(replies.shift()??{canceled:true});await social.openGuildMenu(editor);
  assert.ok(serialized);assert.equal(social.sharesBuildingGroup(editor,{id:owner.id,name:owner.name}),false);
  assert.equal(estate.canEditTownChunk(editor,block,region),false);
  assert.equal(estate.canEditTownChunk(partyEditor,block,region),true);
  const partyReplies=[{selection:1},{selection:1},{canceled:true}];Form.prototype.show=()=>Promise.resolve(partyReplies.shift()??{canceled:true});await social.openPartyMenu(partyEditor);
  assert.equal(estate.canEditTownChunk(partyEditor,block,region),false);
  assert.equal(estate.canEditTownChunk(owner,block,region),true);
 }finally{Form.prototype.show=oldShow;world.setDynamicProperty=oldWrite;world.getDynamicProperty=oldRead;world.getAllPlayers=oldOnline;}
 console.log('Shared building: saved guild membership grants offline-owner access; real guild/party leave immediately revokes edits; unrelated guild and forged tags excluded; guests rejected and floor/underground stay protected');
}
const races=mod('core/races.js'),data=mod('core/playerData.js'),jobs=mod('data/jobs.js').JOBS,binding=mod('core/weaponBinding.js'),advance=mod('core/advance.js');
{
 const {p,inv}=player();assert.equal(races.raceOf(p),'human');inv.setItem(0,new ItemStack('rpg:stone_mask',2));assert.equal(races.useStoneMask(p).ok,true);assert.equal(inv.getItem(0).amount,1);assert.equal(races.raceOf(p),'vampire');assert.equal(races.useStoneMask(p).ok,false);assert.equal(inv.getItem(0).amount,1);
 assert.equal(races.sunDamageMultiplier(p),1.5);p.dimension.getTopmostBlock=()=>({location:{y:70}});assert.equal(races.sunDamageMultiplier(p),1);p.dimension.getTopmostBlock=()=>({location:{y:63}});time=13000;assert.equal(races.sunDamageMultiplier(p),1);time=1000;
 data.setJobId(p,'mage');assert.equal(races.raceOf(p),'human');data.setJobId(p,'blood_mage');assert.equal(races.raceOf(p),'vampire');data.setJobId(p,'revenant');assert.equal(races.raceOf(p),'undead');
}
console.log('Races: mask consumption, redundant use, daylight/shade/night, job resets passed');
{
 const {p,inv}=player();inv.setItem(0,new ItemStack(jobs.swordsman.weapon));const w=new ItemStack('rpg:common_redmoon_blade');w.setDynamicProperty('rpg:weapon_upgrade',5);w.setDynamicProperty('rpg:rarity','epic');w.nameTag='chosen';w.durability.damage=123;inv.setItem(4,w);
 assert.equal(binding.bindCommonWeapon(p,4).ok,true);assert.equal(inv.getItem(0).nameTag,'chosen');assert.equal(inv.getItem(4).typeId,jobs.swordsman.weapon);const uid=inv.getItem(0).getDynamicProperty(binding.WEAPON_UID);
 advance.applyAdvance(p,jobs.sword_saint);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);assert.equal(inv.getItem(0).durability.damage,123);assert.equal(mod('core/context.js').getContext(p).substitute,true);assert.equal(mod('core/util.js').skillItemId(p),jobs.sword_saint.weapon);
 advance.applyAdvance(p,jobs.mage);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);assert.equal(mod('core/context.js').getContext(p).job.id,'mage');
 const upgraded=mod('core/gearState.js').setGearLevel(inv.getItem(0),'weapon',6);inv.setItem(0,upgraded);advance.ensureWeapon(p);assert.equal(inv.getItem(0).getDynamicProperty('rpg:weapon_upgrade'),6);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);
 const slot1=inv.getItem(0);inv.setItem(0,undefined);inv.setItem(8,slot1);advance.ensureWeapon(p);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);assert.equal(inv.getItem(8),undefined);
 inv.setItem(0,undefined);advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,jobs.mage.weapon);assert.equal(binding.weaponBinding(p),undefined);
}
console.log('Weapon binding: metadata/upgrade preservation, both advancements, job switch, moved-item recovery, break fallback passed');
{
 const {p,inv}=player();inv.setItem(0,new ItemStack(jobs.swordsman.weapon));inv.setItem(3,new ItemStack('rpg:common_redmoon_blade'));binding.bindCommonWeapon(p,3);data.setJobId(p,'the_world');data.setSkills(p,jobs.the_world.skills);assert.equal(mod('core/context.js').getContext(p).job.id,'the_world');
 binding.releaseWeaponBinding(p);advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,jobs.the_world.weapon);assert.equal(Array.from({length:inv.size},(_,i)=>inv.getItem(i)).filter(i=>i?.typeId==='rpg:common_redmoon_blade').length,1);
}
console.log('Weapon release preserves exactly one original common weapon');
{
 const {p,health}=player('the_world');const target={id:'enemy',typeId:'minecraft:zombie'};const life=mod('core/lifesteal.js');assert.equal(life.healLifesteal(p,target,20),2);health.currentValue=99;assert.equal(life.healLifesteal(p,target,20),1);data.setJobId(p,'swordsman');assert.equal(life.healLifesteal(p,target,20),0);
 const amounts=mod('core/damageAmounts.js');amounts.noteHealthChange({entity:target,oldValue:3,newValue:0});assert.equal(amounts.actualHurtAmount({hurtEntity:target,damage:100}),3);
}
console.log('Vampire 10% actual-damage lifesteal and overheal/overkill cap passed');
{
 const {p,messages}=player('mage');const trial=mod('core/jobTrials.js');for(let i=0;i<55;i++)trial.recordJobTrialKill(p,{typeId:'minecraft:stray'});assert.equal(messages.length,6);assert.equal(messages[0],'§r§l§b(???/50)');assert.equal(messages[5],'§r§l§b(50/50)');messages.length=0;for(let i=0;i<55;i++)trial.recordJobTrialKill(p,{typeId:'minecraft:blaze'});assert.equal(messages.length,6);assert.equal(messages[5],'§r§l§6(50/50)');
}
console.log('Stray/Blaze counters: exactly 1/10/20/30/40/50 announcements, colors and completion passed');
{
 const {p,inv}=player();mod('core/wallet.js').setWallet(p,{gold:10000000,stone:100000,dust:1000});inv.setItem(0,new ItemStack(jobs.swordsman.weapon));inv.setItem(5,new ItemStack('rpg:common_redmoon_blade'));binding.bindCommonWeapon(p,5);
 const uid=inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),upgrade=mod('core/upgrades.js');let quote=upgrade.enhancementQuote(p,'weapon','Mainhand');let result=upgrade.enhanceEquipped(p,'weapon','Mainhand',quote.fingerprint,{random:()=>0});assert.equal(result.ok,true);assert.equal(result.outcome,'success');assert.equal(inv.getItem(0).getDynamicProperty('rpg:weapon_upgrade'),1);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);
 inv.setItem(0,mod('core/gearState.js').setGearLevel(inv.getItem(0),'weapon',9));quote=upgrade.enhancementQuote(p,'weapon','Mainhand');result=upgrade.enhanceEquipped(p,'weapon','Mainhand',quote.fingerprint,{random:()=>.999});assert.equal(result.outcome,'destroy');advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,jobs.swordsman.weapon);assert.equal(binding.weaponBinding(p),undefined);
}
console.log('Actual upgrade transaction: success stays in slot 1, destruction restores class item passed');
{
 const {p,health}=player('cleric');health.currentValue=50;
 const target={id:'mob',typeId:'minecraft:zombie',isValid:true,location:{x:0,y:64,z:1},getTags:()=>[],getComponent:id=>id==='minecraft:health'?{currentValue:100}:undefined,applyDamage(amount){this.damage=amount;return true;}};
 const holy=mod('skills/holy.js');assert.equal(holy.holyMonsterDamage(p,target,20),true);assert.equal(target.damage,60);assert.equal(holy.holyMonsterDamage(p,p,20),false);
 const allyHeal=mod('core/holyRecovery.js').healHolyAlly(p,p,20);assert.equal(allyHeal,20);assert.equal(health.currentValue,70);
}
console.log('Holy healing: monster takes exactly healing x3, allied healing remains unchanged');
function filter(f,monster,sun){if(f.all_of)return f.all_of.every(x=>filter(x,monster,sun));if(f.any_of)return f.any_of.some(x=>filter(x,monster,sun));const val=f.test==='is_family'?monster:sun;return f.operator==='!='?!val:val;}
{
 const json=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0632/entities/player.json'),'utf8'))['minecraft:entity'];
 for(const [m,s,expected]of [[true,false,.7],[true,true,1.05],[false,true,1.5],[false,false,1]]){
  const hits=json.components['minecraft:damage_sensor'].triggers.filter(t=>filter(t.on_damage.filters,m,s));assert.equal(hits.length,1);assert.equal(hits[0].damage_multiplier,expected);
  for(const [id,g]of Object.entries(json.component_groups))if(id.startsWith('rpg:ward_defense_')){
   const hits=g['minecraft:damage_sensor'].triggers.filter(t=>filter(t.on_damage.filters,m,s));assert.equal(hits.length,1);const index=Number(id.split('_').at(-1));assert.ok(Math.abs(hits[0].damage_multiplier-(1-index/10*.0035)*expected)<1e-7);
  }
 }
 for(const [id,outer,center]of [['stone_mask_fragment','minecraft:stone','minecraft:gold_block'],['stone_mask','rpg:stone_mask_fragment','minecraft:netherite_ingot']]){
  const recipe=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0632/recipes/'+id+'.json'),'utf8'))['minecraft:recipe_shaped'];assert.deepEqual(recipe.pattern,['FFF','FCF','FFF']);assert.equal(recipe.key.F.item,outer);assert.equal(recipe.key.C.item,center);assert.equal(recipe.result.count,1);
 }
}
console.log('Damage sensor matrices: monster x0.7, vampire sun x1.5, existing ward multipliers; both exact recipes passed');
const componentHandlers=new Map(),commandDefs=new Map(),allCommandDefs=new Map();
signal('startup').fire({itemComponentRegistry:{registerCustomComponent:(id,handler)=>componentHandlers.set(id,handler)},customCommandRegistry:{registerCommand:(d,fn)=>{if(!/^[a-z0-9_]+:[a-z0-9_]+$/.test(d.name))throw Error('CustomCommand name requires a namespace');commandDefs.set(d.name,{d,fn});const list=allCommandDefs.get(d.name)??[];list.push({d,fn});allCommandDefs.set(d.name,list);}}});
assert.ok(componentHandlers.has('rpg:stone_mask'));assert.ok(componentHandlers.has('rpg:bound_common'));assert.ok(commandDefs.has('rpg:weapon'));assert.equal(commandDefs.get('rpg:weapon').d.permissionLevel,0);
console.log('Startup registration: mask/common item components and public /rpg:weapon passed');
{
 const {p,inv}=player('apprentice');inv.setItem(0,new ItemStack('rpg:apprentice_sword'));inv.setItem(4,new ItemStack('rpg:common_redmoon_blade'));binding.bindCommonWeapon(p,4);assert.equal(mod('core/context.js').getContext(p).substitute,true);inv.setItem(0,undefined);advance.ensureWeapon(p);assert.equal(inv.getItem(0).typeId,'rpg:apprentice_sword');
}
console.log('Apprentice common-weapon break restores the selected starter line');
{
 const {p,inv}=player();for(let i=0;i<inv.size;i++)inv.setItem(i,new ItemStack(i===0?jobs.swordsman.weapon:i===4?'rpg:common_redmoon_blade':'minecraft:stone'));assert.equal(binding.bindCommonWeapon(p,4).ok,true);assert.equal(inv.getItem(4).typeId,jobs.swordsman.weapon);assert.equal(inv.getItem(0).typeId,'rpg:common_redmoon_blade');
 const uid=inv.getItem(0).getDynamicProperty(binding.WEAPON_UID);const props=p.getDynamicProperty(binding.BINDING_KEY);p.setDynamicProperty(binding.BINDING_KEY,props);advance.ensureWeapon(p);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),uid);
 const before=inv.getItem(0);const result=binding.bindCommonWeapon(p,6);assert.equal(result.ok,false);assert.equal(inv.getItem(0).getDynamicProperty(binding.WEAPON_UID),before.getDynamicProperty(binding.WEAPON_UID));
}
console.log('Full-inventory replacement, persisted binding reuse and invalid selection preserve items');
{
 const {p,health}=player('the_world');const life=mod('core/lifesteal.js');life.registerLifesteal();
 const target={id:'lethal_enemy',typeId:'minecraft:zombie',getComponent:id=>id==='minecraft:health'?{currentValue:0,effectiveMax:20}:undefined};
 signal('entityHealthChanged').fire({entity:target,oldValue:3,newValue:0});signal('entityHurt').fire({hurtEntity:target,damage:100,damageSource:{cause:'entityAttack',damagingEntity:p}});
 assert.ok(Math.abs(health.currentValue-50.3)<1e-8);
}
console.log('Native hurt-event path: lethal overkill only heals 10% of remaining enemy HP');
{
 const {p,inv}=player('apprentice');const card=mod('core/chameleonCard.js');assert.equal(advance.checkAdvance(p,jobs.chameleon).ok,false);
 inv.setItem(3,new ItemStack(card.CHAMELEON_CARD));assert.equal(advance.checkAdvance(p,jobs.chameleon).ok,false);p.selectedSlotIndex=3;assert.equal(advance.checkAdvance(p,jobs.chameleon).ok,true);assert.equal(advance.requirementStatus(p,jobs.chameleon).met,true);
 await advance.requestAdvance(p,jobs.chameleon);assert.equal(data.getJobId(p),'chameleon');assert.equal(inv.getItem(3).typeId,card.CHAMELEON_CARD);assert.equal(inv.getItem(3).amount,1);
 const item=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0632/items/chameleon_job_card.json'),'utf8'))['minecraft:item'];assert.equal(item.description.menu_category.category,'items');
 const loot=path.join(root,'RPG_BP_v0632/loot_tables');function find(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?find(path.join(dir,e.name)):[path.join(dir,e.name)]);}for(const f of [...find(loot),...find(path.join(root,'RPG_BP_v0632/recipes'))])assert.ok(!fs.readFileSync(f,'utf8').includes(card.CHAMELEON_CARD));
}
console.log('Chameleon card: actual mainhand required, apprentice transfer without old trials, card retained, no recipe/loot passed');
{
 const {p,inv}=player('mage');data.setSkills(p,jobs.mage.skills);const card=mod('core/chameleonCard.js');inv.setItem(3,new ItemStack(card.CHAMELEON_CARD));p.selectedSlotIndex=3;
 const original=Form.prototype.show;Form.prototype.show=()=>{inv.setItem(3,undefined);return Promise.resolve({canceled:false,selection:0});};await advance.requestAdvance(p,jobs.chameleon);Form.prototype.show=original;assert.equal(data.getJobId(p),'mage');
 const hito=mod('core/hito.js'),line=hito.HITO_LINES.find(l=>l.id==='chameleon');assert.equal(line.label,'구욱');hito.registerHito();const npc={typeId:'rpg:hito_chameleon',nameTag:'카멜레온 전직관'};signal('entitySpawn').fire({entity:npc});timers.at(-1)();assert.equal(npc.nameTag,'구욱');
}
console.log('Chameleon card rechecked after confirmation; NPC name is exactly 구욱');
assert.equal(commandDefs.get('rpg:citycreate').d.permissionLevel,1);assert.equal(commandDefs.get('rpg:citycreate').d.optionalParameters[0].name,'height');
for(const name of ['citystop','cityresume','citystatus','cityreset'])assert.equal(commandDefs.get('rpg:'+name).d.permissionLevel,1);
console.log('City commands are operator-only with optional height');

{
 const {p}=player();const sent=[];p.runCommand=s=>sent.push(s);assert.equal(commandDefs.has('dungeoncreate'),false);
 const canonical=commandDefs.get('rpg:dungeoncreate');canonical.fn({sourceEntity:p},'10');timers.at(-1)();assert.equal(sent[0],'scriptevent rpg:dungeoncreate 10');
}
console.log('Actual Commands BP: /rpg:dungeoncreate 10 forwards the correct tier with admin permissions');
{
 const {p,inv}=player('chameleon');p.setDynamicProperty('rpg:rpg_level',100);inv.setItem(0,new ItemStack(jobs.chameleon.weapon));
 const cham=mod('core/chameleon.js');for(const line of ['the_world','nen']){const group=cham.CHAMELEON_GROUPS.find(g=>g.line===line);assert.ok(group);assert.equal(group.ids.length,jobs[line].skills.length);for(const id of group.ids){const r=cham.learnChameleonSkill(p,id);assert.equal(r.ok,true,r.message);assert.ok(data.getSkills(p).includes(id));}}
 assert.equal(data.getJobId(p),'chameleon');assert.equal(mod('core/races.js').raceOf(p),'human');assert.ok(mod('core/context.js').getContext(p).skills.includes('world_stop'));assert.ok(mod('core/context.js').getContext(p).skills.includes('nen_en'));
 console.log('Chameleon menus: all 6 World and 10 Nen skills actually purchased with SP, usable in context; job/race unchanged');
 const fx=new Map();p.getEffect=id=>fx.get(id);p.addEffect=(id,duration,o)=>fx.set(id,{duration,amplifier:o.amplifier});p.removeEffect=id=>fx.delete(id);
 p.dimension.getEntities=()=>[];p.inputInfo={getMovementVector:()=>({x:0,y:0}),getButtonState:()=>0};p.getRotation=()=>({x:0,y:0});p.clearVelocity=()=>{};p.applyImpulse=()=>{};
 const oldPlayers=world.getAllPlayers;world.getAllPlayers=()=>[p];const tw=mod('skills/theWorld.js');assert.equal(tw.startTheWorld(p),true);system.currentTick++;tw.tickTheWorld();assert.equal(tw.stopTheWorld(p),true);data.setJobId(p,'mage');assert.equal(tw.startTheWorld(p),false);
 data.setJobId(p,'chameleon');let hit=0;const target={id:'nen_target',isValid:true,typeId:'minecraft:zombie',location:{x:0,y:64,z:1},dimension:p.dimension,getTags:()=>[],getComponent:id=>id==='minecraft:health'?{currentValue:500,effectiveMax:500}:undefined,applyDamage:n=>{hit+=n;return true;}};
 const nen=mod('skills/nen.js'),defs=mod('data/skills.js').SKILLS;nen.registerNen();nen.RUNNERS.nen_ko(p,jobs.nen,defs.nen_ko);nen.RUNNERS.nen_shu(p,jobs.nen,defs.nen_shu);
 signal('entityHurt').fire({hurtEntity:target,damage:5,damageSource:{cause:'entityAttack',damagingEntity:p}});assert.equal(hit,70);signal('entityHurt').fire({hurtEntity:target,damage:5,damageSource:{cause:'entityAttack',damagingEntity:p}});assert.equal(hit,80);
 world.getAllPlayers=oldPlayers;console.log('Borrowed World stop survives tick; unlearned mage rejected; borrowed Nen Ko/Shu produce 70 then 10 damage');
}
{
 const {p,inv}=player('apprentice');const card=mod('core/bloodCard.js');assert.equal(advance.checkAdvance(p,jobs.blood_mage).ok,false);p.setDynamicProperty('rpg:progress',JSON.stringify({job_kills:1000}));assert.equal(advance.checkAdvance(p,jobs.blood_mage).ok,false);
 inv.setItem(3,new ItemStack(card.BLOOD_CARD));assert.equal(advance.checkAdvance(p,jobs.blood_mage).ok,false);p.selectedSlotIndex=3;assert.equal(advance.checkAdvance(p,jobs.blood_mage).ok,true);assert.equal(advance.requirementStatus(p,jobs.blood_mage).met,true);await advance.requestAdvance(p,jobs.blood_mage);assert.equal(data.getJobId(p),'blood_mage');assert.equal(inv.getItem(3).typeId,card.BLOOD_CARD);assert.equal(inv.getItem(3).amount,1);assert.equal(mod('core/races.js').raceOf(p),'vampire');
 const item=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0632/items/blood_job_card.json'),'utf8'))['minecraft:item'];assert.equal(item.description.menu_category.category,'items');
 function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}for(const f of [...files(path.join(root,'RPG_BP_v0632/recipes')),...files(path.join(root,'RPG_BP_v0632/loot_tables'))])assert.ok(!fs.readFileSync(f,'utf8').includes(card.BLOOD_CARD));
 console.log('Blood card: creative item only, mainhand needed, old kills not a bypass, apprentice allowed, card retained, vampire race applied');
}
{
 const {p,inv}=player('mage');data.setSkills(p,jobs.mage.skills);inv.setItem(3,new ItemStack('rpg:blood_job_card'));p.selectedSlotIndex=3;const original=Form.prototype.show;Form.prototype.show=()=>{inv.setItem(3,undefined);return Promise.resolve({canceled:false,selection:0});};await advance.requestAdvance(p,jobs.blood_mage);Form.prototype.show=original;assert.equal(data.getJobId(p),'mage');
 const client=JSON.parse(fs.readFileSync(path.join(root,'RPG_RP_v0632/entity/hito_blood.entity.json'),'utf8'))['minecraft:client_entity']['description'];assert.equal(client.geometry.default,'geometry.rpg.blood_master');
 const info=mod('core/worldMastery.js');p.setDynamicProperty(info.WORLD_MASTERY_KEY,25);assert.ok(info.worldMasteryText(p).includes('3.5초'));assert.ok(mod('core/skillGuide.js').skillGuideDetail('world_stop',p).includes('3.5초'));
 console.log('Blood card rechecked after form; blood skin geometry reference and dynamic mastery guide passed');
}

{
 const {p,inv}=player(),funds=mod('core/creativeFunds.js'),w=mod('core/wallet.js');
 assert.equal(funds.grantCreativeFunds(p).ok,false);assert.equal(w.getWallet(p).gold,0);
 p.getGameMode=()=> 'creative';assert.equal(funds.grantCreativeFunds(p).ok,true);assert.equal(w.getWallet(p).gold,w.BALANCE_MAX);assert.equal(w.getWallet(p).stone,w.BALANCE_MAX);assert.equal(w.getWallet(p).dust,w.BALANCE_MAX);
 w.setWallet(p,{gold:1,stone:2,dust:3});assert.equal(funds.grantCreativeFunds(p).ok,true);assert.equal(w.getWallet(p).dust,w.BALANCE_MAX);
 p.getGameMode=()=> 'survival';inv.setItem(0,new ItemStack(funds.CREATIVE_FUNDS_ITEM));w.setWallet(p,{gold:0,stone:0,dust:0});componentHandlers.get('rpg:creative_funds').onUse({source:p});timers.at(-1)();assert.equal(w.getWallet(p).gold,0);
 assert.equal(commandDefs.get('rpg:creativefunds').d.permissionLevel,0);assert.equal(commandDefs.get('rpg:runebatch').d.permissionLevel,0);
 const j=JSON.parse(fs.readFileSync(path.join(root,'RPG_BP_v0632/items/creative_funds.json'),'utf8'))['minecraft:item'];assert.equal(j.description.menu_category.category,'items');assert.ok(j.components['rpg:creative_funds']);
 for(const dir of ['recipes','loot_tables']){const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);for(const f of walk(path.join(root,'RPG_BP_v0632',dir)))assert.ok(!fs.readFileSync(f,'utf8').includes(funds.CREATIVE_FUNDS_ITEM));}
 console.log('Creative supply: creative mode required on command/item routes, all three currencies repeatably refill to 1 billion, forged survival item rejected, no recipe/drop');
}
{
 const {p}=player(),runes=mod('core/runeInventory.js'),batch=mod('core/runeBatch.js'),w=mod('core/wallet.js');
 const bag=runes.readRuneBag(p),added=[];for(const [id,level,grade]of [['power',0,0],['power',2,0],['power',9,0],['power',10,0],['power',0,1],['arcane',0,0]])added.push(runes.addRuneRecord(bag,id,level,grade));bag.equipped[0]=added[0].uid;runes.writeRuneBag(p,bag);w.setWallet(p,{gold:100000,stone:20,dust:1000});
 const q=batch.runeBatchQuote(p,'power',0);assert.equal(q.count,3);assert.equal(q.total,4);assert.equal(q.cost.dust,10);const draws=[0,.99,.999];const res=batch.executeRuneBatch(p,'power',0,q.fingerprint,{random:()=>draws.shift()});assert.equal(res.ok,true,res.reason);assert.equal(res.counts.success,1);assert.equal(res.counts.downgrade,1);assert.equal(res.counts.destroy,1);
 const after=runes.readRuneBag(p);assert.equal(after.runes.find(r=>r.uid===added[0].uid).level,1);assert.equal(after.runes.find(r=>r.uid===added[1].uid).level,1);assert.equal(after.runes.some(r=>r.uid===added[2].uid),false);assert.equal(after.runes.find(r=>r.uid===added[3].uid).level,10);assert.equal(after.runes.find(r=>r.uid===added[4].uid).level,0);assert.equal(after.runes.find(r=>r.uid===added[5].uid).level,0);assert.equal(after.equipped[0],added[0].uid);assert.equal(w.getWallet(p).gold,100000-q.cost.gold);assert.equal(w.getWallet(p).dust,1000-q.cost.dust);
 const stale=batch.runeBatchQuote(p,'power',0);after.runes[0].level++;runes.writeRuneBag(p,after);const snap=JSON.stringify(runes.readRuneBag(p));assert.equal(batch.executeRuneBatch(p,'power',0,stale.fingerprint).ok,false);assert.equal(JSON.stringify(runes.readRuneBag(p)),snap);
 const current=batch.runeBatchQuote(p,'power',0);w.setWallet(p,{gold:0,stone:0,dust:0});assert.equal(batch.executeRuneBatch(p,'power',0,current.fingerprint).ok,false);assert.equal(JSON.stringify(runes.readRuneBag(p)),snap);
 console.log('Rune batch enhancement: type/grade grouping, +10 skipped, single attempt per rune, correct combined cost, success/downgrade/destroy, other runes/equip preserved, stale selection and insufficient balance rejected');
}
{
 const {p}=player(),runes=mod('core/runeInventory.js'),batch=mod('core/runeBatch.js'),w=mod('core/wallet.js');const bag=runes.readRuneBag(p);for(let i=0;i<3;i++)runes.addRuneRecord(bag,'ward',0,0);runes.writeRuneBag(p,bag);w.setWallet(p,{gold:1000,stone:100,dust:100});const before=p.getDynamicProperty(runes.RUNE_BAG_KEY),money=p.getDynamicProperty(w.WALLET_KEY),q=batch.runeBatchQuote(p,'ward',0);let draw=0;
 const r=batch.executeRuneBatch(p,'ward',0,q.fingerprint,{random:()=>{if(draw++===1)throw Error('injected failure after first successful upgrade');return 0;}});assert.equal(r.ok,false);assert.equal(p.getDynamicProperty(runes.RUNE_BAG_KEY),before);assert.equal(p.getDynamicProperty(w.WALLET_KEY),money);
 console.log('Rune batch rollback: failure in second attempt restores first upgrade and entire original wallet/bag');
}{
 const {p}=player(),runes=mod('core/runeInventory.js'),batch=mod('core/runeBatch.js'),w=mod('core/wallet.js');const bag=runes.readRuneBag(p);runes.addRuneRecord(bag,'power',0,0);runes.addRuneRecord(bag,'power',0,0);runes.writeRuneBag(p,bag);w.setWallet(p,{gold:1000,stone:0,dust:100});
 const answers=[0,1,undefined],original=Form.prototype.show;Form.prototype.show=()=>{const n=answers.shift();return Promise.resolve(n===undefined?{canceled:true}:{canceled:false,selection:n});};try{await batch.openRuneBatch(p);}finally{Form.prototype.show=original;}assert.equal(w.getWallet(p).dust,98);
 console.log('Rune batch UI: group selection, confirmation and batch execution exercised through actual forms');
}
{
 const life=mod('core/townWildlife.js'),spawn=mod('core/spawnEffects.js'),s={x:0,y:64,z:0,size:250,dimId:'minecraft:overworld'},oldGet=world.getDynamicProperty;
 world.getDynamicProperty=k=>k===spawn.SPAWN_REGION_KEY?JSON.stringify(s):undefined;
 function mob(type='minecraft:zombie',x=125,y=65,z=125){const tags=new Set(),dp=new Map();return {typeId:type,isValid:true,location:{x,y,z},dimension:{id:'minecraft:overworld'},getComponent:k=>k==='minecraft:type_family'?{hasTypeFamily:t=>t==='monster'&&type==='minecraft:zombie'}:undefined,getDynamicProperty:k=>dp.get(k),setDynamicProperty:(k,v)=>dp.set(k,v),hasTag:t=>tags.has(t),addTag:t=>tags.add(t),remove(){this.removed=true;}};}
 const zombie=mob(),cow=mob('minecraft:cow'),sheep=mob('minecraft:sheep'),villager=mob('minecraft:villager'),npc=mob('rpg:hito_blood'),bat=mob('minecraft:bat'),dungeon=mob(),below=mob('minecraft:zombie',125,10),outside=mob('minecraft:zombie',250),lastRow=mob('minecraft:zombie',249.9),ally=mob();dungeon.addTag('rpg_dungeon_mob');ally.setDynamicProperty('rpg:necro_owner','test');
 const list=[zombie,cow,sheep,villager,npc,bat,dungeon,below,outside,lastRow,ally];world.getDimension=()=>({getEntities:q=>{assert.equal(q.volume.x,250);return list;}});life.tickTownWildlife();assert.equal(zombie.removed,true);assert.equal(bat.removed,true);assert.equal(lastRow.removed,true);for(const e of [cow,sheep,villager,npc,dungeon,below,outside,ally])assert.equal(e.removed,undefined,e.typeId);
 life.registerTownWildlife();const egg=mob();signal('entitySpawn').fire({entity:egg,cause:'Spawned'});const callbacks=timers.slice();const {p}=player();p.location={x:125,y:65,z:125};signal('itemUse').fire({source:p,itemStack:new ItemStack('minecraft:zombie_spawn_egg')});callbacks.at(-1)();assert.equal(egg.removed,undefined);assert.equal(egg.hasTag('rpg_town_manual_spawn'),true);
 system.currentTick+=10;const natural=mob();signal('entitySpawn').fire({entity:natural,cause:'Spawned'});timers.at(-1)();assert.equal(natural.removed,true);
 const loaded=mob();signal('entitySpawn').fire({entity:loaded,cause:'Loaded'});timers.at(-1)();assert.equal(loaded.removed,true);
 const manual=mob();signal('entitySpawn').fire({entity:manual,cause:'Event'});assert.equal(manual.hasTag('rpg_town_manual_spawn'),true);assert.equal(life.clearTownMonster(manual),false);
 const labeled=mob();labeled.nameTag='§cLv. 50';assert.equal(life.clearTownMonster(labeled),true);
 const zoned=mob();zoned.addTag('rpg_town_manual_spawn');zoned.addTag('rpg_hunt_zoned');assert.equal(life.clearTownMonster(zoned),true);
 world.getDynamicProperty=oldGet;
 console.log('Town wildlife: hostile natural mobs/bats removed including final edge column, animals/villagers/trainers/owned summons/dungeons preserved, finite height, intentional zombie egg kept and stale egg intent expires');
}
{
 const {p}=player(),runes=mod('core/runeInventory.js'),batch=mod('core/runeBatch.js'),w=mod('core/wallet.js'),bag=runes.readRuneBag(p);for(let i=0;i<3;i++)runes.addRuneRecord(bag,'ward',0,0);runes.writeRuneBag(p,bag);w.setWallet(p,{gold:1000,stone:100,dust:100});const before=p.getDynamicProperty(runes.RUNE_BAG_KEY),money=p.getDynamicProperty(w.WALLET_KEY),q=batch.runeBatchQuote(p,'ward',0);const setter=p.setDynamicProperty;let writes=0;
 p.setDynamicProperty=(key,value)=>{if(key===runes.RUNE_BAG_KEY&&++writes===2)throw Error('injected storage failure during second enhancement');setter(key,value);};
 const r=batch.executeRuneBatch(p,'ward',0,q.fingerprint,{random:()=>0});assert.equal(r.ok,false);assert.equal(p.getDynamicProperty(runes.RUNE_BAG_KEY),before);assert.equal(p.getDynamicProperty(w.WALLET_KEY),money);
 console.log('Rune batch storage rollback: second rune write failure restores all three original runes and entire wallet');
}
{
 const hints=mod('data/jobStats.js'),guide=mod('core/skillGuide.js');
 for(const job of Object.values(jobs).filter(j=>!j.placeholder)){assert.ok(hints.LINE_STAT_GUIDES[job.line],job.id);assert.ok(hints.jobStatText(job).includes('추천 스탯:'));}
 assert.match(hints.jobStatText(jobs.chameleon,'mage'),/추천 스탯: 복합/);assert.match(hints.jobStatText(jobs.nen),/근력·마력/);assert.match(hints.jobStatText(jobs.fighter),/풍압은 마력/);
 const originalBody=Form.prototype.body,bodies=[];Form.prototype.body=function(text){bodies.push(text);return this;};
 try{
  for(const [job,expected]of [['swordsman','근력'],['mage','마력'],['cleric','마력'],['archer','근력'],['the_world','근력'],['war_god','근력'],['nen','복합'],['chameleon','복합']]){
   const {p,inv}=player(job);data.setSkills(p,jobs[job].skills);inv.setItem(0,new ItemStack(jobs[job].weapon));bodies.length=0;await guide.openSkillGuide(p);assert.match(bodies[0],new RegExp('추천 스탯: '+expected),job+' guide');bodies.length=0;await mod('core/skillMenu.js').openSkillMenu(p);assert.match(bodies[0],new RegExp('추천 스탯: '+expected),job+' settings');
  }
 }finally{Form.prototype.body=originalBody;}
 for(const [skill,stat]of [['world_stop','근력'],['mage_fireball','마력'],['holy_heal','마력'],['chameleon_crimson_dash','복합']])assert.ok(guide.skillGuideDetail(skill).includes('추천 스탯: '+stat));
 console.log('Stat guidance: every active job mapped, actual skill guide/settings form bodies show STR/MAG, Chameleon always 복합, Nen mixed and Fist exception displayed, skill details preserve effects');
}
{
 const grade=mod('core/setGrade.js'),rarity=mod('data/rarity.js'),grades=mod('data/grades.js');
 for(let i=0;i<7;i++){assert.equal(grade.parseGrade(String(i)),i);assert.equal(grade.parseGrade(grades.RARITIES[i]),i);}for(const value of ['',-1,7,'6.0','신화 추가','NaN'])assert.equal(grade.parseGrade(value),undefined);
 const {p,inv}=player();const item=new ItemStack('rpg:common_redmoon_blade');item.nameTag='my custom weapon';item.durability.damage=137;item.setDynamicProperty('rpg:weapon_upgrade',8);item.setDynamicProperty('rpg:weapon_uid','bound-unique');item.setDynamicProperty('custom:option',17);item.setLore(['custom lore']);inv.setItem(0,item);
 const before=mod('core/gearState.js').gearFingerprint(inv.getItem(0));assert.equal(grade.setEquipmentGrade(p,'신화').ok,false);assert.equal(mod('core/gearState.js').gearFingerprint(inv.getItem(0)),before);
 p.commandPermissionLevel=1;for(let i=6;i>=0;i--){const r=grade.setEquipmentGrade(p,String(i));assert.equal(r.ok,true,r.reason);const next=inv.getItem(0);assert.equal(rarity.itemRarity(next).rank,i);assert.equal(next.getDynamicProperty('rpg:weapon_upgrade'),8);assert.equal(next.getDynamicProperty('rpg:weapon_uid'),'bound-unique');assert.equal(next.getDynamicProperty('custom:option'),17);assert.equal(next.nameTag,'my custom weapon');assert.equal(next.durability.damage,137);assert.ok(next.getLore().includes('custom lore'));}
 inv.setItem(0,new ItemStack('minecraft:stone'));assert.equal(grade.setEquipmentGrade(p,'신화').ok,false);inv.setItem(0,new ItemStack(jobs.swordsman.weapon));assert.equal(grade.setEquipmentGrade(p,'신화').ok,false);
 const token=new ItemStack('rpg:rune_power',12);mod('core/rarityLabels.js').decorateRarity(token);inv.setItem(0,token);assert.equal(grade.setEquipmentGrade(p,'전설').ok,false);assert.equal(inv.getItem(0).amount,12);assert.equal(rarity.itemRarity(inv.getItem(0)).rank,0);
 console.log('Set grade: all seven names/numbers, admin-only, upgrade/UID/name/durability/custom options preserved, lowering allowed, unsupported/class items rejected, stackable rune tokens preserved and redirected to storage');
}
{
 const {p,inv}=player(),grade=mod('core/setGrade.js'),runes=mod('core/runeInventory.js'),gear=mod('core/equipment.js');p.commandPermissionLevel=1;const bag=runes.readRuneBag(p),r=runes.addRuneRecord(bag,'power',8,0),other=runes.addRuneRecord(bag,'ward',2,1);bag.equipped[0]=r.uid;runes.writeRuneBag(p,bag);const beforeBonus=gear.getEquipmentBonuses(p).physical;
 assert.equal(grade.setEquipmentGrade(p,'신화 rune1').ok,true);const next=runes.readRuneBag(p);assert.equal(next.runes[0].grade,6);assert.equal(next.runes[0].level,8);assert.equal(next.equipped[0],r.uid);assert.equal(next.runes[1].grade,1);assert.ok(gear.getEquipmentBonuses(p).physical>beforeBonus);
 assert.equal(grade.setEquipmentGrade(p,'일반 rune:'+other.uid).ok,true);assert.equal(runes.readRuneBag(p).runes[1].grade,0);assert.equal(grade.setEquipmentGrade(p,'신화 rune5').ok,false);assert.equal(grade.setEquipmentGrade(p,'신화 rune2').ok,false);
 const equipment=new Map(),originalGet=p.getComponent;p.getComponent=id=>id==='minecraft:equippable'?{getEquipment:s=>equipment.get(s)?.clone(),setEquipment:(s,i)=>{equipment.set(s,i?.clone());return true;}}:originalGet(id);const helmet=new ItemStack('rpg:adventurer_helmet');helmet.setDynamicProperty('rpg:armor_upgrade',6);helmet.durability.damage=33;equipment.set('Head',helmet);const hp=gear.getEquipmentBonuses(p).health;
 assert.equal(grade.setEquipmentGrade(p,'신화 head').ok,true);assert.equal(equipment.get('Head').getDynamicProperty('rpg:rarity'),6);assert.equal(equipment.get('Head').getDynamicProperty('rpg:armor_upgrade'),6);assert.equal(equipment.get('Head').durability.damage,33);assert.equal(gear.getEquipmentBonuses(p).health,hp+22);
 console.log('Grade targets: equipped armor preserves enhancement/durability and changes HP; equipped/bag UID rune grade changes real bonus and keeps level/equip; empty/locked targets refused');
}
{
 const {p,inv}=player(),grade=mod('core/setGrade.js');p.commandPermissionLevel=1;inv.setItem(0,new ItemStack('rpg:common_redmoon_blade'));const original=mod('core/gearState.js').gearFingerprint(inv.getItem(0)),set=inv.setItem;let fail=true;inv.setItem=(i,item)=>{if(fail){fail=false;throw Error('injected grade write failure');}set(i,item);};assert.equal(grade.setEquipmentGrade(p,'신화').ok,false);assert.equal(mod('core/gearState.js').gearFingerprint(inv.getItem(0)),original);
 const sent=[];p.runCommand=text=>sent.push(text);const cmd=commandDefs.get('rpg:setgrade');assert.equal(cmd.d.permissionLevel,1);assert.equal(cmd.d.mandatoryParameters[0].name,'grade');assert.equal(cmd.d.optionalParameters[0].name,'target');cmd.fn({sourceEntity:p},'신화','head');timers.at(-1)();assert.equal(sent.at(-1),'scriptevent rpg:setgrade 신화 head');cmd.fn({sourceEntity:p},['0','rune1']);timers.at(-1)();assert.equal(sent.at(-1),'scriptevent rpg:setgrade 0 rune1');
 const {p:normal,inv:normalInv}=player();normalInv.setItem(0,new ItemStack('rpg:common_redmoon_blade'));mod('core/rpgActions.js').runRpgAction('setgrade',normal,'신화');assert.equal(normalInv.getItem(0).getDynamicProperty('rpg:rarity'),undefined);
 console.log('Grade command: one/two parameter forwarding, operator registry permissions, direct script action permission enforced, failed item save rolls back');
}
{
 const all=allCommandDefs.get('rpg:setgrade');assert.equal(all.length,2);for(const {d}of all){assert.equal(d.permissionLevel,1);assert.equal(d.mandatoryParameters[0].name,'grade');assert.equal(d.optionalParameters[0].name,'target');}
 const bridge=mod('core/commandBridge.js'),old=bridge.getCommandHandler(),status=bridge.getGameplayStatus(),calls=[];bridge.setGameplayStatus('ready');bridge.setCommandHandler((...args)=>calls.push(args));
 try{const {p}=player();p.commandPermissionLevel=1;all[0].fn({sourceEntity:p},'전설','feet');timers.at(-1)();assert.equal(calls.at(-1)[0],'setgrade');assert.equal(calls.at(-1)[2],'전설 feet');all[0].fn({sourceEntity:p},['6','rune1']);timers.at(-1)();assert.equal(calls.at(-1)[2],'6 rune1');const {p:normal}=player();all[0].fn({sourceEntity:normal},'신화');timers.at(-1)();assert.equal(calls.length,2);}finally{bridge.setCommandHandler(old);bridge.setGameplayStatus(status.state,status.errors);}
 console.log('Both active registrars verified: direct gameplay fallback and independent Commands BP preserve two grade arguments and require operator permissions');
}
{
 const {p,inv}=player('chameleon'),progress=mod('core/chameleonProgress.js'),tr=mod('core/chameleonTranscend.js'),wallet=mod('core/wallet.js'),skills=mod('data/skills.js').SKILLS;
 const ids=['war_god_flurry','sage_zoltraak','fallen_end','dragon_domain'];const state=progress.readChameleonProgress(p);state.learned=[...ids];state.evolved=ids.slice(0,3);progress.saveChameleonProgress(p,state);data.setSkills(p,[...jobs.chameleon.skills,...ids]);wallet.setWallet(p,{gold:3000000,stone:10000,dust:123});
 inv.setItem(3,new ItemStack('minecraft:netherite_ingot',6));inv.setItem(4,new ItemStack('minecraft:diamond_block',27));
 const costs=[[200000,800],[500000,2000],[750000,3000]];const stale=tr.transcendQuote(p,ids[1]);
 for(let i=0;i<3;i++){const q=tr.transcendQuote(p,ids[i]);assert.equal(q.cost.gold,costs[i][0]);assert.equal(q.cost.stone,costs[i][1]);assert.equal(q.materials['minecraft:netherite_ingot'],2);assert.equal(q.materials['minecraft:diamond_block'],9);const r=tr.purchaseTranscend(p,ids[i],'transcend',q.fingerprint);assert.equal(r.ok,true,r.message);assert.equal(r.level,0);if(i===0){const snapshot=p.getDynamicProperty(progress.CHAMELEON_KEY),money=JSON.stringify(wallet.getWallet(p));assert.equal(tr.purchaseTranscend(p,ids[1],'transcend',stale.fingerprint).ok,false);assert.equal(p.getDynamicProperty(progress.CHAMELEON_KEY),snapshot);assert.equal(JSON.stringify(wallet.getWallet(p)),money);}}
 assert.equal(wallet.getWallet(p).gold,1550000);assert.equal(wallet.getWallet(p).stone,4200);assert.equal(wallet.getWallet(p).dust,123);assert.equal(inv.getItem(3),undefined);assert.equal(inv.getItem(4),undefined);assert.equal(Object.keys(progress.readChameleonProgress(p).transcended).length,3);assert.equal(tr.transcendQuote(p,ids[0]),undefined);assert.equal(tr.transcendQuote(p,ids[3]),undefined);
 for(let level=1;level<=3;level++){const q=tr.transcendQuote(p,ids[0],'upgrade');assert.equal(q.cost.gold,30000);assert.equal(q.cost.stone,100);assert.equal(Object.keys(q.materials).length,0);assert.equal(tr.purchaseTranscend(p,ids[0],'upgrade',q.fingerprint).ok,true);assert.equal(tr.transcendLevel(p,ids[0]),level);}assert.equal(tr.transcendQuote(p,ids[0],'upgrade'),undefined);assert.equal(wallet.getWallet(p).gold,1460000);assert.equal(wallet.getWallet(p).stone,3900);
 const base=JSON.stringify(skills.war_god_flurry),scaled=tr.transcendedSkillDefinition(p,skills.war_god_flurry);assert.equal(scaled.damage,8.5*1.55);assert.equal(scaled.projectiles,12);assert.equal(scaled.cooldown,200);assert.equal(JSON.stringify(skills.war_god_flurry),base);assert.equal(tr.transcendedSkillDefinition(p,skills.nen_ho),skills.nen_ho);assert.ok(mod('core/skillGuide.js').skillGuideDetail(ids[0],p).includes('초월 +3'));
 const {p:rejoin}=player('chameleon');for(const [k,v]of p.getDynamicPropertyIds().map(k=>[k,p.getDynamicProperty(k)]))rejoin.setDynamicProperty(k,v);assert.equal(tr.transcendLevel(rejoin,ids[0]),3);data.setJobId(rejoin,'mage');assert.equal(tr.transcendedSkillDefinition(rejoin,skills.war_god_flurry),skills.war_god_flurry);
 const qBefore=wallet.getWallet(p);assert.equal(progress.dismantleChameleonSkill(p,ids[0]).ok,true);assert.equal(tr.transcendLevel(p,ids[0]),undefined);assert.equal(Object.keys(progress.readChameleonProgress(p).transcended).length,2);assert.equal(JSON.stringify(wallet.getWallet(p)),JSON.stringify(qBefore));
 console.log('Transcend: exact 200k/500k/750k and 800/2000/3000 costs, 2 ingots+9 blocks each, stale quote refused, max 3 skills, +3 upgrades at 30k+100, power snapshots, rejoin/job changes, dismantle without refund');
}
{
 const progress=mod('core/chameleonProgress.js'),tr=mod('core/chameleonTranscend.js'),wallet=mod('core/wallet.js');
 function setup(){const {p,inv}=player('chameleon'),s=progress.readChameleonProgress(p);s.learned=['war_god_flurry'];s.evolved=['war_god_flurry'];progress.saveChameleonProgress(p,s);data.setSkills(p,[...jobs.chameleon.skills,'war_god_flurry']);wallet.setWallet(p,{gold:200000,stone:800,dust:3});inv.setItem(3,new ItemStack('minecraft:netherite_ingot',1));inv.setItem(4,new ItemStack('minecraft:netherite_ingot',1));inv.setItem(5,new ItemStack('minecraft:diamond_block',9));return {p,inv};}
 for(const failure of ['material','wallet','inventory_write','progress_write']){
  const {p,inv}=setup();if(failure==='material')inv.setItem(5,new ItemStack('minecraft:diamond_block',8));if(failure==='wallet')wallet.setWallet(p,{gold:199999,stone:800,dust:3});
  const before=p.getDynamicProperty(progress.CHAMELEON_KEY),funds=p.getDynamicProperty(wallet.WALLET_KEY),items=Array.from({length:inv.size},(_,i)=>inv.getItem(i)?.amount);
  if(failure==='inventory_write'){const set=inv.setItem;let writes=0;inv.setItem=(i,v)=>{if(++writes===2)throw Error('second material write failure');set(i,v);};}
  if(failure==='progress_write'){const set=p.setDynamicProperty;let fail=true;p.setDynamicProperty=(k,v)=>{if(k===progress.CHAMELEON_KEY&&fail){fail=false;throw Error('progress write failure');}set(k,v);};}
  const r=tr.purchaseTranscend(p,'war_god_flurry');assert.equal(r.ok,false,failure);assert.equal(p.getDynamicProperty(progress.CHAMELEON_KEY),before,failure);assert.equal(p.getDynamicProperty(wallet.WALLET_KEY),funds,failure);assert.deepEqual(Array.from({length:inv.size},(_,i)=>inv.getItem(i)?.amount),items,failure);
 }
 const {p}=setup();data.setJobId(p,'mage');assert.equal(tr.purchaseTranscend(p,'war_god_flurry').ok,false);
 console.log('Transcend transactions: missing materials/funds, failed second material write and progress write leave all original items/wallet/progress intact; other jobs denied');
}
{
 const {p,inv}=player('chameleon'),progress=mod('core/chameleonProgress.js'),tr=mod('core/chameleonTranscend.js'),skill=mod('data/skills.js').SKILLS.mage_gravity;
 const state=progress.readChameleonProgress(p);state.learned=['mage_gravity'];state.evolved=['mage_gravity'];state.transcended={mage_gravity:0};progress.saveChameleonProgress(p,state);data.setSkills(p,[...jobs.chameleon.skills,'mage_gravity']);data.setDisabled(p,jobs.chameleon.skills);data.setIndex(p,0);inv.setItem(0,new ItemStack(jobs.chameleon.weapon));data.forceSetManaMax(p,'5000');data.setMana(p,5000);system.currentTick+=50;p.getViewDirection=()=>({x:0,y:0,z:1});
 const targetHealth={currentValue:1000,effectiveMax:1000,setCurrentValue(n){this.currentValue=n;}},hits=[];const target={id:'gravity-target',typeId:'minecraft:zombie',isValid:true,dimension:p.dimension,location:{x:0,y:64,z:3},getTags:()=>[],hasTag:()=>false,getDynamicProperty:()=>undefined,getComponent:k=>k==='minecraft:health'?targetHealth:undefined,applyDamage(n){hits.push(n);targetHealth.currentValue-=n;return true;},addEffect:()=>{}};
 p.dimension.getEntities=()=>[target];p.dimension.getBlock=()=>({isAir:true,isSolid:false,typeId:'minecraft:air'});componentHandlers.get('rpg:cast_item').onUse({source:p});const cast=timers.at(-1);cast();assert.equal(hits.length,1);assert.ok(Math.abs(hits[0]-skill.damage*1.25)<1e-7,JSON.stringify({hits,base:skill.damage}));assert.equal(data.cooldownLeft(p,skill.id),skill.cooldown);assert.equal(skill.damage,10);assert.equal(progress.remainingSkillUses(p,skill.id),null);
 console.log('Actual input cast path: evolved transcended mage skill deals exactly +25%, original cooldown/shared definition retained, evolved use remains unlimited');
}
{
 const {p,inv}=player('chameleon'),progress=mod('core/chameleonProgress.js'),wallet=mod('core/wallet.js'),tr=mod('core/chameleonTranscend.js'),s=progress.readChameleonProgress(p);s.learned=['war_god_flurry'];s.evolved=['war_god_flurry'];progress.saveChameleonProgress(p,s);data.setSkills(p,[...jobs.chameleon.skills,'war_god_flurry']);wallet.setWallet(p,{gold:230000,stone:900,dust:0});inv.setItem(3,new ItemStack('minecraft:netherite_ingot',2));inv.setItem(4,new ItemStack('minecraft:diamond_block',9));
 const show=Form.prototype.show;
 try{
  for(const [button,level]of [[5,0],[6,1]]){const answers=[button,0,1,undefined,undefined];Form.prototype.show=()=>{const n=answers.shift();return Promise.resolve(n===undefined?{canceled:true}:{canceled:false,selection:n});};await mod('core/chameleon.js').openChameleonSkillbook(p);assert.equal(tr.transcendLevel(p,'war_god_flurry'),level);}
 }finally{Form.prototype.show=show;}
 assert.equal(wallet.getWallet(p).gold,0);assert.equal(wallet.getWallet(p).stone,0);
 console.log('Actual Chameleon skillbook UI: transcend and upgrade buttons, target and confirmation each execute at stated prices');
}
{
 const {p,inv}=player('chameleon'),progress=mod('core/chameleonProgress.js'),tr=mod('core/chameleonTranscend.js'),defs=mod('data/skills.js').SKILLS,s=progress.readChameleonProgress(p);s.learned=['sage_zoltraak'];s.evolved=['sage_zoltraak'];s.transcended={sage_zoltraak:0};progress.saveChameleonProgress(p,s);data.setSkills(p,['sage_zoltraak']);p.getViewDirection=()=>({x:0,y:0,z:1});
 const hits=[],target={id:'delayed-target',typeId:'minecraft:zombie',location:{x:0,y:64,z:3},getTags:()=>[],hasTag:()=>false,getDynamicProperty:()=>undefined,getComponent:k=>k==='minecraft:health'?{currentValue:1000}:undefined,applyDamage:n=>{hits.push(n);return true;}};p.dimension.getEntities=()=>[target];p.dimension.getBlock=()=>({isAir:true,typeId:'minecraft:air'});
 const castDef=tr.transcendedSkillDefinition(p,defs.sage_zoltraak);mod('skills/mage.js').RUNNERS.sage_zoltraak(p,jobs.sage,castDef);const delayed=timers.at(-1);s.transcended.sage_zoltraak=3;progress.saveChameleonProgress(p,s);delayed();assert.equal(hits.length,1);assert.equal(hits[0],120);assert.equal(defs.sage_zoltraak.damage,96);
 console.log('Delayed spell power snapshot: charge retains cast-time +25% even after upgrade, shared original stays 96');
}
{
 const defs=mod('data/skills.js').SKILLS;
 for(const job of ['nen','chameleon']){
  const {p,inv}=player(job);p.id='cannon-'+job;p.getViewDirection=()=>({x:0,y:0,z:1});p.dimension.getEntities=()=>[];p.dimension.getBlock=()=>({isAir:true,typeId:'minecraft:air'});data.setSkills(p,job==='nen'?jobs.nen.skills:[...jobs.chameleon.skills,'nen_ho']);data.setDisabled(p,(job==='nen'?jobs.nen.skills:jobs.chameleon.skills).filter(id=>id!=='nen_ho'));data.setIndex(p,0);inv.setItem(0,new ItemStack(jobs[job].weapon));data.forceSetManaMax(p,'5000');data.setMana(p,5000);system.currentTick+=100;componentHandlers.get('rpg:cast_item').onUse({source:p});timers.at(-1)();assert.equal(data.cooldownLeft(p,'nen_ho'),900,job);
 }
 console.log('Actual input cooldown: Nen and borrowed Chameleon cannon both start exactly 45 seconds');
}
{
 const {p}=player('chameleon'),progress=mod('core/chameleonProgress.js');p.setDynamicProperty(progress.CHAMELEON_KEY,JSON.stringify({version:1,spentSp:15,learned:['world_stop'],charges:{world_stop:0},evolved:['world_stop'],levelsToBook:3,pendingBooks:2}));const legacy=progress.readChameleonProgress(p);assert.equal(Object.keys(legacy.transcended).length,0);assert.equal(legacy.charges.world_stop,0);assert.equal(legacy.spentSp,15);assert.equal(legacy.levelsToBook,3);assert.equal(legacy.pendingBooks,2);assert.equal(legacy.evolved[0],'world_stop');
 console.log('Legacy Chameleon progression gains empty transcend data without resetting SP, charges, evolution or pending books');
}
{
 const pages=mod('core/rulebook.js').RULEBOOK_PAGES;assert.ok(pages.length<=50);assert.ok(pages.every(p=>p.length<=256));console.log('Rulebook remains within native 50-page / 256-character limits');
}
{
 const {p,inv}=player('chameleon');p.id='rebalance-reference';
 const progress=mod('core/chameleonProgress.js'),runes=mod('core/runeInventory.js'),skill=mod('data/skills.js').SKILLS.sword_annihilation;
 const state=progress.readChameleonProgress(p);state.learned=['sword_annihilation'];state.evolved=['sword_annihilation'];progress.saveChameleonProgress(p,state);
 data.setSkills(p,[...jobs.chameleon.skills,skill.id]);data.setDisabled(p,jobs.chameleon.skills);data.setIndex(p,0);
 const weapon=new ItemStack(jobs.chameleon.weapon);weapon.setDynamicProperty('rpg:weapon_upgrade',6);inv.setItem(0,weapon);
 p.setDynamicProperty('rpg:stat_values',JSON.stringify({str:25,mag:5,vit:5,int:5}));
 const bag=runes.readRuneBag(p),rune=runes.addRuneRecord(bag,'power',0,1);bag.equipped[0]=rune.uid;runes.writeRuneBag(p,bag);
 data.forceSetManaMax(p,'5000');data.setMana(p,5000);system.currentTick+=100;
 p.getViewDirection=()=>({x:0,y:0,z:1});p.getRotation=()=>({x:0,y:0});p.teleport=at=>p.location={...at};
 const hp={currentValue:1000,effectiveMax:1000,setCurrentValue(n){this.currentValue=n;}},hits=[];
 const target={id:'annihilation-balance-dummy',typeId:'minecraft:zombie',isValid:true,dimension:p.dimension,location:{x:0,y:64,z:3},getTags:()=>[],hasTag:()=>false,getDynamicProperty:()=>undefined,getComponent:k=>k==='minecraft:health'?hp:undefined,applyDamage:n=>{hits.push(n);hp.currentValue-=n;return true;}};
 p.dimension.getEntities=()=>[target,target];p.dimension.getBlock=()=>({isAir:true,isSolid:false,typeId:'minecraft:air'});
 componentHandlers.get('rpg:cast_item').onUse({source:p});timers.at(-1)();
 assert.equal(hits.length,1);assert.ok(Math.abs(hits[0]-74.407886336)<1e-7,JSON.stringify(hits));assert.equal(skill.damage,41);assert.equal(data.cooldownLeft(p,skill.id),100);
 console.log('Actual Chameleon input -> Annihilation -> equipment/rune/stat/native damage: STR25, rare rune +0, weapon +6 hits exactly once for 74.408, 5s cooldown preserved');
}
{
 const d=mod('core/jobDiscovery.js'),{p,messages}=player('apprentice');p.id='discovery-new';
 assert.ok(mod('core/statusTablet.js').ALL_STATUS_ACTIONS.some(a=>a.action==='jobs'));
 assert.ok(mod('core/statusTablet.js').ALL_STATUS_ACTIONS.some(a=>a.action==='spawn'));
 for(const id of ['frost_controller','fire_controller','hacker','beast','shadow_assassin','revenant']){
  assert.ok(!d.visiblePromotionJobs(p).some(j=>j.id===id),id);
  assert.equal(advance.requirementStatus(p,jobs[id]).label,d.UNDISCOVERED_JOB_TEXT,id);
  assert.equal(advance.checkAdvance(p,jobs[id]).reason,d.UNDISCOVERED_JOB_TEXT,id);
 }
 assert.ok(d.visiblePromotionJobs(p).some(j=>j.id==='swordsman'));
 const before=p.getDynamicProperty(d.JOB_DISCOVERY_KEY);advance.checkAdvance(p,jobs.frost_controller);assert.equal(p.getDynamicProperty(d.JOB_DISCOVERY_KEY),before);
 const captured=[],show=Form.prototype.show,button=Form.prototype.button;Form.prototype.button=function(s){captured.push(s);return this;};
 try{
  await mod('core/jobMenu.js').openJobMenu(p);assert.ok(!captured.some(s=>s.includes('냉기')));
  await mod('core/hito.js').openHitoMenu(p,{id:'frost',label:'냉기',hidden:true,jobs:['frost_controller']});
  assert.equal(d.isJobDiscovered(p,jobs.frost_controller),true);
  assert.ok(advance.requirementStatus(p,jobs.frost_controller).label.includes('스트레이'));
  captured.length=0;await mod('core/jobMenu.js').openJobMenu(p);assert.ok(captured.some(s=>s.includes('냉기')));
 }finally{Form.prototype.show=show;Form.prototype.button=button;}
 const saved=p.getDynamicProperty(d.JOB_DISCOVERY_KEY),other=player('apprentice').p;other.id='other-player';assert.equal(d.isJobDiscovered(other,jobs.frost_controller),false);
 other.setDynamicProperty(d.JOB_DISCOVERY_KEY,saved);assert.equal(d.isJobDiscovered(other,jobs.frost_controller),true);
 const previous=player('frost_controller').p;previous.id='legacy-hidden';assert.equal(d.isJobDiscovered(previous,jobs.frost_controller),true);data.setJobId(previous,'apprentice');assert.equal(d.isJobDiscovered(previous,jobs.frost_controller),true);
 data.setJobId(p,'mage');messages.length=0;mod('core/rpgActions.js').runRpgAction('status',p);assert.ok(messages.length>0);assert.ok(!messages.join('').includes('→'));assert.ok(!messages.join('').includes('전직 조건'));assert.ok(!messages.join('').includes('마나 소비'));
 console.log('Discovery: status advancement route available; undiscovered hidden classes and descendants absent from jobs, guessed commands redact conditions; actual trainer encounter unlocks only that player/class, persists across reload/job changes, legacy current hidden class preserved');
}
{
 const discovery=mod('core/jobDiscovery.js'),temple=mod('data/temple.js'),{p,messages}=player('apprentice');p.id='temple-discovery';
 const originalRead=world.getDynamicProperty,originalDim=world.getDimension,originalBody=Form.prototype.body;
 const t={x:2000,y:100,z:2000,dimId:'minecraft:overworld',status:'ready'},bodies=[];
 world.getDynamicProperty=k=>k===temple.TEMPLE_KEY?JSON.stringify({version:1,temple:t}):originalRead(k);
 world.getDimension=()=>({getBlock:()=>({typeId:'minecraft:gold_block'})});Form.prototype.body=function(s){bodies.push(s);return this;};
 try{
  await mod('core/temples.js').openTemple(p);assert.equal(bodies.length,0);assert.equal(discovery.isJobDiscovered(p,jobs.sun_heir),false);assert.ok(!messages.join('').includes('60'));
  p.location={...temple.altarPosition(t,'sun')};await mod('core/temples.js').openTemple(p);assert.equal(discovery.isJobDiscovered(p,jobs.sun_heir),true);assert.equal(discovery.isJobDiscovered(p,jobs.moon_heir),false);assert.ok(bodies.some(s=>s.includes('60마리')));
 }finally{world.getDynamicProperty=originalRead;world.getDimension=originalDim;Form.prototype.body=originalBody;}
 const loto=player('apprentice').p;loto.id='loto-discovery';await mod('core/loto.js').openLotoDialogue(loto);assert.equal(discovery.isJobDiscovered(loto,jobs.hacker),true);
 console.log('Discovery locations: remote temple command reveals no conditions; visiting the active altar unlocks only its branch; Loto conversation records Hacker discovery');
}
{
 const {p,inv}=player('apprentice');p.id='card-discovery';const d=mod('core/jobDiscovery.js');d.registerJobDiscovery();inv.setItem(3,new ItemStack('rpg:chameleon_job_card'));signal('playerInventoryItemChange').fire({player:p});assert.equal(d.isJobDiscovered(p,jobs.chameleon),true);assert.equal(advance.checkAdvance(p,jobs.chameleon).ok,false);inv.setItem(3,undefined);assert.equal(d.isJobDiscovered(p,jobs.chameleon),true);
 console.log('Discovery cards: inventory acquisition persists knowledge after card removal; holding-card promotion requirement remains enforced');
}
{
 const choice=mod('core/dragonChoice.js'),discovery=mod('core/jobDiscovery.js'),originalShow=Form.prototype.show;
 const setup=()=>{const r=player('apprentice');r.p.id='dragon-'+Math.random();r.inv.setItem(0,new ItemStack(jobs.apprentice.weapon));r.inv.setItem(3,new ItemStack(choice.DRAGON_CHOICE));r.p.selectedSlotIndex=3;return r;};
 try{
  const {p,inv}=setup();assert.equal(advance.checkAdvance(p,jobs.dragon_knight).ok,true);Form.prototype.show=()=>Promise.resolve({canceled:false,selection:1});componentHandlers.get('rpg:dragon_choice').onUse({source:p});await timers.at(-1)();assert.equal(data.getJobId(p),'dragon_knight');assert.equal(inv.getItem(3),undefined);assert.equal(inv.getItem(0).typeId,jobs.dragon_knight.weapon);assert.ok(data.getSkills(p).includes('dragon_domain'));assert.equal(discovery.isJobDiscovered(p,jobs.dragon_knight),true);assert.equal(advance.checkAdvance(p,jobs.dragon_knight).ok,false);
  const cancel=setup();Form.prototype.show=()=>Promise.resolve({canceled:true});await advance.requestAdvance(cancel.p,jobs.dragon_knight);assert.equal(data.getJobId(cancel.p),'apprentice');assert.equal(cancel.inv.getItem(3).typeId,choice.DRAGON_CHOICE);
  const stale=setup();Form.prototype.show=()=>{stale.inv.setItem(4,stale.inv.getItem(3));stale.inv.setItem(3,undefined);return Promise.resolve({canceled:false,selection:1});};await advance.requestAdvance(stale.p,jobs.dragon_knight);assert.equal(data.getJobId(stale.p),'apprentice');assert.equal(stale.inv.getItem(4).typeId,choice.DRAGON_CHOICE);
  const fail=setup(),write=fail.p.setDynamicProperty;let once=true;fail.p.setDynamicProperty=(k,v)=>{if(k==='rpg:job'&&v==='dragon_knight'&&once){once=false;throw Error('injected promotion save failure');}write(k,v);};Form.prototype.show=()=>Promise.resolve({canceled:false,selection:1});await advance.requestAdvance(fail.p,jobs.dragon_knight);assert.equal(data.getJobId(fail.p),'apprentice');assert.equal(fail.inv.getItem(3).typeId,choice.DRAGON_CHOICE);assert.equal(fail.inv.getItem(0).typeId,jobs.apprentice.weapon);
  const noItem=player('fighter');noItem.p.setDynamicProperty('rpg:rpg_level',100);noItem.p.setDynamicProperty('rpg:progress',JSON.stringify({job_enderman:999,job_boss:999}));assert.equal(advance.checkAdvance(noItem.p,jobs.dragon_knight).ok,false);
  const egg=player('apprentice');egg.inv.setItem(4,new ItemStack('minecraft:dragon_egg'));assert.equal(discovery.isJobDiscovered(egg.p,jobs.dragon_knight),true);assert.equal(advance.checkAdvance(egg.p,jobs.dragon_knight).ok,false);
 }finally{Form.prototype.show=originalShow;}
 console.log('Dragon Choice: actual item component -> confirmation -> consumes 1 -> dragon weapon/skills from level-1 apprentice; cancel/stale item/save error restore state; old kill counters and egg alone cannot promote; egg reveals discovery');
}
{
 const unlock=mod('core/worldUnlock.js'),discovery=mod('core/jobDiscovery.js'),{p,inv}=player('fighter');p.id='world-unlock-new';
 inv.setItem(0,new ItemStack(jobs.fighter.weapon));inv.setItem(3,new ItemStack('rpg:stone_mask'));p.selectedSlotIndex=3;
 assert.equal(races.useStoneMask(p).ok,true);assert.equal(p.getDynamicProperty(unlock.STONE_MASK_USED_KEY),true);assert.equal(inv.getItem(3),undefined);
 p.setDynamicProperty('rpg:progress',JSON.stringify({job_boss:3,job_night:60}));p.setDynamicProperty('rpg:rpg_level',59);inv.setItem(4,new ItemStack(unlock.STAND_ARROW));
 assert.equal(advance.checkAdvance(p,jobs.the_world).ok,false);p.setDynamicProperty('rpg:rpg_level',60);assert.equal(advance.checkAdvance(p,jobs.the_world).ok,true);
 inv.setItem(4,undefined);assert.equal(advance.checkAdvance(p,jobs.the_world).ok,false);inv.setItem(4,new ItemStack(unlock.STAND_ARROW));
 p.setDynamicProperty('rpg:progress',JSON.stringify({job_boss:2,job_night:60}));assert.equal(advance.checkAdvance(p,jobs.the_world).ok,false);p.setDynamicProperty('rpg:progress',JSON.stringify({job_boss:3,job_night:59}));assert.equal(advance.checkAdvance(p,jobs.the_world).ok,false);p.setDynamicProperty('rpg:progress',JSON.stringify({job_boss:3,job_night:60}));
 data.setSkills(p,jobs.fighter.skills);p.selectedSlotIndex=4;const show=Form.prototype.show;
 try{Form.prototype.show=()=>Promise.resolve({canceled:false,selection:0});componentHandlers.get('rpg:stand_manifestation_arrow').onUse({source:p});await timers.at(-1)();}finally{Form.prototype.show=show;}
 assert.equal(data.getJobId(p),'the_world');assert.equal(inv.getItem(0).typeId,jobs.the_world.weapon);assert.equal(inv.getItem(4).typeId,unlock.STAND_ARROW);assert.equal(p.getDynamicProperty('rpg:mask_job'),undefined);assert.equal(unlock.hasUsedStoneMask(p),true);assert.equal(discovery.isJobDiscovered(p,jobs.the_world),true);
 const innate=player('blood_mage').p;assert.equal(races.raceOf(innate),'vampire');assert.equal(unlock.hasUsedStoneMask(innate),false);
 const legacy=player('mage').p;legacy.setDynamicProperty('rpg:mask_job','mage');races.syncRace(legacy);assert.equal(legacy.getDynamicProperty(unlock.STONE_MASK_USED_KEY),true);data.setJobId(legacy,'fighter');assert.equal(unlock.hasUsedStoneMask(legacy),true);
 console.log('World unlock: real mask consumption records persistent history; exact RPG level 60 + owned crafted-arrow item + boss3/night60 + tier2 gates; actual item-use promotion retains arrow, innate vampire does not satisfy mask use; legacy mask state migrates across job change');
}
// v0.6.32 requested workflows, using the linked gameplay graph.
{
 const {p}=player('mage'),d=mod('core/jobDiscovery.js');p.id='two-conditions';
 p.setDynamicProperty('rpg:rpg_level',15);
 assert.equal(d.isJobDiscovered(p,jobs.frost_controller),false);
 p.setDynamicProperty('rpg:progress',JSON.stringify({job_kills:50,job_stray:49}));
 assert.equal(d.isJobDiscovered(p,jobs.frost_controller),true);
 assert.ok(advance.requirementStatus(p,jobs.frost_controller).label.includes('49/50'));
 assert.equal(advance.checkAdvance(p,jobs.frost_controller).ok,false);
 p.setDynamicProperty('rpg:progress','{}');assert.equal(d.isJobDiscovered(p,jobs.frost_controller),true);
 console.log('Two completed conditions reveal remaining promotion requirements; actual unlock still enforced and discovery persists');
}
for(const job of ['cleric','angel','michael','mage']){
 const {p,inv}=player(job),ally=player().p;p.id='healer-'+job;ally.id='ally-'+job;
 p.addTag('rpg_team_test');ally.addTag('rpg_team_test');
 const hp=ally.getComponent('minecraft:health');hp.effectiveMax=1000;hp.currentValue=1;
 const recovery=mod('core/holyRecovery.js'),reward=mod('core/angelHealing.js');
 assert.equal(recovery.healHolyAlly(p,ally,299,false),299);
 assert.equal(inv.getItem(1),undefined);
 assert.equal(recovery.healHolyAlly(p,ally,1,false),1);
 const eligible=job!=='mage';assert.equal(inv.getItem(1)?.amount,eligible?1:undefined);
 recovery.healHolyAlly(p,ally,650,false);
 assert.equal(inv.getItem(1)?.amount,eligible?3:undefined);
 if(eligible)assert.equal(reward.readAngelHealing(p).remainder,50);
 // Overhealing and self healing cannot award lights.
 hp.currentValue=1000;assert.equal(recovery.healHolyAlly(p,ally,500,false),0);
 reward.recordAngelHealing(p,p,300);assert.equal(inv.getItem(1)?.amount,eligible?3:undefined);
}
console.log('Cleric/Angel/Michael: real effective ally healing awards one light per 300 HP with remainder; mage, self and overhealing excluded');
{
 const {p,inv}=player(),u=mod('core/upgrades.js'),w=mod('core/wallet.js');
 w.setWallet(p,{gold:100000,stone:1000,dust:1000});inv.setItem(0,new ItemStack('minecraft:stick'));inv.setItem(5,new ItemStack('rpg:common_redmoon_blade'));
 let q=u.inventoryWeaponQuotes(p)[0];assert.equal(q.slot,5);
 assert.equal(u.enhanceEquipped(p,'weapon',5,q.fingerprint,{random:()=>0}).outcome,'success');
 assert.equal(inv.getItem(5).getDynamicProperty('rpg:weapon_upgrade'),1);assert.equal(inv.getItem(0).typeId,'minecraft:stick');
 const money=w.getWallet(p).gold;
 assert.equal(u.enhanceEquipped(p,'weapon',5,q.fingerprint,{random:()=>0}).ok,false);assert.equal(w.getWallet(p).gold,money);
 q=u.enhancementQuote(p,'weapon',5);inv.setItem(5,new ItemStack('minecraft:stone'));
 assert.equal(u.enhanceEquipped(p,'weapon',5,q.fingerprint).ok,false);assert.equal(w.getWallet(p).gold,money);
 assert.equal(u.enhancementQuote(p,'weapon',-1),undefined);
 console.log('Inventory weapon upgrades work while holding a stick; stale/replaced slots rejected without debit');
}
{
 const {p}=player(),travel=mod('core/menuTravel.js'),social=mod('core/social.js');
 const original={getDimension:world.getDimension,getDefaultSpawnLocation:world.getDefaultSpawnLocation,getAllPlayers:world.getAllPlayers,setDynamicProperty:world.setDynamicProperty};
 const shown=Form.prototype.show,stored=new Map(),moves=[];
 world.getDimension=id=>({id});world.getDefaultSpawnLocation=()=>({x:20,y:80,z:30});world.getAllPlayers=()=>[p];world.setDynamicProperty=(k,v)=>stored.set(k,v);
 p.teleport=(at,options)=>moves.push({at,options});
 Form.prototype.textField=function(){return this;};Form.prototype.submitButton=function(){return this;};
 try{
  travel.returnToSpawn(p);assert.equal(moves.length,1);assert.equal(moves[0].at.x,20);assert.equal(moves[0].options.dimension.id,'overworld');
  p.setDynamicProperty('rpg:dungeon_return_v1','{}');travel.returnToSpawn(p);assert.equal(moves.length,1);p.setDynamicProperty('rpg:dungeon_return_v1',undefined);
  const answers=[{selection:0},{formValues:['테스트길드']},{canceled:true}];Form.prototype.show=()=>Promise.resolve(answers.shift()??{canceled:true});
  await social.openGuildMenu(p);assert.equal(social.setGuildBase(p),true);
  assert.equal(JSON.parse(stored.get('rpg:social_v1')).guilds.at(-1).base.dimension,p.dimension.id);
  social.travelGuildBase(p);assert.equal(moves.length,2);assert.equal(moves[1].at.y,p.location.y);
  const outsider=player().p;outsider.name='outsider';assert.throws(()=>social.travelGuildBase(outsider),/가입/);assert.equal(social.setGuildBase(outsider),false);
  p.setDynamicProperty('rpg:dungeon_return_v1','{}');assert.throws(()=>social.travelGuildBase(p),/이동할 수 없습니다/);assert.equal(moves.length,2);
 }finally{Object.assign(world,original);Form.prototype.show=shown;}
 console.log('Spawn and guild travel execute teleports; guild base saved, outsiders denied, dungeon escape denied');
}
assert.ok(commandDefs.get('rpg:wings').d.optionalParameters);
assert.equal(commandDefs.has('wings'),false);
{
 const {p,inv}=player('cleric'),ally=player().p;ally.id='fullbag-ally';p.addTag('rpg_team_full');ally.addTag('rpg_team_full');
 for(let i=0;i<inv.size;i++)inv.setItem(i,new ItemStack('minecraft:stone',64));
 const r=mod('core/angelHealing.js');assert.equal(r.recordAngelHealing(p,ally,600),2);assert.equal(r.readAngelHealing(p).pending,2);
 inv.setItem(4,undefined);assert.equal(r.claimAngelLight(p),2);assert.equal(inv.getItem(4).amount,2);assert.equal(r.readAngelHealing(p).pending,0);assert.equal(r.claimAngelLight(p),0);
}
{
 const {p,inv}=player(),u=mod('core/upgrades.js'),w=mod('core/wallet.js');w.setWallet(p,{gold:100000,stone:1000,dust:1000});inv.setItem(6,new ItemStack('rpg:common_redmoon_blade'));
 const q=u.enhancementQuote(p,'weapon',6),old=inv.setItem,balance=w.getWallet(p).gold;let fail=true;
 inv.setItem=(slot,item)=>{if(slot===6&&fail){fail=false;throw Error('storage failure');}return old(slot,item);};
 assert.equal(u.enhanceEquipped(p,'weapon',6,q.fingerprint,{random:()=>0}).ok,false);assert.equal(w.getWallet(p).gold,balance);assert.equal(inv.getItem(6).getDynamicProperty('rpg:weapon_upgrade'),undefined);
}
console.log('Full inventory queues blessing rewards without loss/duplicates; inventory upgrade write failure refunds wallet and restores weapon');

{
 const api=mod('core/wings.js'),actions=mod('core/rpgActions.js');
 assert.ok(mod('core/statusTablet.js').ALL_STATUS_ACTIONS.some(a=>a.action==='wingspeed'));
 for(const job of ['angel','michael']){
  const {p}=player(job);p.id='speed-command-'+job;
  // Wing commands are now registered directly by the gameplay BP, without relay.
  p.runCommand=command=>{const match=/^scriptevent rpg:(\w+)\s*(.*)$/.exec(command);assert.ok(match);actions.runRpgAction(match[1],p,match[2]);};
  for(const mode of [1,2,3]){commandDefs.get('rpg:wings').fn({sourceEntity:p},String(mode));timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),({1:1,2:2,3:5})[mode]);}
  const old=Form.prototype.show;
  try{
   for(const [selection,expected]of [[0,1],[1,2],[2,5]]){Form.prototype.show=()=>Promise.resolve({selection});await api.openWingSpeedMenu(p);assert.equal(api.wingSpeedMultiplier(p),expected);}
   for(const picked of [{canceled:true},{selection:3},{selection:-1},{selection:99}]){Form.prototype.show=()=>Promise.resolve(picked);await api.openWingSpeedMenu(p);assert.equal(api.wingSpeedMultiplier(p),5);}
  }finally{Form.prototype.show=old;}
 }
 console.log('Native namespace registration enforced; direct gameplay /rpg:wings callback sets all speeds; status speed menu sets 1/2/5x and cancellation preserves selection');
}

{
 const api=mod('core/wings.js');
 assert.equal(commandDefs.get('rpg:wings').d.optionalParameters[0].type,server.CustomCommandParamType.Integer);
 assert.equal(commandDefs.get('rpg:wingspeed').d.optionalParameters[0].type,server.CustomCommandParamType.Integer);
 for(const name of ['wings','wingspeed','wings1','wings2','wings3'])assert.equal(allCommandDefs.get('rpg:'+name).length,1,'only gameplay pack owns '+name);
 for(const job of ['angel','michael']){
  const {p}=player(job);p.id='direct-command-'+job;
  p.runCommand=()=>{throw Error('wing commands must not relay through scriptevent');};
  for(const [mode,expected]of [[1,1],[2,2],[3,5]]){
   const fixed=commandDefs.get('rpg:wings'+mode);assert.equal(fixed.d.optionalParameters,undefined);
   fixed.fn({sourceEntity:p});timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),expected);
   commandDefs.get('rpg:wings').fn({sourceEntity:p},mode);timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),expected);
  }
  commandDefs.get('rpg:wings').fn({sourceEntity:p},[2]);timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),2);
  commandDefs.get('rpg:wingspeed').fn({sourceEntity:p},3);timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),5);
  for(const invalid of [0,4,-1]){commandDefs.get('rpg:wings').fn({sourceEntity:p},invalid);timers.at(-1)();assert.equal(api.wingSpeedMultiplier(p),5);}
 }
 console.log('Gameplay BP is sole owner of five wing commands; integer 1/2/3 and argument-free wings1/2/3 set 1x/2x/5x, with no command pack relay');
}
// v0.6.32 offer rewards: physical consumption, trial overlap and atomic rollback.
for(const job of ['apprentice','mage','cleric','michael','swordsman']){
 const {p,inv}=player(job),offer=mod('core/offer.js');p.id='mana-offer-'+job;
 inv.setItem(2,new ItemStack('minecraft:book',2));inv.setItem(3,new ItemStack('minecraft:enchanted_book',3));inv.setItem(4,new ItemStack('minecraft:diamond_block',2));
 const before=data.maxManaOf(p);data.setMana(p,17);
 const result=offer.offerItems(p);assert.equal(result.ok,true,result.message);assert.equal(result.counts.books,5);assert.equal(result.counts.diamonds,2);
 assert.equal(data.maxManaOf(p)-before,650);assert.equal(data.getMana(p),667);
 for(const slot of [2,3,4])assert.equal(inv.getItem(slot),undefined);
 assert.equal(offer.offerItems(p).ok,false);assert.equal(data.maxManaOf(p)-before,650);
 const prog=data.getProgress(p);assert.equal(prog.mana_offer_books,5);assert.equal(prog.mana_offer_diamonds,2);
 if(job==='mage')assert.equal(prog.tech_books,3);if(job==='apprentice')assert.equal(prog.books,3);
 const persisted=p.getDynamicProperty('rpg:progress'),copy=player(job).p;copy.setDynamicProperty('rpg:progress',persisted);assert.equal(data.maxManaOf(copy),data.maxManaOf(p));
 inv.setItem(2,new ItemStack('minecraft:book'));assert.equal(offer.offerItems(p).ok,true);assert.equal(data.maxManaOf(p)-before,700);
}
{
 const {p,inv}=player('mage'),offer=mod('core/offer.js');p.setDynamicProperty('rpg:progress',JSON.stringify({books:30,tech_books:9}));
 const before=data.maxManaOf(p);assert.equal(before,800);
 inv.setItem(2,new ItemStack('minecraft:enchanted_book',4));assert.equal(offer.offerItems(p).ok,true);assert.equal(data.maxManaOf(p)-before,200);
 assert.equal(data.getProgress(p).tech_books,10);assert.equal(data.getProgress(p).books,33);assert.equal(data.getProgress(p).mana_legacy_books,30);
 data.setJobId(p,'swordsman');assert.equal(data.maxManaOf(p),1200);data.setJobId(p,'mage');assert.equal(data.maxManaOf(p),1000);
 inv.setItem(2,new ItemStack('minecraft:enchanted_book'));assert.equal(offer.offerTechBooks(p).ok,false);
 assert.equal(offer.offerBooks(p).ok,true);assert.equal(data.maxManaOf(p),1050);
}
for(const failAt of ['inventory','progress','mana']){
 const {p,inv}=player('mage'),offer=mod('core/offer.js');p.setDynamicProperty('rpg:progress',JSON.stringify({books:20}));data.setMana(p,100);
 inv.setItem(2,new ItemStack('minecraft:book',2));inv.setItem(3,new ItemStack('minecraft:diamond_block',2));
 const oldProgress=p.getDynamicProperty('rpg:progress'),before=data.maxManaOf(p),setter=p.setDynamicProperty,write=inv.setItem;let failed=false;
 inv.setItem=(slot,item)=>{if(failAt==='inventory'&&slot===3&&!failed){failed=true;throw Error('inventory save failure');}return write(slot,item);};
 p.setDynamicProperty=(key,v)=>{if(!failed&&((failAt==='progress'&&key==='rpg:progress')||(failAt==='mana'&&key==='rpg:mana'))){failed=true;throw Error('property save failure');}return setter(key,v);};
 assert.equal(offer.offerItems(p).ok,false);assert.equal(failed,true);assert.equal(p.getDynamicProperty('rpg:progress'),oldProgress);assert.equal(data.maxManaOf(p),before);assert.equal(data.getMana(p),100);assert.equal(inv.getItem(2).amount,2);assert.equal(inv.getItem(3).amount,2);
}
console.log('Offer: normal/enchanted book +50 and diamond block +200 for five job types; current/max mana, legacy progress, trial overlap, persistence, repeats and inventory/progress/mana failure rollback passed');
{
 const {p,inv}=player('mage'),offer=mod('core/offer.js');data.forceSetManaMax(p,'100000');inv.setItem(2,new ItemStack('minecraft:diamond_block'));
 const denied=offer.offerItems(p);assert.equal(denied.ok,false);assert.ok(denied.message.includes('reset'));assert.equal(inv.getItem(2).amount,1);assert.equal(data.maxManaOf(p),100000);
 data.forceSetManaMax(p,'reset');const before=data.maxManaOf(p);assert.equal(offer.offerItems(p).ok,true);assert.equal(data.maxManaOf(p)-before,200);
}
// v0.6.32 real estate, ownership protection, preview and diamond shop.
{
 const estate=mod('core/realEstate.js'),shop=mod('core/xpShop.js'),town=mod('core/townProtection.js'),protection=mod('core/structureProtection.js');
 const {p,inv}=player();p.id='land-owner';p.location={x:48,y:80,z:64};p.selectedSlotIndex=3;
 const other=player().p;other.id='land-guest';other.name='LandGuest';const globals=new Map(),old={getDynamicProperty:world.getDynamicProperty,setDynamicProperty:world.setDynamicProperty,beforeEvents:world.beforeEvents};
 world.getDynamicProperty=k=>globals.get(k);world.setDynamicProperty=(k,v)=>v===undefined?globals.delete(k):globals.set(k,v);
 const region={x:0,y:64,z:0,size:250,dimId:'minecraft:overworld'};globals.set('rpg:spawn_town_region_v1',JSON.stringify(region));
 const at=(x,y,z)=>({location:{x,y,z},dimension:p.dimension,typeId:'minecraft:stone'});
 try{
  assert.equal(shop.XP_PRODUCTS[5].currency,'diamond');inv.setItem(1,new ItemStack('minecraft:diamond',4));assert.equal(shop.purchaseXpProduct(p,5).ok,false);assert.equal(inv.getItem(1).amount,4);
  inv.setItem(2,new ItemStack('minecraft:diamond',3));assert.equal(shop.purchaseXpProduct(p,5).ok,true);assert.equal(inv.getItem(1),undefined);assert.equal(inv.getItem(2).amount,2);
  const voucher=Array.from({length:inv.size},(_,i)=>inv.getItem(i)).find(i=>i?.typeId===estate.LAND_DEED);assert.ok(voucher);
  // Before purchase even an existing house footprint is protected.
  assert.equal(town.townProtected(at(49,65,65),region,p),true);
  inv.setItem(3,voucher);const selection=estate.landSelection(p);assert.equal(selection.cx,3);assert.equal(selection.cz,4);
  assert.equal(estate.claimTownChunk(p,selection.key).ok,true);assert.equal(inv.getItem(3),undefined);assert.equal(estate.landOwner(selection).id,p.id);
  for(const y of [65,90,250,319])assert.equal(town.townProtected(at(49,y,65),region,p),false);
  for(const y of [64,63,-64])assert.equal(town.townProtected(at(49,y,65),region,p),true);
  assert.equal(town.townProtected(at(49,65,65),region,other),true);assert.equal(town.townProtected(at(64,65,65),region,p),true);assert.equal(town.townProtected(at(49,65,65),region),true);
  inv.setItem(3,new ItemStack(estate.LAND_DEED,2));assert.equal(estate.claimTownChunk(p).ok,false);assert.equal(inv.getItem(3).amount,2);
  const particles=[];p.dimension.spawnParticle=(id,at)=>particles.push(at);p.onScreenDisplay.setActionBar=()=>{};estate.previewLand(p);assert.equal(particles.length,36);assert.ok(particles.every(at=>at.x===48||at.x===64||at.z===64||at.z===80));
  const data=globals.get(estate.LAND_KEY);assert.ok(JSON.parse(data)[selection.key]); // Reload from persisted world property on every read.
  p.location.x=-0.1;assert.equal(estate.landSelection(p),undefined);assert.equal(estate.landSelection({dimension:p.dimension,location:{x:-0.1,y:0,z:-0.1}},{x:-128,y:64,z:-128,size:250,dimId:'overworld'}).cx,-1);
  p.location.x=249;assert.equal(estate.landSelection(p),undefined);p.location.x=80;
  let failed=false;world.setDynamicProperty=(key,value)=>{if(key===estate.LAND_KEY&&!failed){failed=true;throw Error('disk failure');}globals.set(key,value);};
  assert.equal(estate.claimTownChunk(p).ok,false);assert.equal(inv.getItem(3).amount,2);assert.equal(globals.get(estate.LAND_KEY),data);world.setDynamicProperty=(key,value)=>globals.set(key,value);
  const expected=estate.landSelection(p).key;p.location.z+=16;assert.equal(estate.claimTownChunk(p,expected).ok,false);assert.equal(inv.getItem(3).amount,2);
  // Run the actual protection event hooks with actor identity.
  world.beforeEvents=new Proxy({},{get:(_,key)=>({subscribe:fn=>signal('before:'+key).subscribe(fn)})});town.registerTownProtection();
  const fire=(key,event)=>{signal('before:'+key).fire(event);return !!event.cancel;};
  assert.equal(fire('playerBreakBlock',{player:p,block:at(49,65,65)}),false);assert.equal(fire('playerBreakBlock',{player:other,block:at(49,65,65)}),true);assert.equal(fire('playerBreakBlock',{player:p,block:at(49,64,65)}),true);
  const interaction={player:p,block:at(49,64,65),blockFace:'Up',itemStack:new ItemStack('minecraft:stone')};assert.equal(fire('playerInteractWithBlock',interaction),false);
  assert.equal(fire('playerInteractWithBlock',{...interaction,player:other,cancel:false}),true);
  let remaining;fire('explosion',{getImpactedBlocks:()=>[at(49,65,65),at(49,64,65)],setImpactedBlocks:v=>remaining=v});assert.equal(remaining.length,0);
 }finally{Object.assign(world,old);}
}
{
 const {p,inv}=player(),shop=mod('core/xpShop.js');for(let i=0;i<inv.size;i++)inv.setItem(i,new ItemStack('minecraft:stone',64));inv.setItem(3,new ItemStack('minecraft:diamond',6));
 assert.equal(shop.purchaseXpProduct(p,5).ok,false);assert.equal(inv.getItem(3).amount,6);for(let i=0;i<inv.size;i++)assert.notEqual(inv.getItem(i)?.typeId,'rpg:land_deed');
}
console.log('Land: five diamonds per deed with insufficient/full-bag refund; persistent full-chunk ownership, floor/underground/guest/neighbour protection, owner placement on floor, explosion protection, negative coordinates, selection changes and save rollback; held-deed boundary particles passed');
{
 const mage=mod('core/mageBasic.js'),skills=mod('data/skills.js').SKILLS;
 for(const [id,expected]of [['mage_fireball',7.5],['mage_lightning',20],['mage_thunder',100],['mage_gravity',80],['mage_bombaye',60],['mage_flame_on',75],['mage_ice_fire',90]])assert.equal(skills[id].mana,expected);
 assert.equal(skills.holy_heal.mana,30); // Other families keep their prior cost.
 const {p,inv}=player('mage');p.id='mage-basic-test';inv.setItem(0,new ItemStack(jobs.mage.weapon));data.setSkills(p,jobs.mage.skills);data.setMana(p,200);const ctx=mod('core/context.js').getContext(p);
 const originalTick=system.currentTick;
 try{
  for(const id of mage.MAGE_BASIC_IDS){
   assert.equal(mage.setMageBasic(p,id),true);const def=mage.mageBasicDefinition(p);assert.equal(def.cooldown,20);assert.ok(Math.abs(def.damage-skills[id].damage*.8)<1e-9);assert.notEqual(def,skills[id]);
   system.currentTick+=20;data.setMana(p,200);const before=data.getMana(p);let seen;
   assert.equal(mage.castMageBasic(p,ctx,(_p,_j,d)=>{seen=d;}),true);assert.equal(seen.id,id);assert.equal(data.getMana(p),before-Math.ceil(skills[id].mana));
   const next=mage.MAGE_BASIC_IDS[(mage.MAGE_BASIC_IDS.indexOf(id)+1)%4];mage.setMageBasic(p,next);assert.equal(mage.castMageBasic(p,ctx,()=>{throw Error('cooldown must block');}),false);
  }
  assert.equal(mage.setMageBasic(p,'sage_meteor'),false);system.currentTick+=20;data.setMana(p,0);assert.equal(mage.castMageBasic(p,ctx,()=>{throw Error('insufficient mana');}),false);
  const nonMage=player('cleric').p;assert.equal(mage.mageBasicDefinition(nonMage),undefined);assert.equal(mage.setMageBasic(nonMage,'mage_fireball'),false);
  mage.setMageBasic(p,'mage_gravity');data.setMana(p,200);p.dimension.getEntities=()=>[];p.dimension.playSound=()=>{};p.dimension.spawnParticle=()=>{};
  mod('core/input.js').registerInput();signal('playerSwingStart').fire({player:p});assert.equal(data.cooldownLeft(p,'mage_basic'),20);assert.equal(data.getMana(p),120);
 }finally{system.currentTick=originalTick;}
}
console.log('Mage: mana halved; one chosen basic spell at .8 damage/20 ticks, other definitions untouched, shared cooldown blocks switching exploit, mana/class gates and actual swing input passed');
{
 const tablet=mod('core/statusTablet.js'),{p}=player(),calls=[],old=Form.prototype.show;const root=tablet.STATUS_ACTIONS;assert.equal(root.length,9);
 const all=tablet.ALL_STATUS_ACTIONS.map(a=>a.action);for(const id of ['jobs','spawn','party','guild','dungeon','pvp','tpa','tpaaccept','magebasic','upgrade','wallet'])assert.ok(all.includes(id));assert.equal(new Set(all).size,all.length);
 tablet.registerStatusTablet((action)=>calls.push(action));
 try{
  for(const [group,action]of [['social','party'],['social','guild'],['combat','dungeon'],['combat','pvp'],['travel','tpa'],['travel','tpaaccept'],['character','magebasic'],['shop','xpshop']]){
   const answers=[{selection:root.findIndex(a=>a.action==='group:'+group)},{selection:tablet.STATUS_GROUPS[group].items.findIndex(a=>a[0]===action)}];Form.prototype.show=()=>Promise.resolve(answers.shift());await tablet.openStatusTablet(p);timers.at(-1)();assert.equal(calls.at(-1),action);
  }
  const answers=[{selection:root.findIndex(a=>a.action==='group:travel')},{selection:tablet.STATUS_GROUPS.travel.items.length},{selection:root.findIndex(a=>a.action==='close')}];Form.prototype.show=()=>Promise.resolve(answers.shift());const count=calls.length;await tablet.openStatusTablet(p);assert.equal(calls.length,count);assert.equal(answers.length,0);
 }finally{Form.prototype.show=old;}
}
console.log('Status: nine root buttons, all previous actions preserved in seven categories; party/guild, dungeon/PvP and TPA request/accept routes and Back/Close execute correctly');
{
 const estate=mod('core/realEstate.js'),shop=mod('core/xpShop.js'),town=mod('core/townProtection.js'),{p,inv}=player(),saved=new Map(),old={getDynamicProperty:world.getDynamicProperty,setDynamicProperty:world.setDynamicProperty},show=Form.prototype.show;
 p.id='land-end-to-end';p.location={x:112,y:65,z:112};p.level=0;inv.setItem(0,new ItemStack(jobs.swordsman.weapon));inv.setItem(2,new ItemStack('minecraft:diamond',5));
 world.getDynamicProperty=k=>saved.get(k);world.setDynamicProperty=(k,v)=>saved.set(k,v);saved.set('rpg:spawn_town_region_v1',JSON.stringify({x:0,y:64,z:0,size:250,dimId:p.dimension.id}));
 try{
  const answers=[{selection:5},{selection:1},{selection:shop.XP_PRODUCTS.length}];Form.prototype.show=()=>Promise.resolve(answers.shift());await shop.openXpShop(p);assert.equal(answers.length,0);assert.equal(inv.getItem(2),undefined);assert.equal(p.level,0);
  const slot=Array.from({length:inv.size},(_,i)=>i).find(i=>inv.getItem(i)?.typeId===estate.LAND_DEED);assert.notEqual(slot,undefined);p.selectedSlotIndex=slot;
  Form.prototype.show=()=>Promise.resolve({selection:0});await estate.useLandDeed(p);assert.equal(inv.getItem(slot).amount,1);assert.equal(saved.get(estate.LAND_KEY),undefined);
  Form.prototype.show=()=>Promise.resolve({selection:1});componentHandlers.get('rpg:land_deed').onUse({source:p});timers.at(-1)();await new Promise(resolve=>setImmediate(resolve));
  assert.equal(estate.landOwner(estate.landSelection(p)).id,p.id);assert.equal(inv.getItem(slot),undefined);
  saved.set(estate.LAND_KEY,'broken JSON');assert.equal(town.townProtected({dimension:p.dimension,location:p.location},undefined,p),true);
 }finally{Object.assign(world,old);Form.prototype.show=show;}
 console.log('Actual shop UI -> diamond purchase -> held item custom component -> confirmation -> persistent ownership; cancellation spends nothing, corrupt land data fails closed');
}
