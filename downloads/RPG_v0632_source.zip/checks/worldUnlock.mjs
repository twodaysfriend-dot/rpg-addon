import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0632';
const base=root+'/RPG_BP_v0632/';
async function load(file,bindings={}){
 const context=vm.createContext({console});const m=new vm.SourceTextModule(fs.readFileSync(base+file,'utf8'),{context});
 await m.link(async spec=>{
  const source=fs.readFileSync(base+file,'utf8');
  const names=[];
  for(const match of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(match[2]===spec)names.push(...match[1].split(',').map(s=>s.trim().split(/\s+as\s+/)[0]));
  return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});
 });await m.evaluate();return m.namespace;
}


const stats=await load('scripts/core/stats.js',{getEquipmentBonuses:()=>({physical:1,magic:1}),classWeapon:()=>undefined,CONFIG:{skillDamage:{strengthPerLevel:.05}}});
const p=(n,int=5,job='mage')=>({typeId:'minecraft:player',getDynamicProperty:k=>k==='rpg:stat_values'?JSON.stringify({str:n,mag:n,vit:5,int}):k==='rpg:job'?job:undefined,getComponent:()=>undefined,getEffect:()=>undefined});
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-9,`${a} != ${b}`);
close(stats.skillDamageFor(p(6),10,'physical')-10,.2352);close(stats.skillDamageFor(p(6),10,'magic')-10,.588);close(stats.healingFor(p(6),10)-10,.098);
assert.equal(stats.skillDamageFor(p(100),10,'fixed'),10);assert.equal(stats.manaCostFor(p(5,50),100),60);assert.equal(stats.manaCostFor(p(5,50,'nen'),100),50);
const recipe=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0632/recipes/stand_manifestation_arrow.json','utf8'))['minecraft:recipe_shaped'];
const slots=recipe.pattern.join('').split('').map(k=>recipe.key[k].item);
assert.deepEqual(slots,['minecraft:gold_block','minecraft:gold_block','minecraft:gold_block','minecraft:gold_block','minecraft:arrow','minecraft:gold_block','minecraft:diamond_block','minecraft:netherite_ingot','minecraft:diamond_block']);
assert.equal(recipe.result.item,'rpg:stand_manifestation_arrow');assert.equal(recipe.result.count,1);
const item=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0632/items/stand_manifestation_arrow.json','utf8'))['minecraft:item'];assert.ok(item.components['rpg:stand_manifestation_arrow']);
const atlas=JSON.parse(fs.readFileSync(root+'/RPG_RP_v0632/textures/item_texture.json','utf8'));assert.ok(atlas.texture_data[item.components['minecraft:icon']]);
const trial=(await load('scripts/data/jobTrials.js')).JOB_TRIALS.the_world;assert.equal(trial.level,60);assert.equal(trial.stoneMask,true);assert.equal(trial.standArrow,true);assert.ok(trial.all.some(c=>c.key==='job_boss'&&c.need===3));assert.ok(trial.all.some(c=>c.key==='job_night'&&c.need===60));
console.log('Stats: STR/MAG/HP-heal point bonuses halved, fixed damage and INT mana savings unchanged; World arrow exact slots 1-9, result/item/icon and level60/mask/arrow plus existing trial gates verified');
