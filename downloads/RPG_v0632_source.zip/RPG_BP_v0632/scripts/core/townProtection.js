import {spawnRegion} from './spawnEffects.js';
import {canEditTownChunk} from './realEstate.js';
import {registerStructureProtection} from './structureProtection.js';
const dimensionId=id=>id?.replace('minecraft:','');
export function townProtected(block,region=spawnRegion(),player,operation){
 if(!region||!block?.location||dimensionId(block.dimension?.id)!==dimensionId(region.dimId))return false;
 const {x,y,z}=block.location;
 if(x<region.x||x>=region.x+region.size||z<region.z||z>=region.z+region.size)return false;
 try{if(!canEditTownChunk(player,block,region))return true;}catch{return true;}
 // A purchased chunk allows building on top of the permanent village floor.
 if(operation==='support'&&Math.floor(y)===region.y)return false;
 return Math.floor(y)<=region.y;
}
let registered=false;
export function registerTownProtection(){if(registered)return;registered=true;registerStructureProtection('town',(block,player,operation)=>townProtected(block,spawnRegion(),player,operation));}
