// 숫자 조정은 이 파일과 data/skills.js 에서 합니다. (20틱 = 1초, 체력 1칸 = 피해 2)
export const CONFIG = {
  partyXp: {
    radius: 32, // 처치자 중심, 같은 차원·생존 중인 파티원
    multiplier: 0.75, // 파티원 각자가 몬스터 원래 XP의 75%를 획득 (총량 분할 아님)
  },
  // true 면 다른 플레이어에게도 스킬 피해가 들어갑니다. (시전자 본인은 항상 제외)
  pvp: true,

  // 플레임온 등이 엔티티에게 불을 붙일지. 바닥/블록에는 어떤 스킬도 불을 붙이지 않습니다.
  igniteEntities: true,

  mana: {
    normalMax: 1000, // 일반 직업의 공물 보너스 적용 전 최대 마나
    base: 200, // 책을 바치기 전 기본 최대 마나
    perBook: 10, // 인챈트 책 1권당 최대 마나 증가 (일반 직업)
    perBookHigh: 20, // 이전 버전 책 공물의 마법/성직 마나 유지
    offerBook: 50, // v0.6.32부터 실제 바친 일반·효과부여 책 1권
    offerDiamondBlock: 200, // v0.6.32부터 실제 바친 다이아몬드 블록 1개
    capNormal: 300, // 일반 직업 최대 마나 상한
    capHigh: 0, // (사용 안 함) 마법사/성직자 계열은 상한 없이 책 수만큼 계속 증가
    regenRate: 0.01, // 1초마다 최대 마나의 1% 회복
    maxBooks: 90, // 바칠 수 있는 책 총량 (200 + 90 x 20 = 2000)
  },

  // 번개 연출(라이트닝 / 번개 / 뇌영)을 진짜 벼락(minecraft:lightning_bolt)으로 칠지.
  lightning: {
    real: true, // false 로 하면 예전처럼 파티클+소리만 사용
    boltDamage: 5, // 진짜 벼락이 대상에게 주는 기본 피해(추정). 단일 대상 스킬은 이만큼 빼고 직접 피해를 줘서 합계를 맞춥니다.
    protectRadius: 8, // 벼락 주변의 플레이어(시전자 포함)가 벼락 피해/화상을 안 받도록 잠깐 보호하는 반경
  },

  // 스킬 설정창. 웅크린 채로 책/지팡이를 우클릭하면 열립니다. (false 면 /scriptevent rpg:skills 로만 열림)
  skillMenuOnSneakUse: true,

  // 액션바(HUD) 갱신 주기(틱)
  hudInterval: 4,

  // 물리·마법 스킬의 힘 상태 효과 보정 (고정 피해 제외)
  skillDamage: {
    strengthPerLevel: 0.05, // 힘 효과 1단계당 스킬 피해 +5% (고정 피해 제외)
  },

  // 3차(검성 / 타락검성) 기본 공격: 검을 휘두르는 순간의 참격만 표시 (직선 에너지 투사체 없음)
  basic: {
    cooldown: 8,
    damage: 6,
    range: 10,
    speed: 1.4,
    hitRadius: 1.6,
    knockback: 0.6,
  },
};
