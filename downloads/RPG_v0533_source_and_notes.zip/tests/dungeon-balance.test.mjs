import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {calculate,targetSummary} from '../tools/compare_enhancement_costs.mjs';
import {HUNT_REWARDS,WAVES} from '../RPG_BP_v0533/scripts/data/dungeons.js';
import {player,players} from './minecraftMock.mjs';
import {currencyReward,grantKillCurrencies} from '../RPG_BP_v0533/scripts/core/economy.js';
test('all-five-rune target includes all materials and catalysts and stays near twenty hours',()=>{
 const [hunt,dungeon]=targetSummary();assert.ok(hunt.normalHoursWithoutCatalystSourcing>19.5&&hunt.normalHoursWithoutCatalystSourcing<20.5);assert.ok(dungeon.dungeonHours>19&&dungeon.dungeonHours<20.5);assert.ok(dungeon.allFiveRunes.catalysts>500);assert.ok(dungeon.dungeonClears>110);assert.equal(dungeon.killPlusClearReward.gold,9128);assert.equal(dungeon.killPlusClearReward.stone,92);assert.ok(Math.abs(dungeon.killPlusClearReward.dust-15.8)<1e-9);
 const costs=calculate();assert.ok(Math.abs(costs[0].allFiveRunes.gold-1643309.60234)<.01);assert.ok(Math.abs(costs[1].allFiveRunes.gold-231634.01487)<.01);
});
test('each wave mob has a persistent event and every supply item exists in the actual pack',()=>{
 for(const type of new Set(WAVES.flatMap(w=>w.types))){const e=JSON.parse(fs.readFileSync(new URL('../RPG_BP_v0533/entities/'+type+'.json',import.meta.url)))['minecraft:entity'];assert.deepEqual(e.events['rpg:dungeon_persistent'].add.component_groups,['rpg:dungeon_persistent']);assert.deepEqual(e.component_groups['rpg:dungeon_persistent'],{'minecraft:persistent':{}});assert.ok(currencyReward('rpg:'+type).gold>0);}
 assert.equal(currencyReward('minecraft:zombie',()=>0).gold,HUNT_REWARDS.normal.gold);
});

test('higher normal rewards do not turn every normal kill into a chat notification',()=>{
 const p=player('quiet-hunt');players.push(p);for(let i=0;i<5;i++)grantKillCurrencies(p,{typeId:'minecraft:zombie'},()=>.5);
 assert.equal(p.messages.length,1);grantKillCurrencies(p,{typeId:'rpg:elite_green_goblin'});assert.equal(p.messages.length,2);grantKillCurrencies(p,{typeId:'rpg:rock_golem_boss'});assert.equal(p.messages.length,3);
});
