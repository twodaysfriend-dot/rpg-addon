import test from 'node:test';
import assert from 'node:assert/strict';
import {player,players,world,events,system,timeouts,ItemStack} from './minecraftMock.mjs';
import {DUNGEON_KEY,RETURN_KEY,createDungeon,listDungeons,dungeonTick,enterDungeon,leaveDungeon,dungeonDeath,recoverDungeons,registerDungeons,removeDungeon} from '../RPG_BP_v0533/scripts/core/dungeons.js';
import {DUNGEON_LOOT_KEY,creditDungeonClear,claimDungeonLoot,readDungeonLoot} from '../RPG_BP_v0533/scripts/core/dungeonRewards.js';
import {DUNGEON,dungeonBlock,WAVES} from '../RPG_BP_v0533/scripts/data/dungeons.js';
import {getWallet,setWallet} from '../RPG_BP_v0533/scripts/core/wallet.js';
import {CATALYST_ID} from '../RPG_BP_v0533/scripts/data/upgrades.js';
import {runRpgAction} from '../RPG_BP_v0533/scripts/core/rpgActions.js';
const blocks=new Map(),mobs=new Map(),key=q=>[q.x,q.y,q.z].join(',');let counter=0,blockWrites=0,spawnFailure=false;
const dim={id:'minecraft:overworld',getBlock(q){const k=key(q);return {location:{x:q.x,y:q.y,z:q.z},dimension:dim,get typeId(){return blocks.get(k)??'minecraft:air';},get isAir(){return !blocks.has(k);},setType(id){blockWrites++;blocks.set(k,id);}};},
 getEntities(query={}){return [...mobs.values()].filter(m=>!query.tags||query.tags.every(t=>m.hasTag(t)));},
 spawnEntity(typeId,location){if(spawnFailure)throw Error('spawn unavailable');const tags=new Set(),m={id:'mob'+(++counter),typeId,dimension:dim,location,isValid:true,addTag:t=>tags.add(t),hasTag:t=>tags.has(t),triggerEvent(e){this.event=e;},remove(){mobs.delete(this.id);this.isValid=false;}};mobs.set(m.id,m);return m;}};
world.getDimension=id=>{if(id!==dim.id)throw Error('bad dimension');return dim;};
function actor(id,x=0,admin=false){const p=player(id,30,{dimension:dim,location:{x,y:64,z:0},commandPermissionLevel:admin?1:0});p.teleport=(loc,opt)=>{p.location={...loc};p.dimension=opt.dimension;};players.push(p);return p;}
for(const name of ['playerBreakBlock','playerPlaceBlock','explosion'])world.beforeEvents[name]={listeners:[],subscribe(fn){this.listeners.push(fn);}};
const leader=actor('dungeon-leader',0,true),ally=actor('dungeon-ally',2),outsider=actor('outsider',0);
world.setDynamicProperty('rpg:social_v1',JSON.stringify({version:1,nextId:2,guilds:[],parties:[{id:1,leader:leader.name,members:[leader.name,ally.name]}]}));
function tick(n=1){for(let i=0;i<n;i++){system.currentTick++;dungeonTick();}}
function killWave(){const active=[...mobs.values()];assert.ok(active.length);for(const e of active){mobs.delete(e.id);dungeonDeath({deadEntity:e});}return active;}
function scheduled(){const fns=timeouts.splice(0);for(const fn of fns)fn();}
function resetGroup(){for(const p of [leader,ally]){if(p.getDynamicProperty(RETURN_KEY)!==undefined)leaveDungeon(p);p.location={x:0,y:64,z:0};p.health=20;p.getGameMode=()=> 'survival';}}

test('only administrators can generate a dungeon through every action route',()=>{
 assert.throws(()=>createDungeon(outsider,'bad'),/관리자/);runRpgAction('dungeoncreate',outsider,'bad');assert.ok(outsider.messages.at(-1).includes('관리자'));assert.equal(listDungeons().length,0);
});
test('invalid names are rejected and blueprint has floor, roof, walls and traversable doors',()=>{
 for(const id of ['','../world','two words','x;kill','A','this_name_is_too_long'])assert.throws(()=>createDungeon(leader,id));
 assert.ok(dungeonBlock(0,0,0));assert.ok(dungeonBlock(21,5,0));assert.ok(dungeonBlock(11,18,11));assert.equal(dungeonBlock(0,2,11),undefined);assert.ok(dungeonBlock(0,6,11));assert.equal(dungeonBlock(11,3,11),undefined);
});
test('generation scans the whole empty volume before writing and builds a persistent ready dungeon',()=>{
 createDungeon(leader,'ruin');tick(20);assert.equal(blockWrites,0);assert.throws(()=>createDungeon(leader,'overlap'),/겹칩니다/);assert.throws(()=>createDungeon(leader,'ruin'),/생성 중/);
 tick(300);const d=listDungeons().find(d=>d.id==='ruin');assert.equal(d.status,'ready');assert.ok(blockWrites>3000);assert.ok(world.getDynamicProperty(DUNGEON_KEY).includes('ruin'));assert.equal(blocks.get(key({x:d.x,y:d.y,z:d.z})),'minecraft:sea_lantern');
});
test('an occupied candidate is rejected without changing any existing block',()=>{
 const p=actor('occupied-admin',150,true);blocks.set('129,96,-21','minecraft:diamond_block');const before=blockWrites;createDungeon(p,'occupied');tick(2);assert.equal(blockWrites,before);assert.equal(blocks.get('129,96,-21'),'minecraft:diamond_block');assert.equal(listDungeons().some(d=>d.id==='occupied'),false);
});
test('nonleader, distant, dead and creative party entry are rejected before teleport',()=>{
 assert.throws(()=>enterDungeon(ally,'ruin'),/파티장/);
 for(const condition of ['far','dead','creative']){
  resetGroup();if(condition==='far')ally.location.x=33;if(condition==='dead')ally.health=0;if(condition==='creative')ally.getGameMode=()=> 'creative';
  assert.throws(()=>enterDungeon(leader,'ruin'),/32칸/);assert.equal(leader.getDynamicProperty(RETURN_KEY),undefined);
 }
 resetGroup();
});
test('real 4-stage clear pays each of two members once, then returns them and stores full-bag loot',()=>{
 registerDungeons();ally.slots.fill(new ItemStack('minecraft:stone',64));
 const result=enterDungeon(leader,'ruin');assert.deepEqual(result.members,[leader.id,ally.id]);assert.ok(leader.location.y>64);assert.throws(()=>enterDungeon(outsider,'ruin'),/진행 중/);
 for(let i=0;i<WAVES.length;i++){
  assert.equal(mobs.size,WAVES[i].types.length);for(const mob of mobs.values())assert.equal(mob.event,'rpg:dungeon_persistent');
  const dead=killWave();for(const e of dead)dungeonDeath({deadEntity:e});if(i<WAVES.length-1)scheduled();
 }
 assert.equal(mobs.size,0);assert.equal(leader.location.y,64);assert.equal(ally.location.y,64);assert.equal(leader.getDynamicProperty(RETURN_KEY),undefined);
 assert.equal(getWallet(leader).gold,2000);assert.equal(getWallet(ally).gold,2000);assert.equal(readDungeonLoot(leader).clears,1);assert.equal(readDungeonLoot(ally).pending[CATALYST_ID],4);assert.equal(ally.slots[0].typeId,'minecraft:stone');
 assert.equal(creditDungeonClear(leader,result.runId).duplicate,true);assert.equal(getWallet(leader).gold,2000);ally.slots.fill(undefined);
});
test('leaving or dying prevents that member from claiming clear rewards',()=>{
 resetGroup();enterDungeon(leader,'ruin');ally.health=0;dungeonDeath({deadEntity:ally});assert.ok(ally.getDynamicProperty(RETURN_KEY));
 const before=getWallet(ally).gold;for(let i=0;i<WAVES.length;i++){killWave();if(i<WAVES.length-1)scheduled();}
 assert.equal(getWallet(ally).gold,before);ally.health=20;leaveDungeon(ally);assert.equal(ally.location.y,64);assert.equal(ally.getDynamicProperty(RETURN_KEY),undefined);resetGroup();
});
test('spawn failure returns the whole party without a clear reward or a busy instance',()=>{
 const before=getWallet(leader).gold;spawnFailure=true;try{assert.throws(()=>enterDungeon(leader,'ruin'),/spawn unavailable/);}finally{spawnFailure=false;}
 assert.equal(leader.location.y,64);assert.equal(ally.location.y,64);assert.equal(getWallet(leader).gold,before);assert.equal(listDungeons().find(d=>d.id==='ruin').busy,false);assert.equal(mobs.size,0);
});
test('server restart aborts the fight, retains return positions and never awards an unearned clear',()=>{
 resetGroup();enterDungeon(leader,'ruin');const gold=getWallet(leader).gold;recoverDungeons();assert.equal(mobs.size,0);assert.equal(listDungeons().find(d=>d.id==='ruin').busy,false);
 for(const fn of events.playerSpawn.listeners)fn({player:leader,initialSpawn:true});scheduled();assert.equal(leader.location.y,64);assert.equal(getWallet(leader).gold,gold);leaveDungeon(ally);resetGroup();
});
test('all-member logout and timeout clean up monsters and allow later return',()=>{
 enterDungeon(leader,'ruin');for(const p of [leader,ally])for(const fn of events.playerLeave.listeners)fn({playerId:p.id});assert.equal(mobs.size,0);leaveDungeon(leader);leaveDungeon(ally);resetGroup();
 const real=Date.now;let now=100000;Date.now=()=>now;
 try{enterDungeon(leader,'ruin');now+=DUNGEON.timeoutMs+1;tick(21);assert.equal(mobs.size,0);assert.equal(leader.location.y,64);}finally{Date.now=real;}
});
test('clear ledger is idempotent and five clears grant every rune, 21 catalysts and one armor kit',()=>{
 const p=player('ledger');for(let run=100;run<105;run++){creditDungeonClear(p,run);creditDungeonClear(p,run);}const s=readDungeonLoot(p);
 assert.equal(s.clears,5);assert.equal(getWallet(p).gold,10000);assert.equal(s.pending[CATALYST_ID],21);
 for(const id of ['power','arcane','vitality','mana','ward'])assert.equal(s.pending['rpg:rune_'+id],1);
 for(const id of ['helmet','chestplate','leggings','boots'])assert.equal(s.pending['rpg:adventurer_'+id],1);
});
test('ledger storage failure restores wallet and allows a single safe retry',()=>{
 const p=player('ledger-fail');setWallet(p,{gold:50,stone:1,dust:2});const write=p.setDynamicProperty.bind(p);let fail=true;
 p.setDynamicProperty=(k,v)=>{if(fail&&k===DUNGEON_LOOT_KEY){fail=false;throw Error('storage');}write(k,v);};assert.throws(()=>creditDungeonClear(p,200));assert.deepEqual(getWallet(p),{gold:50,stone:1,dust:2});assert.equal(readDungeonLoot(p).clears,0);creditDungeonClear(p,200);assert.equal(getWallet(p).gold,2050);
});
test('full inventory keeps pending loot; freeing a slot grants a bounded stack exactly once',()=>{
 const p=player('bag');creditDungeonClear(p,300);p.slots.fill(new ItemStack('minecraft:stone',64));const pending=readDungeonLoot(p).pending;assert.equal(claimDungeonLoot(p).delivered,0);assert.deepEqual(readDungeonLoot(p).pending,pending);
 p.slots[5]=undefined;const r=claimDungeonLoot(p);assert.ok(r.delivered>0);const before=p.slots[5].amount;assert.equal(claimDungeonLoot(p).delivered,0);assert.equal(p.slots[5].amount,before);
});
test('loot never occupies the reserved RPG weapon slot even when it is empty',()=>{
 const p=player('reserved-weapon');creditDungeonClear(p,350);for(let i=1;i<p.slots.length;i++)p.slots[i]=new ItemStack('minecraft:stone',64);
 assert.equal(claimDungeonLoot(p).delivered,0);assert.equal(p.slots[0],undefined);assert.equal(readDungeonLoot(p).pending[CATALYST_ID],4);
});
test('inventory or pending-write failure rolls back claimed loot and leaves the receipt claimable',()=>{
 for(const failure of ['inventory','storage']){
  const p=player('claim-'+failure);creditDungeonClear(p,400);const before=p.getDynamicProperty(DUNGEON_LOOT_KEY);let fail=true;
  if(failure==='inventory'){const real=p.getComponent.bind(p),c=real('minecraft:inventory').container,write=c.setItem;c.setItem=(i,v)=>{if(fail&&i===2){fail=false;throw Error('inventory');}write(i,v);};}
  else{const write=p.setDynamicProperty.bind(p);p.setDynamicProperty=(k,v)=>{if(fail&&k===DUNGEON_LOOT_KEY){fail=false;throw Error('storage');}write(k,v);};}
  assert.throws(()=>claimDungeonLoot(p));assert.equal(p.slots.filter(Boolean).length,0);assert.equal(p.getDynamicProperty(DUNGEON_LOOT_KEY),before);assert.ok(claimDungeonLoot(p).delivered>0);assert.equal(readDungeonLoot(p).clears,1);
 }
});
test('interrupted construction resumes the same saved blueprint without overwriting other blocks',()=>{
 const p=actor('resume-admin',300,true);createDungeon(p,'resume');tick(138);assert.equal(listDungeons().find(d=>d.id==='resume').status,'building');
 const real=dim.getBlock;let calls=0;dim.getBlock=q=>{if(++calls===40)throw Error('chunk unloaded');return real(q);};tick(1);dim.getBlock=real;
 assert.equal(listDungeons().find(d=>d.id==='resume').status,'building');createDungeon(p,'resume');tick(300);assert.equal(listDungeons().find(d=>d.id==='resume').status,'ready');removeDungeon(p,'resume');
});
test('registered floors and walls reject block edits and explosion damage; outside terrain stays editable',()=>{
 const d=listDungeons().find(d=>d.id==='ruin'),block=dim.getBlock({x:d.x,y:d.y,z:d.z}),outside=dim.getBlock({x:500,y:64,z:0});
 for(const name of ['playerBreakBlock','playerPlaceBlock']){
  const ev={block,player:leader,cancel:false};for(const fn of world.beforeEvents[name].listeners)fn(ev);assert.equal(ev.cancel,true);
  const other={block:outside,player:leader,cancel:false};for(const fn of world.beforeEvents[name].listeners)fn(other);assert.equal(other.cancel,false);
 }
 let kept;for(const fn of world.beforeEvents.explosion.listeners)fn({getImpactedBlocks:()=>[block,outside],setImpactedBlocks:blocks=>{kept=blocks;}});assert.deepEqual(kept,[outside]);
});
test('dungeon unregister preserves generated blocks and requires administrator permission',()=>{
 assert.throws(()=>removeDungeon(outsider,'ruin'),/관리자/);const n=blocks.size;removeDungeon(leader,'ruin');assert.equal(blocks.size,n);assert.equal(listDungeons().length,0);
});
