// Economy targets all four armor pieces +10 and all five rune kinds +5.
export const HUNT_REWARDS=Object.freeze({normal:{gold:114,stone:2,dustChance:0.15},elite:{gold:360,stone:6,dust:1},boss:{gold:3600,stone:24,dust:6}});
export const DUNGEON={radius:21,height:18,maxCount:8,maxParty:4,timeoutMs:30*60*1000,baselineMinutes:10};
export const CLEAR_REWARD={gold:2000,stone:8,dust:2,catalysts:4,bonusEvery:3};
export const RUNE_CYCLE=['power','arcane','vitality','mana','ward'];
export const ARMOR_KIT=['adventurer_helmet','adventurer_chestplate','adventurer_leggings','adventurer_boots'];
export const SUPPLIES={'minecraft:iron_ingot':8,'minecraft:copper_ingot':2,'minecraft:emerald':2,'minecraft:oak_planks':2,'minecraft:amethyst_shard':2,'minecraft:lapis_lazuli':1};
export const WAVES=[
 {name:'고블린 전초실',x:-11,z:-11,types:['green_goblin','green_goblin','green_goblin','green_goblin','red_goblin','red_goblin']},
 {name:'정예 경비실',x:11,z:-11,types:['green_goblin','green_goblin','red_goblin','red_goblin','elite_green_goblin','elite_green_goblin']},
 {name:'정예 지휘실',x:-11,z:11,types:['red_goblin','red_goblin','elite_green_goblin','elite_green_goblin','elite_red_goblin','elite_red_goblin']},
 {name:'바위 골렘의 왕좌',x:11,z:11,types:['rock_golem_boss']},
];
// Pure blueprint; undefined is interior air. No fill commands overwrite terrain.
export function dungeonBlock(x,y,z){
 const {radius:r,height:h}=DUNGEON;
 if(y===0)return Math.abs(x)%10===0&&Math.abs(z)%10===0?'minecraft:sea_lantern':'minecraft:polished_deepslate';
 if(y===h)return Math.abs(x)===11&&Math.abs(z)===11?'minecraft:sea_lantern':'minecraft:stone_bricks';
 if(Math.abs(x)===r||Math.abs(z)===r)return 'minecraft:stone_bricks';
 const divider=x===0&&Math.abs(z)>3 || z===0&&Math.abs(x)>3;
 const doorway=x===0&&Math.abs(Math.abs(z)-11)<=2 || z===0&&Math.abs(Math.abs(x)-11)<=2;
 if(divider&&!(doorway&&y<=5))return 'minecraft:stone_bricks';
 return undefined;
}
