import { world,system } from '@minecraft/server';
import { ActionFormData } from '@minecraft/server-ui';
import { DUNGEON,WAVES,dungeonBlock } from '../data/dungeons.js';
import { partyMembership,partyLeaderName } from './social.js';
import { isActiveNearbyPlayer } from './xpDistribution.js';
import { healthAlive } from './util.js';
import { creditDungeonClear,claimDungeonLoot } from './dungeonRewards.js';
export const DUNGEON_KEY='rpg:dungeons_v1',RETURN_KEY='rpg:dungeon_return_v1';
let maintenanceTick=-20;
const MOB_TAG='rpg_dungeon_mob',runs=new Map(),builders=new Map();let db,registered=false;
const say=(p,s)=>{try{p.sendMessage(s);}catch{}};
const admin=p=>p?.playerPermissionLevel===2||p?.commandPermissionLevel>=1||p?.isOp?.()===true;
function state(){
 if(!db){const raw=world.getDynamicProperty(DUNGEON_KEY);db=raw===undefined?{version:1,nextRun:1,dungeons:[],outbox:[]}:JSON.parse(raw);
  if(db.version!==1||!Array.isArray(db.dungeons)||!Array.isArray(db.outbox)||!Number.isSafeInteger(db.nextRun))throw Error('던전 저장 데이터 오류');}
 return db;
}
function save(){const text=JSON.stringify(state());if(text.length>29000)throw Error('던전 저장 공간 부족');world.setDynamicProperty(DUNGEON_KEY,text);}
const find=id=>state().dungeons.find(d=>d.id===id);
const inside=(p,d)=>p.dimension.id===d.dimId&&Math.abs(p.location.x-d.x)<DUNGEON.radius&&Math.abs(p.location.z-d.z)<DUNGEON.radius&&p.location.y>d.y&&p.location.y<d.y+DUNGEON.height;
const runOf=id=>[...runs.values()].find(r=>r.members.some(m=>m.id===id));
const tagFor=d=>'rpg_dungeon_'+d.id;
function* volume(d){for(let y=0;y<=DUNGEON.height;y++)for(let x=-DUNGEON.radius;x<=DUNGEON.radius;x++)for(let z=-DUNGEON.radius;z<=DUNGEON.radius;z++)yield {x:d.x+x,y:d.y+y,z:d.z+z,block:dungeonBlock(x,y,z)};}
function dimension(d){return world.getDimension(d.dimId);}
function requireAdmin(p){if(!admin(p))throw Error('던전 생성·등록 해제는 관리자만 가능합니다.');}
export function listDungeons(){return state().dungeons.map(d=>({...d,busy:runs.has(d.id)}));}
export function createDungeon(p,id){
 requireAdmin(p);if(!/^[a-z][a-z0-9_]{0,15}$/.test(id))throw Error('이름은 영문 소문자로 시작하는 1~16자 영문·숫자·밑줄입니다. 예: /rpg:dungeoncreate ruin');
 if(p.dimension.id!=='minecraft:overworld')throw Error('던전은 오버월드에서 생성하세요.');
 const old=find(id);if(old?.status==='ready'||builders.has(id))throw Error('이미 있거나 생성 중인 던전입니다.');
 if(!old&&state().dungeons.length>=DUNGEON.maxCount)throw Error('던전은 최대 8개까지 등록할 수 있습니다.');
 const d=old??{id,dimId:p.dimension.id,x:Math.floor(p.location.x),y:Math.min(290,Math.max(64,Math.floor(p.location.y)+32)),z:Math.floor(p.location.z),status:'scanning'};
 if(!old&&state().dungeons.some(v=>Math.abs(d.x-v.x)<=DUNGEON.radius*2+2&&Math.abs(d.z-v.z)<=DUNGEON.radius*2+2&&Math.abs(d.y-v.y)<=DUNGEON.height+2))throw Error('다른 던전과 겹칩니다. 수평으로 45칸 이상 이동하세요.');
 const resume=old?.status==='building';if(!old)state().dungeons.push(d);
 save();const job={d,p,phase:'scan',iterator:volume(d),resume};builders.set(id,job);
 say(p,`§e[던전] ${id}: 빈 공간 검사 중. 중심 ${d.x} ${d.y} ${d.z}, 크기 43×19×43. 기존 블록이 있으면 생성하지 않습니다.`);
 return {id,building:true};
}
function buildTick(job){
 const {d,p}=job;
 try{
  const dim=dimension(d);
  for(let n=0;n<256;n++){
   const next=job.iterator.next();
   if(next.done){
    if(job.phase==='scan'){job.phase='build';d.status='building';save();job.iterator=volume(d);return;}
    d.status='ready';save();builders.delete(d.id);say(p,`§a[던전] ${d.id} 생성 완료! /rpg:dungeon ${d.id} 로 입장하세요.`);return;
   }
   const at=next.value,b=dim.getBlock(at);if(!b)throw Error('청크가 로드되지 않았습니다. 가까이에서 같은 이름으로 다시 생성하세요.');
   if(job.phase==='scan'){
    if(!b.isAir&&!(job.resume&&at.block===b.typeId))throw Error('기존 블록이 있어 중단했습니다. 다른 빈 공간에서 생성하세요.');
   }else if(at.block){
    if(!b.isAir&&b.typeId!==at.block)throw Error('생성 중 다른 블록을 발견했습니다. 해당 블록은 보존합니다.');
    if(b.isAir)b.setType(at.block);
   }else if(!b.isAir)throw Error('생성 중 내부 공간에 블록을 발견했습니다. 해당 블록은 보존합니다.');
  }
 }catch(error){
  builders.delete(d.id);
  if(job.phase==='scan'&&!job.resume)state().dungeons=state().dungeons.filter(v=>v!==d);
  else d.status='building';
  try{save();}catch{}say(p,'§c[던전] '+String(error.message??error));
 }
}
function cleanMobs(d){
 try{for(const e of dimension(d).getEntities({tags:[MOB_TAG,tagFor(d)]}))if(e.typeId!=='minecraft:player')e.remove();}catch{}
}
export function removeDungeon(p,id){
 requireAdmin(p);const d=find(id);if(!d)throw Error('등록된 던전이 없습니다.');if(runs.has(id)||builders.has(id))throw Error('진행·생성 중인 던전은 등록 해제할 수 없습니다.');
 cleanMobs(d);state().dungeons=state().dungeons.filter(v=>v!==d);save();say(p,'§7던전 등록을 해제했습니다. 건축물은 보존합니다.');
}
function returnPlayer(p){
 const raw=p.getDynamicProperty(RETURN_KEY);if(raw===undefined)return true;
 if(!healthAlive(p))return false;
 const back=JSON.parse(raw);p.teleport(back.location,{dimension:world.getDimension(back.dimId),keepVelocity:false});p.setDynamicProperty(RETURN_KEY,undefined);return true;
}
function finish(r,cleared){
 if(r.finishing)return;r.finishing=true;
 if(cleared){
  const recipients=r.members.map(m=>world.getAllPlayers().find(p=>p.id===m.id)).filter(p=>p&&healthAlive(p)&&inside(p,r.d)&&isActiveNearbyPlayer(p,p.location,p.dimension.id,1));
  const outbox=state().outbox.length;for(const p of recipients)state().outbox.push({playerId:p.id,runId:r.id});
  try{save();}catch(error){state().outbox.length=outbox;r.finishing=false;throw error;}
 }
 runs.delete(r.d.id);r.d.activeId=null;save();cleanMobs(r.d);
 for(const m of r.members){const p=world.getAllPlayers().find(p=>p.id===m.id);if(!p)continue;
  say(p,cleared?'§6[던전] 모든 방 클리어! 골드 2000·강화석 8·룬 가루 2 + 촉매·룬·제작 재료 지급.':'§7[던전] 탐험이 종료되어 입장 위치로 돌아갑니다.');
  try{returnPlayer(p);}catch(error){say(p,'§c귀환 대기: /rpg:dungeonleave 로 재시도하세요.');}
 }
 flushRewards();
}
function spawnWave(r){
 if(r.finishing)return;const wave=WAVES[r.stage],made=[];
 try{
  for(let i=0;i<wave.types.length;i++){
   const spawn={x:r.d.x+wave.x+(i%3-1)*2,y:r.d.y+1,z:r.d.z+wave.z+(Math.floor(i/3)-.5)*2};
   const mob=dimension(r.d).spawnEntity('rpg:'+wave.types[i],spawn);made.push(mob);mob.addTag(MOB_TAG);mob.addTag(tagFor(r.d));mob.triggerEvent('rpg:dungeon_persistent');r.live.add(mob.id);
  }
 }catch(error){for(const mob of made)try{mob.remove();}catch{}finish(r,false);throw error;}
 for(const m of r.members){const p=world.getAllPlayers().find(p=>p.id===m.id);if(p)say(p,`§e[던전 ${r.stage+1}/${WAVES.length}] ${wave.name} · 적 ${wave.types.length}마리 · 방 중심 ${r.d.x+wave.x}, ${r.d.z+wave.z}`);}
}
export function enterDungeon(p,id){
 flushRewards();if(state().outbox.some(o=>o.playerId===p.id))throw Error('이전 보상 저장을 완료한 뒤 재입장하세요.');
 const d=find(id);if(!d||d.status!=='ready')throw Error('입장 가능한 던전이 없습니다. /rpg:dungeon 으로 목록을 확인하세요.');
 if(runs.has(id))throw Error('다른 파티가 진행 중입니다.');
 const party=partyMembership(p);if(partyLeaderName(p).toLowerCase()!==p.name.toLowerCase())throw Error('파티장만 파티 입장을 시작할 수 있습니다.');
 const group=party.members;if(!group.length||group.length>DUNGEON.maxParty)throw Error('던전은 1~4명만 입장할 수 있습니다.');
 for(const member of group){
  if(runOf(member.id)||member.getDynamicProperty(RETURN_KEY)!==undefined)throw Error('파티원이 이미 던전 진행·귀환 중입니다.');
  if(!isActiveNearbyPlayer(member,p.location,p.dimension.id,32))throw Error('접속 중인 모든 파티원이 같은 차원 32칸 안에서 생존·서바이벌 상태여야 합니다.');
  if(state().outbox.some(o=>o.playerId===member.id))throw Error('파티원의 이전 보상 저장이 대기 중입니다.');
 }
 cleanMobs(d);const r={id:state().nextRun++,d,members:group.map(m=>({id:m.id})),stage:0,live:new Set(),deadline:Date.now()+DUNGEON.timeoutMs,finishing:false};d.activeId=r.id;save();runs.set(id,r);
 try{
  for(let i=0;i<group.length;i++){
   const member=group[i];member.setDynamicProperty(RETURN_KEY,JSON.stringify({runId:r.id,dimId:member.dimension.id,location:member.location}));
   member.teleport({x:d.x+(i%2)*2-.5,y:d.y+1,z:d.z+Math.floor(i/2)*2-.5},{dimension:dimension(d),keepVelocity:false});
  }
  spawnWave(r);
 }catch(error){finish(r,false);throw error;}
 return {runId:r.id,members:group.map(p=>p.id)};
}
export function leaveDungeon(p){
 const r=runOf(p.id);if(r){r.members=r.members.filter(m=>m.id!==p.id);if(!r.members.length)finish(r,false);}
 const returned=returnPlayer(p);say(p,returned?'§7던전에서 나왔습니다.':'§7부활 후 입장 위치로 귀환합니다.');return returned;
}
export function flushRewards(){
 for(const receipt of [...state().outbox]){
  const p=world.getAllPlayers().find(p=>p.id===receipt.playerId);if(!p)continue;
  try{creditDungeonClear(p,receipt.runId);state().outbox=state().outbox.filter(x=>x!==receipt);save();
   const delivered=claimDungeonLoot(p);if(delivered.pending)say(p,'§e가방 부족 보급품은 저장되었습니다. /rpg:dungeonloot 로 받으세요.');
  }catch(error){say(p,'§c던전 보상·보급품은 저장 대기 중입니다. /rpg:dungeonloot 로 재시도하세요.');}
 }
}
export function dungeonDeath(ev){
 const dead=ev.deadEntity;if(!dead)return;
 if(dead.typeId==='minecraft:player'){const p=world.getAllPlayers().find(p=>p.id===dead.id);if(p)leaveDungeon(p);return;}
 for(const r of runs.values())if(r.live.delete(dead.id)){
  if(r.live.size)return;
  if(r.stage===WAVES.length-1)finish(r,true);
  else{r.stage++;system.runTimeout(()=>{if(runs.get(r.d.id)===r)try{spawnWave(r);}catch(error){console.warn('[RPG dungeon] '+error);}},60);}
  return;
 }
}
export function dungeonTick(){
 for(const job of [...builders.values()])buildTick(job);
 if(system.currentTick-maintenanceTick<20)return;maintenanceTick=system.currentTick;
 for(const r of [...runs.values()]){
  if(Date.now()>=r.deadline){finish(r,false);continue;}
  for(const m of [...r.members]){
   const p=world.getAllPlayers().find(p=>p.id===m.id);
   if(!p){r.members=r.members.filter(x=>x!==m);continue;}
   if(!inside(p,r.d)||!healthAlive(p)||!isActiveNearbyPlayer(p,p.location,p.dimension.id,1))leaveDungeon(p);
  }
  if(!r.members.length&&!r.finishing)finish(r,false);
 }
}
export function recoverDungeons(){
 // Running fights abort after restart; earned receipts and player return points persist.
 for(const r of runs.values())cleanMobs(r.d);runs.clear();builders.clear();db=undefined;
 for(const d of state().dungeons){if(d.activeId)cleanMobs(d);d.activeId=null;}save();flushRewards();
}
export async function openDungeons(p){
 const list=listDungeons().filter(d=>d.status==='ready'),current=runOf(p.id);
 const progress=current?`진행: ${current.stage+1}/4 · 남은 적 ${current.live.size} · 제한 ${Math.max(0,Math.ceil((current.deadline-Date.now())/60000))}분\n/rpg:dungeonleave 로 퇴장\n\n`:'';
 const form=new ActionFormData().title('던전 · 폐허의 시련').body(progress+'1~4명 · 전투 3개 방 → 바위 골렘\n파티장 입장, 같은 차원 32칸 안 파티원 동행\n제한 30분. 사망·이탈 시 해당 플레이어 보상 제외.\n클리어: 촉매 4개, 매 3회차 +1개·룬 1개·제작 재료\n/rpg:dungeonloot: 보급품 받기');
 for(const d of list)form.button(d.id+(d.busy?' · 진행 중':''));form.button('닫기');const answer=await form.show(p);
 if(answer.canceled||answer.selection==null||answer.selection>=list.length)return;
 try{enterDungeon(p,list[answer.selection].id);}catch(error){say(p,'§c'+error.message);}
}
export function registerDungeons(){
 if(registered)return;registered=true;recoverDungeons();
 world.afterEvents.entityDie.subscribe(ev=>{try{dungeonDeath(ev);}catch(error){console.warn('[RPG dungeon death] '+error);}});
 world.afterEvents.playerLeave.subscribe(ev=>{const r=runOf(ev.playerId);if(r){r.members=r.members.filter(m=>m.id!==ev.playerId);if(!r.members.length)finish(r,false);}});
 world.afterEvents.playerSpawn.subscribe(ev=>system.runTimeout(()=>{try{if(!runOf(ev.player.id))returnPlayer(ev.player);flushRewards();}catch(error){say(ev.player,'§c던전 귀환·보상 대기: '+error.message);}},20));
 world.beforeEvents.explosion?.subscribe(ev=>{
  ev.setImpactedBlocks(ev.getImpactedBlocks().filter(b=>!state().dungeons.some(d=>d.dimId===b.dimension.id&&Math.abs(b.location.x-d.x)<=DUNGEON.radius&&Math.abs(b.location.z-d.z)<=DUNGEON.radius&&b.location.y>=d.y&&b.location.y<=d.y+DUNGEON.height)));
 });
 for(const name of ['playerBreakBlock','playerPlaceBlock'])world.beforeEvents[name]?.subscribe(ev=>{
  const b=ev.block,dim=b?.dimension?.id??ev.player?.dimension?.id;if(!b)return;
  if(state().dungeons.some(d=>d.dimId===dim&&Math.abs(b.location.x-d.x)<=DUNGEON.radius&&Math.abs(b.location.z-d.z)<=DUNGEON.radius&&b.location.y>=d.y&&b.location.y<=d.y+DUNGEON.height))ev.cancel=true;
 });
 system.runInterval(()=>{try{dungeonTick();}catch(error){console.warn('[RPG dungeon] '+error);}},1);
}
