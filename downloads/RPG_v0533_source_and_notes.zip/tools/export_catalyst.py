"""Export image-tool artwork as a Minecraft 128px hard-alpha pixel texture."""
from pathlib import Path
import json
from PIL import Image

root=Path(__file__).resolve().parents[1]
source=Image.open(root/'art/catalyst_generated.png').convert('RGBA')
# Technical pixel-grid export, not a second illustration: sample the generated
# sprite onto its intended 32px logical grid, then scale each pixel to 4x4.
sprite=source.resize((32,32),Image.Resampling.NEAREST)
sprite.putdata([(r,g,b,255) if a>=128 else (0,0,0,0) for r,g,b,a in sprite.get_flattened_data()])
sprite=sprite.quantize(colors=16,method=Image.Quantize.FASTOCTREE,dither=Image.Dither.NONE).convert('RGBA')
sprite=sprite.resize((128,128),Image.Resampling.NEAREST)
rp=root/'RPG_RP_v0533'
target=rp/'textures/items/rpg_equipment/enhancement_catalyst.png'
sprite.save(target)
atlas=rp/'textures/item_texture.json'
data=json.loads(atlas.read_text())
data['texture_data']['rpg_enhancement_catalyst']={'textures':'textures/items/rpg_equipment/enhancement_catalyst'}
atlas.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
item=root/'RPG_BP_v0533/items/enhancement_catalyst.json'
data=json.loads(item.read_text());data['minecraft:item']['components']['minecraft:icon']='rpg_enhancement_catalyst'
item.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print('Exported',target,'size',sprite.size,'colors',len(sprite.getcolors()))
