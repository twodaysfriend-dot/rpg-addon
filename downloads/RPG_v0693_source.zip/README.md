# RPG v0.6.93 · 마을 밖 부동산과 관리자 토지 회수

- 부동산 구매권을 손에 들고 사용하면 마을과 야생에서 현재 차원의 16×16 청크를 구매할 수 있습니다. 구매권은 경험치 상점에서 다이아몬드 5개로 구입합니다. 소유자와 같은 길드·파티에 건축 권한이 부여되며, 마을에 해당하는 구역의 바닥과 지하는 보호됩니다. 기존 소유권 기록도 그대로 읽습니다.
- 운영자 관리 도구의 **현재 청크·대상 소유지 조회**에서 현재 청크의 소유자와 선택한 플레이어의 소유 청크를 확인할 수 있습니다.
- **땅뺏기**를 크리에이티브 인벤토리에서 꺼냅니다. 관리자가 회수할 청크에 서서 아이템을 들고 우클릭한 뒤 확인하면 소유권이 해제됩니다. 건축물은 유지되고 청크는 다시 구매할 수 있습니다. 아이템은 반복 사용할 수 있습니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.93으로 활성화하세요. 모의 테스트에서 야생 구매·보호, 기존 저장 호환, 관리 메뉴 조회, 권한 검사, 회수 확인과 저장 실패 복구를 검증했습니다. 실제 Bedrock 월드에서의 동작 확인은 남아 있습니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0693
```
