import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=path.resolve('.'),rp=path.join(root,'RPG_RP_v0571');const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const pose=read(path.join(root,'held_weapon_pose.json'));
test('all 39 visible weapons have a real hand skeleton, upright sprite, and twice native model dimensions',()=>{
 const models=read(path.join(rp,'models/entity/upright_weapons.geo.json'))['minecraft:geometry'];assert.equal(models.length,39);
 for(const spec of pose.items){const model=models.find(g=>g.description.identifier==='geometry.rpg.upright.'+spec.id.slice(4));assert.ok(model);assert.equal(model.bones.some(b=>b.binding),false);
  const weapon=model.bones.find(b=>b.name==='weapon');assert.equal(weapon.parent,'rightItem');assert.deepEqual(weapon.pivot,[-6,15,1]);
  const sprite=model.bones.find(b=>b.name==='sprite');assert.equal(sprite.cubes.length,1);assert.equal(sprite.cubes[0].size[0],spec.nativeSide*2);
  const a=read(path.join(rp,'attachables',spec.id.slice(4)+'.json'))['minecraft:attachable'].description;assert.equal(a.identifier,spec.id);assert.equal(a.geometry.default,model.description.identifier);
 }
});
test('original common weapon pixels remain exact and transparent geometry has no generated edge cubes',()=>{
 for(const r of read(path.join(root,'original_weapon_texture_mapping.json'))){assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(rp,'textures/items/common_weapons',r.target))).digest('hex'),r.sha256);}
 const a=read(path.join(rp,'animations/upright_weapons.animation.json')).animations;assert.ok(a['animation.rpg.upright.first']);assert.ok(a['animation.rpg.upright.third']);
});
test('private War God rendering stays owner-first-person only while its sprite doubles',()=>{
 assert.match(JSON.stringify(read(path.join(rp,'attachables/war_god_gauntlets.json'))),/context.is_first_person/);
 assert.deepEqual(read(path.join(rp,'models/entity/war_god_private.geo.json'))['minecraft:geometry'][0].bones[0].cubes[0].size,[16,16,.2]);
});
test('first-person guide compensation makes the normalized blade point upward/right and keeps its face visible',()=>{
 const matrix=angles=>{const [x,y,z]=angles.map(a=>a*Math.PI/180),cx=Math.cos(x),sx=Math.sin(x),cy=Math.cos(y),sy=Math.sin(y),cz=Math.cos(z),sz=Math.sin(z);return [[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]];};
 const g=matrix(pose.firstPersonGuide),p=matrix(pose.localPose),world=g.map(row=>p[0].map((_,j)=>row.reduce((n,v,k)=>n+v*p[k][j],0)));
 assert.ok(world[0][1]>.2);assert.ok(world[1][1]>.8);assert.ok(Math.abs(world[2][2])>.8);
});
