import test from 'node:test';
import assert from 'node:assert/strict';
import {system,player,forms,CommandPermissionLevel,CustomCommandStatus} from './minecraftMock.mjs';
import {initializeGameplay} from '../RPG_BP_v0571/scripts/main.js';
import '../RPG_Commands_BP_v0571/scripts/commands.js';
test('independent command pack registers public rune/jobs commands and opens gameplay menus',()=>{
  initializeGameplay();const registered=new Map();
  for(const fn of system.beforeEvents.startup.listeners)fn({
    itemComponentRegistry:{registerCustomComponent(){}},
    customCommandRegistry:{registerCommand:(def,callback)=>{assert.ok(!registered.has(def.name));registered.set(def.name,{def,callback});}},
  });
  const p=player('slash'),sent=[];p.runCommand=command=>{
    sent.push(command);const id=command.split(' ')[1];
    for(const fn of system.afterEvents.scriptEventReceive.listeners)fn({id,sourceEntity:p,message:''});
  };
  for(const name of ['runes','jobs','skillguide','dungeon','ask','transfer','temple','fuse']){
    const entry=registered.get('rpg:'+name);assert.ok(entry);assert.equal(entry.def.permissionLevel,CommandPermissionLevel.Any);assert.equal(entry.def.cheatsRequired,false);
    assert.equal(entry.callback({sourceEntity:p}).status,CustomCommandStatus.Success);
  }
  assert.deepEqual(sent,['scriptevent rpg:runes','scriptevent rpg:jobs','scriptevent rpg:skillguide','scriptevent rpg:dungeon','scriptevent rpg:ask','scriptevent rpg:transfer','scriptevent rpg:temple','scriptevent rpg:fuse']);
  assert.equal(registered.get('rpg:dungeon').def.optionalParameters[0].name,'difficulty');
  assert.equal(registered.get('rpg:ask').def.optionalParameters[0].name,'question');
  assert.ok(forms.some(f=>f.heading==='RPG 정보 질문'));
  assert.ok(forms.some(f=>f.heading==='갑옷 강화 이전'));
  for(const name of ['dungeoncreate','dungeonremove','templecreate','templeremove','gptnpc','hito'])assert.equal(registered.get('rpg:'+name).def.permissionLevel,CommandPermissionLevel.GameDirectors);
  assert.ok(forms.some(f=>f.heading==='던전 · 난이도 1~10'));
  assert.ok(forms.some(f=>f.heading==='룬 전용 보관함'));assert.ok(forms.some(f=>f.heading==='전직 조건 · 시련'));
  assert.ok(forms.some(f=>f.heading==='직업 계열별 스킬 도감'));
});
