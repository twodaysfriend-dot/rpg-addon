import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,system,CommandPermissionLevel} from './minecraftMock.mjs';
import {offerItems} from '../RPG_BP_v0571/scripts/core/offer.js';
import {getProgress,maxManaOf,setMana,getMana} from '../RPG_BP_v0571/scripts/core/playerData.js';
import {runRpgAction} from '../RPG_BP_v0571/scripts/core/rpgActions.js';
import '../RPG_Commands_BP_v0571/scripts/commands.js';
const potion=(effect='healing',type='minecraft:potion')=>{const i=new ItemStack(type);i.potionEffect=effect;return i;};
test('native registry exposes one public offering command and removes sword/book commands',()=>{
 const all=new Map();for(const f of system.beforeEvents.startup.listeners)f({customCommandRegistry:{registerCommand:(def,callback)=>all.set(def.name,{def,callback})},itemComponentRegistry:{registerCustomComponent(){}}});
 assert.ok(all.has('rpg:offer'));assert.equal(all.get('rpg:offer').def.description,'검과 책을 바칩니다');assert.equal(all.get('rpg:offer').def.permissionLevel,CommandPermissionLevel.Any);assert.equal(all.has('rpg:book'),false);assert.equal(all.has('rpg:sword'),false);
});
test('one command handles both apprentice objectives and keeps surplus swords/books',()=>{
 const p=player('offer-start');for(let i=0;i<7;i++)p.slots[i]=new ItemStack('minecraft:diamond_sword');p.slots[9]=new ItemStack('minecraft:enchanted_book',14);assert.equal(offerItems(p).ok,true);assert.equal(getProgress(p).diamond_swords,5);assert.equal(getProgress(p).books,10);assert.equal(p.slots.filter(i=>i?.typeId==='minecraft:diamond_sword').length,2);assert.equal(p.slots[9].amount,4);assert.equal(p.messages.length,1);assert.match(p.messages[0],/검 5개.*책 10권/);
});
test('mage books are each consumed once: first outstanding trial books, then mana books',()=>{
 const p=player('offer-mage');p.setDynamicProperty('rpg:job','mage');p.setDynamicProperty('rpg:progress',JSON.stringify({books:10,tech_books:8}));p.slots[3]=new ItemStack('minecraft:enchanted_book',5);setMana(p,100);const beforeMax=maxManaOf(p);assert.equal(offerItems(p).ok,true);assert.equal(getProgress(p).tech_books,10);assert.equal(getProgress(p).books,13);assert.equal(getMana(p),100+maxManaOf(p)-beforeMax);assert.equal(p.slots[3],undefined);
});
test('secret resource is accepted by the same command without separate public item guidance',()=>{
 const p=player('offer-secret');p.setDynamicProperty('rpg:job','sage');p.slots[2]=potion();p.slots[3]=potion('water');p.slots[4]=potion('strength','minecraft:splash_potion');assert.equal(offerItems(p).ok,true);assert.equal(getProgress(p).tech_potions,2);assert.equal(p.slots[2],undefined);assert.equal(p.slots[3].potionEffect,'water');assert.equal(p.slots[4],undefined);assert.ok(!/물약|포션|potion/i.test(p.messages.join('')));
 const other=player('wrong-role');other.slots[2]=potion();assert.equal(offerItems(other).ok,false);assert.ok(other.slots[2]);
});
test('failed inventory or progress save restores all donation items, objective counters and mana',()=>{
 for(const failure of ['inventory','progress']){
  const p=player('rollback-'+failure);p.slots[2]=new ItemStack('minecraft:diamond_sword');p.slots[4]=new ItemStack('minecraft:enchanted_book',3);const before=p.getDynamicProperty('rpg:progress'),mana=p.getDynamicProperty('rpg:mana');let fail=true;
  if(failure==='inventory'){const inv=p.getComponent('minecraft:inventory').container,set=inv.setItem;inv.setItem=(i,item)=>{if(fail&&i===4){fail=false;throw Error('test inventory');}set(i,item);};}
  else{const set=p.setDynamicProperty.bind(p);p.setDynamicProperty=(k,v)=>{if(fail&&k==='rpg:progress'){fail=false;throw Error('test save');}set(k,v);};}
  assert.equal(offerItems(p).ok,false);assert.equal(p.slots[2].typeId,'minecraft:diamond_sword');assert.equal(p.slots[4].amount,3);assert.equal(p.getDynamicProperty('rpg:progress'),before);assert.equal(p.getDynamicProperty('rpg:mana'),mana);
 }
});
test('removed legacy script/chat action paths cannot consume items, unified action still works',()=>{
 const p=player('old-actions');p.slots[3]=new ItemStack('minecraft:enchanted_book',10);for(const old of ['book','sword','techpotions','techbooks'])runRpgAction(old,p);assert.equal(p.slots[3].amount,10);assert.deepEqual(getProgress(p),{});runRpgAction('offer',p);assert.equal(getProgress(p).books,10);assert.equal(p.slots[3],undefined);
});
