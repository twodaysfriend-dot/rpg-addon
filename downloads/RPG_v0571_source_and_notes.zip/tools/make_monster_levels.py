"""Generate bounded native level events without changing baseline entity stats."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
BP=ROOT/'RPG_BP_v0571'
LEVELS=[1,5,10,15,20,30,40,55,70,90,115,145,180,220,260]
PRESSURE=[1,1,1.05,1.1,1.2,1.35,1.55,1.85,2.3,3]
TIER_INDEX=[2,4,5,6,7,8,9,10,11,12]
def main():
 ids=[]
 for p in sorted((BP/'entities').glob('*.json')):
  data=json.loads(p.read_text());e=data['minecraft:entity'];c=e.get('components',{})
  if not e['description'].get('is_spawnable') or 'monster' not in c.get('minecraft:type_family',{}).get('family',[]) or 'minecraft:health' not in c:continue
  ids.append(e['description']['identifier']);groups=e.setdefault('component_groups',{});events=e.setdefault('events',{})
  for level in LEVELS:
   group={'minecraft:health':{'value':round(c['minecraft:health']['max']*(1+(level-1)*.035),2),'max':round(c['minecraft:health']['max']*(1+(level-1)*.035),2)}}
   group['minecraft:damage_sensor']={'triggers':[{'cause':'all','damage_multiplier':round(1/(1+(level-1)*.004),6)}]}
   attack=c.get('minecraft:attack',{}).get('damage')
   if isinstance(attack,(int,float)):group['minecraft:attack']={**c['minecraft:attack'],'damage':round(attack*(1+(level-1)*.018),2)}
   name='rpg:level_'+str(level);groups[name]=group;events[name]={'remove':{'component_groups':['rpg:level_'+str(n) for n in LEVELS]},'add':{'component_groups':[name]}}
  for tier in range(1,11):
   for kind in ['normal','elite','boss']:
    for variant in range(3 if kind=='normal' else 1):
     delta=[-1,0,1][variant] if kind=='normal' else 1 if kind=='elite' else 2
     level=LEVELS[min(len(LEVELS)-1,max(0,TIER_INDEX[tier-1]+delta))]
     group=json.loads(json.dumps(groups['rpg:level_'+str(level)]))
     for k in ['value','max']:group['minecraft:health'][k]=round(group['minecraft:health'][k]*PRESSURE[tier-1],2)
     name=f'rpg:dungeon_scaled_{tier}_{kind}_{variant}';groups[name]=group;events[name]={'add':{'component_groups':[name]}}
  p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 lang={}
 for line in (ROOT/'RPG_RP_v0571/texts/ko_KR.lang').read_text().splitlines():
  if '=' in line:
   k,v=line.split('=',1);lang[k]=v
 names={id:lang.get('entity.'+id+'.name',{'rpg:hydra_boss':'히드라','rpg:tech_block_golem_boss':'마공학 골렘','rpg:rock_golem_boss':'바위 골렘','rpg:cyclops_boss':'외눈 거인'}.get(id,id[4:].replace('_',' '))) for id in ids}
 (BP/'scripts/data/leveledMonsters.js').write_text('export const LEVELED_MONSTERS=Object.freeze('+json.dumps(ids,ensure_ascii=False,indent=2)+');\nexport const MONSTER_NAMES=Object.freeze('+json.dumps(names,ensure_ascii=False,indent=2)+');\n')
 print('Generated 15 native level bands for',len(ids),'RPG monster types.')
if __name__=='__main__':main()
