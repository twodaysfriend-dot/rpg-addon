import { canUseSkill,isChameleonWeapon } from "../core/skillAccess.js";
import { skillDamageFor } from "../core/stats.js";
import { areAllies } from "../core/social.js";
import { world, system, EntityDamageCause } from "@minecraft/server";
import { getJobId, getSkills } from "../core/playerData.js";
import { getLastHit } from "../core/tracking.js";
import { CONFIG } from "../config.js";
import {
  getTargets, healthAlive, flatDir, firstTargetInView,
  isSolidAt, knockback, particle, sound, dist3, heldItemId,
} from "../core/util.js";

const killPassiveTicks = 100;  // 5 seconds
const empowered = new Map(); // playerId -> { expires? no: next basic hit consumes it }
const wallMarks = new Map(); // targetId -> { entity, untilTick } doubled incoming damage
const wallStuns = new Map(); // targetId -> { entity, point, dimension, untilTick }
const affectedKinds = new Set(["mangnani", "beast"]);
const ignoredTypes = new Set(["minecraft:item", "minecraft:xp_orb", "minecraft:armor_stand", "rpg:bone_minion"]);

function isBerserker(player) {
  try { return player?.typeId === "minecraft:player" && (affectedKinds.has(getJobId(player)) || (getJobId(player)==="chameleon" && getSkills(player).includes("beast_berserk"))); }
  catch { return false; }
}
function validVictim(player, entity) {
  try {
    return !!entity && entity.id !== player.id && healthAlive(entity)
      && !ignoredTypes.has(entity.typeId)
      && !areAllies(player, entity)
      && (CONFIG.pvp || entity.typeId !== "minecraft:player");
  } catch { return false; }
}
function effect(entity, type, ticks, amplifier) {
  try { entity.addEffect(type, ticks, { amplifier, showParticles: true }); } catch {}
}
function feetOpen(dim, loc) {
  return !isSolidAt(dim, {x:loc.x, y:loc.y+0.1, z:loc.z})
    && !isSolidAt(dim, {x:loc.x, y:loc.y+1.3, z:loc.z});
}
function skillHurt(target, source, amount) {
  if (!validVictim(source, target) || amount <= 0) return false;
  // Skill damage is magic, not melee. This prevents consuming the next basic-attack buff.
  try { return !!target.applyDamage(skillDamageFor(source,amount,"physical"), {cause:EntityDamageCause.magic, damagingEntity:source}); }
  catch { return false; }
}
function chooseTarget(player, maxRange) {
  const a = firstTargetInView(player, maxRange);
  if (validVictim(player,a)) return a;
  // When the view picker finds nothing, lock onto the last hit target only if in front.
  const b = getLastHit(player);
  if (!validVictim(player,b)) return null;
  try {
    if (b.dimension.id !== player.dimension.id || dist3(player.location,b.location) > maxRange) return null;
    const dir = flatDir(player), d={x:b.location.x-player.location.x,z:b.location.z-player.location.z};
    const len=Math.hypot(d.x,d.z);
    return len>0.1 && (dir.x*d.x+dir.z*d.z)/len > 0.45 ? b : null;
  }catch{return null;}
}
function nearWall(dim, targetPos, direction, length) {
  // Target is pressed toward the obstacle in dash direction.
  for(let a=0.5; a<=length; a+=0.5){
    const pos={x:targetPos.x+direction.x*a, y:targetPos.y, z:targetPos.z+direction.z*a};
    if(!feetOpen(dim,pos))return true;
  }
  return false;
}
function charge(player, job, def) {
  const enemy=chooseTarget(player, def.range);
  if (!enemy) { try{player.onScreenDisplay.setActionBar("§7돌진: 전방에 대상이 없습니다.");}catch{} return false; }
  const start={...player.location};
  const pos={...enemy.location};
  const dx=pos.x-start.x, dz=pos.z-start.z;
  const len=Math.hypot(dx,dz);
  const dir=len>0.1 ? {x:dx/len,z:dz/len} : flatDir(player);
  const dim=player.dimension;
  // Rush toward the selected entity immediately. It receives target-locked damage,
  // even if knockback or natural sidestepping would otherwise miss the strike.
  const maxAdvance=Math.max(0,len-1.6);
  const end={x:start.x+dir.x*maxAdvance,y:start.y,z:start.z+dir.z*maxAdvance};
  if(maxAdvance>0.25){
    try{player.teleport(end,{dimension:dim,keepVelocity:false});}catch{}
  }
  const collision=nearWall(dim,enemy.location,dir,def.wallHitDistance);
  const amount=def.damage*(collision?def.wallDamageMultiplier:1);
  skillHurt(enemy,player,amount);
  if(collision){
    wallMarks.set(enemy.id,{entity:enemy,untilTick:system.currentTick+def.wallStunTicks});
    wallStuns.set(enemy.id,{entity:enemy,point:{...enemy.location},dimension:dim,untilTick:system.currentTick+def.wallStunTicks});
    effect(enemy,"slowness",def.wallStunTicks,255);
    effect(enemy,"weakness",def.wallStunTicks,255);
    particle(dim,"minecraft:critical_hit_emitter",{x:enemy.location.x,y:enemy.location.y+1,z:enemy.location.z});
    sound(dim,"random.anvil_land",enemy.location,{volume:1,pitch:0.5});
  }else{
    knockback(enemy,dir.x,dir.z,1.2,0.12);
    sound(dim,"mob.irongolem.hit",enemy.location,{volume:0.8,pitch:0.7});
  }
  particle(dim,"minecraft:large_explosion",{x:enemy.location.x,y:enemy.location.y+1,z:enemy.location.z});
  return true;
}
function slam(player, job, def){
  const dim=player.dimension, p=player.location;
  const targets=getTargets(player,p,def.radius).filter(e=>validVictim(player,e)).slice(0,32);
  // Ten upward 1-block steps, stopping at a ceiling instead of placing victims in solid blocks.
  for (const victim of targets){
    let moved=0;
    const handle=system.runInterval(()=>{
      try{
        if(!healthAlive(victim) || victim.dimension.id!==dim.id || moved>=def.riseBlocks){system.clearRun(handle);return;}
        const q=victim.location, next={x:q.x,y:q.y+1,z:q.z};
        if(!feetOpen(dim,next)){system.clearRun(handle);return;}
        victim.teleport(next,{dimension:dim});
        moved++;
      }catch{system.clearRun(handle);}
    },1);
    particle(dim,"minecraft:critical_hit_emitter",{x:victim.location.x,y:victim.location.y+1,z:victim.location.z});
  }
  particle(dim,"minecraft:large_explosion",{x:p.x,y:p.y+0.2,z:p.z});
  sound(dim,"random.anvil_land",p,{volume:1,pitch:0.65});
  return true;
}
function execute(player, job, def) {
  empowered.set(player.id,{multiplier:def.nextMeleeMultiplier});
  try{player.onScreenDisplay.setActionBar("§c[참수] 다음 기본 근접 공격의 피해량 ×4");}catch{}
  sound(player.dimension,"random.orb",player.location,{volume:0.8,pitch:0.5});
  return true;
}
function berserk(player,job,def){
  effect(player,"hunger",def.duration,def.hungerAmp); // hunger III
  effect(player,"strength",def.duration,def.strengthAmp); // strength IV
  effect(player,"resistance",def.duration,def.resistanceAmp); // resistance II
  effect(player,"speed",def.duration,def.speedAmp); // speed II
  // 야수에게만 광분화 중 피해흡수 IV, 망나니에게는 기존 강화만 부여.
  if(getJobId(player)==="beast") effect(player,"absorption",def.duration,def.beastAbsorptionAmp??3);
  sound(player.dimension,"mob.ravager.roar",player.location,{volume:0.85,pitch:0.55});
  particle(player.dimension,"minecraft:large_explosion",{x:player.location.x,y:player.location.y+1,z:player.location.z});
  return true;
}

// 망나니·야수 공용: 짧게 전진하며 세 번 벤다. 같은 적도 각 타격마다 맞을 수 있다.
function tripleSlash(player,job,def){
  if(!canUseSkill(player,"berserker_triple_slash",["mangnani","beast"]))return false;
  const dim=player.dimension, dimId=dim.id;
  const dir=flatDir(player), side={x:-dir.z,z:dir.x};
  const step=Math.max(0,def.stepDistance??1.1);
  const slashes=def.slashes??3;
  let hitNumber=0;
  sound(dim,"random.swish",player.location,{volume:.85,pitch:.8});
  const timer=system.runInterval(()=>{
    try{
      if(!player.isValid||player.dimension.id!==dimId||!canUseSkill(player,"berserker_triple_slash",["mangnani","beast"])){system.clearRun(timer);return;}
      // 조금씩 전진하되 앞에 벽이나 위험한 공중 지형이 있으면 이동하지 않는다.
      const start=player.location;
      let distance=0;
      for(let d=.2;d<=step+.001;d+=.2){
        const next={x:start.x+dir.x*d,y:start.y,z:start.z+dir.z*d};
        const below=dim.getBlock({x:next.x,y:next.y-0.65,z:next.z});
        if(!feetOpen(dim,next)||!below?.isSolid)break;
        distance=d;
      }
      if(distance>.05){
        try{player.teleport({x:start.x+dir.x*distance,y:start.y,z:start.z+dir.z*distance},{dimension:dim,keepVelocity:false});}catch{}
      }
      const at=player.location;
      const reach=def.range??3.5, width=def.halfWidth??2.2;
      // 전방 부채꼴 타격으로 회전베기 효과를 구현한다.
      for(const e of getTargets(player,{x:at.x+dir.x*reach/2,y:at.y+.9,z:at.z+dir.z*reach/2},reach+width,.9)){
        if(!validVictim(player,e))continue;
        const p=e.location, dx=p.x-at.x,dz=p.z-at.z;
        const forward=dx*dir.x+dz*dir.z, sideways=Math.abs(dx*side.x+dz*side.z);
        if(forward<-.5||forward>reach||sideways>width||Math.abs(p.y-at.y)>2.4)continue;
        skillHurt(e,player,def.damagePerHit);
        particle(dim,"minecraft:critical_hit_emitter",{x:p.x,y:p.y+1,z:p.z});
      }
      // 수평 방향 아크 이펙트
      const q=player.location;
      for(let i=0;i<9;i++){
        const a=-1.15+(2.3*i/8), r=2.15;
        const x=q.x+dir.x*Math.cos(a)*r+side.x*Math.sin(a)*r;
        const z=q.z+dir.z*Math.cos(a)*r+side.z*Math.sin(a)*r;
        particle(dim,"minecraft:basic_flame_particle",{x,y:q.y+1.05+Math.sin(i/8*Math.PI)*.6,z});
      }
      sound(dim,"random.swish",q,{volume:.95,pitch:1.1+hitNumber*.13});
      hitNumber++;
      if(hitNumber>=slashes)system.clearRun(timer);
    }catch{system.clearRun(timer);}
  },Math.max(1,def.slashInterval??10));
  return true;
}

// 야수 전용 화염방사: 전방으로 화염 구체 세 발을 순차 발사한다.
function flameBurst(player,job,def){
  if(!canUseSkill(player,"beast_flame_burst",["beast"]))return false;
  const dim=player.dimension, dimId=dim.id;
  const vec=player.getViewDirection();
  const length=Math.hypot(vec.x,vec.y,vec.z)||1;
  const dir={x:vec.x/length,y:vec.y/length,z:vec.z/length};
  const shots=Math.max(1,def.shots??3);
  for(let shot=0;shot<shots;shot++){
    system.runTimeout(()=>{
      try{
        if(!player.isValid||player.dimension.id!==dimId||!canUseSkill(player,"beast_flame_burst",["beast"]))return;
        const eye=player.getHeadLocation();
        const origin={x:eye.x+dir.x*.8,y:eye.y+dir.y*.8,z:eye.z+dir.z*.8};
        let travel=0;
        particle(dim,"rpg:beast_fire_ember",origin);
        const projectile=system.runInterval(()=>{
          try{
            if(!player.isValid||player.dimension.id!==dimId){system.clearRun(projectile);return;}
            let lastAt;
            for(let sub=0;sub<3;sub++){
              travel+=(def.speed??1.6)/3;
              if(travel>def.range){system.clearRun(projectile);return;}
              const at={x:origin.x+dir.x*travel,y:origin.y+dir.y*travel,z:origin.z+dir.z*travel};
              lastAt=at;
              if(isSolidAt(dim,at)){
                particle(dim,"rpg:beast_giant_fireball",at);
                particle(dim,"minecraft:large_explosion",at);
                system.clearRun(projectile);return;
              }
              if(sub===0)particle(dim,"rpg:beast_fire_ember",{x:at.x-dir.x*0.4,y:at.y-dir.y*0.4,z:at.z-dir.z*0.4});
              const hits=getTargets(player,at,def.hitRadius??1.3,.9).filter(e=>validVictim(player,e));
              if(hits.length){
                const target=hits[0];
                skillHurt(target,player,def.damagePerShot);
                try{target.setOnFire(def.burnSeconds??3,true);}catch{}
                particle(dim,"rpg:beast_giant_fireball",at);
                particle(dim,"minecraft:large_explosion",{x:target.location.x,y:target.location.y+1,z:target.location.z});
                sound(dim,"mob.blaze.hit",target.location,{volume:.65,pitch:.9});
                system.clearRun(projectile);return;
              }
            }
            if(lastAt){
              particle(dim,"rpg:beast_giant_fireball",lastAt);
              particle(dim,"rpg:beast_fire_ember",{x:lastAt.x-dir.x*0.65,y:lastAt.y-dir.y*0.65,z:lastAt.z-dir.z*0.65});
            }
          }catch{system.clearRun(projectile);}
        },1);
        sound(dim,"mob.ghast.fireball",origin,{volume:.55,pitch:1.25+shot*.15});
      }catch{}
    },shot*Math.max(1,def.shotInterval??7));
  }
  return true;
}

// 야수 궁극기. 1초 예고 후 중심으로부터 반경 15블록에 70의 기본 피해를 부여한다.
// 지형을 파괴하지 않도록 실제 Minecraft 폭발을 생성하지 않고 폭발 파티클/타격을 사용.
function grandExplosion(player,job,def){
  if(!canUseSkill(player,"beast_grand_explosion",["beast"]))return false;
  const dim=player.dimension, dimId=dim.id;
  const spot={...player.location};
  const radius=def.radius??15;
  sound(dim,"mob.wither.spawn",spot,{volume:.75,pitch:.75});
  for(let ring=0;ring<2;ring++){
    system.runTimeout(()=>{
      for(let i=0;i<20;i++){
        const a=i*Math.PI/10;
        try{particle(dim,"minecraft:basic_flame_particle",{x:spot.x+Math.cos(a)*(ring?radius*.8:radius*.4),y:spot.y+.35,z:spot.z+Math.sin(a)*(ring?radius*.8:radius*.4)});}catch{}
      }
    },ring*10);
  }
  try{player.onScreenDisplay.setActionBar("§c[대폭발] 1초 뒤 반경 15블록 폭발!");}catch{}
  system.runTimeout(()=>{
    try{
      if(!player.isValid||player.dimension.id!==dimId||!canUseSkill(player,"beast_grand_explosion",["beast"]))return;
      const victims=getTargets(player,{x:spot.x,y:spot.y+1,z:spot.z},radius+1,1);
      for(const target of victims){
        if(!validVictim(player,target))continue;
        const at=target.location;
        if(dist3(spot,at)>radius)continue;
        skillHurt(target,player,def.damage);
        knockback(target,at.x-spot.x,at.z-spot.z,1.2,.3);
      }
      // 화염 고리 + 폭발 연출: 블록 파괴는 없음.
      for(const r of [0,4,8,12,15]){
        const n=r===0?1:Math.ceil(r*1.8);
        for(let i=0;i<n;i++){
          const a=(Math.PI*2*i)/n;
          particle(dim,"minecraft:large_explosion",{x:spot.x+Math.cos(a)*r,y:spot.y+.35,z:spot.z+Math.sin(a)*r});
        }
      }
      sound(dim,"random.explode",spot,{volume:1,pitch:.65});
    }catch{}
  },def.delay??20);
  return true;
}

export function registerBerserker(){
  world.afterEvents.entityDie.subscribe(ev=>{
    try{
      const killer=ev.damageSource?.damagingEntity;
      if(!isBerserker(killer)||!ev.deadEntity||ev.deadEntity.id===killer.id)return;
      if(ignoredTypes.has(ev.deadEntity.typeId))return;
      if(!CONFIG.pvp&&ev.deadEntity.typeId==="minecraft:player")return;
      effect(killer,"speed",killPassiveTicks,2); // speed III
      effect(killer,"regeneration",killPassiveTicks,2); // regeneration III
    }catch{}
  });
  // WorldBeforeEvents.entityHurt is present on modern Bedrock; it allows the
  // damage to be multiplied on the original hit (no extra invulnerability hit).
  let hasBefore=false;
  try{
    if(world.beforeEvents.entityHurt?.subscribe){
      world.beforeEvents.entityHurt.subscribe(ev=>{
        try{
          const now=system.currentTick, src=ev.damageSource?.damagingEntity;
          const marked=wallMarks.get(ev.hurtEntity.id);
          if(marked && now < marked.untilTick) ev.damage*=2;
          if(!canUseSkill(src,"berserker_execute",["mangnani","beast"]) || ev.damageSource?.cause !== EntityDamageCause.entityAttack)return;
          const job=getJobId(src), weapon=job==="beast"?"rpg:beast_axe":"rpg:mangnani_axe";
          if((getJobId(src)==="chameleon" ? !isChameleonWeapon(heldItemId(src)) : heldItemId(src)!==weapon) || !validVictim(src,ev.hurtEntity))return;
          const exec=empowered.get(src.id);
          if(!exec)return;
          ev.damage*=exec.multiplier;
          empowered.delete(src.id);
        }catch{}
      });
      hasBefore=true;
    }
  }catch{}
  // Fallback for older server APIs without the before-hurt damage adjustment.
  // Raw health adjustment is only used when the modern pre-hurt event is absent.
  if(!hasBefore){
    world.afterEvents.entityHurt.subscribe(ev=>{
      try{
        const src=ev.damageSource?.damagingEntity, victim=ev.hurtEntity;
        const marked=wallMarks.get(victim.id);
        let factor=marked&&system.currentTick<marked.untilTick?2:1;
        if(canUseSkill(src,"berserker_execute",["mangnani","beast"])&&ev.damageSource.cause===EntityDamageCause.entityAttack){
          const weapon=getJobId(src)==="beast"?"rpg:beast_axe":"rpg:mangnani_axe";
          if((getJobId(src)==="chameleon" ? isChameleonWeapon(heldItemId(src)) : heldItemId(src)===weapon) && validVictim(src,victim)){
            const exec=empowered.get(src.id);
            if(exec){factor*=exec.multiplier;empowered.delete(src.id);}
          }
        }
        if(factor>1){
          const h=victim.getComponent("minecraft:health");
          if(h&&h.currentValue>0)h.setCurrentValue(Math.max(0,h.currentValue-(factor-1)*ev.damage));
        }
      }catch{}
    });
  }
  // Lock a stunned entity at the original impact position for 2 seconds.
  system.runInterval(()=>{
    const now=system.currentTick;
    for(const [id, state] of wallStuns){
      if(now>=state.untilTick){wallStuns.delete(id);wallMarks.delete(id);continue;}
      try{
        if(!healthAlive(state.entity)||state.entity.dimension.id!==state.dimension.id){wallStuns.delete(id);wallMarks.delete(id);continue;}
        state.entity.teleport(state.point,{dimension:state.dimension});
      }catch{wallStuns.delete(id);wallMarks.delete(id);}
    }
    for(const [id,state] of wallMarks)if(now>=state.untilTick)wallMarks.delete(id);
    for(const p of world.getAllPlayers())if(!canUseSkill(p,"berserker_execute",["mangnani","beast"]))empowered.delete(p.id);
  },2);
  world.afterEvents.playerLeave.subscribe(ev=>empowered.delete(ev.playerId));
}
export const RUNNERS={
  berserker_charge:charge,
  berserker_slam:slam,
  berserker_execute:execute,
  beast_berserk:berserk,
  berserker_triple_slash:tripleSlash,
  beast_flame_burst:flameBurst,
  beast_grand_explosion:grandExplosion,
};
