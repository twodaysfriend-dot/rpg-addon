import { hasBorrowedSkill,isChameleonWeapon } from "../core/skillAccess.js";
// 작골염양: 고속 불꽃 회전베기. 시전 중 점프 입력 시 전방 돌진 회전베기로 전환.
// 점프 감지는 playerButtonInput 이벤트 + inputInfo 폴링 폴백을 함께 사용한다.
import * as mc from "@minecraft/server";
import { SKILLS } from "../data/skills.js";
import { getJobId } from "../core/playerData.js";
import { getTargets, hurt, knockback, particle, sound, flatDir, isSolidAt, heldItemId } from "../core/util.js";
import { notify } from "../core/hud.js";

const { world, system } = mc;
const SKILL_ID = "sword_flame_spin";
const swordJobs = new Set(["swordsman", "sword_saint", "fallen_sword_saint"]);
const states = new Map();
let registered = false;

function jumpDown(p) {
  try {
    const button = mc.InputButton?.Jump ?? "Jump";
    const pressed = mc.ButtonState?.Pressed ?? "Pressed";
    return p.inputInfo?.getButtonState(button) === pressed;
  } catch { return false; }
}

function canCast(p, state) {
  try {
    const job = getJobId(p);
    const weapon = job === "swordsman" ? "rpg:swordsman_sword"
      : job === "sword_saint" ? "rpg:sword_saint_sword"
      : job === "fallen_sword_saint" ? "rpg:fallen_sword_saint_sword" : null;
    return !!p.isValid && p.dimension.id === state.dim.id &&
      (swordJobs.has(job) && heldItemId(p) === weapon || hasBorrowedSkill(p,SKILL_ID) && isChameleonWeapon(heldItemId(p)));
  } catch { return false; }
}

function safeDashPoint(dim, at) {
  if (at.y < 1) return false;
  try {
    for (const y of [0.1, 1.45]) {
      const pos = { x:at.x, y:at.y+y, z:at.z };
      const block = dim.getBlock(pos);
      const type = block?.typeId;
      if (type === "minecraft:lava" || type === "minecraft:flowing_lava") return false;
      if (isSolidAt(dim, pos)) return false;
    }
    return true;
  } catch { return false; }
}

function slashAt(player, state, origin) {
  const { dim, def } = state;
  const radius = def.radius;
  for (const target of getTargets(player, {
    x:origin.x, y:origin.y+0.95, z:origin.z,
  }, radius, 0.95)) {
    try {
      if (state.hitIds.has(target.id)) continue;
      if (Math.hypot(target.location.x-origin.x, target.location.z-origin.z) > radius + 0.45) continue;
      const ok = hurt(target, player, def.damage, "physical");
      if (!ok) continue;
      state.hitIds.add(target.id); // 한 번의 사용 중 같은 적에게 중복 피해 방지
      try { target.setOnFire(def.burnSeconds, true); } catch {}
      knockback(target, target.location.x-origin.x, target.location.z-origin.z,
        state.dashing ? 0.65 : 0.4, 0.12);
      particle(dim, "rpg:fire_ember", {
        x:target.location.x, y:target.location.y+1.1, z:target.location.z,
      });
      sound(dim, "random.explode", target.location, { volume:0.35, pitch:1.6 });
    } catch {}
  }
}

function spinFx(state, origin) {
  const { dim, tick, def } = state;
  const angleBase = tick * 1.15;
  const radius = Math.min(def.radius, 2.5);
  for (let k = 0; k < 8; k++) {
    const a = angleBase + k * Math.PI / 4;
    const r = radius * (k % 2 === 0 ? 1 : 0.78);
    const at = {
      x: origin.x + Math.cos(a)*r,
      y: origin.y + 0.9 + (k%3)*0.23,
      z: origin.z + Math.sin(a)*r,
    };
    particle(dim, k%3===0 ? "rpg:fire_ring" : "rpg:fire_ember", at);
  }
}

function finish(p, state, reason) {
  states.delete(p.id);
  try { system.clearRun(state.runner); } catch {}
  if (reason === "blocked") notify(p, "§6작골염양: §f돌진 경로가 막혀 제자리에서 종료되었습니다.");
}

function swordFlameSpin(p, job, def) {
  if (!swordJobs.has(getJobId(p)) && !hasBorrowedSkill(p,SKILL_ID)) return false;
  const existing = states.get(p.id);
  if (existing) return false;
  const state = {
    dim:p.dimension,
    def,
    hitIds:new Set(),
    tick:0,
    dashRequested:false,
    dashing:false,
    dashDistance:0,
    dashDir:null,
    previousJump:jumpDown(p),
    runner:undefined,
  };
  states.set(p.id, state);
  notify(p, "§6작골염양! §f불꽃 회전베기 · 진행 중 점프하면 돌진 회전베기");
  sound(p.dimension, "item.trident.riptide_1", p.location, { volume:0.8, pitch:1.45 });
  // 한 틱마다 회전베기를 수행하고, 점프 입력이 들어오면 전방으로 이동.
  state.runner = system.runInterval(() => {
    try {
      if (states.get(p.id) !== state || !canCast(p,state)) {
        finish(p,state);
        return;
      }
      state.tick++;
      const down = jumpDown(p);
      if (down && !state.previousJump && state.tick > 1) state.dashRequested = true;
      state.previousJump = down;

      if (state.dashRequested && !state.dashing) {
        state.dashing = true;
        state.dashDir = flatDir(p);
        state.dashDistance = 0;
        notify(p, "§c작골염양: §f돌진 회전베기!");
        sound(state.dim, "item.trident.riptide_2", p.location, { volume:0.7, pitch:1.15 });
      }

      if (state.dashing && state.dashDistance < state.def.dashRange) {
        const dir = state.dashDir;
        const step = Math.min(state.def.dashSpeed, state.def.dashRange-state.dashDistance);
        const current = p.location;
        let moved = 0;
        // 0.25블록 간격으로 경로 검사해 벽 관통을 방지.
        for (let d=0.25; d<=step+0.0001; d+=0.25) {
          const at = { x:current.x+dir.x*d, y:current.y, z:current.z+dir.z*d };
          if (!safeDashPoint(state.dim,at)) {
            if (moved > 0) p.teleport({x:current.x+dir.x*moved,y:current.y,z:current.z+dir.z*moved}, {dimension:state.dim,keepVelocity:false});
            slashAt(p,state,p.location);
            finish(p,state,"blocked");
            return;
          }
          moved=d;
        }
        if (moved < step-0.001) {
          const at = { x:current.x+dir.x*step, y:current.y, z:current.z+dir.z*step };
          if (safeDashPoint(state.dim,at)) moved=step;
        }
        if (moved>0) {
          p.teleport({ x:current.x+dir.x*moved, y:current.y, z:current.z+dir.z*moved }, {dimension:state.dim,keepVelocity:false});
          state.dashDistance += moved;
        }
      }

      const pos = p.location;
      slashAt(p, state, pos);
      spinFx(state, pos);
      if (state.tick >= state.def.duration ||
          (state.dashing && state.dashDistance >= state.def.dashRange - 0.001)) {
        finish(p,state);
      }
    } catch {
      finish(p,state);
    }
  }, 1);
  return true;
}

export const RUNNERS = { [SKILL_ID]: swordFlameSpin };

export function registerSwordFlameSpin() {
  if (registered) return;
  registered = true;
  // 순간적인 점프 눌림도 놓치지 않도록 이벤트를 우선 사용.
  try {
    world.afterEvents.playerButtonInput?.subscribe(ev => {
      try {
        if (ev.button !== (mc.InputButton?.Jump ?? "Jump") ||
            ev.newButtonState !== (mc.ButtonState?.Pressed ?? "Pressed")) return;
        const state = states.get(ev.player.id);
        if (state && state.tick > 0 && !state.dashing) state.dashRequested = true;
      } catch {}
    }, { buttons:[mc.InputButton?.Jump ?? "Jump"] });
  } catch {}
  world.afterEvents.playerLeave.subscribe(ev => {
    const state = states.get(ev.playerId);
    if (state) {
      states.delete(ev.playerId);
      try { system.clearRun(state.runner); } catch {}
    }
  });
}
