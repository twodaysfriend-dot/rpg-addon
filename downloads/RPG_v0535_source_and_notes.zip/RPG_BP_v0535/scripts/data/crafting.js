// Generated from recipes by tools/make_crafting_catalog.py.
export const CRAFTING_RECIPES = [
  {
    "id": "rpg:adventurer_boots",
    "category": "armor",
    "name": "모험가 장화",
    "text": "작업대 제작 → 모험가 장화 ×1\n\n재료:\n철 주괴 ×4\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 □ 철\n철 구 철\n□ □ □"
  },
  {
    "id": "rpg:adventurer_chestplate",
    "category": "armor",
    "name": "모험가 흉갑",
    "text": "작업대 제작 → 모험가 흉갑 ×1\n\n재료:\n철 주괴 ×7\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 □ 철\n철 구 철\n철 철 철"
  },
  {
    "id": "rpg:adventurer_helmet",
    "category": "armor",
    "name": "모험가 투구",
    "text": "작업대 제작 → 모험가 투구 ×1\n\n재료:\n철 주괴 ×4\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 구 철\n철 □ 철\n□ □ □"
  },
  {
    "id": "rpg:adventurer_leggings",
    "category": "armor",
    "name": "모험가 각반",
    "text": "작업대 제작 → 모험가 각반 ×1\n\n재료:\n철 주괴 ×6\n구리 주괴 ×1\n\n배치도 (철=철 주괴, 구=구리 주괴, □=빈 칸):\n철 구 철\n철 □ 철\n철 □ 철"
  },
  {
    "id": "rpg:astral_boots",
    "category": "armor",
    "name": "별빛 술사 장화",
    "text": "작업대 제작 → 별빛 술사 장화 ×1\n\n재료:\n모험가 장화 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n기존 갑옷을 재료로 쓰는 세트 업그레이드는 강화·인챈트를 승계하지 않습니다. 전용 보관함 룬은 유지됩니다."
  },
  {
    "id": "rpg:astral_chestplate",
    "category": "armor",
    "name": "별빛 술사 흉갑",
    "text": "작업대 제작 → 별빛 술사 흉갑 ×1\n\n재료:\n모험가 흉갑 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n기존 갑옷을 재료로 쓰는 세트 업그레이드는 강화·인챈트를 승계하지 않습니다. 전용 보관함 룬은 유지됩니다."
  },
  {
    "id": "rpg:astral_helmet",
    "category": "armor",
    "name": "별빛 술사 투구",
    "text": "작업대 제작 → 별빛 술사 투구 ×1\n\n재료:\n모험가 투구 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n기존 갑옷을 재료로 쓰는 세트 업그레이드는 강화·인챈트를 승계하지 않습니다. 전용 보관함 룬은 유지됩니다."
  },
  {
    "id": "rpg:astral_leggings",
    "category": "armor",
    "name": "별빛 술사 각반",
    "text": "작업대 제작 → 별빛 술사 각반 ×1\n\n재료:\n모험가 각반 ×1\n자수정 조각 ×2\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n기존 갑옷을 재료로 쓰는 세트 업그레이드는 강화·인챈트를 승계하지 않습니다. 전용 보관함 룬은 유지됩니다."
  },
  {
    "id": "rpg:enhancement_catalyst",
    "category": "catalyst",
    "name": "강화 촉매",
    "text": "작업대 제작 → 강화 촉매 ×1\n\n재료:\n네더의 별 ×1\n자수정 조각 ×4\n다이아몬드 ×2\n엔더 진주 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_arcane",
    "category": "rune",
    "name": "비전의 룬",
    "text": "작업대 제작 → 비전의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n엔더 진주 ×1\n청금석 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_mana",
    "category": "rune",
    "name": "샘의 룬",
    "text": "작업대 제작 → 샘의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n청금석 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_power",
    "category": "rune",
    "name": "힘의 룬",
    "text": "작업대 제작 → 힘의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×2\n철 주괴 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_vitality",
    "category": "rune",
    "name": "생명의 룬",
    "text": "작업대 제작 → 생명의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n황금사과 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:rune_ward",
    "category": "rune",
    "name": "수호의 룬",
    "text": "작업대 제작 → 수호의 룬 ×1\n\n재료:\n자수정 조각 ×3\n레드스톤 ×1\n철 주괴 ×2\n\n작업대에 배치 순서와 관계없이 넣으세요."
  },
  {
    "id": "rpg:sandbag_spawner",
    "category": "training",
    "name": "훈련용 샌드백 소환",
    "text": "작업대 제작 → 훈련용 샌드백 소환 ×1\n\n재료:\n건초 더미 ×9\n\n배치도 (건=건초 더미):\n건 건 건\n건 건 건\n건 건 건"
  },
  {
    "id": "rpg:warden_boots",
    "category": "armor",
    "name": "숲 수호자 장화",
    "text": "작업대 제작 → 숲 수호자 장화 ×1\n\n재료:\n모험가 장화 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n기존 갑옷을 재료로 쓰는 세트 업그레이드는 강화·인챈트를 승계하지 않습니다. 전용 보관함 룬은 유지됩니다."
  },
  {
    "id": "rpg:warden_chestplate",
    "category": "armor",
    "name": "숲 수호자 흉갑",
    "text": "작업대 제작 → 숲 수호자 흉갑 ×1\n\n재료:\n모험가 흉갑 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n기존 갑옷을 재료로 쓰는 세트 업그레이드는 강화·인챈트를 승계하지 않습니다. 전용 보관함 룬은 유지됩니다."
  },
  {
    "id": "rpg:warden_helmet",
    "category": "armor",
    "name": "숲 수호자 투구",
    "text": "작업대 제작 → 숲 수호자 투구 ×1\n\n재료:\n모험가 투구 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n기존 갑옷을 재료로 쓰는 세트 업그레이드는 강화·인챈트를 승계하지 않습니다. 전용 보관함 룬은 유지됩니다."
  },
  {
    "id": "rpg:warden_leggings",
    "category": "armor",
    "name": "숲 수호자 각반",
    "text": "작업대 제작 → 숲 수호자 각반 ×1\n\n재료:\n모험가 각반 ×1\n에메랄드 ×2\n참나무 판자 ×1\n\n작업대에 배치 순서와 관계없이 넣으세요.\n\n기존 갑옷을 재료로 쓰는 세트 업그레이드는 강화·인챈트를 승계하지 않습니다. 전용 보관함 룬은 유지됩니다."
  }
];
