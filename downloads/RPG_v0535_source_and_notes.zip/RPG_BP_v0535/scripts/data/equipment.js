export const ARMOR_SETS = {
  adventurer: {name:'모험가', protection:[2,5,4,2], durability:[220,320,300,220], physical:1.08, description:'4세트: 물리 스킬 피해 +8%'},
  warden: {name:'숲 수호자', protection:[3,6,5,2], durability:[300,450,420,300], health:8, description:'4세트: 최대 HP +8'},
  astral: {name:'별빛 술사', protection:[2,5,4,2], durability:[260,400,375,260], magic:1.08, manaRegen:3, description:'4세트: 마법 스킬 피해 +8%, 초당 마나 +3'},
};
export const ARMOR_PARTS = ['helmet','chestplate','leggings','boots'];
export const PART_NAMES = ['투구','흉갑','각반','장화'];
export const RUNES = {
  power:{name:'힘의 룬', description:'물리 스킬 피해 +10%', physical:1.10},
  ward:{name:'수호의 룬', description:'저항 I 유지 (더 강한 저항 효과 우선)', ward:true},
  mana:{name:'샘의 룬', description:'초당 최대 마나의 1% 추가 회복', manaRegenPercent:0.01},
  arcane:{name:'비전의 룬', description:'마법 스킬 피해 +10%', magic:1.10},
  vitality:{name:'생명의 룬', description:'최대 HP +4, 강화마다 +4 (최대 +24)', health:4},
};
export const RUNE_KEY = 'rpg:chest_rune';
export const ALL_EQUIPMENT_IDS = [
  'rpg:enhancement_catalyst', 'rpg:random_skillbook',
  ...Object.keys(ARMOR_SETS).flatMap(set=>ARMOR_PARTS.map(part=>`rpg:${set}_${part}`)),
  ...Object.keys(RUNES).map(rune=>`rpg:rune_${rune}`),
];
export function armorInfo(typeId) {
  for (const [set, data] of Object.entries(ARMOR_SETS)) {
    for (let i=0;i<ARMOR_PARTS.length;i++) if (typeId === `rpg:${set}_${ARMOR_PARTS[i]}`) return {set, part:ARMOR_PARTS[i], ...data};
  }
  return undefined;
}
