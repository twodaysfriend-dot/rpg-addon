import { world } from '@minecraft/server';
import { ActionFormData,ModalFormData } from '@minecraft/server-ui';
import { getProgress,addProgress,getJobId } from './playerData.js';
import { JOBS } from '../data/jobs.js';
import { requestAdvance,requirementStatus } from './advance.js';
import { showForm } from './skillMenu.js';
const busy=new Set();
export async function openLotoDialogue(p){
  if(busy.has(p.id))return;busy.add(p.id);
  try{
    if(p.getDynamicProperty('rpg:loto_rewarded')===true&&!getProgress(p).job_hacker_quiz)addProgress(p,'job_hacker_quiz',1);
    if(!getProgress(p).job_hacker_quiz){
      const talks=Number(p.getDynamicProperty('rpg:loto_talk_count')??0)+1;p.setDynamicProperty('rpg:loto_talk_count',talks);
      if(talks<3){await showForm(new ActionFormData().title('로토').body(`안녕, 난 코딩 전문 로토야. 대화 ${talks}/3. 세 번째에는 해커 시련 퀴즈를 줄게.`).button('확인'),p);return;}
      const reply=await showForm(new ModalFormData().title('로토의 해커 시련').textField('C언어에서 int형 포인터 변수 x를 선언해 보세요.','선언문 입력').submitButton('제출'),p);
      if(!reply||reply.canceled)return;
      if(!/^int\s*\*\s*x\s*;$/.test(String(reply.formValues?.[0]??'').trim())){p.sendMessage('§e오답입니다. 다시 도전할 수 있습니다.');return;}
      addProgress(p,'job_hacker_quiz',1);p.setDynamicProperty('rpg:loto_rewarded',true);
      if(!world.getDynamicProperty('rpg:loto_first_hacker'))world.setDynamicProperty('rpg:loto_first_hacker',p.id);
    }
    if(getJobId(p)==='hacker'){p.sendMessage('§a이미 해커이며 퀴즈 시련을 완료했습니다.');return;}
    const status=requirementStatus(p,JOBS.hacker);
    const reply=await showForm(new ActionFormData().title('해커 전직 조건').body(status.label+'\n최초 한 명 제한은 없습니다. 조건을 채운 모든 플레이어가 전직할 수 있습니다.').button('해커 전직 시도').button('나중에'),p);
    if(reply&&!reply.canceled&&reply.selection===0)await requestAdvance(p,JOBS.hacker);
  }catch(error){try{p.sendMessage('§c[로토] '+String(error));}catch{}}finally{busy.delete(p.id);}
}
export function clearLotoRuntime(id){busy.delete(id);}
