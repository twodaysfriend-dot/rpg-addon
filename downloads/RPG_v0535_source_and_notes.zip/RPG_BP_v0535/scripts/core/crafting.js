import { ActionFormData } from '@minecraft/server-ui';
import { CRAFTING_RECIPES } from '../data/crafting.js';
import { RUNES } from '../data/equipment.js';
import { showForm } from './skillMenu.js';

const categories=[{id:'armor',name:'갑옷 제작법'},{id:'rune',name:'룬 획득·제작법'},{id:'catalyst',name:'강화 촉매 제작법'},{id:'training',name:'샌드백 제작법'}];
const RUNE_GUIDE='룬 획득:\n일반 몬스터: 1% 확률로 룬 1개\nRPG 엘리트: 3% 확률로 룬 1개\nRPG 보스 4종·드래곤·위더·워든: 30% 확률로 룬 1개\n5종 중 같은 확률로 무작위 +0 룬을 드롭합니다.\n드롭은 바닥에 1개이며 파티원마다 복제하지 않습니다.\n\n원하는 룬은 아래 작업대 제작법으로 확정 제작할 수 있습니다.';
const menus=new Set();
export async function openCraftingGuide(player) {
  if(menus.has(player.id))return;
  menus.add(player.id);
  try {
    for(let i=0;i<30&&player.isValid;i++) {
      const root=new ActionFormData().title('RPG 제작 · 획득 도감')
        .body('제작은 작업대에서 진행합니다.\n모험가 갑옷 → 숲 수호자 또는 별빛 술사로 업그레이드할 수 있습니다.\n\n제작을 마친 뒤 장비를 강화하세요. 재료 갑옷의 강화·인챈트는 새 갑옷에 승계되지 않습니다. 룬 보관함은 유지됩니다.');
      for(const category of categories)root.button(category.name);
      root.button('닫기');
      const picked=await showForm(root,player);
      if(!picked||picked.canceled||picked.selection==null||picked.selection>=categories.length)return;
      const category=categories[picked.selection];
      const entries=CRAFTING_RECIPES.filter(recipe=>recipe.category===category.id);
      for(let j=0;j<40&&player.isValid;j++) {
        const form=new ActionFormData().title(category.name).body(category.id==='rune'?RUNE_GUIDE:'아이템을 선택하면 재료 수량과 실제 제작 배치를 보여줍니다.');
        for(const recipe of entries)form.button(recipe.name);
        form.button('뒤로');
        const answer=await showForm(form,player);
        if(!answer||answer.canceled||answer.selection==null||answer.selection>=entries.length)break;
        const recipe=entries[answer.selection];
        const rune=RUNES[recipe.id.replace('rpg:rune_','')];
        await showForm(new ActionFormData().title(recipe.name).body(recipe.text+
          (rune?'\n\n효과: '+rune.description+'\n/rpg:runes 에서 보관한 뒤 장착하세요.':'')).button('돌아가기'),player);
      }
    }
  }catch(error){try{player.sendMessage('§c[RPG] 제작 도감 오류: '+String(error));}catch{}}
  finally{menus.delete(player.id);}
}
