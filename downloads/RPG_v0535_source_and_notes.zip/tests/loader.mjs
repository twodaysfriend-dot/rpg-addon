export async function resolve(specifier, context, next) {
  if (specifier === '@minecraft/server' || specifier === '@minecraft/server-ui') {
    return {url: new URL('./minecraftMock.mjs', import.meta.url).href, shortCircuit:true};
  }
  return next(specifier, context);
}
export async function load(url, context, next) {
  if ((url.includes('/RPG_BP_v0535/')||url.includes('/RPG_Commands_BP_v0535/')) && url.endsWith('.js')) return next(url, {...context, format:'module'});
  return next(url, context);
}
