import test from 'node:test';
import assert from 'node:assert/strict';
import {player,players,world,events,timeouts,ItemStack,system} from './minecraftMock.mjs';
import {RUNNERS,armBlackFlash,BLACK_FLASH_KEY,registerWarGod} from '../RPG_BP_v0553/scripts/skills/warGod.js';
import {registerLifesteal,runeLifestealRate} from '../RPG_BP_v0553/scripts/core/lifesteal.js';
import {addRuneRecord,readRuneBag,writeRuneBag,equipRune,unequipRune} from '../RPG_BP_v0553/scripts/core/runeInventory.js';
import {upgradedRune} from '../RPG_BP_v0553/scripts/data/upgrades.js';
import {RUNES} from '../RPG_BP_v0553/scripts/data/equipment.js';
import {SKILLS} from '../RPG_BP_v0553/scripts/data/skills.js';
import {JOBS} from '../RPG_BP_v0553/scripts/data/jobs.js';
import {hurt} from '../RPG_BP_v0553/scripts/core/util.js';
import {registerRpgStats,getXp} from '../RPG_BP_v0553/scripts/core/stats.js';
import {registerInput} from '../RPG_BP_v0553/scripts/core/input.js';
import {setSkills,setIndex,setMana,getMana,cooldownLeft} from '../RPG_BP_v0553/scripts/core/playerData.js';
import {getContext} from '../RPG_BP_v0553/scripts/core/context.js';
import {purchaseChameleonSkill,executeChameleonSkill,remainingSkillUses,dismantleChameleonSkill} from '../RPG_BP_v0553/scripts/core/chameleonProgress.js';
import {getWallet} from '../RPG_BP_v0553/scripts/core/wallet.js';
import {checkAdvance} from '../RPG_BP_v0553/scripts/core/advance.js';
registerLifesteal();registerWarGod();let serial=0;
const emit=ev=>{for(const fn of events.entityHurt.listeners)fn(ev);};
function scene(rank=0,deferred=false){const id='wg'+serial++,p=player(id,80,{maxHealth:100}),t=player(id+'enemy',1,{typeId:'minecraft:zombie',health:500,maxHealth:500,location:{x:0,y:64,z:2}}),queue=[],hits=[],particles=[];
 p.setDynamicProperty('rpg:job','war_god');setSkills(p,JOBS.war_god.skills);p.equipment.set('Mainhand',new ItemStack('rpg:war_god_gauntlets'));p.health=10;players.push(p);
 const dim={id:'minecraft:overworld',getEntities:()=>[t],getBlock:()=>({isSolid:false,isAir:true,typeId:'minecraft:air'}),spawnParticle:(id,at)=>particles.push({id,at}),playSound(){}};p.dimension=t.dimension=dim;p.getViewDirection=()=>({x:0,y:0,z:1});t.applyKnockback=()=>{};
 t.applyDamage=(amount,options)=>{hits.push(amount);t.health=Math.max(0,t.health-amount);const fn=()=>emit({hurtEntity:t,damage:amount,damageSource:options});if(deferred)queue.push(fn);else fn();return true;};
 const bag=readRuneBag(p),r=addRuneRecord(bag,'absorption',rank);writeRuneBag(p,bag);equipRune(p,r.uid,0);return {p,t,r,queue,hits,particles};
}
test('absorption rune means lifesteal, with exact 5–12% ranks and no incoming damage reduction',()=>{
 for(const [rank,rate]of [.05,.064,.078,.092,.106,.12].entries()){assert.equal(upgradedRune(RUNES.absorption,rank).lifesteal,rate);assert.equal(upgradedRune(RUNES.absorption,rank).damageAbsorption,undefined);const {p,t}=scene(rank);hurt(t,p,100,'physical');assert.ok(Math.abs(p.health-(10+100*rate))<1e-8);}
});
test('unequipped rune, self hits, allies, dead attackers and dummies cannot produce lifesteal',()=>{
 const {p,t,r}=scene(5);unequipRune(p,r.uid);hurt(t,p,100);assert.equal(p.health,10);equipRune(p,r.uid,0);emit({hurtEntity:p,damage:20,damageSource:{damagingEntity:p}});assert.equal(p.health,10);
 const ally=player('friendly');p.getTags=()=>['rpg_team_f'];ally.hasTag=()=>true;emit({hurtEntity:ally,damage:20,damageSource:{damagingEntity:p}});assert.equal(p.health,10);
 p.health=0;emit({hurtEntity:t,damage:100,damageSource:{damagingEntity:p}});assert.equal(p.health,0);p.health=99;emit({hurtEntity:t,damage:100,damageSource:{damagingEntity:p}});assert.equal(p.health,100);
});
test('black flash makes the next effective basic hit exactly ten times and is consumed once',()=>{
 const {p,t}=scene();armBlackFlash(p);t.health-=10;emit({hurtEntity:t,damage:10,damageSource:{damagingEntity:p,cause:'entityAttack'}});assert.equal(t.health,400);assert.equal(p.health,15);assert.equal(p.getDynamicProperty(BLACK_FLASH_KEY),undefined);
 t.health-=10;emit({hurtEntity:t,damage:10,damageSource:{damagingEntity:p,cause:'entityAttack'}});assert.equal(t.health,390);assert.equal(p.health,15.5);
});
test('spell damage dispatched after applyDamage returns does not consume black flash or double heal',()=>{
 const {p,t,queue}=scene(0,true);armBlackFlash(p);hurt(t,p,40,'magic');assert.equal(p.health,10);assert.equal(p.getDynamicProperty(BLACK_FLASH_KEY),true);for(const fn of queue.splice(0))fn();assert.equal(p.health,12);assert.equal(p.getDynamicProperty(BLACK_FLASH_KEY),true);
});
test('all four skills deliver their actual hit counts and cancel follow-ups after death',()=>{
 for(const id of ['war_god_punch','war_god_flurry','war_god_kick','war_god_kick_flurry']){const {p,t,hits}=scene();const before=timeouts.length,d=SKILLS[id];assert.equal(RUNNERS[id](p,JOBS.war_god,d),true);for(const fn of timeouts.splice(before))fn();assert.equal(hits.length,d.hits);assert.equal(500-t.health,d.hits*d.damagePerHit);}
 const {p,hits}=scene();const before=timeouts.length;RUNNERS.war_god_flurry(p,JOBS.war_god,SKILLS.war_god_flurry);p.health=0;for(const fn of timeouts.splice(before))fn();assert.equal(hits.length,1);
});
test('raw multi-hit fallback preserves lifesteal and fatal kill XP/currency credit',()=>{
 const {p,t}=scene();t.typeId='rpg:rock_golem_boss';t.health=20;t.applyDamage=()=>false;registerRpgStats();RUNNERS.war_god_punch(p,JOBS.war_god,SKILLS.war_god_punch);assert.equal(t.health,0);assert.equal(p.health,11);
 for(const fn of events.entityDie.listeners)fn({deadEntity:t,damageSource:{}});assert.equal(getXp(p),450);assert.equal(getWallet(p).gold,3600);
});
test('misses, friends and repeated activation do not waste the black flash charge',()=>{
 const {p,t}=scene();assert.equal(armBlackFlash(p),true);assert.equal(armBlackFlash(p),false);t.location.z=50;assert.equal(RUNNERS.war_god_punch(p,JOBS.war_god,SKILLS.war_god_punch),false);assert.equal(p.getDynamicProperty(BLACK_FLASH_KEY),true);
});
test('war god is an independent hidden job available from any second-tier job with common trials',()=>{
 assert.equal(JOBS.war_god.parent,null);assert.equal(JOBS.war_god.tier,2);assert.equal(JOBS.war_god.hidden,true);assert.equal(JOBS.war_god.line,'war_god');
 for(const from of ['swordsman','mage','archer','fighter','cleric','fist_bone','sword_saint']){
  const p=player('trial-wg-'+from,40);p.setDynamicProperty('rpg:job',from);assert.equal(checkAdvance(p,JOBS.war_god).ok,false);
  p.setDynamicProperty('rpg:progress',JSON.stringify({job_kills:150,job_boss:5}));assert.equal(checkAdvance(p,JOBS.war_god).ok,true,from);
  p.setDynamicProperty('rpg:rpg_level',39);assert.equal(checkAdvance(p,JOBS.war_god).ok,false);
 }
 const p=player('trial-apprentice',40);p.setDynamicProperty('rpg:progress',JSON.stringify({job_kills:150,job_boss:5}));assert.equal(checkAdvance(p,JOBS.war_god).ok,false);
});

test('actual item input casts the new class skills, pays mana and respects cooldown',()=>{
 registerInput();const {p,hits}=scene();setSkills(p,JOBS.war_god.skills);setIndex(p,0);setMana(p,1000);
 for(const fn of events.itemUse.listeners)fn({source:p,itemStack:new ItemStack('rpg:war_god_gauntlets')});assert.equal(hits.length,1);assert.equal(getMana(p),940);assert.equal(cooldownLeft(p,'war_god_punch'),120);
 for(const fn of events.itemUse.listeners)fn({source:p,itemStack:new ItemStack('rpg:war_god_gauntlets')});assert.equal(hits.length,1);
 const registered=new Map();for(const fn of system.beforeEvents.startup.listeners)fn({itemComponentRegistry:{registerCustomComponent:(id,c)=>registered.set(id,c)}});assert.ok(registered.has('rpg:cast_item'));
 registered.get('rpg:cast_item').onUse({source:p});assert.equal(hits.length,1);
});
test('Chameleon learns black flash with ultimate charges and dismantling preserves its armed buff',()=>{
 const p=player('borrowed-black',40);p.setDynamicProperty('rpg:job','chameleon');setSkills(p,JOBS.chameleon.skills);assert.equal(purchaseChameleonSkill(p,'war_god_black_flash').ok,true);assert.equal(remainingSkillUses(p,'war_god_black_flash'),3);
 executeChameleonSkill(p,'war_god_black_flash',()=>armBlackFlash(p));assert.equal(remainingSkillUses(p,'war_god_black_flash'),2);assert.equal(dismantleChameleonSkill(p,'war_god_black_flash').refund,15);assert.equal(p.getDynamicProperty(BLACK_FLASH_KEY),true);
});

test('all four attacks show bounded cyan wave or upward kick effects without changing their hits',()=>{
 for(const id of ['war_god_punch','war_god_flurry','war_god_kick','war_god_kick_flurry']){
  const {p,t,hits,particles}=scene(),d=SKILLS[id],n=timeouts.length;RUNNERS[id](p,JOBS.war_god,d);for(const fn of timeouts.splice(n))fn();
  assert.equal(hits.length,d.hits);assert.equal(500-t.health,d.hits*d.damagePerHit);
  assert.ok(particles.some(e=>e.id===(d.kick?'rpg:war_god_kick_arc':'rpg:war_god_wave')),id);assert.ok(particles.some(e=>e.id==='rpg:war_god_burst'));assert.ok(particles.length<300);
 }
});
test('ultimate produces a radial visual while preserving tenfold single-target damage',()=>{
 const {p,t,particles}=scene(),bystander=player('ultimate-bystander',1,{typeId:'minecraft:zombie',health:500});p.dimension.getEntities=()=>[t,bystander];
 armBlackFlash(p);t.health-=10;emit({hurtEntity:t,damage:10,damageSource:{damagingEntity:p,cause:'entityAttack'}});
 assert.equal(t.health,400);assert.equal(bystander.health,500);assert.equal(particles.filter(e=>e.id==='rpg:war_god_finale').length,1);assert.ok(particles.filter(e=>e.id==='rpg:war_god_wave').length>=24);
});
test('delayed War God damage and visuals stop on death or dimension change',()=>{
 for(const stop of [p=>{p.health=0;},p=>{p.dimension={id:'minecraft:nether'};}]){
  const {p,hits,particles}=scene(),n=timeouts.length;RUNNERS.war_god_flurry(p,JOBS.war_god,SKILLS.war_god_flurry);const count=particles.length;stop(p);for(const fn of timeouts.splice(n))fn();assert.equal(hits.length,1);assert.equal(particles.length,count);
 }
});
test('particle API failures cannot suppress combat damage',()=>{
 const {p,t,hits}=scene();p.dimension.spawnParticle=()=>{throw Error('particle unavailable');};assert.equal(RUNNERS.war_god_punch(p,JOBS.war_god,SKILLS.war_god_punch),true);assert.deepEqual(hits,[40]);assert.equal(t.health,460);
});
