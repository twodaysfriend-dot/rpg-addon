import {updateHealthHud,resetHealthHud} from '../RPG_BP_v0553/scripts/core/healthHud.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,ItemStack,system} from './minecraftMock.mjs';
import {compactHudText,refreshHud,RPG_HUD_MARKER} from '../RPG_BP_v0553/scripts/core/hud.js';
import {setSkills,startCooldown} from '../RPG_BP_v0553/scripts/core/playerData.js';
import {JOBS} from '../RPG_BP_v0553/scripts/data/jobs.js';
import {dungeonRuns} from '../RPG_BP_v0553/scripts/core/dungeonState.js';
function swordsman(){const p=player('compact',100,{maxHealth:100});p.health=25;p.setDynamicProperty('rpg:job','sword_saint');setSkills(p,[...JOBS.sword_saint.skills]);p.equipment.set('Mainhand',new ItemStack(JOBS.sword_saint.weapon));return p;}
test('weapon, skill and resources fit three compact lines without level, next skill or slot count',()=>{
 const p=swordsman(),s=compactHudText(p);assert.equal(s.split('\n').length,3);assert.match(s,/검성의 검/);assert.match(s,/360도 휘두르기/);assert.match(s,/HP 25\/100/);assert.match(s,/MP/);assert.doesNotMatch(s,/Lv\.|다음:|\(1\/|\[검성\]/);
 startCooldown(p,'sword_spin',40);assert.match(compactHudText(p),/2.0초/);
});
test('dungeon adds only one short line and its timer keeps updating',()=>{
 const p=swordsman(),r={d:{tier:1},phase:'mobs',normalKilled:1,eliteKilled:0,deadline:Date.now()+289000,members:[{id:p.id}]};dungeonRuns.set('test',r);
 const s=compactHudText(p);assert.equal(s.split('\n').length,4);assert.match(s,/D1.*1\/50.*E0\/5/);dungeonRuns.clear();
});
test('HUD is namespaced for RP routing and empty hands clear it once instead of continuously clearing others',()=>{
 const p=swordsman();refreshHud(p,true);assert.ok(p.actionBars.at(-1).startsWith(RPG_HUD_MARKER));p.equipment.clear();p.maxHealth=20;refreshHud(p);assert.equal(p.actionBars.at(-1),'');const count=p.actionBars.length;system.currentTick+=100;refreshHud(p);assert.equal(p.actionBars.length,count);
});
test('UI anchors only RPG-marked actionbar at the lower left and preserves unmarked vanilla text',()=>{
 const d=JSON.parse(fs.readFileSync(new URL('../RPG_RP_v0553/ui/hud_screen.json',import.meta.url))),r=d.hud_actionbar_text;
 assert.equal(d.namespace,'hud');assert.deepEqual(r.offset,[0,0]);const panel=r.controls.find(c=>c.rpg_compact_panel).rpg_compact_panel;
 assert.equal(panel.anchor_from,'bottom_left');assert.equal(panel.anchor_to,'bottom_left');assert.deepEqual(panel.offset,[8,-38]);assert.ok(panel.visible.includes(RPG_HUD_MARKER));assert.equal(panel.controls[0].rpg_text.font_scale_factor,.75);assert.ok(panel.controls[0].rpg_text.text.includes(RPG_HUD_MARKER));assert.ok(r.controls.some(c=>c.vanilla_actionbar));assert.equal(r.controls[0].actionbar_message.visible,false);
});

test('armor and status effect HUD elements stay hidden across respawn without removing actual armor or buffs',()=>{
 const p=player('quiet-hud');p.equipment.set('Chest',new ItemStack('rpg:adventurer_chestplate'));p.addEffect('resistance',200,{amplifier:1});
 updateHealthHud(p);assert.deepEqual(p.hudChanges[0],{visibility:0,elements:[1,11]});assert.equal(p.equipment.get('Chest').typeId,'rpg:adventurer_chestplate');assert.equal(p.effects.get('resistance').amplifier,1);
 updateHealthHud(p);assert.equal(p.hudChanges.length,1);resetHealthHud(p);assert.deepEqual(p.hudChanges.at(-1),{visibility:0,elements:[1,11]});
});
