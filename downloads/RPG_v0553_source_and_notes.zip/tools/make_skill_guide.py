"""Generate the player reference from the same descriptions as /rpg:skillguide."""
from pathlib import Path
import json
import subprocess
root=Path(__file__).resolve().parents[1]
source="""import {JOBS,APPRENTICE_SKILLS} from './RPG_BP_v0553/scripts/data/jobs.js';
import {SKILLS} from './RPG_BP_v0553/scripts/data/skills.js';
import {LINE_NAMES,LINE_NOTES,SKILL_NOTES} from './RPG_BP_v0553/scripts/data/skillGuide.js';
console.log(JSON.stringify({JOBS,APPRENTICE_SKILLS,SKILLS,LINE_NAMES,LINE_NOTES,SKILL_NOTES}));"""
result=subprocess.run(['node','--experimental-loader','./tests/loader.mjs','--input-type=module','-e',source],cwd=root,text=True,capture_output=True,check=True)
data=json.loads(result.stdout)
jobs=[j for j in data['JOBS'].values() if not j.get('placeholder')]
apprentice=set(sum(data['APPRENTICE_SKILLS'].values(),[]))
active={s for j in jobs for s in j['skills']}|apprentice
assert active==set(data['SKILL_NOTES']),active^set(data['SKILL_NOTES'])
text='''# RPG v0.5.53 직업 계열별 스킬 상세 도감

게임에서는 `/rpg:skillguide`로 같은 설명을 볼 수 있습니다. 구현된 30개 전직 직업과 견습의 액티브 **136개**, 19계열의 고유 기능을 정리했습니다. 미구현 직업과 사용하지 않는 과거 스킬은 제외했습니다.

피해는 HP 단위(하트 한 칸=HP 2), 마나·피해는 지능·스탯·갑옷·룬 보정 전 기본 값입니다. 쿨타임은 초입니다. 다단 피해는 모든 타격을 넣은 명목 합계이며, 실제 피격 무적·방어·이동·벽·화염 면역으로 달라집니다. ‘고정’으로 적은 피해는 일반 스탯 피해 증가와 구분합니다.

힘 상태 효과는 물리·마법 스킬 피해를 단계당 5% 증가시킵니다(힘 I +5%·II +10%·III +15%). 단타와 연타 총합의 증가 비율은 같습니다. 무투가의 기존 힘 계산과 평타 배수에는 중복 적용하지 않으며, 고정 피해는 유지합니다. 기본 평타의 힘 효과는 엔진 규칙입니다. 보스에게 CC 1회 지속시간 및 넉백은 절반입니다.

천궁 마나 화살의 발당 MP 20은 고정 비용으로 지능 할인 대상이 아닙니다. 초신성 최대 55와 메테오 중심 58은 기본 피해이며 일반 스탯·장비 보정 후에는 달라집니다. 재부팅과 계약은 이번 요청대로 유지했습니다.

해·달의 후예는 천체 신전의 활성 제단에서만 전직합니다. 해는 낮, 달은 밤이며 기존 레벨20·해당 시간대 적60 조건도 유지합니다. `/rpg:temple`로 위치와 전직 메뉴를 확인합니다.

## 전직 계열과 스킬 승계

'''
text+='| 직업 | 직전 직업 | 보유 액티브 |\n|---|---|---|\n'
for j in jobs:
    if j['id']=='apprentice':continue
    parent=('로토 최초 정답자 (직업·레벨 제한 없음)' if j['id']=='hacker' else '성직자·천사·미카엘' if j['id']=='fallen_angel' else data['JOBS'][j['parent']]['name'] if j['parent'] else '아무 2차 이상')
    text+='| '+j['name']+' | '+parent+' | '+', '.join(data['SKILLS'][id]['name'] for id in j['skills'])+' |\n'
text+='\n상위 직업의 보유 목록은 실제 직업 데이터 기준입니다. 카멜레온은 기본 2개에 구매·스킬북으로 배운 액티브가 추가되지만, 원래 직업 제한이 있는 기술과 패시브까지 자동 승계되지는 않습니다.\n'
count=0
for line,title in data['LINE_NAMES'].items():
    ids=[id for id,s in data['SKILLS'].items() if id in active and s['line']==line]
    if not ids:continue
    text+=f"\n## {title}\n\n{data['LINE_NOTES'][line]}\n\n| 스킬·ID | 사용 직업 | 기본 MP | 쿨(초) | 효과·조건 |\n|---|---|---:|---:|---|\n"
    for id in ids:
        s=data['SKILLS'][id];owners=[j['name'] for j in jobs if id in j['skills']]
        if id in apprentice:owners.insert(0,'견습')
        text+=f"| {s['name']}<br>`{id}` | {', '.join(owners)} | {s['mana']} | {s['cooldown']/20:g} | {data['SKILL_NOTES'][id]} |\n";count+=1
text+='''
## 카멜레온 학습 전 확인

v0.5.53에서 직업·무기 검사로 막혔던 작골염양·검호 난도 후속타·광분화·용의 질주·용의 브레스·삼조격·3연베기·야수 화염방사·대폭발·참수·강펀치·축복의 구슬을 카멜레온 학습자에게 연결했습니다. 차크람 분열은 활성화 시 즉시 투척하고 버프 중 같은 기술 재사용으로 반복 투척합니다(0.75초 간격, 추가 MP·학습 횟수 없음). 마법 기술은 원래 계열처럼 마력 보정을 받습니다. 천궁 마나 화살·날개·용기사 3타 회복 등 고유 패시브는 자동 승계되지 않습니다. 빛 충전·조준 대상 등 각 기술의 조건은 충족해야 합니다.

검증은 코드 검토와 모의 API 실행입니다. 실제 Bedrock 클라이언트의 명중률·피격 무적·렌더링·PvP 승률을 측정한 결과는 아닙니다.
'''
assert count==136
target=root/'직업계열별_136개_스킬_상세도감.md';target.write_text(text)
print(f'Generated {target.name}: {count} skills')
