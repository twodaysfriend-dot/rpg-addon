import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0623'),base=root+'/RPG_BP_v0623/scripts/';
async function load(file,bindings={},basePath=base){const context=vm.createContext({console}),source=fs.readFileSync(basePath+file,'utf8'),m=new vm.SourceTextModule(source,{context});await m.link(async spec=>{const names=[];for(const hit of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g))if(hit[2]===spec)names.push(...hit[1].split(',').map(n=>n.trim().split(/\s+as\s+/)[0]));return new vm.SyntheticModule([...new Set(names)],function(){for(const n of new Set(names))this.setExport(n,bindings[n]??(()=>{}));},{context});});await m.evaluate();return m.namespace;}
const skills=(await load('data/skills.js')).SKILLS;
assert.equal(skills.war_god_flurry.projectiles,12);assert.equal(skills.war_god_flurry.damage,8.5);assert.equal(skills.nen_ho.cooldown,900);
async function waves({blocked=false,nativeFail=false,boost=false,distance=1,allied=false}={}){
 const intervals=new Map(),flags=new Map(),hits=[],manual=[];let next=0;const system={currentTick:0,runInterval:fn=>{const id=++next;intervals.set(id,fn);return id;},clearRun:id=>intervals.delete(id)};const dim={id:'overworld'},hp={currentValue:1000,setCurrentValue(n){this.currentValue=n;}};
 const t={id:'enemy',typeId:'minecraft:zombie',location:{x:0,y:0,z:distance},getComponent:()=>hp,applyDamage:n=>{hits.push(n);if(nativeFail)return false;hp.currentValue-=n;return true;}};
 const p={id:'p',typeId:'minecraft:player',isValid:true,location:{x:0,y:0,z:0},dimension:dim,getViewDirection:()=>({x:0,y:0,z:1}),getComponent:()=>({currentValue:100}),getDynamicProperty:k=>flags.get(k),setDynamicProperty:(k,v)=>v===undefined?flags.delete(k):flags.set(k,v)};
 const mod=await load('skills/warGod.js',{world:{},system,EntityDamageCause:{override:'override'},getTargets:(p,point,radius)=>Math.hypot(point.x,point.z-distance)<=radius?[t]:[],headPos:()=>({x:0,y:1.6,z:0}),norm3:v=>{const n=Math.hypot(v.x,v.y,v.z)||1;return {x:v.x/n,y:v.y/n,z:v.z/n};},isSolidAt:()=>blocked,areAllies:()=>allied,CONFIG:{pvp:false},skillDamageFor:(p,n)=>n,scriptedHit:(t,p,fn)=>fn(),deferStoppedDamage:()=>false,isTimeFrozen:()=>false,setCombatHealth:(t,p,hp,n)=>hp.setCurrentValue(n),noteManualDamage:(p,t,n)=>manual.push(n),BLACK_FLASH_KEY:'flash'});
 if(boost)flags.set('flash',true);assert.equal(mod.fanAttack(p,null,skills.war_god_flurry),true);let ticks=0;while(intervals.size&&ticks++<100){system.currentTick++;for(const fn of [...intervals.values()])fn();}assert.equal(intervals.size,0);return {hits,manual,hp,flags,ticks};
}
{const t=await waves();assert.equal(t.hits.length,12);assert.ok(t.hits.every(n=>n===8.5));assert.equal(t.hp.currentValue,898);}
{const t=await waves({nativeFail:true});assert.equal(t.hits.length,12);assert.equal(t.manual.reduce((a,b)=>a+b,0),102);assert.equal(t.hp.currentValue,898);}
{const t=await waves({boost:true});assert.equal(t.hits.length,12);assert.ok(t.hits.every(n=>n===25.5));assert.equal(t.flags.has('flash'),false);}
for(const option of [{blocked:true,boost:true},{allied:true,boost:true},{distance:100,boost:true}]){const t=await waves(option);assert.equal(t.hits.length,0);assert.equal(t.flags.get('flash'),true);}
{const t=await waves({distance:12});assert.ok(t.hits.length>0);assert.ok(t.ticks>1);}
console.log('War God ranged volley: 12 independent hits x8.5=102, true travel, native rejection fallback, x3 boost, allies/walls/range, misses preserve charge');
// Freeze the previous release curve here so source archives remain reproducible.
const armor=[[95,5,0,0],[90,10,0,0],[80,18,2,0],[70,23,7,0],[60,28,10,2],[50,30,16,4],[40,32,22,6],[30,34,27,9],[22,35,30,13],[15,35,32,18]],rune=[[95,5,0,0],[90,10,0,0],[70,28,2,0],[65,28,7,0],...armor.slice(4)];
const rates=(await load('data/upgrades.js')).enhancementRates;
for(const kind of ['rune','armor','weapon'])for(let level=0;level<10;level++)for(let c=0;c<=5;c++){
 const allowed=kind==='rune'?level>=2:level>=5,actual=rates(kind,level,c);if(c&&!allowed){assert.equal(actual,undefined);continue;}
 let [s,f,d,x]=(kind==='rune'?rune:armor)[level];if(c){x=Math.max(0,x-3*c);s=Math.min(s+9*c,100-d-x);f=100-s-d-x;}
 const expected=kind==='rune'?[s+d/4,f+d/4,d/2,x]:[s,f,d,x];assert.deepEqual(Array.from(Object.values(actual)),expected);assert.equal(expected.reduce((a,b)=>a+b),100);
}
assert.equal(rates('rune',2,5).success,98.5);assert.equal(rates('rune',2,5).fail,.5);assert.equal(rates('rune',2,5).downgrade,1);
console.log('Rune rates: every level and valid catalyst count halves downgrade, splits released chance equally, unchanged destruction; armor/weapons unchanged; totals exactly 100%');
console.log('Nen cannon cooldown: exactly 900 ticks / 45 seconds');

const grades=await load('data/grades.js');
const up=await load('data/upgrades.js',{gradeRank:grades.gradeRank,GRADE_MULTIPLIERS:grades.GRADE_MULTIPLIERS});
const runes=(await load('data/equipment.js',{COMMON_WEAPONS:[]})).RUNES;
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-9,`${a} != ${b}`);
for(const key of ['power','arcane'])for(let level=0;level<=10;level++){
 const field=key==='power'?'physical':'magic';
 for(let grade=1;grade<=6;grade++){
  const prev=up.upgradedRune(runes[key],level,grade-1)[field];
  const now=up.upgradedRune(runes[key],level,grade)[field];
  // Hero unlocks additional enhancement perks; all other grade steps are exactly x1.5.
  if(grade===4&&level>=8)assert.ok(now-1>=(prev-1)*1.5-1e-9);else close(now-1,(prev-1)*1.5);
 }
}
for(let level=0;level<=10;level++)for(let grade=0;grade<=6;grade++){
 const extras=grade>=4?(level>=8?.01:0)+(level>=10?.015:0):0;
 close(up.upgradedRune(runes.absorption,level,grade).lifesteal,((.05+level*.007)*1.5**grade+extras*(up.EXTRA_SCALE[grade]??1))*.5);
}
const stats=await load('core/stats.js',{world:{},system:{},EquipmentSlot:{Mainhand:'Mainhand'},CONFIG:{skillDamage:{strengthPerLevel:.05}},getEquipmentBonuses:()=>({physical:1,magic:1}),classWeapon:()=>undefined});
const player=n=>({typeId:'minecraft:player',getDynamicProperty:k=>k==='rpg:stat_values'?JSON.stringify({str:n,mag:n,vit:5,int:5}):undefined,getComponent:()=>undefined,getEffect:()=>undefined});
for(const type of ['physical','magic']){close(stats.skillDamageFor(player(6),10,type)-stats.skillDamageFor(player(5),10,type),type==='physical'?.4704:1.176);assert.equal(stats.skillDamageFor(player(100),10,'fixed'),10);}
const weapons=(await load('data/commonWeapons.js')).COMMON_WEAPONS;
let manual=0;
const damage=await load('core/commonWeaponDamage.js',{COMMON_WEAPONS:weapons,classWeapon:()=>undefined,GRADE_MULTIPLIERS:grades.GRADE_MULTIPLIERS,itemGrade:i=>i.grade,upgradeLevel:i=>i.level,runeMeleeBonus:()=>0,EquipmentSlot:{Mainhand:'Mainhand'},EntityDamageCause:{entityAttack:'entityAttack'},currentScriptHit:()=>false,areAllies:()=>false,CONFIG:{pvp:false},scriptedHit:(t,p,fn)=>fn(),setCombatHealth:(t,p,hp,n)=>hp.currentValue=n,noteManualDamage:(p,t,n)=>manual+=n});
for(const w of weapons)for(let grade=0;grade<=6;grade++)for(let level=0;level<=10;level++){
 const item={typeId:w.id,grade,level},native=1+w.damage,expected=1+w.damage*grades.GRADE_MULTIPLIERS[grade]+level;
 const p={id:'p',typeId:'minecraft:player',getComponent:()=>({getEquipment:()=>item})},hp={currentValue:1000},t={id:'t',typeId:'minecraft:zombie',getComponent:()=>hp};
 close(damage.applyCommonWeaponBonus({damage:native,damageSource:{damagingEntity:p,cause:'entityAttack'},hurtEntity:t}),expected);
 close(hp.currentValue,1000-(expected-native));
 close(damage.applyCommonWeaponBonus({damage:native,damageSource:{damagingEntity:p,cause:'entityAttack'},hurtEntity:t},true),native);
}
console.log('v0.6.23: all rune grades/enhancements, halved absorption incl extras, STR +0.4704 / MAG +1.176 per base 10, all 7 common weapons x 7 grades x 11 upgrades through real melee hook; scripted hits excluded');
