// Shared display state without loading world/skill modules into the HUD.
export const dungeonRuns=new Map(),dungeonLobbies=new Map();
export function dungeonHudText(player,now=Date.now()){
 const r=[...dungeonRuns.values()].find(r=>r.members.some(m=>m.id===player.id));if(!r)return '';
 if(r.phase==='preparing')return `§7던전 ${r.d.tier} · 입장 준비 중§r`;
 const seconds=Math.max(0,Math.ceil((r.deadline-now)/1000)),clock=`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;
 return r.phase==='boss'?`§c던전 ${r.d.tier} · 보스 · ${clock}§r`:`§e던전 ${r.d.tier} · 일반 ${r.normalKilled}/50 · 정예 ${r.eliteKilled}/5 · ${clock}§r`;
}
