import fs from 'node:fs';import assert from 'node:assert/strict';
const root=process.argv[2]??'.';let bosses=0;
for(const name of fs.readdirSync(root+'/RPG_BP_v0638/entities').filter(n=>n.endsWith('.json'))){
 const entity=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0638/entities/'+name))['minecraft:entity'],c=entity.components??{};
 if(!c['minecraft:boss']&&!c['minecraft:type_family']?.family?.includes('boss'))continue;
 bosses++;
 for(const group of [c,...Object.values(entity.component_groups??{})])assert.equal(group['minecraft:behavior.hurt_by_target'],undefined,name+' must not pin aggro to a distant attacker');
 const target=c['minecraft:behavior.nearest_attackable_target'];assert.equal(target.priority,1);assert.equal(target.reselect_targets,true);assert.equal(target.scan_interval,10);assert.equal(target.must_see,true);assert.equal(target.must_reach,true);assert.equal(target.must_see_forget_duration,.5);assert.equal(target.persist_time,0);
 assert.ok(target.entity_types.length);for(const entry of target.entity_types){assert.equal(entry.filters.value,'player');assert.equal(entry.must_see,true);assert.equal(entry.must_see_forget_duration,.5);assert.ok(entry.max_dist>0);}
}
assert.equal(bosses,5);console.log('Boss targeting: all 5 boss definitions, including all 10 dungeon tiers, use native nearest visible/reachable player reselection every 10 ticks; retaliation pinning removed; runtime native AI remains an in-engine check');
