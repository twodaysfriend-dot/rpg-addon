# RPG v0.6.58 · 미카엘 홀리 스피어

우클릭하면 사파이어 창날과 금빛 날개 장식이 달린 성창이 머리 위를 0.8초 동안 한 바퀴 돕니다. 발사 순간 20칸 안에서 가장 최근에 공격한 유효 대상을 우선하며, 없으면 가장 가까운 적을 추적합니다. 비행 도중 목표가 사라지면 남은 사거리 안에서 다시 유도됩니다. 창은 벽에 부딪히면 소멸하고 한 번만 적중합니다. 시전할 대상이 없으면 마나와 쿨타임이 소모되지 않습니다.

좌클릭으로 적을 맞히면 즉시 피해를 주고 빛의 인장이 펼쳐집니다. 창날이 박힌 위치에서 창자루가 바깥으로 드러나며, 약 1초 동안 살아 있는 적의 움직임과 회전을 따라갑니다.

마법 기본 피해 20, 몬스터 기본 피해 30, 기본 마나 80, 쿨타임 3초. Bedrock 1.21.100 이상에서 세 팩을 모두 v0.6.58로 활성화하세요.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0658
```
