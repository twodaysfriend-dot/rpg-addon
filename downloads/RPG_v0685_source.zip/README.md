# RPG v0.6.85 · 직업 교환과 복귀

명령어 `/rpg:jobchange` 또는 **상태창 → 내 캐릭터 → 직업 교환 · 복귀**로 열 수 있습니다.

- **직업 교환**은 접속 중인 플레이어를 선택해 요청을 보냅니다. 상대가 60초 안에 **받은 교환 요청**에서 수락하면 현재 직업이 서로 바뀝니다.
- **이전 직업으로 복귀**에서는 직접 전직했거나 교환으로 얻은 직업을 선택할 수 있습니다. 전직 시험이나 카드를 다시 요구하지 않습니다. 기존 월드는 현재 직업과 저장된 기본 전직 기록을 불러옵니다. 업데이트 전 기록이 남지 않은 직업은 목록에 표시할 수 없습니다.
- 장비와 재화는 원래 소유자가 보유합니다. 직업 교환·복귀로 벗은 전용 무기는 인벤토리에 보관하며 해당 직업으로 돌아가면 다시 장착합니다. 해당 직업의 스킬 선택과 켜고 끈 설정도 복구합니다. 전용 장비를 넣을 칸이 필요한 경우 인벤토리에 빈칸을 만들어 주세요.
- 사망·수감·던전·결투·시간 정지 중에는 변경할 수 없습니다. 교환은 전직한 서로 다른 직업 간에 할 수 있습니다. 해커는 월드 최초 전직자 전용이므로 자신의 이전 기록으로 복귀할 수 있습니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.85로 활성화하세요. 모의 테스트에서 교환 수락·거절·만료, 요청 중 직업 변경, 저장 실패 시 양쪽 복구, 전용 장비와 스킬 설정 복원을 확인했습니다. 실제 Bedrock 멀티플레이 월드에서의 작동은 확인 전입니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0685
```
