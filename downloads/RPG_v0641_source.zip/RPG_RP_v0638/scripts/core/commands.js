import * as mc from "@minecraft/server";
import { runRpgAction } from "./rpgActions.js";

// 슬래시 명령어 등록: /rpg:job 검성, /rpg:status 처럼 /scriptevent 없이 씁니다.
// (커스텀 명령어는 이름 앞에 네임스페이스 rpg: 가 반드시 붙습니다.)
// 없는 이름이 있어도 스크립트 전체가 죽지 않도록 모듈 전체(mc)를 통해 안전하게 꺼내고,
// 명령어마다 따로 등록해서 하나가 실패해도 나머지는 등록됩니다.
export function registerCommands() {
  const startup = mc.system.beforeEvents?.startup;
  if (!startup) return;

  startup.subscribe((init) => {
    const registry = init.customCommandRegistry;
    if (!registry) {
      console.warn("[rpg] 이 버전은 커스텀 명령어를 지원하지 않습니다. /scriptevent rpg:... 를 쓰세요.");
      return;
    }
    const perm = mc.CommandPermissionLevel ?? mc.CustomCommandPermissionLevel ?? {};
    const ANY = perm.Any ?? 0;
    const OP = perm.GameDirectors ?? 1; // 관리자(명령 블록 포함)
    const ok = mc.CustomCommandStatus?.Success ?? 0;
    const fail = mc.CustomCommandStatus?.Failure ?? 1;
    const STRING = mc.CustomCommandParamType?.String;

    // action: runRpgAction 의 동작 이름, param: 문자열 인자 이름(없으면 인자 없음)
    const add = (action, description, level, param) => {
      try {
        const def = { name: `rpg:${action}`, description, permissionLevel: level, cheatsRequired: false };
        if (param && STRING !== undefined) def.mandatoryParameters = [{ name: param, type: STRING }];
        registry.registerCommand(def, (origin, arg) => {
          const p = origin?.sourceEntity;
          if (p?.typeId !== "minecraft:player") {
            return { status: fail, message: "플레이어만 사용할 수 있습니다." };
          }
          // 명령어 콜백은 읽기 전용 구간이라, 아이템/창을 다루는 작업은 한 틱 뒤에 실행
          mc.system.run(() => {
            try {
              const value = Array.isArray(arg) ? arg[0] : arg;
              runRpgAction(action, p, value);
            } catch (e) {
              console.warn(`[rpg] /rpg:${action} 실패: ${e}`);
            }
          });
          return { status: ok };
        });
      } catch (e) {
        console.warn(`[rpg] /rpg:${action} 등록 실패: ${e}`);
      }
    };

    add("job", "조건을 지키며 전직합니다 (예: /rpg:job 마법사)", ANY, "job");
    add("help", "RPG 명령어 사용법을 확인합니다", ANY);
    add("status", "내 직업, 마나, 전직 조건 진행도를 봅니다", ANY);
    add("skills", "책/지팡이의 스킬을 켜고 끄는 설정창을 엽니다", ANY);
    add("book", "인벤토리의 인챈트 책을 바쳐 최대 마나를 늘립니다", ANY);
    add("sword", "다이아몬드 검을 바쳐 검성 전직 조건을 채웁니다", ANY);
    add("bless", "축복의 빛을 바쳐 천사/미카엘 전직 조건을 채웁니다", ANY);
    add("holywater", "물병 1개와 축복의 빛 1개로 성수를 만듭니다 (조합이 안 될 때)", ANY);
    add("force", "조건 무시하고 전직합니다 (관리자)", OP, "job");
    add("reset", "견습으로 초기화합니다 (관리자)", OP);
    add("starter", "견습 시작 아이템과 스킬을 받습니다 (관리자) - sword, mage, holy, fist, archer", OP, "line");
    add("charge", "마나를 가득 채우고 쿨타임을 초기화합니다 (관리자)", OP);
    add("items", "애드온 전용 아이템을 전부 받습니다 (관리자)", OP);
    add("wings", "천사/미카엘/타락 계열의 날개를 켜거나 끕니다", ANY);
    add("wingcheck", "날개 아이템 보조손 장착 및 활성 상태 확인", ANY);
    add("wingrefresh", "보조손 날개 재장착으로 표시 갱신", ANY);
    add("guild", "길드 생성·초대·관리 메뉴를 엽니다", ANY);
    add("party", "파티 생성·초대·관리 메뉴를 엽니다", ANY);
    add("invites", "받은 길드·파티 초대를 확인합니다", ANY);
    add("boss", "바위 골렘을 앞에 소환합니다 (관리자)", OP);
    add("fistcheck", "무투가·권골 무장색 장착 상태 확인", ANY);
  });
}
