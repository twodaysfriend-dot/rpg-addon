import { ItemStack, ItemLockMode } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { JOBS, ALL_WEAPON_IDS, STARTER_BY_LINE, APPRENTICE_SKILLS } from "../data/jobs.js";
import { SKILLS } from "../data/skills.js";
import {
  getJobId, setJobId, getSkills, setSkills, setMana, setIndex, maxManaOf, getProgress, getDisabled, setDisabled,
} from "./playerData.js";
import { sound } from "./util.js";
import { showForm } from "./skillMenu.js";

// 전직 조건 진행도 (조건이 없으면 null)
export function requirementStatus(player, target) {
  if (!target?.req) return null;
  const have = Math.min(getProgress(player)[target.req.key] ?? 0, target.req.need);
  return { have, need: target.req.need, label: target.req.label, met: have >= target.req.need };
}

// 전직 가능 여부: 직전 직업 + 전직 조건
export function checkAdvance(player, target) {
  if (!target) return { ok: false, reason: "존재하지 않는 직업입니다." };
  if (target.hidden) return { ok: false, reason: `${target.name}은(는) 히든 직업입니다. 해금 방법은 추후 설정됩니다.` };
  if (target.placeholder) {
    return { ok: false, reason: `${target.name}은(는) 아직 구현되지 않았습니다.` };
  }
  const cur = getJobId(player);
  if (target.parent !== cur) {
    const from = JOBS[target.parent]?.name ?? "?";
    return { ok: false, reason: `${target.name}은(는) ${from}에서만 전직할 수 있습니다.` };
  }
  const st = requirementStatus(player, target);
  if (st && !st.met) {
    return {
      ok: false,
      reason: `전직 조건 미달: ${st.label} ${st.have}/${st.need}`,
    };
  }
  return { ok: true };
}

// 2차 전직 때 사라질 스킬 id 목록 (선택한 계열 밖의 스킬)
export function skillsLostOnAdvance(player, target) {
  if (target.tier !== 2) return [];
  return getSkills(player).filter((id) => SKILLS[id]?.line !== target.line);
}

function moveOrDrop(player, container, item) {
  for (let i = 1; i < container.size; i++) {
    if (!container.getItem(i)) {
      container.setItem(i, item);
      return;
    }
  }
  player.dimension.spawnItem(item, player.location);
}

// 직업 무기를 1번 칸에 고정해서 지급합니다. 이전 RPG 무기(견습 시작 아이템 포함)는 모두 회수합니다.
export function giveWeapon(player, job) {
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c) return;

  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it && ALL_WEAPON_IDS.includes(it.typeId)) c.setItem(i, undefined);
  }
  if (!job.weapon) return;

  const old = c.getItem(0);
  if (old) {
    c.setItem(0, undefined);
    moveOrDrop(player, c, old);
  }

  const weapon = new ItemStack(job.weapon, 1);
  weapon.lockMode = ItemLockMode?.slot ?? "slot";
  weapon.keepOnDeath = true;
  c.setItem(0, weapon);
}

// 1번 칸에 무기가 없으면 다시 지급 (사망/크리에이티브 조작 등 대비)
export function ensureWeapon(player) {
  const job = JOBS[getJobId(player)];
  if (!job?.weapon) return;
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c) return;
  if (c.getItem(0)?.typeId === job.weapon) return;
  giveWeapon(player, job);
}

// 견습 시작 아이템 지급 + 그 계열의 견습 스킬 습득 (초반 지역의 상자/NPC/명령 블록에서 호출)
export function giveStarter(player, line) {
  const itemId = STARTER_BY_LINE[line];
  if (!itemId) return { ok: false, reason: "알 수 없는 계열입니다. (sword, mage, holy, fist, archer)" };
  if (getJobId(player) !== "apprentice") {
    return { ok: false, reason: "견습만 받을 수 있습니다." };
  }

  const learned = getSkills(player);
  for (const id of APPRENTICE_SKILLS[line] ?? []) {
    if (!learned.includes(id)) learned.push(id);
  }
  setSkills(player, learned);

  const c = player.getComponent("minecraft:inventory")?.container;
  if (c) {
    let has = false;
    for (let i = 0; i < c.size; i++) if (c.getItem(i)?.typeId === itemId) has = true;
    if (!has) {
      const left = c.addItem(new ItemStack(itemId, 1));
      if (left) player.dimension.spawnItem(left, player.location);
    }
  }
  if (line === "archer" && c) {
    const arrows = c.addItem(new ItemStack("minecraft:arrow", 64));
    if (arrows) player.dimension.spawnItem(arrows, player.location);
  }
  return { ok: true };
}

// 애드온 전용 아이템 전부를 인벤토리에 지급 (이미 가진 아이템은 건너뜀)
export function giveAllItems(player) {
  const c = player.getComponent("minecraft:inventory")?.container;
  if (!c) return 0;
  const have = new Set();
  for (let i = 0; i < c.size; i++) {
    const it = c.getItem(i);
    if (it) have.add(it.typeId);
  }
  let n = 0;
  for (const id of new Set([...ALL_WEAPON_IDS, "rpg:blessing_light", "rpg:holy_water", "rpg:sandbag_spawner", "rpg:angel_wing_toggle", "rpg:michael_wing_toggle", "rpg:fallen_wing_toggle", "rpg:mangnani_contract", "rpg:blood_spear"])) {
    if (have.has(id)) continue;
    const left = c.addItem(new ItemStack(id, 1));
    if (left) player.dimension.spawnItem(left, player.location);
    n++;
  }
  return n;
}

export function applyAdvance(player, target) {
  let skills = getSkills(player);
  if (target.tier === 2) {
    skills = skills.filter((id) => SKILLS[id]?.line === target.line);
  }
  if (target.tier >= 3) {
    // 견습 마법처럼 낮은 차수까지만 쓰는 스킬은 목록에서 제외
    skills = skills.filter((id) => (SKILLS[id]?.maxTier ?? 99) >= target.tier);
  }
  // 천궁 전직 시 궁수 전용 불 화살이 폭탄 화살로 교체됩니다.
  if (target.id === "heavenly_archer") {
    skills = skills.filter(id => id !== "archer_fire" && id !== "archer_triple");
    const disabled = getDisabled(player);
    if (disabled.includes("archer_fire")) setDisabled(player, disabled.filter(id => id !== "archer_fire"));
  }
  // 검성 계열 전직 시 발도를 제거합니다. 섬멸은 검성만 보유합니다.
  if (target.id === "sword_saint" || target.id === "fallen_sword_saint") {
    skills = skills.filter((id) => id !== "sword_draw");
    const off = getDisabled(player);
    if (off.includes("sword_draw")) setDisabled(player, off.filter((id) => id !== "sword_draw"));
  }
  if (target.id === "fallen_sword_saint") {
    skills = skills.filter((id) => id !== "sword_annihilation");
    const off = getDisabled(player);
    if (off.includes("sword_annihilation")) setDisabled(player, off.filter((id) => id !== "sword_annihilation"));
  }
  for (const id of target.skills) if (!skills.includes(id)) skills.push(id);

  setSkills(player, skills);
  setJobId(player, target.id);
  setIndex(player, 0);
  setMana(player, maxManaOf(player));
  giveWeapon(player, target);
  if (target.line === "archer") {
    try {
      const c = player.getComponent("minecraft:inventory")?.container;
      const arrows = c?.addItem(new ItemStack("minecraft:arrow", 64));
      if (arrows) player.dimension.spawnItem(arrows, player.location);
    } catch { /* 인벤토리가 준비되지 않은 경우 */ }
  }

  try {
    player.onScreenDisplay.setTitle(`${target.corrupt ? "§c" : "§b"}${target.name}`, {
      subtitle: "전직 완료",
      fadeInDuration: 10,
      stayDuration: 50,
      fadeOutDuration: 10,
    });
  } catch {
    player.sendMessage(`§e전직 완료: ${target.name}`);
  }
  sound(player.dimension, "random.levelup", player.location, { volume: 1, pitch: 1 });
}

export function resetToApprentice(player) {
  setJobId(player, "apprentice");
  setSkills(player, []);
  setDisabled(player, []);
  setIndex(player, 0);
  setMana(player, maxManaOf(player));
  giveWeapon(player, JOBS.apprentice);
}

// 전직 요청. 사라지는 스킬이 있으면 확인창을 먼저 띄웁니다.
// force=true 는 테스트용으로 조건 검사를 건너뜁니다.
export async function requestAdvance(player, target, force = false) {
  if (!force) {
    const r = checkAdvance(player, target);
    if (!r.ok) {
      player.sendMessage(`§c${r.reason}`);
      return;
    }
  }

  const lost = skillsLostOnAdvance(player, target);
  if (lost.length === 0) {
    applyAdvance(player, target);
    return;
  }

  const names = lost.map((id) => SKILLS[id]?.name ?? id).join(", ");
  const form = new ActionFormData()
    .title("전직 확인")
    .body(
      `${target.name}(으)로 전직하면 다음 스킬이 사라집니다.\n\n§c${names}§r\n\n되돌릴 수 없습니다. 전직할까요?`
    )
    .button("전직한다")
    .button("취소");

  const res = await showForm(form, player);
  if (!res || res.canceled) {
    player.sendMessage("§7전직창이 닫혔습니다. 채팅창을 닫고 다시 시도해 주세요.");
    return;
  }
  if (res.selection !== 0) return;

  // 확인창이 떠 있는 동안 상태가 바뀌었을 수 있으니 다시 확인
  if (!force) {
    const r = checkAdvance(player, target);
    if (!r.ok) {
      player.sendMessage(`§c${r.reason}`);
      return;
    }
  }
  applyAdvance(player, target);
}
