import { world, system } from "@minecraft/server";
import { CONFIG } from "./config.js";
import { JOBS, findJob } from "./data/jobs.js";
import { SKILLS } from "./data/skills.js";
import {
  getJobId, setJobId, setSkills, getSkills, getMana, setMana, maxManaOf, getProgress,
  clearPlayerRuntime, getDisabled,
} from "./core/playerData.js";
import {
  requestAdvance, ensureWeapon, resetToApprentice, giveStarter, requirementStatus,
} from "./core/advance.js";
import { registerInput, handleFriendlyHit } from "./core/input.js";
import { registerTracking } from "./core/tracking.js";
import { registerHoly } from "./skills/holy.js";
import { registerFist } from "./skills/fist.js";
import { registerFistCoating } from "./core/fistCoating.js";
import { registerArcher } from "./skills/archer.js";
import { registerNecromancer } from "./skills/necro.js";
import { registerDarkMagic } from "./skills/dark.js";
import { registerSandbag } from "./core/sandbag.js";
import { registerWings } from "./core/wings.js";
import { registerFrenzy } from "./core/frenzy.js";
import { registerBerserker } from "./skills/berserker.js";
import { registerBloodMagic } from "./skills/blood.js";
import { registerHacker } from "./skills/hacker.js";
import { registerHarpoon } from "./skills/harpoon.js";
import { registerFrost } from "./skills/frost.js";
import { registerFire } from "./skills/fire.js";
import { registerAssassin } from "./skills/assassin.js";
import { registerTechnomancer } from "./skills/technomancer.js";
import { registerDemon } from "./skills/demon.js";
import { registerCelestial } from "./skills/celestial.js";
import { registerSwordFlameSpin } from "./skills/swordFlameSpin.js";
import { registerDragon } from "./skills/dragon.js";

import { registerSocial } from "./core/social.js";
import { registerFriendlyFire } from "./core/friendlyFire.js";
import { registerGolemBoss } from "./core/golemBoss.js";
import { registerCyclopsBoss } from "./core/cyclopsBoss.js";
import { runRpgAction } from "./core/rpgActions.js";
import { setCommandHandler, setGameplayStatus } from "./core/commandBridge.js";
import { startHud } from "./core/hud.js";
import { registerRpgStats, applyVitality } from "./core/stats.js";

// 처음 들어온 플레이어는 견습으로 시작
function initPlayer(player) {
  if (getJobId(player)) return;
  setJobId(player, "apprentice");
  setSkills(player, []);
  setMana(player, maxManaOf(player));
}

// Start gameplay from the same static ES module graph as command registration.
// Each feature is isolated so a single faulty handler does not disable commands.
let gameplayInitialized = false;
export function initializeGameplay() {
  if (gameplayInitialized) return { state: "ready", errors: [] };
  gameplayInitialized = true;
  const errors = [];
  const safe = (name, fn) => {
    try { fn(); }
    catch (error) {
      const info = name + ": " + String(error?.stack ?? error);
      errors.push(info);
      console.warn("[rpg/gameplay] " + info);
    }
  };

  // Link the command bridge even if a nonessential skill system fails.
  setCommandHandler(runRpgAction);
  safe("playerSpawn", () => world.afterEvents.playerSpawn.subscribe((ev) => {
    const p = ev.player;
    system.runTimeout(() => {
      try {
        initPlayer(p);
        ensureWeapon(p);
        applyVitality(p);
      } catch { /* player unavailable */ }
    }, 20);
  }));
  safe("playerLeave", () => world.afterEvents.playerLeave.subscribe((ev) => clearPlayerRuntime(ev.playerId)));
  safe("manaRegen", () => system.runInterval(() => {
    for (const p of world.getAllPlayers()) {
      try {
        initPlayer(p);
        const max = maxManaOf(p);
        const mana = getMana(p);
        if (mana < max) setMana(p, mana + Math.max(1, max * CONFIG.mana.regenRate));
        ensureWeapon(p);
      } catch { /* player not ready */ }
    }
  }, 20));

  const features = [
    ["RPG stats", () => registerRpgStats()],
    ["social", () => registerSocial()],
    ["friendly fire", () => registerFriendlyFire(handleFriendlyHit)],
    ["golem boss", () => registerGolemBoss()],
    ["cyclops boss", () => registerCyclopsBoss()],
    ["input", () => registerInput()],
    ["작골염양 점프 감지", () => registerSwordFlameSpin()],
    ["tracking", () => registerTracking()],
    ["holy", () => registerHoly()],
    ["fist", () => registerFist()],
    ["fist coating", () => registerFistCoating()],
    ["archer", () => registerArcher()],
    ["necromancer", () => registerNecromancer()],
    ["dark magic", () => registerDarkMagic()],
    ["sandbag", () => registerSandbag()],
    ["wings", () => registerWings()],
    ["frenzy", () => registerFrenzy()],
    ["berserker", () => registerBerserker()],
    ["blood magic", () => registerBloodMagic()],
    ["hacker", () => registerHacker()],
    ["harpoon", () => registerHarpoon()],
    ["frost", () => registerFrost()],
    ["fire", () => registerFire()],
    ["assassin", () => registerAssassin()],
    ["technomancer", () => registerTechnomancer()],
    ["demon", () => registerDemon()],
    ["celestial", () => registerCelestial()],
    ["dragon knight", () => registerDragon()],
    ["HUD", () => startHud()],
  ];
  for (const [name, start] of features) safe(name, start);

  safe("script events", () => system.afterEvents.scriptEventReceive.subscribe((ev) => {
    if (!ev.id.startsWith("rpg:") || ["rpg:rulebook", "rpg:ping", "rpg:diag"].includes(ev.id)) return;
    const p = ev.sourceEntity;
    if (!p || p.typeId !== "minecraft:player") return;
    try { runRpgAction(ev.id.slice(4), p, ev.message); }
    catch (error) { console.warn("[rpg/script-event] " + String(error)); }
  }));
  setGameplayStatus(errors.length ? "partial" : "ready", errors);
  console.warn("[rpg/gameplay] initialized; errors=" + errors.length);
  return { state: errors.length ? "partial" : "ready", errors };
}
