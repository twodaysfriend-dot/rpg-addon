import { system, EntityDamageCause } from "@minecraft/server";
import { CONFIG } from "../config.js";
import {
  getTargets, hurt, knockback, particle, sound, flatDir, isSolidAt, dist3, healthAlive,
} from "../core/util.js";
import { notify } from "../core/hud.js";
import { getLastHit } from "../core/tracking.js";
import { beginFrenzy } from "../core/frenzy.js";
import { forceWingsOn } from "../core/wings.js";

const THEMES = {
  blue: {
    main: "minecraft:blue_flame_particle",
    hit: "minecraft:critical_hit_emitter",
    slash: "rpg:sword_saint_slash",
    wave: "rpg:sword_saint_wave",
    draw: "rpg:sword_saint_draw",
  },
  red: {
    main: "minecraft:redstone_ore_dust_particle",
    hit: "minecraft:critical_hit_emitter",
    slash: "rpg:fallen_sword_saint_slash",
    wave: "rpg:fallen_sword_saint_wave",
    draw: "rpg:fallen_sword_saint_draw",
  },
};

function themeOf(job) {
  return THEMES[job.theme] ?? THEMES.blue;
}

// 앞으로 나아가는 에너지. 기본 공격과 '검기 방출'이 함께 사용합니다.
function travelWave(player, job, opt) {
  const th = themeOf(job);
  const dim = player.dimension;
  const { origin, dir } = opt;
  const side = { x: -dir.z, z: dir.x };
  const hit = new Set();
  let dist = 0;

  const id = system.runInterval(() => {
    dist += opt.speed;
    if (dist > opt.range) {
      system.clearRun(id);
      return;
    }
    const pos = { x: origin.x + dir.x * dist, y: origin.y, z: origin.z + dir.z * dist };

    // 벽에 닿으면 사라짐
    if (isSolidAt(dim, pos)) {
      particle(dim, th.hit, pos);
      system.clearRun(id);
      return;
    }

    // 검기 방출은 작은 불꽃 줄 대신 전용 초승달 참격이 전방으로 이동합니다.
    // 중앙 참격과 양옆의 잔상을 함께 생성해 넓은 검기 형태로 보이게 합니다.
    const lane = Math.min(0.85, Math.max(0.45, opt.width * 0.3));
    const waveOffsets = opt.waveOffsets ?? [-lane, 0, lane];
    const waveParticle = opt.waveParticle ?? th.wave;
    for (const offset of waveOffsets) {
      particle(dim, waveParticle, {
        x: pos.x + side.x * offset,
        y: pos.y + (offset === 0 ? 0 : 0.06),
        z: pos.z + side.z * offset,
      });
    }

    let stop = false;
    for (const t of getTargets(player, pos, opt.hitRadius, opt.bodyOffset ?? 0)) {
      if (hit.has(t.id)) continue;
      hit.add(t.id);
      hurt(t, player, opt.damage);
      knockback(t, dir.x, dir.z, opt.knockback, 0.3);
      const tl = t.location;
      particle(dim, th.hit, { x: tl.x, y: tl.y + 1, z: tl.z });
      if (opt.stopOnHit) stop = true;
    }
    if (stop) system.clearRun(id);
  }, 1);
}

// 휘두르면 나가는 푸른(타락 시 붉은) 에너지
export function fireBasic(player, job) {
  const th = themeOf(job);
  const dir = flatDir(player);
  const l = player.location;
  sound(player.dimension, "random.swish", l, { volume: 0.5, pitch: 1.25 });

  // 기본 공격은 휘두르는 순간의 참격만 표시합니다.
  // 평타마다 일직선으로 날아가던 작은 불꽃/에너지 입자는 생성하지 않습니다.
  particle(player.dimension, th.slash, {
    x: l.x + dir.x * 1.05,
    y: l.y + 1.15,
    z: l.z + dir.z * 1.05,
  });
}

function trail(dim, a, b, th) {
  const n = Math.min(20, Math.max(1, Math.floor(dist3(a, b) / 0.7)));
  for (let i = 0; i <= n; i++) {
    particle(dim, th.main, {
      x: a.x + ((b.x - a.x) * i) / n,
      y: a.y + 1 + ((b.y - a.y) * i) / n,
      z: a.z + ((b.z - a.z) * i) / n,
    });
  }
}

// 스킬 실행 함수. false 를 반환하면 발동 취소(마나/쿨타임 소모 없음).
export const RUNNERS = {
  // 1번: 360도 휘두르기
  sword_spin(player, job, def) {
    const th = themeOf(job);
    const dim = player.dimension;
    const c = player.location;

    for (const t of getTargets(player, { x: c.x, y: c.y + 1, z: c.z }, def.radius)) {
      hurt(t, player, def.damage);
      const tl = t.location;
      knockback(t, tl.x - c.x, tl.z - c.z, def.knockback, 0.4);
      particle(dim, th.hit, { x: tl.x, y: tl.y + 1, z: tl.z });
    }
    sound(dim, "item.trident.riptide_1", c, { volume: 0.8, pitch: 1.2 });

    // 한 바퀴 도는 궤적 연출
    const yaw = (player.getRotation().y * Math.PI) / 180;
    const steps = 8;
    let step = 0;
    const id = system.runInterval(() => {
      try {
        const p = player.location;
        for (let k = 0; k < 8; k++) {
          const a = yaw + ((step * 8 + k) / (steps * 8)) * Math.PI * 2;
          for (const r of [def.radius * 0.55, def.radius * 0.9]) {
            particle(dim, th.main, {
              x: p.x - Math.sin(a) * r,
              y: p.y + 1.0,
              z: p.z + Math.cos(a) * r,
            });
          }
        }
      } catch {
        system.clearRun(id);
        return;
      }
      if (++step >= steps) system.clearRun(id);
    }, 1);
  },

  // 2번: 검기를 전방으로 방출 (넓게, 관통)
  sword_wave(player, job, def) {
    const dir = flatDir(player);
    const l = player.location;
    sound(player.dimension, "mob.evocation_fangs.attack", l, { volume: 0.9, pitch: 1.0 });
    travelWave(player, job, {
      origin: { x: l.x + dir.x * 1.0, y: l.y + 0.9, z: l.z + dir.z * 1.0 },
      dir,
      speed: def.speed,
      range: def.range,
      width: def.width,
      hitRadius: def.hitRadius,
      damage: def.damage,
      knockback: def.knockback,
      stopOnHit: false,
    });
  },

  // 섬멸: 발도식 순간이동. 전방 15블록의 이동 경로에서 4블록 이내의
  // 공격 가능한 엔티티를 모두 베며, 각 엔티티는 한 번만 피해를 받습니다.
  sword_annihilation(player, job, def) {
    if (job.id !== "sword_saint") {
      notify(player, "§c섬멸은 검성 전용 스킬입니다.");
      return false;
    }

    const dim = player.dimension;
    const th = themeOf(job);
    const start = { ...player.location };
    const dir = flatDir(player); // 위/아래를 보아도 수평으로 15블록 이동
    const maxRange = def.range; // 15
    const radius = def.hitRadius; // 4
    const rot = player.getRotation();

    // 지나가는 구간과 도착 지점의 발/머리 공간을 모두 확인해 벽 속 순간이동을 방지.
    // 뚫고 지나갈 수 없는 블록이 있으면 마지막 안전 위치에서 멈춥니다.
    let safeDistance = 0;
    for (let d = 0.5; d <= maxRange + 0.001; d += 0.5) {
      const pos = { x: start.x + dir.x * d, y: start.y, z: start.z + dir.z * d };
      if (isSolidAt(dim, { x: pos.x, y: pos.y + 0.1, z: pos.z }) ||
          isSolidAt(dim, { x: pos.x, y: pos.y + 1.6, z: pos.z })) break;
      safeDistance = d;
    }
    if (safeDistance < 0.5) {
      notify(player, "§7앞이 막혀 섬멸을 사용할 수 없습니다.");
      return false;
    }

    const end = {
      x: start.x + dir.x * safeDistance,
      y: start.y,
      z: start.z + dir.z * safeDistance,
    };
    try {
      // 먼저 순간이동하고 그다음 이동 궤적에 피해를 적용합니다.
      player.teleport(end, { rotation: rot });
    } catch {
      notify(player, "§7섬멸 순간이동에 실패했습니다.");
      return false;
    }

    // 이동 경로에서 반경 4블록 이내인 엔티티만 선별합니다.
    // 중점 기준 한 번의 넓은 탐색 후 선분-점 거리를 정확하게 검사합니다.
    const half = safeDistance * 0.5;
    const mid = {
      x: start.x + dir.x * half,
      y: start.y + 0.9,
      z: start.z + dir.z * half,
    };
    const candidates = getTargets(player, mid, half + radius + 0.5, 0.9);
    const hit = new Set();
    for (const target of candidates) {
      try {
        if (hit.has(target.id)) continue;
        const p = target.location;
        const along = Math.max(0, Math.min(safeDistance,
          (p.x - start.x) * dir.x + (p.z - start.z) * dir.z));
        const dx = p.x - (start.x + dir.x * along);
        const dy = p.y - start.y;
        const dz = p.z - (start.z + dir.z * along);
        if (dx * dx + dy * dy + dz * dz > radius * radius) continue;
        hit.add(target.id);
        hurt(target, player, def.damage);
        knockback(target, dir.x, dir.z, def.knockback, 0.3);
        particle(dim, th.hit, { x: p.x, y: p.y + 1, z: p.z });
      } catch { /* 전투 도중 소멸한 엔티티 건너뜀 */ }
    }

    // 경로의 잔상은 순간이동 후 표시하며, 푸른색/붉은색 직업 테마를 유지.
    sound(dim, "mob.evocation_fangs.attack", end, { volume: 1.15, pitch: 0.82 });
    sound(dim, "random.swish", start, { volume: 1.0, pitch: 1.3 });
    const side = { x: -dir.z, z: dir.x };
    const steps = Math.ceil(safeDistance / 0.75);
    for (let i = 0; i <= steps; i++) {
      const d = safeDistance * i / steps;
      const center = { x: start.x + dir.x * d, y: start.y + 1, z: start.z + dir.z * d };
      particle(dim, th.main, center);
      if (i % 2 === 0) {
        for (const offset of [-radius * 0.65, radius * 0.65]) {
          particle(dim, th.draw, {
            x: center.x + side.x * offset,
            y: center.y,
            z: center.z + side.z * offset,
          });
        }
      }
    }
    return true;
  },

  // 발도: 레거시 저장 데이터 호환용 러너. 현재 직업 스킬 목록에서는 사용하지 않습니다.
  sword_draw(player, job, def) {
    const dim = player.dimension;
    const dir = flatDir(player);
    const l = player.location;
    const th = themeOf(job);
    sound(dim, "mob.evocation_fangs.attack", l, { volume: 1.05, pitch: 1.55 });
    particle(dim, th.draw, {
      x: l.x + dir.x * 1.15,
      y: l.y + 1.1,
      z: l.z + dir.z * 1.15,
    });
    travelWave(player, job, {
      origin: { x: l.x + dir.x * 1.1, y: l.y + 1.0, z: l.z + dir.z * 1.1 },
      dir,
      speed: def.speed,
      range: def.range,
      width: def.width,
      hitRadius: def.hitRadius,
      damage: def.damage,
      knockback: def.knockback,
      waveParticle: th.draw,
      waveOffsets: [-0.3, 0, 0.3],
      stopOnHit: false,
    });
  },

  // 타락검성 전용: 광분화. 날개를 자동 활성화하고 20초 동안 피해의 일정 비율을 흡혈합니다.
  fallen_sword_frenzy(player, job, def) {
    if (job.id !== "fallen_sword_saint") {
      notify(player, "§c광분화는 타락검성 전용 스킬입니다.");
      return false;
    }
    if (!forceWingsOn(player)) {
      notify(player, "§c타락한 날개를 활성화하지 못했습니다.");
      return false;
    }
    beginFrenzy(player, def.duration, def.lifesteal);
    sound(player.dimension, "mob.wither.spawn", player.location, { volume: 0.85, pitch: 0.75 });
    particle(player.dimension, "minecraft:soul_particle", { x: player.location.x, y: player.location.y + 1.0, z: player.location.z });
    return true;
  },

  // 궁극기. 가장 최근에 타격한 대상(주변 radius 안)에게 돌진해 hits 번 연속으로 베고,
  // 끝나면 원래 자리로 복귀
  sword_rush(player, job, def) {
    const th = themeOf(job);
    const dim = player.dimension;
    const origin = { ...player.location };
    const rot = player.getRotation();

    const target = getLastHit(player);
    if (!target || !healthAlive(target) || target.dimension.id !== dim.id ||
        dist3(target.location, origin) > def.radius) {
      notify(player, "§7최근에 타격한 대상이 주변에 없습니다. 먼저 공격하세요.");
      return false;
    }

    // 돌진하는 동안 받는 피해를 크게 줄임
    try {
      player.addEffect("resistance", def.hits * def.stepTicks + 20, {
        amplifier: 4,
        showParticles: false,
      });
    } catch {
      // 효과를 못 걸어도 스킬은 진행
    }

    let hitCount = 0;
    let tick = 0;
    let last = origin;

    const finish = () => {
      system.clearRun(id);
      try {
        trail(dim, last, origin, th);
        player.teleport(origin, { rotation: rot });
      } catch {
        // 플레이어가 사라진 경우
      }
    };

    const id = system.runInterval(() => {
      try {
        if (hitCount >= def.hits || !healthAlive(target)) {
          finish();
          return;
        }
        if (tick % def.stepTicks === 0) {
          const tl = target.location;
          // 대상 둘레를 돌며 매번 다른 방향에서 벤다
          const ang = hitCount * 2.4;
          let stand = { x: tl.x + Math.cos(ang) * 1.5, y: tl.y, z: tl.z + Math.sin(ang) * 1.5 };
          if (isSolidAt(dim, stand) || isSolidAt(dim, { x: stand.x, y: stand.y + 1, z: stand.z })) {
            stand = { x: tl.x, y: tl.y, z: tl.z };
          }
          trail(dim, last, stand, th);
          player.teleport(stand, { facingLocation: { x: tl.x, y: tl.y + 1, z: tl.z } });
          // 연속 타격이 무적 시간에 막히지 않도록 override 로 피해를 줌
          try {
            target.applyDamage(def.damage, { cause: EntityDamageCause.override, damagingEntity: player });
          } catch {
            hurt(target, player, def.damage);
          }
          knockback(target, tl.x - stand.x, tl.z - stand.z, 0.1, 0.05);
          particle(dim, th.hit, { x: tl.x, y: tl.y + 1, z: tl.z });
          sound(dim, "random.explode", tl, { volume: 0.4, pitch: 1.4 + hitCount * 0.05 });
          last = stand;
          hitCount++;
        }
        tick++;
      } catch {
        finish();
      }
    }, 1);
  },
};
