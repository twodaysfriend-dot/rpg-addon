import fs from 'node:fs';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {ARMOR_SETS} from '../RPG_BP_v0638/scripts/data/equipment.js';
const root=path.resolve(process.argv[2]??path.join(path.dirname(fileURLToPath(import.meta.url)),'..'));
const read=rel=>JSON.parse(fs.readFileSync(path.join(root,rel),'utf8'));
const previous={cyclops_boss:[2.45,5.75],rock_golem_boss:[1.7,3.5],elite_mantis:[2.05,4.2],deathworm:[14.4,17.4],elite_scorpion:[2.65,3.5],tech_block_golem_boss:[5.1,7.5],scorpion:[2.25,2.6],elite_deathworm:[15.6,18.6],hydra_boss:[10.5,15.9],mantis:[1.65,3.25]};
for(const [id,[width,height]] of Object.entries(previous)){
 const c=read('RPG_BP_v0638/entities/'+id+'.json')['minecraft:entity'].components;
 assert.ok(Math.abs(c['minecraft:collision_box'].width-width*1.2)<1e-8);
 assert.ok(Math.abs(c['minecraft:collision_box'].height-height*1.2)<1e-8);
 assert.equal(c['minecraft:behavior.melee_attack'],undefined);
 assert.equal(c['minecraft:behavior.melee_box_attack'].horizontal_reach,.8);
}
const e=read('RPG_BP_v0638/entities/player.json')['minecraft:entity'];
function matches(f,s){
 if(f.all_of&&!f.all_of.every(x=>matches(x,s)))return false;
 if(f.any_of&&!f.any_of.some(x=>matches(x,s)))return false;
 if(f.none_of&&f.none_of.some(x=>matches(x,s)))return false;
 if(!f.test)return true;
 let v;
 if(f.test==='has_tag')v=f.subject==='self'?s.tags.has(f.value):s.owned&&f.value==='rpg_player_owned';
 else if(f.test==='bool_property')v=s[f.domain]===f.value;
 else if(f.test==='is_family')v=f.value==='monster'?s.monster:f.value==='player'?s.player:false;
 else if(f.test==='has_damage')v=f.value==='fatal'?s.fatal:s.cause===f.value;
 else throw Error(f.test);
 return f.operator==='!='?!v:!!v;
}
const profiles=[[0,0],...[1,2,3].flatMap(n=>Array.from({length:n*2+1},(_,o)=>[n,o])),[4,8]];
let cases=0;
for(const [name,c] of [['base',e.components],...Object.entries(e.component_groups)]){
 const sensor=c['minecraft:damage_sensor'];if(!sensor)continue;
 const ward=name==='base'?1:1-Number(name.split('_').at(-1))/10*.0035;
 for(const [n,o] of profiles)for(const monster of [false,true])for(const player of [false,true])for(const owned of [false,true])for(const undead of [false,true])for(const sun of [false,true])for(const armed of [false,true])for(const fatal of [false,true]){
  const tags=new Set([...(n?['rpg_abyssal_active','rpg_abyssal_'+(n*9+o)]:[]),...(undead?['rpg_undead']:[]),...(sun?['rpg_vampire_sun']:[])]);
  const state={monster,player,owned,fatal,tags,cause:'entity_attack','rpg:resurrection_armed':armed,'rpg:resurrection_pending':false};
  const hits=sensor.triggers.filter(t=>t.cause==='all'&&matches(t.on_damage.filters,state));
  assert.equal(hits.length,1,JSON.stringify({name,n,o,monster,player,owned,undead,sun,armed,fatal}));
  if(monster&&!player&&!owned&&armed&&fatal){assert.equal(hits[0].deals_damage,false);}else{
   const race=(sun?1.5:1)*(monster&&undead?.7:1);
   assert.ok(Math.abs(hits[0].damage_multiplier-ward*race*(1-o*.04)*(1-n*.04))<1e-9);
  }
  cases++;
 }
}
for(let n=0;n<=4;n++)assert.equal(e.component_groups['rpg:abyssal_knockback_'+n]['minecraft:knockback_resistance'].value,n/5);
for(const [i,part] of ['helmet','chestplate','leggings','boots'].entries()){
 const c=read('RPG_BP_v0638/items/abyssal_'+part+'.json')['minecraft:item'].components;
 assert.equal(c['minecraft:wearable'].protection,[5,10,8,5][i]);assert.equal(c['minecraft:enchantable'].value,15);
}
assert.deepEqual(ARMOR_SETS.abyssal.protection,[5,10,8,5]);
console.log(`Large mobs: 10 hitboxes +20%, iron-golem edge reach .8; ${cases} native armor/race/ward/resurrection cases, item protections and enchantability passed`);
