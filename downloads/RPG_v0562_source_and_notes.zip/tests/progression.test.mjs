import test from 'node:test';
import assert from 'node:assert/strict';
import {player,ItemStack,world,events} from './minecraftMock.mjs';
import {JOBS} from '../RPG_BP_v0562/scripts/data/jobs.js';
import {SKILLS} from '../RPG_BP_v0562/scripts/data/skills.js';
import {JOB_TRIALS} from '../RPG_BP_v0562/scripts/data/jobTrials.js';
import {getSkills,setSkills,getProgress,resetCooldowns} from '../RPG_BP_v0562/scripts/core/playerData.js';
import {gainRpgXp,forceSetLevel,xpForNext,unspentPoints,allocateStat} from '../RPG_BP_v0562/scripts/core/stats.js';
import {CHAMELEON_KEY,SKILLBOOK_ID,CHAMELEON_ALLOWED,learningRule,isUltimate,purchaseChameleonSkill,readChameleonProgress,syncChameleonLoadout,remainingSkillUses,executeChameleonSkill,rechargeSkill,awardChameleonLevels,deliverSkillBooks,useRandomSkillBook,skillBookItemUse} from '../RPG_BP_v0562/scripts/core/chameleonProgress.js';
import {jobTrialStatus,recordJobTrialKill} from '../RPG_BP_v0562/scripts/core/jobTrials.js';
import {saveTemple} from '../RPG_BP_v0562/scripts/core/templeAccess.js';
import {checkAdvance} from '../RPG_BP_v0562/scripts/core/advance.js';
import {vanillaRuneChance,rollVanillaRune,registerRuneDrops} from '../RPG_BP_v0562/scripts/core/runeDrops.js';
function cham(id='c',level=30){const p=player(id,level);p.setDynamicProperty('rpg:job','chameleon');setSkills(p,[...JOBS.chameleon.skills]);return p;}
function setProgress(p,value){p.setDynamicProperty('rpg:progress',JSON.stringify(value));}
function countBooks(p){return p.slots.reduce((n,t)=>n+(t?.typeId===SKILLBOOK_ID?t.amount:0),0);}
test('all 29 implemented jobs have trials and every learnable skill exists',()=>{
  const jobs=Object.values(JOBS).filter(j=>!j.placeholder&&j.id!=='apprentice');
  assert.equal(jobs.length,30);assert.deepEqual(new Set(jobs.filter(j=>j.id!=='hacker').map(j=>j.id)),new Set(Object.keys(JOB_TRIALS)));
  for(const id of CHAMELEON_ALLOWED)assert.ok(SKILLS[id],id);
  for(const id of ['sword_rush','fist_finale','archer_heavenly','fallen_end','sage_zoltraak','beast_grand_explosion','dragon_domain'])assert.equal(isUltimate(id),true,id);
});
test('chosen skills spend the same SP pool as stats, with no duplicate debit',()=>{
  const p=cham('sp',10);assert.equal(unspentPoints(p),27);
  assert.equal(purchaseChameleonSkill(p,'sword_spin').ok,true);assert.equal(unspentPoints(p),24);
  assert.equal(purchaseChameleonSkill(p,'sword_spin').ok,false);assert.equal(unspentPoints(p),24);
  assert.equal(purchaseChameleonSkill(p,'sword_annihilation').ok,true);assert.equal(unspentPoints(p),15);
  assert.equal(purchaseChameleonSkill(p,'sword_rush').ok,true);assert.equal(unspentPoints(p),0);
  assert.equal(allocateStat(p,'str',1).ok,false);assert.equal(purchaseChameleonSkill(p,'mage_fireball').ok,false);
});
test('normal skills unlimited; important start 10 and ultimate/copy start 3',()=>{
  assert.deepEqual(learningRule('sword_spin'),{cost:3,uses:null,diamondUses:0});
  assert.deepEqual(learningRule('sword_annihilation'),{cost:9,uses:10,diamondUses:5});
  assert.deepEqual(learningRule('hacker_copy'),{cost:15,uses:3,diamondUses:1});
  assert.deepEqual(learningRule('sword_rush'),{cost:15,uses:3,diamondUses:1});
});
test('limited successful casts exhaust and cooldown resets never restore uses',()=>{
  const p=cham('casts');purchaseChameleonSkill(p,'sword_rush');let casts=0;
  for(let i=0;i<3;i++)assert.equal(executeChameleonSkill(p,'sword_rush',()=>{casts++;return true;}).ok,true);
  resetCooldowns(p);assert.equal(executeChameleonSkill(p,'sword_rush',()=>casts++).ok,false);
  assert.equal(casts,3);assert.equal(remainingSkillUses(p,'sword_rush'),0);
});
test('rejected or throwing runner refunds only that attempt, native jobs unaffected',()=>{
  const p=cham('refund');purchaseChameleonSkill(p,'sword_annihilation');
  assert.equal(executeChameleonSkill(p,'sword_annihilation',()=>false).result,false);assert.equal(remainingSkillUses(p,'sword_annihilation'),10);
  assert.equal(executeChameleonSkill(p,'sword_annihilation',()=>{throw Error('no target');}).ok,false);assert.equal(remainingSkillUses(p,'sword_annihilation'),10);
  p.setDynamicProperty('rpg:job','sword_saint');executeChameleonSkill(p,'sword_annihilation',()=>true);assert.equal(remainingSkillUses(p,'sword_annihilation'),10);
});
test('diamonds charge the selected skill across stacks and persist on rejoin',()=>{
  const p=cham('diamond');purchaseChameleonSkill(p,'sword_annihilation');purchaseChameleonSkill(p,'sword_rush');
  p.slots[2]=new ItemStack('minecraft:diamond',2);p.slots[5]=new ItemStack('minecraft:diamond',4);
  assert.equal(rechargeSkill(p,'sword_annihilation',5).ok,true);assert.equal(p.slots[2],undefined);assert.equal(p.slots[5].amount,1);
  assert.equal(remainingSkillUses(p,'sword_annihilation'),35);assert.equal(remainingSkillUses(p,'sword_rush'),3);
  assert.equal(rechargeSkill(p,'sword_rush',1).ok,true);assert.equal(remainingSkillUses(p,'sword_rush'),4);
  assert.equal(rechargeSkill(p,'sword_rush',1).ok,false);
  const reload=cham('reload');reload.setDynamicProperty(CHAMELEON_KEY,p.getDynamicProperty(CHAMELEON_KEY));syncChameleonLoadout(reload);
  assert.ok(getSkills(reload).includes('sword_annihilation'));assert.equal(remainingSkillUses(reload,'sword_annihilation'),35);assert.equal(remainingSkillUses(reload,'sword_rush'),4);
});
test('SP learning failure rolls back learned state and charges',()=>{
  const p=cham('learnfail'),write=p.setDynamicProperty.bind(p);let fail=true;
  p.setDynamicProperty=(key,value)=>{if(fail&&key==='rpg:skills'){fail=false;throw Error('storage');}write(key,value);};
  assert.equal(purchaseChameleonSkill(p,'sword_rush').ok,false);assert.equal(unspentPoints(p),87);assert.equal(getSkills(p).includes('sword_rush'),false);assert.equal(readChameleonProgress(p).learned.length,0);
});
test('diamond storage failure restores diamonds and exact charge count',()=>{
  const p=cham('chargefail');purchaseChameleonSkill(p,'sword_rush');p.slots[5]=new ItemStack('minecraft:diamond',3);
  const before=p.getDynamicProperty(CHAMELEON_KEY),write=p.setDynamicProperty.bind(p);let fail=true;
  p.setDynamicProperty=(key,value)=>{if(fail&&key===CHAMELEON_KEY){fail=false;throw Error('storage');}write(key,value);};
  assert.equal(rechargeSkill(p,'sword_rush',3).ok,false);assert.equal(p.slots[5].amount,3);assert.equal(p.getDynamicProperty(CHAMELEON_KEY),before);
});
test('five actual Chameleon level gains give one book; force level gives none',()=>{
  const p=cham('levels',25);let xp=0;for(let lv=25;lv<30;lv++)xp+=xpForNext(lv);
  gainRpgXp(p,xp);assert.equal(countBooks(p),1);assert.equal(readChameleonProgress(p).levelsToBook,0);
  forceSetLevel(p,50);assert.equal(countBooks(p),1);
  p.setDynamicProperty('rpg:job','swordsman');awardChameleonLevels(p,10);assert.equal(countBooks(p),1);
});
test('full inventory holds pending books, later delivery cannot duplicate',()=>{
  const p=cham('full');p.slots.fill(new ItemStack('minecraft:stone',64));awardChameleonLevels(p,12);
  assert.equal(countBooks(p),0);assert.equal(readChameleonProgress(p).pendingBooks,2);assert.equal(readChameleonProgress(p).levelsToBook,2);
  p.slots[10]=undefined;assert.equal(deliverSkillBooks(p),2);assert.equal(deliverSkillBooks(p),0);assert.equal(countBooks(p),2);
});
test('book learns unknown non-ultimate for free, including limited important skills',()=>{
  const p=cham('book');p.slots[4]=new ItemStack(SKILLBOOK_ID,2);
  const pool=CHAMELEON_ALLOWED.filter(id=>!isUltimate(id)&&!getSkills(p).includes(id)),index=pool.indexOf('sword_annihilation');assert.ok(index>=0);
  assert.equal(useRandomSkillBook(p,()=>(index+.1)/pool.length).id,'sword_annihilation');
  assert.equal(readChameleonProgress(p).spentSp,0);assert.equal(remainingSkillUses(p,'sword_annihilation'),10);assert.equal(p.slots[4].amount,1);
  const other=useRandomSkillBook(p,()=>0);assert.equal(other.ok,true);assert.notEqual(other.id,'sword_annihilation');assert.equal(isUltimate(other.id),false);assert.equal(p.slots[4],undefined);
});
test('books preserved for wrong job, full skill collection and invalid RNG',()=>{
  const p=cham('invalidbook');p.slots[2]=new ItemStack(SKILLBOOK_ID,3);
  assert.equal(useRandomSkillBook(p,()=>1).ok,false);assert.equal(p.slots[2].amount,3);
  p.setDynamicProperty('rpg:job','hacker');assert.equal(useRandomSkillBook(p).ok,false);assert.equal(p.slots[2].amount,3);
  p.setDynamicProperty('rpg:job','chameleon');setSkills(p,[...CHAMELEON_ALLOWED]);assert.equal(useRandomSkillBook(p).ok,false);assert.equal(p.slots[2].amount,3);
});
test('duplicate same-tick book item events consume a single book',()=>{
  const p=cham('double');p.slots[2]=new ItemStack(SKILLBOOK_ID,3);skillBookItemUse(p,100);skillBookItemUse(p,100);assert.equal(p.slots[2].amount,2);
});
test('trial kill credit excludes animals, villagers, dummy, players and creative',()=>{
  const p=player('trial',20);p.setDynamicProperty('rpg:job','swordsman');
  for(const id of ['minecraft:cow','minecraft:villager','minecraft:player','rpg:sandbag_entity'])recordJobTrialKill(p,{typeId:id});assert.deepEqual(getProgress(p),{});
  p.getGameMode=()=> 'creative';recordJobTrialKill(p,{typeId:'minecraft:zombie'});assert.deepEqual(getProgress(p),{});
});
test('trials credit line, elite, bosses, types and time/dimension independently',()=>{
  const p=player('credit',25);p.setDynamicProperty('rpg:job','swordsman');
  for(const id of ['rpg:elite_red_goblin','rpg:rock_golem_boss','rpg:rock_golem_boss','minecraft:zombie'])recordJobTrialKill(p,{typeId:id});
  let s=getProgress(p);assert.equal(s.job_kills,4);assert.equal(s.line_sword,4);assert.equal(s.job_boss,2);assert.equal(s.job_elite,1);assert.equal(s.job_unique,3);assert.equal(s.job_undead,1);assert.equal(s.job_day,4);
  const time=world.getTimeOfDay;world.getTimeOfDay=()=>18000;recordJobTrialKill(p,{typeId:'minecraft:drowned'});world.getTimeOfDay=time;
  p.dimension.id='minecraft:nether';recordJobTrialKill(p,{typeId:'minecraft:blaze'});s=getProgress(p);assert.equal(s.job_night,1);assert.equal(s.job_nether,1);assert.equal(s.job_drowned,1);assert.equal(s.job_blaze,1);
});
test('normal upgrades require both parent and every designed condition',()=>{
  const p=player('advance',20);p.setDynamicProperty('rpg:job','swordsman');setProgress(p,{line_sword:80});
  assert.equal(checkAdvance(p,JOBS.sword_saint).ok,false);setProgress(p,{line_sword:80,job_boss:1});assert.equal(checkAdvance(p,JOBS.sword_saint).ok,true);
  p.setDynamicProperty('rpg:job','mage');assert.equal(checkAdvance(p,JOBS.sword_saint).ok,false);
  p.setDynamicProperty('rpg:job','swordsman');p.setDynamicProperty('rpg:rpg_level',19);assert.equal(checkAdvance(p,JOBS.sword_saint).ok,false);
});
test('holy trials support either actual healing or solo undead kills',()=>{
  const p=player('holy',20);p.setDynamicProperty('rpg:job','cleric');
  setProgress(p,{job_undead:30});assert.equal(checkAdvance(p,JOBS.angel).ok,true);
  setProgress(p,{job_healing:300});assert.equal(checkAdvance(p,JOBS.angel).ok,true);
  setProgress(p,{job_healing:299,job_undead:29});assert.equal(checkAdvance(p,JOBS.angel).ok,false);
  p.setDynamicProperty('rpg:job','angel');p.setDynamicProperty('rpg:rpg_level',40);setProgress(p,{job_healing:1500});assert.equal(checkAdvance(p,JOBS.michael).ok,false);
  setProgress(p,{light_michael:192});assert.equal(checkAdvance(p,JOBS.michael).ok,true);
});
test('uploaded hidden progression requires its revised milestones and matching parent',()=>{
  const p=player('hidden',25);setProgress(p,{job_elite:20,job_boss:2,job_unique:8});assert.equal(checkAdvance(p,JOBS.chameleon).ok,false);
  p.setDynamicProperty('rpg:job','swordsman');setProgress(p,{cham_jobs:3,cham_waived:1,cham_found:1});assert.equal(checkAdvance(p,JOBS.chameleon).ok,true);
  setProgress(p,{job_elite:20,job_boss:2,job_unique:7});assert.equal(checkAdvance(p,JOBS.chameleon).ok,false);
  p.setDynamicProperty('rpg:rpg_level',30);setProgress(p,{assassin_ambush:50});assert.equal(checkAdvance(p,JOBS.shadow_assassin).ok,false);
  p.setDynamicProperty('rpg:job','assassin');assert.equal(checkAdvance(p,JOBS.shadow_assassin).ok,true);
});
test('all new trials reject a blank character and accept fully satisfied matching parent',()=>{
  for(const [id,rule] of Object.entries(JOB_TRIALS)){
    if(rule.starter)continue;
    const p=player('all-'+id,rule.level),target=JOBS[id];p.setDynamicProperty('rpg:job',rule.allowedFrom?.[0]??(rule.fromApprentice?'apprentice':target.parent??'swordsman'));assert.equal(jobTrialStatus(p,target).met,false,id);
    const oldTime=world.getTimeOfDay,oldDim=world.getDimension;
    if(rule.shrine){saveTemple({dimId:'minecraft:overworld',x:0,y:62,z:0,status:'ready',writes:1});p.location={x:rule.shrine==='sun'?-7:7,y:64,z:0};world.getTimeOfDay=()=>rule.shrine==='sun'?1000:13000;world.getDimension=()=>({getBlock:at=>({typeId:at.y===63?(at.x<0?'minecraft:gold_block':'minecraft:amethyst_block'):'minecraft:sea_lantern'})});}
    setProgress(p,Object.fromEntries([...(rule.all??[]),...(rule.any??[])].map(c=>[c.key,c.need])));assert.equal(checkAdvance(p,target).ok,true,id);
    if(rule.shrine){saveTemple(undefined);world.getTimeOfDay=oldTime;world.getDimension=oldDim;}
  }
});
test('vanilla drops meet exact 1%/30% boundaries and skip addon/dummy/animals',()=>{
  assert.equal(vanillaRuneChance('minecraft:zombie'),.01);assert.equal(vanillaRuneChance('minecraft:wither'),.30);
  assert.equal(rollVanillaRune('minecraft:zombie',()=>.0099),'rpg:rune_power');assert.equal(rollVanillaRune('minecraft:zombie',()=>.01),undefined);
  assert.ok(rollVanillaRune('minecraft:ender_dragon',()=>.2999));assert.equal(rollVanillaRune('minecraft:ender_dragon',()=>.30),undefined);
  for(const id of ['rpg:red_goblin','rpg:elite_red_goblin','rpg:hydra_boss','minecraft:player','minecraft:cow'])assert.equal(vanillaRuneChance(id),0);
  let tick=0;assert.equal(rollVanillaRune('minecraft:zombie',()=>tick++===0?0:.9999),'rpg:rune_absorption');
});
test('vanilla death handler spawns exactly one physical rune without touching original loot',()=>{
  const before=events.entityDie.listeners.length;registerRuneDrops();const spawned=[],old=Math.random;Math.random=()=>0;
  try{events.entityDie.listeners[before]({deadEntity:{typeId:'minecraft:wither',location:{x:1,y:2,z:3},dimension:{spawnItem:(t,l)=>spawned.push({t,l})}}});}
  finally{Math.random=old;}assert.equal(spawned.length,1);assert.equal(spawned[0].t.typeId,'rpg:rune_power');assert.equal(spawned[0].t.amount,1);
});
