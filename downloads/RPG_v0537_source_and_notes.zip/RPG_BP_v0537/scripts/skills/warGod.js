import {world,system,EntityDamageCause} from '@minecraft/server';
import {getTargets,flatDir,isSolidAt,knockback,particle,sound,heldItemId} from '../core/util.js';
import {skillDamageFor} from '../core/stats.js';
import {scriptedHit,currentScriptHit,rememberScriptKiller,noteManualDamage,setBasicHitHandler,BLACK_FLASH_KEY} from '../core/combatContext.js';
import {healLifesteal} from '../core/lifesteal.js';
import {areAllies} from '../core/social.js';
import {CONFIG} from '../config.js';
import {notify} from '../core/hud.js';
export {BLACK_FLASH_KEY};
function valid(p,t){return t&&t.id!==p.id&&!areAllies(p,t)&&!['minecraft:armor_stand','minecraft:item','minecraft:xp_orb'].includes(t.typeId)&&(!t.typeId.startsWith('rpg:hito_'))&&(t.typeId!=='minecraft:player'||(CONFIG.pvp&&!['creative','spectator'].includes(String(t.getGameMode?.()).toLowerCase())));}
function cone(p,def){
 const origin=p.location,dir=flatDir(p);return getTargets(p,{x:origin.x,y:origin.y+1,z:origin.z},def.range+1,.9).filter(t=>{
  if(!valid(p,t))return false;const dx=t.location.x-origin.x,dz=t.location.z-origin.z,along=dx*dir.x+dz*dir.z,side=Math.abs(dx*dir.z-dz*dir.x);
  if(along<0||along>def.range||side>def.width||Math.abs(t.location.y-origin.y)>3)return false;
  for(let step=.5;step<Math.hypot(dx,dz);step+=.5){const distance=Math.hypot(dx,dz)||1;if(isSolidAt(p.dimension,{x:origin.x+dx/distance*step,y:origin.y+1,z:origin.z+dz/distance*step}))return false;}
  return true;
 }).slice(0,8);
}
function hit(p,t,damage){
 return scriptedHit(t,p,()=>{
  const amount=skillDamageFor(p,damage,'physical');
  try{if(t.applyDamage(amount,{cause:EntityDamageCause.override,damagingEntity:p})!==false)return true;}catch{}
  const hp=t.getComponent('minecraft:health');if(!hp||hp.currentValue<=0)return false;
  if(amount>=hp.currentValue)rememberScriptKiller(p,t);const before=hp.currentValue;hp.setCurrentValue(Math.max(0,before-amount));noteManualDamage(p,t,Math.min(before,amount));return true;
 });
}
function impact(p,t,kick){
 const at={x:t.location.x,y:t.location.y+1,z:t.location.z};particle(p.dimension,'minecraft:critical_hit_emitter',at);particle(p.dimension,'minecraft:redstone_ore_dust_particle',at);sound(p.dimension,'mob.irongolem.hit',at,{volume:.6,pitch:kick ? 0.7 : 1.1});
}
function attack(p,j,d){
 const targets=cone(p,d);if(!targets.length){notify(p,'§7전방에 공격할 적이 없습니다.');return false;}
 const originDimension=p.dimension.id;let i=0;
 const pulse=()=>{
  if(!p.isValid||p.dimension.id!==originDimension||!(p.getComponent('minecraft:health')?.currentValue>0))return;
  for(const t of cone(p,d)){if(hit(p,t,d.damagePerHit)){impact(p,t,d.kick);if(i===d.hits-1){const direction=flatDir(p);knockback(t,direction.x,direction.z,d.kick?2.1:1.1,.2);try{t.addEffect('slowness',d.kick?20:10,{amplifier:1,showParticles:false});}catch{}}}}
  i++;
 };
 pulse();for(let n=1;n<d.hits;n++)system.runTimeout(pulse,n*d.interval);return true;
}
export function armBlackFlash(p){
 if(p.getDynamicProperty(BLACK_FLASH_KEY)===true){notify(p,'§7이미 천멸격이 준비되어 있습니다.');return false;}
 p.setDynamicProperty(BLACK_FLASH_KEY,true);notify(p,'§c천멸격 준비 · 다음 평타 ×10');sound(p.dimension,'mob.wither.spawn',p.location,{volume:.5,pitch:1.8});return true;
}
export function applyBlackFlash(ev,scripted=false){
 const p=ev.damageSource?.damagingEntity,t=ev.hurtEntity;
 if(p?.typeId!=='minecraft:player'||ev.damageSource.cause!==EntityDamageCause.entityAttack||p.getDynamicProperty(BLACK_FLASH_KEY)!==true||scripted||currentScriptHit(p,t)||!valid(p,t)||!(ev.damage>0))return;
 p.setDynamicProperty(BLACK_FLASH_KEY,undefined);
 // The first hit has already received armor/resistance. Add nine copies of that
 // effective damage without a second armor pass or Bedrock invulnerability loss.
 const hp=t.getComponent('minecraft:health');if(hp?.currentValue>0){const before=hp.currentValue,bonus=Math.min(before,ev.damage*9);if(bonus>=before)rememberScriptKiller(p,t);hp.setCurrentValue(Math.max(0,before-bonus));healLifesteal(p,t,bonus);}
 impact(p,t,true);particle(p.dimension,'minecraft:large_explosion',{x:t.location.x,y:t.location.y+1,z:t.location.z});notify(p,'§4천멸격! §f평타 ×10');
}
export const RUNNERS={war_god_punch:attack,war_god_flurry:attack,war_god_kick:attack,war_god_kick_flurry:attack,war_god_black_flash:armBlackFlash};
let registered=false;export function registerWarGod(){if(registered)return;registered=true;setBasicHitHandler(applyBlackFlash);}
