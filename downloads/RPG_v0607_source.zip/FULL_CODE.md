# RPG v0.6.7 변경 파일 전체 코드

## RPG_BP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon BP v0.6.7",
    "description": "RPG v0.6.7 · 룬 장착 슬롯 강화 해금 · 기본 3개에서 최대 5개",
    "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
    "version": [
      0,
      6,
      7
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "data",
      "uuid": "cc5d6e3c-5285-4787-8a59-a8e2856f2aec",
      "version": [
        0,
        6,
        7
      ]
    },
    {
      "type": "script",
      "language": "javascript",
      "uuid": "c41fa3d6-d82c-4a54-9783-68f92fe633a1",
      "entry": "scripts/gameplayEntry.js",
      "version": [
        0,
        6,
        7
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
      "version": [
        0,
        6,
        7
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    },
    {
      "module_name": "@minecraft/server-ui",
      "version": "2.0.0"
    }
  ]
}

```

## RPG_BP_v0603/scripts/core/equipment.js

```js
import {itemGrade,ARMOR_GRADE_HP} from '../data/grades.js';
import {rarityBadge,armorRarity} from '../data/rarity.js';
import { world, system, EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { ARMOR_SETS, RUNES, RUNE_KEY, armorInfo } from '../data/equipment.js';
import { showForm } from './skillMenu.js';
import { RUNE_LEVEL_KEY, upgradeLevel, upgradedRune } from '../data/upgrades.js';
import { openUpgradeMenu } from './upgrades.js';
import { openCraftingGuide } from './crafting.js';
import { equippedRunes, migrateChestRune, migrateRetiredRunes } from './runeInventory.js';
import { openRuneMenu } from './runeMenu.js';

const neutral = () => ({physical:1, magic:1, health:0, defense:0, manaRegen:0, manaRegenPercent:0, ward:false, speed:false, lifesteal:0, wardAmplifier:0, speedAmplifier:0, auras:{}});
export function getEquipmentBonuses(player) {
  const result = neutral();
  try {
    const eq = player.getComponent('minecraft:equippable');
    if (!eq) return result;
    const items = [EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet].map(slot=>eq.getEquipment(slot));
    const parts = ['helmet','chestplate','leggings','boots'];
    for (let i=0;i<items.length;i++) if (armorInfo(items[i]?.typeId)?.part === parts[i]) result.health += upgradeLevel(items[i],'armor')+ARMOR_GRADE_HP[itemGrade(items[i])];
    for (const [set, data] of Object.entries(ARMOR_SETS)) {
      if (!items.every((item,i)=>item?.typeId===`rpg:${set}_${parts[i]}`)) continue;
      result.ward ||= data.ward===true;
      result.physical *= data.physical ?? 1;
      result.magic *= data.magic ?? 1;
      result.health += data.health ?? 0;
      result.manaRegen += data.manaRegen ?? 0;
    }
    for(const stored of equippedRunes(player)) {
      const rune=upgradedRune(RUNES[stored.id],stored.level,stored.grade);
      result.physical*=rune.physical??1;result.magic*=rune.magic??1;
      result.health+=rune.health??0;result.defense+=rune.defense??0;result.manaRegen+=rune.manaRegen??0;result.manaRegenPercent+=rune.manaRegenPercent??0;
      result.lifesteal=Math.max(result.lifesteal,rune.lifesteal??0);
      result.ward ||= rune.ward===true;result.speed ||= rune.speed===true;
      result.wardAmplifier=Math.max(result.wardAmplifier,rune.wardAmplifier??0);
      result.speedAmplifier=Math.max(result.speedAmplifier,rune.speedAmplifier??0);
      for(const [eid,amp] of Object.entries(rune.auras??{}))result.auras[eid]=Math.max(result.auras[eid]??-1,amp);
    }
  } catch { return neutral(); }
  return result;
}

export async function openEquipmentMenu(player) {
  try {
    const form=new ActionFormData().title('RPG 장비').body('룬은 기본 3개를 장착하며, 장착 슬롯 강화를 통해 최대 5개까지 해금합니다. 같은 종류는 하나만 장착할 수 있습니다.\n'+Object.entries(ARMOR_SETS).map(([id,s])=>rarityBadge(armorRarity(id))+' '+s.name+': '+s.description).join('\n'))
      .button('룬 보관함 · 장착').button('강화 메뉴 · 룬 / 갑옷 / 무기').button('획득·제작 도감').button('닫기');
    const res=await showForm(form,player);if(!res||res.canceled)return;
    if(res.selection===0)await openRuneMenu(player);
    else if(res.selection===1)await openUpgradeMenu(player);
    else if(res.selection===2)await openCraftingGuide(player);
  }catch(error){try{player.sendMessage('§c[RPG] '+String(error));}catch{}}
}

function refreshAura(player, id, amplifier=0) {
  const effect = player.getEffect(id);
  if (!effect || effect.amplifier < amplifier || (effect.amplifier === amplifier && effect.duration < 60)) player.addEffect(id,60,{amplifier,showParticles:false});
}
export function registerEquipment() {
  system.runInterval(()=>{
    for (const player of world.getAllPlayers()) {
      try {
        migrateRetiredRunes(player);
        migrateChestRune(player);
        const bonuses = getEquipmentBonuses(player);
        if (bonuses.ward) refreshAura(player,'resistance',bonuses.wardAmplifier);
        if (bonuses.speed) refreshAura(player,'speed',bonuses.speedAmplifier);
        for (const [eid,amp] of Object.entries(bonuses.auras??{})) refreshAura(player,eid,amp);
      } catch {}
    }
  },20);

}

```

## RPG_BP_v0603/scripts/core/rpgKnowledge.js

```js
import {dungeonMonsterLevel} from '../data/monsterLevels.js';
import {PROMOTION_RATES,GRADE_MULTIPLIERS,ARMOR_GRADE_HP} from '../data/grades.js';
import {RARITIES,itemRarity,runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {skillScalingInfo} from '../data/skillScaling.js';
import {isBalanceQuestion,isHiddenPromotionQuestion} from './assistantPolicy.js';
import {JOBS,APPRENTICE_SKILLS} from '../data/jobs.js';
import {SKILLS} from '../data/skills.js';
import {LINE_NOTES,SKILL_NOTES} from '../data/skillGuide.js';
import {JOB_TRIALS} from '../data/jobTrials.js';
import {CRAFTING_RECIPES} from '../data/crafting.js';
import {RUNES,ARMOR_SETS} from '../data/equipment.js';
import {upgradedRune,RUNE_MAX,ARMOR_MAX,MAX_CATALYSTS,upgradeCost,enhancementRates} from '../data/upgrades.js';
import {DUNGEON,DUNGEON_TIERS,clearRewardForTier,netheriteChanceForTier} from '../data/dungeons.js';
import {CONFIG} from '../config.js';
import {defaultDamageTypeFor} from './stats.js';
export const QUESTION_LIMIT=200;
export const UNKNOWN_ANSWER='이 애드온의 직업·스킬·룬·갑옷·제작·강화·던전·성장 정보만 안내합니다. 도감에 없는 내용은 확인할 수 없습니다. 예: 월룡륜미 범위 / 검사 전직 / 생명의 룬 / 샌드백 제작';
export const normalizeQuestion=s=>String(s??'').normalize('NFKC').toLowerCase().replace(/§./g,'').replace(/[^a-z0-9가-힣]/g,'');
const clean=s=>String(s??'').replace(/§./g,'').replace(/[\u0000-\u0008\u000b-\u001f]/g,'');
const bossName=id=>({rock_golem_boss:'바위 골렘',cyclops_boss:'외눈 거인',hydra_boss:'히드라',tech_block_golem_boss:'마공학 골렘'}[id]??'던전 보스');
const percent=n=>Number((n*100).toFixed(3))+'%';
function runeEffects(r){
 const a=[];if(r.physical)a.push('물리 피해 +'+percent(r.physical-1));if(r.magic)a.push('마법 피해 +'+percent(r.magic-1));
 if(r.defense)a.push('RPG 방어력 +'+Number(r.defense.toFixed(1))+' (피해 감소 '+percent(r.defense*.0035)+')');if(r.health)a.push('최대 HP +'+r.health);if(r.manaRegenPercent)a.push('초당 최대 MP의 '+percent(r.manaRegenPercent)+' 추가 회복');
 if(r.lifesteal)a.push('준 피해의 '+percent(r.lifesteal)+' HP 회복');if(r.ward)a.push('저항 '+(r.wardAmplifier+1)+'단계 유지');return a.join(', ');
}
const EFFECT_GROUPS=[
 {id:'damagebuff',title:'피해 증가·공격 강화 기술',match:q=>/딜뻥|공증|뎀증|힘버프|공격력버프|((데미지|대미지|피해|공격력|딜).*(버프|증가|강화|올려|높여))/.test(q),groups:[
 ['힘 효과를 주는 기술',['holy_sword','fist_stance','beast_berserk','blood_awaken','fire_armor','fire_emperor','sun_descent']],
 ['평타·후속 타격을 강화하는 기술',['war_god_black_flash','sun_slash','fist_strong','berserker_execute','assassin_stealth','dragon_triple_strike']],
 ['적이 받는 피해를 늘리는 기술',['assassin_mark','fallen_orb','berserker_charge']],
 ['적에게 힘을 주는 예외: 자가 공격 강화용 지원기가 아님',['demon_contract']]]},
 {id:'healing',title:'회복·흡혈 기술',match:q=>/회복|힐|치유|흡혈/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|있는|주는/.test(q),groups:[['회복·재생·흡혈 효과',['holy_heal','holy_orb','angel_bless','angel_zone','demon_vampirism','fallen_sword_frenzy','beast_berserk','moon_moonlight','sun_descent']]]},
 {id:'defense',title:'보호·방어 강화 기술',match:q=>/보호막|방어버프|저항버프|피해흡수/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['보호·저항·피해 흡수',['holy_shield','holy_orb','angel_bless','angel_zone','fallen_shield','fist_stance','fire_armor','sun_blessing','sun_descent','demon_contract']]]},
 {id:'control',title:'적 제어 기술',match:q=>/기절|동결|빙결|속박|둔화|cc/.test(q)&&/기술|스킬|뭐|무엇|어떤|목록|주는/.test(q),groups:[['제어 효과를 갖는 기술 예시',['fist_face','frost_grasp','frost_absolute','blood_bind','tech_prison','sage_zero','moon_fullwave','sun_slash']]]}
];
function effectKnowledge(q){
 const g=EFFECT_GROUPS.find(g=>g.match(q));if(!g)return undefined;
 
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder&&j.id!=='chameleon');
 const groups=g.groups.map(([title,ids])=>title+'\n'+ids.filter(id=>SKILLS[id]&&SKILL_NOTES[id]).map(id=>{
 const skill=SKILLS[id],owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name).join('·');
 return '• '+skill.name+' ('+owners+'): '+SKILL_NOTES[id].split(/\.\s+(?=[가-힣A-Z])/)[0]+'.';
 }).join('\n')).join('\n\n');
 return Object.freeze({id:'effect:'+g.id,title:g.title,aliases:[],body:groups+'\n\n효과별 안내이며 강함·티어 순위가 아닙니다. 개별 기술명으로 상세 수치·조건을 확인하세요.',source:'data/skills.js · data/skillGuide.js · data/jobs.js'});
}
const PUBLIC_JOBS=new Set(['swordsman','mage','archer','fighter','cleric']);
let catalog;
export function knowledgeEntries(){
 if(catalog)return catalog;
 const entries=[];
 const add=(id,title,aliases,body,source)=>entries.push(Object.freeze({id,title,aliases:Object.freeze([...new Set([title,...aliases].map(normalizeQuestion).filter(x=>x.length>=2))]),body:clean(body),source}));
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder),active=new Set([...jobs.flatMap(j=>j.skills),...Object.values(APPRENTICE_SKILLS).flat()]);
 for(const id of active){
  const s=SKILLS[id];if(!s||!SKILL_NOTES[id])continue;
  const owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name);
  add('skill:'+id,s.name,[id,s.name.replace(/\s*\([^)]*\)/g,''),s.name.replace(/\s*제작$/,'')],`피해 보정: ${skillScalingInfo(id)}\n기본 MP ${s.mana} / 쿨 ${s.cooldown/20}초\n${SKILL_NOTES[id]}\n사용 직업: ${owners.join('·')}\n피해 수치는 스탯·힘 버프·장비 보정 전입니다.`, 'data/skills.js · data/skillGuide.js');
 }
 for(const j of jobs){
  const publicPromotion=PUBLIC_JOBS.has(j.id);
  const trial=publicPromotion?JOB_TRIALS[j.id]:undefined,condition=trial?`레벨 ${trial.level}\n`+['all','any'].filter(k=>trial[k]).map(k=>trial[k].map(c=>`${c.label} ${c.need}`).join(k==='all'?' + ':' 또는 ')).join('\n'):'견습 시작 직업';
  const from=trial?.allowedFrom?.map(id=>JOBS[id].name).join('·')??(j.hidden&&j.parent===null?'아무 2차 이상 직업':JOBS[j.parent]?.name??'없음');
  const type=defaultDamageTypeFor({getDynamicProperty:()=>j.id});
  const special=!publicPromotion?'전직 방법·조건은 공개하지 않습니다.':j.id==='hacker'?'전직: 로토와 23회 대화 후 퀴즈 정답. 월드 최초 정답자 1명만 전직 가능. 직업·레벨 제한 없음.':`직전 직업: ${from}\n전직 조건: ${condition}`;
  const shrine=trial?.shrine?`\n전직 장소: 천체 신전의 ${trial.shrine==='sun'?'해 제단·낮':'달 제단·밤'} 4칸 안. /rpg:temple에서 위치 확인.`:'';
  const extra='';
  add('job:'+j.id,j.name,[j.id],`${special}${extra}${shrine}\n기본 피해 계열: ${type==='magic'?'마력(마법)':'근력(물리)'}. 개별 기술에 다른 피해 판정이 있으면 해당 판정을 따릅니다.\n보유 기술: ${j.skills.map(id=>SKILLS[id]?.name??id).join('·')||'시작 장비에 따라 사용'}\n${j.id==='chameleon'?LINE_NOTES.chameleon:''}`,'data/jobs.js · data/jobTrials.js · data/skillGuide.js');
 }
 for(const [id,r]of Object.entries(RUNES)){
  const recipe=CRAFTING_RECIPES.find(c=>c.id==='rpg:rune_'+id);
  add('rune:'+id,r.name,[r.name.replace('의 ',''),'rune_'+id],`등급: 일반~신화, 강화와 별개인 합성 승급. 힘·비전 룬은 +1부터 공용·직업 무기 근접 평타에도 추가 피해를 줍니다. 두 룬의 평타 추가 피해율은 합산합니다. 아래는 일반 등급 기준\n기본: ${runeEffects(upgradedRune(r,0))}\n최대 +${RUNE_MAX}: ${runeEffects(upgradedRune(r,RUNE_MAX))}\n/rpg:runes 보관함에서 장착해야 효과를 받습니다.\n${recipe?.text??'룬 드롭으로 획득'}`,'data/equipment.js · data/upgrades.js · data/crafting.js');
 }
 for(const [id,a]of Object.entries(ARMOR_SETS))add('armor:'+id,a.name+' 갑옷',[a.name,id,...(id==='abyssal'?['심연갑옷','상위갑옷','네더라이트이상']:[])],`${a.description}\n등급: 일반~신화. 부위당 등급 추가 HP ${ARMOR_GRADE_HP.join(' / ')}\n부위별 방어력: ${a.protection.join(' / ')}\n최대 강화 +${ARMOR_MAX}. 부위별 제작법은 /rpg:craft에서 확인하세요.`,'data/equipment.js · data/upgrades.js');
 for(const r of CRAFTING_RECIPES)add('craft:'+r.id,r.name+' 제작법',[r.name,r.id,r.name.replace('훈련용 ','').replace(' 소환',''),...(r.id==='rpg:stat_reset_scroll'?['스탯초기화']:[])],r.text,'data/crafting.js (실제 조합법에서 생성)');
 add('rule:offer','검과 책 바치기',['공물','바치기','검바치기','책바치기'], '/rpg:offer: 검과 책을 바칩니다. 인벤토리에서 현재 직업과 진행도에 맞게 소비합니다. 바친 아이템은 사라집니다. 효과부여 책은 시련과 마나 공물 중 현재 필요한 용도로 사용됩니다.','core/offer.js');
 add('rule:huntingzones','사냥 구역과 자연 출현',['사냥구역','초반사냥','중반사냥','후반사냥','몹스폰','몬스터출현'], '오버월드 X·Z 중 절댓값이 큰 좌표를 기준으로 초반 ±1500, 초반 밖 중반 ±4000, 중반 밖 후반 ±10000입니다. 경계는 안쪽 구역에 포함하고 10000 밖도 후반을 유지합니다. 밤에는 구역에 맞는 RPG 몬스터가 출현합니다. 바닐라 적대 몹 자연 출현은 동굴로 제한합니다. 사막 몬스터는 사막에서 밤낮·좌표 제한 없이 출현합니다.','data/huntingZones.js · spawn_rules');
 add('rule:rarity','아이템 등급·합성',['등급','아이템등급','무기등급','갑옷등급','룬등급','희귀도','합성','승급'],RARITIES.join(' → ')+'\n룬·RPG 갑옷·공용 무기 7종은 모두 일반~신화가 존재합니다. 같은 종류·같은 등급의 +5 이상 두 개를 /rpg:fuse에서 합성합니다. 성공하면 다음 등급 +0, 실패하면 두 장비를 보존하며 50% 확률로 주장비만 -1강. 둘 다 +10이면 성공률 100%. 신화는 최종 등급. 갑옷은 보호 IV 책 1권, 공용 무기는 날카로움 V 책 1권이 추가로 필요하고 성공·실패 모두 소모합니다. 룬은 책이 필요 없습니다.\n다음 등급 성공률: '+PROMOTION_RATES.join(' / ')+'%. 무기 기본 피해·룬 수치 효과 배율: '+GRADE_MULTIPLIERS.join(' / ')+'. 갑옷 부위당 추가 HP: '+ARMOR_GRADE_HP.join(' / ')+'. 직업 기본 무기는 등급·승급 없이 +10 강화만 가능하며, 강화 단계당 근접 피해 +1·물리/마법 스킬 피해 +2%. 고정 피해·회복량은 제외. 바닐라 장비는 제외.','data/grades.js · core/fusion.js');
 add('rule:armor','갑옷 종류·제작',['갑옷','방어구'],Object.values(ARMOR_SETS).map(a=>a.name+': '+a.description).join('\n')+'\n4부위를 같은 세트로 입어야 세트 효과를 받습니다. /rpg:craft에서 부위별 제작법, /rpg:upgrade에서 강화를 확인하세요.','data/equipment.js · data/crafting.js');
 add('rule:scalingjobs','근력·마력 직업 안내',['근력직업','마력직업','근력캐','마력캐','힘캐','마법직업'],['근력(물리) 기본 계열: '+jobs.filter(j=>j.id!=='apprentice'&&defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='physical').map(j=>j.name).join('·'),'마력(마법) 기본 계열: '+jobs.filter(j=>defaultDamageTypeFor({getDynamicProperty:()=>j.id})==='magic').map(j=>j.name).join('·'),'직업 기본 계열과 개별 기술은 다를 수 있습니다. 풍압·용의 브레스는 마력, 달 계열 공격은 근력, 메테오드라이브/혈인은 혼합, 대미장식은 고정 피해입니다. 스킬명과 함께 물어보세요.'].join('\n'),'core/stats.js · data/skillScaling.js');
 add('rule:damage','피해 계산·힘 버프',['힘버프','힘효과','힘스킬','마법딜','고정피해','마법피해','피해계산'],`힘 효과는 물리·마법 스킬 피해를 단계당 ${CONFIG.skillDamage.strengthPerLevel*100}% 증가시킵니다. 힘 I +5%·II +10%·III +15%. 단타와 연타 총합에 같은 비율로 적용합니다. 이후 물리는 근력, 마법은 마력과 장비·룬 보정을 받습니다. 고정 피해는 유지합니다.\n무투가 기존 힘 계산 및 평타 배수에는 중복 적용하지 않습니다. 기본 평타의 힘 효과는 마인크래프트 엔진 규칙입니다.`,'core/stats.js · skills/fist.js');
 add('rule:transfer','갑옷 강화 이전',['강화이전','이전서','강화추출'],`/rpg:transfer에서 제작 전에 강화를 이전서로 추출하세요. 단계당 골드 500, 원래 갑옷은 +0. 새 RPG 갑옷을 만든 뒤 같은 부위에 100% 적용하며 이전서는 소모됩니다. 기존 단계보다 높은 이전서만 적용하며 합산하지 않습니다. 인챈트·내구도는 대상 장비 것을 유지합니다.`,'core/armorTransfer.js');
 add('rule:bosscc','보스 CC 저항',['보스cc','보스기절','보스빙결','보스둔화'],`커스텀 보스 4종·드래곤·위더·워든에게 기절·빙결·둔화·속박 1회 지속시간은 50%, 넉백·끌어당김 강도는 50%입니다. 일반 몬스터와 플레이어는 그대로입니다. 장판에서 CC를 다시 적용하는 동작은 유지하며, 피해·화상·독은 CC 감소 대상이 아닙니다.`,'core/crowdControl.js');
 add('rule:farm','좀벌레 보상',['좀벌레','좀벌레팜','공장'],`좀벌레는 XP 5, 골드 2, 강화석·룬 가루 0, 룬 확률 0.1%입니다. 일반 적과 다른 전용 보상을 적용합니다.`,'core/economy.js · core/runeDrops.js');
 add('rule:commonweapons','공용 전투 무기',['공용무기','무기제작','평타무기'],COMMON_WEAPONS.map(w=>w.name+': 추가 근접 피해 설정 '+w.damage+'·내구도 '+w.durability).join('\n')+'\n누구나 제작하는 평타용 무기입니다. 직업 스킬은 기존 전용 아이템으로 사용합니다. /rpg:craft에서 재료를 확인하세요.','data/commonWeapons.js · data/crafting.js');
 for(const w of COMMON_WEAPONS)add('weapon:'+w.key,w.name,[w.key,w.id],`공용 RPG 평타 무기. 일반~신화 합성 승급 가능, 최대 +10 강화(단계당 추가 근접 피해 +1) · 추가 근접 피해 설정 ${w.damage}·내구도 ${w.durability}. 직업 제한 없음. /rpg:craft에서 제작법을 확인하세요. 직업 스킬은 전용 아이템을 사용합니다.`,'data/commonWeapons.js');
 add('rule:stats','레벨·스탯',['스탯','근력','마력','지능','체력스탯','레벨업'],`자연 성장 최대 레벨 100, 레벨마다 SP 3. 근력·체력·마력 투자 상한 없음. 지능 최대 50이며 마나 소모 감소는 최대 40%.\n근력은 물리 피해, 마력은 마법 피해·회복량, 체력은 최대 HP입니다. /rpg:stats에서 분배합니다.`,'core/stats.js');
 add('rule:pvp','PvP·결투·PK',['pvp','피케이','결투','현상금','pk패널티'], '일반 PvP 허용. /rpg:pvp 또는 지원되는 환경의 /pvp로 신청하고 서로 수락하면 PvP장으로 이동하여 최대 HP로 회복 후 3초 뒤 결투 시작, 패배 직전 비살상 종료합니다. 결투 밖 플레이어 살인은 PK 표식. PK 플레이어를 죽이면 그 지갑에서 최대 50,000골드를 지급하고 새 PK가 되지 않습니다. 잔액만 지급하며 부족분은 생성하지 않습니다. PK는 플레이어에게 처치돼야 해제됩니다. 던전에서는 결투 불가.','core/pvp.js');
 add('rule:party','파티 경험치',['파티','경험치','쩔','xp'],`최대 4명. 같은 차원·처치자 ${CONFIG.partyXp.radius}칸 안·생존한 파티원은 각자 원래 XP의 ${percent(CONFIG.partyXp.multiplier)} 획득. 90 XP 몹이면 각자 ${90*CONFIG.partyXp.multiplier} XP.\n일반 마크 생물 10, 대부분 적대 몹 30, 좀벌레·좀비화 피글린 5 XP. 커스텀 몹/보스는 별도 값.\n전직 처치는 최근 30초 공격·탱킹·유효 회복에 기여한 같은 차원·시체 32칸 안 생존 파티원도 인정합니다.`,'config.js · data/mobXp.js · core/combatContribution.js');
 add('rule:runes','룬 획득·장착',['룬','룬획득','룬드랍','룬드롭','룬장착'],`일반 몬스터 1%·RPG 엘리트 3%·보스 30% 확률로 룬 드롭(좀벌레만 0.1%). 현재 룬 ${Object.values(RUNES).map(r=>r.name).join('·')}.\n/rpg:runes 전용 보관함 30칸, 장착 기본 3개·슬롯 강화로 최대 5개. 같은 종류는 하나만 장착. 원하는 룬은 /rpg:craft 제작법을 확인하세요.`,'core/runeDrops.js · loot_tables/rpg · core/runeInventory.js');
 const ar=enhancementRates('armor',ARMOR_MAX-1),rr=enhancementRates('rune',RUNE_MAX-1),ac=upgradeCost('armor',ARMOR_MAX-1),rc=upgradeCost('rune',RUNE_MAX-1);
 add('rule:classweapon','직업 기본 무기 강화',['직업무기강화','기본무기강화','직업무기등급'], '직업·견습 기본 무기 36종은 /rpg:upgrade에서 +10까지 강화합니다. 등급·승급은 없습니다. 강화당 근접 피해 +1, 그 무기를 들고 사용하는 물리·마법 스킬 피해 +2%(+10은 +20%). 고정 피해와 회복량은 증가하지 않습니다. 공용 무기와 같은 비용·실패·강등·파괴·촉매 규칙입니다. 카멜레온 무기 전환과 직업 무기 재지급·전직 시 강화 단계를 유지합니다.','data/classWeapons.js · core/upgrades.js');
 add('rule:upgrade','강화·촉매·재화',['강화','촉매','골드','강화석','룬가루'],`/rpg:upgrade에서 갑옷·공용·직업 무기 최대 +${ARMOR_MAX}, 룬 최대 +${RUNE_MAX}. 실패·강등·파괴에도 비용 소모.\n갑옷 마지막 단계: 골드 ${ac.gold}·강화석 ${ac.stone}, 성공 ${ar.success}% / 유지 ${ar.fail}% / 강등 ${ar.downgrade}% / 파괴 ${ar.destroy}%.\n룬 마지막 단계: 골드 ${rc.gold}·룬 가루 ${rc.dust}, 성공 ${rr.success}% / 유지 ${rr.fail}% / 강등 ${rr.downgrade}% / 파괴 ${rr.destroy}%.\n촉매는 갑옷·무기 +5·룬 +2부터 1회 최대 ${MAX_CATALYSTS}개, 1개당 성공 +9%p·파괴 -3%p(파괴 0% 하한). 최종 확률은 확인창에 표시.`,'data/upgrades.js');
 add('rule:monsterlevels','몬스터 레벨',['몬스터레벨','몹레벨','필드레벨','던전난이도'], 'RPG 몬스터 22종은 레벨에 따라 체력·공격·방어가 증가합니다. 초반 필드 Lv.1/5/10/15, 중반 Lv.20/30/40/55, 후반 Lv.70/90/115/145. 같은 종도 여러 레벨로 등장합니다. 10단계는 일반 Lv.145~220, 엘리트 Lv.220, 보스 Lv.260입니다. 무기·RPG 갑옷·장착 룬 전설 +10 수준의 4인 파티 권장선이며 장비 입장 제한은 없습니다. 고정 피해는 레벨 방어를 상쇄합니다.','data/monsterLevels.js');
 add('rule:dungeon','던전 입장·진행',['던전','던젼','보스제한시간','솔플','솔로보상','혼자던전'],`난이도 ${DUNGEON_TIERS.length}개. /rpg:dungeon에서 참가, /rpg:dungeonstart로 최대 ${DUNGEON.maxParty}명 출발. 혼자는 /rpg:dungeonsolo 1. 처음부터 혼자 출발하면 클리어 골드·강화석·룬 가루·촉매 1.5배(올림). 룬·보급품·처치 보상은 그대로입니다.\n파티는 일반 ${DUNGEON.normalCount}·엘리트 ${DUNGEON.eliteCount}마리를 ${DUNGEON.mobLimitMs/60000}분 안에 처치한 뒤 보스 1마리를 ${DUNGEON.bossLimitMs/60000}분 안에 잡습니다. 혼자 출발하면 전반 7분 30초·보스 4분 30초입니다. 몹이 없으면 후속 몹이 일찍 나옵니다. 전투 중 임의 퇴장 불가, 사망·완료·제한시간 종료로 귀환.\n종료 시 남은 아이템과 몹의 마크 XP를 피해+유효 회복 기여도에 따라 분배합니다. RPG 처치 XP는 기존 방식이며 가방 부족 전리품은 /rpg:dungeonloot로 받습니다.\n관리자 생성: /rpg:dungeoncreate 1 또는 all.`,'data/dungeons.js · core/dungeons.js');
 for(const d of DUNGEON_TIERS){const r=clearRewardForTier(d.tier),solo=clearRewardForTier(d.tier,true);add('dungeon:'+d.tier,`던전 ${d.tier} ${d.name}`,[d.name,'던전'+d.tier,d.tier+'번던전',d.tier+'단계던전',d.tier+'티어던전'],`난이도 ${d.tier}. 일반 Lv.${dungeonMonsterLevel(d.tier,'normal',0)}~${dungeonMonsterLevel(d.tier,'normal',2)}, 엘리트 Lv.${dungeonMonsterLevel(d.tier,'elite')}, 보스 Lv.${dungeonMonsterLevel(d.tier,'boss')}. 10단계는 전설 +10 세트 권장, 입장 제한 없음. 보스: ${bossName(d.boss)}.\n클리어 보상: 골드 ${r.gold}·강화석 ${r.stone}·룬 가루 ${r.dust}·촉매 ${r.catalysts}·룬 ${r.runes}개. 보급품 ${r.supplyMultiplier}배. 솔로 클리어는 골드 ${solo.gold}·강화석 ${solo.stone}·룬 가루 ${solo.dust}·촉매 ${solo.catalysts}입니다. 던전 엘리트는 다이아 1개 40%·3개 10%·없음 50%로 공동 전리품을 남깁니다. 클리어 시 네더라이트 주괴 1개 확률 ${Math.round(netheriteChanceForTier(d.tier)*100)}%(6~10단계 한정, 각자 추첨). 개별 몬스터 처치 재화는 별도.`,'data/dungeons.js');}
 add('rule:temple','해·달의 신전',['신전','해의신전','달의신전','천체신전'],'낮에는 해의 제단, 밤에는 달의 제단이 활성화되는 구조물입니다. 히든 직업의 전직 방법·조건은 안내하지 않습니다.','data/temple.js');
 add('rule:melee','추가 근접 피해 없는 기본 아이템',['근접피해없는직업','근접데미지없는직업','기본아이템피해'],`기본 아이템에 추가 근접 피해 설정이 없는 직업은 마법사·현자·궁수·천궁·성직자·천사·미카엘·타락천사입니다. 공격이 완전히 0인 뜻은 아니며 맨손 수준 기본 피해·힘·인챈트와 화살/스킬 피해는 별도입니다. 공용 전투검/전투창으로 근접 사냥을 보완할 수 있습니다.`,'items/*.json · data/jobs.js');
 add('rule:start','처음 시작',['초보','시작','처음','막혔','막힘'],`/rpg:guide의 견습 5계열 체험에서 시작 계열과 관계없이 검·마법·활·격투·회복 견습 장비를 바꿔 사용할 수 있습니다. 빵과 화살은 처음 한 번만 지급합니다. 첫 전직은 레벨 10과 각 직업 시련이 필요합니다. /rpg:jobs에서 현재 전직 조건, /rpg:craft에서 재료, /rpg:skillguide에서 기술을 확인하세요.`,'core/beginner.js · core/jobMenu.js');
 catalog=Object.freeze(entries);return catalog;
}
export function lookupRpgQuestion(question){
 const raw=String(question??'').trim();if(!raw)return {status:'empty',entries:[]};
 if(raw.length>QUESTION_LIMIT)return {status:'too_long',entries:[]};
 if(isBalanceQuestion(raw))return {status:'balance',entries:[]};
 if(isHiddenPromotionQuestion(raw))return {status:'hidden',entries:[]};
 const q=normalizeQuestion(raw);if(!q)return {status:'unknown',entries:[]};
 if(/전직(방법|조건|하는법|하려면|알려)|직업.*조건/.test(q)&&!Object.values(JOBS).some(j=>j.id!=='apprentice'&&q.includes(normalizeQuestion(j.name)))){return {status:'answer',entries:[{id:'rule:publicpromotions',title:'공개 전직 안내: 기본 직업 5종',body:knowledgeEntries().filter(e=>['job:swordsman','job:mage','job:archer','job:fighter','job:cleric'].includes(e.id)).map(e=>e.title+'\n'+e.body).join('\n\n'),source:'data/jobTrials.js'}],effect:true};}
 const named=knowledgeEntries().some(e=>e.id.startsWith('skill:')&&e.aliases.some(a=>q.includes(a)));
 const effect=!named&&effectKnowledge(q);if(effect)return {status:'answer',entries:[effect],effect:true};
 const ranked=knowledgeEntries().map(e=>({entry:e,score:Math.max(0,...e.aliases.filter(a=>q.includes(a)&&(!/[0-9]$/.test(a)||new RegExp(a+'(?![0-9])').test(q))).map(a=>a.length*10+(/등급|희귀도/.test(q)&&/^(weapon|armor|rune):/.test(e.id)?100:0)+(named&&/근력|마력|물리|마법|피해계열/.test(q)&&e.id.startsWith('skill:')?100:0)+(e.id.startsWith('skill:')?2:e.id.startsWith('rune:')?3:0)+(e.id.startsWith('craft:')&&/제작|만드|만들|조합|재료/.test(q)?5:0)))})).filter(e=>e.score>0).sort((a,b)=>b.score-a.score||a.entry.id.localeCompare(b.entry.id));
 return {status:ranked.length?'answer':'unknown',entries:ranked.slice(0,6).map(r=>r.entry)};
}
// Only canonical records may be rendered; remote services cannot inject answer text.
export function selectKnowledgeEntries(candidates,ids){
 if(!Array.isArray(ids)||ids.length>3||ids.some(id=>typeof id!=='string'))return undefined;
 const unique=[...new Set(ids)],selected=unique.map(id=>candidates.find(e=>e.id===id));
 return selected.some(e=>!e)?undefined:selected;
}
export function formatKnowledge(entries){
 if(!entries?.length)return UNKNOWN_ANSWER;
 return entries.slice(0,3).map(e=>`${e.title}\n${e.body}`).join('\n\n')+'\n\n자료: 이 애드온의 게임 도감 v0.5.78';
}

```

## RPG_BP_v0603/scripts/core/rulebook.js

```js
import {layoutRulebook} from '../data/rulebookLayout.js';
// 명령어 책 페이지는 v0.4.82의 실제 등록 명령어 목록을 기반으로 작성.
// ItemBookComponent는 @minecraft/server 2.2.0부터 지원.
import { ItemStack } from "@minecraft/server";

export const RULEBOOK_SECTIONS = [
  "§l§61. RPG 서버 종합 룰북§r\n\n일반 PvP가 허용됩니다. 결투는 /rpg:pvp 메뉴에서 신청하고 상대가 수락해야 합니다. 두 사람의 체력을 채운 뒤 3초 후 시작하며 패배 직전 비살상 종료합니다.\n\n결투 밖 살인은 PK 표식·현상금 패널티. 건축물 훼손·약탈은 하지 마세요. 던전·신전 보호는 유지합니다.",
  "§l§62. 목차§r\n\n기초 지식·사냥 구역\n시작 안내·전투 조작·공물\n전직·스탯·파티·길드\n재화·룬·갑옷·무기\n강화·촉매·등급·합성\n던전·신전·초기화 아이템\n정보 질문·서바이벌 명령어\n\n주제 번호순으로 정리했습니다.",
  "§l§63. 기초 지식§r\n\nRPG 경험치와 바닐라 초록 경험치바는 별개입니다.\n/rpg:stats에서 RPG 레벨·SP를 확인하세요.\n\nRPG 레벨이 오를 때 SP 3개를 받습니다. 자연 성장은 레벨 100까지입니다.\nHP 2는 하트 1칸입니다.",
  "§l§64. 사냥 구역 기준§r\n\n오버월드 X·Z 중 절댓값이 큰 좌표로 구분합니다. 높이 Y는 무관합니다.\n\n초반: -1,500~+1,500\n중반: 초반 밖, -4,000~+4,000\n후반: 중반 밖, -10,000~+10,000\n\n경계는 안쪽 구역. 1만 밖도 후반 몬스터가 계속 나옵니다.",
  "§l§65. 밤의 사냥§r\n\n밤에는 현재 사냥 구역에 맞는 RPG 몬스터가 나옵니다. 바깥 구역일수록 강한 적을 만나게 됩니다.\n\n초반: 버섯·초록 고블린\n중반: 빨강·황금 고블린·대장\n후반: 엘리트 버섯·고블린\n\n밤이 되어도 조명·공간·몹 수에 따라 출현량은 달라집니다.",
  "§l§66. 동굴과 사막§r\n\n바닐라 적대 몹은 오버월드 동굴에서 자연 출현합니다.\n\n사막에서는 밤낮과 사냥 구역 좌표에 상관없이 사막 몬스터가 나옵니다.\n전갈·사마귀·데스웜과 엘리트가 있으니 초반에도 주의하세요.\n\n동물은 먹거리와 목장 운영에 활용하세요.",
  "§l§67. 처음 시작하기§r\n\n/rpg:guide\n원할 때 시작 장비와 안내를 받습니다. 첫 접속에 계열 선택창은 자동으로 뜨지 않습니다.\n\n/rpg:guide의 견습 5계열 체험에서 시작 계열과 관계없이 장비를 바꿔 써보세요. 빵과 화살은 처음 한 번만 지급합니다. 첫 사냥 5마리를 완료하면 같은 안내창에서 보상을 받으세요.",
  "§l§68. 전투 조작§r\n\n직업 전용 아이템을 손에 들고 사용하세요. 웅크리면 다음 기술로 전환합니다.\n\n대부분 우클릭/아이템 사용으로 시전합니다. 활과 대상 지정 회복 등은 조작이 다릅니다.\n/rpg:skills에서 기술을 켜거나 끕니다.\n/rpg:skillguide에서 효과·MP·쿨타임을 확인하세요.",
  "§l§69. 검과 책을 바칩니다§r\n\n/rpg:offer\n\n인벤토리의 검과 효과부여 책을 현재 직업·진행도에 맞게 바칩니다. 바친 아이템은 소비됩니다.\n\n검사 기본 시련에는 다이아몬드 검을 사용합니다. 마법사 기본 시련에는 효과부여 책을 사용합니다.\n검은 시련 수량까지만 소비합니다. 책은 직업에 따라 마나 공물로도 사용됩니다.",
  "§l§610. 기본 직업과 정보§r\n\n검사·마법사·궁수·무투가·성직자가 기본 직업입니다. 첫 전직은 레벨 10과 직업별 시련이 필요합니다.\n\n/rpg:job <직업>\n전직을 요청합니다.\n/rpg:jobs\n직업 정보를 확인합니다.\n\n이 책에는 히든 직업의 전직 방법을 적지 않습니다.",
  "§l§611. 스탯과 마나§r\n\n근력: 물리 스킬 피해\n마력: 마법 스킬 피해·직접 회복\n체력: 최대 HP\n지능: 기술 MP 소모 감소\n\n지능 할인은 최대 40%입니다. 근력·마력·체력은 투자 상한이 없습니다.\n마법·성직 고마나 직업은 책 공물로 최대 마나를 늘릴 수 있습니다.",
  "§l§612. 파티 사냥§r\n\n/rpg:party · /rpg:invites\n파티를 만들고 초대를 수락하세요. 최대 4명입니다.\n\n같은 차원·처치자 32칸 안·생존 중인 파티원은 각자 원래 XP의 75%를 받습니다.\n예: 90 XP 몹 → 각자 67.5 XP.\n레벨 차이로 나눠 갖는 방식은 아닙니다.",
  "§l§613. 길드와 전직 기여§r\n\n/rpg:guild\n길드 생성·초대·관리를 합니다. 길드만 같다고 XP를 공유하지는 않습니다.\n\n전직용 처치는 최근 30초간 공격·탱킹·유효 회복에 기여한 파티원도 인정됩니다. 같은 차원·처치 위치 32칸·생존 조건을 충족해야 합니다.",
  "§l§614. 재화와 제작§r\n\n/rpg:wallet\n골드·강화석·룬 가루를 확인합니다.\n골드: 공통 강화 비용\n강화석: 갑옷·공용 무기 강화\n룬 가루: 룬 강화\n\n/rpg:craft\n실제 조합법과 획득법을 봅니다. 제작은 작업대에서 합니다.",
  "§l§615. 룬 획득§r\n\n일반 몬스터: 1%\n엘리트 몬스터: 3%\n보스 몬스터: 30%\n좀벌레: 0.1%\n\n드롭 룬은 바닥에 1개이며 파티원별로 복제되지 않습니다.\n원하는 룬은 /rpg:craft에서 재료를 확인해 제작할 수도 있습니다.",
  "§l§616. 룬 보관·장착§r\n\n/rpg:runes\n일반 가방의 룬을 전용 보관함에 넣고 장착하세요. 들고만 있어서는 효과를 받지 않습니다.\n\n보관 30칸·장착 기본 3개·슬롯 강화로 최대 5개. 같은 종류는 1개만 장착합니다.\n갑옷과 독립적입니다. 강화·승급 룬은 전용 보관함에서 관리합니다.",
  "§l§617. 힘·비전의 룬§r\n\n일반 등급 기준\n\n힘의 룬: 물리 스킬 피해 +10% → +10 강화 시 +30%.\n\n비전의 룬: 마법 스킬 피해 +10% → +10 강화 시 +30%.\n\n고정 피해에는 일반 피해 증가 보정이 적용되지 않습니다.",
  "§l§618. 샘·생명의 룬§r\n\n일반 등급 기준\n\n샘의 룬: 초당 최대 마나의 1% 추가 회복 → +10 강화 시 3%.\n\n생명의 룬: 최대 HP +4 → +10 강화 시 +24.\n실제 최대 HP는 기존 엔진 효과에 따라 4 HP 단위로 근사됩니다.",
  "§l§619. 수호·흡수의 룬§r\n\n일반 등급 기준\n\n수호의 룬: RPG 방어력 +4, 강화마다 +2. 일반 +10은 방어력 +24(룬 피해 감소 8.4%)와 기존 HP 보너스. 저항 효과는 부여하지 않습니다.\n\n흡수의 룬: 적에게 준 실제 피해의 5%를 HP로 회복 → +10에서 12%.\n받는 피해를 줄이는 룬이 아닙니다.",
  "§l§620. RPG 갑옷§r\n\n같은 종류의 갑옷 4부위를 착용해야 세트 효과를 받습니다.\n\n모험가: 물리 스킬 +8%\n숲 수호자: 최대 HP +8\n별빛 술사: 마법 스킬 +8%, 초당 MP +3\n심연 수호자: 최대 HP +16, 물리·마법 +8%, 저항 I\n\n/rpg:equipment에서 관리하세요.",
  "§l§621. 공용 무기 7종§r\n\n적월선\n마공학 검\n마공학 대검\n정예기사의 대검\n빙설의 대검\n화염의 대검\n마수의 도끼\n\n직업 제한 없이 제작하는 평타 무기입니다. 직업 기술은 기존 전용 아이템을 사용하세요. 제작법은 /rpg:craft.",
  "§l§622. 강화와 위험§r\n\n/rpg:upgrade\n착용 RPG 갑옷·손에 든 공용·직업 무기·보관함 룬을 최대 +10까지 강화합니다.\n\n성공·유지 실패·1단계 강등·파괴가 있습니다. 높은 단계일수록 위험합니다. 모든 완료된 시도에서 비용이 소비됩니다. 확인창을 읽고 진행하세요.",
  "§l§623. 촉매와 이전§r\n\n촉매는 한 번에 최대 5개. 개당 성공률 +9%p·파괴 확률 -3%p입니다. 강등·파괴를 제외한 확률 상한을 적용합니다.\n갑옷·무기 +5, 룬 +2부터 사용합니다.\n\n/rpg:transfer\n갑옷 강화는 제작 전에 이전서로 추출하세요. 같은 부위에 강화 단계만 이전하며 등급·인챈트는 옮기지 않습니다.",
  "§l§624. 장비 등급§r\n\n일반 → 레어 → 에픽 → 고대 → 영웅 → 전설 → 신화\n\n룬·RPG 갑옷·공용 무기에 각각 등급이 있습니다. 직업 전용 아이템은 등급·승급 없이 +10 강화만 가능합니다. 단계당 근접 피해 +1·물리/마법 스킬 +2%입니다.\n\n등급은 무기 기본 피해·룬 수치형 효과·갑옷 추가 HP에 영향을 줍니다. 일반 강화만으로 등급이 오르지는 않습니다.",
  "§l§625. 장비 합성§r\n\n/rpg:fuse\n같은 종류·같은 등급의 +5 이상 장비 두 개를 합성합니다. 갑옷은 세트·부위도 같아야 합니다.\n\n성공: 다음 등급 +0\n실패: 두 장비 보존, 50%로 주장비 -1강. 둘 다 +10이면 확정 승급\n\n갑옷은 보호 IV 책, 공용 무기는 날카로움 V 책 1권 추가. 성공·실패 모두 소모하며 룬은 제외합니다.\n\n승급 확률은 순서대로 90/85/80/75/70/60%. 신화가 최종 등급입니다.",
  "§l§626. 던전 입장§r\n\n/rpg:dungeon\n난이도 1~10 중 본인이 원하는 대기실에 참가합니다. 몬스터 레벨은 후반일수록 높습니다. 10단계는 무기·갑옷·장착 룬 전설 +10 세트 권장, 입장 제한 없음.\n/rpg:dungeonstart\n대기실 첫 참가자가 1~4명으로 출발합니다.\n/rpg:dungeonsolo <1~10>\n혼자 바로 출발합니다. 파티원을 자동으로 이동시키지 않습니다.",
  "§l§627. 던전 진행·실패§r\n\n일반 몬스터 50마리·엘리트 5마리를 5분 안에 잡으세요. 모두 잡으면 보스 1마리가 나옵니다. 보스는 등장 후 3분 제한입니다. 혼자 출발하면 일반·엘리트 7분 30초, 보스 4분 30초입니다.\n\n시간 초과·전원 사망이면 실패하며 내부 몹을 보상 없이 정리합니다. 전직관·GPT NPC는 보존됩니다.",
  "§l§628. 던전 귀환·보상§r\n\n종료 시 남은 아이템·몹의 마크 XP를 피해+유효 회복 기여도로 나눕니다. RPG 처치 XP는 기존 방식입니다.\n\n전투 중 임의로 나갈 수 없습니다. 경계 밖으로 이탈하면 복귀됩니다.\n/rpg:dungeonleave\n대기를 취소하거나 사망 후 귀환합니다.\n/rpg:dungeonloot\n가방 부족으로 보관된 보급품과 분배 전리품을 받습니다.\n\n처음부터 혼자 출발하면 주요 클리어 재화가 1.5배입니다.\n\n던전 엘리트 다이아: 1개 40%·3개 10%·없음 50%(공동 전리품).\n6~10단계 클리어: 각자 네더라이트 주괴 1개를 10/15/20/25/30% 확률로 받습니다.",
  "§l§629. 신전·구조물 보호§r\n\n낮에는 해의 제단, 밤에는 달의 제단이 활성화됩니다.\n/rpg:temple\n신전의 위치와 현재 상태를 확인합니다.\n\n등록된 던전·신전은 채굴·폭발·블록 변형으로부터 보호됩니다. 제단과 전직관을 사용하는 것은 가능합니다.",
  "§l§630. 성장 초기화 아이템§r\n\n스탯 초기화 주문서: 배분한 스탯 SP를 되돌립니다.\n전직 포기각서: 현재 직업을 포기하고 견습으로 돌아갑니다.\n\n제작법은 /rpg:craft. 사용 확인창을 읽으세요. 전직 포기는 기술 구성을 바꾸지만 레벨·재화·장비를 삭제하지 않습니다.",
  "§l§631. 정보 질문과 도감§r\n\n/rpg:ask <질문>\n또는 GPT NPC와 대화하세요.\n기술 효과·물리/마법 판정·제작·룬·던전 정보를 안내합니다.\n\n밸런스 순위·사기 직업 평가는 하지 않습니다. 전직 방법 안내는 기본 5직업만 제공합니다.\n/rpg:skillguide: 기술 상세 도감",
  "§l§632. 서바이벌 명령어 1§r\n\n/rpg:guide 시작 안내\n/rpg:status 내 상태\n/rpg:stats 스탯 배분\n/rpg:skills 기술 켜기/끄기\n/rpg:offer 검과 책을 바칩니다\n/rpg:craft 제작·획득 도감\n/rpg:wallet 지갑\n/rpg:equipment 장비 메뉴\n/rpg:runes 룬 보관·장착",
  "§l§633. 서바이벌 명령어 2§r\n\n/rpg:upgrade 강화\n/rpg:fuse 등급 합성\n/rpg:transfer 갑옷 강화 이전\n/rpg:party 파티\n/rpg:guild 길드\n/rpg:invites 초대 확인\n/rpg:dungeon 던전\n/rpg:temple 신전 정보\n/rpg:rulebook 이 책 다시 받기",
  "§l§634. 직업 전용 기능§r\n\n/rpg:skillbook: 카멜레온 학습·분해·횟수 충전\n/rpg:learn <스킬ID>: 학습\n/rpg:swap: 카멜레온 무기 전환\n/rpg:wings: 날개 전환\n/rpg:wingcheck: 날개 상태\n/rpg:wingrefresh: 날개 재장착\n/rpg:fistcheck: 격투 상태\n\n해당 직업·기능을 보유해야 사용할 수 있습니다.",
  "§l§635. 안내를 다시 볼 때§r\n\nRPG v0.5.78 PvP·PK 서버용\n\n/rpg:rulebook으로 최신 종합 룰북을 다시 받으세요. 업데이트 전의 책은 옛 내용이 남아 있습니다.\n\n기술 사용이 막히면 직업 아이템·켜 둔 기술·MP·쿨타임을 먼저 확인하세요. 막힌 내용은 /rpg:ask로 질문할 수 있습니다.",
  "§l§636. 결투·PK 상세§r\n\n/rpg:pvp 신청·수락·항복\n서로 동의한 결투는 사망·아이템·XP 손실 없이 끝납니다. 던전 진행 중에는 결투 불가.\n\nPK 상태 플레이어를 죽이면 상대 지갑에서 최대 50,000골드를 받으며 추가 PK가 되지 않습니다. 잔액이 부족하면 있는 만큼만 지급합니다. PK는 플레이어에게 처치되면 해제되며 환경 사망·재접속으로 지워지지 않습니다."
];

export const RULEBOOK_PAGES=layoutRulebook(RULEBOOK_SECTIONS);

export function giveRulebook(player) {
  try {
    const book = new ItemStack("minecraft:writable_book", 1);
    const pages = book.getComponent("minecraft:book");
    if (!pages || typeof pages.setContents !== "function") {
      player.sendMessage("§c[RPG] 책 페이지 API가 없는 버전입니다. @minecraft/server 2.2.0 이상을 사용하세요.");
      return false;
    }
    pages.setContents(RULEBOOK_PAGES);
    if(typeof pages.signBook==="function")pages.signBook("RPG 서버 종합 룰북","RPG 서버");
    book.nameTag = "§6RPG 서버 종합 룰북";
    book.setLore(["§7서바이벌·성장·룬·던전 · " + RULEBOOK_PAGES.length + "쪽", "§7/rulebook 또는 /rpg:rulebook"]);
    const inventory = player.getComponent("minecraft:inventory")?.container;
    if (!inventory) {
      player.sendMessage("§c[RPG] 인벤토리를 찾지 못했습니다.");
      return false;
    }
    const leftover = inventory.addItem(book);
    if (leftover) {
      // 가방이 꽉 차도 책이 사라지지 않게 플레이어 발밑에 드롭합니다.
      const loc = player.location;
      player.dimension.spawnItem(leftover, { x: loc.x, y: loc.y + 0.5, z: loc.z });
      player.sendMessage("§e[RPG] 인벤토리가 가득 차서 명령어 책이 발밑에 떨어졌습니다.");
    } else {
      player.sendMessage("§a[RPG] 'RPG 서버 종합 룰북'을 받았습니다! (" + RULEBOOK_PAGES.length + "쪽)");
    }
    return true;
  } catch (error) {
    player.sendMessage("§c[RPG] 안내서 지급 실패: " + String(error));
    return false;
  }
}

```

## RPG_BP_v0603/scripts/core/runeInventory.js

```js
import { ItemStack, EquipmentSlot } from '@minecraft/server';
import { RUNES, RUNE_KEY } from '../data/equipment.js';
import {itemGrade} from '../data/grades.js';
import { RUNE_LEVEL_KEY, upgradeLevel } from '../data/upgrades.js';

export const RUNE_BAG_KEY='rpg:rune_bag_v1';
export const RUNE_CAPACITY=30;
export const RUNE_BASE_SLOTS=3;
export const RUNE_SLOTS=5;
export function readRuneBag(p){
  const raw=p.getDynamicProperty(RUNE_BAG_KEY);
  if(raw===undefined)return {version:3,nextId:1,runes:[],equipped:Array(RUNE_SLOTS).fill(null),unlockedSlots:RUNE_BASE_SLOTS};
  const bag=JSON.parse(raw);
  if(![1,2,3].includes(bag?.version)||!Number.isSafeInteger(bag.nextId)||bag.nextId<1||!Array.isArray(bag.runes)||bag.runes.length>RUNE_CAPACITY||!Array.isArray(bag.equipped))throw Error('룬 보관함 데이터 오류');
  if(bag.version<3){
    if(bag.equipped.length!==RUNE_BASE_SLOTS)throw Error('기존 룬 장착 데이터 오류');
    bag.equipped.push(...Array(RUNE_SLOTS-RUNE_BASE_SLOTS).fill(null));bag.unlockedSlots=RUNE_BASE_SLOTS;
  }else if(bag.equipped.length!==RUNE_SLOTS||!Number.isInteger(bag.unlockedSlots)||bag.unlockedSlots<RUNE_BASE_SLOTS||bag.unlockedSlots>RUNE_SLOTS||bag.equipped.some((uid,i)=>i>=bag.unlockedSlots&&uid!==null))throw Error('룬 장착 슬롯 데이터 오류');
  const ids=new Set();
  for(const r of bag.runes){if(r.id==='haste')r.id='mana';if(typeof r.uid!=='string'||ids.has(r.uid)||!RUNES[r.id]||!Number.isInteger(r.level)||r.level<0||r.level>(bag.version===1?5:10))throw Error('룬 데이터 오류');if(bag.version===1){r.level*=2;r.grade=0;}if(!Number.isInteger(r.grade)||r.grade<0||r.grade>6)throw Error('룬 등급 오류');ids.add(r.uid);}
  if(bag.equipped.some(uid=>uid!==null&&!ids.has(uid)))throw Error('룬 장착 데이터 오류');
  const kinds=new Set();bag.equipped=bag.equipped.map(uid=>{if(uid===null)return null;const rune=bag.runes.find(r=>r.uid===uid);if(kinds.has(rune.id))return null;kinds.add(rune.id);return uid;});
  bag.version=3;return bag;
}
export function writeRuneBag(p,bag){p.setDynamicProperty(RUNE_BAG_KEY,JSON.stringify(bag));}
export function migrateRetiredRunes(p){
  const old=p.getDynamicProperty(RUNE_BAG_KEY),inv=p.getComponent('minecraft:inventory')?.container,changed=[];
  try{
    const bag=readRuneBag(p);
    if(inv)for(let i=0;i<inv.size;i++){const token=inv.getItem(i);if(token?.typeId==='rpg:rune_haste'){changed.push({slot:i,old:token.clone()});inv.setItem(i,new ItemStack('rpg:rune_mana',token.amount));}}
    if(old!==undefined&&JSON.stringify(bag)!==old)writeRuneBag(p,bag);
    return {ok:true,converted:changed.length};
  }catch(error){for(const e of changed)inv.setItem(e.slot,e.old);p.setDynamicProperty(RUNE_BAG_KEY,old);return {ok:false,reason:String(error)};}
}
export function equippedRunes(p){
  const bag=readRuneBag(p),seen=new Set(),result=[];
  for(const uid of bag.equipped.slice(0,bag.unlockedSlots)){const rune=bag.runes.find(r=>r.uid===uid);if(rune&&!seen.has(rune.id)){seen.add(rune.id);result.push(rune);}}
  return result;
}
export function addRuneRecord(bag,id,level=0,grade=0){
  if(!RUNES[id]||bag.runes.length>=RUNE_CAPACITY)throw Error('룬 보관함이 가득 찼거나 잘못된 룬입니다.');
  if(!Number.isInteger(level)||level<0||level>10||!Number.isInteger(grade)||grade<0||grade>6)throw Error('룬 강화·등급 오류');
  const rune={uid:'r'+bag.nextId++,id,level,grade};bag.runes.push(rune);return rune;
}
export function depositRune(p,slot){
  try{
    const bag=readRuneBag(p),original=JSON.stringify(bag),inventory=p.getComponent('minecraft:inventory')?.container;
    const token=inventory?.getItem(slot),id=token?.typeId?.replace('rpg:rune_','');
    if(!token||token.typeId!=='rpg:rune_'+id||!RUNES[id])return {ok:false,reason:'선택한 칸에 룬이 없습니다.'};
    const previous=token.clone();const rune=addRuneRecord(bag,id,upgradeLevel(token,'rune'),itemGrade(token));
    try{
      if(token.amount===1)inventory.setItem(slot,undefined);else{token.amount--;inventory.setItem(slot,token);}
      writeRuneBag(p,bag);
    }catch(error){inventory.setItem(slot,previous);p.setDynamicProperty(RUNE_BAG_KEY,original);throw error;}
    return {ok:true,rune};
  }catch(error){return {ok:false,reason:String(error)};}
}
export function equipRune(p,uid,slot){
  try{
    if(!Number.isInteger(slot)||slot<0||slot>=RUNE_SLOTS)return {ok:false,reason:'장착 칸은 1~5입니다.'};
    const bag=readRuneBag(p),rune=bag.runes.find(r=>r.uid===uid);
    if(slot>=bag.unlockedSlots)return {ok:false,reason:'잠긴 슬롯입니다. 장착 슬롯 강화를 통해 먼저 해금하세요.'};
    if(!rune)return {ok:false,reason:'보관함에 해당 룬이 없습니다.'};
    for(let i=0;i<bag.unlockedSlots;i++)if(i!==slot){const other=bag.runes.find(r=>r.uid===bag.equipped[i]);if(other?.id===rune.id&&other.uid!==uid)return {ok:false,reason:'같은 종류의 룬은 하나만 장착할 수 있습니다.'};}
    bag.equipped=bag.equipped.map(id=>id===uid?null:id);bag.equipped[slot]=uid;writeRuneBag(p,bag);return {ok:true};
  }catch(error){return {ok:false,reason:String(error)};}
}
export function unequipRune(p,uid){const bag=readRuneBag(p);bag.equipped=bag.equipped.map(id=>id===uid?null:id);writeRuneBag(p,bag);}
export function removeRune(p,uid){const bag=readRuneBag(p);if(!bag.runes.some(r=>r.uid===uid))return false;bag.runes=bag.runes.filter(r=>r.uid!==uid);bag.equipped=bag.equipped.map(id=>id===uid?null:id);writeRuneBag(p,bag);return true;}
export function withdrawRune(p,uid){
  try{
    const bag=readRuneBag(p),old=JSON.stringify(bag),rune=bag.runes.find(r=>r.uid===uid);
    if(!rune)return {ok:false,reason:'룬이 없습니다.'};
    if(rune.level>0||rune.grade>0)return {ok:false,reason:'강화하거나 승급한 룬은 전용 보관함에서만 관리합니다.'};
    const inv=p.getComponent('minecraft:inventory')?.container;if(!inv)return {ok:false,reason:'가방이 없습니다.'};
    let slot=-1;for(let i=0;i<inv.size;i++){const item=inv.getItem(i);if(!item||(item.typeId==='rpg:rune_'+rune.id&&item.amount<64&&itemGrade(item)===0&&upgradeLevel(item,'rune')===0)){slot=i;break;}}
    if(slot<0)return {ok:false,reason:'가방에 빈 공간이 없습니다.'};
    const previous=inv.getItem(slot)?.clone(),token=previous?.clone()??new ItemStack('rpg:rune_'+rune.id,1);if(previous)token.amount++;
    try{inv.setItem(slot,token);bag.runes=bag.runes.filter(r=>r.uid!==uid);bag.equipped=bag.equipped.map(id=>id===uid?null:id);writeRuneBag(p,bag);}
    catch(error){inv.setItem(slot,previous);p.setDynamicProperty(RUNE_BAG_KEY,old);throw error;}
    return {ok:true};
  }catch(error){return {ok:false,reason:String(error)};}
}
export function migrateChestRune(p){
  const eq=p.getComponent('minecraft:equippable'),chest=eq?.getEquipment(EquipmentSlot.Chest);
  const legacyId=chest?.getDynamicProperty(RUNE_KEY),id=legacyId==='haste'?'mana':legacyId;if(!RUNES[id])return {ok:true,migrated:false};
  const bag=readRuneBag(p);if(bag.runes.length>=RUNE_CAPACITY)return {ok:false,reason:'룬 이전을 위해 보관함 빈 칸이 필요합니다.'};
  const oldBag=JSON.stringify(bag),oldChest=chest.clone(),rune=addRuneRecord(bag,id,Math.min(10,upgradeLevel(chest,'rune')*2));
  const slot=bag.equipped.findIndex((uid,i)=>uid===null&&i<bag.unlockedSlots);if(slot>=0&&!equippedRunes(p).some(r=>r.id===id))bag.equipped[slot]=rune.uid;
  chest.setDynamicProperty(RUNE_KEY,undefined);chest.setDynamicProperty(RUNE_LEVEL_KEY,undefined);chest.setLore(chest.getLore().filter(line=>!line.startsWith('§8룬:')));
  try{writeRuneBag(p,bag);if(!eq.setEquipment(EquipmentSlot.Chest,chest))throw Error('기존 흉갑 저장 실패');}
  catch(error){p.setDynamicProperty(RUNE_BAG_KEY,oldBag);eq.setEquipment(EquipmentSlot.Chest,oldChest);return {ok:false,reason:String(error)};}
  return {ok:true,migrated:true};
}

```

## RPG_BP_v0603/scripts/core/runeMenu.js

```js
import {openRuneSlotUpgradeMenu} from './runeSlotUpgrade.js';
import {runeRarity,rarityBadge} from '../data/rarity.js';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { RUNES } from '../data/equipment.js';
import { readRuneBag,depositRune,equipRune,unequipRune,withdrawRune,removeRune,migrateChestRune,migrateRetiredRunes,RUNE_CAPACITY,RUNE_SLOTS } from './runeInventory.js';
import { describeRune,openRuneUpgradeMenu } from './upgrades.js';
import { showForm } from './skillMenu.js';
const open=new Set();
export async function openRuneMenu(p){
  if(open.has(p.id))return;open.add(p.id);
  try{
    migrateRetiredRunes(p);
    const migration=migrateChestRune(p);if(!migration.ok)p.sendMessage('§e'+migration.reason);
    for(let loop=0;loop<80&&p.isValid;loop++){
      const bag=readRuneBag(p);
      const slots=bag.equipped.map((uid,i)=>{const r=bag.runes.find(r=>r.uid===uid);return i>=bag.unlockedSlots?`§8${i+1}번: 잠김 (슬롯 강화로 해금)§r`:`${i+1}번: ${r?rarityBadge(runeRarity(r.grade))+' '+RUNES[r.id].name+' +'+r.level:'비어 있음'}`;}).join('\n');
      const form=new ActionFormData().title('룬 전용 보관함').body(`${bag.runes.length}/${RUNE_CAPACITY}칸\n${slots}\n\n${bag.unlockedSlots}/${RUNE_SLOTS}개 장착 가능·같은 종류 중복 불가. 갑옷과 독립적으로 효과를 받습니다.\n강화한 룬은 보관함에서 관리하며 일반 등급 +0 룬만 일반 가방으로 꺼낼 수 있습니다.`);
      form.button('일반 가방의 룬 넣기');form.button('룬 강화');form.button('장착 슬롯 강화 · 해금');
      for(const r of bag.runes)form.button(`${bag.equipped.includes(r.uid)?'§a[장착] ':''}${RUNES[r.id].name} +${r.level}\n${describeRune(r.id,r.level,r.grade)}`);
      form.button('닫기');const choice=await showForm(form,p);
      if(!choice||choice.canceled||choice.selection==null||choice.selection>=bag.runes.length+3)return;
      if(choice.selection===0){
        const inv=p.getComponent('minecraft:inventory')?.container,entries=[];
        const f=new ActionFormData().title('룬 넣기').body('한 번 선택하면 룬 1개를 보관합니다.');
        if(inv)for(let i=0;i<inv.size;i++){const t=inv.getItem(i),id=t?.typeId?.replace('rpg:rune_','');if(t?.typeId==='rpg:rune_'+id&&RUNES[id]){entries.push(i);f.button(RUNES[id].name+' ×'+t.amount);}}
        f.button('뒤로');const r=await showForm(f,p);if(r&&!r.canceled&&r.selection<entries.length){const result=depositRune(p,entries[r.selection]);if(!result.ok)p.sendMessage('§c'+result.reason);}continue;
      }
      if(choice.selection===1){await openRuneUpgradeMenu(p);continue;}
      if(choice.selection===2){await openRuneSlotUpgradeMenu(p);continue;}
      const rune=bag.runes[choice.selection-3];
      const f=new ActionFormData().title(RUNES[rune.id].name+' +'+rune.level).body(describeRune(rune.id,rune.level,rune.grade));
      for(let i=0;i<RUNE_SLOTS;i++)f.button(i<bag.unlockedSlots?`${i+1}번 칸 장착`:`§8${i+1}번 칸 잠김 · 슬롯 강화`);
      f.button('장착 해제').button('일반 가방으로 꺼내기 (일반 +0)').button('룬 삭제').button('뒤로');
      const r=await showForm(f,p);if(!r||r.canceled||r.selection==null)continue;
      if(r.selection<RUNE_SLOTS){if(r.selection>=bag.unlockedSlots){await openRuneSlotUpgradeMenu(p);continue;}const result=equipRune(p,rune.uid,r.selection);if(!result.ok)p.sendMessage('§c'+result.reason);}
      else if(r.selection===RUNE_SLOTS)unequipRune(p,rune.uid);
      else if(r.selection===RUNE_SLOTS+1){const result=withdrawRune(p,rune.uid);if(!result.ok)p.sendMessage('§c'+result.reason);}
      else if(r.selection===RUNE_SLOTS+2){const yes=await showForm(new MessageFormData().title('룬 삭제').body('이 룬과 강화 단계가 영구 삭제됩니다.').button1('취소').button2('삭제'),p);if(yes&&!yes.canceled&&yes.selection===1)removeRune(p,rune.uid);}
    }
  }catch(error){try{p.sendMessage('§c[RPG] '+String(error));}catch{}}
  finally{open.delete(p.id);}
}

```

## RPG_BP_v0603/scripts/core/runeSlotUpgrade.js

```js
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {RUNE_SLOT_UNLOCK_COSTS} from '../data/upgrades.js';
import {RUNE_BAG_KEY,RUNE_SLOTS,readRuneBag,writeRuneBag} from './runeInventory.js';
import {WALLET_KEY,getWallet,setWallet,canAfford,walletText} from './wallet.js';
import {showForm} from './skillMenu.js';

export function runeSlotQuote(player){
  const bag=readRuneBag(player),cost=RUNE_SLOT_UNLOCK_COSTS[bag.unlockedSlots];
  return {unlockedSlots:bag.unlockedSlots,nextSlot:cost?bag.unlockedSlots+1:undefined,cost};
}
export function upgradeRuneSlot(player,expectedSlots){
  try{
    const bag=readRuneBag(player),cost=RUNE_SLOT_UNLOCK_COSTS[bag.unlockedSlots];
    if(!cost)return {ok:false,reason:'이미 모든 룬 장착 슬롯을 해금했습니다.'};
    if(expectedSlots!==undefined&&expectedSlots!==bag.unlockedSlots)return {ok:false,reason:'장착 슬롯 수가 변경됐습니다. 다시 확인하세요.'};
    const wallet=getWallet(player);
    if(!canAfford(wallet,cost))return {ok:false,reason:'슬롯 해금에 필요한 골드 또는 룬 가루가 부족합니다.'};
    const originalBag=player.getDynamicProperty(RUNE_BAG_KEY),originalWallet=player.getDynamicProperty(WALLET_KEY);
    const nextWallet={gold:wallet.gold-cost.gold,stone:wallet.stone-cost.stone,dust:wallet.dust-cost.dust};
    bag.unlockedSlots++;
    try{setWallet(player,nextWallet);writeRuneBag(player,bag);}
    catch(error){
      let recovered=true;
      try{player.setDynamicProperty(RUNE_BAG_KEY,originalBag);}catch{recovered=false;}
      try{player.setDynamicProperty(WALLET_KEY,originalWallet);}catch{recovered=false;}
      if(!recovered)console.error('[RPG rune slots] rollback incomplete: '+String(error));
      return {ok:false,reason:recovered?'슬롯 저장에 실패해 해금을 취소하고 재화를 복구했습니다.':'슬롯 복구에 실패했습니다. 관리자에게 콘텐츠 로그 확인을 요청하세요.'};
    }
    return {ok:true,unlockedSlots:bag.unlockedSlots,cost};
  }catch(error){return {ok:false,reason:'슬롯 강화 오류: '+String(error)};}
}
const open=new Set();
export async function openRuneSlotUpgradeMenu(player){
  if(open.has(player.id))return;open.add(player.id);
  try{
    for(let i=0;i<20&&player.isValid;i++){
      const quote=runeSlotQuote(player);
      const form=new ActionFormData().title('룬 장착 슬롯 강화').body(walletText(getWallet(player))+
        `\n\n장착 가능: ${quote.unlockedSlots} / ${RUNE_SLOTS}개\n기본 3칸에서 순서대로 4·5번째 슬롯을 해금합니다.\n성공률 100% · 해금한 슬롯은 영구 유지됩니다.\n같은 종류의 룬은 하나만 장착할 수 있습니다.`+
        (quote.cost?`\n\n다음 해금: ${quote.nextSlot}번째 슬롯\n비용: 골드 ${quote.cost.gold.toLocaleString()} · 룬 가루 ${quote.cost.dust}개`:'\n\n모든 슬롯을 해금했습니다.'));
      if(quote.cost)form.button(`${quote.nextSlot}번째 슬롯 강화 해금\n성공률 100%`);
      form.button('뒤로');
      const choice=await showForm(form,player);
      if(!choice||choice.canceled||choice.selection!==0||!quote.cost)return;
      const confirm=await showForm(new MessageFormData().title('룬 슬롯 해금 확인')
        .body(`${quote.nextSlot}번째 장착 슬롯을 해금할까요?\n장착 가능 ${quote.unlockedSlots}개 → ${quote.nextSlot}개\n\n골드 ${quote.cost.gold.toLocaleString()} · 룬 가루 ${quote.cost.dust}개 소비\n성공률 100% · 기존 룬과 강화 단계는 유지됩니다.`)
        .button1('취소').button2('강화 해금'),player);
      if(!confirm||confirm.canceled||confirm.selection!==1)continue;
      const result=upgradeRuneSlot(player,quote.unlockedSlots);
      player.sendMessage(result.ok?`§a[RPG] ${result.unlockedSlots}번째 룬 장착 슬롯을 해금했습니다!`:'§c[RPG] '+result.reason);
    }
  }catch(error){try{player.sendMessage('§c[RPG] 슬롯 강화 메뉴 오류: '+String(error));}catch{}}
  finally{open.delete(player.id);}
}

```

## RPG_BP_v0603/scripts/core/upgrades.js

```js
import {openRuneSlotUpgradeMenu} from './runeSlotUpgrade.js';
import {itemGrade} from '../data/grades.js';
import {COMMON_WEAPONS} from '../data/commonWeapons.js';
import {classWeapon} from '../data/classWeapons.js';
import {gearFingerprint,setGearLevel} from './gearState.js';
import {openFusionMenu} from './fusion.js';
import {runeRarity,armorRarity,rarityBadge} from '../data/rarity.js';
import {decorateRarity} from './rarityLabels.js';
import {openArmorTransfer} from './armorTransfer.js';
import { EquipmentSlot } from '@minecraft/server';
import { ActionFormData, MessageFormData } from '@minecraft/server-ui';
import { armorInfo, RUNES, RUNE_KEY } from '../data/equipment.js';
import { ARMOR_LEVEL_KEY, RUNE_LEVEL_KEY, upgradeLevel, upgradeCost, upgradedRune, enhancementRates, rollEnhancement, catalystAllowed, CATALYST_ID, MAX_CATALYSTS } from '../data/upgrades.js';
import { getWallet, setWallet, canAfford, walletText } from './wallet.js';
import { showForm } from './skillMenu.js';
import { readRuneBag, writeRuneBag, migrateChestRune } from './runeInventory.js';

const SLOTS = () => [
  {slot:EquipmentSlot.Head, part:'helmet', name:'투구'},
  {slot:EquipmentSlot.Chest, part:'chestplate', name:'흉갑'},
  {slot:EquipmentSlot.Legs, part:'leggings', name:'각반'},
  {slot:EquipmentSlot.Feet, part:'boots', name:'장화'},
];
export function describeRune(id, rank, grade=0) {
  const r = upgradedRune(RUNES[id],rank,grade);
  if (!r) return '없음';
  const values = [];
  if (r.physical && r.physical>1) values.push(`물리 스킬 +${Number(((r.physical-1)*100).toFixed(1))}%`);
  if (r.magic && r.magic>1) values.push(`마법 스킬 +${Number(((r.magic-1)*100).toFixed(1))}%`);
  if(rank>0&&['power','arcane'].includes(id))values.push('공용·직업 무기 근접 평타 +'+Number((((r.physical??r.magic)-1)*100).toFixed(1))+'%');
  if (r.defense) values.push('RPG 방어력 +'+Number(r.defense.toFixed(1))+' (피해 감소 '+Number((r.defense*.35).toFixed(2))+'%)');
  if (r.health) values.push(`최대 HP +${Number(r.health.toFixed(2))}`);
  if (r.manaRegenPercent) values.push(`초당 최대 마나의 +${Number((r.manaRegenPercent*100).toFixed(1))}% 회복`);
  if (r.lifesteal) values.push('준 피해의 '+Number((r.lifesteal*100).toFixed(1))+'% 흡혈');
  if (r.ward) values.push('저항 '+(r.wardAmplifier+1));
  if (r.speed) values.push('신속 '+(r.speedAmplifier+1));
  for (const t of r.extraText??[]) values.push(t);
  return rarityBadge(runeRarity(grade))+' · '+values.join(', ');
}

function fingerprint(item) {return gearFingerprint(item);}
export function enhancementQuote(player,kind,slot) {
  if(kind==='rune') {
    const rune=readRuneBag(player).runes.find(r=>r.uid===slot);if(!rune)return undefined;
    return {kind,slot,level:rune.level,runeId:rune.id,fingerprint:JSON.stringify(rune),cost:upgradeCost(kind,rune.level),name:RUNES[rune.id].name,
      effect:describeRune(rune.id,rune.level,rune.grade)+'\n→ '+describeRune(rune.id,rune.level+1,rune.grade)};
  }
  if(kind==='weapon'){
    if(slot!==EquipmentSlot.Mainhand)return undefined;
    const item=player.getComponent('minecraft:equippable')?.getEquipment(slot),jobWeapon=classWeapon(item?.typeId),w=COMMON_WEAPONS.find(w=>w.id===item?.typeId)??jobWeapon;
    if(!w||item.amount!==1)return undefined;const level=upgradeLevel(item,kind);
    return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:w.name,effect:jobWeapon?`직업 무기 · 등급·승급 없음\n근접 피해 +${level} → +${level+1}\n물리·마법 스킬 피해 +${level*2}% → +${(level+1)*2}%`:`${rarityBadge(itemGrade(item))} 등급 유지 · 강화 근접 피해 +${level} → +${level+1}`};
  }
  if(kind!=='armor')return undefined;
  const definition=SLOTS().find(s=>s.slot===slot),item=player.getComponent('minecraft:equippable')?.getEquipment(slot);
  const info=armorInfo(item?.typeId);if(!definition||info?.part!==definition.part)return undefined;
  const level=upgradeLevel(item,'armor');return {kind,slot,level,fingerprint:fingerprint(item),cost:upgradeCost(kind,level),name:info.name+' '+definition.name,effect:`${rarityBadge(itemGrade(item))} 등급 유지\n부위 강화 HP +${level} → +${level+1}`};
}

export function enhanceEquipped(player,kind,slot,expectedFingerprint,options={}) {
  try {
    const quote=enhancementQuote(player,kind,slot);
    if (!quote) return {ok:false,reason:'강화할 RPG 갑옷·공용·직업 무기·보관 룬이 없습니다.'};
    if (!quote.cost) return {ok:false,reason:'이미 최대 강화 단계입니다.'};
    if (expectedFingerprint!==undefined&&quote.fingerprint!==expectedFingerprint) return {ok:false,reason:'장비 또는 강화 단계가 변경됐습니다. 다시 선택하세요.'};
    const catalystCount=options.catalystCount??0;
    const rates=enhancementRates(kind,quote.level,catalystCount);
    if (!rates) return {ok:false,reason:'촉매 수량은 0~5개이며, 갑옷·무기 +5·룬 +2부터 사용할 수 있습니다.'};
    const wallet=getWallet(player);
    if (!canAfford(wallet,quote.cost)) return {ok:false,reason:'강화에 필요한 재화가 부족합니다.'};
    const eq=player.getComponent('minecraft:equippable');
    const inventory=player.getComponent('minecraft:inventory')?.container;
    const catalysts=[];
    let needed=catalystCount;
    if(needed>0&&inventory)for(let i=0;i<inventory.size&&needed>0;i++) {
      const token=inventory.getItem(i);
      if(token?.typeId!==CATALYST_ID||token.amount<1)continue;
      const take=Math.min(needed,token.amount);
      catalysts.push({slot:i,original:token.clone(),take});needed-=take;
    }
    if(needed>0)return {ok:false,reason:`강화 촉매 ${catalystCount}개가 필요합니다.`};
    const original=kind!=='rune'?eq.getEquipment(slot).clone():readRuneBag(player);
    const outcome=rollEnhancement(rates,options.random??Math.random);
    let level=quote.level,target;
    if(outcome==='success')level++;
    if(outcome==='downgrade')level=Math.max(0,level-1);
    if(kind!=='rune') {
      target=original.clone();
      if(outcome==='destroy'){target=undefined;level=0;}
      else target=setGearLevel(target,kind,level);
    }else{
      target=JSON.parse(JSON.stringify(original));
      if(outcome==='destroy'){level=0;target.runes=target.runes.filter(r=>r.uid!==slot);target.equipped=target.equipped.map(uid=>uid===slot?null:uid);}
      else target.runes.find(r=>r.uid===slot).level=level;
    }
    const next=Object.fromEntries(Object.entries(wallet).map(([k,v])=>[k,v-quote.cost[k]]));
    let debited=false,catalystTouched=false;
    try {
      setWallet(player,next);debited=true;
      if(catalysts.length) {
        catalystTouched=true;
        for(const entry of catalysts) {
          if(entry.original.amount===entry.take)inventory.setItem(entry.slot,undefined);
          else {const remaining=entry.original.clone();remaining.amount-=entry.take;inventory.setItem(entry.slot,remaining);}
        }
      }
      if(kind!=='rune'){if(!eq.setEquipment(slot,target))throw Error('장비 저장 실패');}else writeRuneBag(player,target);
    } catch(error) {
      let recovered=true;
      try {if(kind!=='rune'){if(!eq.setEquipment(slot,original))recovered=false;}else writeRuneBag(player,original);}catch{recovered=false;}
      if(catalystTouched)for(const entry of catalysts)try{inventory.setItem(entry.slot,entry.original);}catch{recovered=false;}
      if(debited)try{setWallet(player,wallet);}catch{recovered=false;}
      if(!recovered)console.error('[RPG upgrade] rollback incomplete: '+String(error));
      return {ok:false,reason:recovered?'강화를 저장하지 못해 취소하고 재화를 복구했습니다.':'강화 복구에 실패했습니다. 관리자에게 콘텐츠 로그 확인을 요청하세요.'};
    }
    return {ok:true,outcome,level,cost:quote.cost,rates,catalystCount};
  }catch(error){return {ok:false,reason:'강화 오류: '+String(error)};}
}

const menus = new Set();
const KIND_NAMES = {rune:'룬',armor:'갑옷',weapon:'무기'};
function costText(cost) {
  if(!cost)return '§a최대 강화 +10';
  return `골드 ${cost.gold.toLocaleString()}`+(cost.stone?` · 강화석 ${cost.stone}`:'')+(cost.dust?` · 룬 가루 ${cost.dust}`:'');
}
function quoteButton(quote) {
  return `${quote.name} +${quote.level}\n${costText(quote.cost)}`;
}
async function attemptUpgrade(player,quote) {
  if (!quote.cost) {player.sendMessage('§e[RPG] 이미 최대 강화 단계입니다.');return;}
  let catalystCount=0;
  if(catalystAllowed(quote.kind,quote.level)) {
    const inventory=player.getComponent('minecraft:inventory')?.container;
    let owned=0;
    if(inventory)for(let i=0;i<inventory.size;i++){const token=inventory.getItem(i);if(token?.typeId===CATALYST_ID)owned+=token.amount;}
    const maximum=Math.min(MAX_CATALYSTS,owned);
    const form=new ActionFormData().title('강화 촉매 수량')
      .body(`보유 촉매 ${owned}개. 한 번에 최대 5개 사용.\n1개당 성공률 +9%p, 파괴확률 -3%p (최소 0%).\n완료된 모든 결과에서 선택 수량을 소비합니다.`);
    for(let count=0;count<=maximum;count++) {
      const preview=enhancementRates(quote.kind,quote.level,count);
      form.button(`${count===0?'촉매 사용 안 함':count+'개 사용'}\n성공 ${preview.success}% / 파괴 ${preview.destroy}%`);
    }
    form.button('취소');
    const choice=await showForm(form,player);
    if(!choice||choice.canceled||choice.selection==null||choice.selection>maximum)return;
    catalystCount=choice.selection;
  }
  const rates=enhancementRates(quote.kind,quote.level,catalystCount);
  const percentages=`성공 ${rates.success}% / 유지 실패 ${rates.fail}%\n1단계 강등 ${rates.downgrade}% / 파괴 ${rates.destroy}%`;
  const destruction=quote.kind!=='rune'?'장비 파괴 시 해당 장비만 소멸하고 전용 보관함 룬은 유지됩니다.':'룬 파괴 시 해당 보관 룬만 소멸하며 장착도 해제됩니다.';
  const confirm=await showForm(new MessageFormData().title('위험 강화 확인')
    .body(`${quote.name} +${quote.level} → +${quote.level+1}\n${quote.effect}\n\n${percentages}\n${destruction}\n\n비용: ${costText(quote.cost)}\n${catalystCount?'강화 촉매 '+catalystCount+'개 사용\n':''}모든 결과에서 비용이 소비됩니다.`)
    .button1('취소').button2('강화'),player);
  if(!confirm||confirm.canceled||confirm.selection!==1)return;
  const attempt=enhanceEquipped(player,quote.kind,quote.slot,quote.fingerprint,{catalystCount});
  if(!attempt.ok)player.sendMessage('§c[RPG] '+attempt.reason);
  else {
    const messages={success:`§a강화 성공! +${attempt.level}`,fail:'§e강화 실패: 단계 유지',downgrade:`§6강등: +${attempt.level}`,destroy:quote.kind!=='rune'?'§c장비 파괴: 해당 장비 소멸':'§c룬 파괴: 해당 보관 룬 소멸'};
    player.sendMessage('[RPG] '+quote.name+' · '+messages[attempt.outcome]);
  }
}

export async function openUpgradeMenu(player) {await upgradeSession(player,'root');}
export async function openRuneUpgradeMenu(player) {await upgradeSession(player,'runeTypes');}
export async function openArmorUpgradeMenu(player) {await upgradeSession(player,'armor');}
export async function openWeaponUpgradeMenu(player) {await upgradeSession(player,'weapon');}

async function upgradeSession(player,initialPage) {
  if(menus.has(player.id))return;
  menus.add(player.id);
  try {
    const migration=migrateChestRune(player);if(!migration.ok)player.sendMessage('§e'+migration.reason);
    let page=initialPage,runeId;
    for(let count=0;count<160&&player.isValid;count++) {
      const form=new ActionFormData();
      let options=[];
      const wallet=walletText(getWallet(player));
      if(page==='root') {
        form.title('RPG 강화 메뉴').body(wallet+'\n\n강화할 종류를 선택하세요.\n룬·갑옷·무기는 각각의 화면에서 관리합니다.');
        form.button('§d룬 강화\n종류 선택 · 보관 룬 강화')
          .button('§b갑옷 강화\n착용 부위별 강화 · 강화 이전')
          .button('§6무기 강화\n손에 든 공용·직업 무기 강화')
          .button('장비 등급 합성').button('닫기');
      } else if(page==='runeTypes') {
        const bag=readRuneBag(player);
        options=Object.entries(RUNES);
        form.title('룬 강화 · 종류 선택').body(wallet+'\n\n강화할 룬 종류를 고르세요.\n장착하지 않은 보관 룬도 강화할 수 있습니다.\n일반 가방의 룬은 룬 보관함에 넣어 주세요.');
        for(const [id,definition] of options) {
          const runes=bag.runes.filter(r=>r.id===id);
          form.button(`${definition.name}\n보유 ${runes.length}개 · 강화 가능 ${runes.filter(r=>r.level<10).length}개`);
        }
        form.button('장착 슬롯 강화 · 해금').button('강화 메뉴로');
      } else if(page==='runes') {
        const bag=readRuneBag(player);
        options=bag.runes.filter(r=>r.id===runeId).map(r=>({rune:r,quote:enhancementQuote(player,'rune',r.uid)}));
        form.title('룬 강화 · '+RUNES[runeId].name).body(wallet+'\n\n강화할 룬 1개를 선택하세요.\n같은 종류도 등급·강화 단계·보관 번호로 구분합니다.\n촉매는 현재 +2부터 최대 5개 사용할 수 있습니다.'+(options.length?'':'\n\n이 종류의 룬이 보관함에 없습니다.'));
        for(const {rune,quote} of options) {
          const slot=bag.equipped.indexOf(rune.uid);
          form.button(`${slot>=0?'§a['+(slot+1)+'번 장착] ':''}${rarityBadge(runeRarity(rune.grade))} +${rune.level} · 보관 #${rune.uid}\n${costText(quote.cost)}`);
        }
        form.button('룬 종류 선택으로');
      } else {
        const kind=page;
        form.title(KIND_NAMES[kind]+' 강화').body(wallet+(kind==='armor'?
          '\n\n착용 중인 RPG 갑옷 부위를 선택하세요.\n최대 +10 · 부위 강화당 최대 HP +1\n총 HP는 게임 효과에 따라 4 HP 단위로 근사합니다.':
          '\n\n주 손에 공용·직업 무기 1개를 들고 선택하세요.\n최대 +10 · 강화당 근접 피해 +1\n직업 무기는 단계당 물리·마법 스킬 피해 +2%')+
          '\n촉매는 현재 +5부터 최대 5개 사용할 수 있습니다.');
        options=kind==='armor'?SLOTS().map(s=>({name:s.name,quote:enhancementQuote(player,kind,s.slot)})):
          [{name:'주 손 무기',quote:enhancementQuote(player,kind,EquipmentSlot.Mainhand)}];
        for(const {name,quote} of options)form.button(quote?quoteButton(quote):name+'\n강화할 RPG 장비 없음');
        if(kind==='armor')form.button('갑옷 강화 이전');
        form.button('강화 메뉴로');
      }
      const choice=await showForm(form,player);
      if(!choice||choice.canceled||choice.selection==null)return;
      const selected=choice.selection;
      if(page==='root') {
        if(selected===0)page='runeTypes';
        else if(selected===1)page='armor';
        else if(selected===2)page='weapon';
        else if(selected===3)await openFusionMenu(player);
        else return;
      } else if(page==='runeTypes') {
        if(selected===options.length){await openRuneSlotUpgradeMenu(player);continue;}
        if(selected===options.length+1){page='root';continue;}
        if(!options[selected])return;
        runeId=options[selected][0];page='runes';
      } else if(page==='runes') {
        if(selected===options.length){page='runeTypes';continue;}
        if(!options[selected])return;
        await attemptUpgrade(player,options[selected].quote);
      } else {
        if(selected<options.length) {
          const entry=options[selected];if(!entry)return;
          if(entry.quote)await attemptUpgrade(player,entry.quote);
          else player.sendMessage('§e[RPG] '+entry.name+'에 강화할 RPG 장비가 없습니다.');
        } else if(page==='armor'&&selected===options.length)await openArmorTransfer(player);
        else page='root';
      }
    }
  } catch(error) {try{player.sendMessage('§c[RPG] 강화 메뉴 오류: '+String(error));}catch{}}
  finally {menus.delete(player.id);}
}

```

## RPG_BP_v0603/scripts/data/upgrades.js

```js
import {GRADE_MULTIPLIERS,gradeRank} from './grades.js';
export const ARMOR_LEVEL_KEY = 'rpg:armor_upgrade';
export const RUNE_LEVEL_KEY = 'rpg:rune_upgrade';
export const ARMOR_MAX = 10;
export const RUNE_MAX = 10;
export const WEAPON_MAX = 10;
export const WEAPON_LEVEL_KEY = 'rpg:weapon_upgrade';

export function upgradeLevel(item, kind) {
  const key = kind === 'armor' ? ARMOR_LEVEL_KEY : kind === 'weapon' ? WEAPON_LEVEL_KEY : RUNE_LEVEL_KEY;
  const max = kind === 'armor' ? ARMOR_MAX : RUNE_MAX;
  const value = item?.getDynamicProperty(key);
  return Number.isInteger(value) ? Math.max(0, Math.min(max, value)) : 0;
}

export const RUNE_DUST_COSTS=Object.freeze([1,1,2,3,5,5,5,6,6,7]);
// Costs refer to the NEXT level, and are consumed for all completed attempts.
export function upgradeCost(kind, current) {
  const max = ['armor','weapon','rune'].includes(kind) ? 10 : 0;
  if (!Number.isInteger(current) || current < 0 || current >= max) return undefined;
  const next = current + 1;
  return kind !== 'rune'
    ? {gold:200*next*next, stone:2*next, dust:0}
    : {gold:Math.round(2.5*next*next)*5, stone:0, dust:RUNE_DUST_COSTS[current]};
}

export const CATALYST_ID = 'rpg:enhancement_catalyst';
export const MAX_CATALYSTS = 5;
// Rows are success / unchanged failure / downgrade / destruction, in percent.
const ARMOR_RATES = [
  [95,5,0,0], [90,10,0,0], [80,18,2,0], [70,23,7,0], [60,28,10,2],
  [50,30,16,4], [40,32,22,6], [30,34,27,9], [22,35,30,13], [15,35,32,18],
];
// +10 rune curve follows the armor curve; catalysts remain available from +2.
const RUNE_RATES = [[95,5,0,0],[90,10,0,0],[70,28,2,0],[65,28,7,0],...ARMOR_RATES.slice(4)];
export function catalystAllowed(kind,current) {return kind==='armor'||kind==='weapon'?current>=5:kind==='rune'&&current>=2;}
export function enhancementRates(kind,current,catalystCount=0) {
  if (!Number.isInteger(catalystCount)||catalystCount<0||catalystCount>MAX_CATALYSTS) return undefined;
  const row = (kind==='armor'||kind==='weapon'?ARMOR_RATES:kind==='rune'?RUNE_RATES:[])[current];
  if (!row) return undefined;
  let [success,fail,downgrade,destroy] = row;
  if (catalystCount>0) {
    if (!catalystAllowed(kind,current)) return undefined;
    destroy = Math.max(0,destroy-3*catalystCount);
    success = Math.min(success+9*catalystCount,100-downgrade-destroy);
    fail = 100-success-downgrade-destroy;
  }
  return {success,fail,downgrade,destroy};
}
export function rollEnhancement(rates,random=Math.random) {
  const value=random();
  if (!Number.isFinite(value)||value<0||value>=1) throw Error('강화 난수 범위 오류');
  const roll=value*100;
  if (roll<rates.success) return 'success';
  if (roll<rates.success+rates.fail) return 'fail';
  if (roll<rates.success+rates.fail+rates.downgrade) return 'downgrade';
  return 'destroy';
}

// ── 영웅·전설·신화 룬 +8/+9/+10 추가 능력 ─────────────────────────────
// 수치는 영웅 기준이며 전설 ×1.5, 신화 ×2 로 커집니다. 효과는 +8, +9, +10 에서 누적됩니다.
// aura 는 장착 중 계속 유지되는 상태 효과(증폭 0 = I단계)입니다.
export const EXTRA_MIN_GRADE = 4; // 영웅
export const EXTRA_SCALE = Object.freeze({ 4: 1, 5: 1.5, 6: 2 });
const AURA_NAMES = Object.freeze({ speed: '신속 I', fire_resistance: '화염 저항', regeneration: '재생 I' });
const RUNE_EXTRAS = Object.freeze({
  power:      { 8: { physical: 0.03 },          9: { aura: { speed: 0 } },            10: { physical: 0.04 } },
  arcane:     { 8: { magic: 0.03 },             9: { manaRegenPercent: 0.004 },        10: { magic: 0.04 } },
  ward:       { 8: { health: 6 },               9: { aura: { regeneration: 0 } },      10: { health: 10 } },
  mana:       { 8: { manaRegenPercent: 0.003 }, 9: { aura: { speed: 0 } },             10: { manaRegenPercent: 0.005 } },
  vitality:   { 8: { health: 6 },               9: { aura: { regeneration: 0 } },      10: { health: 10 } },
  absorption: { 8: { lifesteal: 0.01 },         9: { health: 6 },                      10: { lifesteal: 0.015 } },
});
function runeKind(rune) {
  if (rune.defense) return 'ward';
  if (rune.physical) return 'power';
  if (rune.magic) return 'arcane';
  if (rune.manaRegenPercent) return 'mana';
  if (rune.lifesteal) return 'absorption';
  if (rune.health) return 'vitality';
  return undefined;
}
function fmtExtra(key, v) {
  if (key === 'physical') return '물리 스킬 +' + Number((v * 100).toFixed(2)) + '%p';
  if (key === 'magic') return '마법 스킬 +' + Number((v * 100).toFixed(2)) + '%p';
  if (key === 'manaRegenPercent') return '초당 마나 +' + Number((v * 100).toFixed(2)) + '%p';
  if (key === 'lifesteal') return '흡혈 +' + Number((v * 100).toFixed(2)) + '%p';
  return '최대 HP +' + Number(v.toFixed(2));
}
function applyRuneExtras(result, kind, rank, gradeIdx) {
  const table = RUNE_EXTRAS[kind];
  const scale = EXTRA_SCALE[gradeIdx] ?? 1;
  if (!table) return;
  for (const lv of [8, 9, 10]) {
    if (rank < lv || !table[lv]) continue;
    for (const [key, base] of Object.entries(table[lv])) {
      if (key === 'aura') {
        for (const [eid, amp] of Object.entries(base)) {
          result.auras[eid] = Math.max(result.auras[eid] ?? -1, amp);
          result.extraText.push('[+' + lv + '] ' + (AURA_NAMES[eid] ?? eid) + ' 상시 유지');
        }
        continue;
      }
      const add = base * scale;
      result[key] = (result[key] ?? (key === 'physical' || key === 'magic' ? 1 : 0)) + add;
      result.extraText.push('[+' + lv + '] ' + fmtExtra(key, add));
    }
  }
}

export function upgradedRune(rune, level, grade=0) {
  if (!rune) return undefined;
  const rank = Math.max(0, Math.min(RUNE_MAX, Number.isInteger(level) ? level : 0));
  const result = {...rune, wardAmplifier:0, speedAmplifier:0};
  if (rune.physical) result.physical += rank*0.034;
  if (rune.magic) result.magic += rank*0.034;
  if (rune.manaRegenPercent) result.manaRegenPercent = (10+rank*2)/1000;
  if (rune.health) result.health = rune.health+rank*2;
  if (rune.lifesteal) result.lifesteal=(50+rank*7)/1000;
  if (rune.defense) {
    result.health=rank;
    result.defense=rune.defense+rank*2;
  }
  const multiplier=GRADE_MULTIPLIERS[gradeRank(grade)];
  for(const key of ['physical','magic'])if(result[key])result[key]=1+(result[key]-1)*multiplier;
  for(const key of ['health','manaRegen','manaRegenPercent','lifesteal','defense'])if(result[key])result[key]*=multiplier;
  result.auras = {};
  result.extraText = [];
  const gradeIdx = gradeRank(grade);
  if (rank >= 8 && gradeIdx >= EXTRA_MIN_GRADE) { const kind = runeKind(rune); if (kind) applyRuneExtras(result, kind, rank, gradeIdx); }
  return result;
}

// Rune equipment slots unlock in order; unlike item enhancement, unlocks always succeed.
export const RUNE_SLOT_UNLOCK_COSTS = Object.freeze({
  3:Object.freeze({gold:10000,stone:0,dust:20}),
  4:Object.freeze({gold:30000,stone:0,dust:50}),
});

```

## RPG_BP_v0603/scripts/gameplayEntry.js

```js
// RPG gameplay module - independent from slash-command registration pack.
import * as mc from "@minecraft/server";
import { initializeGameplay } from "./main.js";
let started = false;
function safeStart() {
  if (started) return;
  started = true;
  try { initializeGameplay(); }
  catch (e) { console.error("[RPG v0.6.7 gameplay] initialization failed: " + String(e?.stack ?? e)); }
}
try { mc.system.run(safeStart); }
catch (e) { console.error("[RPG v0.6.7 gameplay] schedule failed: " + String(e)); }
try {
  mc.world.afterEvents.worldLoad.subscribe(() => {
    if (!started) mc.system.run(safeStart);
  });
} catch (e) { console.warn("[RPG v0.6.7 gameplay] worldLoad recovery unavailable: " + String(e)); }

// Hydra: guard against any existing burning visual effects after pack upgrade.
// Fire immunity is configured in entities/hydra_boss.json.
try {
  mc.system.runInterval(() => {
    for (const id of ["overworld", "nether", "the_end"]) {
      try {
        const dim = mc.world.getDimension(id);
        for (const hydra of dim.getEntities({ type: "rpg:hydra_boss" })) {
          try {
            if (hydra.getComponent("minecraft:onfire")) hydra.extinguishFire(false);
          } catch (_) { /* invalid or unloaded entity */ }
        }
      } catch (_) { /* unloaded or inaccessible dimension */ }
    }
  }, 10);
} catch (e) { console.warn("[RPG] hydra fire cleanup unavailable: " + String(e)); }

```

## RPG_Commands_BP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Commands BP v0.6.7",
    "description": "RPG v0.6.7 · 룬 장착 슬롯 강화 해금 · 기본 3개에서 최대 5개",
    "uuid": "533cff27-4591-48cb-85fb-540c8bcbcc72",
    "version": [
      0,
      6,
      7
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "script",
      "language": "javascript",
      "uuid": "9518dff9-cc69-4ea4-adb6-2762b6291c45",
      "entry": "scripts/commands.js",
      "version": [
        0,
        6,
        7
      ]
    }
  ],
  "dependencies": [
    {
      "uuid": "a1b49558-2a78-4754-bae7-1c5ec7a84303",
      "version": [
        0,
        6,
        7
      ]
    },
    {
      "module_name": "@minecraft/server",
      "version": "2.2.0"
    }
  ]
}

```

## RPG_Commands_BP_v0603/scripts/commands.js

```js
// RPG command registry, isolated in a separate behavior pack.
// Even if complex RPG combat/skill imports fail, /rpg:ping can still register.
import * as mc from "@minecraft/server";
const VERSION = "0.6.7";
const commands = [
  ['tpa','플레이어 이동 요청 · 이동 성공 시 1000골드'],
  ['tpaaccept','받은 플레이어 이동 요청 수락·거절'],
  ['pvpcreate','관리자: 1000 250 1000에 PvP장 생성',null,true],
  ['pkclear','관리자: 플레이어 PK 패널티 해제','player',true],
  ['peace','관리자: 현재 위치 반경 200 평화구역 설정·해제','mode',true],
  ['pvp','결투 신청·수락·항복·PK 상태','player'],
  ['gptnpc','관리자: GPT RPG 질문 NPC 생성',null,true],
  ['temple','천체 신전 위치·활성 제단·후예 전직'],
  ['templecreate','관리자: 앞쪽 빈 지역에 천체 신전 생성',null,true],
  ['templeremove','관리자: 신전 등록 해제·건물 보존',null,true],
  ['fuse','RPG 장비 등급 합성'],
  ['transfer','RPG 갑옷 강화 추출·이전'],
  ['ask','이 애드온의 직업·스킬·제작·던전 정보 질문','question'],
  ['dungeoncreate','관리자: 난이도 1~10 또는 all 동굴 생성·누락 복구','difficulty',true],
  ['dungeonremove','관리자: 던전 등록 해제 (건축물 보존)','name',true],
  ['dungeon','난이도 목록·파티장 입장 시 파티원 자동 등록','difficulty'],
  ['dungeonstart','대기실 인원 1~4명 출발'],
  ['dungeonsolo','해당 난이도 혼자 바로 시작','difficulty'],
  ['dungeonleave','대기 취소·사망 후 귀환 (전투 중 불가)'],
  ['dungeonloot','보관된 던전 보급품 받기'],
  ['skillguide','모든 직업·스킬 상세 도감'],
  ['runes','룬 전용 보관함·장착'],
  ['jobs','직업별 전직 조건·시련'],
  ['craft', '갑옷·룬 제작법과 획득 도감'],
  ['upgrade', '갑옷·룬·공용 무기 강화'],
  ['wallet', '골드·강화석·룬 가루 지갑'],
  ['equipment', 'RPG 갑옷·룬 보관·장착'],
  ['guide', '모험 시작·견습 5계열 자유 체험'],
  ["rulebook", "RPG 서버 종합 룰북"],
  ["ping", "명령어 등록 진단"],
  ["diag", "명령어 및 스크립트 진단"],
  ["menu", "카멜레온 스킬 메뉴"],
  ["job", "전직", "job"],
  ["help", "명령어 도움말"],
  ["status", "캐릭터 상태"],
  ["stats", "레벨·스탯 분배"],
  ["admin", "운영자 설정 도구", null, true],
  ["setlevel", "관리자: 레벨 설정", "level", true],
  ["setmana", "관리자: 최대 마나 설정", "amount", true],
  ["skills", "스킬 켜기·끄기"],
  ["skillbook", "스킬 도감"],
  ["learn", "스킬 습득", "skill"],
  ["swap", "카멜레온 무기 전환"],
  ["offer", "검과 책을 바칩니다"],
  ["bless", "미카엘 전직: 축복의 빛 192개 공물"],
  ["holywater", "성수 제작"],
  ["force", "관리자: 강제 전직", "job", true],
  ["reset", "관리자: 초기화", null, true],
  ["starter", "관리자: 견습 장비", "line", true],
  ["charge", "관리자: 마나·쿨타임 회복", null, true],
  ["items", "관리자: 전용 아이템", null, true],
  ["egg", "관리자: 몬스터 스폰알", null, true],
  ["hito", "관리자: 전직관 소환알 지급", "line", true],
  ["wings", "날개 켜기·끄기"],
  ["wingcheck", "날개 상태"],
  ["wingrefresh", "날개 새로고침"],
  ["guild", "길드 메뉴"],
  ["party", "파티 메뉴"],
  ["invites", "초대 확인"],
  ["boss", "관리자: 바위 골렘", null, true],
  ["cyclops", "관리자: 외눈 거인", null, true],
  ["hydra", "관리자: 히드라", null, true],
  ["techgolem", "관리자: 마공학 골렘", null, true],
  ["fistcheck", "주먹 강화 상태"]
];
const registered = new Set();
let startupDone = false;
let failures = [];
function isPlayer(p) { return !!p && p.typeId === "minecraft:player"; }
function tell(p, msg) { try { p.sendMessage(msg); } catch (e) { console.warn("[RPG commands] message: " + e); } }
function handle(action, p, arg="") {
  if (!isPlayer(p)) return;
  if (action === "ping") {
    tell(p, "§a[RPG v"+VERSION+"] 명령어 스크립트 실행 정상. 등록 "+registered.size+"/"+commands.length);
    return;
  }
  if (action === "diag") {
    tell(p,"§e[RPG v"+VERSION+"] 명령어 팩 실행 정상 ("+registered.size+"/"+commands.length+"). RPG 본체 확인: /rpg:status");
    if(failures.length) failures.slice(0,4).forEach(x=>tell(p,"§c"+x));
    tell(p,"§7게임플레이 오류는 설정 → 제작자 → 콘텐츠 로그에서 확인 가능. /function rpg_hydra 로 히드라 소환 검사 가능");
    return;
  }
  // The RPG gameplay BP independently handles this script event. It is run as
  // the player so event.sourceEntity is the correct player object.
  const message = String(arg??"").replace(/[\r\n]/g," ").trim();
  try {
    p.runCommand("scriptevent rpg:"+action+(message?" "+message:""));
  } catch (e) {
    tell(p,"§c[RPG] 명령어 전달 실패: "+String(e));
  }
}
mc.system.beforeEvents.startup.subscribe(ev => {
  startupDone = true;
  const registry = ev.customCommandRegistry;
  if(!registry){ console.error("[RPG commands] customCommandRegistry unavailable"); return; }
  const levels = mc.CommandPermissionLevel ?? mc.CustomCommandPermissionLevel;
  const params = mc.CustomCommandParamType;
  const statuses = mc.CustomCommandStatus;
  if(!levels || !params || !statuses){ console.error("[RPG commands] Script API command enums unavailable"); return; }
  for(const [name, description, arg, admin] of commands){
    try{
      const def={name:"rpg:"+name,description,permissionLevel: admin?levels.GameDirectors:levels.Any,cheatsRequired:false};
      if(arg){
        const t = name === "setlevel" ? params.Integer : params.String;
        if(name === "hito" || name === "dungeon" || name === "ask" || name === "pvp" || name === "peace" || name === "pkclear") def.optionalParameters=[{name:arg,type:t}];
        else def.mandatoryParameters=[{name:arg,type:t}];
      }
      registry.registerCommand(def,(origin,...args)=>{
        const p=origin.sourceEntity??origin.initiator;
        if(!isPlayer(p)) return {status:statuses.Failure,message:"플레이어 전용 명령어"};
        const raw=Array.isArray(args[0])?args[0][0]:args[0];
        mc.system.run(()=>handle(name,p,raw==null?"":String(raw)));
        return {status:statuses.Success};
      });
      registered.add(name);
    }catch(e){
      const msg="/rpg:"+name+" 등록 실패: "+String(e);
      failures.push(msg);console.error("[RPG commands] "+msg);
    }
  }
  try{registry.registerCommand({name:'pvp',description:'결투 신청',permissionLevel:levels.Any,cheatsRequired:false,optionalParameters:[{name:'player',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvp',p,arg??''));return {status:statuses.Success};});}catch{ /* Namespace-free aliases are unsupported on some Bedrock versions. */ }
  try{registry.registerCommand({name:'peace',description:'관리자: 반경 200 평화구역',permissionLevel:levels.GameDirectors,cheatsRequired:false,optionalParameters:[{name:'mode',type:params.String}]},(origin,arg)=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('peace',p,arg??''));return {status:statuses.Success};});}catch{console.warn('[RPG] /peace 별칭 미지원: /rpg:peace 사용');}
  try{registry.registerCommand({name:'pvpcreate',description:'관리자: PvP장 생성',permissionLevel:levels.GameDirectors,cheatsRequired:false},origin=>{const p=origin.sourceEntity??origin.initiator;if(!isPlayer(p))return {status:statuses.Failure};mc.system.run(()=>handle('pvpcreate',p,''));return {status:statuses.Success};});}catch{console.warn('[RPG] /pvpcreate 별칭 미지원: /rpg:pvpcreate 사용');}
  console.warn("[RPG v"+VERSION+"] registered "+registered.size+"/"+commands.length+" commands");
});
// Allow commands even if a particular client doesn't display slash commands.
try {
  const chat=mc.world.beforeEvents?.chatSend;
  if(chat?.subscribe) chat.subscribe(ev=>{
    const msg=String(ev.message??"").trim();
    if(!/^!(?:rpg|rulebook|hito|pvp)(?:\s|$)/i.test(msg))return;
    ev.cancel=true;
    let action="help",arg="";
    if(/^!pvp(?:\s|$)/i.test(msg)){action='pvp';arg=msg.replace(/^!pvp\s*/i,'');}
    else if(/^!rulebook$/i.test(msg))action="rulebook";
    else if(/^!hito(?:\s|$)/i.test(msg)){action="hito";arg=msg.replace(/^!hito\s*/i,"");}
    else {const parts=msg.replace(/^!rpg\s*/i,"").trim().split(/\s+/);action=(parts.shift()||"help").toLowerCase();arg=parts.join(" ");}
    const p=ev.sender;
    mc.system.run(()=>handle(action,p,arg));
  });
}catch(e){console.warn("[RPG commands] chat fallback disabled: "+e);}
// Direct /scriptevent rpg:ping and rpg:diag allow diagnosing even if custom
// command registration is unsupported on the current Bedrock version.
try {
  mc.system.afterEvents.scriptEventReceive.subscribe(ev=>{
    if(ev.id!=="rpg:ping"&&ev.id!=="rpg:diag") return;
    if(isPlayer(ev.sourceEntity))mc.system.run(()=>handle(ev.id.slice(4),ev.sourceEntity));
  });
}catch(e){console.warn("[RPG commands] event diagnostic fallback disabled: "+e);}

```

## RPG_RP_v0603/manifest.json

```json
{
  "format_version": 2,
  "header": {
    "name": "RPG Addon RP v0.6.7",
    "description": "RPG v0.6.7 · 룬 장착 슬롯 강화 해금 · 기본 3개에서 최대 5개",
    "uuid": "8fa45523-e936-4258-a195-01e5e62e814c",
    "version": [
      0,
      6,
      7
    ],
    "min_engine_version": [
      1,
      21,
      100
    ]
  },
  "modules": [
    {
      "type": "resources",
      "uuid": "7ede5e36-9a5f-44d1-9aa0-9dc38822fa99",
      "version": [
        0,
        6,
        7
      ]
    }
  ]
}

```

