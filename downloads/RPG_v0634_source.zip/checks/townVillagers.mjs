import fs from 'node:fs';import assert from 'node:assert/strict';
const root=process.argv[2]??'/workspace/rpg-work/v0634';
const TAG='rpg_town_villager_protected';
function filter(f,state){
 if(Array.isArray(f))return f.every(x=>filter(x,state));assert.equal(typeof f,'object');assert.ok(f&&!Array.isArray(f));
 if(f.all_of&&!f.all_of.every(x=>filter(x,state)))return false;
 if(f.any_of&&!f.any_of.some(x=>filter(x,state)))return false;
 if(f.none_of&&f.none_of.some(x=>filter(x,state)))return false;
 if(!f.test)return true;
 let value;
 if(f.test==='has_tag')value=state.protected&&f.value===TAG;
 else if(f.test==='is_family')value=state.families.includes(f.value);
 else if(f.test==='has_damage')value=state.fatal;
 else if(f.test==='is_difficulty')value=state.difficulty===f.value;
 else throw Error('Unexpected filter '+f.test);
 return f.operator==='!='?!value:!!value;
}
for(const name of ['villager','villager_v2']){
 const def=JSON.parse(fs.readFileSync(root+'/RPG_BP_v0634/entities/'+name+'.json'));
 const baseline=JSON.parse(fs.readFileSync(root+'/checks/fixtures/'+name+'_121100.json'));
 const e=def['minecraft:entity'],original=baseline['minecraft:entity'];
 assert.deepEqual(e.description,original.description);assert.deepEqual(e.component_groups,original.component_groups);assert.deepEqual(e.events,original.events);
 const components={...e.components};delete components['minecraft:damage_sensor'];const baseComponents={...original.components};delete baseComponents['minecraft:damage_sensor'];assert.deepEqual(components,baseComponents);
 const triggers=e.components['minecraft:damage_sensor'].triggers,old=original.components['minecraft:damage_sensor'].triggers;
 assert.equal(triggers.length,old.length+9);assert.deepEqual(triggers[10],old[1]);
 const blocked=state=>triggers.slice(0,9).some(t=>(!t.cause||t.cause===state.cause)&&filter(t.on_damage.filters,state)&&t.deals_damage===false);
 const state={protected:true,families:['player'],cause:'entity_attack',fatal:true,difficulty:'normal'};
 assert.equal(blocked(state),true);assert.equal(blocked({...state,protected:false}),false);
 assert.equal(blocked({...state,families:['zombie']}),false);assert.equal(filter(triggers[10].on_damage.filters,{...state,families:['zombie']}),true);
 for(const cause of ['projectile','magic','entity_explosion','block_explosion','lightning','fire','fire_tick','lava']){
  assert.equal(blocked({...state,families:[],cause}),true);assert.equal(blocked({...state,protected:false,cause}),false);
 }
 assert.equal(blocked({...state,families:[],cause:'fall'}),false);
 assert.equal(filter(triggers[9].on_damage.filters,{...state,families:['lightning'],cause:'lightning'}),false);
 assert.equal(filter(triggers[9].on_damage.filters,{...state,protected:false,families:['lightning'],cause:'lightning'}),true);
}
console.log('Both vanilla villager definitions: lethal player/projectile/magic/explosion/lightning town protection, outside vanilla behavior, zombie fatal conversion, all trade/breed/AI components and events unchanged');
