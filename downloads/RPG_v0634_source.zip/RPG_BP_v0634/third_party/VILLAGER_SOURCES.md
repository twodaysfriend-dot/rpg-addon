Vanilla villager definitions adapted from Mojang/bedrock-samples.
Source tag: v1.21.100.6
Commit: c32ab2ac8ebdd8b418c03990b30597d6b56bc8c9
https://github.com/Mojang/bedrock-samples/tree/c32ab2ac8ebdd8b418c03990b30597d6b56bc8c9/behavior_pack/entities
Files: villager.json and villager_v2.json. JSONC comments/trailing commas removed. Added native damage-sensor filters gated by rpg_town_villager_protected; town lightning cannot convert to witches. All other components, events and zombie conversion retained. See accompanying license.
