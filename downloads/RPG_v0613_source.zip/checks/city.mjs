import fs from 'node:fs';import vm from 'node:vm';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'/workspace/rpg-work/v0613'),base=root+'/RPG_BP_v0613/scripts/';
const source=fs.readFileSync(base+'data/fantasyCity.js','utf8');const context=vm.createContext({console});
const data=new vm.SourceTextModule(source,{context});await data.link(()=>{});await data.evaluate();const planner=data.namespace,{operations,houses}=planner.makeFantasyCityPlan();
let area=0,volume=0;const sum=op=>(op.x2-op.x+1)*(op.y2-op.y+1)*(op.z2-op.z+1);
for(const op of operations){assert.ok(op.x>=0&&op.z>=0&&op.x2<1000&&op.z2<1000&&op.y>=-1&&op.y2<=54,JSON.stringify(op));volume+=sum(op);}
for(let i=0;i<256;i++){const tile=planner.cityTile(i);area+=(tile.x2-tile.x+1)*(tile.z2-tile.z+1);for(const op of planner.tileOperations(operations,tile)){assert.ok(op.x>=tile.x&&op.x2<=tile.x2&&op.z>=tile.z&&op.z2<=tile.z2);}}
assert.equal(area,1000000);let clipped=0;for(let i=0;i<256;i++)for(const op of planner.tileOperations(operations,planner.cityTile(i)))clipped+=sum(op);assert.equal(clipped,volume);
const material=(x,y,z)=>operations.find(op=>x>=op.x&&x<=op.x2&&y>=op.y&&y<=op.y2&&z>=op.z&&z<=op.z2)?.type;
assert.equal(material(999,-1,999),'minecraft:stone_bricks');assert.equal(material(500,1,0),undefined);assert.equal(material(0,1,50),'minecraft:stone_bricks');assert.equal(material(130,1,120),undefined);assert.equal(material(121,3,120),'minecraft:glass');
for(const [type,x,z]of planner.CITY_TRAINERS){assert.ok(material(x,0,z));assert.equal(material(x,1,z),undefined);}
assert.ok(houses>=100);console.log(`City plan: ${houses} houses, ${operations.length} rectangles, ${volume} air-only placement visits; exact 1,000,000-column coverage, gates/windows/NPC spaces passed`);
async function runtime(store=new Map(),options={}){
 const messages=[],commands=[],npcs=[],writes=[],timers=[];let count=0,queries=0;const p={id:'admin',dimension:{id:'minecraft:overworld'},sendMessage:s=>messages.push(s)};
 const dim={runCommand:s=>{commands.push(s);return {successCount:1};},getTopmostBlock:()=>{queries++;return {location:{y:options.obstructed?210:70}};},getBlock:location=>({isAir:!options.existing,setPermutation:permutation=>{count++;if(writes.length<512)writes.push({location,permutation});}}),getEntities:q=>npcs.filter(n=>n.type===q.type&&Math.hypot(n.location.x-q.location.x,n.location.z-q.location.z)<=q.maxDistance),spawnEntity:(type,location)=>{npcs.push({type,location});}};
 const world={getDimension:()=>dim,getAllPlayers:()=>options.offline?[]:[p],getDefaultSpawnLocation:()=>({x:0,y:64,z:0}),setDefaultSpawnLocation:at=>{options.newSpawn=at;},getDynamicProperty:k=>store.get(k),setDynamicProperty:(k,v)=>v===undefined?store.delete(k):store.set(k,v)};
 const system={currentTick:0,run:fn=>timers.push(fn),runInterval:()=>1};const runtimeSource=fs.readFileSync(base+'core/fantasyCity.js','utf8');const ctx=vm.createContext({console});const m=new vm.SourceTextModule(runtimeSource,{context:ctx});
 const plan=new vm.SourceTextModule(source,{context:ctx});await plan.link(()=>{});
 const ext=new vm.SyntheticModule(['world','system','BlockPermutation'],function(){this.setExport('world',world);this.setExport('system',system);this.setExport('BlockPermutation',{resolve:id=>({type:id})});},{context:ctx});
 await m.link(spec=>spec.startsWith('.')?plan:ext);await m.evaluate();const api=m.namespace;
 return {api,p,system,store,messages,commands,npcs,writes,timers,get count(){return count;},get queries(){return queries;},tick(){system.currentTick++;api.tickFantasyCity();},saved(){return JSON.parse(store.get(api.CITY_KEY));}};
}
{
 const t=await runtime(new Map(),{obstructed:true});assert.equal(t.api.createFantasyCity(t.p,''),true);assert.equal(t.saved().x,-500);assert.equal(t.saved().y,200);
 for(let n=0;n<20;n++)t.tick();assert.equal(t.saved().paused,true);assert.equal(t.count,0);assert.ok(t.saved().error.includes('공간 충돌'));t.api.resetUnbuiltCity(t.p);assert.equal(t.store.size,0);
}
console.log('City obstruction: pauses before any placement; unbuilt survey reset passed');
{
 const t=await runtime();assert.equal(t.api.createFantasyCity(t.p,'261'),false);assert.equal(t.api.createFantasyCity(t.p,'200'),true);
 let steps=0;while(t.saved().phase==='survey'&&steps++<20000)t.tick();assert.equal(t.saved().phase,'build');assert.equal(t.count,0);assert.equal(t.queries,1000000);
 while(t.count===0&&steps++<21000)t.tick();assert.ok(t.count>0&&t.count<=256);const before=t.saved();t.api.stopFantasyCity(t.p);const n=t.count;t.tick();assert.equal(t.count,n);assert.equal(t.saved().paused,true);
 t.api.resumeFantasyCity(t.p);t.tick();assert.equal(t.saved().phase,'build');assert.equal(t.api.resetUnbuiltCity(t.p),undefined);assert.equal(t.saved().phase,'build');
 while(t.saved().phase!=='done'&&steps++<100000)t.tick();assert.equal(t.saved().phase,'done');assert.equal(t.npcs.length,8);assert.ok(t.count>2000000);
 const created=t.npcs.length;t.api.resumeFantasyCity(t.p);t.tick();assert.equal(t.npcs.length,created);
 assert.ok(t.commands.every(s=>s.includes('rpg_city_build_v1')));assert.ok(!t.commands.some(s=>s.includes('remove_all')));
 console.log(`City full simulated build: ${steps} ticks, ${t.count} placements, 8 NPCs; stop/resume, completed retry and ticking-area cleanup passed`);
}
{
 const t=await runtime();t.api.createFantasyCity(t.p,'200');const saved=t.saved();saved.phase='build';saved.op=2;saved.offset=10;t.store.set(t.api.CITY_KEY,JSON.stringify(saved));
 const restored=await runtime(t.store,{existing:true});restored.api.registerFantasyCity();restored.timers[0]();assert.equal(restored.saved().paused,true);assert.equal(restored.saved().op,2);assert.equal(restored.saved().offset,10);restored.api.resumeFantasyCity(restored.p);
 for(let n=0;n<25;n++)restored.tick();assert.equal(restored.count,0);assert.ok(restored.saved().op>=2);
}
console.log('City restart checkpoint and occupied-block preservation passed');
