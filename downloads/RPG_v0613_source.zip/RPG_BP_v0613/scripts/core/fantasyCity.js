import {world,system,BlockPermutation} from '@minecraft/server';
import {CITY_SIZE,CITY_TILES,cityTile,makeFantasyCityPlan,tileOperations,CITY_TRAINERS} from '../data/fantasyCity.js';
export const CITY_KEY='rpg:fantasy_city_v1';
const AREA='rpg_city_build_v1',BUDGET=256,TOTAL=CITY_TILES*CITY_TILES;
let state,loadedTile=-1,wait=0,survey=0,ops,permutations=new Map(),registered=false,lastNotice=-1;
const city=makeFantasyCityPlan();
const dim=()=>world.getDimension('overworld');
function read(){const value=world.getDynamicProperty(CITY_KEY);if(!value)return;const s=JSON.parse(value);if(s.version!==1||!Number.isSafeInteger(s.x)||!Number.isSafeInteger(s.z)||!Number.isInteger(s.y)||s.y< -62||s.y>260||!Number.isInteger(s.op)||s.op<0||!Number.isInteger(s.offset)||s.offset<0||!Number.isInteger(s.tile)||s.tile<0||s.tile>TOTAL||!['survey','build','npcs','done'].includes(s.phase))throw Error('도시 저장 정보가 잘못되었습니다.');return s;}
function save(){world.setDynamicProperty(CITY_KEY,JSON.stringify(state));}
function tell(message){const p=world.getAllPlayers().find(p=>p.id===state?.owner);if(p)p.sendMessage(message);}
function release(){try{dim().runCommand('tickingarea remove '+AREA);}catch{}loadedTile=-1;ops=undefined;survey=0;wait=0;}
function pause(reason){state.paused=true;state.error=reason;save();release();tell('§e[성곽 도시] 일시 중지: '+reason+'\n§7/rpg:cityresume 으로 이어서 생성합니다.');}
function at(x,y,z){return {x:state.x+x,y:state.y+y,z:state.z+z};}
function ensureLoaded(tileIndex){
 if(loadedTile!==tileIndex){
  release();const tile=cityTile(tileIndex),a=at(tile.x,0,tile.z),b=at(tile.x2,0,tile.z2);
  const result=dim().runCommand(`tickingarea add ${a.x} ${a.y} ${a.z} ${b.x} ${b.y} ${b.z} ${AREA} true`);
  if(result?.successCount===0)throw Error('청크 로드 영역을 만들 수 없습니다. tickingarea 여유가 필요합니다.');
  loadedTile=tileIndex;wait=12;return false;
 }
 if(wait>0){wait--;return false;}
 const tile=cityTile(tileIndex);
 try{for(const x of [tile.x,tile.x2])for(const z of [tile.z,tile.z2])if(!dim().getBlock(at(x,0,z)))throw Error('unloaded');}
 catch{if(++state.retries<120){wait=2;return false;}throw Error('생성 지역 청크를 로드하지 못했습니다.');}
 state.retries=0;return true;
}
function nextTile(){state.tile++;state.op=0;state.offset=0;save();release();}
function progress(){const value=Math.floor(state.tile/TOTAL*100);if(value!==lastNotice&&value%10===0){lastNotice=value;tell('§b[성곽 도시] '+(state.phase==='survey'?'공간 검사':'건축')+' '+value+'% · '+state.tile+'/'+TOTAL+'구역');}}
export function cityStatus(p){const s=state??read();if(!s){p.sendMessage('§7생성 중인 성곽 도시가 없습니다.');return;}p.sendMessage(`§b1000×1000 성곽 도시: ${s.phase}${s.paused?' (중지)':''}\n§7${s.tile}/${TOTAL}구역 · 바닥 Y=${s.y} · 중심 ${s.x+500} ${s.y+1} ${s.z+500}${s.error?'\n§e'+s.error:''}`);}
export function createFantasyCity(p,height){
 const previous=state??read();if(previous){p.sendMessage('§e기존 도시 작업이 있습니다. /rpg:citystatus 또는 /rpg:cityresume 을 사용하세요.');return false;}
 if(!['minecraft:overworld','overworld'].includes(p.dimension.id)){p.sendMessage('§e오버월드에서 실행하세요.');return false;}
 const y=height===''||height===undefined?200:Number(height);
 if(!Number.isInteger(y)||y< -62||y>260){p.sendMessage('§e높이는 -62~260의 정수입니다. 예: /rpg:citycreate 200');return false;}
 const spawn=world.getDefaultSpawnLocation();
 state={version:1,x:Math.floor(spawn.x)-500,z:Math.floor(spawn.z)-500,y,owner:p.id,phase:'survey',tile:0,op:0,offset:0,paused:false,retries:0};
 save();p.sendMessage(`§a1000×1000 판타지 성곽 도시 준비 · 주거 건물 ${city.houses}동\n§7월드 스폰 X/Z 중심, 바닥 Y=${y}. 기존 건물을 지우지 않습니다.\n§7먼저 전체 공간을 검사하고 구역별로 건축합니다. /rpg:citystatus · /rpg:citystop · /rpg:cityresume`);return true;
}
export function stopFantasyCity(p){state=state??read();if(!state||state.phase==='done'){cityStatus(p);return;}pause('관리자 요청');}
export function resumeFantasyCity(p){state=state??read();if(!state){p.sendMessage('§e먼저 /rpg:citycreate 로 시작하세요.');return false;}if(state.phase==='done'){cityStatus(p);return false;}state.owner=p.id;state.paused=false;state.error=undefined;state.retries=0;save();release();p.sendMessage('§a저장된 위치부터 이어서 생성합니다.');return true;}
export function tickFantasyCity(){
 if(!state||state.paused||state.phase==='done')return;
 try{
  if(!world.getAllPlayers().some(p=>p.id===state.owner)){pause('실행한 관리자가 접속을 종료했습니다.');return;}
  if(state.phase==='survey'){
   if(state.tile>=TOTAL){state.phase='build';state.tile=0;save();release();lastNotice=-1;tell('§a전체 공간 검사 완료. 성곽 도시 건축을 시작합니다.');return;}
   if(!ensureLoaded(state.tile))return;
   const tile=cityTile(state.tile),width=tile.x2-tile.x+1,count=width*(tile.z2-tile.z+1);
   for(let i=0;i<BUDGET&&survey<count;i++,survey++){
    const x=tile.x+survey%width,z=tile.z+Math.floor(survey/width),column=at(x,0,z);
    const top=dim().getTopmostBlock({x:column.x,z:column.z});
    if(top&&top.location.y>=state.y-1)throw Error(`공간 충돌: ${column.x} ${top.location.y} ${column.z}. 건축 전 공간 검사에서 중단했습니다. 높이를 변경하려면 아직 건축을 시작하지 않은 작업을 /rpg:cityreset 으로 취소한 뒤 다시 시작하세요.`);
   }
   if(survey>=count){nextTile();progress();}return;
  }
  if(state.phase==='build'){
   if(state.tile>=TOTAL){state.phase='npcs';state.tile=9*CITY_TILES+7;state.npc=0;save();release();return;}
   if(!ensureLoaded(state.tile))return;
   ops=ops??tileOperations(city.operations,cityTile(state.tile));
   for(let n=0;n<BUDGET&&state.op<ops.length;n++){
    const op=ops[state.op],width=op.x2-op.x+1,depth=op.z2-op.z+1,count=width*depth*(op.y2-op.y+1),offset=state.offset;
    const location=at(op.x+offset%width,op.y+Math.floor(offset/(width*depth)),op.z+Math.floor(offset/width)%depth),block=dim().getBlock(location);
    if(!block)throw Error('건축 대상 청크가 로딩되지 않았습니다.');
    // Preserve anything present; resuming an already-partly-built operation is idempotent.
    if(block.isAir){let permutation=permutations.get(op.type);if(!permutation){permutation=BlockPermutation.resolve(op.type);permutations.set(op.type,permutation);}block.setPermutation(permutation);}
    state.offset++;if(state.offset>=count){state.op++;state.offset=0;}
   }
   if(state.op>=ops.length){nextTile();progress();}else if(system.currentTick%100===0)save();return;
  }
  if(state.phase==='npcs'){
   if(state.npc>=CITY_TRAINERS.length){world.setDefaultSpawnLocation(at(500,1,610));state.phase='done';state.tile=TOTAL;save();release();tell(`§a1000×1000 판타지 성곽 도시 완료! 전직관 8명 배치 · 월드 스폰을 중앙 광장으로 지정했습니다.\n§e이동: /tp @s ${state.x+500} ${state.y+1} ${state.z+610}\n§e스폰 지정: /setworldspawn ${state.x+500} ${state.y+1} ${state.z+610}`);return;}
   const [type,x,z]=CITY_TRAINERS[state.npc],tileIndex=Math.floor(z/64)*CITY_TILES+Math.floor(x/64);
   if(!ensureLoaded(tileIndex))return;
   const location=at(x+.5,1,z+.5),identifier='rpg:hito_'+type;
   if(!dim().getEntities({type:identifier,location,maxDistance:2}).length)dim().spawnEntity(identifier,location);
   state.npc++;save();
  }
 }catch(error){pause(String(error.message??error));}
}
export function resetUnbuiltCity(p){state=state??read();if(!state)return;if(state.phase!=='survey'){p.sendMessage('§e건축을 시작한 도시는 초기화할 수 없습니다. /rpg:cityresume 으로 이어서 완성하세요.');return;}release();state=undefined;world.setDynamicProperty(CITY_KEY,undefined);p.sendMessage('§a아직 건축하지 않은 도시 검사를 취소했습니다. 다시 높이를 지정해 시작할 수 있습니다.');}
export function registerFantasyCity(){if(registered)return;registered=true;system.run(()=>{try{state=read();release();if(state&&state.phase!=='done'){state.paused=true;state.error='월드 재시작 후 관리자 /rpg:cityresume 대기';save();}}catch(error){console.warn('[RPG city] '+error);}});system.runInterval(tickFantasyCity,1);}
