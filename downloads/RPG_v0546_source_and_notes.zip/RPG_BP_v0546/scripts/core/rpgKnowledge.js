import {JOBS,APPRENTICE_SKILLS} from '../data/jobs.js';
import {SKILLS} from '../data/skills.js';
import {LINE_NOTES,SKILL_NOTES} from '../data/skillGuide.js';
import {JOB_TRIALS} from '../data/jobTrials.js';
import {CRAFTING_RECIPES} from '../data/crafting.js';
import {RUNES,ARMOR_SETS} from '../data/equipment.js';
import {upgradedRune,RUNE_MAX,ARMOR_MAX,MAX_CATALYSTS,upgradeCost,enhancementRates} from '../data/upgrades.js';
import {DUNGEON,DUNGEON_TIERS,clearRewardForTier} from '../data/dungeons.js';
import {CONFIG} from '../config.js';
import {defaultDamageTypeFor} from './stats.js';
export const QUESTION_LIMIT=200;
export const UNKNOWN_ANSWER='이 애드온의 직업·스킬·룬·갑옷·제작·강화·던전·성장 정보만 안내합니다. 도감에 없는 내용은 확인할 수 없습니다. 예: 월룡륜미 범위 / 해커 전직 / 생명의 룬 / 샌드백 제작';
export const normalizeQuestion=s=>String(s??'').normalize('NFKC').toLowerCase().replace(/§./g,'').replace(/[^a-z0-9가-힣]/g,'');
const clean=s=>String(s??'').replace(/§./g,'').replace(/[\u0000-\u0008\u000b-\u001f]/g,'');
const bossName=id=>({rock_golem_boss:'바위 골렘',cyclops_boss:'외눈 거인',hydra_boss:'히드라',tech_block_golem_boss:'마공학 골렘'}[id]??'던전 보스');
const percent=n=>Number((n*100).toFixed(3))+'%';
function runeEffects(r){
 const a=[];if(r.physical)a.push('물리 피해 +'+percent(r.physical-1));if(r.magic)a.push('마법 피해 +'+percent(r.magic-1));
 if(r.health)a.push('최대 HP +'+r.health);if(r.manaRegenPercent)a.push('초당 최대 MP의 '+percent(r.manaRegenPercent)+' 추가 회복');
 if(r.lifesteal)a.push('준 피해의 '+percent(r.lifesteal)+' HP 회복');if(r.ward)a.push('저항 '+(r.wardAmplifier+1)+'단계 유지');return a.join(', ');
}
let catalog;
export function knowledgeEntries(){
 if(catalog)return catalog;
 const entries=[];
 const add=(id,title,aliases,body,source)=>entries.push(Object.freeze({id,title,aliases:Object.freeze([...new Set([title,...aliases].map(normalizeQuestion).filter(x=>x.length>=2))]),body:clean(body),source}));
 const jobs=Object.values(JOBS).filter(j=>!j.placeholder),active=new Set([...jobs.flatMap(j=>j.skills),...Object.values(APPRENTICE_SKILLS).flat()]);
 for(const id of active){
  const s=SKILLS[id];if(!s||!SKILL_NOTES[id])continue;
  const owners=jobs.filter(j=>j.skills.includes(id)).map(j=>j.name);
  add('skill:'+id,s.name,[id,s.name.replace(/\s*\(궁극기\)/g,'')],`기본 MP ${s.mana} / 쿨 ${s.cooldown/20}초\n${SKILL_NOTES[id]}\n사용 직업: ${owners.join('·')}\n피해 수치는 스탯·힘 버프·장비 보정 전입니다.`, 'data/skills.js · data/skillGuide.js');
 }
 for(const j of jobs){
  const trial=JOB_TRIALS[j.id],condition=trial?`레벨 ${trial.level}\n`+['all','any'].filter(k=>trial[k]).map(k=>trial[k].map(c=>`${c.label} ${c.need}`).join(k==='all'?' + ':' 또는 ')).join('\n'):'견습 시작 직업';
  const from=trial?.allowedFrom?.map(id=>JOBS[id].name).join('·')??(j.hidden&&j.parent===null?'아무 2차 이상 직업':JOBS[j.parent]?.name??'없음');
  const type=defaultDamageTypeFor({getDynamicProperty:()=>j.id});
  const special=j.id==='hacker'?'전직: 로토와 23회 대화 후 퀴즈 정답. 월드 최초 정답자 1명만 전직 가능. 직업·레벨 제한 없음.':`직전 직업: ${from}\n전직 조건: ${condition}`;
  const extra=j.id==='fallen_angel'?'\n치유한 플레이어 사망 목격 5회 후 성직 직업 포기가 필요합니다.':j.id==='angel'?'\n아군 실제 HP 300 회복마다 축복의 빛 1개. 자가 회복·초과 회복은 제외.':'';
  add('job:'+j.id,j.name,[j.id],`${special}${extra}\n기본 피해 계열: ${type==='magic'?'마력(마법)':'근력(물리)'}. 개별 기술에 다른 피해 판정이 있으면 해당 판정을 따릅니다.\n보유 기술: ${j.skills.map(id=>SKILLS[id]?.name??id).join('·')||'시작 장비에 따라 사용'}\n${LINE_NOTES[j.line]??''}`,'data/jobs.js · data/jobTrials.js · data/skillGuide.js');
 }
 for(const [id,r]of Object.entries(RUNES)){
  const recipe=CRAFTING_RECIPES.find(c=>c.id==='rpg:rune_'+id);
  add('rune:'+id,r.name,[r.name.replace('의 ',''),'rune_'+id],`기본: ${runeEffects(upgradedRune(r,0))}\n최대 +${RUNE_MAX}: ${runeEffects(upgradedRune(r,RUNE_MAX))}\n/rpg:runes 보관함에서 장착해야 효과를 받습니다.\n${recipe?.text??'룬 드롭으로 획득'}`,'data/equipment.js · data/upgrades.js · data/crafting.js');
 }
 for(const [id,a]of Object.entries(ARMOR_SETS))add('armor:'+id,a.name+' 갑옷',[a.name,id],`${a.description}\n부위별 방어력: ${a.protection.join(' / ')}\n최대 강화 +${ARMOR_MAX}. 부위별 제작법은 /rpg:craft에서 확인하세요.`,'data/equipment.js · data/upgrades.js');
 for(const r of CRAFTING_RECIPES)add('craft:'+r.id,r.name+' 제작법',[r.name,r.id,r.name.replace('훈련용 ','').replace(' 소환',''),...(r.id==='rpg:stat_reset_scroll'?['스탯초기화']:[])],r.text,'data/crafting.js (실제 조합법에서 생성)');
 add('rule:armor','갑옷 종류·제작',['갑옷','방어구'],Object.values(ARMOR_SETS).map(a=>a.name+': '+a.description).join('\n')+'\n4부위를 같은 세트로 입어야 세트 효과를 받습니다. /rpg:craft에서 부위별 제작법, /rpg:upgrade에서 강화를 확인하세요.','data/equipment.js · data/crafting.js');
 add('rule:damage','피해 계산·힘 버프',['힘버프','힘효과','힘스킬','마법딜','고정피해','마법피해','피해계산'],`힘 효과는 물리·마법 스킬의 기본 피해에 단계당 +${CONFIG.skillDamage.strengthPerLevel}. 그 뒤 물리는 근력, 마법은 마력과 장비·룬을 곱합니다. 고정 피해는 유지합니다.\n물리/마법 피해 = (기본 피해 + 힘 단계 × ${CONFIG.skillDamage.strengthPerLevel}) × (1 + 0.007 × (해당 스탯 - 5)) × 장비 보정.\n무투가의 기존 힘 보정과 평타 배수에는 중복 적용하지 않습니다.`,'core/stats.js · skills/fist.js');
 add('rule:stats','레벨·스탯',['스탯','근력','마력','지능','체력스탯','레벨업'],`자연 성장 최대 레벨 100, 레벨마다 SP 3. 근력·체력·마력 투자 상한 없음. 지능 최대 50이며 마나 소모 감소는 최대 40%.\n근력은 물리 피해, 마력은 마법 피해·회복량, 체력은 최대 HP입니다. /rpg:stats에서 분배합니다.`,'core/stats.js');
 add('rule:party','파티 경험치',['파티','경험치','쩔','xp'],`최대 4명. 같은 차원·처치자 ${CONFIG.partyXp.radius}칸 안·생존한 파티원은 각자 원래 XP의 ${percent(CONFIG.partyXp.multiplier)} 획득. 90 XP 몹이면 각자 ${90*CONFIG.partyXp.multiplier} XP.\n일반 마크 생물 10, 대부분 적대 몹 30, 좀벌레·좀비화 피글린 5 XP. 커스텀 몹/보스는 별도 값.\n전직 처치는 최근 30초 공격·탱킹·유효 회복에 기여한 같은 차원·시체 32칸 안 생존 파티원도 인정합니다.`,'config.js · data/mobXp.js · core/combatContribution.js');
 add('rule:runes','룬 획득·장착',['룬','룬획득','룬드랍','룬드롭','룬장착'],`일반 몬스터 1%·RPG 엘리트 3%·보스 30% 확률로 룬 드롭. 현재 룬 ${Object.values(RUNES).map(r=>r.name).join('·')}.\n/rpg:runes 전용 보관함 30칸, 장착 3개. 같은 종류는 하나만 장착. 원하는 룬은 /rpg:craft 제작법을 확인하세요.`,'core/runeDrops.js · loot_tables/rpg · core/runeInventory.js');
 const ar=enhancementRates('armor',ARMOR_MAX-1),rr=enhancementRates('rune',RUNE_MAX-1),ac=upgradeCost('armor',ARMOR_MAX-1),rc=upgradeCost('rune',RUNE_MAX-1);
 add('rule:upgrade','강화·촉매·재화',['강화','촉매','골드','강화석','룬가루'],`/rpg:upgrade에서 갑옷 최대 +${ARMOR_MAX}, 룬 최대 +${RUNE_MAX}. 실패·강등·파괴에도 비용 소모.\n갑옷 마지막 단계: 골드 ${ac.gold}·강화석 ${ac.stone}, 성공 ${ar.success}% / 유지 ${ar.fail}% / 강등 ${ar.downgrade}% / 파괴 ${ar.destroy}%.\n룬 마지막 단계: 골드 ${rc.gold}·룬 가루 ${rc.dust}, 성공 ${rr.success}% / 유지 ${rr.fail}% / 강등 ${rr.downgrade}% / 파괴 ${rr.destroy}%.\n촉매는 갑옷 +5·룬 +2부터 1회 최대 ${MAX_CATALYSTS}개, 1개당 성공 +5%p·파괴 -3%p(파괴 0% 하한). 최종 확률은 확인창에 표시.`,'data/upgrades.js');
 add('rule:dungeon','던전 입장·진행',['던전','던젼','보스제한시간'],`난이도 ${DUNGEON_TIERS.length}개. /rpg:dungeon에서 참가, /rpg:dungeonstart로 최대 ${DUNGEON.maxParty}명 출발. 혼자는 /rpg:dungeonsolo 1.\n일반 ${DUNGEON.normalCount}·엘리트 ${DUNGEON.eliteCount}마리를 ${DUNGEON.mobLimitMs/60000}분 안에 처치한 뒤 보스 1마리를 ${DUNGEON.bossLimitMs/60000}분 안에 잡습니다. 몹이 없으면 후속 몹이 일찍 나옵니다. 전투 중 임의 퇴장 불가, 사망·완료·제한시간 종료로 귀환.\n관리자 생성: /rpg:dungeoncreate 1 또는 all.`,'data/dungeons.js · core/dungeons.js');
 for(const d of DUNGEON_TIERS){const r=clearRewardForTier(d.tier);add('dungeon:'+d.tier,`던전 ${d.tier} ${d.name}`,[d.name,'던전'+d.tier,d.tier+'번던전',d.tier+'단계던전',d.tier+'티어던전'],`난이도 ${d.tier}. 보스: ${bossName(d.boss)}.\n클리어 보상: 골드 ${r.gold}·강화석 ${r.stone}·룬 가루 ${r.dust}·촉매 ${r.catalysts}·룬 ${r.runes}개. 보급품 ${r.supplyMultiplier}배. 개별 몬스터 처치 보상은 별도.`,'data/dungeons.js');}
 add('rule:start','처음 시작',['초보','시작','처음','막혔','막힘'],`/rpg:guide에서 견습 장비와 시작 안내를 받습니다. 첫 전직은 레벨 10과 각 직업 시련이 필요합니다. /rpg:jobs에서 현재 전직 조건, /rpg:craft에서 재료, /rpg:skillguide에서 기술을 확인하세요.`,'core/beginner.js · core/jobMenu.js');
 catalog=Object.freeze(entries);return catalog;
}
export function lookupRpgQuestion(question){
 const raw=String(question??'').trim();if(!raw)return {status:'empty',entries:[]};
 if(raw.length>QUESTION_LIMIT)return {status:'too_long',entries:[]};
 const q=normalizeQuestion(raw);if(!q)return {status:'unknown',entries:[]};
 const ranked=knowledgeEntries().map(e=>({entry:e,score:Math.max(0,...e.aliases.filter(a=>q.includes(a)&&(!/[0-9]$/.test(a)||new RegExp(a+'(?![0-9])').test(q))).map(a=>a.length*10+(e.id.startsWith('skill:')?2:e.id.startsWith('rune:')?3:0)+(e.id.startsWith('craft:')&&/제작|만드|만들|조합|재료/.test(q)?5:0)))})).filter(e=>e.score>0).sort((a,b)=>b.score-a.score||a.entry.id.localeCompare(b.entry.id));
 return {status:ranked.length?'answer':'unknown',entries:ranked.slice(0,6).map(r=>r.entry)};
}
// Only canonical records may be rendered; remote services cannot inject answer text.
export function selectKnowledgeEntries(candidates,ids){
 if(!Array.isArray(ids)||ids.length>3||ids.some(id=>typeof id!=='string'))return undefined;
 const unique=[...new Set(ids)],selected=unique.map(id=>candidates.find(e=>e.id===id));
 return selected.some(e=>!e)?undefined:selected;
}
export function formatKnowledge(entries){
 if(!entries?.length)return UNKNOWN_ANSWER;
 return entries.slice(0,3).map(e=>`${e.title}\n${e.body}`).join('\n\n')+'\n\n자료: 이 애드온의 게임 도감 v0.5.46';
}
