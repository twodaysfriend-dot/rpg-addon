# RPG v0.6.92 · 난식 강화와 파괴 면제권

- 투신 난식의 파편당 기본 물리 피해가 8에서 16으로 증가했습니다. 전방 120°로 파편 32발을 발사하며, 조준선으로 한 발이 나갑니다. 시전 위치 기준 사거리는 25칸이고 적이나 벽에 닿으면 파편이 멈춥니다. 대상당 최대 10발이 적중하며, MP 120을 소모하고 쿨타임은 0초입니다.
- 파괴 면제권을 일반 인벤토리에 지니면 룬·RPG 갑옷·무기의 강화에서 파괴가 나올 때 면제권 한 장이 자동 소모됩니다. 그 장비의 등급과 강화 단계가 유지됩니다. 한 번의 강화에 필요한 재화와 선택한 촉매는 소모됩니다. 룬 일괄·자동 강화에서도 파괴 시도마다 한 장씩 적용됩니다.
- 작업대에서 종이 1장, 강화 촉매 1개, 다이아몬드 2개를 조합해 면제권 1장을 제작합니다. 아이템 ID는 `rpg:destruction_waiver`입니다.

Bedrock 1.21.100 이상에서 BP·Commands BP·RP를 모두 v0.6.92로 활성화하세요. 모의 테스트로 난식의 25칸 경계, 벽 판정, 파편 피해와 면제권의 자동 소모, 장비 보존, 저장 실패 시 복구를 검증했습니다. 실제 Bedrock 월드에서의 시전과 제작 확인은 남아 있습니다.

## 개발·검증·패키징

Node.js 24·Python 3.12. 외부 패키지는 필요하지 않습니다.

```sh
set -e
python3 checks/validate.py .
node checks/cleanup.mjs .
node tools/build_monster_balance.mjs --check
node checks/dungeonBalance.mjs .
python3 tools/build_abyssal_armor.py --check
node checks/largeArmor.mjs .
node checks/bossTargeting.mjs .
node --experimental-vm-modules checks/bossMechanics.mjs .
node --experimental-vm-modules checks/bloodedge.mjs .
node --experimental-vm-modules checks/mending.mjs .
node --experimental-vm-modules checks/prison.mjs .
node --experimental-vm-modules checks/dragon.mjs .
node --experimental-vm-modules checks/city.mjs .
node --experimental-vm-modules checks/dungeons.mjs .
node --experimental-vm-modules checks/cleaner.mjs .
node --experimental-vm-modules checks/integration.mjs . --gameplay-only-wings
for suite in integration worldUnlock behavior balance world rebalance frost holyOrb vitality dragonSnow statInput wings townMuda townVillagers beastHoly michael; do
 node --experimental-vm-modules "checks/$suite.mjs" .
done
python3 tools/package.py /workspace/rpg-release/v0692
```
