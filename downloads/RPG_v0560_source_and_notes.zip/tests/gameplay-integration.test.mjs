import test from 'node:test';
import assert from 'node:assert/strict';
import {initializeGameplay} from '../RPG_BP_v0560/scripts/main.js';
import {player,ItemStack,events,system,EquipmentSlot,players} from './minecraftMock.mjs';
import {JOBS} from '../RPG_BP_v0560/scripts/data/jobs.js';
import {getSkills,setSkills,setIndex,getMana,setMana,maxManaOf,resetCooldowns,getProgress} from '../RPG_BP_v0560/scripts/core/playerData.js';
import {getContext} from '../RPG_BP_v0560/scripts/core/context.js';
import {purchaseChameleonSkill,remainingSkillUses,SKILLBOOK_ID} from '../RPG_BP_v0560/scripts/core/chameleonProgress.js';
import {RUNNERS as HOLY} from '../RPG_BP_v0560/scripts/skills/holy.js';
import {SKILLS} from '../RPG_BP_v0560/scripts/data/skills.js';
test('entire active gameplay module graph loads and all feature registration succeeds',()=>{
  const result=initializeGameplay();assert.equal(result.state,'ready');assert.deepEqual(result.errors,[]);
  assert.equal(initializeGameplay().state,'ready');
});
test('skillbook custom item component registers and duplicate use paths consume one book',()=>{
  const components=new Map();for(const fn of system.beforeEvents.startup.listeners)fn({itemComponentRegistry:{registerCustomComponent:(id,c)=>components.set(id,c)}});
  assert.ok(components.has('rpg:random_skillbook'));
  const p=player('bookinput',30);p.setDynamicProperty('rpg:job','chameleon');setSkills(p,[...JOBS.chameleon.skills]);p.slots[7]=new ItemStack(SKILLBOOK_ID,2);
  components.get('rpg:random_skillbook').onUse({source:p});for(const fn of events.itemUse.listeners)fn({source:p,itemStack:p.slots[7]});assert.equal(p.slots[7].amount,1);
});
test('actual item input decrements a limited skill and blocks mana use at zero',()=>{
  const p=player('castinput',30);p.setDynamicProperty('rpg:job','chameleon');setSkills(p,[...JOBS.chameleon.skills]);purchaseChameleonSkill(p,'hacker_reboot');
  p.equipment.set(EquipmentSlot.Mainhand,new ItemStack(JOBS.chameleon.weapon));setIndex(p,getContext(p).skills.indexOf('hacker_reboot'));players.push(p);
  for(let i=0;i<11;i++){
    resetCooldowns(p);setMana(p,1000);system.currentTick+=10;
    for(const fn of events.itemUse.listeners)fn({source:p,itemStack:new ItemStack(JOBS.chameleon.weapon)});
    assert.equal(remainingSkillUses(p,'hacker_reboot'),Math.max(0,9-i));
    assert.equal(getMana(p),i===10?maxManaOf(p):maxManaOf(p)-SKILLS.hacker_reboot.mana);
  }
  assert.ok(p.actionBars.some(text=>text.includes('남은 0회')));
});
test('holy healing trial counts restored self HP and excludes overhealing and hostile targets',()=>{
  const p=player('healing',20);p.setDynamicProperty('rpg:job','cleric');p.health=5;
  HOLY.holy_heal(p,JOBS.cleric,SKILLS.holy_heal,p);const healed=getProgress(p).job_healing;assert.ok(healed>0&&healed<=15);
  p.health=20;HOLY.holy_heal(p,JOBS.cleric,SKILLS.holy_heal,p);assert.equal(getProgress(p).job_healing,healed);
});
