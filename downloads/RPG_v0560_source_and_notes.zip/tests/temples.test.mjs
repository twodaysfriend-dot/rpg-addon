import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {player,players,world,system,replies,forms} from './minecraftMock.mjs';
import {createTemple,removeTemple,templeTick,registerTemples,templeProtected,openTemple} from '../RPG_BP_v0560/scripts/core/temples.js';
import {readTemple,saveTemple,templeRequirement} from '../RPG_BP_v0560/scripts/core/templeAccess.js';
import {templeBlock,TEMPLE_VOLUME,templeOffset,altarPosition,celestialPhase} from '../RPG_BP_v0560/scripts/data/temple.js';
import {checkAdvance,requestAdvance} from '../RPG_BP_v0560/scripts/core/advance.js';
import {JOBS} from '../RPG_BP_v0560/scripts/data/jobs.js';
import {setSkills} from '../RPG_BP_v0560/scripts/core/playerData.js';
import {runRpgAction} from '../RPG_BP_v0560/scripts/core/rpgActions.js';
const signal=()=>({listeners:[],subscribe(fn){this.listeners.push(fn);}});
for(const name of ['playerInteractWithBlock','playerBreakBlock','playerPlaceBlock','explosion'])world.beforeEvents[name]=signal();
registerTemples();let sequence=0;
function scene(){
 saveTemple(undefined);const blocks=new Map(),key=p=>`${p.x},${p.y},${p.z}`,control={time:1000,unavailable:()=>false,dropped:new Set(),writes:0};
 const dim={id:'minecraft:overworld',getBlock(at){if(control.unavailable(at))return undefined;return {location:{...at},dimension:dim,get typeId(){return blocks.get(key(at))??(at.y===63?'minecraft:grass_block':at.y<63?'minecraft:stone':'minecraft:air');},setType(id){control.writes++;const k=key(at);if(control.dropped.delete(k))return;blocks.set(k,id);}};}};
 world.getDimension=id=>{assert.equal(id,dim.id);return dim;};world.getTimeOfDay=()=>control.time;
 const p=player('temple-owner-'+sequence++,20,{dimension:dim,commandPermissionLevel:1});p.getViewDirection=()=>({x:0,y:0,z:1});p.setDynamicProperty('rpg:job','swordsman');p.setDynamicProperty('rpg:progress',JSON.stringify({job_day:60,job_night:60}));players.push(p);
 return {p,dim,blocks,control,key};
}
function tick(n=1){for(let i=0;i<n;i++){system.currentTick++;templeTick();}}
function drain(){for(let i=0;i<1000;i++){const t=readTemple();if(t.status==='ready'||t.status==='error')return t;tick();}throw Error('Temple build did not finish');}
function built(){const s=scene();createTemple(s.p);assert.equal(drain().status,'ready');system.currentTick=100;templeTick();return s;}
function atAltar(p,kind){const a=altarPosition(readTemple(),kind);p.location={x:a.x,y:a.y,z:a.z-2};}
test('temple blueprint has a complete circular floor, both shrines, elevated arches and open sky above the altars',()=>{
 for(const [x,z]of [[0,0],[12,0],[-12,0],[0,12],[0,-12]])assert.ok(templeBlock(x,0,z));assert.equal(templeBlock(13,0,13),undefined);
 for(const x of [-7,7]){assert.ok(templeBlock(x,1,0));assert.ok(templeBlock(x,2,0));for(let y=3;y<=14;y++)assert.equal(templeBlock(x,y,0),undefined);}
 assert.ok(templeBlock(-10,12,0));assert.ok(templeBlock(10,12,-2));assert.equal(templeBlock(10,12,1),undefined);
 assert.equal(new Set(Array.from({length:TEMPLE_VOLUME},(_,i)=>JSON.stringify(templeOffset(i)))).size,TEMPLE_VOLUME);
});
test('creation requires an admin in the Overworld and reserves a site ahead of the player',()=>{
 const {p,dim}=scene();p.commandPermissionLevel=0;assert.throws(()=>createTemple(p),/관리자/);assert.equal(readTemple(),undefined);
 p.commandPermissionLevel=1;p.dimension={id:'minecraft:nether'};assert.throws(()=>createTemple(p),/오버월드/);p.dimension=dim;const t=createTemple(p);assert.deepEqual([t.x,t.y,t.z],[0,63,22]);
});
test('occupied construction space is rejected before any block writes, and unbuilt failed sites are not protected',()=>{
 const {p,blocks,key,dim,control}=scene();const at={x:0,y:65,z:22};blocks.set(key(at),'minecraft:chest');createTemple(p);const t=drain();assert.equal(t.status,'error');assert.equal(control.writes,0);assert.equal(blocks.get(key(at)),'minecraft:chest');assert.equal(templeProtected(dim.getBlock(at)),false);
});
test('construction finishes every planned block in all quadrants and never overwrites the players position',()=>{
 const {p,dim}=built(),t=readTemple();let count=0;for(let i=0;i<TEMPLE_VOLUME;i++){const o=templeOffset(i),expected=templeBlock(o.x,o.y,o.z);if(!expected)continue;const at={x:t.x+o.x,y:t.y+o.y,z:t.z+o.z};if(o.y===2&&o.z===0&&o.x===-7)assert.equal(dim.getBlock(at).typeId,'minecraft:sea_lantern');else assert.equal(dim.getBlock(at).typeId,expected);count++;}assert.ok(count>700);assert.deepEqual(p.location,{x:0,y:64,z:0});
});
test('unavailable chunks pause without skipping positions and resume to a complete temple',()=>{
 const {p,control}=scene();control.unavailable=at=>at.x>=0;createTemple(p);tick(10);const before=readTemple();assert.equal(before.status,'scan');assert.equal(control.writes,0);tick(10);assert.equal(readTemple().cursor,before.cursor);control.unavailable=()=>false;assert.equal(drain().status,'ready');
});
test('verification repairs a dropped block write before marking the temple ready',()=>{
 const {p,dim,control,key}=scene();control.dropped.add(key({x:0,y:63,z:22}));createTemple(p);assert.equal(drain().status,'ready');assert.equal(dim.getBlock({x:0,y:63,z:22}).typeId,'minecraft:quartz_block');
});
test('day and night activate opposite altars without rebuilding the structure',()=>{
 const {control,dim}=built(),t=readTemple();for(const [time,kind]of [[0,'sun'],[11999,'sun'],[12000,'moon'],[23999,'moon']]){control.time=time;system.currentTick+=20;templeTick();assert.equal(celestialPhase(time),kind);assert.equal(dim.getBlock(altarPosition(t,kind)).typeId,'minecraft:sea_lantern');const other=kind==='sun'?'moon':'sun';assert.equal(dim.getBlock(altarPosition(t,other)).typeId,other==='sun'?'minecraft:gold_block':'minecraft:amethyst_block');}
});
test('both heir jobs require the correct live shrine, time, level, prior class and kill trial',()=>{
 const {p,control,blocks,key}=built();
 for(const [kind,id,time]of [['sun','sun_heir',1000],['moon','moon_heir',13000]]){
  control.time=time;atAltar(p,kind);assert.equal(checkAdvance(p,JOBS[id]).ok,true);p.setDynamicProperty('rpg:rpg_level',19);assert.equal(checkAdvance(p,JOBS[id]).ok,false);p.setDynamicProperty('rpg:rpg_level',20);
  const pos={...p.location};p.location.x+=20;assert.equal(checkAdvance(p,JOBS[id]).ok,false);p.location=pos;
  control.time=kind==='sun'?13000:1000;assert.equal(checkAdvance(p,JOBS[id]).ok,false);control.time=time;
  p.setDynamicProperty('rpg:job','apprentice');assert.equal(checkAdvance(p,JOBS[id]).ok,false);p.setDynamicProperty('rpg:job','swordsman');
  const a=altarPosition(readTemple(),kind),old=blocks.get(key(a));blocks.set(key(a),'minecraft:air');assert.equal(checkAdvance(p,JOBS[id]).ok,false);blocks.set(key(a),old);
 }
});
test('ordinary job commands cannot bypass shrine distance or time',()=>{
 const {p}=built();runRpgAction('job',p,'해의 후예');assert.equal(p.getDynamicProperty('rpg:job'),'swordsman');assert.ok(p.messages.some(s=>s.includes('신전')));
});
test('shrine UI actually advances a qualified visitor and rechecks time after a skill-loss confirmation',async()=>{
 let {p}=built();atAltar(p,'sun');replies.length=0;replies.push({canceled:false,selection:0});await openTemple(p);assert.equal(p.getDynamicProperty('rpg:job'),'sun_heir');assert.ok(forms.some(f=>f.heading==='해의 신전'));
 const s=built();p=s.p;atAltar(p,'sun');setSkills(p,['sword_spin']);replies.push({canceled:false,get selection(){s.control.time=13000;return 0;}});await requestAdvance(p,JOBS.sun_heir);assert.equal(p.getDynamicProperty('rpg:job'),'swordsman');
});
test('registered temple blocks resist player changes and explosions, while admins can edit and removal preserves blocks',()=>{
 const {p,dim,blocks}=built(),t=readTemple(),block=dim.getBlock(altarPosition(t,'sun')),visitor=player('temple-visitor',20,{dimension:dim});
 assert.equal(templeProtected(block),true);const edit={block,player:visitor,cancel:false};for(const fn of world.beforeEvents.playerBreakBlock.listeners)fn(edit);assert.equal(edit.cancel,true);edit.player=p;edit.cancel=false;for(const fn of world.beforeEvents.playerBreakBlock.listeners)fn(edit);assert.equal(edit.cancel,false);
 let impacted;for(const fn of world.beforeEvents.explosion.listeners)fn({getImpactedBlocks:()=>[block,dim.getBlock({x:100,y:63,z:100})],setImpactedBlocks:b=>{impacted=b;}});assert.equal(impacted.length,1);
 const before=blocks.size;removeTemple(p);assert.equal(readTemple(),undefined);assert.equal(blocks.size,before);assert.equal(templeProtected(block),false);assert.equal(templeRequirement(p,'sun').met,false);
});
test('interacting with an altar opens the time-appropriate private shrine menu',async()=>{
 const {p,dim}=built();atAltar(p,'sun');const ev={block:dim.getBlock(altarPosition(readTemple(),'sun')),player:p,cancel:false};replies.length=0;replies.push({canceled:true});const n=forms.length;for(const fn of world.beforeEvents.playerInteractWithBlock.listeners)fn(ev);await Promise.resolve();assert.equal(ev.cancel,true);assert.ok(forms.slice(n).some(f=>f.heading==='해의 신전'));
});
test('private gauntlet rendering is first-person-only while the inventory icon and damage stay intact',()=>{
 const read=path=>JSON.parse(fs.readFileSync(new URL(path,import.meta.url))),a=read('../RPG_RP_v0560/attachables/war_god_gauntlets.json')['minecraft:attachable'].description,c=read('../RPG_RP_v0560/render_controllers/rpg_private_gauntlet.render_controllers.json').render_controllers['controller.render.rpg_private_gauntlet'],i=read('../RPG_BP_v0560/items/war_god_gauntlets.json')['minecraft:item'].components;
 assert.equal(a.render_controllers[0]['controller.render.rpg_private_gauntlet'],'context.is_first_person');assert.equal(c.part_visibility[0]['*'],'context.is_first_person');assert.equal(i['minecraft:icon'],'rpg_war_god_gauntlets');assert.equal(i['minecraft:damage'],18);assert.ok(i['rpg:cast_item']);
 const geometry=read('../RPG_RP_v0560/models/entity/war_god_private.geo.json')['minecraft:geometry'][0];assert.equal(geometry.description.identifier,a.geometry.default);
});
